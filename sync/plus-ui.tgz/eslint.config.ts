import pluginVue from 'eslint-plugin-vue';
import globals from 'globals';
import prettier from 'eslint-plugin-prettier';
import vueTsEslintConfig from '@vue/eslint-config-typescript';
import skipFormatting from '@vue/eslint-config-prettier/skip-formatting';

// @vue/eslint-config-typescript@14 移除了 defineConfigWithVueTs / vueTsConfigs 两个具名导出，
// 改为默认导出工厂函数 vueTsEslintConfig()（返回 flat config 数组）。
// 因此这里直接用 ESLint 9 flat config 顶层数组组合，等价于旧 defineConfigWithVueTs(...) 的展开语义。
// 首块 app/files-to-lint 不带 rules，仅用于声明 ESLint 9 需要扫描的文件扩展名。
export default [
  {
    name: 'app/files-to-lint',
    files: ['**/*.{js,cjs,ts,mts,tsx,vue}']
  },

  {
    name: 'app/files-to-ignore',
    ignores: ['**/dist/**', '**/dist-ssr/**', '**/coverage/**']
  },
  {
    languageOptions: {
      globals: globals.browser
    }
  },
  ...pluginVue.configs['flat/essential'],
  ...vueTsEslintConfig(),
  skipFormatting,
  {
    name: 'app/vue-tsx-parser-final',
    files: ['**/*.vue'],
    languageOptions: {
      parserOptions: {
        parser: '@typescript-eslint/parser',
        ecmaFeatures: { jsx: true },
        extraFileExtensions: ['.vue']
      }
    }
  },
  {
    plugins: { prettier },
    rules: {
      '@typescript-eslint/no-empty-function': 'off',
      '@typescript-eslint/no-explicit-any': 'off',
      '@typescript-eslint/no-unused-vars': 'off',
      '@typescript-eslint/no-this-alias': 'off',
      // vue
      'vue/multi-word-component-names': 'off',
      'vue/valid-define-props': 'off',
      'vue/no-v-model-argument': 'off',
      'prefer-rest-params': 'off',
      // prettier
      'prettier/prettier': 'error',
      // 允许使用空Object类型 {}
      '@typescript-eslint/no-empty-object-type': 'off',
      'vue/block-lang': 'off',
      '@typescript-eslint/no-unused-expressions': 'off'
    }
  }
];
