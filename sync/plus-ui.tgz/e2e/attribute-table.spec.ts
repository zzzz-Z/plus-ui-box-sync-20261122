import { test, expect } from '@playwright/test';

/**
 * E2E：属性表不得出现重复的英文列。
 * 断言两条：
 * 1. 表头文字互不重复（label 去重生效）；
 * 2. 至少渲染出一列。
 */
test('属性表无重复英文列', async ({ page }) => {
  await page.goto('/');
  // 若有登录页则填默认超管账号（按项目实际账号调整）
  if (await page.locator('input[type="password"]').count()) {
    await page.locator('input[type="text"], input:not([type="password"])').first().fill('admin');
    await page.locator('input[type="password"]').fill('admin123');
    await page.keyboard.press('Enter');
    await page.waitForTimeout(2000);
  }
  // 按菜单文字导航，避免硬编码路由
  const menu = page.locator('text=元数据').first();
  if (await menu.count()) await menu.click();

  const table = page.locator('.attr-table');
  await expect(table).toBeVisible({ timeout: 15000 });

  const headers = await table.locator('.el-table__header-wrapper th .cell').allInnerTexts();
  const trimmed = headers.map((h) => h.trim()).filter(Boolean);
  expect(trimmed.length, '应渲染出列头').toBeGreaterThan(0);
  expect(new Set(trimmed).size, `表头重复: ${JSON.stringify(trimmed)}`).toBe(trimmed.length);
});