---
title: 参考文档目录职责
domain: _shared
type: reference
status: active
updated: 2026-11-17
tags: [reference, index]
---

# reference/ — 参考文档

> **受众 / 读取时机**：需要查某个模块的字段、接口契约、配置项等「事实型」信息时，在此目录按模块定位。
> **边界**：本目录只放参考类文档，不讲解原理、不写操作步骤（那属于 explanation/ 与 how-to/）。
> **导航**：全量文档见 [INDEX](../INDEX.md)。

## 职责表

| 文档 | 功能域 | 职责 / Owns | 更新时间 |
| --- | --- | --- | --- |
| — | — | 当前无参考文档；产品管理接口契约索引（含底图）已并入 skill：`.dsh/skills/frontend-api-sync-e2e/refs/apis/product-manage.md` | 2026-11-19 |
