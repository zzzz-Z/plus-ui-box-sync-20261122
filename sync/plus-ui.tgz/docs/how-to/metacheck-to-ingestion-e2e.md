---
title: 元数据检查 → 数据入库 端到端验证流程
domain: product-manage
type: how-to
status: active
updated: 2026-11-19
tags: [e2e, metadata-check, ingestion, product-manage, validation]
---

# 元数据检查 → 数据入库 端到端验证流程

> **受众 / 读取时机**：需要在产品管理模块验证「元数据检查」与「数据入库」完整链路（建检查 → 检查到终态 → 建入库批次 → 入库到终态 → 资源复核 → 清理）时，按本文复跑。
> **边界**：本文是**操作指南**，只讲「怎么跑、看什么、期望什么」。契约六维差异见 `.dsh/artifacts/metacheck-ingest/01-contract-diff.md`，历史实测数据与截图见 `.dsh/artifacts/data-pipeline-e2e/06-ui-evidence/`。本文不替代接口契约文档。
> **导航**：全量文档见 [INDEX](../INDEX.md)；接口契约索引（中文名 → docId）见 `.dsh/skills/frontend-api-sync-e2e/refs/apis/product-manage.md`，接口正文以在线 Apifox 文档为 SSOT。

---

## 一、这套流程验证什么

产品管理的「元数据检查」和「数据入库」是两个 tab（挂在产品线页，不是独立路由），链路核心是 **入库策略 `require_passed`（必须通过检查）真正消费上一环的检查结论**：

```
登录 → 建元数据检查任务 → 轮询到终态（接受/拒绝）
     → 用「接受」的 checkUid 建入库批次 → 列表点「开始」→ 入库到终态
     → 接口复核（资源/数据项/元数据）→ 清理测试数据
```

一次完整验证要拿到三类证据：

1. **UI E2E**：用无头浏览器真实填表建单，抓提交载荷，截图每步状态（证据：`06-ui-evidence/`）。
2. **接口复核**：用 token 直接打只读接口，核对 check / import / resource / metadata 的落库结果。
3. **反向与门禁**：检查不通过时入库被拦、缺必填被拒，证明服务端校验真实生效。

---

## 二、前置条件（开始前逐项确认）

| # | 条件 | 确认方式 | 不满足的后果 |
|---|---|---|---|
| 1 | dev server 在 `8091` 运行 | `lsof -nP -iTCP:8091 -sTCP:LISTEN`；`curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8091/ZHGL/` = 200 | 页面打不开，脚本全超时 |
| 2 | 产品网关可达 | `curl http://10.61.129.27:19999/datamanage/api/...` 带有效 token 返回 `code:0` | 列表为空 / 提交 500 |
| 3 | 登录态有效 | 跑 `node 00-login.mjs`，输出「登录态有效，复用」即 OK | 需先过验证码登录（见 §三） |
| 4 | Playwright + Chromium 已装 | `node -e "require('playwright')"` 不报错；本机只有完整版 Chromium，脚本已用 `channel:'chromium'` 走无头 | `chromium.launch` 失败 |
| 5 | 有可用于检查的元数据模型 + 共享目录 | 参照现有 `meta_common_fields` / `flys_sx` 模型与 `共享存储一` 下含 SHP 图层的目录（见 §七表） | 检查恒「拒绝」或入库报「不含 SHP 图层」 |

**环境事实**（来自历史实测，口径固定）：

- 前端 dev：`http://127.0.0.1:8091/ZHGL/`；产品网关：`http://10.61.129.27:19999/datamanage/api`（vite 代理前缀 `/dev-api/datamanage/api`）。
- 鉴权头：`Authorization: Bearer <token>` + `clientid: e5cd7e4891bf95d1d19206ce24a7b32e`。
- token 存浏览器 `localStorage['Admin-Token']`，存储值**不带** `Bearer ` 前缀；只走环境变量 / 脚本内存，禁止落盘到 `.dsh/` 之外（r229 曾误提交超管 JWT）。
- 入口页：`category-feature`（分类要素初级产品）或 `category-attribute`（分类要素属性产品），tab「元数据检查」/「数据入库」。

---

## 三、步骤 0 · 登录与登录态复用

脚本目录：`.dsh/artifacts/data-pipeline-e2e/pw/`，所有命令在该目录执行。

```bash
cd .dsh/artifacts/data-pipeline-e2e/pw
node 00-login.mjs
```

- 脚本先用现有 `.out/state.json` 探活；有效则直接复用，**不重复识别验证码**。
- 登录态失效时走 UI 登录：账号 `admin` / `admin123`，验证码是**算术型**（`a op b =`，提交算式结果，不是 4 字符）。脚本写 `.out/round_N.png`，由识图方回写 `.out/round_N.answer`（一行答案），脚本轮询。
- 成功后产出 `.out/state.json`（storageState）与 `.out/tok.txt`（裸 token），后续脚本自动带上，不再登录。

---

## 四、步骤 1 · 元数据检查（建单 → 终态）

```bash
# 先 DRY 跑：只填表 + 截图 + 取消，校准选择器，不落库
DRY=1 node 20-check.mjs

# 真建检查（默认 分类要素产品元数据 × 交通 × 元数据二 → 预期「拒绝」分支）
node 20-check.mjs

# 建一条「接受」分支（作为入库准入前提）
LEVELS='共享存储一,分类要素产品元数据模型,分类要素产品元数据,元数据一' NAME='（E2E链路·元数据一）' node 20-check.mjs
```

关键环境变量（ `20-check.mjs` ）：

| 变量 | 默认 | 作用 |
|---|---|---|
| `PAGE` | `category-feature` | 入口页；属性产品用 `category-attribute` |
| `MODEL` | `分类要素产品元数据` | 元数据模型名 |
| `CATEGORY` | `交通` | 产品类别名 |
| `LEVELS` | `共享存储一,分类要素产品元数据模型,分类要素产品元数据,元数据二` | 级联选择的来源路径（逗号分隔） |
| `SCOPE` | `全量` | 检查范围 |
| `NAME` | 空（自动生成） | 检查任务名后缀，便于与历史数据区分 |
| `DRY` | 空 | `=1` 只演练不提交 |

**期望结果**：任务跑到终态（`state=成功`），结论 `accepted=true / decision=接受` 或 `拒绝`。拒绝分支要有真实错误账本（如 `存储小数位超限`，字段 `nw_lon/ne_lon/sw_lon/se_lon`），证明检查逻辑生效而非链路故障。UI 提交载荷由 `page.on('request')` 抓取，核对含 `modelUid / productCategoryUid / sourceType / scope / taskName / sourceStorageUid / sourcePath`。

---

## 五、步骤 2 · 数据入库（建批次 → 开始 → 终态）

```bash
# 真建入库（require_passed，消费上一环「接受」的 checkUid）
TYPE='交通' POLICY='需要检查通过' LEVELS='共享存储一,分类要素产品元数据模型,分类要素产品元数据,元数据一' NAME='（E2E链路）' node 30-import.mjs

# 中途挂了用 RESUME=1 复用 .out/import-batch.json 续跑，避免重复建单
RESUME=1 node 30-import.mjs
```

关键环境变量（ `30-import.mjs` ）：

| 变量 | 默认 | 作用 |
|---|---|---|
| `TYPE` | `交通` | 产品类型 |
| `POLICY` | `需要检查通过` | 检查策略：`需要检查通过` / `直接入库` / `按需运行`（已弃用） |
| `LEVELS` | `共享存储一,分类要素产品元数据模型,分类要素产品元数据,元数据一` | 数据目录 |
| `PRIORITY` / `SECURITY` | `中` / `公开` | 优先级 / 数据级别 |
| `NAME` | 空（自动生成） | 批次名后缀 |
| `RESUME` | 空 | `=1` 复用已建批次续跑 |

**期望结果**：批次状态 `已创建 → 进行中 → 成功`，进度跑满（如 `309884/309884`），`stage=SUCCEEDED`，错误 0，产出 `resourceUid / dataUid / versionUid`。批次创建后停在「已创建」，**必须点列表行「开始」按钮**才推进（脚本已实现该 UI 路径）。

**门禁反向验证**：若检查结论为「拒绝」，用 `require_passed` 建入库应被拦，报「数据来源未通过元数据检查：检查单号 …（完整性=失败…）」，弹窗不关闭、列表不新增记录——证明门禁生效。

---

## 六、步骤 3 · 接口复核与清理

```bash
# 接口层复核 → .out/verify.json
node 40-verify.mjs

# 清理本轮探测数据（按任务名前缀批删，幂等）
ALL_PROBE=1 node 51-cleanup-bulk.mjs
# 或按前缀精确删
DEL_CHECKS='PROBE ' DEL_IMPORTS='PROBE ' node 51-cleanup-bulk.mjs
```

复核要点（ `40-verify.mjs` → `.out/verify.json` ）：

- 检查列表 `total` 增加、新任务名在列。
- 入库列表 `total` 增加、新批次状态「成功」。
- `GET /platform/resources/{uid}`：`state=就绪`、`dataCount/versionCount` 正确、`metadataModelUid` 与检查用模型一致。
- `GET /platform/imports/{uid}/items`：`total≥1`、状态成功。
- `GET /platform/imports/{uid}/metadata`：`model.bound=true`，`values` 含要素数 / 数据格式 / 坐标系 / 空间范围。

清理脚本按分类核验 `reportDeleted:false`（契约内正常返回，磁盘报告不影响删除结论）。全程**不留半成品**——失败的检查/批次也要删掉。

---

## 七、关键坑（复跑前必读）

1. **验证码是算术型**（`a op b =`），按字符提交必失败。
2. **本机无 chrome-headless-shell**，`chromium.launch({headless:true})` 报错；脚本用 `channel:'chromium'` 走完整版无头，不开窗口。
3. **弹窗标题选择器是 `.title-content`**，不是 `.el-dialog__title`（`create-dialog` 自定义 header）。
4. **label 全等匹配要剥星号去冒号**：Form 渲染成 `* 元数据模型:`，且「元数据模型/元数据位置」「检查范围/检查任务名称」互为前缀，子串匹配会选错。
5. **el-cascader（lazy + checkStrictly）两种点击语义**：中间级点 `.el-cascader-node__label` 展开并懒加载，末级点 `input.el-radio__original` 选中。级联回显恒空是组件自身限制，别拿 `inputValue()` 当选中依据，以提交载荷/接口为准。
6. **残留 popper 拦截点击**：交互一律 `locator.evaluate(el => el.click())` DOM dispatch。
7. **别用 `Escape` 收浮层**：会连弹窗一起关（`close-on-press-escape`）。
8. **filterable 的 el-tree-select 打 `.el-select__wrapper` 展开**，不是 `<input>`（那是搜索框）；节点文本在 `.el-tree-node__content > .el-select-dropdown__item > span`，无 `.el-tree-node__label`。
9. **入库页操作列无 `.row-actions` 包裹**，按 `row.locator('button')` 序号取：开始/暂停/恢复/取消/删除。
10. **列表首列显示 `taskName`/`batchName`，不是 uid**；按 uid 定位 UI 行必然失败，批删走接口。
11. **入库对源目录有「必须含 SHP 图层」服务端校验**：SMS/geojson-only 目录检查能过但入库必失败（「不含 SHP 图层」）。
12. **能走完整链路的表有限**：`flys_sx`（元数据一目录，图层与历史重复）、`meta_common_fields`（多个 past 目录，可用）。`flys_bhys` 检查能过但目录无 SHP，入库必失败。跨表对比要素数要用批次 `progress.total`（`meta_common_fields` 的 `metadata.values` 无 `feature_count`）。
13. **入参分页字段是 `limit` 不是 `page`/`size`**：`?page=1&size=2` 静默返回全量，`?limit=2` 才生效。
14. **读字段按实测口径**：`state`/`decision` 是中文（`成功`/`接受`），三维指标在 `summary` 下，列表项 `files=null`（用 `fileCount`），401 响应用 `msg` 不是 `message`。

---

## 八、已知后端缺陷（影响验证口径，不归咎前端）

来源：`.dsh/artifacts/metacheck-ingest/07-evidence.md`（接口探针 PASS 26 / 未通过 8，9 端点全覆盖）。

| # | 缺陷 | 对验证的影响 |
|---|---|---|
| **C6** | 关系 `tb_metadata_check` 缺 `source_type` 列，Worker 执行检查必失败 | 无法产出新 `accepted=true` 检查，`require_passed` 新链路在该环境可能无法端到端跑通（此时 UI E2E 用历史已接受数据） |
| **C7/C8** | `GET /platform/imports/*` 与 backfill 恒 120s → `code:500`（POST 正常） | 入库 GET 侧接口复核受阻；POST 反向校验仍拿到真实 400/409 |
| C9–C15 | 分页字段失效、中文枚举、三维指标嵌套层级、409 错误码不符、错误体字段缺失、列表 files=null | 前端已按实测实现 + 兜底；验证断言要用实测编码 |

处置原则：**阻塞可复现、归因明确、不伪装成功**——拿不到预期响应时如实记为未通过并附状态码，不因拿不到数据就改判 PASS。

---

## 九、命令速查

```bash
cd .dsh/artifacts/data-pipeline-e2e/pw
node 00-login.mjs                                   # 登录 / 复用登录态
DRY=1 node 20-check.mjs                             # 检查演练
node 20-check.mjs                                   # 建检查（拒绝分支）
LEVELS='共享存储一,...,元数据一' NAME='…接受' node 20-check.mjs  # 建检查（接受分支）
TYPE='交通' POLICY='需要检查通过' node 30-import.mjs            # 建入库并推进
RESUME=1 node 30-import.mjs                         # 入库续跑
node 40-verify.mjs                                  # 接口复核
ALL_PROBE=1 node 51-cleanup-bulk.mjs                # 批删清理
```

## 十、证据索引

| 证据 | 位置 | 内容 |
|---|---|---|
| UI E2E 第一轮 | `.dsh/artifacts/data-pipeline-e2e/06-ui-e2e-check-into-store.md` | 两检查 + 一入库完整链路、载荷、截图 |
| UI E2E 第二轮 | `.dsh/artifacts/data-pipeline-e2e/07-ui-e2e-round2-different-table-layer.md` | 换表换图层两条链路、通过性矩阵、清理 |
| 截图 | `.dsh/artifacts/data-pipeline-e2e/06-ui-evidence/` | 登录/检查/入库/详情/级联面板 PNG |
| 接口探针 | `.dsh/artifacts/metacheck-ingest/04-probe.log` | 9 端点正反向断言逐条 PASS/未通过 |
| 缺陷与闸门 | `.dsh/artifacts/metacheck-ingest/07-evidence.md` | 后端缺陷 C5–C15、G0–G7 闸门总表 |
| 契约快照 | `.dsh/artifacts/metacheck-ingest/01-contract/` | Apifox 原始 md 快照 |
