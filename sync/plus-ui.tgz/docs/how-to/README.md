---
title: 操作指南文档目录职责
domain: _shared
type: reference
status: active
updated: 2026-11-19
tags: [how-to, index]
---

# how-to/ — 操作指南文档

> **受众 / 读取时机**：需要按步骤完成一项具体任务（复跑验证、执行流程、配置某功能）时，在此目录定位。
> **边界**：本目录放「怎么做」的操作指南，不承载参考事实（reference/）或一次性报告（reports/）。
> **导航**：全量文档见 [INDEX](../INDEX.md)。

## 职责表

| 文档 | 功能域 | 职责 / Owns | 更新时间 |
| --- | --- | --- | --- |
| [元数据检查 → 数据入库 端到端验证流程](metacheck-to-ingestion-e2e.md) | product-manage | 产品管理两 tab 链路的可复跑 E2E SOP：登录 / 建检查 / 入库 / 复核 / 清理 / 坑表 / 后端缺陷口径 | 2026-11-19 |
