---
title: 契约对齐中的字段漂移与假数据改造：决策与复盘
domain: _shared
type: explanation
status: active
updated: 2026-11-19
tags: [contract-sync, field-drift, mock-to-real, e2e, decision, retrospective]
---

# 契约对齐中的字段漂移与假数据改造：决策与复盘

> **受众 / 读取时机**：接手接口契约对齐，遇到「文档与实测对不上」「页面显示假数据」「闸门误报」而想知道**为什么这样处理**时读本文。要动手执行请直接用项目级技能 `frontend-api-sync-e2e`。
> **边界**：本文解释决策依据与事故驱动的设计缘由，不重复操作步骤、不列接口清单（契约事实以线上 Apifox 为准，docId 索引见 `refs/apis/`）。「怎么做」归 skill，「为什么」归本文。
> **导航**：可执行 SOP 见 `.dsh/skills/frontend-api-sync-e2e/SKILL.md`（本地技能，VCS 忽略）；端到端验证流程见[元数据检查 → 数据入库](../how-to/metacheck-to-ingestion-e2e.md)；文档规范见[索引](../INDEX.md)。

## 背景

本会话在「数据提取 / 版本管理 / 数据更新」三模块做接口与 UI 的端到端对齐，规则大多不是预先写好，而是被一次次误判逼出来的。本文把每条规则背后的**案例、权衡与后果**记下来，避免后来者重复踩坑，或把它们当成可以随手简化的繁文缛节。

## 为什么「实测优先于文档」

文档与后端版本错位是常态，不能拿旧文档或历史类型当真相。判据用响应体 `code` 而非 HTTP 状态码（网关先鉴权，无 token 时返回的是业务码 `401` 而非 HTTP 401）。同一端点按 query 变体分别实测——一个端点不同参数组合可能是不同契约。探活时 **HTML 404（drogon 兜底页）= 路由不存在，JSON 业务错 = 路由存在**，这条区分是后面所有决策的地基：没有可靠观测，归一化和定夺都是空谈。

## 为什么整组字段漂移要在接口层单点归一

版本列表接口（docId 532351480）是一次典型事故：文档与页面按 `versionNo / changeFields(字符串数组) / 英文 operation / createdByRef` 写，后端实测返回的却是 `rowVersion / changedFields(对象数组,带中文 label) / 中文 operation / actor(JSON 串)`。症状是版本号裸 `v`、比较器失效、操作人显示乱码——这不是单个字段改名，而是**整组字段集 + 枚举值域 + 结构全漂移**。

两个看似自然的错误做法：

- 在页面逐处写 `raw.versionNo ?? raw.rowVersion`：必然漏掉某一处，退回「副本未同步」的老事故；
- 改前端语义去迎合后端：把后端契约失准掩盖掉，下次没人知道文档已经错了。

最终选择（用户定夺）：在**接口层**加唯一的 `normalizeXxx()`，一次性完成字段改名 + 值域归一（中英 operation 统一）+ 结构归一（changedFields 对象数组 → 可读 label、actor JSON 串 → 可读文本），页面只读归一化后的字段；同时另出一份后端缺陷报告。理由是兼容与追责两不误——前端能正常显示，后端问题也留了案，不会被兼容层永久掩盖。

## 为什么无专用接口要先定夺再动手

「数据更新」页报假数据，但探活发现 `/platform/data-updates`、`/platform/data-deliveries`、`/platform/metadata/updates` 一族路径全 404；唯一真实承载该业务的是 `/platform/data-extractions`（与「数据提取」共用同一批后端任务记录）。

这里不做两件事：不自己凭空新建一个「数据更新接口」，也不默默选一族接上。因为「这个页面到底该与谁共用数据」是**产品语义决策**，副作用（与数据提取页数据相近）必须由用户知情。用 `ask_user_question` 让用户在「复用真实接口族（接受接近数据提取）/ 先不做 / 其他」中定夺，用户选了复用。未定夺前不动手，是这个场景的硬规矩。

## 为什么假数据页要删净四类本地状态

定夺复用之后，只把列表请求换成真接口是不够的，会留下更隐蔽的「真接口 + 假状态」混搭。必须删净四类本地假状态：

1. 本地 store / seed（`createTaskStore`、`TASK_SEEDS`、`buildXxxTasks`）；
2. 假进度定时器（`setInterval` 给 `progress` 自增）；
3. 本地建任务 / 改状态（`createTask`、`splice` 改状态）；
4. 本地 filter 冒充查询。

列表直连真实接口；关键词与左树勾选这类无法下推后端的过滤，明确标注为**前端过滤**并按过滤结果计 total。分页键名按实测契约走——`data-extractions` 用的是 `page` 而非项目通用的 `pageNum`，但仍用 `:request-cfg` 显式声明 `items` 壳字段。左树按中文类别名对 `categories[].categoryName` 前端过滤（后端只收 `categoryUid`），并在注释写明原因。理由：混搭比纯假数据更难查——真请求会掩盖假状态，让人误以为整条链路都是真的。

## 为什么写操作 E2E 后要恢复数据、且业务错误不算契约错

写操作 E2E 必然改动真实库。收工前要用**同一条写链**把业务值改回原值（本会话把 `meta_id` 从 `5101 → 5102` 后又用 plan → edit-sessions → apply → release 改回 `5101`）；`rowVersion` 递增属正常历史，不必也无法回退。理由：探针绝不留脏数据。

反过来，像「几何解析或坐标转换失败」「取值必须是整数」这类返回，是**后端字段校验生效**，不是前端契约错。判法：请求体逐字段核对契约，若字段与值全对，就是业务校验；再复查该记录原值未变，说明数据库未被改动，无需恢复。别去改前端载荷迎合后端校验，也别在业务错误时慌着回滚——先用非法值验证前端 `validateField` 基于真实 `field.type` 拦截成功，再填合法值走通，反而能证明删硬编码后校验走的是真实字段定义。

## 为什么闸门误报要限定 SRC 而不是改代码

`selfcheck.sh G3` 扫的是**全仓**的 `setInterval` / mock 引用，命中他模块历史代码并不代表本次改动有问题。为了让「全仓零」而去改那些无关代码，等于一次性迁移整个模块，是范围扩张，应当先问用户。正确做法是用脚本原生的 `SRC=<本次改动目录>` 把扫描限定到本次范围；`G2`（旧字段/载荷点）与 `G3`（定时器/mock）扫描范围不同，必须**分开跑**（单一 `SRC` 与跨目录的 G2 冲突），证据里写清「全仓告警数 / 本次命中数 / 归属」。另有两条易踩：G5 日志必须写字面量 `PASS`（中文「通过」会判 FAIL）；脚本须在项目根执行，否则报 `DSH_WS_ROOT unbound variable`。

## 几个反直觉的 E2E 坑（操作细节见 skill stage-5）

- 慢接口（本仓约 8s）导致页面「总记录 0」：先查接口耗时再判「没接线」，切 tab 后 `sleep ~12s`，CDP 内异步 fetch 结果再 `sleep ~9s` 才读；
- `cdp.js --eval "localStorage.getItem('Admin-Token')"` 返回 `{"value":"..."}` 包装串，需 `JSON.parse(r).value` 取纯 token 才能拼 header，否则报 `code=401`；
- 排查登录态只列 `Object.keys(localStorage)` 或只取 token，别把 `mdm.*` 旧 mock 缓存全导出来；
- 用户报「控制台 `ERR_CONNECTION_REFUSED`、页面打不开」时，多半是我起的临时验证 dev server（如 8092）随 worktree 删除而停，把标签导回正式端口（8091）即恢复，与代码无关。

## 与 skill 的分工

项目级技能 `frontend-api-sync-e2e` 负责「怎么做」——G0–G7 闸门、`stage-0~7` 操作细则、`pitfalls.md` 坑表、`selfcheck.sh` 脚本；本文负责「为什么这么做」。两者表述冲突时，以 skill 的操作细节为准执行，本文用于理解与回顾决策。契约事实以线上 Apifox 为 SSOT；接口 docId 索引见技能目录下的 `.dsh/skills/frontend-api-sync-e2e/refs/apis/product-manage.md`。
