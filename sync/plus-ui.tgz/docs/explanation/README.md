---
title: 解释型文档目录职责
domain: _shared
type: reference
status: active
updated: 2026-11-19
tags: [explanation, index]
---

# explanation/ — 解释型文档

> **受众 / 读取时机**：想知道某个处理方式「为什么这样设计、为什么排除了别的做法」时，在此目录定位。要动手执行请用 [how-to](../how-to/README.md) 或项目级技能。
> **边界**：本目录放「为什么」的决策依据与复盘，不承载操作步骤（how-to/）、参考事实（reference/）或一次性盘点报告（reports/）。
> **导航**：全量文档见 [INDEX](../INDEX.md)。

## 职责表

| 文档 | 功能域 | 职责 / Owns | 更新时间 |
| --- | --- | --- | --- |
| [契约对齐中的字段漂移与假数据改造：决策与复盘](contract-drift-and-mock-replacement.md) | _shared | 契约对齐中整组字段漂移、无专用接口定夺、假数据改造、写操作恢复、闸门误报等决策的依据与事故复盘 | 2026-11-19 |
