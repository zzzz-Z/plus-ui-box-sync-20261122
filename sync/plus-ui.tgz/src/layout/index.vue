<template>
  <div :class="classObj" class="app-wrapper" :style="{ '--current-color': theme }">
    <div v-if="device === 'mobile' && sidebar.opened" class="drawer-bg" @click="handleClickOutside" />
    <!-- 头部全宽 -->
    <div class="top-header">
      <navbar @set-layout="setLayout" />
    </div>
    <!-- 侧边栏 + 主内容区 -->
    <div class="layout-body">
      <side-bar v-if="!sidebar.hide" class="sidebar-container" />
      <div :class="{ sidebarHide: sidebar.hide }" class="main-container">
        <app-main />
        <settings ref="settingRef" />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import SideBar from './components/Sidebar/index.vue';
import { AppMain, Navbar, Settings } from './components';
import { useAppStore } from '@/store/modules/app';
import { useSettingsStore } from '@/store/modules/settings';
import { NavTypeEnum } from '@/enums/NavTypeEnum';
import { initWebSocket } from '@/utils/websocket';

const settingsStore = useSettingsStore();
const theme = computed(() => settingsStore.theme);
const sidebar = computed(() => useAppStore().sidebar);
const device = computed(() => useAppStore().device);
const layout = computed(() => settingsStore.navType);

// 根据布局模式判断是否显示侧边栏
const showSidebar = computed(() => {
  if (sidebar.value.hide) return false;
  return layout.value === NavTypeEnum.LEFT || layout.value === NavTypeEnum.MIX;
});

const classObj = computed(() => ({
  hideSidebar: !sidebar.value.opened,
  openSidebar: sidebar.value.opened,
  withoutAnimation: sidebar.value.withoutAnimation,
  mobile: device.value === 'mobile'
}));

const { width } = useWindowSize();
const WIDTH = 992; // refer to Bootstrap's responsive design

watchEffect(() => {
  if (device.value === 'mobile') {
    useAppStore().closeSideBar({ withoutAnimation: false });
  }
  if (width.value - 1 < WIDTH) {
    useAppStore().toggleDevice('mobile');
    useAppStore().closeSideBar({ withoutAnimation: true });
  } else {
    useAppStore().toggleDevice('desktop');
  }
});

const settingRef = ref<InstanceType<typeof Settings>>();

/**
 * 侧边栏兜底恢复：
 * 驾驶舱这类全屏页会临时把 sidebar.hide 置 true；万一组件卸载时没恢复（缓存/异常），
 * 用户会停在"没有菜单"的页面里，点菜单自然没反应。这里在路由变化后做一次校正，
 * 只对「左侧/混合导航」生效（顶部导航布局本来就把侧边栏隐藏，不能误开）。
 */
const route = useRoute();
watch(
  () => route.path,
  (p) => {
    const appStore = useAppStore();
    const layoutIsTop = layout.value === NavTypeEnum.TOP;
    if (p !== '/cockpit' && appStore.sidebar.hide && !layoutIsTop) {
      appStore.toggleSideBarHide(false);
    }
  },
  { immediate: true }
);

onMounted(() => {
  const protocol = window.location.protocol === 'https:' ? 'wss://' : 'ws://';
  initWebSocket(protocol + window.location.host + import.meta.env.VITE_APP_BASE_API + '/resource/websocket');
});

const handleClickOutside = () => {
  useAppStore().closeSideBar({ withoutAnimation: false });
};

const setLayout = () => {
  settingRef.value?.openSetting();
};

/**
 * 分区样式作用域：把当前分区以 class 形式挂到 <html>，供
 * assets/styles/index.scss 里的 `html.group-task` / `html.group-manage` 命中。
 *
 * 为什么挂在 <html> 而不是 .app-wrapper：
 *   el-dialog / el-drawer / el-message / el-select 下拉 / el-date-picker 面板
 *   都 teleport 到 <body>，它们的祖先在 #app 之外，容器级选择器选不中，
 *   只有挂在 <html> 这一层，路由内组件与弹层才都能被同一个作用域覆盖。
 *
 * 分区口径与 Sidebar / AppMain 的 showPageHeader 完全一致（都读 route.matched
 * 上的 meta.group），不使用 appStore.activeGroup —— 后者是持久化的「上次点的分区」，
 * 直接输地址或进驾驶舱时会与真实路由不一致。
 */
const isManageGroup = computed<boolean>(() => route.matched.some((r) => (r.meta as any)?.group === 'manage'));

watchEffect(() => {
  const el = document.documentElement;
  el.classList.toggle('group-manage', isManageGroup.value);
  el.classList.toggle('group-task', !isManageGroup.value);
});

// 退出 Layout（登出 / 跳 404）时清掉，避免分区类残留到登录页
onBeforeUnmount(() => {
  document.documentElement.classList.remove('group-manage', 'group-task');
});
</script>

<style lang="scss" scoped>
@use '@/assets/styles/mixin.scss';
@use '@/assets/styles/variables.module.scss' as *;

.app-wrapper {
  @include mixin.clearfix;
  position: relative;
  height: 100%;
  width: 100%;

  &.mobile.openSidebar {
    position: fixed;
    top: 0;
  }
}

.drawer-bg {
  background: #000;
  opacity: 0.3;
  width: 100%;
  top: 0;
  height: 100%;
  position: absolute;
  z-index: 999;
}

.top-header {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 1000;
  background-image: url('../assets/images/顶部背景.png');
}

.layout-body {
  display: flex;
  padding-top: var(--app-header-height);
  min-height: 100vh;

  .main-container {
    flex: 1;
    min-width: 0;
  }
}

.fixed-header {
  position: fixed;
  top: 0;
  right: 0;
  z-index: 9;
  width: calc(100% - #{$base-sidebar-width});
  transition: width 0.28s;
  background: $fixed-header-bg;
  box-shadow: 0 2px 8px rgba(0, 21, 41, 0.1);
}

.hideSidebar .fixed-header {
  width: calc(100% - 54px);
}

.sidebarHide .fixed-header {
  width: 100%;
}

.mobile .fixed-header {
  width: 100%;
}
</style>
