<template>
  <section class="app-main">
    <PageHeader v-if="showPageHeader" />
    <div ref="viewRef" class="app-main__view">
      <router-view v-slot="{ Component, route }">
        <transition :enter-active-class="animate" mode="out-in">
          <keep-alive :include="tagsViewStore.cachedViews">
            <component :is="Component" v-if="!route.meta.link" :key="route.path" />
          </keep-alive>
        </transition>
      </router-view>
    </div>
    <iframe-toggle />
  </section>
</template>

<script setup name="AppMain" lang="ts">
import { useSettingsStore } from '@/store/modules/settings';
import { useTagsViewStore } from '@/store/modules/tagsView';
import { applyQueryBackground } from '@/utils/queryBg';

import IframeToggle from './IframeToggle/index.vue';
const { proxy } = getCurrentInstance() as ComponentInternalInstance;
const route = useRoute();
const tagsViewStore = useTagsViewStore();

// 随机动画集合
const animate = ref<string>('');
const animationEnable = ref(useSettingsStore().animationEnable);
watch(
  () => useSettingsStore().animationEnable,
  (val: boolean) => {
    animationEnable.value = val;
    if (val) {
      animate.value = proxy?.animate.animateList[Math.round(Math.random() * proxy?.animate.animateList.length)] as string;
    } else {
      animate.value = proxy?.animate.defaultAnimate as string;
    }
  },
  { immediate: true }
);

onMounted(() => {
  addIframe();
});

watchEffect(() => {
  addIframe();
});

function addIframe() {
  if (route.meta.link) {
    useTagsViewStore().addIframeView(route);
  }
}

/**
 * 是否渲染全局 PageHeader（页面标题条）
 *
 * 「数据管理」分区（后端菜单树，permission.ts 里 tagManage 打的 meta.group === 'manage'）
 * 的页面自带顶部 tab / 标题栏，再挂一条 44px 标题条只会挤占内容高度，所以整区隐藏。
 * 分区判定口径与布局侧一致（Sidebar / Navbar 同样用 route.matched 上的 meta.group），
 * 避免出现「菜单认为是任务分区、标题条认为是数据分区」的不一致。
 *
 * 逃生口：个别页面需要恢复标题条时，在路由 meta 上写 `pageHeader: true` 即可。
 */
const showPageHeader = computed<boolean>(() => {
  const override = (route.meta as any)?.pageHeader;
  if (typeof override === 'boolean') return override;
  return !route.matched.some((r) => (r.meta as any)?.group === 'manage');
});

/**
 * 查询区背景图：按表单"实际渲染行数"自动挂 one_input / two_input 类
 * （行数随窗口宽度变化，所以窗口尺寸、DOM 结构、显隐变化后都要重算）
 */
const viewRef = ref<HTMLElement>();
let queryBgObserver: MutationObserver | undefined;
let queryBgTimer: ReturnType<typeof setTimeout> | undefined;

function scheduleQueryBg() {
  clearTimeout(queryBgTimer);
  queryBgTimer = setTimeout(() => applyQueryBackground(viewRef.value || document), 100);
}

onMounted(() => {
  scheduleQueryBg();
  window.addEventListener('resize', scheduleQueryBg);
  if (viewRef.value) {
    queryBgObserver = new MutationObserver(scheduleQueryBg);
    // 只看结构变化与内联样式变化（v-show 切显隐）；applyQueryBackground 幂等，不会自激
    queryBgObserver.observe(viewRef.value, { childList: true, subtree: true, attributes: true, attributeFilter: ['style'] });
  }
});

onBeforeUnmount(() => {
  window.removeEventListener('resize', scheduleQueryBg);
  queryBgObserver?.disconnect();
  clearTimeout(queryBgTimer);
});

watch(
  () => route.path,
  () => nextTick(scheduleQueryBg)
);
</script>

<style lang="scss" scoped>
/**
 * 应用主区容器
 *
 * 高度用 height 而非 min-height：min-height 只设下界，内容超出时容器会跟着变高，
 * 挤到视口外触发页面级滚动条。这里用确定高度 + flex 列布局，
 * 把「PageHeader 之外的空间」锁死，子页面只能在这块空间内自行滚动。
 * 注意：--app-header-height 只含顶部导航(100px)，未含 PageHeader(44px)，
 * 后者由 flex-shrink:0 保留自身高度、不参与剩余空间分配。
 *
 * 外边距：margin 既不计入 height 也不计入 width，所以高度必须显式扣掉上下 10px，
 * 宽度用 auto 让块级元素自己减掉左右 10px；写成 100% 会横向溢出 20px。
 */
.app-main {
  height: calc(100vh - var(--app-header-height) - 20px);
  width: auto;
  /* 内容卡片：四边留 10px（露出 .main-container 的浅灰底）+ 1px 描边 */
  margin: 10px;
  border: 1px solid #e7eff8;
  box-sizing: border-box;
  position: relative;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  padding: 8px;
}

/* 路由视图容器：占满 PageHeader 之外的剩余空间，内层页面滚动在此消化
   注意：这里必须是 auto（可滚动），否则"长内容页"（如执行管理展开子任务）
   内容超出后会被直接裁掉、且全页没有滚动条。列表页的"锁定高度 + 表格内部滚动"
   由下方全局样式里 :has(.pagination-container) 的规则负责收回。 */
.app-main__view {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
}

.hasTagsView {
  .app-main {
    /* 顶部导航 + tags-view(34) + 上下 margin(20)（当前未挂载 tags-view，保留以防后续开启） */
    height: calc(100vh - var(--app-header-height) - 34px - 20px);
  }
}
</style>
<style lang="scss">
// fix css style bug in open el-dialog
.el-popup-parent--hidden {
  .fixed-header {
    padding-right: 6px;
  }
}

::-webkit-scrollbar {
  width: 6px;
  height: 6px;
}

::-webkit-scrollbar-track {
  background-color: var(--el-fill-color-lighter);
}

::-webkit-scrollbar-thumb {
  background-color: var(--el-text-color-placeholder);
  border-radius: 999px;
}

/* ===============================================================
   表格页面统一高度策略
   （从此不再需要给每个页面写 height="calc(100vh - xxx)" 这类魔法数字）
   ---------------------------------------------------------------
   背景：.app-main 是「确定高度 + overflow:hidden」的 flex 容器，
        而页面内部没有高度约束 → 内容一多就被裁掉，分页被顶出可视区。
   做法：页面根节点吃满可用高度并纵向排布 → 查询区/工具栏/分页按内容固定，
        表格吃掉剩余高度、表体自己滚动。
   兼容：已显式设置 height/max-height 的表格由 Element Plus 写内联样式，
        内联优先级更高，不受本规则影响（不会破坏现有正常页面）。
   =============================================================== */
.app-main__view > * {
  height: 100%;
  min-height: 0;
  display: flex;
  flex-direction: column;
}

/* 查询区 / 工具栏 / 分页 / 页签：按自身内容高度固定，不参与拉伸 */
.app-main__view .el-card,
.app-main__view .search-card,
.app-main__view .list-toolbar,
.app-main__view .pagination-container,
.app-main__view .el-form--inline,
.app-main__view .el-tabs__header {
  flex: 0 0 auto;
}
.app-main__view .pagination-container {
  margin-top: 8px;
}

/* 表格：吃满剩余高度，表体内部滚动（不再依赖 height 属性） */
.app-main__view .el-table {
  flex: 1 1 auto;
  min-height: 0;
}
.app-main__view .el-table > .el-table__inner-wrapper {
  height: 100%;
  display: flex;
  flex-direction: column;
}
.app-main__view .el-table .el-table__header-wrapper,
.app-main__view .el-table .el-table__footer-wrapper {
  flex: 0 0 auto;
}
.app-main__view .el-table .el-table__body-wrapper {
  flex: 1 1 auto;
  min-height: 0;
  overflow-y: auto;
}

/* ===============================================================
   两类页面必须分开处理（用 :has() 自动识别，无需给任何页面单独配置）
   ---------------------------------------------------------------
   A 列表页（页面内含 .pagination-container）：
       锁定高度 → 表格内部滚动、分页固定在底部（上面那组规则只服务于这一类）
   B 长内容页（没有分页，例如「任务调度 → 执行管理」：多张表 + 展开子任务）：
       整页滚动 → 内容再长也能滚到底，不会出现"展开后什么都没有、也没有滚动条"
   =============================================================== */

/* B（默认）：页面自身可滚动 */
.app-main__view {
  overflow-y: auto;
}

/* A：含分页 → 锁定高度，滚动交给表格内部 */
.app-main__view:has(.pagination-container) {
  overflow: hidden;
}

/* B：把上一版对"所有页面"的强制约束收回，避免长内容页被拉伸/裁切 */
.app-main__view:not(:has(.pagination-container)) > * {
  height: auto;
  min-height: 0;
  display: block;
}
.app-main__view:not(:has(.pagination-container)) .el-table {
  flex: none;
}
.app-main__view:not(:has(.pagination-container)) .el-table > .el-table__inner-wrapper {
  height: auto;
  display: block;
}
.app-main__view:not(:has(.pagination-container)) .el-table .el-table__body-wrapper {
  flex: none;
}

/* A 类（含分页的列表页）：把页面级滚动收回来，交给表格内部滚动。
   用三层类名提高权重，压过上面 scoped 编译出来的 .app-main__view[data-v-x]。 */
.main-container .app-main .app-main__view:has(.pagination-container) {
  overflow: hidden;
}
</style>
