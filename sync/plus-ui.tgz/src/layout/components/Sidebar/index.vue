<template>
  <!-- 侧边栏面板只保留背景图（见 assets/styles/sidebar.scss），不再叠加纯色底 -->
  <div :class="{ 'has-logo': showLogo }">
    <logo v-if="showLogo" :collapse="isCollapse" />
    <el-scrollbar :class="sideTheme" wrap-class="scrollbar-wrapper">
      <transition :enter-active-class="proxy?.animate.menuSearchAnimate.enter" mode="out-in">
        <el-menu
          :default-active="activeMenu"
          :default-openeds="defaultOpeneds"
          :collapse="isCollapse"
          :background-color="bgColor"
          :text-color="textColor"
          :unique-opened="true"
          :active-text-color="'#ffffff'"
          :collapse-transition="false"
          :popper-offset="12"
          mode="vertical"
        >
          <sidebar-item v-for="(r, index) in sidebarRouters" :key="r.path + index" :item="r" :base-path="r.path" />
        </el-menu>
      </transition>
    </el-scrollbar>
  </div>
</template>

<script setup lang="ts">
import Logo from './Logo.vue';
import SidebarItem from './SidebarItem.vue';
import variables from '@/assets/styles/variables.module.scss';
import { useAppStore } from '@/store/modules/app';
import { useSettingsStore } from '@/store/modules/settings';
import { usePermissionStore } from '@/store/modules/permission';
import { RouteRecordRaw } from 'vue-router';

const { proxy } = getCurrentInstance() as ComponentInternalInstance;

const route = useRoute();
const appStore = useAppStore();
const settingsStore = useSettingsStore();
const permissionStore = usePermissionStore();
/**
 * 侧边栏菜单：按当前分区展示
 *  - task   -> 三个分系统（本地路由）
 *  - manage -> 后端菜单树（原管理系统那套：安全管理/数据库配置/数据存取/备份恢复/运维监控/子系统管理/系统管理）
 */
const sidebarRouters = computed<RouteRecordRaw[]>(() =>
  appStore.activeGroup === 'manage' ? permissionStore.getManageRoutes() : permissionStore.getSidebarRoutes()
);

/** 路由变化时同步分区：进入后端菜单页面即切到「数据管理」，回到任务模块则切回 */
watch(
  () => route.path,
  () => {
    const inManage = route.matched.some((r) => (r.meta as any)?.group === 'manage');
    if (inManage && appStore.activeGroup !== 'manage') appStore.setActiveGroup('manage');
    else if (!inManage && appStore.activeGroup === 'manage') appStore.setActiveGroup('task');
  },
  { immediate: true }
);

const defaultOpeneds = computed(() => {
  return sidebarRouters.value
    .filter((r: RouteRecordRaw) => !r.hidden && r.children && r.children.length > 0)
    .map((r: RouteRecordRaw) => r.path);
});
const showLogo = computed(() => settingsStore.sidebarLogo);
const sideTheme = computed(() => settingsStore.sideTheme);
const isCollapse = computed(() => !appStore.sidebar.opened);

const activeMenu = computed(() => {
  const { meta, path } = route;
  // if set path, the sidebar will highlight the path you set
  if (meta.activeMenu) {
    return meta.activeMenu;
  }
  return path;
});

const bgColor = computed(() => (sideTheme.value === 'theme-dark' ? variables.menuBackground : variables.menuLightBackground));
const textColor = computed(() => (sideTheme.value === 'theme-dark' ? variables.menuColor : variables.menuLightColor));
</script>
