<template>
  <div class="navbar">
    <!-- 左侧：折叠按钮 + 任务管理分系统 -->
    <div class="navbar-left">
      <!-- <div class="hamburger" @click="toggleSideBar">
        <el-icon :size="22"><Fold v-if="!appStore.sidebar.opened" /><Expand v-else /></el-icon>
      </div> -->
      <img src="../../assets/images/图标.png" alt="" @click="toggleSideBar" />
      <span class="platform-title">{{ t('app.headerTitle') }}</span>
    </div>

    <!-- 中间：分区切换（任务管理 / 数据管理） -->
    <div class="navbar-center">
      <div
        v-for="item in groupList"
        :key="item.key"
        class="system-switch-item"
        :class="{ active: appStore.activeGroup === item.key }"
        @click="switchGroup(item.key)"
      >
        <span class="system-name">{{ item.label }}</span>
      </div>
    </div>

    <!-- 右侧：个人头像 -->
    <div class="navbar-right">
      <!-- 运行驾驶舱快捷入口：跳转到菜单里配置的驾驶舱页面（/cockpit） -->
      <div class="nav-cockpit-btn" :title="t('route.cockpit')" @click="goCockpit">
        <el-icon :size="18"><DataAnalysis /></el-icon>
      </div>
      <!--      <div @click="returnHome" style="cursor: pointer; color: white; font-size: 12px; padding-right: 10px">返回首页</div>-->
      <el-dropdown trigger="click" @command="handleCommand">
        <div class="avatar-wrapper">
          <!-- 头像统一用默认图（不再读系统里的人物头像） -->
          <img :src="defaultAvatar" class="user-avatar" />
          <!--          <span class="username">{{ userStore.name }}</span>-->
          <!--          <el-icon><caret-bottom /></el-icon>-->
        </div>
        <template #dropdown>
          <el-dropdown-menu>
            <router-link to="/user/profile">
              <el-dropdown-item>{{ t('navbar.personalCenter') }}</el-dropdown-item>
            </router-link>
            <el-dropdown-item v-if="settingsStore.showSettings" command="setLayout">
              <span>{{ t('navbar.layoutSetting') }}</span>
            </el-dropdown-item>
            <el-dropdown-item divided command="logout">
              <span>{{ t('navbar.logout') }}</span>
            </el-dropdown-item>
          </el-dropdown-menu>
        </template>
      </el-dropdown>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useAppStore } from '@/store/modules/app';
import { useUserStore } from '@/store/modules/user';
import { useSettingsStore } from '@/store/modules/settings';
import { usePermissionStore } from '@/store/modules/permission';
import { getNormalPath } from '@/utils/ruoyi';
import { removeToken } from '@/utils/auth';
import router from '@/router';
import { RouteRecordRaw } from 'vue-router';
import { ElMessageBox } from 'element-plus';
import { DataAnalysis } from '@element-plus/icons-vue';
import { ElMessageBoxOptions } from 'element-plus/es/components/message-box/src/message-box.type';
import defaultAvatar from '@/assets/images/人.png';
import i18n from '@/lang/index';

const t = (key: string) => i18n.global.t(key);

const appStore = useAppStore();
const userStore = useUserStore();
const settingsStore = useSettingsStore();
const permissionStore = usePermissionStore();

const { proxy } = getCurrentInstance() as ComponentInternalInstance;

const emits = defineEmits(['setLayout']);

/**
 * 分区切换：
 *  - task   -> 任务管理（本地三个分系统菜单）
 *  - manage -> 数据管理（后端菜单树，原管理系统那套菜单）
 * 切换后侧边栏换成该分区菜单（Sidebar 按 appStore.activeGroup 过滤），
 * 并把路由跳到该分区菜单的第一个页面。
 */
const groupList = computed(() => [
  { key: 'task' as const, label: t('app.groupTaskShort') },
  { key: 'manage' as const, label: t('app.groupDataShort') }
]);

/**
 * 路径是否真的能访问：匹配到的记录数 > 1 说明命中了真实页面
 * （只命中 1 条说明落到了 constantRoutes 里的 404 兜底路由）；
 * 另外校验分区归属，避免跳到另一个分区的同名页面。
 */
const isRoutable = (path: string, group: 'task' | 'manage'): boolean => {
  const matched = router.resolve(path).matched;
  if (matched.length < 2) return false;
  const isManage = matched.some((r) => (r.meta as any)?.group === 'manage');
  return group === 'manage' ? isManage : !isManage;
};

/**
 * 深度优先找出菜单里第一个可访问的叶子页面（目录可能嵌套多层，
 * 例如「数据管理 → 配置运维管理 → 安全管理 → 角色管理」）。
 */
const findFirstLeaf = (list: RouteRecordRaw[], group: 'task' | 'manage', parentPath = ''): string => {
  for (const item of list) {
    if (item.hidden) continue;
    const anyItem = item as any;
    // 与侧边栏 SidebarItem 的路径拼接保持一致（父级 '/' 时会拼出 '//x'，需归一化）
    const fullPath = anyItem.path?.startsWith('/') ? anyItem.path : getNormalPath(`${parentPath}/${anyItem.path}`);
    const children = (anyItem.children || []).filter((c: any) => !c.hidden);
    if (children.length) {
      const hit = findFirstLeaf(children, group, fullPath);
      if (hit) return hit;
      continue;
    }
    const candidates = [anyItem.meta?.activeMenu, fullPath].filter(Boolean) as string[];
    const hit = candidates.find((p) => isRoutable(p, group));
    if (hit) return hit;
  }
  return '';
};

/** 取某分区菜单里第一个能访问的页面，作为切换分区后的落地页 */
const firstPageOf = (group: 'task' | 'manage'): string => {
  const list: RouteRecordRaw[] = group === 'manage' ? permissionStore.getManageRoutes() : permissionStore.getSidebarRoutes();
  return findFirstLeaf(list, group);
};

/**
 * 各分区的固定落地页（点头部切换项时进入的页面）。
 *
 * 留空 = 回退到"该分区菜单里第一个可访问的页面"（受菜单排序影响，
 * 菜单顺序一调，落地页就跟着变，容易跳错地方）。
 * manage 显式指定为「初级产品管理 → 元数据管理」：无论菜单怎么排，
 * 点"数据管理"都进这一页。
 */
const GROUP_HOME: Record<'task' | 'manage', string> = {
  task: '',
  manage: '/primary-product/metadata-manage'
};

/** 驾驶舱路由前缀（驾驶舱不属于 task / manage 任何分区） */
const COCKPIT_PATH = '/cockpit';

/** 当前是否停在驾驶舱页 */
const isInCockpit = (): boolean => router.currentRoute.value.path.startsWith(COCKPIT_PATH);

/**
 * 打开运行驾驶舱。
 * 已在驾驶舱时不重复 push，避免 Duplicated navigation 警告 / 未捕获的 rejection。
 */
const goCockpit = () => {
  if (isInCockpit()) return;
  router.push(COCKPIT_PATH);
};

/** 切换分区：切菜单分区 + 跳到该分区菜单的第一个页面 */
const switchGroup = (group: 'task' | 'manage') => {
  // 驾驶舱不属于任何分区，进去后 activeGroup 仍停在离开时的那个分区；
  // 此时点回"同一个分区"不能早退，否则会一直卡在 /cockpit 跳不回来。
  const inCockpit = isInCockpit();

  if (appStore.activeGroup === group && !inCockpit) return;

  // 只有真正换了分区才写 store（activeGroup 用 useStorage 持久化，
  // 重复 set 会白白触发一次持久化写入）
  if (appStore.activeGroup !== group) {
    appStore.setActiveGroup(group);
  }

  // 优先用分区指定的固定落地页，未指定才回退到菜单第一项
  const target = GROUP_HOME[group] || firstPageOf(group);
  if (target && router.currentRoute.value.path !== target) {
    router.push(target);
  }
};

const toggleSideBar = () => {
  appStore.toggleSideBar(false);
};

/**
 * 门户（综合管理系统）地址。
 * 优先取 VITE_APP_PORTAL_BASE：
 *   开发环境  -> http://localhost（门户 dev server 跑在 80 端口根路径）
 *   生产环境  -> /GLXT（与门户同源部署，门户挂在 /GLXT 路径下）
 * 没配置时按运行环境给默认值，避免忘了重启 dev server 就跳错地址。
 */
const portalBase = () => {
  const configured = import.meta.env.VITE_APP_PORTAL_BASE as string | undefined;
  const base = configured || (import.meta.env.DEV ? 'http://localhost' : '/GLXT');
  return base.replace(/\/+$/, '');
};

/** 跳到门户的某个页面（跨应用，用整页跳转） */
const goPortal = (path: string) => {
  window.location.href = `${portalBase()}${path}`;
};

/** 本系统登录页地址（带应用上下文路径，例如 /ZHGL/login） */
const loginUrl = () => {
  const base = (import.meta.env.VITE_APP_CONTEXT_PATH as string) || '/';
  return `${base.replace(/\/+$/, '')}/login`;
};

const logout = async () => {
  await ElMessageBox.confirm(t('common.logoutConfirm'), t('common.tip'), {
    confirmButtonText: t('common.confirm'),
    cancelButtonText: t('common.cancel'),
    type: 'warning'
  } as ElMessageBoxOptions);
  try {
    await userStore.logout();
  } catch {
    /* 后端注销失败（网络异常/会话已失效）也要把本地登录态清干净，否则会被守卫弹回系统 */
    removeToken();
  } finally {
    proxy?.$tab.closeAllPage();
    // 退出后回到【本系统】的登录页（不再跳转门户），整页跳转顺带清掉内存状态
    window.location.href = loginUrl();
  }
};

const setLayout = () => {
  emits('setLayout');
};

const commandMap: { [key: string]: any } = {
  setLayout,
  logout
};

const handleCommand = (command: string) => {
  if (commandMap[command]) {
    commandMap[command]();
  }
};

const returnHome = () => {
  goPortal('/home');
};
</script>

<style lang="scss" scoped>
.navbar {
  height: var(--app-header-height);
  display: flex;
  align-items: center;
  //background: linear-gradient(to right, #093567, #011547);
  padding: 0 24px;
  box-sizing: border-box;
  user-select: none;
}

/* ===== 左侧平台标题 ===== */
.navbar-left {
  flex-shrink: 0;
  display: flex;
  align-items: center;
  gap: 12px;
}

.hamburger {
  cursor: pointer;
  color: rgba(255, 255, 255, 0.7);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 6px;
  border-radius: 4px;
  transition: all 0.2s ease;

  &:hover {
    background: rgba(255, 255, 255, 0.1);
    color: #fff;
  }
}

.platform-title {
  font-size: 40px;
  color: #fff;
  letter-spacing: 1px;
  font-family: var(--app-font-family-title);
}

/* ===== 中间系统切换 ===== */
.navbar-center {
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 10px;
}

.system-switch-item {
  display: flex;
  align-items: center;
  justify-content: center;
  /* 背景图原始尺寸 165 x 44，按原尺寸显示 */
  width: 165px;
  height: 44px;
  padding: 0;
  border-radius: 0;
  background-image: url('../../assets/images/顶部导航-默认背景.png');
  background-repeat: no-repeat;
  background-position: center;
  background-size: 165px 44px;
  cursor: pointer;
  transition: filter 0.2s ease;

  .system-name {
    font-size: 20px;
    font-weight: normal;
    color: #fff;
    font-family: var(--app-font-family-title);
    line-height: 1;
    transition: none;
  }

  &:hover {
    filter: brightness(1.15);
  }

  &.active {
    background-image: url('../../assets/images/顶部导航-选中背景.png');

    .system-name {
      color: #fff;
    }
  }
}

/* ===== 右侧头像 ===== */
.nav-cockpit-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  margin-right: 10px;
  border-radius: 4px;
  cursor: pointer;
  color: #515a6e;
  transition:
    background-color 0.2s,
    color 0.2s;

  &:hover {
    color: #2d68e8;
    background: #f2f6fe;
  }
}

.navbar-right {
  /* 中间的系统切换按钮停用后，用 auto 外边距把右侧区域顶到最右 */
  margin-left: auto;
  flex-shrink: 0;
  display: flex;
  align-items: center;
}

.avatar-wrapper {
  display: flex;
  align-items: center;
  cursor: pointer;
  gap: 8px;
  padding: 4px 8px;
  border-radius: 4px;
  transition: background 0.2s ease;

  &:hover {
    background: rgba(255, 255, 255, 0.1);
  }

  .user-avatar {
    width: 32px;
    height: 32px;
    border-radius: 4px;
    background-color: #5b6e80;
  }

  .username {
    font-size: 14px;
    color: #fff;
  }

  .el-icon {
    font-size: 12px;
    color: rgba(255, 255, 255, 0.6);
  }
}
</style>
