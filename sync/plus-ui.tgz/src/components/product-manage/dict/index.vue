<script setup lang="tsx">
import { useDict } from '@/composables/use-dict'

const props = defineProps<{
  type: string
  value: string
  label?: string
}>()

const dict = useDict([props.type])

const current = computed(() => dict[props.type].find(v => v.dictValue === props.value))
</script>

<template>
  <span v-if="!value">/</span>
  <el-tag v-else :type="current?.listClass! as any || 'primary'">
    {{ current?.dictLabel || label }}
  </el-tag>
</template>
