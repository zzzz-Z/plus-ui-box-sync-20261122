<script setup lang='tsx'>
import type { icons } from '@iconify/json/json/ant-design.json'

defineProps<{
  name: keyof typeof icons
}>()
</script>

<template>
  <div class="i-icon" :class="`i-ant-design:${name}`" />
</template>

<style lang='scss' scoped>
.i-icon {
  display: inline-block;
}
</style>
