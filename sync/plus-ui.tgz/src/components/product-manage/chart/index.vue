<script setup lang="ts">
import type { ChartEvents, Props } from './type'
import * as echarts from 'echarts'
import { isNumber } from 'lodash'

const { options, width, height, theme, initOption, ...props } = defineProps<Props>()
const chartRef = ref<echarts.ECharts | null>(null)
const chartDom = ref()

function normalizeSize(value?: number | string) {
  if (value === undefined || value === null) return undefined
  if (isNumber(value) || /^\d+(?:\.\d+)?$/.test(String(value).trim())) {
    return `${value}px`
  }
  return value
}

const style = computed(() => ({
  width: normalizeSize(width) ?? '100%',
  height: normalizeSize(height) ?? '100%',
}))

useResizeObserver(chartDom, () => chartRef.value?.resize())

watch(
  () => options,
  () => chartRef.value?.setOption(options),
  { deep: true },
)

onMounted(() => {
  const chart = chartRef.value = echarts.init(chartDom.value, theme, initOption)
  chart?.setOption(options)
  initEvents(chart)
})

onUnmounted(() => {
  chartRef.value?.dispose()
  chartRef.value = null
})

function initEvents(chart: echarts.ECharts) {
  Object.keys(props)
    .filter(key => key.startsWith('on'))
    .map(event => event.replace('on', ''))
    .forEach((event) => {
      const eventName = event.toLowerCase()
      const propsEvent = props[`on${event}` as keyof ChartEvents]!
      event.startsWith('Zr:')
        ? chart.getZr().on(eventName.replace('Zr:', ''), propsEvent)
        : chart?.on(eventName, propsEvent as any)
    })
}

defineExpose(forwardRef(chartRef))
</script>

<template>
  <div ref="chartDom" class="i-chart" :style="style" />
</template>

<style>
.i-chart {
  display: block;
  width: 100%;
  height: 100%;
  min-width: 0;
}
</style>
