<script setup lang='ts'>
import type { ButtonProps, MessageOptions, Placement, PopconfirmProps, UseTooltipProps } from 'element-plus'
import { isObject } from '@vueuse/core'
import { ElMessageBox } from 'element-plus'
import { mergeProps } from 'vue'

type Props = Partial<ButtonProps> & {
  tooltip?: string | Partial<UseTooltipProps>
  popConfirm?: Partial<PopconfirmProps>
  msgBox?: Partial<MessageOptions>
  onClick?: (evt?: Event, loading?: Ref<boolean>) => Promise<any> | void
}

defineOptions({
  name: 'IButton',
  inheritAttrs: false
})

const { popConfirm, msgBox, tooltip, onClick, ...props } = defineProps<Props>()
const attrs = useAttrs()
const loading = ref(false)
const tooltipRef = ref()

const buttonProps = computed(() => mergeProps(props, attrs))

const tooltipProps = computed(() =>
  isObject(tooltip)
    ? tooltip
    : { effect: 'dark', placement: 'top' as Placement, content: tooltip },
)

function click(evt?: Event) {
  tooltipRef.value?.hide?.()
  return onClick?.(evt, loading)
}

async function customClick(evt: MouseEvent) {
  // 如果配置了 msgBox，由 msgBoxConfirm 全权处理流程和 loading 状态
  if (msgBox) {
    msgBoxConfirm()
    return
  }

  // 无 msgBox 时，直接执行点击逻辑并控制 loading
  try {
    loading.value = true
    await click(evt)
  } catch (error) {
    console.error(error)
  } finally {
    loading.value = false
  }
}

function msgBoxConfirm() {
  if (!msgBox?.message) {
    console.warn('msgBox.message is required when using msgBox property')
    return
  }

  ElMessageBox.confirm(
    msgBox.message,
    {
      confirmButtonText: '确认',
      cancelButtonText: '取消',
      beforeClose: async (action, ctx, done) => {
        if (action !== 'confirm') {
          done()
          return
        }
        try {
          ctx.confirmButtonLoading = true
          await click()
        } finally {
          ctx.confirmButtonLoading = false
          done()
        }
      },
      ...msgBox as any,
    }
  ).catch(() => {})
}
</script>

<template>
  <!-- 根据 popConfirm 属性决定是否显示确认框 -->
  <el-popconfirm
    v-if="popConfirm"
    v-bind="popConfirm"
    confirm-button-text="确定"
    cancel-button-text="取消"
    @confirm="customClick"
  >
    <template #reference>
      <span class="i-button-reference" style="display: inline-flex;">
        <el-tooltip v-if="!!tooltip" v-bind="tooltipProps" ref="tooltipRef">
          <template #default>
            <el-button v-bind="buttonProps" :loading="loading" @click="customClick">
              <slot />
            </el-button>
          </template>
        </el-tooltip>
        <el-button v-else v-bind="buttonProps" :loading="loading" @click="customClick">
          <slot />
        </el-button>
      </span>
    </template>
  </el-popconfirm>

  <!-- 根据 tooltip 属性决定是否显示工具提示 -->
  <el-tooltip v-else-if="!!tooltip" v-bind="tooltipProps" ref="tooltipRef">
    <template #default>
      <el-button v-bind="buttonProps" :loading="loading" @click="customClick">
        <slot />
      </el-button>
    </template>
  </el-tooltip>

  <!-- 如果没有 popConfirm 和 tooltip 属性，则直接渲染按钮 -->
  <el-button v-else v-bind="buttonProps" :loading="loading" @click="customClick">
    <slot />
  </el-button>
</template>
