<script setup lang="ts">
import { Search } from '@element-plus/icons-vue';

/**
 * 通用选项树（带搜索、计数 badge、二次点击取消的单选树）
 *
 * 纯展示组件：items / nodes / counts 由调用方给定，组件不依赖任何 store。
 * 两条产品线（初级产品 / 产品成果）各有一个薄 wrapper 负责算 items / nodes / counts，
 * 保证本组件零业务知识、可被任一侧复用。
 * items（平铺）与 nodes（层级）二选一；nodes 提供时优先。
 */
interface TreeNode {
  key: string;
  label: string;
  count?: number;
  children?: TreeNode[];
}

const props = defineProps<{
  title?: string;
  items?: string[];
  nodes?: TreeNode[];
  counts?: Record<string, number>;
  placeholder?: string;
  emptyText?: string;
}>();

const selected = defineModel<string>({ default: '' });

const filterText = ref('');
const treeRef = ref();

const treeData = computed<TreeNode[]>(() => {
  if (props.nodes) return props.nodes;
  return (props.items ?? []).map((name) => ({
    key: name,
    label: name,
    count: props.counts?.[name] ?? 0
  }));
});

/** 递归过滤层级节点：命中自身或任一后代时保留该支 */
function filterNodes(list: TreeNode[], kw: string): TreeNode[] {
  const out: TreeNode[] = [];
  for (const node of list) {
    const kids = node.children ? filterNodes(node.children, kw) : undefined;
    if (node.label.toLowerCase().includes(kw) || (kids && kids.length)) {
      out.push({ ...node, children: kids && kids.length ? kids : node.children });
    }
  }
  return out;
}

const filteredTree = computed(() => {
  const kw = filterText.value.trim().toLowerCase();
  return kw ? filterNodes(treeData.value, kw) : treeData.value;
});

function onNodeClick(data: TreeNode) {
  selected.value = selected.value === data.key ? '' : data.key;
}
function onClear() {
  selected.value = '';
  treeRef.value?.setCurrentKey(null);
}
watch(selected, (k) => treeRef.value?.setCurrentKey(k || null));
</script>

<template>
  <div class="tree-panel">
    <!-- <div class="tree-panel__header">
      <span class="tree-panel__title">{{ props.title }}</span>
      <el-button v-if="selected" link size="small" @click="onClear"> 清空 </el-button>
    </div> -->
    <el-input v-model="filterText" :placeholder="props.placeholder ?? '搜索'" clearable :prefix-icon="Search" class="tree-panel__search" />
    <div class="tree-panel__body">
      <el-tree
        ref="treeRef"
        :data="filteredTree"
        :props="{ label: 'label', children: 'children' }"
        node-key="key"
        :default-expand-all="true"
        :expand-on-click-node="false"
        :current-node-key="selected"
        highlight-current
        @node-click="onNodeClick"
      >
        <template #default="{ data }">
          <span class="tree-node">
            <span class="tree-node__label">{{ data.label }}</span>
            <span class="tree-node__count">{{ data.count }}</span>
          </span>
        </template>
      </el-tree>
      <el-empty v-if="!filteredTree.length" :description="props.emptyText ?? '无匹配项'" :image-size="50" />
    </div>
  </div>
</template>

<style scoped lang="scss">
.tree-panel {
  display: flex;
  flex-direction: column;
  height: 100%;
  padding: 12px;
  background: var(--el-bg-color);
  border-radius: 4px;
  box-shadow: var(--el-box-shadow-light);
}
.tree-panel__header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  min-height: 24px;
  margin-bottom: 10px;
}
.tree-panel__title {
  color: var(--el-text-color-primary);
  font-size: 13px;
  font-weight: 600;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.tree-panel__search {
  margin-bottom: 8px;
}
.tree-panel__body {
  flex: 1;
  min-height: 0;
  overflow: auto;
}
.tree-node {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  padding-right: 4px;
  font-size: 13px;
}
.tree-node__count {
  min-width: 24px;
  padding: 0 6px;
  color: var(--el-text-color-secondary);
  font-size: 11px;
  line-height: 16px;
  text-align: center;
  background: var(--el-fill-color-light);
  border-radius: 8px;
}
:deep(.el-tree-node__content) {
  height: 30px;
}
:deep(.el-tree-node.is-current > .el-tree-node__content) {
  background: var(--el-color-primary-light-9);
}
:deep(.el-tree-node.is-current > .el-tree-node__content .tree-node__count) {
  color: var(--el-color-primary);
  background: var(--el-color-primary-light-8);
}
</style>
