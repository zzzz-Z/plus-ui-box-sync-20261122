<script setup lang="ts">
import { ArrowDown, ArrowUp, Setting } from '@element-plus/icons-vue';
import type { ColumnState } from './useColumnSetting';

defineProps<{
  /** 可设置列状态（响应式对象，直接双向绑定 visible/fixedLeft） */
  states: ColumnState[];
  /** 指定方向是否可移动 */
  canMove: (state: ColumnState, direction: 'up' | 'down') => boolean;
  /** 移动列 */
  move: (state: ColumnState, direction: 'up' | 'down') => void;
}>();
</script>

<template>
  <div class="table-action__setting">
    <el-popover placement="bottom-end" :width="320" trigger="click">
      <template #reference>
        <el-button :icon="Setting" plain />
      </template>
      <div class="column-setting">
        <div class="column-setting__title">字段显示与顺序</div>
        <div class="column-setting__list">
          <div v-for="state in states" :key="state.key" class="column-setting__row">
            <el-checkbox v-model="state.visible" :disabled="!state.hideable">
              {{ state.label }}
            </el-checkbox>
            <el-switch v-model="state.fixedLeft" inline-prompt active-text="冻" inactive-text="普" />
            <el-button link :icon="ArrowUp" :disabled="!canMove(state, 'up')" @click="move(state, 'up')" />
            <el-button link :icon="ArrowDown" :disabled="!canMove(state, 'down')" @click="move(state, 'down')" />
          </div>
        </div>
      </div>
    </el-popover>
  </div>
</template>

<style scoped lang="scss">
.table-action__setting {
  margin-left: auto;
}

.column-setting__title {
  margin-bottom: 8px;
  color: var(--el-text-color-primary);
  font-weight: 600;
}

.column-setting__list {
  max-height: 320px;
  overflow-y: auto;
}

.column-setting__row {
  display: flex;
  align-items: center;
  gap: 5px;
  min-height: 34px;

  :deep(.el-checkbox) {
    flex: 1;
    margin-right: 4px;
  }
}
</style>
