import { computed, ref, watch } from 'vue';

/**
 * Table 列设置（字段显示与顺序）状态与逻辑
 *
 * 内部只维护基础类型状态（key/label/visible/fixedLeft 等），不直接持有
 * TableColumn，避免 ref 深度解包 Element Plus 递归列类型触发 TS2589；
 * 原始列通过 computed 的 Record 按 key 映射回来（computed 不做深度解包）。
 *
 * UI 反馈与渲染由 ColumnSetting.vue 负责，本模块只做数据与业务操作。
 */

export interface ColumnState {
  key: string;
  label: string;
  /** 锁定列（selection/index/expand 或操作列）不参与显隐与排序 */
  locked: boolean;
  /** 是否允许隐藏（列 hideable 为 false 时复选框禁用） */
  hideable: boolean;
  visible: boolean;
  /** 是否冻结在左侧 */
  fixedLeft: boolean;
}

export interface UseColumnSettingOptions {
  /** 原始列（响应式 getter） */
  columns: () => TableColumn[];
  /** 是否启用列设置 */
  enabled: () => boolean;
}

function getColumnKey(column: TableColumn, index: number): string {
  return String(column.prop ?? column.label ?? column.type ?? `__col_${index}`);
}

function isLockedColumn(column: TableColumn): boolean {
  return Boolean(column.type) || column.label === '操作';
}

export function useColumnSetting({ columns, enabled }: UseColumnSettingOptions) {
  const columnState = ref<ColumnState[]>([]);

  /** 依据 columns 构建/同步内部列状态，按 key 保留用户已调整的显隐与冻结 */
  function sync() {
    const prevByKey: Record<string, ColumnState> = {};
    columnState.value.forEach((state) => {
      prevByKey[state.key] = state;
    });
    columnState.value = columns().map((column, index): ColumnState => {
      const key = getColumnKey(column, index);
      const locked = isLockedColumn(column);
      const before = prevByKey[key];
      return {
        key,
        label: String(column.label ?? ''),
        locked,
        hideable: column.hideable !== false,
        visible: locked ? true : (before?.visible ?? column.show?.() !== false),
        fixedLeft: before?.fixedLeft ?? (column.fixed === 'left' || column.fixed === true)
      };
    });
  }

  // 仅在列集合(按 key)变化时重建,用户排序不会触发
  watch(
    () =>
      columns()
        .map((column, index) => getColumnKey(column, index))
        .join('|'),
    sync,
    { immediate: true }
  );

  /** 可设置列(排除锁定列),用于弹窗列表与排序边界判断 */
  const settingableStates = computed(() => columnState.value.filter((state) => !state.locked));

  /** 原始列按 key 索引,供内部状态映射回列定义 */
  const columnByKey = computed(() => {
    const map: Record<string, TableColumn> = {};
    columns().forEach((column, index) => {
      map[getColumnKey(column, index)] = column;
    });
    return map;
  });

  /** 实际渲染的列:按内部顺序与显隐过滤,并应用左侧冻结 */
  const renderedColumns = computed<TableColumn[]>(() => {
    if (!enabled()) return columns();
    return columnState.value
      .filter((state) => state.visible)
      .map((state) => {
        const column = columnByKey.value[state.key];
        return state.locked ? column : { ...column, fixed: state.fixedLeft ? 'left' : undefined };
      });
  });

  /** 在相邻的可设置列之间移动(跳过锁定列) */
  function moveColumn(state: ColumnState, direction: 'up' | 'down') {
    const list = columnState.value;
    const from = list.indexOf(state);
    if (from < 0) return;
    const step = direction === 'up' ? -1 : 1;
    let to = from + step;
    while (to >= 0 && to < list.length && list[to].locked) to += step;
    if (to < 0 || to >= list.length) return;
    const [moved] = list.splice(from, 1);
    list.splice(to, 0, moved);
  }

  /** 指定方向是否存在可交换的可设置列 */
  function canMoveColumn(state: ColumnState, direction: 'up' | 'down'): boolean {
    const list = columnState.value;
    const step = direction === 'up' ? -1 : 1;
    let i = list.indexOf(state) + step;
    while (i >= 0 && i < list.length) {
      if (!list[i].locked) return true;
      i += step;
    }
    return false;
  }

  return { columnState, settingableStates, renderedColumns, moveColumn, canMoveColumn };
}
