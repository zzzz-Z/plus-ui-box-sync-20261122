import type { Ref } from 'vue';
import { useResizeObserver } from '@vueuse/core';
import { ref, unref } from 'vue';

/**
 * Table 自适应高度计算
 *
 * 依据容器与各功能区（表头/搜索/操作/分页）的实际高度，动态推算表格主体高度；
 * 未指定固定 height 且未开启 autoHeight 时，监听尺寸变化自动重算。
 */

/** 高度计算额外偏移量 */
const HEIGHT_OFFSET = 32;

export interface TableHeightRefs {
  root: Ref<any>;
  header: Ref<any>;
  search: Ref<any>;
  action: Ref<any>;
  pagination: Ref<any>;
}

export interface UseTableHeightOptions {
  height?: string | number;
  autoHeight?: boolean;
}

export function useTableHeight(refs: TableHeightRefs, options: UseTableHeightOptions) {
  const customHeight = ref<string | number | undefined>(options.height);

  /** 获取 DOM 元素高度 */
  function getRefHeight(domRef: Ref<any>, extraHeight = 0): number {
    const dom = unref(domRef);
    const h = dom?.offsetHeight ?? dom?.$el?.offsetHeight ?? 0;
    return h ? h + extraHeight : h;
  }

  /** 计算表格高度(自适应) */
  function computedHeight(): void {
    const rootEl = unref(refs.root);
    if (!rootEl) return;

    const { paddingTop, paddingBottom } = getComputedStyle(rootEl);
    const rootPadding = [paddingTop, paddingBottom].map((s) => Number(s.replace('px', ''))).reduce((prev, curr) => prev + curr, 0);

    customHeight.value =
      getRefHeight(refs.root) -
      getRefHeight(refs.header) -
      getRefHeight(refs.search) -
      getRefHeight(refs.action) -
      getRefHeight(refs.pagination) -
      rootPadding -
      HEIGHT_OFFSET;
  }

  /** 未指定固定高度时监听尺寸变化自动计算 */
  function observe(): void {
    if (!options.height && !options.autoHeight) useResizeObserver([refs.root, refs.header, refs.search, refs.action], computedHeight);
  }

  return { customHeight, computedHeight, observe };
}
