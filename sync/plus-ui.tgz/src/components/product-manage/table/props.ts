import type { TableProps } from 'element-plus';

export interface ITableProps<T = any> extends Omit<TableProps<any>, 'data'> {
  /** 列是否展示序号，默认为true */
  index?: boolean;
  /** 是否展示分页  */
  pagination?: boolean;
  columns?: TableColumn<T>[];
  /** 请求函数 */
  request?: (params: any) => Promise<any>;
  data?: any[];
  /**
   * 🔍 搜索参数
   */
  queryParams?: Params;
  /** 是否立即调用请求函数 */
  immediate?: boolean;
  autoHeight?: boolean;
  /** 是否显示「字段显示与顺序」列设置，渲染在操作区右侧 @default false */
  columnSetting?: boolean;
  requestCfg?: {
    /** 请求函数返回字段映射 @default size */
    size?: string;
    /** 请求函数返回字段映射 @default page */
    page?: string;
    /** 请求函数返回字段映射 @default list */
    list?: string;
    /** 请求函数返回字段映射 @default total */
    total?: string;
  };
}
