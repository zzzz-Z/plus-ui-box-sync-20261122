<script lang="tsx" setup>
import type { ConcreteComponent, Slot } from 'vue';
import type { PageHeaderInstance, TableEmits, TableInstance } from 'element-plus';
import { ElCol, ElMessage, ElTable, ElTableColumn } from 'element-plus';
import { cloneDeep, isObject } from 'lodash';
import { cloneVNode, Comment, createVNode, Fragment } from 'vue';
import ColumnSetting from './columnSetting.vue';
import type { ITableProps } from './props';
import { useColumnSetting } from './useColumnSetting';
import { useTableHeight } from './useTableHeight';
import i18n from '@/lang/index';
import { pt } from '@/lang/modules/pm-i18n';

defineOptions({ name: 'ITable', inheritAttrs: false });
defineEmits<TableEmits>();

const t = (key: string) => i18n.global.t(key);

const {
  request,
  immediate = true,
  pagination = true,
  height,
  queryParams = {},
  columns = [],
  data = [],
  rowKey = 'id',
  fit = true,
  showHeader = true,
  requestCfg,
  style,
  autoHeight,
  columnSetting = false,
  ...tableProps
} = defineProps<ITableProps>();

const slots = defineSlots<Record<'action' | 'search' | 'append' | 'default' | 'header', Slot>>();

const listener = useListener();
// 响应式布局配置
const FLEX_LAYOUT = { xl: 4, lg: 6, md: 8, sm: 12, xs: 24 } as const;
// 默认分页大小选项
const PAGE_SIZES = [10, 20, 50, 100];
// 日期时间正则匹配
const DATE_TIME_REGEX = /日期|时间|Date|Time/;
// 操作列单元格标记类：① 命中它强制不换行；② 用它取 DOM 实测宽度
const ACTION_CELL_CLASS = 'i-table__action-cell';

// 深拷贝查询参数用于重置
const rawQueryParams = reactive(cloneDeep(queryParams));

// 请求配置合并默认值
const _requestCfg = computed(() => ({
  size: 'pageSize',
  page: 'page',
  total: 'total',
  list: 'data',
  ...requestCfg
}));

// 分页状态
const _pagination = reactive({
  total: 0,
  page: 1,
  size: 10
});

// 数据源
const dataSource = ref<any[]>(data);
// 加载状态
const loading = ref(false);
// 表格实例引用
const table = ref<TableInstance>();
// DOM 引用
const root = ref<HTMLDivElement>();
const header = ref<HTMLDivElement>();
const search = ref<HTMLDivElement>();
const action = ref<HTMLDivElement>();
const paginationRef = ref<PageHeaderInstance>();
// 自适应高度计算抽离到 useTableHeight
const { customHeight, observe: observeHeight } = useTableHeight({ root, header, search, action, pagination: paginationRef }, { height, autoHeight });
// 表格内部 store
const store = ref<Params>({});

// 选中行数据(双向绑定)
const selection = computed<Params[]>({
  get: () => store.value.states?.selection ?? [],
  set: (v) => {
    if (store.value.states) {
      store.value.states.selection = v;
    }
  }
});

// 列设置（字段显示与顺序）：状态与逻辑抽离到 useColumnSetting
const { settingableStates, renderedColumns, moveColumn, canMoveColumn } = useColumnSetting({
  columns: () => columns,
  enabled: () => columnSetting
});

/**
 * 操作列实测宽度（px），0 表示本轮还没测过。
 *
 * WHY 用 ref 而不是回写 columns：columns 是父组件传入的普通数组，改它的成员不会触发重渲染
 * （只在「恰好还有别的响应式变化」时才生效，宽度落不落地全看运气）。ref 参与渲染即建立依赖，
 * 测完立刻生效；getData 时清零，数据换批后按新按钮集重测。
 */
const actionColumnWidth = ref(0);

// 监听外部数据变化
watch(
  () => data,
  (newValue) => {
    dataSource.value = newValue;
  },
  { deep: true }
);

// 组件挂载时初始化
onMounted(() => {
  // 立即加载数据
  if (immediate) {
    getData();
  }

  // 如果没有指定固定高度,则监听尺寸变化自动计算
  observeHeight();
});

/**
 * 获取表格数据
 */
async function getData(_params?: Params): Promise<void> {
  if (!request) {
    return;
  }

  try {
    loading.value = true;
    const params = {
      ...queryParams,
      ..._params,
      [_requestCfg.value.size!]: _pagination.size,
      [_requestCfg.value.page!]: _pagination.page
    };

    const res = await request(params);

    if (!res) {
      return;
    }

    // 根据响应码判断请求是否成功
    if (res.code === 0 || !!res.success) {
      // 数据换批后按钮组合可能变化（禁用/隐藏），清掉旧宽度让下一轮渲染按新内容重测；
      // 否则上一批里最宽的那行会把列宽永久撑在一个过大的值上
      actionColumnWidth.value = 0;
      if (pagination) {
        dataSource.value = res.data.items;
        _pagination.total = res.data.total ?? 0;
      } else {
        dataSource.value = res.data?.items ?? [];
      }
    } else {
      dataSource.value = [];
      _pagination.total = 0;
      ElMessage.error(res.message ?? t('common.requestFailed'));
    }
  } catch (error) {
    console.error('Failed to fetch data:', error);
    ElMessage.error(t('common.fetchFailed'));
    dataSource.value = [];
    _pagination.total = 0;
  } finally {
    loading.value = false;
  }
}

/**
 * 重置查询条件
 */

function reset(): void {
  _pagination.page = 1;
  // 恢复初始查询参数(通过 emit 通知父组件)
  const resetParams: Params = {};
  Object.keys(queryParams).forEach((key) => {
    const rawValue = rawQueryParams[key];
    resetParams[key] = isObject(rawValue) ? cloneDeep(rawValue) : rawValue;
  });

  // 更新本地 queryParams (注意:这违反了 props 不可变原则,建议父组件使用 v-model:queryParams)
  // eslint-disable-next-line vue/no-mutating-props
  Object.assign(queryParams, resetParams);

  if (immediate) {
    getData();
  } else {
    dataSource.value = [];
    _pagination.total = 0;
  }
}

/**
 * 执行查询
 */
function query(): void {
  _pagination.page = 1;
  getData();
}

/**
 * 页码改变
 */
function change(page: number): void {
  _pagination.page = page;
  getData();
}

/**
 * 每页条数改变
 */
function sizeChange(size: number): void {
  _pagination.size = size;
  getData();
}

/**
 * 渲染表格列(递归支持嵌套列)
 */
function RenderColumns(props: { columns: any[] }): any {
  const tableColumns = reactive([...props.columns]);

  return tableColumns
    ?.filter(({ show }) => show?.() !== false)
    .map(({ columns, width, className, ...rest }) => {
      // 根据列标签自动调整日期时间列宽度
      const labelText = String(rest.label ?? '');
      let autoWidth = DATE_TIME_REGEX.test(labelText) ? 190 : width;
      if (rest.label) rest.label = pt(labelText);
      // 操作列：调用方没给 width 时用实测宽度（见 computeActionColumnWidth）
      if (rest.action === true && !width) {
        autoWidth = actionColumnWidth.value || undefined;
      }
      return (
        <ElTableColumn
          showOverflowTooltip={true}
          width={autoWidth}
          formatter={createColumnFormatter(rest)}
          {...rest}
          className={[className, rest.action === true ? ACTION_CELL_CLASS : ''].filter(Boolean).join(' ') || undefined}
          v-slots={{
            default: columns ? () => RenderColumns({ columns }) : rest.renderDefault,
            header: rest.renderHeader
          }}
        />
      );
    });
}

/** 创建列格式化函数 */
function createColumnFormatter(rest: TableColumn) {
  return (row: any, column: any, value: any, index: number) => {
    const node = rest?.render?.({ row, column, value, index });

    // 操作列未设宽度时根据按钮实际数量动态计算宽度
    if (rest.action === true && !rest.width) {
      scheduleActionMeasure();
    }

    return rest.dictType ? <Dict type={rest.dictType} value={value} /> : node || value || '/';
  };
}

/** 已有待执行的操作列测量则跳过，避免每行每列都排一次 nextTick */
let actionMeasurePending = false;

function scheduleActionMeasure() {
  if (actionMeasurePending) return;
  actionMeasurePending = true;
  nextTick(() => {
    actionMeasurePending = false;
    computeActionColumnWidth();
  });
}

/**
 * 按操作列单元格的真实内容宽度计算列宽。
 *
 * WHY 必须量 DOM 而不是数按钮个数：按钮宽度受 size / icon / 文案 / 自定义 class 影响，
 * 只有布局完成后才知道；列宽差 2px 时最后一个按钮就会折到第二行，整行被撑高。
 *
 * WHY 用 max-content 而不是累加子元素宽度：
 *  ① 累加只认「直接子元素是按钮」的写法，内容被 `<div class="row-actions">` 这类容器包一层就量错；
 *  ② clientWidth 是取整值，18.4px 会算成 18，6 个累加就少 2.4px —— 正是折行的直接原因。
 * 把 .cell 临时设成 max-content 让浏览器自己算「内容不换行需要多宽」，一次取整、无累加误差。
 * .cell 是 box-sizing: border-box，测出的宽度已含左右 padding，正好就是列宽。
 *
 * 只量 tbody 的单元格：表头 th 也带同一个 className，但里面只有「操作」二字没有按钮，
 * 先命中 th 会让测量永远拿不到内容。（表头宽随列宽走，一并被约束。）
 */
function computeActionColumnWidth() {
  const cells = Array.from(root.value?.querySelectorAll<HTMLElement>(`.el-table__body td.${ACTION_CELL_CLASS} .cell`) ?? []);
  // 过滤掉不可见容器（抽屉 / 未激活 tab）里的单元格：那里 offsetWidth 恒为 0，测出来是 0
  const measurable = cells.filter((cell) => cell.offsetWidth > 0 || hasVisibleContent(cell));
  if (!measurable.length) return;

  // 先统一改成 max-content，再统一读宽度：避免「改一行读一行」触发多次同步 reflow
  const prevWidths = measurable.map((cell) => cell.style.width);
  measurable.forEach((cell) => (cell.style.width = 'max-content'));
  const widths = measurable.map((cell) => Math.ceil(cell.getBoundingClientRect().width));
  measurable.forEach((cell, i) => (cell.style.width = prevWidths[i]));

  // 每行的按钮组合可能不同（按状态禁用/隐藏），取最宽的一行才能保证都不折行；
  // +1px 吸收 subpixel 舍入，避免恰好差一像素又折行
  const maxWidth = Math.max(...widths) + 1;

  // 只增不减：同一批数据里让最宽的一行说话，已够宽就不再缩小，避免来回抖动
  if (maxWidth > actionColumnWidth.value) {
    actionColumnWidth.value = maxWidth;
  }
}

/** 单元格里是否有可测量的内容（排除不可见容器里 offsetWidth 全为 0 的假阳性） */
function hasVisibleContent(cell: HTMLElement): boolean {
  return Array.from(cell.children).some((el) => (el as HTMLElement).offsetWidth > 0);
}

/**
 * 搜索框回车事件
 */
function onKeyup(e: KeyboardEvent): void {
  if (e.key === 'Enter') {
    query();
  }
}

function RenderSearch() {
  return slots
    .search?.()
    .filter((node) => node.type !== Comment)
    .map((node) => {
      const componentName = (node.type as ConcreteComponent).name?.toLocaleLowerCase();
      const prefix = componentName ? (componentName?.includes('input') ? t('common.placeholderInput') : t('common.placeholderSelect')) : '';
      return (
        <ElCol class="search-item" {...FLEX_LAYOUT} {...node.props?.col}>
          <span class="text-14px mr-10px">{pt(String(node.props?.label ?? ''))}</span>
          {createVNode(node, {
            clearable: node.props?.clearable ?? true,
            filterable: node.props?.filterable ?? true,
            placeholder: node.props?.placeholder || `${prefix}${pt(String(node.props?.label ?? ''))}`,
            onKeyup,
            class: 'flex-1'
          })}
        </ElCol>
      );
    });
}
/**
 * 渲染操作按钮区域
 */
function RenderAction() {
  const actionSlots = slots.action?.() ?? [];
  return actionSlots.filter((node) => node.type !== Comment && node.type !== Fragment).map((node) => cloneVNode(node, { plain: true }));
}

function RenderTable() {
  return (
    <ElTable
      ref={table}
      fit={fit}
      showHeader={showHeader}
      v-loading={loading.value}
      row-key={rowKey}
      height={customHeight.value}
      data={dataSource.value}
      show-overflow-tooltip={true}
      {...tableProps}
      {...listener}
      onVnodeMounted={(node: any) => (store.value = node.component!.store)}
    >
      {{
        header: slots.header,
        append: slots.append,
        default: () => [slots.default?.(), <RenderColumns columns={renderedColumns.value} />],
        empty: () => <el-empty />
      }}
    </ElTable>
  );
}

// 暴露方法给父组件
defineExpose(
  forwardRef(table, {
    getData,
    reset,
    query,
    rawQueryParams,
    dataSource,
    selection,
    store,
    pagination: _pagination
  })
);
</script>

<template>
  <div ref="root" :style="style" class="i-table">
    <!-- 表头插槽 -->
    <div v-if="slots.header" ref="header" class="table-header">
      <slot name="header" />
    </div>

    <!-- 搜索区域 -->
    <el-row v-if="slots.search?.()" ref="search" :gutter="20" class="table-search">
      <RenderSearch />
      <ElCol v-bind="FLEX_LAYOUT" class="pb-10px">
        <el-button type="primary" plain @click="reset">{{ t('common.reset') }}</el-button>
        <el-button type="primary" @click="query">{{ t('common.query') }}</el-button>
      </ElCol>
    </el-row>

    <!-- 操作区域和表格主体 -->
    <el-card>
      <template v-if="slots.action?.() || columnSetting" #header>
        <div ref="action" class="table-action">
          <RenderAction />
          <ColumnSetting v-if="columnSetting" :states="settingableStates" :can-move="canMoveColumn" :move="moveColumn" />
        </div>
      </template>

      <!-- 表格 -->
      <RenderTable />

      <!-- 分页组件 -->
      <el-pagination
        v-if="pagination"
        ref="paginationRef"
        size="small"
        background
        class="table-pagination"
        :teleported="false"
        layout="total, prev, pager, next, sizes"
        :total="_pagination.total"
        :page-sizes="PAGE_SIZES"
        :current-page="_pagination.page"
        :page-size="_pagination.size"
        @current-change="change"
        @size-change="sizeChange"
      />
    </el-card>
  </div>
</template>

<style lang="scss">
.i-table {
  display: flex;
  flex-direction: column;
  height: 100%;
  width: 100%;

  .el-card {
    flex: 1 1 auto;
    min-height: 0;
    border: none;
  }

  .el-card__header {
    padding: 0;
  }
}

.table-search {
  /* 与若依原生查询条一致的浅蓝斜纹底图（queryBg 只扫 .el-form，本组件用 el-row 渲染，故此处直接挂图） */
  background: url('../../../assets/images/one_input.png') no-repeat center / 100% 100%;
  box-shadow: var(--el-box-shadow);
  align-items: center;
  padding: 10px 12px 0;
  margin: 0 0 6px !important;
  border-radius: 4px;
  box-sizing: content-box;
}

.table-action {
  display: flex;
  align-items: center;
  padding: 4px 0 6px;
  border-top-right-radius: 4px;
  border-top-left-radius: 4px;
}

.table-pagination {
  padding: 2px 10px;
  border-bottom-left-radius: 4px;
  border-bottom-right-radius: 4px;
  display: flex;
  justify-content: end;
  margin-top: 6px;
}

.search-item {
  display: flex !important;
  white-space: nowrap;
  align-items: center;
  margin-bottom: 10px;
  > span {
    box-sizing: border-box;
    color: var(--el-text-color-regular);
    font-weight: 700;
  }
}

/* 操作列强制单行：
   - 列宽由 computeActionColumnWidth 按真实按钮宽度回写；
   - 这里再兜一层 nowrap —— EP 对 showOverflowTooltip=false 的列给 .cell 的是
     `white-space: normal`，一旦列宽因字体 / 缩放差 1~2px，最后一个按钮就折到第二行、
     整行被撑高。nowrap 后同样的偏差只会溢出，不会再改行高。 */
.i-table .el-table__cell.i-table__action-cell > .cell {
  white-space: nowrap;
}

/* 卡片内外边距收紧：
   - header 区（.el-card__header）原本 padding 14/7 + action 42 = 63px；
   - body 区（.el-card__body）原本底部 padding 20px，数据少时底部留大片空白。
   收紧后这两处红框消失，同时保留足够的按钮呼吸空间。 */
.i-table .el-card__header {
  padding: 4px 12px !important;
  min-height: 0;
}
.i-table .el-card__body {
  padding: 8px 12px 0 !important;
}
</style>
