import type { Map as MapLibreMap } from 'maplibre-gl';

/**
 * 地图相机状态持久化
 *
 * 参考 maplibre-gl-extend 的 map state 思路：只记住「用户可感知的视图」——
 * 中心点 / 缩放 / 朝向 / 俯仰，恢复时按恢复值初始化，避免用户每次回到固定视角。
 *
 * 保存节流：moveend / rotateend 已在交互结束时触发，再做一次短延时合并，
 * 避免连续拖拽产生的大量写入命中 localStorage 配额。
 */

export interface MapCameraState {
  center: [number, number];
  zoom: number;
  bearing: number;
  pitch: number;
}

// v2：默认视角由倾斜 3D 改为正视俯视，旧版本缓存里的 pitch/bearing 会让新默认值失效，故升版本一次性作废旧缓存。
const STORAGE_PREFIX = 'geo-map-state:v2:';
const SAVE_DELAY = 200;

export function useMapState(getKey: () => string | undefined) {
  let timer: ReturnType<typeof setTimeout> | null = null;

  function storageKey(): string | null {
    const key = getKey();
    return key ? STORAGE_PREFIX + key : null;
  }

  /** 读取持久化相机状态；未配置 key 或解析失败时返回 null（调用方用默认值兜底） */
  function restore(): MapCameraState | null {
    const key = storageKey();
    if (!key) return null;
    try {
      const raw = localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as MapCameraState) : null;
    } catch {
      return null;
    }
  }

  /** 立即保存当前相机；未配置 key 时为空操作 */
  function saveNow(map: MapLibreMap | undefined) {
    const key = storageKey();
    if (!key || !map) return;
    try {
      const c = map.getCenter();
      const state: MapCameraState = {
        center: [c.lng, c.lat],
        zoom: map.getZoom(),
        bearing: map.getBearing(),
        pitch: map.getPitch()
      };
      localStorage.setItem(key, JSON.stringify(state));
    } catch {
      /* 存储配额或隐私模式失败时静默：地图可用性优先 */
    }
  }

  /** 节流保存；连续交互时只落一次最终状态 */
  function save(map: MapLibreMap | undefined) {
    if (!storageKey() || !map) return;
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => {
      timer = null;
      saveNow(map);
    }, SAVE_DELAY);
  }

  /** 清空持久化（外部重置按钮可用） */
  function clear() {
    const key = storageKey();
    if (!key) return;
    try {
      localStorage.removeItem(key);
    } catch {
      /* 忽略 */
    }
  }

  return { restore, save, saveNow, clear };
}
