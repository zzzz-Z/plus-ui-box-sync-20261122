import type { StyleSpecification } from 'maplibre-gl';
import chinaProvinces from '@/assets/maps/china-provinces.json';

import Liberty from '@/assets/maps/liberty.json';
import Positron from '@/assets/maps/positron.json';

/**
 * 离线底图：完全自包含的 maplibre style。
 *
 * WHY 离线：所有在线底图（OpenFreeMap / OSM）都依赖公网瓦片服务，
 * 内网 / 无网络环境下 setStyle 会拿不到瓦片，地图只剩空白背景。
 * 这里改用「本地打包的 GeoJSON 矢量源 + 面填充 / 描边 / 中文标注」，
 * 不引用任何外部 sprite / glyphs / tiles URL，零网络依赖即可渲染地理底图。
 *
 * 中文标注：依赖地图构造时的 `localIdeographFontFamily`（见 geo-map/index.vue 与 cockpit.vue），
 * 由浏览器本地字体渲染汉字，无需下载字形 PBF。
 */

/** 本地打包的中国省级边界（DataV GeoAtlas，省/直辖市/自治区/特别行政区） */
export const CHINA_PROVINCES_GEOJSON = chinaProvinces as any;
export const LIBERTY_STYLE = Liberty as StyleSpecification;
export const POSITRON_STYLE = Positron as StyleSpecification;

/** 构造一份「全新」的离线中国底图 style（每次调用返回独立对象，避免 setStyle 复用被引擎改写） */
export function buildOfflineChinaStyle(): StyleSpecification {
  return {
    version: 8,
    // 不设置 sprite / glyphs：离线环境无字形服务；中文经 localIdeographFontFamily 本地渲染
    sources: {
      'offline-china': {
        type: 'geojson',
        data: CHINA_PROVINCES_GEOJSON
      }
    },
    layers: [
      // 海洋 / 底图背景
      {
        id: 'background',
        type: 'background',
        paint: { 'background-color': '#dceaf5' }
      },
      // 陆地（省级面）浅色填充
      {
        id: 'china-fill',
        type: 'fill',
        source: 'offline-china',
        paint: {
          'fill-color': '#f5f3ec',
          'fill-opacity': 0.96
        }
      },
      // 省级边界描边
      {
        id: 'china-border',
        type: 'line',
        source: 'offline-china',
        paint: {
          'line-color': '#aab6c2',
          'line-width': 0.8
        }
      },
      // 省级名称标注（中文，靠 localIdeographFontFamily 本地渲染）
      {
        id: 'china-label',
        type: 'symbol',
        source: 'offline-china',
        layout: {
          'text-field': ['get', 'name'],
          'text-font': ['sans-serif'],
          'text-size': 11,
          'text-allow-overlap': false,
          'text-max-angle': 25
        },
        paint: {
          'text-color': '#44515f',
          'text-halo-color': '#ffffff',
          'text-halo-width': 1.2
        }
      }
    ]
  };
}
