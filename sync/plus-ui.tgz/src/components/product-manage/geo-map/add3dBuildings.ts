import type { Map } from 'maplibre-gl';

/**
 * 3D 白膜建筑（严格按 OpenFreeMap 官方示例）
 *
 */

const BUILDING_LAYER_ID = '3d-buildings';
const BUILDING_SOURCE_ID = 'openfreemap';
const OPENFREEMAP_PLANET = 'https://tiles.openfreemap.org/planet';

export function applyExtrusion(map: Map, enabled: boolean) {
  /* pitch-init: easeTo removed */
  // 默认视角为正视俯视（pitch 0）；如需立体感，用户可在地图上手动旋转/俯仰，或通过 NavigationControl 调整。
  // 此处不做 easeTo（会被后续 fitBounds 打断）。
  if (enabled) add3dBuildings(map);
  else remove3dBuildings(map);
}

function add3dBuildings(map: Map) {
  if (map.getLayer(BUILDING_LAYER_ID)) return;

  // 1. 独立声明 source（官网写法，不复用样式自带的）
  if (!map.getSource(BUILDING_SOURCE_ID)) {
    map.addSource(BUILDING_SOURCE_ID, {
      url: OPENFREEMAP_PLANET,
      type: 'vector'
    } as any);
  }

  // 2. 找第一个带文字的 symbol 图层，把 3D 建筑插到它下面
  const layers = map.getStyle().layers;
  let labelLayerId: string | undefined;
  for (let i = 0; i < layers.length; i++) {
    const layer = layers[i] as any;
    if (layer.type === 'symbol' && layer.layout?.['text-field']) {
      labelLayerId = layer.id;
      break;
    }
  }

  // 3. addLayer（paint 表达式完全按官网，不改字段、不做 zoom 兜底）
  map.addLayer(
    {
      'id': BUILDING_LAYER_ID,
      'source': BUILDING_SOURCE_ID,
      'source-layer': 'building',
      'type': 'fill-extrusion',
      'minzoom': 8,
      'filter': ['!=', ['get', 'hide_3d'], true],
      'paint': {
        'fill-extrusion-color': ['interpolate', ['linear'], ['get', 'render_height'], 0, 'lightgray', 200, 'royalblue', 400, 'lightblue'],
        'fill-extrusion-height': ['interpolate', ['linear'], ['zoom'], 13, 0, 14, ['get', 'render_height']],
        'fill-extrusion-base': ['case', ['>=', ['get', 'zoom'], 16], ['get', 'render_min_height'], 0]
      }
    } as any,
    labelLayerId
  );
}

function remove3dBuildings(map: Map) {
  if (map.getLayer(BUILDING_LAYER_ID)) map.removeLayer(BUILDING_LAYER_ID);
}
