/**
 * 地图「选中」视觉规范（唯一真源）
 *
 * 为什么需要集中定义：选中描边此前在两处图层模块里各写死一份 `#f04444`，而类别配色表里
 * 「交通」正好是 `#FF6B6B`（红色系）—— 选中一条交通类记录时，红框与红色填充几乎同色，
 * 用户看不出到底是「选中了」还是「本来就是这个颜色」。故统一：
 *
 *   1. **色相**取系统主色蓝 `#1677ff`（用户选定的「绿或蓝」中的蓝），
 *      语义与按钮/链接的选中蓝一致，区别于任何类别填充色；
 *   2. **不靠色相单独区分**——再补一层白色 halo 描边垫在彩色线下面。
 *      类别配色表有 4 套方案（标准/暖/冷/地质），冷色方案本身就有多个蓝，
 *      只换颜色仍会撞；白色描边在任何底色上都能把选中项「抠」出来。
 *   3. 选中线走**实线**，未选中维持细线：实线本身也是「被选中」的形状信号。
 */
export interface SelectionStyle {
  /** 选中主色（描边 / 点 / 行高亮框） */
  color: string;
  /** 垫在主色下面的白色描边色 */
  haloColor: string;
  /** 选中区域的填充不透明度（只做淡染，不能糊住底图与相邻图斑） */
  fillOpacity: number;
  /** 选中描边线宽（px） */
  lineWidth: number;
  /** halo 描边线宽（px），约为主色的 2 倍 */
  haloWidth: number;
  /** halo 不透明度 */
  haloOpacity: number;
  /** 点要素半径（px） */
  circleRadius: number;
  /** 点要素描边宽（px） */
  circleStrokeWidth: number;
}

export const MAP_SELECTION: SelectionStyle = {
  color: '#1677ff',
  haloColor: '#ffffff',
  fillOpacity: 0.14,
  lineWidth: 2.5,
  haloWidth: 6,
  haloOpacity: 0.9,
  circleRadius: 5.5,
  circleStrokeWidth: 2
};

/** 未选中描边（与选中同色系、低对比，保证图层本身仍可读） */
export const MAP_UNSELECTED_LINE = {
  color: '#526174',
  width: 1.5,
  opacity: 0.8
};
