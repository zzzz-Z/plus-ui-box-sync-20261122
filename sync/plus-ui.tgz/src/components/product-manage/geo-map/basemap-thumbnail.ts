import type { BasemapOption } from './use-basemaps';

/**
 * 底图缩略图（离线 SVG，零网络 / 零鉴权依赖）。
 *
 * WHY 不用真实瓦片截图：
 * - 在线瓦片（OpenFreeMap / OSM / 业务网关）需要网络 + token，下拉菜单里逐个请求既慢又会在
 *   断网 / 无权限时整片报错；
 * - 离线底图（中国省级边界 / 空白）根本没有可截的瓦片。
 * 这里按底图「语义类别」画一张示意性 SVG（海洋 / 陆地 / 路网 / 中国轮廓），
 * 既能一眼区分「标准 / 浅色 / 离线中国 / 空白 / 在线」，又不引入任何外部依赖。
 *
 * 缩略图只作视觉区分，不承担地理精度；菜单项仍配文字名，信息不丢失。
 */

const W = 44;
const H = 30;

/** 包成 data URL：encodeURIComponent 编码 SVG，直接喂给 <img src> */
function toDataUrl(inner: string, bg: string): string {
  const svg =
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">` +
    `<rect width="${W}" height="${H}" fill="${bg}"/>` +
    inner +
    `</svg>`;
  return 'data:image/svg+xml,' + encodeURIComponent(svg);
}

/** 通用「彩色在线地图」示意：蓝海 + 绿地 + 白色路网 + 城市红点 */
function colorfulMap(): string {
  const inner = [
    '<path d="M-2 20 Q10 12 20 17 T46 14 L46 32 L-2 32 Z" fill="#dfeeb8" stroke="#bcd08a" stroke-width="0.6"/>',
    '<path d="M6 6 L15 10 L24 7 L33 12" fill="none" stroke="#ffffff" stroke-width="0.8"/>',
    '<path d="M2 15 L12 18 L20 15" fill="none" stroke="#ffffff" stroke-width="0.6"/>',
    '<circle cx="22" cy="11" r="1.3" fill="#ff6b6b"/>',
    '<circle cx="11" cy="13" r="0.9" fill="#ff6b6b"/>'
  ].join('');
  return toDataUrl(inner, '#aadaff');
}

/** 浅色 Positron 示意：浅灰底 + 极淡陆地 + 细白路网 */
function lightMap(): string {
  const inner = [
    '<path d="M-2 21 Q12 14 22 18 T46 15 L46 32 L-2 32 Z" fill="#f3f3f1" stroke="#e3e3e0" stroke-width="0.5"/>',
    '<path d="M6 7 L16 11 L26 8 L34 13" fill="none" stroke="#ffffff" stroke-width="0.8"/>',
    '<circle cx="20" cy="12" r="1" fill="#c9c9c9"/>'
  ].join('');
  return toDataUrl(inner, '#e8eaed');
}

/** 离线·中国示意：蓝海 + 中国轮廓（米色填充 / 灰描边） */
function chinaMap(): string {
  // 简化中国轮廓，仅作示意，不承担地理精度
  const shape = 'M7 8 L13 6 L21 7 L29 6 L35 9 L34 15 L30 19 L24 22 L18 21 L12 23 L8 19 L5 14 Z';
  const inner = [
    `<path d="${shape}" fill="#f5f3ec" stroke="#aab6c2" stroke-width="0.7"/>`,
    '<circle cx="22" cy="13" r="1" fill="#c7a36a"/>'
  ].join('');
  return toDataUrl(inner, '#dceaf5');
}

/** 空白底图示意：纯底色，无内容 */
function blankMap(): string {
  return toDataUrl('', '#f5f7fa');
}

/**
 * 按底图 id 推断语义类别，返回对应的缩略图 data URL。
 * 后端动态注入的在线底图（xyz/wms/wmts）id 不可预知，统一回落到「彩色在线地图」示意。
 */
export function basemapThumbnail(option: BasemapOption): string {
  const id = option.id.toLowerCase();
  if (id.includes('offline-china')) return chinaMap();
  if (id.includes('positron')) return lightMap();
  if (id.includes('blank')) return blankMap();
  if (id.includes('liberty') || id.includes('osm')) return colorfulMap();
  // 其余（含业务侧在线底图）一律按「在线彩色地图」示意
  return colorfulMap();
}
