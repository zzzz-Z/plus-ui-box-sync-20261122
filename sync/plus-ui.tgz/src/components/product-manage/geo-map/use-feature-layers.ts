import type { LngLatLike } from 'maplibre-gl';
import * as maplibregl from 'maplibre-gl';
import type { Ref, VNode } from 'vue';
import { watch } from 'vue';
import type { useMapResource } from './use-map-resource';
import { MAP_SELECTION, MAP_UNSELECTED_LINE } from './selection-style';

/**
 * GeoMap 业务图层管理
 *
 * 把 features / palette / 高亮 / 进度 / label / cluster 相关的图层创建、状态同步、
 * 内部 watch 全部内聚到此处，让 geo-map/index.vue 只负责地图本身。
 *
 * 使用：
 *   const layers = useFeatureLayers(utils, { features, palette, ... })
 *   地图 load 或 style.load 后：layers.attach()
 *   切换底图前：layers.detach()
 */

export interface FeatureLayerOptions {
  // 数据
  features: Ref<any[]>;
  colorKey: Ref<string>;
  palette: Ref<Record<string, string>>;
  selectedIds: Ref<number[]>;
  hiddenIds: Ref<number[]>;
  progressFeatures: Ref<any[]>;
  labelKey: Ref<string>;
  // 行为
  cluster: Ref<boolean>;
  clusterAnchor: Ref<'corner' | 'center'>;
  fit: Ref<boolean>;
  hover: Ref<boolean>;
  popup?: Ref<((properties: Record<string, any>) => VNode | null) | undefined>;
  // 事件
  onFeatureClick?: (feature: any, originalEvent: any) => void;
  // 复用 GeoMap 已有的 useMapbox 实例（sources 集合需要共享）
  createPopup?: (node: VNode, lngLat: LngLatLike) => void;
}

export interface FeatureLayerApi {
  /** 地图 load 或 style.load 后调用，创建所有业务图层 */
  attach: () => void;
  /** 切换底图前调用，清空图层 id 缓存（setStyle 会清掉图层） */
  detach: () => void;
  /** 手动重算高亮（选中 / 屏蔽） */
  applyState: () => void;
  /** 手动重算填充配色 */
  applyPalette: () => void;
  /** 手动刷新进度条 */
  applyProgress: () => void;
  /** 手动刷新要素文字 */
  applyLabel: () => void;
}

export function useFeatureLayers(utils: ReturnType<typeof useMapResource>, options: FeatureLayerOptions): FeatureLayerApi {
  // ------ 图层 id 缓存（attach 时赋值，detach 时清空）------
  let polygonSourceId = '';
  let clusterSourceId = '';
  let fillLayerId = '';
  let lineLayerId = '';
  /** 选中 halo 白描边（垫在彩色选中线下；详见 selection-style.ts 的说明） */
  let haloLayerId = '';
  let progressSourceId = '';
  let progressLayerId = '';
  let labelSourceId = '';
  let labelLayerId = '';
  let hoverPopup: maplibregl.Popup | null = null;
  let lastSignature = '';

  // ------ 工具函数 ------
  function featureCollection(features: any[]) {
    return { type: 'FeatureCollection', features };
  }

  function clusterPoint(feature: any) {
    const coords = feature?.geometry?.coordinates?.[0];
    if (!Array.isArray(coords) || !coords.length) return [116.4, 39.9];
    if (options.clusterAnchor.value === 'corner') return coords[0];
    const lngs = coords.map((p: number[]) => p[0]);
    const lats = coords.map((p: number[]) => p[1]);
    return [(Math.min(...lngs) + Math.max(...lngs)) / 2, (Math.min(...lats) + Math.max(...lats)) / 2];
  }

  function colorExpression() {
    return ['match', ['get', options.colorKey.value], ...Object.entries(options.palette.value).flat(), '#cccccc'];
  }

  function opacityExpression() {
    return ['case', ['in', ['id'], ['literal', options.hiddenIds.value]], 0.08, ['in', ['id'], ['literal', options.selectedIds.value]], 0.85, 0.35];
  }

  // ------ 状态应用 ------
  function applyFillOpacity() {
    const map = utils.mapInstance.value;
    if (!fillLayerId || !map?.getLayer(fillLayerId)) return;
    map.setPaintProperty(fillLayerId, 'fill-opacity', opacityExpression() as any);
  }

  function applyLineStyle() {
    const map = utils.mapInstance.value;
    if (!lineLayerId || !map?.getLayer(lineLayerId)) return;
    const selected = ['in', ['id'], ['literal', options.selectedIds.value]] as any;
    // [why] 选中线用要素自身类别色（与 fill-color 同源 colorExpression），不再写死系统蓝；
    // 加粗 + 白色 halo 仍作为「已选中」的额外信号，避免纯靠颜色在同类图斑里认不出来。
    map.setPaintProperty(lineLayerId, 'line-color', ['case', selected, colorExpression(), MAP_UNSELECTED_LINE.color] as any);
    map.setPaintProperty(lineLayerId, 'line-width', ['case', selected, MAP_SELECTION.lineWidth, MAP_UNSELECTED_LINE.width] as any);
    if (haloLayerId && map.getLayer(haloLayerId)) {
      map.setPaintProperty(haloLayerId, 'line-width', ['case', selected, MAP_SELECTION.haloWidth, 0] as any);
    }
  }

  function applyPalette() {
    const map = utils.mapInstance.value;
    if (!map) return;
    if (fillLayerId && map.getLayer(fillLayerId)) map.setPaintProperty(fillLayerId, 'fill-color', colorExpression() as any);
    if (progressLayerId && map.getLayer(progressLayerId)) map.setPaintProperty(progressLayerId, 'fill-color', colorExpression() as any);
  }

  function applyState() {
    applyFillOpacity();
    applyLineStyle();
  }

  function setSourceData(id: string, data: any) {
    const source = utils.mapInstance.value?.getSource(id) as any;
    if (source?.setData) source.setData(data);
  }

  function syncData(fitBounds: boolean) {
    if (!utils.mapInstance.value) return;
    if (polygonSourceId) setSourceData(polygonSourceId, featureCollection(options.features.value));
    if (labelSourceId) setSourceData(labelSourceId, featureCollection(options.features.value));
    if (progressSourceId) setSourceData(progressSourceId, featureCollection(options.progressFeatures.value));
    if (clusterSourceId) {
      setSourceData(
        clusterSourceId,
        featureCollection(
          options.features.value.map((feature: any) => ({
            type: 'Feature',
            geometry: { type: 'Point', coordinates: clusterPoint(feature) },
            properties: feature.properties,
            id: feature.id
          }))
        )
      );
    }
    if (fitBounds && options.features.value.length) utils.fitBounds(featureCollection(options.features.value) as any);
  }

  function featuresSignature() {
    return options.features.value.map((f: any) => `${f?.id}:${f?.properties?.category ?? ''}`).join('|');
  }

  function fitToFeatures() {
    if (options.fit.value && options.features.value.length) utils.fitBounds(featureCollection(options.features.value) as any);
  }

  function applyProgress() {
    if (progressSourceId) setSourceData(progressSourceId, featureCollection(options.progressFeatures.value));
  }

  function applyLabel() {
    const map = utils.mapInstance.value;
    if (labelLayerId && map?.getLayer(labelLayerId)) {
      map.setLayoutProperty(labelLayerId, 'text-field', options.labelKey.value ? ['get', options.labelKey.value] : '');
    }
  }

  // ------ 图层创建 ------
  function attach() {
    const map = utils.mapInstance.value;
    if (!map) return;

    // fill 图层
    const fillSource = utils.createSource({ type: 'geojson', data: featureCollection(options.features.value) } as any);
    polygonSourceId = fillSource.id;
    const fillLayer = fillSource.addLayer({
      type: 'fill',
      paint: {
        'fill-color': colorExpression() as any,
        'fill-opacity': opacityExpression() as any,
        'fill-outline-color': '#ffffff'
      }
    });
    fillLayerId = fillLayer.id;
    fillLayer.on('click', (event: any) => {
      const feature = event.features?.[0];
      if (!feature) return;
      hoverPopup?.remove();
      hoverPopup = null;
      const node = options.popup?.value?.(feature.properties ?? {});
      if (node && options.createPopup) {
        options.createPopup(node, [event.lngLat.lng, event.lngLat.lat]);
      }
      options.onFeatureClick?.(feature, event.originalEvent);
    });

    if (options.hover.value) {
      fillLayer.on('mouseenter', (event: any) => {
        const feature = event.features?.[0];
        if (!feature) return;
        const canvas = map.getCanvas();
        if (canvas) canvas.style.cursor = 'pointer';
        const fields = feature.properties ?? {};
        const el = document.createElement('div');
        el.className = 'geo-map__hover';
        // 名称（加粗，独占一行，长编码可换行不被截断）
        const nameEl = document.createElement('div');
        nameEl.className = 'geo-map__hover-name';
        nameEl.textContent = String(fields.name ?? '未命名');
        el.append(nameEl);
        // 类别（有值才显示，作为次级信息行）
        if (fields.category) {
          const catEl = document.createElement('div');
          catEl.className = 'geo-map__hover-cat';
          catEl.textContent = String(fields.category);
          el.append(catEl);
        }
        // 更新时间（末行，弱色）
        const timeEl = document.createElement('div');
        timeEl.className = 'geo-map__hover-time';
        const time = fields.createTime || fields.update_time || fields.created_at || '';
        timeEl.textContent = time ? `更新时间：${time}` : '';
        if (timeEl.textContent) el.append(timeEl);
        hoverPopup?.remove();
        hoverPopup = new maplibregl.Popup({ closeButton: false, closeOnClick: false, className: 'geo-map__hover-popup' })
          .setLngLat(event.lngLat)
          .setDOMContent(el)
          .addTo(map);
      });
      fillLayer.on('mousemove', (event: any) => {
        hoverPopup?.setLngLat(event.lngLat);
      });
      fillLayer.on('mouseleave', () => {
        map.getCanvas().style.cursor = '';
        hoverPopup?.remove();
        hoverPopup = null;
      });
    }

    // 选中 halo 白描边：先加才垫在彩色线下面
    const haloLayer = fillSource.addLayer({
      type: 'line',
      paint: {
        'line-color': MAP_SELECTION.haloColor,
        'line-width': ['case', ['in', ['id'], ['literal', options.selectedIds.value]], MAP_SELECTION.haloWidth, 0] as any,
        'line-opacity': MAP_SELECTION.haloOpacity
      }
    } as any);
    haloLayerId = haloLayer.id;

    // line 图层
    const lineLayer = fillSource.addLayer({
      type: 'line',
      paint: { 'line-color': MAP_UNSELECTED_LINE.color, 'line-width': MAP_UNSELECTED_LINE.width, 'line-opacity': MAP_UNSELECTED_LINE.opacity }
    });
    lineLayerId = lineLayer.id;

    // progress 图层
    const progressSource = utils.createSource({ type: 'geojson', data: featureCollection(options.progressFeatures.value) } as any);
    progressSourceId = progressSource.id;
    progressLayerId = progressSource.addLayer({
      type: 'fill',
      paint: { 'fill-color': colorExpression() as any, 'fill-opacity': 0.95, 'fill-outline-color': '#ffffff' }
    }).id;

    // label 图层
    const labelSource = utils.createSource({ type: 'geojson', data: featureCollection(options.features.value) } as any);
    labelSourceId = labelSource.id;
    labelLayerId = labelSource.addLayer({
      type: 'symbol',
      layout: {
        'text-field': options.labelKey.value ? ['get', options.labelKey.value] : '',
        'text-size': 12,
        'text-anchor': 'center'
      },
      paint: { 'text-color': '#172b4d', 'text-halo-color': '#ffffff', 'text-halo-width': 1.5 }
    }).id;

    // cluster 图层
    if (options.cluster.value) {
      const pointFeatures = options.features.value.map((feature: any) => ({
        type: 'Feature',
        geometry: { type: 'Point', coordinates: clusterPoint(feature) },
        properties: feature.properties,
        id: feature.id
      }));
      const clusterSource = utils.createSource({
        type: 'geojson',
        data: featureCollection(pointFeatures),
        cluster: true,
        clusterMaxZoom: 9,
        clusterRadius: 45
      } as any);
      clusterSourceId = clusterSource.id;
      clusterSource.addLayer({
        type: 'circle',
        filter: ['has', 'point_count'],
        paint: {
          'circle-color': '#2563eb',
          'circle-radius': ['step', ['get', 'point_count'], 16, 5, 22, 10, 28],
          'circle-opacity': 0.85
        }
      });
      clusterSource.addLayer({
        type: 'symbol',
        filter: ['has', 'point_count'],
        layout: { 'text-field': '{point_count_abbreviated}', 'text-size': 12 },
        paint: { 'text-color': '#ffffff' }
      });
    }

    applyState();
  }

  function detach() {
    // setStyle 会清空所有图层和 sources；这里只需清空 id 缓存，
    // 让 attach 重新生成。useMapbox 内部的 sources 集合会在 setStyle 后失效，
    // 但 utils.createSource 用 genId 生成新 id，不会与旧冲突。
    polygonSourceId = '';
    clusterSourceId = '';
    fillLayerId = '';
    lineLayerId = '';
    haloLayerId = '';
    progressSourceId = '';
    progressLayerId = '';
    labelSourceId = '';
    labelLayerId = '';
    hoverPopup?.remove();
    hoverPopup = null;
    lastSignature = '';
  }

  // ------ 内部 watch：把状态变化内聚在这里 ------
  watch(options.selectedIds, () => applyState(), { deep: true });
  watch(options.hiddenIds, () => applyState(), { deep: true });
  watch(options.palette, () => applyPalette(), { deep: true });
  watch(
    options.features,
    () => {
      if (!utils.mapInstance.value || !polygonSourceId) return;
      const sig = featuresSignature();
      syncData(sig !== lastSignature && options.fit.value);
      lastSignature = sig;
    },
    { deep: true }
  );
  watch(options.progressFeatures, () => applyProgress(), { deep: true });
  watch(options.labelKey, () => applyLabel());

  return { attach, detach, applyState, applyPalette, applyProgress, applyLabel };
}
