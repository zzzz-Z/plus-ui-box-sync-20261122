<script setup lang="tsx">
import type { Map as MapLibreMap, MapEventType } from 'maplibre-gl';
import * as maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import { Grid, OfficeBuilding, Picture } from '@element-plus/icons-vue';
import { applyExtrusion } from './add3dBuildings';
import { MapToolbarControl, TOOLBAR_COMMAND_EVENT } from './toolbar-control';
import type { ToolbarCommand } from './toolbar-control';
import type { ToolbarItem } from './toolbar-types';
import { useBaseMaps } from './use-basemaps';
import type { BasemapOption } from './use-basemaps';
import { useDrawTool } from './use-draw-tool';
import type { DrawToolType } from './use-draw-tool';
import { useMapResource } from './use-map-resource';
import { useLayerManager } from './use-layer-manager';
import { useGridLayer } from './use-grid-layer';
import LayerControl from './layer-control.vue';
import { useMapState } from './use-map-state';
import { getToken } from '@/utils/auth';

/**
 * 通用地图容器（不含业务图层）
 *
 * 职责边界：
 * - 本组件负责：地图实例创建、3D 白膜、绘制引擎驱动、插槽、工具栏拼装；
 * - 底图（列表 / 状态 / 切换 / 首帧应用）全部内聚在 useBaseMaps，本组件只接回调；
 * - 业务图层（要素矩形 / 高亮 / 进度 / label / cluster / 配色）由业务侧通过 useMap() 自行注册。
 *
 * 事件契约：
 * - ready：地图 load 完成（含首帧底图 style.load），抛出 { map, utils }，业务侧据此首次 attach 图层；
 * - styleChange：底图切换后 style.load 完成（setStyle 会清掉所有图层），业务侧据此 detach + attach；
 * - toolbarCommand：工具栏控件（MapToolbarControl）交互时 map.fire('toolbar:command') 的透传，
 *   负载 { kind, key, value }；业务侧也可直接 @ready 拿到的 map.on('toolbar:command', …) 监听。
 *
 * 工具栏实现方式：自定义按钮不再是模板浮层，而是实现 IControl（见 toolbar-control.ts），
 * 经 map.addControl 挂到右下角 —— onAdd 内建 Vue 实例渲染 MapToolbar，onRemove 卸载。
 */

interface Props {
  basemapSwitcher?: boolean;
  extrusion?: boolean;
  /** 当前激活的绘制工具；空字符串 / 未传 = 未绘制 */
  drawTool?: DrawToolType | '';
  /**
   * 业务侧动态追加的工具栏项。
   * 渲染顺序：业务项 → 分割线 → 内置底图下拉 → 内置 3D 白膜开关；
   * 底图项仅在 basemaps.length > 1 时显示，3D 项始终显示。
   */
  toolbarItems?: ToolbarItem[];
  /**
   * 外部底图源；未传时用内置 DEFAULT_BASEMAPS。
   * WHY 由调用方注入：底图来自「系统管理 · 电子地图底图」接口，本组件不感知业务侧数据源。
   */
  basemaps?: BasemapOption[];
  /**
   * 启用的地图基础控件（maplibre 原生控件）。
   * 默认开启全部；传空数组可关闭所有。
   */
  controls?: Array<'navigation' | 'scale' | 'fullscreen' | 'geolocate'>;
  /**
   * 全屏目标元素；不传则对地图外壳 `.geo-map` 全屏。
   * 传页面级容器（如「地图 + 列表」上下分栏的容器）时，全屏子树里就带上了表格等兄弟节点 ——
   * 浏览器 requestFullscreen 只绘制「全屏元素」的子树，全屏地图自身会把表格整块裁掉。
   * 组件内部按「点击时才校正」处理，所以父级的模板 ref 晚一帧赋值也能生效。
   */
  fullscreenContainer?: HTMLElement;
  /**
   * 地图状态持久化 key；传值则记住相机（center/zoom/bearing/pitch），下次挂载时恢复。
   * 为空表示不持久化（适合临时预览/一次性地图）。
   */
  stateKey?: string;
  /**
   * 挂起 resize：容器尺寸剧烈变化期间（如拖动地图/表格分隔条）置真，
   * 此时 ResizeObserver 只记待执行标记、不真正 resize，避免每帧重排画布+重拉瓦片
   * （表现为「地图一直在刷新」）。置假时（拖动结束）补一次 resize 把地图拉回正确尺寸。
   */
  pauseResize?: boolean;
  /**
   * 50 万标准图幅格网图层（grid50）开关。
   * WHY 做成受控 prop 而非组件内部自持：开关态要能被业务侧持久化（刷新后保持），
   * 也可能被外部（图层面板 / 快捷入口）驱动，组件内自持会出现两份真值。
   */
  gridLayer?: boolean;
  /** 格网图层是否显示图幅号标注（th）；默认关闭，8104 个标注会明显拖慢渲染 */
  gridLabel?: boolean;
  /**
   * 绘制图形清除信号（自增计数）。值变大即擦除地图上残留的绘制图形。
   * WHY 独立信号：重置 / 清除由业务侧（查询面板）发起，draw 引擎却在本通用组件内；
   * 沿用 drawTool 由 prop 驱动的既有模式，由 map/index.vue 把业务 state 转发进来。
   */
  clearDrawSignal?: number;
}

const props = withDefaults(defineProps<Props>(), {
  basemapSwitcher: true,
  extrusion: true,
  drawTool: '',
  toolbarItems: () => [],
  gridLayer: false,
  gridLabel: false,
  clearDrawSignal: 0,
  controls: () => ['navigation', 'scale', 'fullscreen', 'geolocate']
});

const emit = defineEmits<{
  'ready': [payload: { map: MapLibreMap; utils: ReturnType<typeof useMapResource> }];
  'styleChange': [payload: { map: MapLibreMap; utils: ReturnType<typeof useMapResource> }];
  'update:basemap': [id: string];
  'update:extrusion': [value: boolean];
  'basemapChange': [id: string];
  'update:gridLayer': [value: boolean];
  'drawComplete': [feature: any];
  /** 工具栏自定义事件（map.fire('toolbar:command')）的 Vue 透传；业务侧也可直接 map.on */
  'toolbarCommand': [cmd: ToolbarCommand];
}>();

const mapContainer = ref<HTMLElement>();
/** 外壳根节点：作为全屏元素（见 applyControls 的 why） */
const rootEl = ref<HTMLElement>();
// 地图状态持久化：仅在传入 stateKey 时启用
const mapState = useMapState(() => props.stateKey);
const mapRef = shallowRef<maplibregl.Map>();
/**
 * 是否已按「外部注入的底图列表」应用过首帧底图。
 * WHY：底图列表（接口数据）晚于 map load 到达，需要补挂一次；
 * 补挂后置真，避免后续列表重算再次覆盖用户手动切换的底图。
 */
let appliedFromProps = false;
/** 工具栏控件实例：onAdd 内建 Vue 实例，removeControl 时随之卸载 */
let toolbarControl: MapToolbarControl | undefined;
/** 全屏控件实例：需要按 props.fullscreenContainer 校正全屏目标（见 syncFullscreenTarget） */
let fullscreenControl: maplibregl.FullscreenControl | undefined;
/** 容器尺寸监听：flex 布局撑开时触发 map.resize()，避免世界地图重复平铺 */
let resizeObserver: ResizeObserver | undefined;
/**
 * 拖动分隔条等分栏尺寸剧烈变化期间挂起 resize，解除后补一次，避免地图每帧刷新。
 * - pendingResize：挂起期间尺寸确有变化，待解除时补 resize；
 * - resizeRaf：rAF 合并同一帧内的多次 RO 通知，并规避「ResizeObserver loop」报错。
 */
let pendingResize = false;
let resizeRaf = 0;
function doResize() {
  resizeRaf = 0;
  // 排队中的 rAF 可能在「开始拖拽」那一帧之前就排好了，此时 pauseResize 已置真 ——
  // 仍然要放弃这次 resize，否则拖拽首帧仍会重建一次画布（就是那一下闪屏）。
  if (props.pauseResize) {
    pendingResize = true;
    return;
  }
  mapRef.value?.resize();
}
function scheduleResize() {
  if (props.pauseResize) {
    pendingResize = true;
    return;
  }
  pendingResize = false;
  if (resizeRaf) return;
  resizeRaf = requestAnimationFrame(doResize);
}
const utils = useMapResource(mapRef!);
// 图层管理：面板打开时扫描当前 style 的图层（styleChange 后需重新扫描）
const layerManager = useLayerManager(() => mapRef.value);
const showLayers = ref(false);
const layerList = computed(() => layerManager.layers.value);

/**
 * 底图 composable：内置列表 + 当前底图状态 + 切换 + 首帧应用。
 * 事件回吐给父组件；样式完成回调里挂 3D 白膜并按场景抛 ready / styleChange。
 */
// ------ 绘制引擎（折线/矩形/圆/多边形）------
// [why] 独立 composable，通过 drawTool prop 驱动；完成后 emit drawComplete 由父组件派生命中。
const draw = useDrawTool({
  getMap: () => mapRef.value,
  onComplete: (feature) => emit('drawComplete', feature)
});

watch(
  () => props.drawTool,
  (tool) => {
    if (!tool) {
      draw.stop();
      return;
    }
    if (!mapRef.value) return;
    draw.start(tool as DrawToolType);
  }
);
/**
 * 业务侧「重置 / 清除」发来的信号：擦掉绘制引擎留在地图上的图形。
 * WHY 用信号值变化而非方法调用：GeoMap 是通用组件、draw 实例不外泄；
 * 与 drawTool 一样走 prop 驱动，map/index.vue 把 state.drawClearSignal 转发进来即可。
 * WHY 判 signal > 0：默认 0 是初始态，避免首帧误清。
 */
watch(
  () => props.clearDrawSignal,
  (signal, prev) => {
    if (signal !== prev && signal > 0) draw.clear();
  }
);
// ------ 50 万标准图幅格网（grid50）------
// [why] 由 props.gridLayer 受控：ready / styleChange 时按开关态挂载，开关翻转时挂/卸；
// 数据本身在模块级缓存，反复开关不会重复下载解析 3.8MB geojson。
const gridLayer = useGridLayer(() => mapRef.value, { label: props.gridLabel });

async function syncGridLayer() {
  if (props.gridLayer) await gridLayer.attach();
  else gridLayer.detach();
}

watch(
  () => props.gridLayer,
  () => syncGridLayer()
);

const basemapSource = computed<BasemapOption[] | undefined>(() => props.basemaps);
const basemaps = useBaseMaps(mapRef, {
  basemaps: basemapSource,
  onUpdateBasemap: (id) => emit('update:basemap', id),
  onBasemapChange: (id) => emit('basemapChange', id),
  onStyleLoad: (map, kind) => {
    applyExtrusion(map, props.extrusion);
    // setStyle 会清掉所有 source/layer，格网需在每次 style.load 后重挂
    void syncGridLayer();
    emitReady(kind === 'switch' ? 'styleChange' : 'ready');
    // 首帧地图就绪后若父组件已指定 drawTool，补启一次（watch 会因 map 未就绪被跳过）
    if (kind === 'initial' && props.drawTool) draw.start(props.drawTool as DrawToolType);
  }
});

watch(
  () => props.extrusion,
  (enabled) => {
    if (mapRef.value) applyExtrusion(mapRef.value, enabled);
  }
);

/**
 * 工具栏项拼装：业务动态项 + 分割线 + 内置项。
 * WHY 用 computed 而非 watch：底图名称 / 3D 状态变化时无需手动同步，
 * 模板每次渲染都从最新 props 派生，避免「点了 3D 但按钮态滞后」。
 */
const baseToolbarItem = computed<ToolbarItem[]>(() => {
  return [
    ...(props.toolbarItems ?? []),
    { type: 'divider', key: '__divider_basemap' },
    {
      type: 'dropdown',
      key: '__basemap',
      icon: Picture,
      tooltip: `底图：${basemaps.basemapName.value || '切换'}`,
      options: basemaps.basemaps.value.map((b) => ({ id: b.id, name: b.name, thumb: b.thumbnail })),
      value: basemaps.activeBasemap.value,
      horizontal: true,
      onSelect: (id: string) => basemaps.switchBasemap(id)
    },
    {
      type: 'button',
      key: '__grid50',
      icon: Grid,
      tooltip: props.gridLayer ? '关闭 50 万图幅格网' : '开启 50 万图幅格网',
      active: props.gridLayer,
      onClick: () => emit('update:gridLayer', !props.gridLayer)
    },
    // {
    //   type: 'button',
    //   key: '__layers',
    //   icon: Grid,
    //   tooltip: showLayers.value ? '关闭图层面板' : '图层面板',
    //   active: showLayers.value,
    //   onClick: () => {
    //     showLayers.value = !showLayers.value;
    //     if (showLayers.value) layerManager.refresh();
    //   }
    // },
    {
      type: 'button',
      key: '__extrusion',
      icon: OfficeBuilding,
      tooltip: props.extrusion ? '关闭 3D 白膜' : '开启 3D 白膜',
      active: props.extrusion,
      onClick: () => emit('update:extrusion', !props.extrusion)
    }
  ] as ToolbarItem[];
});

/** 通知业务侧：地图就绪 或 底图切换完成 */
function emitReady(kind: 'ready' | 'styleChange') {
  const m = mapRef.value;
  if (!m) return;
  // [why] Vue defineEmits 的重载按字面量事件名分派；传联合类型 kind 时 TS 无法定位具体重载（TS2769）。
  // 拆成两个具体 emit 调用，让每次调用的事件名都是字面量，重载可精确匹配。
  const payload = { map: m, utils };
  if (kind === 'ready') emit('ready', payload);
  else emit('styleChange', payload);
  // styleChange 会清掉业务图层，面板若开着需重扫，避免显示过期条目
  if (kind === 'styleChange' && showLayers.value) layerManager.refresh();
}

// ------ 地图生命周期 ------
function setChineseLabels(mapInstance: maplibregl.Map) {
  mapInstance.getStyle().layers?.forEach((layer: any) => {
    if (layer.type !== 'symbol' || !layer.layout?.['text-field']) return;
    mapInstance.setLayoutProperty(layer.id, 'text-field', ['coalesce', ['get', 'name_zh-Hans'], ['get', 'name_zh'], ['get', 'name']]);
  });
}

onMounted(() => {
  if (!mapContainer.value) return;

  const initial = mapState.restore();
  mapRef.value = new maplibregl.Map({
    container: mapContainer.value,
    // 关闭右下角 attribution 信息条（默认会显示 MapLibre/OpenFreeMap/OSM 版权行）
    attributionControl: false,
    // 用本地字体渲染汉字（离线中国底图的中文省名标注无需下载字形 PBF，断网也可用）
    localIdeographFontFamily: 'sans-serif',
    // WHY 关闭世界副本：数据 bbox 缺失时 zoom 可能被拉到很小，
    // renderWorldCopies 会在低 zoom 下平铺多份世界地图，视觉上像重复渲染。
    renderWorldCopies: false,
    style: { version: 8, sources: {}, layers: [{ id: 'background', type: 'background', paint: { 'background-color': '#f5f7fa' } }] } as any,
    /**
     * 瓦片请求注入鉴权头。
     *
     * WHY 必需：元数据矢量瓦片（metadata-tables/{tableKey}/tiles）在统一网关上要 token，
     * 但 maplibre 拉瓦片走浏览器原生 fetch，完全不经过 axios 实例，拿不到 request.ts 里的
     * Authorization / clientid 头 —— 不注入的话瓦片恒 401。
     *
     * CONSTRAINT 只对本项目网关路径注入，第三方瓦片（openfreemap 等）不带本站 token，
     * 避免把凭证发给外部服务。
     */
    transformRequest: (url: string) => {
      if (!/\/product-api\/|\/datamanage\/api\//.test(url)) return { url };
      const headers: Record<string, string> = {};
      const token = getToken();
      if (token) headers.Authorization = 'Bearer ' + token;
      const cid = import.meta.env.VITE_APP_CLIENT_ID;
      if (cid) headers.clientid = cid;
      return { url, headers };
    },
    center: (initial?.center ?? [116.3974, 39.9093]) as any,
    bearing: initial?.bearing ?? 0,
    pitch: initial?.pitch ?? 0,
    zoom: initial?.zoom ?? 10
  });
  // 交互结束（拖拽/缩放/旋转）后节流保存；保存失败不阻塞地图
  mapRef.value.on('moveend', () => mapState.save(mapRef.value));
  mapRef.value.on('rotateend', () => mapState.save(mapRef.value));

  mapRef.value.on('style.load', () => {
    if (mapRef.value) setChineseLabels(mapRef.value);
  });

  mapRef.value.on('load', () => {
    if (!mapRef.value) return;
    basemaps.applyInitialBasemap();
  });

  /**
   * 底图列表异步到达后再补挂一次首帧底图。
   *
   * WHY 必需：`load` 事件在地图初始化阶段就触发，而外部注入的底图列表（接口返回的在线底图）
   * 通常晚于它到达。此时 applyInitialBasemap 已经用「当时的列表」（可能是内置兜底）跑过一次，
   * 若不补挂，接口数据到位后地图仍停在兜底底图上 ——
   * 表现为「下拉里列着在线底图，画面却还是离线底图」。
   *
   * CONSTRAINT 必须走 switchBasemap 而不是 applyInitialBasemap：
   * 后者在地图已挂过 style 时（此时必然已挂过）只触发 onStyleLoad、不调 setStyle，画面不会换。
   *
   * CONSTRAINT 用 appliedFromProps 只补挂一次：
   * 用户手动切换底图后，若父组件因重算再次刷新列表，不得把用户的选图强行拉回默认。
   */
  watch(
    () => props.basemaps,
    (list) => {
      if (!mapRef.value || !list?.length) return;
      if (appliedFromProps) return;
      const current = basemaps.activeBasemap.value;
      // 当前激活项不在新列表内（说明首帧用的是旧/兜底列表）→ 切到新列表第一项
      if (!list.some((b) => b.id === current)) {
        const first = list[0];
        if (first) {
          // switchBasemap 内部会跳过「与当前相同」的 id，故先清空激活值
          basemaps.activeBasemap.value = '';
          basemaps.switchBasemap(first.id);
        }
      }
      appliedFromProps = true;
    }
  );

  applyControls(mapRef.value);

  // 自定义工具栏：实现 IControl 后经 map.addControl 挂到右下角，
  // onAdd 内部建 Vue 实例渲染 MapToolbar，交互统一 map.fire('toolbar:command')
  toolbarControl = new MapToolbarControl({ getItems: () => baseToolbarItem.value });
  mapRef.value.addControl(toolbarControl, 'bottom-right');
  // items computed 变化（底图名 / 3D 开关态 / 业务动态项）同步进控件，触发内部 Vue 重渲染
  watch(baseToolbarItem, (items) => toolbarControl?.updateItems(items));
  // 控件抛出的自定义事件 → 转 Vue 事件透传给业务侧
  mapRef.value.on(TOOLBAR_COMMAND_EVENT, (e: any) => emit('toolbarCommand', { kind: e.kind, key: e.key, value: e.value } as ToolbarCommand));

  // WHY 自建 ResizeObserver：maplibre 内置 trackResize 只监听 window resize，
  // 容器在挂载后才被 flex 撑开（如列表/地图分栏切换）时 canvas 不会跟随，
  // 表现为世界地图被重复平铺多次。这里监听容器尺寸并主动 resize。
  // 优化：拖动分隔条等场景容器高度每帧都在变，若每帧同步 resize() 会让 maplibre
  // 持续重排画布并重拉瓦片，表现为「地图一直在刷新」。故 resize 走 rAF 合并，
  // 且 props.pauseResize 为真时挂起，仅记待执行标记，解除挂起后补一次（见下方 watch）。
  resizeObserver = new ResizeObserver(scheduleResize);
  resizeObserver.observe(mapContainer.value);
});

/** 按 props.controls 加装 maplibre 原生控件；样式由本组件覆盖以保持视觉统一 */
function applyControls(map: maplibregl.Map) {
  const enabled = new Set(props.controls ?? []);
  if (enabled.has('navigation')) {
    map.addControl(new maplibregl.NavigationControl({ visualizePitch: true }), 'top-right');
  }
  if (enabled.has('scale')) {
    map.addControl(new maplibregl.ScaleControl({ maxWidth: 100, unit: 'metric' }), 'bottom-left');
  }
  if (enabled.has('fullscreen')) {
    // WHY 显式指定 container（默认取 map.getContainer()，即 .map-container）：
    // 浏览器 requestFullscreen 只渲染「全屏元素」的子树，其余节点一律不绘制。
    // 而查询面板 / 图例是 .map-container 的兄弟节点（走 GeoMap 的插槽，渲染在 .geo-map 下），
    // 一进全屏就整块消失 —— 表现为「地图全屏后查询框不见了」。
    // 改成对外层 .geo-map 全屏：地图 + 原生控件 + 自定义工具栏 + 图例 + 查询面板一起进子树。
    // 业务侧若传入 fullscreenContainer（「地图 + 列表」分栏容器），则连表格一起进子树。
    fullscreenControl = new maplibregl.FullscreenControl({ container: props.fullscreenContainer ?? rootEl.value ?? undefined });
    map.addControl(fullscreenControl, 'top-right');
  }
  // if (enabled.has('geolocate')) {
  //   map.addControl(
  //     new maplibregl.GeolocateControl({
  //       positionOptions: { enableHighAccuracy: true },
  //       trackUserLocation: true
  //     }),
  //     'top-right'
  //   );
  // }
}

/**
 * 全屏目标校正：父级的模板 ref（分栏容器）在子组件挂载后才赋值，
 * applyControls 那一刻可能还拿不到，首帧只能退化成「对 .geo-map 全屏」。
 * FullscreenControl 没有暴露 setter，而 maplibre 内部把它存成普通字段 `_container`
 * （_requestFullscreen 用它、_onFullscreenChange 用它比对 fullscreenElement），
 * 所以这里直接改写该字段；不校正的话点全屏仍是「只有地图、表格消失」。
 */
watch(
  () => props.fullscreenContainer,
  (el) => {
    if (el && fullscreenControl) (fullscreenControl as any)._container = el;
  }
);

// 解除挂起（分隔条拖动结束）：补一次 resize，把地图拉回正确尺寸
watch(
  () => props.pauseResize,
  (paused) => {
    if (!paused && pendingResize) scheduleResize();
  }
);

onBeforeUnmount(() => {
  if (resizeRaf) cancelAnimationFrame(resizeRaf);
  resizeRaf = 0;
  resizeObserver?.disconnect();
  resizeObserver = undefined;
  draw.stop();
  // 先 removeControl（触发 onRemove：卸载内部 Vue 实例 + 摘除 DOM），再销毁地图
  if (mapRef.value && toolbarControl) mapRef.value.removeControl(toolbarControl);
  toolbarControl = undefined;
  // 卸载前落一次最新相机，避免快速切页丢状态
  mapState.saveNow(mapRef.value);
  gridLayer.detach();
  mapRef.value?.remove();
  mapRef.value = undefined;
});

defineExpose({ mapRef, utils, gridLayer });
</script>

<template>
  <div ref="rootEl" class="geo-map" :class="{ 'is-resize-paused': pauseResize }">
    <div ref="mapContainer" class="map-container" />
    <!-- 工具栏已改为 MapToolbarControl（map.addControl 挂载），不再走模板渲染 -->
    <LayerControl
      v-if="showLayers"
      :layers="layerList"
      @toggle="layerManager.toggle"
      @set-opacity="layerManager.setOpacity"
      @set-minzoom="layerManager.setMinzoom"
      @refresh="layerManager.refresh"
      @close="showLayers = false"
    />
    <slot />
  </div>
</template>

<style lang="scss" scoped>
.geo-map {
  position: relative;
  height: 100%;
  min-height: 0;
  /* 浮层停靠 token：业务侧浮层（图例 / 查询面板等）经插槽渲染在 .geo-map 内，
     与 maplibre 原生控件抢同一块边缘空间，统一由这里给出几何常量。
     - --map-ctrl-rail：右上角原生控件竖条占位宽（控件 30px + 角标 10px 内边距 + 余量）；
     - --map-legend-w：图例面板宽度（legend.vue 的 .map-tools），查询面板据此停在图例左侧。
     自定义属性沿 DOM 继承，插槽内容（不出本组件的子树）都能读到；页面不传时各浮层用同值兜底。 */
  --map-ctrl-rail: 52px;
  --map-legend-w: 176px;
}

.map-container {
  width: 100%;
  height: 100%;
  /* WHY 不用 min-height：分栏场景下容器高可能小于 320px，撑破会导致 canvas 溢出、世界地图被重复平铺 */
  min-height: 0;
  /* 与 style 里 background 图层的颜色一致：canvas 尺寸滞后于容器时（见下方 is-resize-paused），
     露出来的这条边读作「地图空白区」，而不是一条突兀的白边。 */
  background: #f5f7fa;
}

/*
 * 拖分隔条期间把画布「钉」在左上角。
 *
 * WHY：容器尺寸每帧都在变，而 maplibre 的 canvas 是 position:absolute 且由 JS 显式写死
 * style.width/height（_resizeCanvas 里按容器尺寸 × pixelRatio 反算）。我们挂起 resize 后，
 * canvas 的 CSS 尺寸停在旧值，容器却在缩 —— 浏览器每帧都要把这张旧位图重新合成到新容器里，
 * 表现为拖动过程中地图「抖动 / 闪一下」。
 * 加 will-change 让画布单独成层、拖动期间不参与父级重排的重绘，视觉上就稳住了；
 * 松手后 pauseResize 置假、补一次 resize，尺寸与位图重新对齐。
 */
.geo-map.is-resize-paused :deep(.maplibregl-canvas) {
  will-change: transform;
}

/* maplibre 原生控件：与自定义工具栏统一风格 */
:deep(.maplibregl-ctrl-group) {
  background: rgb(255 255 255 / 94%);
  border: 1px solid rgb(31 55 84 / 10%);
  border-radius: 6px;
  box-shadow: 0 4px 12px rgb(25 45 70 / 14%);
  backdrop-filter: blur(8px);
}

:deep(.maplibregl-ctrl-group button) {
  width: 30px;
  height: 30px;
}

/* WHY 抬 z-index：自定义工具栏经 addControl 进入控件容器（maplibre 默认 z-index 2），
   会被 .geo-map 内的浮层盖住 —— 图层面板 z-index 7、查询面板 5；
   且工具栏的 dropdown/tooltip 已改为 teleported=false 原地渲染（全屏时 body 级弹窗不显示），
   层级必须随容器一起抬到最顶层。只抬 bottom-right：原生控件在其余三个角，不受影响。 */
:deep(.maplibregl-ctrl-bottom-right) {
  z-index: 10;
}

:deep(.maplibregl-ctrl-scale) {
  color: #172b4d;
  background: rgb(255 255 255 / 94%);
  border-color: rgb(31 55 84 / 20%);
  font-size: 11px;
  backdrop-filter: blur(8px);
}
</style>

<style lang="scss">
/* 地图气泡：与图例 / 查询面板统一的玻璃风格（半透明底 + 模糊 + 统一描边 / 阴影 / 圆角） */
.geo-map .maplibregl-popup-content {
  padding: 10px 12px;
  color: #26364b;
  background: rgb(255 255 255 / 96%);
  border: 1px solid rgb(31 55 84 / 12%);
  border-radius: 8px;
  box-shadow: 0 8px 24px rgb(25 45 70 / 20%);
  backdrop-filter: blur(8px);
}

.geo-map .maplibregl-popup-close-button {
  top: 5px;
  right: 7px;
  width: 22px;
  height: 22px;
  color: #8a97a8;
  border-radius: 50%;
  font-size: 16px;
}

.geo-map .maplibregl-popup-close-button:hover {
  color: #e04b4b;
  background: #fff1f1;
}

/* 悬停气泡正文：限定最大宽度并允许长编码换行，避免气泡被超长资源名撑爆 */
.geo-map__hover {
  max-width: 240px;
  color: #26364b;
  font-size: 12px;
  line-height: 1.5;
  word-break: break-word;
}

.geo-map__hover-name {
  color: #172b4d;
  font-size: 13px;
  font-weight: 600;
  line-height: 1.4;
  margin-bottom: 3px;
  word-break: break-word;
}

/* 类别行：有值时才渲染，作为名称与时间的次级信息 */
.geo-map__hover-cat {
  color: #5b6b80;
  font-size: 12px;
  line-height: 1.4;
  margin-bottom: 3px;
  word-break: break-word;
}

.geo-map__hover-time {
  color: #728096;
  font-size: 12px;
  word-break: break-word;
}
</style>
