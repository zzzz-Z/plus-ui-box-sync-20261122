import type { Map as MapLibreMap } from 'maplibre-gl';
import type { Ref } from 'vue';
import { ref } from 'vue';
import gridGeoJsonUrl from '@/assets/geojson/grid50.geojson?url';

/**
 * 50 万标准图幅格网图层（grid50）
 *
 * 数据：src/assets/geojson/grid50.geojson（EPSG:4490，经纬度，与 maplibre 的 WGS84 一致，无需投影转换）。
 * 结构：8104 个 Polygon，属性 bqbm（S 南半球 / N 北半球）、x（经向列号）、y（纬向行号）、
 *       xh（图幅列号 1-4）、remark（图幅尺寸，如 6°*4°）、th（图幅号）。
 *
 * WHY 走 ?url + fetch 而非 `import grid from '...geojson'`：
 * Vite 的 JSON 插件只匹配 `.json` 后缀（jsonExtRE = /\.json(?:$|\?)/），`.geojson` 会落到静态资源管线，
 * 直接 import 拿到的是 URL 字符串而非对象。即便把后缀改成 .json，3.8MB 也会被打进主 chunk，
 * 首屏解析代价过高。这里用 ?url 保留为独立资源文件，按需 fetch，且可走浏览器缓存。
 *
 * 职责边界：
 * - 本模块只关心「把格网画到地图上」，不持有地图实例；
 * - 由 GeoMap 在 ready / styleChange 与开关态变化时调用 attach / hide；
 * - 底图切换会 setStyle 清空 source/layer，故重挂由 attach 完成。
 *
 * 为什么单独一个模块而不并入 use-feature-layers：
 * 业务图层（要素矩形 / 高亮 / 进度）随业务数据变化重绘，格网是静态底衬，
 * 两者生命周期不同；混在一起会让「业务数据刷新」顺带重建 8104 个面，代价过高。
 */

export interface GridLayerOptions {
  /** 南北半球配色：默认南半球冷色、北半球暖色，便于一眼分辨 */
  palette?: Record<string, string>;
  /** 是否显示图幅编号标注（th 字段）；默认关闭，8104 个标注会明显拖慢渲染 */
  label?: boolean;
  /** 描边不透明度（0-1），默认 0.55 */
  opacity?: number;
}

export interface GridLayerApi {
  /** 地图就绪 / 底图切换后调用；重复调用安全（已挂载则忽略） */
  attach: () => Promise<void>;
  /** 真正从地图移除 source / layer（业务侧关掉开关时用） */
  detach: () => void;
  /** 显示 / 隐藏（不销毁数据，仅切 layout.visibility） */
  setVisible: (visible: boolean) => void;
  /** 当前是否已挂到地图上 */
  mounted: Ref<boolean>;
  /** 数据是否已加载完成 */
  loaded: Ref<boolean>;
  /** 格网要素总数（加载完成前为 0） */
  featureCount: Ref<number>;
}

/** 图层 id 常量：语义化命名，方便图层面板与调试时辨认 */
export const GRID_SOURCE_ID = 'grid50-source';
export const GRID_FILL_LAYER_ID = 'grid50-fill';
export const GRID_LINE_LAYER_ID = 'grid50-line';
export const GRID_LABEL_LAYER_ID = 'grid50-label';

/** 默认配色：S 南半球 / N 北半球 */
const DEFAULT_PALETTE: Record<string, string> = {
  S: '#2563eb',
  N: '#f59e0b'
};

/** 模块级缓存：同一页面多次挂载（底图切换 / 组件重建）只下载解析一次 */
let gridDataPromise: Promise<any> | null = null;

function loadGridData(): Promise<any> {
  if (!gridDataPromise) {
    gridDataPromise = fetch(gridGeoJsonUrl)
      .then((res) => {
        if (!res.ok) throw new Error(`grid50 加载失败：HTTP ${res.status}`);
        return res.json();
      })
      .catch((err) => {
        // 失败不缓存，下次挂载可重试
        gridDataPromise = null;
        throw err;
      });
  }
  return gridDataPromise;
}

/**
 * 创建格网图层控制器。
 * @param getMap 取地图实例（用函数而非实例：地图在 GeoMap onMounted 里创建，composable 需先于它执行）
 * @param options 配色 / 标注 / 透明度
 */
export function useGridLayer(getMap: () => MapLibreMap | undefined, options: GridLayerOptions = {}): GridLayerApi {
  const palette = options.palette ?? DEFAULT_PALETTE;
  const opacity = options.opacity ?? 0.55;
  const showLabel = options.label ?? false;

  const mounted = ref(false);
  const loaded = ref(false);
  const featureCount = ref(0);
  let visible = true;

  /**
   * 配色表达式：按 bqbm 匹配。
   * WHY 用 match 而非逐要素 setFeatureState：8104 个面逐条设状态在低配机器上会卡顿，
   * 单条表达式由渲染管线内部完成，代价与要素数同阶但常数小得多。
   */
  function colorExpression() {
    const entries = Object.entries(palette).flat();
    // maplibre 的 match 至少需要 input + 1 组 label/output + fallback，空 palette 会退化成 3 参数而报错
    if (!entries.length) return '#94a3b8';
    return ['match', ['get', 'bqbm'], ...entries, '#94a3b8'];
  }

  function addLayers(map: MapLibreMap, data: any) {
    map.addSource(GRID_SOURCE_ID, { type: 'geojson', data });

    // 填充：极低不透明度，只做「哪一格属于南 / 北半球」的底色暗示，不遮挡业务要素
    map.addLayer({
      id: GRID_FILL_LAYER_ID,
      type: 'fill',
      source: GRID_SOURCE_ID,
      layout: { visibility: visible ? 'visible' : 'none' },
      paint: {
        'fill-color': colorExpression() as any,
        'fill-opacity': 0.16
      }
    });

    // 描边：格网的主视觉，线宽随缩放递增，低 zoom 时不至于糊成一片
    map.addLayer({
      id: GRID_LINE_LAYER_ID,
      type: 'line',
      source: GRID_SOURCE_ID,
      layout: { visibility: visible ? 'visible' : 'none' },
      paint: {
        'line-color': colorExpression() as any,
        'line-opacity': opacity,
        'line-width': ['interpolate', ['linear'], ['zoom'], 0, 0.2, 4, 0.5, 8, 1] as any
      }
    });

    // 标注：默认关闭。th 是图幅号（如 KS12013），zoom 10 起才显示，避免全球视角下满屏文字
    if (showLabel) {
      map.addLayer({
        id: GRID_LABEL_LAYER_ID,
        type: 'symbol',
        source: GRID_SOURCE_ID,
        minzoom: 10,
        layout: {
          'text-field': ['get', 'th'],
          'text-size': 10,
          'text-allow-overlap': false,
          visibility: visible ? 'visible' : 'none'
        },
        paint: {
          'text-color': '#172b4d',
          'text-halo-color': '#ffffff',
          'text-halo-width': 1.2
        }
      });
    }
    mounted.value = true;
  }

  /**
   * 等待 style 可写。
   * WHY 不只靠 isStyleLoaded 一次判定：maplibre 的 style.load 回调里 isStyleLoaded()
   * 仍可能返回 false（还有未完成的 sprite/glyphs 请求）。此时 addSource 会抛错，
   * 而调用方（GeoMap）只在 style.load 时调一次 attach —— 一旦跳过就再没人重试，
   * 表现为「打开开关但格网不出现」。这里以 once('idle') 兜底重试一次。
   */
  function whenStyleReady(map: MapLibreMap): Promise<void> {
    if (map.isStyleLoaded()) return Promise.resolve();
    return new Promise((resolve) => {
      const done = () => {
        map.off('idle', done);
        resolve();
      };
      map.once('idle', done);
      // 兜底：极少数情况下 idle 不再触发（地图被卸载），500ms 后无论如何放行，
      // 由后续 addSource 的 try/catch 决定成败，不让 Promise 悬挂。
      setTimeout(done, 500);
    });
  }

  async function attach() {
    const map = getMap();
    if (!map || mounted.value) return;
    await whenStyleReady(map);
    // 已存在（例如上次 attach 后未走 detach）：直接标记为已挂载，避免重复 addSource 抛错
    if (map.getSource(GRID_SOURCE_ID)) {
      mounted.value = true;
      return;
    }

    const data = await loadGridData();
    // 等待期间可能已卸载 / 已切底图：二次校验，避免往失效的 map 上挂图层
    const current = getMap();
    if (!current || mounted.value) return;
    if (current.getSource(GRID_SOURCE_ID)) return;

    loaded.value = true;
    featureCount.value = data?.features?.length ?? 0;
    try {
      addLayers(current, data);
    } catch (err) {
      // 挂载失败（style 被并发 setStyle 替换等）：回滚状态，下次 attach 可重试
      mounted.value = false;
      throw err;
    }
  }

  function detach() {
    const map = getMap();
    if (map && map.getSource(GRID_SOURCE_ID)) {
      for (const id of [GRID_LABEL_LAYER_ID, GRID_LINE_LAYER_ID, GRID_FILL_LAYER_ID]) {
        if (map.getLayer(id)) map.removeLayer(id);
      }
      if (map.getSource(GRID_SOURCE_ID)) map.removeSource(GRID_SOURCE_ID);
    }
    mounted.value = false;
  }

  function setVisible(v: boolean) {
    visible = v;
    const map = getMap();
    if (!map || !mounted.value) return;
    const value = v ? 'visible' : 'none';
    for (const id of [GRID_FILL_LAYER_ID, GRID_LINE_LAYER_ID, GRID_LABEL_LAYER_ID]) {
      if (map.getLayer(id)) map.setLayoutProperty(id, 'visibility', value);
    }
  }

  return { attach, detach, setVisible, mounted, loaded, featureCount };
}