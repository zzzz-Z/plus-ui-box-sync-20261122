<script setup lang="ts">
import { Check } from '@element-plus/icons-vue';
import type { ToolbarDropdownItem, ToolbarItem } from './toolbar-types';

/**
 * 通用地图工具栏（右下角竖向条）
 *
 * 只消费结构化 item 数组，不感知「底图 / 3D / 查询」这些具体语义 ——
 * 具体项由调用方（GeoMap 内置 + 业务动态追加）拼装后传入。
 *
 * WHY 由 MapToolbarControl 挂载：本组件不直接出现在页面模板里，而是被
 * toolbar-control.ts 的 onAdd 用 createApp 挂进 maplibre 控件容器，
 * 随地图 addControl / removeControl 生命周期创建与销毁。
 *
 * WHY 每次渲染新对象也不做 memo：item 数组由 GeoMap 的 computed 派生，
 * 状态变化自动收敛到最新；此处再缓存反而增加失效点。
 */
defineProps<{ items: ToolbarItem[] }>();

/** dropdown 的 command 回调：屏蔽 el-dropdown 的 string 型 command 与 TS 收敛问题 */
function onDropdownCommand(item: ToolbarDropdownItem, cmd: string) {
  item.onSelect(cmd);
}
</script>

<template>
  <div v-if="items.length" class="map-toolbar" role="toolbar" aria-label="地图操作">
    <template v-for="item in items" :key="item.key">
      <!-- WHY 两处 teleported=false：地图全屏时浏览器只渲染全屏元素（地图容器）子树，
           默认 teleport 到 body 的弹窗/提示会被整体隐藏；原地渲染则始终留在子树内。
           代价是失去 body 级层级，由 GeoMap 抬高控件容器 z-index 兜底（见 index.vue）。 -->
      <span v-if="item.type === 'divider'" class="map-toolbar__divider" aria-hidden="true" />

      <el-tooltip
        v-else-if="item.type === 'button'"
        :content="item.tooltip"
        placement="left"
        :show-after="150"
        :teleported="false"
        popper-class="map-toolbar-tooltip"
      >
        <button
          type="button"
          class="map-toolbar__btn"
          :class="{ 'is-active': item.active }"
          :aria-pressed="item.active"
          :aria-label="item.tooltip"
          @click="item.onClick?.()"
        >
          <el-icon><component :is="item.icon" /></el-icon>
        </button>
      </el-tooltip>

      <el-dropdown
        v-else-if="item.type === 'dropdown'"
        trigger="click"
        placement="left-end"
        :teleported="false"
        @command="(cmd) => onDropdownCommand(item, cmd)"
      >
        <button type="button" class="map-toolbar__btn map-toolbar__btn--basemap" :aria-label="item.tooltip">
          <el-icon><component :is="item.icon" /></el-icon>
        </button>
        <template #dropdown>
          <el-dropdown-menu :class="{ 'map-toolbar__menu--horizontal': item.horizontal }">
            <el-dropdown-item v-for="opt in item.options" :key="opt.id" :command="opt.id" :class="{ 'is-active': opt.id === item.value }">
              <span class="map-toolbar__option" :class="{ 'map-toolbar__option--stack': item.horizontal }">
                <img v-if="opt.thumb" :src="opt.thumb" class="map-toolbar__thumb" alt="" aria-hidden="true" />
                <span class="map-toolbar__option-name">
                  <el-icon v-if="opt.id === item.value"><Check /></el-icon>
                  {{ opt.name }}
                </span>
              </span>
            </el-dropdown-item>
          </el-dropdown-menu>
        </template>
      </el-dropdown>
    </template>
  </div>
</template>

<style scoped lang="scss">
.map-toolbar {
  /* WHY 不再绝对定位：本组件由 MapToolbarControl 经 map.addControl 挂到
     .maplibregl-ctrl-bottom-right 角标容器，定位与层级由 maplibre 接管。
     WHY 面板 token 与原生控件（index.vue 的 :deep(.maplibregl-ctrl-group)）逐项对齐：
     背景/边框/模糊本就一致，圆角 2px→6px、阴影 0 6px 18px→0 4px 12px，避免两套控件并排可见时观感割裂。 */
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: 2px;
  background: rgb(255 255 255 / 94%);
  border: 1px solid rgb(31 55 84 / 10%);
  border-radius: 6px;
  box-shadow: 0 4px 12px rgb(25 45 70 / 14%);
  backdrop-filter: blur(8px);
}

.map-toolbar__btn {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 1px;
  width: 30px;
  height: 30px;
  padding: 4px 0;
  /* WHY #333：与原生控件图标同色（maplibre 的 ctrl-icon SVG fill 为 #333） */
  color: #333;
  background: transparent;
  border: 0;
  border-radius: 2px;
  cursor: pointer;
  user-select: none;
  transition:
    color 0.18s ease,
    background-color 0.18s ease,
    box-shadow 0.18s ease;
}

.map-toolbar__btn:hover {
  /* WHY 与原生控件 hover 一致：maplibre 的 .maplibregl-ctrl button:hover 为 5% 黑，
     原蓝色强调 hover 与默认控件并排时风格割裂；蓝色仅保留给 is-active 开关态。 */
  background: rgb(0 0 0 / 5%);
}

.map-toolbar__btn:active {
  background: rgb(0 0 0 / 8%);
}

.map-toolbar__btn.is-active,
.map-toolbar__btn.is-active:hover {
  color: #fff;
  background: #2563eb;
  box-shadow: 0 2px 6px rgb(37 99 235 / 32%);
}

.map-toolbar__btn:focus-visible {
  outline: 2px solid rgb(37 99 235 / 40%);
  outline-offset: 1px;
}

.map-toolbar__btn .el-icon {
  font-size: 16px;
}

.map-toolbar__btn--basemap {
  gap: 2px;
}

.map-toolbar__divider {
  height: 1px;
  margin: 3px 5px;
  background: rgb(31 55 84 / 12%);
}

.map-toolbar__option {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  font-size: 12px;
}

/* 缩略图与文字上下堆叠：缩略图在上，名称（含激活勾选）在下居中 */
.map-toolbar__option--stack {
  flex-direction: column;
  gap: 4px;
  align-items: center;
}

.map-toolbar__option-name {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  line-height: 1.1;
}

.map-toolbar__thumb {
  flex: none;
  width: 56px;
  height: 38px;
  border-radius: 3px;
  border: 1px solid rgb(31 55 84 / 15%);
  background: #f5f7fa;
  object-fit: cover;
}

.map-toolbar__option .el-icon {
  font-size: 13px;
  color: #2563eb;
}

:deep(.el-dropdown-menu__item) {
  padding: 6px 14px;
  font-size: 12px;
}

:deep(.el-dropdown-menu__item.is-active) {
  color: #2563eb;
  font-weight: 600;
  background: rgb(37 99 235 / 8%);
}

/* 底图面板横向排成一行：所有底图卡片并排，缩略图在上、名称在下 */
:deep(.map-toolbar__menu--horizontal) {
  display: flex;
  flex-direction: row;
  gap: 8px;
  padding: 10px 12px;
}

:deep(.map-toolbar__menu--horizontal .el-dropdown-menu__item) {
  padding: 0;
  line-height: normal;
  border-radius: 6px;
  border: 1px solid transparent;
}

:deep(.map-toolbar__menu--horizontal .el-dropdown-menu__item.is-active) {
  border-color: #2563eb;
  background: rgb(37 99 235 / 8%);
}
</style>

<!-- WHY 非 scoped：tooltip 由 el-popper 挂出，虽 teleported=false 留在地图子树内，
     但 popper 根节点不带本组件的 scoped 属性，scoped 选择器命中不到。
     工具栏是 30px 窄竖条，popper 若继承父级宽度约束会把中文逐字挤成竖排；
     width:max-content + white-space:nowrap 让它按文案实际宽度横向单行显示。 -->
<style lang="scss">
.map-toolbar-tooltip.el-popper {
  width: max-content;
  max-width: none;
  white-space: nowrap;
}
</style>
