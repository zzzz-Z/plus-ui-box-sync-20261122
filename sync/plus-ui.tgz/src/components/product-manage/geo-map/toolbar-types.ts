import type { Component } from 'vue';

/**
 * GeoMap 工具栏项类型
 *
 * WHY 拆成三种基本单元而非笼统的对象：
 * - divider 只是间距，不含交互；
 * - button 和 dropdown 的交互形态差异较大，强行合并会让渲染模板塞满 if-else；
 * - 用 discriminated union 让业务侧传入时由 TS 精确收敛到各自字段，避免传错字段静默失效。
 */

export interface ToolbarButtonItem {
  type: 'button';
  key: string;
  icon: Component;
  tooltip?: string;
  active?: boolean;
  onClick?: () => void;
}

export interface ToolbarDividerItem {
  type: 'divider';
  key: string;
}

export interface ToolbarDropdownItem {
  type: 'dropdown';
  key: string;
  icon: Component;
  tooltip?: string;
  options: { id: string; name: string; thumb?: string }[];
  value: string;
  onSelect: (id: string) => void;
  /** 下拉面板是否横向排列（底图缩略图卡片并排一行），默认竖向列表 */
  horizontal?: boolean;
}

export type ToolbarItem = ToolbarButtonItem | ToolbarDividerItem | ToolbarDropdownItem;
