import { bbox } from '@turf/turf';
import type { AllGeoJSON } from '@turf/turf';
import type { LayerSpecification, LngLatLike, SourceSpecification } from 'maplibre-gl';
import * as maplibregl from 'maplibre-gl';
import type { VNode } from 'vue';
import { render } from 'vue';

type MapboxMap = maplibregl.Map | undefined;

/**
 * 分布式 Omit：LayerSpecification 是联合类型，Omit 对联合类型不是分布式的，
 * 会先把各分支合并再删键，导致 filter/layout/paint 等分支独有属性丢失。
 * 用条件类型让每个分支单独 Omit，再交回来。
 */
type DistributiveOmit<T, K extends keyof any> = T extends any ? Omit<T, K> : never;

type LayerOption = DistributiveOmit<LayerSpecification, 'id' | 'source'> & {
  id?: string;
  source?: string;
};

/**
 * 地图 Hook：封装 maplibre-gl 的 source / layer / popup 管理与清理。
 *
 * 类型修正要点：
 * - createLayer.on 不再借用 Map['on'] 的 Parameters，改为显式 (eventName, callback)；
 * - events 显式声明 Map<string, (...args: any[]) => void>；
 * - addLayer 参数 as any，绕过联合类型 source 必需性推断；
 * - loadImage 回调显式判空 image；
 * - 去掉 popup 上多余的可选调用。
 */
export function useMapResource(mapInstance: Ref<MapboxMap> | ShallowRef<MapboxMap>) {
  const sources = new Map<string, ReturnType<typeof createSource>>();
  const popup = shallowRef<maplibregl.Popup | null>(null);

  /** 清理所有已创建的地图资源 */
  function clearAll() {
    sources.forEach((source) => source.clear());
    sources.clear();
  }

  /** 创建一个数据源，并返回其管理方法 */
  function createSource(sourceOptions: SourceSpecification) {
    const id = genId(sourceOptions.type);
    const layers = new Map<string, ReturnType<typeof createLayer>>();
    const source = { id, clear, remove, addLayer };

    mapInstance.value?.addSource(id, sourceOptions);
    sources.set(id, source);

    function addLayer(layerOptions: LayerOption, before?: string) {
      const layer = createLayer({ ...layerOptions, source: id } as any, before);
      layers.set(layer.id, layer);
      return { ...layer, addLayer };
    }

    function clear() {
      if (!mapInstance.value?.getSource(id)) return;
      layers.forEach((layer) => layer.remove());
      layers.clear();
      mapInstance.value?.removeSource(id);
      sources.delete(id);
    }

    function remove(layerId: string) {
      layers.get(layerId)?.remove();
      layers.delete(layerId);
    }

    return source;
  }

  /** 创建单个图层，支持事件绑定 */
  function createLayer(layerOptions: LayerOption, before?: string) {
    const id = genId(layerOptions.type);
    const events = new Map<string, (...args: any[]) => void>();
    const layer = { id, remove, on };

    mapInstance.value?.addLayer({ ...layerOptions, id } as any, before);

    function remove() {
      if (!mapInstance.value?.getLayer(id)) return;
      mapInstance.value?.removeLayer(id);
      events.forEach((callback, type) => {
        (mapInstance.value as any)?.off(type, id, callback);
      });
      events.clear();
    }

    function on(eventName: string, callback: (...args: any[]) => void) {
      (mapInstance.value as any)?.on(eventName, id, callback);
      events.set(eventName, callback);
      return layer;
    }

    return layer;
  }

  /** 创建带 Vue 渲染内容的 Popup */
  function createPopup(node: VNode, lngLat: LngLatLike) {
    popup.value?.remove();

    const div = document.createElement('div');

    render(node, div);

    const instance = new maplibregl.Popup({ offset: 12 }).setLngLat(lngLat).setDOMContent(div).addTo(mapInstance.value!);

    instance.on('close', () => {
      render(null, div);
      div.remove();
      popup.value = null;
    });

    popup.value = instance;
    return instance;
  }

  /** 加载并添加图像资源 */
  function loadImage(name: string, url: string) {
    if (mapInstance.value?.hasImage(name)) return;
    mapInstance.value?.loadImage(url);
  }

  /**
   * 聚焦到 GeoJSON 数据的包围盒。
   *
   * WHY 校验退化包围盒：业务侧几何可能缺失（bbox 全 0），此时 bbox 为零尺寸，
   * fitBounds 会把 zoom 拉到最小级别，maplibre 的 renderWorldCopies 会平铺出多份世界地图。
   * 这里直接跳过，保持当前相机不动。
   */
  function fitBounds(geoJsonData: AllGeoJSON) {
    const bboxValue = bbox(geoJsonData);
    if (!Array.isArray(bboxValue) || bboxValue.length < 4) return;
    const [minLng, minLat, maxLng, maxLat] = bboxValue as number[];
    if (![minLng, minLat, maxLng, maxLat].every((n) => Number.isFinite(n))) return;
    // 零尺寸（或退化到 0,0 附近）视为无效几何
    if (maxLng - minLng < 1e-6 && maxLat - minLat < 1e-6) return;
    const bounds = new maplibregl.LngLatBounds([minLng, minLat], [maxLng, maxLat]);
    mapInstance.value?.fitBounds(bounds);
  }

  return {
    mapInstance,
    popup,
    fitBounds,
    clearAll,
    createPopup,
    createSource,
    loadImage
  };
}

function genId(type?: string) {
  const id = Math.random().toString(36).substring(2, 15);
  return type ? `${type}-${id}` : id;
}
