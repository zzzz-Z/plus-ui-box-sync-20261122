import type { Map as MapLibreMap, StyleSpecification } from 'maplibre-gl';
import type { Ref } from 'vue';
import { computed, ref } from 'vue';
import { buildOfflineChinaStyle, LIBERTY_STYLE, POSITRON_STYLE } from './offline-basemap';
import { basemapThumbnail } from './basemap-thumbnail';

export interface BasemapOption {
  id: string;
  name: string;
  style: string | StyleSpecification;
  /** 底图缩略图（离线 SVG data URL），下拉列表里作视觉区分，缺省时由 basemapThumbnail 推断生成 */
  thumbnail?: string;
}

const BLANK_STYLE: StyleSpecification = {
  version: 8,
  sources: {},
  layers: [
    {
      id: 'background',
      type: 'background',
      paint: { 'background-color': '#f5f7fa' }
    }
  ]
};

/**
 * 内置离线底图：本地打包的矢量边界，零网络依赖，无网络也能渲染地理底图。
 * 任何地图（无论是否注入外部底图源）都应保证该底图始终可用，作为离线兜底。
 */
export const OFFLINE_BASEMAPS: BasemapOption[] = [
  { id: 'liberty', name: '标准', style: LIBERTY_STYLE, thumbnail: basemapThumbnail({ id: 'liberty', name: '标准', style: LIBERTY_STYLE }) },
  { id: 'positron', name: '浅色', style: POSITRON_STYLE, thumbnail: basemapThumbnail({ id: 'positron', name: '浅色', style: POSITRON_STYLE }) },
  { id: 'offline-china', name: '离线·中国', style: buildOfflineChinaStyle(), thumbnail: basemapThumbnail({ id: 'offline-china', name: '离线·中国', style: buildOfflineChinaStyle() }) },
  { id: 'blank', name: '空白', style: BLANK_STYLE, thumbnail: basemapThumbnail({ id: 'blank', name: '空白', style: BLANK_STYLE }) }
];

export const DEFAULT_BASEMAPS: BasemapOption[] = [
  // 默认即离线底图：无网络时首帧也能看到中国行政区划底图，而非空白
  ...OFFLINE_BASEMAPS
];

/**
 * 底图配置的最小形状（结构化类型，避免反向依赖业务侧类型定义）。
 * 只关心「能渲染成底图」所需的字段：XYZ/WMTS 用 url 模板，WMS 额外需要图层与格式。
 */
export interface BasemapLike {
  uid: string;
  name: string;
  type: 'xyz' | 'wms' | 'wmts' | 'offline';
  url: string;
  tileSize?: number;
  wmsLayers?: string;
  wmsStyles?: string;
  wmsFormat?: string;
  wmsVersion?: string;
  wmsTransparent?: boolean;
}

/** 瓦片 URL 模板识别：含 {z} 才走栅格源，否则视为外部 style URL 直接透传 */
const TILE_TEMPLATE_PATTERN = /\{z\}/;

/** 构造单栅格图层的 style 骨架：所有栅格底图共用 */
function rasterStyle(tiles: string[], tileSize: number): StyleSpecification {
  return {
    version: 8,
    sources: { basemap: { type: 'raster', tiles, tileSize } },
    layers: [{ id: 'basemap', type: 'raster', source: 'basemap' }]
  };
}

/**
 * WMS GetMap 瓦片地址。
 * CONSTRAINT bbox 用 maplibre 的 {bbox-epsg-3857} 占位符 —— 由地图引擎按瓦片范围替换，
 * 不能经 URLSearchParams 编码（花括号会被转义为 %7B / %7D 导致模板失配）。
 */
function wmsTilesOf(basemap: BasemapLike, tileSize: number): string {
  const query = [
    'service=WMS',
    'request=GetMap',
    `version=${encodeURIComponent(basemap.wmsVersion ?? '1.1.1')}`,
    `layers=${encodeURIComponent(basemap.wmsLayers ?? '')}`,
    `styles=${encodeURIComponent(basemap.wmsStyles ?? '')}`,
    `format=${encodeURIComponent(basemap.wmsFormat ?? 'image/png')}`,
    `transparent=${basemap.wmsTransparent ?? true}`,
    `width=${tileSize}`,
    `height=${tileSize}`,
    'srs=EPSG:3857',
    'bbox={bbox-epsg-3857}'
  ].join('&');
  return basemap.url + (basemap.url.includes('?') ? '&' : '?') + query;
}

/**
 * 业务底图配置 → maplibre 底图选项。
 * - xyz / wmts 且 url 含 {z} → 栅格瓦片源；
 * - wms → 拼 GetMap 参数后走栅格源；
 * - 其余（url 为 style 地址）→ 直接透传，交给 maplibre 解析。
 * 后一条兼容历史 seed：positron / liberty 存的是 style 地址而非瓦片模板。
 */
export function basemapToOption(basemap: BasemapLike): BasemapOption {
  const tileSize = basemap.tileSize ?? 256;
  const isTileTemplate = TILE_TEMPLATE_PATTERN.test(basemap.url);
  let style: string | StyleSpecification = basemap.url;
  if (basemap.type === 'offline') {
    // 离线底图：本地矢量源，无需联网；url 字段在此类型下无意义
    style = buildOfflineChinaStyle();
  } else if (basemap.type === 'wms') {
    style = rasterStyle([wmsTilesOf(basemap, tileSize)], tileSize);
  } else if (basemap.type === 'wmts' || isTileTemplate) {
    style = rasterStyle([basemap.url], tileSize);
  }
  return { id: basemap.uid, name: basemap.name, style, thumbnail: basemapThumbnail({ id: basemap.uid, name: basemap.name, style }) };
}

export interface UseBaseMapsOptions {
  /**
   * 底图源；未传则用内置 DEFAULT_BASEMAPS。
   * WHY 支持外部注入：底图可由「系统管理 · 电子地图底图」配置（XYZ/WMS/WMTS）动态加载，
   * 或对接 qqpt 等第三方地图服务，不应把可用底图固化在组件内。
   */
  basemaps?: Ref<BasemapOption[]>;
  /** 底图 id 变化时回调（用于 v-model:basemap 双向绑定） */
  onUpdateBasemap?: (id: string) => void;
  /** 底图变化事件（业务可能对 update 与 change 做不同处理） */
  onBasemapChange?: (id: string) => void;
  /**
   * 底图 style.load 完成（首次加载 / 切换底图）后回调。
   * WHY 区分 kind：
   * - 'initial'：首次加载完成，业务侧 attach 图层即可；
   * - 'switch'：切换底图后 setStyle 会清空所有 source/layer，业务侧需 detach + attach。
   */
  onStyleLoad?: (map: MapLibreMap, kind: 'initial' | 'switch') => void;
}

/**
 * 底图切换 composable。
 *
 * 职责：默认底图列表、当前底图状态、底图切换（setStyle + style.load 回调）。
 * 不感知 3D 白膜 / 业务图层 / 绘制工具 —— 那些由 GeoMap 与业务侧处理。
 */
export function useBaseMaps(mapRef: Ref<MapLibreMap | undefined>, options: UseBaseMapsOptions = {}) {
  const activeBasemap = ref('');

  /** 实际生效的底图源：外部注入优先，否则回落内置常量 */
  const source = computed<BasemapOption[]>(() => options.basemaps?.value ?? DEFAULT_BASEMAPS);

  /** 当前底图名称（工具栏下拉 tooltip 展示用） */
  const basemapName = computed(() => source.value.find((b) => b.id === activeBasemap.value)?.name ?? '');

  /** 当前底图配置（外部若需读取 style 等） */
  const currentBasemap = computed(() => source.value.find((b) => b.id === activeBasemap.value));

  /**
   * 切换到指定底图。
   * CONSTRAINT setStyle 会清空所有 source/layer（含业务图层），故必须在 style.load 之后再回调业务侧，
   * 让业务侧自行 detach + attach —— 本模块不负责图层重建。
   */
  function switchBasemap(id: string) {
    const item = source.value.find((b) => b.id === id);
    if (!item || id === activeBasemap.value) return;
    const map = mapRef.value;
    if (!map) return;

    activeBasemap.value = id;
    options.onUpdateBasemap?.(id);
    options.onBasemapChange?.(id);

    map.once('style.load', () => {
      if (!mapRef.value) return;
      options.onStyleLoad?.(mapRef.value, 'switch');
    });
    map.setStyle(item.style as any);
  }

  /**
   * 首帧调用：应用默认底图。
   * 地图初始化时挂的是「空 style」，source 数为 0 —— 此时需要 setStyle 才会真正加载底图；
   * 若地图已挂过 style，则直接触发 onStyleLoad，避免重复 setStyle 造成底图闪烁。
   */
  function applyInitialBasemap() {
    const map = mapRef.value;
    if (!map) return;
    const list = source.value;
    const target = list.find((b) => b.id === activeBasemap.value) ?? list[0];
    if (!target) {
      options.onStyleLoad?.(map, 'initial');
      return;
    }
    activeBasemap.value = target.id;
    const currentSources = Object.keys(map.getStyle()?.sources ?? {});
    const isBlank = currentSources.length === 0;
    if (isBlank && target.style) {
      map.once('style.load', () => {
        if (!mapRef.value) return;
        options.onStyleLoad?.(mapRef.value, 'initial');
      });
      map.setStyle(target.style as any);
    } else {
      options.onStyleLoad?.(map, 'initial');
    }
  }

  return {
    DEFAULT_BASEMAPS,
    basemaps: source,
    activeBasemap,
    basemapName,
    currentBasemap,
    switchBasemap,
    applyInitialBasemap
  };
}
