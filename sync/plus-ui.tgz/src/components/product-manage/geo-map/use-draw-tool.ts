import type { Map as MapLibreMap } from 'maplibre-gl';
import { circle as turfCircle } from '@turf/turf';

// [why] @turf/turf 不 re-export Feature/Position 等 GeoJSON 类型别名——它们源自 @types/geojson 的
// 全局命名空间 GeoJSON.*，而 'geojson' 模块名未在项目内显式声明（无 @types/geojson 的模块声明）。
// 本引擎改用本地宽松别名，类型安全由调用侧（GeoMap / 业务地图）保证。
type Position = [number, number];
interface Geometry {
  type: string;
  coordinates?: any;
  [key: string]: any;
}
interface Polygon extends Geometry {
  type: 'Polygon';
  coordinates: Position[][];
}
interface Feature<G = Geometry> {
  type: 'Feature';
  geometry: G;
  properties: Record<string, any>;
}
interface FeatureCollection {
  type: 'FeatureCollection';
  features: Feature[];
}

/**
 * 地图绘制引擎（折线 / 矩形 / 圆 / 多边形）
 *
 * 独立 composable：GeoMap 通过 props.drawTool 驱动 start(tool)，绘制完成后回调 onComplete。
 * 内部维护预览图层（line + fill），使用固定前缀 id，与业务图层互不干扰。
 * 交互约束：
 * - polyline / polygon：单击加点，双击结束；Esc 取消
 * - rectangle / circle：按下起、拖动、松开定；Esc 取消
 * 完成时 stop() 会清预览并保留最终图形，由调用方决定是否继续保留（再 start 时自动清空）。
 */

export type DrawToolType = 'polyline' | 'rectangle' | 'circle' | 'polygon';

interface UseDrawToolOptions {
  getMap: () => MapLibreMap | undefined;
  onComplete: (feature: Feature<Geometry>) => void;
  /** 预览几何更新回调（每次点/移动/释放触发）；传 null 表示已清空 */
  onUpdate?: (feature: Feature<Geometry> | null) => void;
}

const EMPTY_FC: FeatureCollection = { type: 'FeatureCollection', features: [] };

export function useDrawTool(options: UseDrawToolOptions) {
  const suffix = Math.random().toString(36).slice(2, 8);
  const sourceId = `__draw_src_${suffix}`;
  const lineLayerId = `__draw_line_${suffix}`;
  const fillLayerId = `__draw_fill_${suffix}`;

  let active = false;
  let tool: DrawToolType = 'polyline';
  let points: Position[] = [];
  let hover: Position | null = null;
  let dragging = false;
  let origin: Position | null = null;

  function ensureLayers() {
    const map = options.getMap();
    if (!map || map.getSource(sourceId)) return;
    // 本地 FeatureCollection 与 GeoJSON.FeatureCollection 不严格兼容；此处收口 as any，内部数据流保持自有类型
    map.addSource(sourceId, { type: 'geojson', data: EMPTY_FC as any });
    map.addLayer({
      id: fillLayerId,
      type: 'fill',
      source: sourceId,
      filter: ['==', ['geometry-type'], 'Polygon'],
      paint: { 'fill-color': '#2563eb', 'fill-opacity': 0.15 }
    });
    map.addLayer({
      id: lineLayerId,
      type: 'line',
      source: sourceId,
      paint: {
        'line-color': '#2563eb',
        'line-width': 2,
        'line-dasharray': [2, 1.5]
      }
    });
  }

  function updateData(data: FeatureCollection) {
    const map = options.getMap();
    const src = map?.getSource(sourceId) as any;
    src?.setData?.(data as any);
  }

  /** 依据 tool + 已有点集计算当前几何（不含最终 Feature 包装） */
  function currentGeometry(): Geometry | null {
    if (tool === 'polyline') {
      if (points.length < 2) return null;
      const pts = hover ? [...points, hover] : points;
      return { type: 'LineString', coordinates: pts };
    }
    if (tool === 'polygon') {
      if (points.length < 2) return null;
      const pts = hover ? [...points, hover] : points;
      const first = pts[0];
      const closed = [...pts, first];
      return { type: 'Polygon', coordinates: [closed] };
    }
    if (tool === 'rectangle') {
      if (points.length < 2) return null;
      const [a, b] = points;
      const minX = Math.min(a[0], b[0]);
      const minY = Math.min(a[1], b[1]);
      const maxX = Math.max(a[0], b[0]);
      const maxY = Math.max(a[1], b[1]);
      return {
        type: 'Polygon',
        coordinates: [
          [
            [minX, minY],
            [maxX, minY],
            [maxX, maxY],
            [minX, maxY],
            [minX, minY]
          ]
        ]
      };
    }
    if (tool === 'circle') {
      if (!origin || !hover) return null;
      const radiusKm = haversineKm(origin, hover);
      const circleFeature: any = (turfCircle as any)(origin, radiusKm, { units: 'kilometers', steps: 64 });
      return circleFeature.geometry as Polygon;
    }
    return null;
  }

  /** 两经纬度点间距离（km），用于圆半径 */
  function haversineKm(a: Position, b: Position) {
    const R = 6371;
    const toRad = (d: number) => (d * Math.PI) / 180;
    const dLat = toRad(b[1] - a[1]);
    const dLng = toRad(b[0] - a[0]);
    const lat1 = toRad(a[1]);
    const lat2 = toRad(b[1]);
    const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
    return 2 * R * Math.asin(Math.sqrt(h));
  }

  function refreshPreview() {
    const geom = currentGeometry();
    const feature = geom ? { type: 'Feature' as const, geometry: geom, properties: {} } : null;
    updateData({ type: 'FeatureCollection', features: feature ? [feature] : [] });
    options.onUpdate?.(feature as Feature<Geometry> | null);
  }

  function onMouseDown(e: any) {
    if (!active) return;
    const p: Position = [e.lngLat.lng, e.lngLat.lat];
    if (tool === 'polyline' || tool === 'polygon') {
      points.push(p);
      hover = p;
      refreshPreview();
      return;
    }
    dragging = true;
    origin = p;
    points = [p, p];
    hover = p;
    options.getMap()?.dragPan.disable();
    refreshPreview();
  }

  function onMouseMove(e: any) {
    if (!active) return;
    const p: Position = [e.lngLat.lng, e.lngLat.lat];
    if ((tool === 'polyline' || tool === 'polygon') && points.length > 0) {
      hover = p;
      refreshPreview();
      return;
    }
    if (dragging && origin) {
      points = [origin, p];
      hover = p;
      refreshPreview();
    }
  }

  function onMouseUp() {
    if (!active || !dragging) return;
    dragging = false;
    options.getMap()?.dragPan.enable();
    finish();
  }

  function onDblClick() {
    if (!active) return;
    if (tool === 'polyline' || tool === 'polygon') {
      if (points.length > 1) points.pop();
      finish();
    }
  }

  function onKeyDown(e: KeyboardEvent) {
    if (e.key === 'Escape') cancel();
  }

  function finish() {
    const geom = currentGeometry();
    // [why] polyline/polygon 双击前会 pop 掉多余点，数据源仍是上一次 hover 版本；
    // 刷新一次保证地图上保留的图形与回调几何一致。
    refreshPreview();
    stop();
    if (geom) options.onComplete({ type: 'Feature', geometry: geom, properties: {} });
  }

  function start(nextTool: DrawToolType) {
    stop();
    tool = nextTool;
    points = [];
    hover = null;
    origin = null;
    dragging = false;
    const map = options.getMap();
    if (!map) return;
    ensureLayers();
    updateData(EMPTY_FC);
    map.getCanvas().style.cursor = 'crosshair';
    map.on('mousedown', onMouseDown);
    map.on('mousemove', onMouseMove);
    map.on('mouseup', onMouseUp);
    map.on('dblclick', onDblClick);
    window.addEventListener('keydown', onKeyDown);
    active = true;
  }

  function stop() {
    const map = options.getMap();
    if (map) {
      map.off('mousedown', onMouseDown);
      map.off('mousemove', onMouseMove);
      map.off('mouseup', onMouseUp);
      map.off('dblclick', onDblClick);
      map.dragPan.enable();
      map.getCanvas().style.cursor = '';
    }
    window.removeEventListener('keydown', onKeyDown);
    // [why] stop 只负责停止交互，不动数据源；保留图形由 stop 语义保证。
    // 需要擦除请走 cancel()（Esc 场景）。start() 内部会显式 updateData(空) 开始新一轮。
    active = false;
    points = [];
    hover = null;
    origin = null;
    dragging = false;
  }

  /** 取消绘制：停止交互并清空图形（Esc 场景） */
  function cancel() {
    stop();
    updateData(EMPTY_FC);
  }

  /** 仅清空图形数据，不动监听（外部重置按钮可用） */
  function clear() {
    updateData(EMPTY_FC);
  }

  return { start, stop, cancel, clear };
}
