import { ref } from 'vue';
import type { Map as MapLibreMap } from 'maplibre-gl';
import type { LayerSpecification } from 'maplibre-gl';

/**
 * 图层管理（可见性 / 透明度）
 *
 * 参考 maplibre-gl-layer-control：扫描当前 style 中的图层，按类型映射到正确的 paint 属性，
 * 避免统一写 fill-opacity 导致线/点/raster 图层透明度失效。
 *
 * 约束：
 * - 只暴露 maplibre 原生图层；业务侧 deck.gl 等自定义图层不在此列（需各自接入）。
 * - 底图（type === 'background' / 'raster' 且 id 含 basemap）默认纳入「背景」分组。
 */

/** 图层类型 → 不透明度 paint 属性；未列出的类型不支持透明度控制 */
const OPACITY_KEY: Record<string, string> = {
  fill: 'fill-opacity',
  line: 'line-opacity',
  circle: 'circle-opacity',
  symbol: 'icon-opacity',
  raster: 'raster-opacity',
  'fill-extrusion': 'fill-extrusion-opacity',
  heatmap: 'heatmap-opacity'
};

export interface LayerState {
  id: string;
  type: string;
  /** 图层类型映射到的不透明度属性；空串表示不支持透明度控制 */
  opacityKey: string;
  visible: boolean;
  opacity: number;
  /** 最小可见缩放级别（zoom 低于此值时图层不渲染）；maplibre 默认 0 */
  minzoom: number;
  /** 最大可见缩放级别；setLayerZoomRange 需成对传入，故一并读出 */
  maxzoom: number;
  /** 是否为底图（background/raster 且 id 含 basemap），用于分组 */
  isBasemap: boolean;
}

/** 从 layer 规范读取初始不透明度（缺失时按 1 处理） */
function readOpacity(layer: LayerSpecification, key: string): number {
  const paint = (layer as any).paint ?? {};
  const value = paint[key];
  return typeof value === 'number' ? value : 1;
}

/** 从 layer 规范读取初始可见性（layout.visibility === 'none' 视为隐藏） */
function readVisible(layer: LayerSpecification): boolean {
  return (layer as any).layout?.visibility !== 'none';
}

function toState(layer: LayerSpecification): LayerState {
  const opacityKey = OPACITY_KEY[layer.type] ?? '';
  return {
    id: layer.id,
    type: layer.type,
    opacityKey,
    visible: readVisible(layer),
    opacity: opacityKey ? readOpacity(layer, opacityKey) : 1,
    minzoom: typeof layer.minzoom === 'number' ? layer.minzoom : 0,
    maxzoom: typeof layer.maxzoom === 'number' ? layer.maxzoom : 24,
    isBasemap: layer.type === 'background' || (layer.type === 'raster' && /basemap|base/i.test(layer.id))
  };
}

export function useLayerManager(getMap: () => MapLibreMap | undefined) {
  const layers = ref<LayerState[]>([]);

  /** 重新扫描当前 style 的图层；底图切换后需重调（style.load 已换新） */
  function refresh() {
    const map = getMap();
    if (!map) return;
    const style = map.getStyle();
    const list: LayerState[] = [];
    for (const layer of style?.layers ?? []) {
      list.push(toState(layer as LayerSpecification));
    }
    layers.value = list;
  }

  function find(id: string): LayerState | undefined {
    return layers.value.find((item) => item.id === id);
  }

  /** 切换图层可见性（同步 layout.visibility） */
  function toggle(id: string) {
    const map = getMap();
    const state = find(id);
    if (!map || !state) return;
    const next = !state.visible;
    map.setLayoutProperty(id, 'visibility', next ? 'visible' : 'none');
    state.visible = next;
  }

  /** 设置图层不透明度（仅对该类型支持时才生效）；value 范围 [0, 1] */
  function setOpacity(id: string, value: number) {
    const map = getMap();
    const state = find(id);
    if (!map || !state || !state.opacityKey) return;
    const clamped = Math.max(0, Math.min(1, value));
    map.setPaintProperty(id, state.opacityKey, clamped);
    state.opacity = clamped;
  }

  /**
   * 设置图层最小可见缩放级别。
   * WHY 用 setLayerZoomRange：maplibre 的 minzoom 是构造期属性，运行时改必须走该方法，
   * 且 maxzoom 需成对传入，故读出 state.maxzoom 原值回填。
   */
  function setMinzoom(id: string, value: number) {
    const map = getMap();
    const state = find(id);
    if (!map || !state) return;
    const next = Math.max(0, Math.min(state.maxzoom, Math.round(value)));
    map.setLayerZoomRange(id, next, state.maxzoom);
    state.minzoom = next;
  }

  return { layers, refresh, toggle, setOpacity, setMinzoom };
}
