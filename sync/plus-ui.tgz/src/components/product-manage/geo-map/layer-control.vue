<script setup lang="ts">
import { Close, Refresh } from '@element-plus/icons-vue';
import type { LayerState } from './use-layer-manager';

/**
 * 图层管理面板（可见性 + 透明度）
 *
 * 纯展示：图层状态由 useLayerManager 维护，本组件只派发 toggle / setOpacity / refresh / close。
 * 参考 maplibre-gl-layer-control 的交互：每行一个复选开关 + 透明度滑块，底图与业务图层同列。
 */
defineProps<{ layers: LayerState[] }>();

const emit = defineEmits<{
  toggle: [id: string];
  setOpacity: [id: string, value: number];
  setMinzoom: [id: string, value: number];
  refresh: [];
  close: [];
}>();
</script>

<template>
  <div class="layer-panel">
    <div class="layer-panel__head">
      <span class="layer-panel__title">图层</span>
      <button type="button" class="layer-panel__icon" aria-label="刷新图层" @click="emit('refresh')">
        <el-icon><Refresh /></el-icon>
      </button>
      <button type="button" class="layer-panel__icon" aria-label="关闭" @click="emit('close')">
        <el-icon><Close /></el-icon>
      </button>
    </div>

    <div v-if="!layers.length" class="layer-panel__empty">暂无可管理图层</div>

    <ul v-else class="layer-panel__list">
      <li v-for="item in layers" :key="item.id" class="layer-panel__row">
        <el-checkbox :model-value="item.visible" @change="() => emit('toggle', item.id)" />
        <div class="layer-panel__meta">
          <span class="layer-panel__name" :title="item.id">{{ item.id }}</span>
          <el-slider
            v-if="item.opacityKey"
            class="layer-panel__slider"
            :model-value="item.opacity"
            :min="0"
            :max="1"
            :step="0.05"
            size="small"
            :show-tooltip="false"
            @update:model-value="(v) => emit('setOpacity', item.id, Number(v))"
          />
          <div class="layer-panel__zoom">
            <span class="layer-panel__zoom-label">最小缩放</span>
            <el-input-number
              class="layer-panel__zoom-input"
              :model-value="item.minzoom"
              :min="0"
              :max="item.maxzoom"
              :step="1"
              size="small"
              controls-position="right"
              @update:model-value="(v) => emit('setMinzoom', item.id, Number(v ?? 0))"
            />
          </div>
        </div>
      </li>
    </ul>
  </div>
</template>

<style scoped lang="scss">
.layer-panel {
  position: absolute;
  top: 6px;
  right: 46px;
  z-index: 7;
  display: flex;
  flex-direction: column;
  width: 240px;
  max-height: calc(100% - 24px);
  padding: 10px 12px;
  overflow: hidden;
  background: rgb(255 255 255 / 94%);
  border: 1px solid rgb(31 55 84 / 10%);
  border-radius: 8px;
  box-shadow: 0 6px 18px rgb(25 45 70 / 14%);
  backdrop-filter: blur(8px);
}

.layer-panel__head {
  display: flex;
  align-items: center;
  gap: 4px;
  padding-bottom: 8px;
  margin-bottom: 6px;
  border-bottom: 1px solid rgb(31 55 84 / 8%);
}

.layer-panel__title {
  flex: 1;
  color: #172b4d;
  font-size: 13px;
  font-weight: 600;
}

.layer-panel__icon {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 22px;
  height: 22px;
  color: #728096;
  background: transparent;
  border: 0;
  border-radius: 4px;
  cursor: pointer;
}

.layer-panel__icon:hover {
  color: #1d4ed8;
  background: rgb(37 99 235 / 10%);
}

.layer-panel__empty {
  padding: 8px 0;
  color: var(--el-text-color-secondary);
  font-size: 12px;
  text-align: center;
}

.layer-panel__list {
  margin: 0;
  padding: 0;
  overflow-y: auto;
  list-style: none;
}

.layer-panel__row {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 4px 0;
}

.layer-panel__meta {
  display: flex;
  flex: 1;
  flex-direction: column;
  min-width: 0;
  gap: 2px;
}

.layer-panel__name {
  overflow: hidden;
  color: var(--el-text-color-regular);
  font-size: 12px;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.layer-panel__slider {
  margin: 0 2px;
}

.layer-panel__zoom {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-top: 2px;
}

.layer-panel__zoom-label {
  color: var(--el-text-color-secondary);
  font-size: 11px;
  white-space: nowrap;
}

.layer-panel__zoom-input {
  width: 84px;
}

:deep(.layer-panel__zoom-input .el-input__wrapper) {
  padding: 0 6px;
}

:deep(.layer-panel__slider .el-slider__runway) {
  height: 4px;
  margin: 6px 0;
}

:deep(.layer-panel__slider .el-slider__button) {
  width: 10px;
  height: 10px;
}
</style>
