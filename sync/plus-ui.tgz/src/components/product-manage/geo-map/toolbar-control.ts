import { createApp, h, ref, type App } from 'vue';
import type { IControl, Map as MapLibreMap, MapEventType } from 'maplibre-gl';
import MapToolbar from './map-toolbar.vue';
import type { ToolbarItem } from './toolbar-types';

/**
 * 工具栏控件对外抛出的自定义事件名。
 * 监听方式：map.on(TOOLBAR_COMMAND_EVENT, (e) => { e.kind / e.key / e.value })
 *
 * WHY 断言到 keyof MapEventType：maplibre 的 fire / on 只接受内置事件名，
 * 自定义事件名需断言后才能过类型检查（MapEventType 是 type 不是 interface，无法声明合并扩展）。
 */
export const TOOLBAR_COMMAND_EVENT = 'toolbar:command' as keyof MapEventType;

/**
 * toolbar:command 事件负载。
 * WHY 不叫 type：maplibre 的 Event 构造器先 extend(data) 再 this.type = 事件名，
 * payload 里的 type 会被事件名覆盖，必须换字段名。
 */
export interface ToolbarCommand {
  /** 触发源：button = 单击；dropdown = 下拉选择 */
  kind: 'button' | 'dropdown';
  /** 工具栏项 key（调用方定义，用于路由到具体动作） */
  key: string;
  /** 仅 dropdown 命中：被选中的 option id */
  value?: string;
}

export interface ToolbarControlOptions {
  /**
   * 取最新工具栏项数组。
   * WHY 用 getter 而非直接传数组：items 由调用方 computed 派生（底图名 / 3D 开关态 / 业务动态项），
   * 构造时取一次首帧值，之后由调用方 watch 后调 updateItems() 同步进控件。
   */
  getItems: () => ToolbarItem[];
}

/**
 * 地图工具栏自定义控件（maplibre IControl）
 *
 * WHY 从 Vue 浮层改为 map.addControl 引入：
 * - 挂载 / 卸载跟随地图生命周期（onAdd / onRemove），不再依赖外层 .geo-map 的绝对定位；
 * - removeControl 时卸载内部 Vue 实例，杜绝监听器与 DOM 残留；
 * - 交互统一转成地图自定义事件（map.fire），业务侧 map.on 即可监听，与 item.onClick 回调并存。
 *
 * WHY onAdd 内部仍用 Vue 渲染而非手写 DOM：工具栏含 el-tooltip / el-dropdown / el-icon，
 * 复用现有 MapToolbar 组件；onAdd 里 createApp 挂到控件容器，onRemove 里 unmount。
 */
export class MapToolbarControl implements IControl {
  private map?: MapLibreMap;
  private container?: HTMLDivElement;
  private app?: App;
  /** 驱动内部 Vue 重渲染的响应式 items */
  private items = ref<ToolbarItem[]>([]);

  constructor(private options: ToolbarControlOptions) {}

  onAdd(map: MapLibreMap): HTMLDivElement {
    this.map = map;
    this.container = document.createElement('div');
    // WHY 挂 maplibregl-ctrl 基类：角标容器（.maplibregl-ctrl-bottom-right）是 pointer-events:none，
    // 该基类重新打开交互并应用右下 10px 边距；定位与层级从此由 maplibre 接管。
    this.container.className = 'maplibregl-ctrl';

    // 首帧 items（后续变化走 updateItems）
    this.wrapItems(this.options.getItems());

    // Vue 根组件只做转发：items.value 变化时 render 自动重跑，无需手动操作 DOM
    this.app = createApp({
      setup: () => () => h(MapToolbar, { items: this.items.value })
    });
    this.app.mount(this.container);
    return this.container;
  }

  onRemove(): void {
    // 先卸载 Vue 实例：el-dropdown 的 popper 挂在 body 下，unmount 会连带清理
    this.app?.unmount();
    this.app = undefined;
    this.items.value = [];
    // WHY 必须自己摘：maplibre 的 removeControl 只调 onRemove，不会移除 onAdd 返回的元素
    this.container?.remove();
    this.container = undefined;
    this.map = undefined;
  }

  getDefaultPosition(): 'bottom-right' {
    return 'bottom-right';
  }

  /** 调用方 items computed 变化时同步进控件 */
  updateItems(next: ToolbarItem[]): void {
    this.wrapItems(next);
  }

  /**
   * WHY 包一层回调：控件把每次交互都 map.fire(TOOLBAR_COMMAND_EVENT) 抛出去，
   * 再调原始 onClick / onSelect —— 解耦监听（map.on）与直接回调两种用法并存。
   */
  private wrapItems(next: ToolbarItem[]) {
    this.items.value = next.map((item) => {
      if (item.type === 'button') {
        const onClick = item.onClick;
        return {
          ...item,
          onClick: () => {
            this.fireCommand({ kind: 'button', key: item.key });
            onClick?.();
          }
        };
      }
      if (item.type === 'dropdown') {
        const onSelect = item.onSelect;
        return {
          ...item,
          onSelect: (id: string) => {
            this.fireCommand({ kind: 'dropdown', key: item.key, value: id });
            onSelect?.(id);
          }
        };
      }
      return item;
    });
  }

  private fireCommand(command: ToolbarCommand) {
    // WHY 只在交互回调里 fire：onAdd 执行时地图刚就绪，构造期 fire 无人监听、事件必丢
    this.map?.fire(TOOLBAR_COMMAND_EVENT, command);
  }
}
