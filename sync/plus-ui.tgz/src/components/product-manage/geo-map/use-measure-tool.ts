import { ref, shallowRef } from 'vue';
import * as maplibregl from 'maplibre-gl';
import type { Map as MapLibreMap } from 'maplibre-gl';
import { area, length } from '@turf/turf';
import { useDrawTool } from './use-draw-tool';
import type { DrawToolType } from './use-draw-tool';

/**
 * 测量工具（折线测距 / 多边形、矩形、圆测面）
 *
 * 包装 useDrawTool：绘制过程中实时弹出测量气泡（长度或面积），完成后保留图形与气泡。
 * 参考 terra-draw / maplibre-gl-terradraw 的交互：绘制即测量，无需二次确认。
 *
 * 单位自适应：
 * - 长度 < 1 km 显示米，否则显示千米；
 * - 面积 < 0.01 km² 显示 m²，< 1 km² 显示公顷，否则显示 km²。
 */
export type MeasureToolType = 'polyline' | 'polygon' | 'rectangle' | 'circle';

interface UseMeasureToolOptions {
  getMap: () => MapLibreMap | undefined;
}

/** turf.length 默认返回千米；turf.area 默认返回平方米 —— 统一换算到 km / km² 再格式化 */
function formatLength(km: number): string {
  if (km < 1) return `${Math.round(km * 1000)} m`;
  return `${km.toFixed(2)} km`;
}

function formatArea(sqKm: number): string {
  if (sqKm < 0.01) return `${Math.round(sqKm * 1e6)} m²`;
  if (sqKm < 1) return `${(sqKm * 100).toFixed(2)} 公顷`;
  return `${sqKm.toFixed(2)} km²`;
}

/** 几何 → 测量文案；不支持的几何类型或中途不完整时返回空串 */
function measureText(feature: { geometry: { type: string; coordinates: any } } | null): string {
  if (!feature) return '';
  try {
    if (feature.geometry.type === 'LineString') {
      return formatLength(length(feature as any));
    }
    if (feature.geometry.type === 'Polygon') {
      return formatArea(area(feature as any) / 1e6);
    }
  } catch {
    /* 几何不完整时静默跳过（绘制途中可能出现） */
  }
  return '';
}

/** 几何定位点：折线取末点，多边形取首环中点 */
function anchorOf(feature: { geometry: { type: string; coordinates: any } }): [number, number] | null {
  const g = feature.geometry;
  if (g.type === 'LineString') return g.coordinates[g.coordinates.length - 1] ?? null;
  if (g.type === 'Polygon') {
    const ring = g.coordinates[0] ?? [];
    if (!ring.length) return null;
    return ring[Math.floor(ring.length / 2)];
  }
  return null;
}

export function useMeasureTool(options: UseMeasureToolOptions) {
  const popup = shallowRef<maplibregl.Popup | null>(null);
  const visible = ref(false);

  function ensurePopup(map: MapLibreMap) {
    if (!popup.value) {
      popup.value = new maplibregl.Popup({
        closeButton: false,
        closeOnClick: false,
        className: 'geo-map__measure-popup',
        offset: 14
      });
    }
    return popup.value;
  }

  function hide() {
    popup.value?.remove();
    visible.value = false;
  }

  const draw = useDrawTool({
    getMap: options.getMap,
    onUpdate: (feature) => {
      const map = options.getMap();
      if (!map || !feature) {
        hide();
        return;
      }
      const text = measureText(feature as any);
      const anchor = anchorOf(feature as any);
      if (!text || !anchor) {
        hide();
        return;
      }
      ensurePopup(map).setLngLat(anchor).setText(text).addTo(map);
      visible.value = true;
    },
    // 绘制完成时图形与气泡均保持（stop 语义已保留图形），无需额外动作
    onComplete: () => undefined
  });

  function start(tool: MeasureToolType) {
    draw.start(tool as DrawToolType);
  }

  function stop() {
    draw.stop();
  }

  function cancel() {
    draw.cancel();
    hide();
  }

  function clear() {
    draw.clear();
    hide();
  }

  return { start, stop, cancel, clear, hide, visible };
}
