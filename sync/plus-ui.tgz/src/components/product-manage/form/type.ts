import type { FormItemRule } from 'element-plus';

export {};

declare module 'vue' {
  interface ComponentCustomProps {
    /** Form 表单控件label */
    label?: string;
    /** Form 表单控件required */
    required?: boolean;
    span?: number;
    /** 表单控件的提示信息 */
    tooltip?: string;
    rule?: FormItemRule;
    validator?: FormItemRule['validator'];
  }
}
