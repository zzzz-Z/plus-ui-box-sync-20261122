<script setup lang="tsx">
import type { FormInstance, FormProps } from 'element-plus';
import { ElCol, ElFormItem, ElIcon, ElTooltip, formItemProps } from 'element-plus';
import type { ConcreteComponent, Slot, VNode } from 'vue';
import { cloneVNode, Comment, Fragment } from 'vue';
import { QuestionFilled } from '@element-plus/icons-vue';
import { isArray, isString, isUndefined } from 'lodash';

/**
 * 表单项配置接口
 */
interface FormItemOption extends Params {
  node?: VNode;
  render?: () => VNode;
  label?: string;
  tooltip?: string;
  span?: number;
  block?: boolean;
  card?: boolean;
  required?: boolean;
  rule?: any;
  validator?: (rule: any, value: any, callback: any) => void;
  options?: Array<{ label: string; value: any }>;
  data?: any[];
  dictType?: string;
  modelValue?: any;
}

type Props = Partial<FormProps> & {
  options?: FormItemOption[];
  span?: number;
  gutter?: number;
  readonly?: boolean;
};

const { readonly, showMessage = true, labelWidth = 'auto', span, gutter = 16, options, ...props } = defineProps<Props>();

const slots = defineSlots<Record<string, Slot>>();

const form = ref<FormInstance>();
const flexLayout = { xl: 8, lg: 8, md: 8, sm: 12, xs: 24 };

// 缓存插槽选项,避免重复计算
const cachedOptions = computed(() => (slots.default ? slotToOptions() : options));

/**
 * 根据表单项配置获取占位符文本
 * @param item 表单项配置对象
 * @returns 占位符文本
 */
function getPlaceholder(item: FormItemOption): string {
  const node = item.node || item.render?.();
  if (!node) return '';

  const componentName = (node.type as ConcreteComponent)?.name?.toLowerCase() || '';
  const prefix = componentName.includes('input') ? '请输入' : componentName ? '请选择' : '';
  const label = item.label || node.props?.label;

  return node.props?.placeholder || (prefix && label ? `${prefix}${label}` : '');
}

/**
 * 移除对象中值为 undefined 的属性
 *
 * @param obj {Params} - 输入的对象,其类型为 Params
 * @returns {Params} - 返回一个新的对象,其中不包含值为 undefined 的属性
 */
function removeUndefinedProps(obj: Params): Params {
  // 将对象转换为键值对数组,过滤掉值为 undefined 的键值对,再将其转换回对象
  return Object.fromEntries(Object.entries(obj).filter(([, value]) => value !== undefined));
}

/**
 * 从模型更新函数中提取属性路径
 * @param onUpdateModelValue 模型更新函数
 * @returns 属性路径字符串
 */
function extractPropPath(onUpdateModelValue: any): string {
  if (!onUpdateModelValue) return '';

  try {
    const modelValueString = onUpdateModelValue.toString();
    return modelValueString
      .split('=>')[1]
      .split('=')[0]
      .trim()
      .split('.')
      .filter((field: string) => field !== '$setup')
      .slice(1)
      .join('.');
  } catch {
    return '';
  }
}

/**
 * 递归从树结构中根据 value 查找节点
 * @param tree 树形数据数组
 * @param value 要查找的值
 * @returns 找到的节点对象，未找到返回 undefined
 */
function findNodeByValue(tree: any[], value: any) {
  const valueKey = 'value';
  const childrenKey = 'children';

  for (const node of tree) {
    if (node[valueKey] === value) {
      return node.label;
    }
    if (node[childrenKey]?.length) {
      return findNodeByValue(node[childrenKey], value);
    }
  }
  return undefined;
}

/**
 * 格式化表单项属性
 * @param item 表单项配置对象
 * @returns 格式化后的表单项属性
 */
function formatItemProps(item: FormItemOption) {
  const propsKeys = Object.keys(formItemProps);
  const _required = !isUndefined(item.required) && item.required !== false;

  // 提取属性路径
  const prop = extractPropPath((item as any)['onUpdate:modelValue']);

  // 构建验证规则
  const rules = readonly
    ? undefined
    : removeUndefinedProps({
        message: _required && !item.validator ? getPlaceholder(item) : undefined,
        required: _required,
        trigger: ['blur', 'change'],
        validator: item.validator,
        ...item.rule
      });

  // 合并表单项属性
  const itemProps: Params = { prop, rules };

  propsKeys.forEach((key) => {
    const v = (item as Params)[key];
    if (!isUndefined(v)) {
      itemProps[key] = v;
    }
  });

  return itemProps;
}

/**
 * 获取只读模式下的显示值
 * @param nodeName 节点名称
 * @param item 表单项配置
 * @returns 显示值
 */
function getReadonlyValue(nodeName: string, item: FormItemOption): string {
  const { options, data, modelValue } = item;

  if (nodeName === 'ElSelect' && options) {
    return options
      .filter((v) => (isArray(modelValue) ? modelValue.includes(v.value) : v.value === modelValue))
      .map((v) => v.label)
      .join('、');
  }

  if (nodeName === 'ElTreeSelect' && data) {
    return findNodeByValue(data, modelValue) || '';
  }

  return String(modelValue || '/');
}

/**
 * 渲染只读模式的节点
 * @param node VNode 节点
 * @param item 表单项配置
 * @returns 渲染后的节点
 */
function renderReadonlyNode(node: VNode, item: FormItemOption): VNode {
  const nodeName = (node.type as any)?.name;

  // CheckboxGroup 直接禁用
  if (nodeName === 'ElCheckboxGroup') {
    return cloneVNode(node, { disabled: true });
  }

  // 字典类型使用 Dict 组件
  if (item.dictType) {
    return <Dict type={item.dictType} value={item.modelValue} />;
  }

  // 其他类型显示文本
  const displayValue = getReadonlyValue(nodeName, item);
  return <span>{displayValue}</span>;
}

/**
 * 渲染节点函数,根据表单项配置渲染对应的组件节点
 * @param item 表单项配置对象
 * @returns 返回渲染后的节点
 */
function RenderNode(item: FormItemOption): VNode {
  const node = item.node || item.render?.();

  // 如果节点不存在,返回空
  if (!node) return <></>;

  // 如果节点类型是字符串(原生节点如 div span),则返回节点本身
  if (isString(node.type)) {
    return node;
  }

  // 渲染只读模式(查看详情时渲染为对应的文本节点)
  if (readonly) {
    return renderReadonlyNode(node, item);
  }

  // 正常编辑模式,克隆节点并添加通用属性
  return cloneVNode(node, {
    filterable: true,
    placeholder: getPlaceholder(item)
  });
}

/**
 * 渲染表单项标签(带提示图标)
 * @param item 表单项配置
 * @returns 标签 VNode
 */
function renderLabel(item: FormItemOption) {
  return (
    <>
      {item.tooltip && (
        <ElTooltip effect="dark" popper-class="form-label-tooltip" content={item.tooltip} placement="top" raw-content>
          <ElIcon class="form-label-help">
            <QuestionFilled />
          </ElIcon>
        </ElTooltip>
      )}
      {item.label}:
    </>
  );
}

/**
 * 渲染表单项
 * @param item 表单项配置对象
 * @returns 渲染后的表单项
 */
function RenderFormItem(item: FormItemOption) {
  const _span = item.span || span;
  const colProps = _span ? { span: _span } : flexLayout;

  // 如果节点本身就是 ElFormItem,直接返回
  const nodeType = item.node?.type as any;
  if (nodeType?.name === 'ElFormItem') {
    return <ElCol {...colProps}>{item.node}</ElCol>;
  }

  // 否则包装为 ElFormItem
  return (
    <ElCol {...colProps}>
      <ElFormItem
        {...formatItemProps(item)}
        v-slots={{
          label: item.label ? () => renderLabel(item) : null,
          default: () => <RenderNode {...item} />
        }}
      />
    </ElCol>
  );
}

/**
 * 将插槽内容转换为表单项选项数组
 * 此函数用于处理默认插槽中的节点,过滤掉注释节点,并将剩余节点的属性和渲染方法转换为 FormItemOption 对象
 * @param slots 插槽对象
 * @returns 表单项选项数组
 */
function slotToOptions(slotsObj = slots): FormItemOption[] {
  const defaultSlot = slotsObj.default?.();
  if (!defaultSlot) return [];

  return defaultSlot
    .flatMap((node) => (node.type === Fragment ? node.children : node))
    .filter((node: any) => node && node.type !== Comment)
    .map((node: any) => ({
      node,
      ...node.props,
      block: node.props?.block === true || node.props?.block === '',
      card: node.type?.name === 'ElCard',
      render: () => node
    }));
}

defineExpose(forwardRef(form));
</script>

<template>
  <ElForm ref="form" class="i-form" :show-message :label-width v-bind="props">
    <!-- 行组件，设置栏间距 -->
    <ElRow :gutter="gutter">
      <!-- 遍历表单项配置，生成表单项 -->
      <template v-for="(item, index) in cachedOptions" :key="index">
        <RenderNode v-if="item.block" v-bind="item" />
        <RenderFormItem v-else v-bind="item" />
      </template>
    </ElRow>
  </ElForm>
</template>

<style lang="scss">
.form-label-tooltip {
  max-width: 500px;
}

.i-form {
  .el-form-item {
    margin-bottom: 16px !important;
    width: 100%;
    margin-right: 0;
  }

  .el-form-item .el-form-item__error {
    position: absolute;
  }
  .el-form-item__label {
    display: flex;
    align-items: center;
    justify-content: initial;

    .form-label-help {
      margin-right: 4px;
      color: var(--el-text-color-placeholder);
      cursor: help;

      &:hover {
        color: var(--el-color-primary);
      }
    }
  }

  .el-input-number,
  .el-cascader,
  .el-date-editor {
    width: 100%;
  }

  .el-input-number .el-input__inner {
    text-align: left !important;
  }

  .el-card {
    /** 解决 el-card 中下拉框展示不全问题 */
    overflow: inherit;
  }

  :deep(.el-form--inline) {
    .el-form-item {
      margin-right: 0;
    }
  }
}
</style>
