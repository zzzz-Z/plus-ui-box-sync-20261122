<template>
  <div class="dict-tag-wrap">
    <span v-for="item in matchedItems" :key="item.value" class="dict-pill" :style="{ color: colorOf(item.elTagType) }">
      <!-- <span class="dict-pill__dot"></span> -->
      <span class="dict-pill__text">{{ item.label }}</span>
    </span>
    <span v-if="unmatch && showValue" class="dict-pill-unmatch">{{ unmatchArray }}</span>
  </div>
</template>

<script setup lang="ts">
interface Props {
  options: Array<DictDataOption>;
  value: number | string | Array<number | string>;
  showValue?: boolean;
  separator?: string;
}
const props = withDefaults(defineProps<Props>(), {
  showValue: true,
  separator: ','
});

// type → 颜色映射
const COLOR_MAP: Record<string, string> = {
  primary: '#00b6da',
  success: '#60b45e',
  warning: '#ec9400',
  info: '#999999',
  danger: '#d02729',
  default: '#999999'
};
const colorOf = (type?: string) => COLOR_MAP[type || 'default'] || COLOR_MAP.default;

const values = computed(() => {
  if (props.value === '' || props.value === null || typeof props.value === 'undefined') return [];
  if (typeof props.value === 'number' || typeof props.value === 'boolean') return [props.value];
  return Array.isArray(props.value) ? props.value.map((item) => '' + item) : String(props.value).split(props.separator);
});

// 匹配上的 options 项（按 value 命中）
const matchedItems = computed(() => {
  if (!props.options?.length) return [];
  return props.options.filter((item) => values.value.some((val) => val == item.value));
});

const unmatch = computed(() => {
  if (!props.options?.length || props.value === '' || props.value === null || typeof props.value === 'undefined') return false;
  return values.value.some((item) => !props.options.some((v) => v.value == item));
});

const unmatchArray = computed(() => {
  const arr: Array<string | number> = [];
  if (props.value !== '' && props.value !== null && typeof props.value !== 'undefined') {
    values.value.forEach((item) => {
      if (!props.options.some((v) => v.value === item)) arr.push(item);
    });
  }
  return arr.length ? arr.join(' ') : '';
});
</script>

<style lang="scss" scoped>
.dict-tag-wrap {
  display: inline-flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 6px;
}

.dict-pill {
  display: inline-flex;
  align-items: center;
  height: 34px;
  padding: 0 10px;
  border: 1px solid currentColor;
  border-radius: 20px;
  font-size: 12px;
  line-height: 1;
  gap: 6px;
  background-color: transparent;

  &__dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background-color: currentColor;
    flex-shrink: 0;
  }
}

.dict-pill-unmatch {
  font-size: 12px;
  color: #909399;
}
</style>
