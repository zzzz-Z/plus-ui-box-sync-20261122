<template>
  <div class="page-header">
    <span class="page-header__bar"></span>
    <span class="page-header__title">{{ displayTitle }}</span>
    <slot name="extra" />
  </div>
</template>

<script lang="ts" setup>
import { useRoute } from 'vue-router';

const props = defineProps<{
  /** 显式指定标题；不传则自动取当前路由的 meta.title（降级到 route.name） */
  title?: string;
}>();

const route = useRoute();

const displayTitle = computed(() => props.title || (route.meta?.title as string) || (route.name as string) || '');
</script>

<style lang="scss" scoped>
.page-header {
  position: relative;
  width: 100%;
  height: 44px;
  display: flex;
  align-items: center;
  /* 与下方内容固定 8px 间隔 */
  margin-bottom: 8px;
  box-sizing: border-box;
  /* 浅色模式：标题条用背景图（1605x48，宽度自适应拉伸贴满）；
     图片底部自带一条分隔线，所以不再额外画 border-bottom，避免双线 */
  background-image: url('../../assets/images/大标题背景.png');
  background-repeat: no-repeat;
  background-size: 100% 100%;

  &__bar {
    width: 2px;
    height: 16px;
    margin-left: 24px;
    border-radius: 2px;
    background: #2d68e8;
  }

  &__title {
    margin-left: 12px;
    font-size: 14px;
    font-weight: 590;
    /* 标题色跟随主题：浅色 #333（项目在 html:not(.dark) 里覆盖过），深色 #fff */
    color: var(--el-text-color-primary);
    line-height: 22px;
  }

  /* extra 插槽靠右 */
  &__extra,
  :slotted([slot='extra']) {
    margin-left: auto;
    margin-right: 24px;
  }
}

/* 暗色模式保持现状：不挂浅色底图，回到纯色底 + 细分隔线 */
html.dark .page-header {
  background-image: none;
  background-color: var(--el-bg-color);
  border-bottom: 1px solid var(--el-border-color);
}
</style>
