<template>
  <el-dropdown trigger="click" @command="handleLanguageChange">
    <div class="lang-select--style">
      <svg-icon icon-class="language" />
    </div>
    <template #dropdown>
      <el-dropdown-menu>
        <el-dropdown-item :disabled="appStore.language === 'zh_CN'" command="zh_CN"> 中文 </el-dropdown-item>
        <el-dropdown-item :disabled="appStore.language === 'en_US'" command="en_US"> English </el-dropdown-item>
      </el-dropdown-menu>
    </template>
  </el-dropdown>
</template>

<script setup lang="ts">
import i18n from '@/lang/index';
import { useAppStore } from '@/store/modules/app';
import SvgIcon from '@/components/SvgIcon/index.vue';

const appStore = useAppStore();

const handleLanguageChange = (lang: any) => {
  // 只写唯一真源：i18n.locale 与 Element Plus locale 均由 watch/computed 派生
  appStore.changeLanguage(lang);
  // 用 global.t 保证 toast 立即跟随刚切换到的语言（flush:sync watch 已同步更新 global.locale）
  ElMessage.success(i18n.global.t('common.switchLanguageSuccess'));
};
</script>

<style lang="scss" scoped>
.lang-select--style {
  font-size: 18px;
  line-height: 50px;
}
</style>
