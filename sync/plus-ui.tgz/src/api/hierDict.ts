import request from '@/utils/request';

/**
 * 通用层级字典（hierDict）
 *
 * 后端落位：ruoyi-task-manage / common / dict，表 t_hier_dict
 * 网关前缀必须带 /dolphinscheduler（断言 /dolphinscheduler/** + StripPrefix=1），
 * 少了这一层会被 catch-all 打到海豚返回 Jetty 404。
 */
export const HIER_DICT_BASE = '/dolphinscheduler/hierDict';

/**
 * 字典类型编码 → 中文名。
 *
 * 后端 `/hierDict/types` 只返回编码（如 GLOBAL_GEO_FEATURE），中文名在前端维护；
 * 新增字典类型时在这里补一条即可（界面会同步生效）。
 */
export const HIER_DICT_TYPE_LABELS: Record<string, string> = {
  GLOBAL_GEO_FEATURE: '基础地理信息要素编码'
};

/** 类型编码 → 中文名（未知类型原样返回编码，避免显示空白） */
export function hierDictTypeLabel(code?: string | null): string {
  if (!code) return '';
  return HIER_DICT_TYPE_LABELS[code] || code;
}

/** 类型编码 → 中文名（编码）——用于需要同时看到编码的展示场景 */
export function hierDictTypeLabelWithCode(code?: string | null): string {
  if (!code) return '';
  return HIER_DICT_TYPE_LABELS[code] ? `${HIER_DICT_TYPE_LABELS[code]}（${code}）` : code;
}

/** 层级字典节点（树/分页/详情共用） */
export interface HierDictNode {
  id: number;
  dictType: string;
  code: string;
  name: string;
  /** 0 表示顶级 */
  parentId: number;
  /** 1 大类 / 2 中类 / 3 小类 / 4 细类 */
  level: number;
  sort?: number;
  /** 0 正常 / 1 停用 */
  status?: string;
  remark?: string | null;
  createTime?: string | null;
  updateTime?: string | null;
  /** 树的子节点，叶子为 [] */
  children?: HierDictNode[];
}

/** 树查询参数 */
export interface HierDictTreeQuery {
  dictType: string;
  /** 传 0 只取正常项，不传取全部 */
  status?: string;
}

/** 分页查询参数 */
export interface HierDictListQuery {
  dictType: string;
  code?: string;
  name?: string;
  status?: string;
  pageNum: number;
  pageSize: number;
}

/** 新增/修改提交体 */
export interface HierDictBo {
  id?: number;
  dictType: string;
  code: string;
  name: string;
  parentId?: number;
  sort?: number;
  status?: string;
  remark?: string;
}

/** 树状结构（children 递归，后端已按 sort + code 排序） */
export function getHierDictTree(params: HierDictTreeQuery) {
  return request({
    url: `${HIER_DICT_BASE}/tree`,
    method: 'get',
    params
  });
}

/** 平铺分页（返回 TableDataInfo：裸 rows / total） */
export function getHierDictList(params: HierDictListQuery) {
  return request({
    url: `${HIER_DICT_BASE}/list`,
    method: 'get',
    params
  });
}

/** 已有字典类型列表 */
export function getHierDictTypes() {
  return request({
    url: `${HIER_DICT_BASE}/types`,
    method: 'get'
  });
}

/** 详情 */
export function getHierDictInfo(id: number | string) {
  return request({
    url: `${HIER_DICT_BASE}/${id}`,
    method: 'get'
  });
}

/** 新增（返回新 id） */
export function addHierDict(data: HierDictBo) {
  return request({
    url: HIER_DICT_BASE,
    method: 'post',
    data
  });
}

/** 修改（body 必带 id） */
export function updateHierDict(data: HierDictBo) {
  return request({
    url: HIER_DICT_BASE,
    method: 'put',
    data
  });
}

/** 删除（逻辑删，逗号分隔；存在下级会被拒绝） */
export function deleteHierDict(ids: number | string) {
  return request({
    url: `${HIER_DICT_BASE}/${ids}`,
    method: 'delete'
  });
}
