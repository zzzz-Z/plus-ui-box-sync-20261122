/**
 * 产品类型管理页面适配层
 *
 * 将真实产品类别接口（product-category-api.ts）适配为页面消费形状，
 * 对 product-type-manage/index.vue 与 edit.vue 保持与旧 Mock 门面 api.ts 相同的调用签名：
 *   - getProductTypeList(params) -> { code, message, data: { items, total } }
 *   - saveProductType(data)      -> { code, message, data }
 *   - deleteProductType(uid)     -> { code, message, data }
 *
 * 差异处理：
 *   1. GET 无服务端搜索参数 → 关键词在本地按 categoryName/categoryKey/description 递归裁剪树；
 *      items 为树形根节点数组（Table 自动识别 children 渲染树表）。
 *   2. POST/PATCH 不返回 categoryPath/modelCount，也不支持 sortOrder → 写后由页面 refresh() 重查；
 *      categoryKey 创建后不可改，更新时若与原值不同后端会拒绝（页面未提供修改入口，此处透传）。
 *   3. 根节点父级：页面传 undefined/null → 真实接口约定空字符串或省略表示根。
 */
import type { ProductCategory } from '../platform/category';
import { createProductCategory, deleteProductCategory, listProductCategories, updateProductCategory } from '../platform/category';

export interface ProductTypeListParams {
  categoryName?: string;
  keyword?: string;
  [key: string]: unknown;
}

export interface ProductTypePayload {
  categoryUid?: string;
  categoryName: string;
  categoryKey?: string;
  description?: string;
  parentCategoryUid?: string | null;
  /** 类别颜色，#RRGGBB 或空串表示未设置 */
  color?: string | null;
}

/** 递归裁剪：命中节点保留全部子级，未命中但有命中后代的节点仅保留命中分支 */
function pruneByKeyword(nodes: ProductCategory[], keyword: string): ProductCategory[] {
  const text = keyword.trim().toLowerCase();
  if (!text) return nodes;
  return nodes.reduce<ProductCategory[]>((kept, node) => {
    const children = pruneByKeyword(node.children ?? [], keyword);
    const hit = `${node.categoryName}${node.categoryKey ?? ''}${node.description ?? ''}`.toLowerCase().includes(text);
    if (hit || children.length) kept.push({ ...node, children: hit ? node.children : children });
    return kept;
  }, []);
}

/** 平铺列表按 parentCategoryUid 组树；根为 parentCategoryUid 为 null 或空串的项 */
function buildTree(flatList: ProductCategory[]): ProductCategory[] {
  const byUid = new Map<string, ProductCategory>();
  const roots: ProductCategory[] = [];
  for (const item of flatList) byUid.set(item.categoryUid, { ...item, children: [] });
  for (const item of flatList) {
    const node = byUid.get(item.categoryUid)!;
    const pid = item.parentCategoryUid;
    if (!pid || pid === '' || !byUid.has(pid)) {
      roots.push(node);
    } else {
      const parent = byUid.get(pid)!;
      (parent.children ??= []).push(node);
    }
  }
  return roots;
}

/** 产品类型列表：契约返回平铺 { items, total }，本地按 parentCategoryUid 组树 + 关键词裁剪，包成 Table 期望的 { items, total } */
export async function getProductTypeList(params: ProductTypeListParams = {}) {
  const res = await listProductCategories();
  const flat = (res.code === 0 ? (res.data?.items ?? []) : []) as unknown as ProductCategory[];
  const tree = buildTree(flat);
  const items = pruneByKeyword(tree, String(params.categoryName || params.keyword || ''));
  return { code: res.code, message: res.message, data: { items, total: items.length } };
}

/** 保存产品类型：有 categoryUid 走 PATCH，否则 POST 新建 */
export function saveProductType(data: ProductTypePayload) {
  const parentCategoryUid = data.parentCategoryUid ?? '';
  if (data.categoryUid) {
    return updateProductCategory(data.categoryUid, {
      categoryName: data.categoryName,
      categoryKey: data.categoryKey,
      parentCategoryUid,
      description: data.description ?? '',
      color: data.color ?? ''
    });
  }
  return createProductCategory({
    categoryName: data.categoryName,
    categoryKey: data.categoryKey ?? data.categoryName,
    parentCategoryUid,
    description: data.description ?? '',
    color: data.color ?? ''
  });
}

/** 转发颜色格式校验（供表单保存前预校验，错误文案与后端一致） */
export { validateCategoryColor } from '../platform/category';

/** 删除产品类型（逻辑删除，含全部后代；适配层已带 confirm:true） */
export function deleteProductType(categoryUid: string) {
  return deleteProductCategory(categoryUid);
}
