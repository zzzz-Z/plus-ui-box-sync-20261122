/**
 * 元数据记录适配层
 *
 * 把真实接口（统一查询 / 模型表选项 / 记录写入）适配成页面既有消费形状，
 * 让元数据浏览、更新、提取等面板不再读取 mock 数据。
 *
 * 返回口径与旧 mock 门面一致：{ code, data, message }，页面无需改动数据结构。
 */
import type { AxiosResponse } from 'axios';
import type { MetadataRecord } from '../types';
import { queryMetadataRecords } from '../platform/metadata-query';
import type { MetadataQueryItem } from '../types/platform';
import { listModelTableOptions as fetchModelTableOptions } from '../platform/model-tables';
import { updateMetadataRecord, withEditLock } from '../platform/metadata-records';

function ok<T>(data: T, message = 'success') {
  return { code: 0, data, message } as unknown as AxiosResponse<T>;
}

/** 真实接口单页上限：一次拉全量记录，供共享 store / 分析面板消费 */
const FULL_PAGE_SIZE = 200;

function text(value: unknown): string {
  if (value == null) return '';
  return String(value);
}

/** 真实接口时间可能是时间戳或 ISO 串；统一成 YYYY-MM-DD HH:mm:ss，供 .slice/.replace 消费 */
function toDateTime(value: unknown): string {
  if (value == null || value === '') return '';
  if (typeof value === 'number') {
    const d = new Date(value);
    return Number.isNaN(d.getTime()) ? '' : formatDateTime(d);
  }
  const raw = String(value);
  if (/^\d{4}-\d{2}-\d{2}/.test(raw)) return raw.replace('T', ' ').slice(0, 19);
  const d = new Date(raw);
  return Number.isNaN(d.getTime()) ? '' : formatDateTime(d);
}

function formatDateTime(d: Date): string {
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

/** 从业务属性里挑出记录名；不同模型字段名可能不同，按优先级回退 */
function pickName(item: MetadataQueryItem): string {
  const attrs = item.attributes ?? {};
  return text(attrs.name ?? attrs.recordName ?? attrs.title ?? attrs.NAME ?? attrs['名称'] ?? item.metadataUid ?? item.featureUid);
}

function pickString(attrs: Record<string, string>, keys: string[]): string {
  for (const key of keys) {
    const value = attrs[key];
    if (value != null && text(value) !== '') return text(value);
  }
  return '';
}

/** MetadataQueryItem → MetadataRecord（页面消费形状） */
export function toMetadataRecord(item: MetadataQueryItem, index: number): MetadataRecord {
  const attrs = { ...(item.attributes ?? {}) };
  const dataLevelRaw = pickString(attrs, ['dataLevel', 'securityLevel', '密级']);
  const bboxRaw = pickString(attrs, ['bbox', 'spatialRange', '空间范围']);
  let bbox: [number, number, number, number] = [0, 0, 0, 0];
  if (bboxRaw) {
    const nums = bboxRaw.split(/[,，\s]+/).map(Number).filter((n) => Number.isFinite(n));
    if (nums.length >= 4) bbox = [nums[0], nums[1], nums[2], nums[3]];
  }
  const versionNo = item.versionNo;
  const version = text(attrs.version ?? attrs.versionNo ?? (versionNo != null ? versionNo : ''));
  return {
    id: index + 1,
    recordUid: text(item.metadataUid ?? item.featureUid),
    modelUid: text(item.modelUid),
    tableUid: text(item.tableKey),
    tableName: text(item.resourceName ?? attrs.tableName),
    category: text(item.categoryName ?? attrs.category),
    name: pickName(item),
    version,
    dataLevel: dataLevelRaw === '内部' ? '内部' : '公开',
    region: pickString(attrs, ['region', 'administrativeDivision', '区域']),
    bbox,
    description: pickString(attrs, ['description', 'remark', '描述']),
    operator: pickString(attrs, ['operator', 'creator', '操作人']),
    createdAt: toDateTime(attrs.createdAt ?? attrs.createTime),
    updatedAt: toDateTime(attrs.updatedAt ?? attrs.updateTime),
    fields: attrs,
    checkStatus: undefined,
    errorMessage: undefined,
    // 写入所需的真实接口上下文，不参与页面展示
    _resourceUid: text(item.resourceUid),
    _tableKey: text(item.tableKey),
    _rowVersion: item.rowVersion ?? (attrs.row_version != null ? Number(attrs.row_version) : attrs.rowVersion != null ? Number(attrs.rowVersion) : 0)
  } as MetadataRecord & { _resourceUid: string; _tableKey: string; _rowVersion: number };
}

/** 分页拉取全部记录（最多 ${FULL_PAGE_SIZE} 条/页，循环至取尽） */
export async function getAllMetadataRecords() {
  const items: MetadataQueryItem[] = [];
  const MAX_PAGES = 100; // 200/页 × 100 = 2 万条上限，防止游标异常导致死循环
  let page = 1;
  let total = 0;
  let batch: MetadataQueryItem[] = [];
  let queryToken: string | undefined;
  do {
    // queryToken 是跨页游标：后续页必须原样回传，否则服务端退回从头查
    const res: any = await queryMetadataRecords({ page, pageSize: FULL_PAGE_SIZE, queryToken });
    batch = res?.data?.items ?? [];
    total = res?.data?.total ?? 0;
    queryToken = res?.data?.queryToken ?? undefined;
    items.push(...batch);
    page += 1;
  } while (items.length < total && batch.length > 0 && page <= MAX_PAGES);
  return ok(items.map((item, index) => toMetadataRecord(item, index)));
}

/** 模型表选项：直接转发真实聚合接口，字段形状已与页面一致 */
export async function getModelTableOptions() {
  const res: any = await fetchModelTableOptions();
  return ok(res?.data ?? { items: [], total: 0 });
}

interface RecordUpdateMeta {
  // toMetadataRecord 注入的真实写入上下文
  _resourceUid?: string;
  _tableKey?: string;
  _rowVersion?: number;
  // 兼容直接从接口项转换、带标准字段名的对象
  resourceUid?: string;
  tableKey?: string;
  rowVersion?: number;
}

/**
 * 保存记录：逐条写回真实接口。
 *
 * 取锁 → 更新 → 放锁由 withEditLock 收敛；values 取记录 fields，
 * expectedRowVersion 取真实接口的 rowVersion（缺失时 0，由后端校验冲突）。
 */
export async function saveMetadataRecords(records: MetadataRecord[]) {
  for (const record of records) {
    const meta = record as MetadataRecord & RecordUpdateMeta;
    const resourceUid = meta._resourceUid ?? meta.resourceUid;
    const tableKey = meta._tableKey ?? meta.tableUid;
    const metadataUid = record.recordUid;
    if (!resourceUid || !tableKey || !metadataUid) {
      throw new Error('记录缺少真实写入上下文（resourceUid/tableKey/recordUid），无法保存');
    }
    const expectedRowVersion = meta._rowVersion ?? Number(record.fields?.row_version ?? record.fields?.rowVersion ?? 0);
    await withEditLock(resourceUid, tableKey, { mode: 'records', metadataUids: [metadataUid] }, (lock) =>
      updateMetadataRecord(resourceUid, tableKey, metadataUid, {
        values: record.fields ?? {},
        expectedRowVersion: Number.isFinite(expectedRowVersion) ? expectedRowVersion : 0,
        lockToken: lock.lockToken
      })
    );
  }
  return ok(null, `已保存 ${records.length} 条记录`);
}
