/**
 * 分类要素初级产品「配色表」纯逻辑与内置预设
 *
 * - 不依赖 Vue / localStorage，仅做数据与纯函数，便于 node 自检与多处复用。
 * - CATEGORY_PALETTE 为 9 类产品类别的默认（标准）配色，是产品地图的唯一配色真源，
 *   record-map.ts 由此 re-export，mock 持久化与 useProductPalette 均以此为准。
 * - PALETTE_PRESETS 提供 4 套内置配色方案（标准 / 暖色 / 冷色 / 地质），可一键套用。
 */
import { PRODUCT_TYPES } from '../types';

/** 分类要素初级产品 9 类默认配色（标准方案，与产品地图一致） */
export const CATEGORY_PALETTE: Record<string, string> = {
  交通: '#FF6B6B',
  水系: '#4DABF7',
  居民地: '#FCC419',
  植被: '#51CF66',
  地表覆盖: '#9775FA',
  三维建筑物: '#FF922B',
  岩土体: '#845EF7',
  灾害地质: '#E64980',
  矿产资源: '#20C997'
};

/** 配色方案：一套「类别 → 填充色 / 边框色」映射，内置或自定义 */
export interface PaletteScheme {
  id: string;
  name: string;
  /** 内置方案不可删除 / 重命名，仅可套用或复制为自定义 */
  builtin: boolean;
  /** 类别 → 填充色（地图矩形着色，键与 PRODUCT_TYPES 对齐） */
  colors: Record<string, string>;
  /** 类别 → 边框色（产品类型管理展示 / 未来地图描边） */
  borderColors: Record<string, string>;
}

/** 暖色方案：红 / 橙 / 黄家族 */
const WARM_PALETTE: Record<string, string> = {
  交通: '#E03131',
  水系: '#F76707',
  居民地: '#F59F00',
  植被: '#FCC419',
  地表覆盖: '#FF922B',
  三维建筑物: '#E8590C',
  岩土体: '#D9480F',
  灾害地质: '#C2255C',
  矿产资源: '#F06595'
};

/** 冷色方案：蓝 / 青 / 绿 / 紫家族 */
const COOL_PALETTE: Record<string, string> = {
  交通: '#1971C2',
  水系: '#339AF0',
  居民地: '#4DABF7',
  植被: '#38D9A9',
  地表覆盖: '#20C997',
  三维建筑物: '#15AABF',
  岩土体: '#5C7CFA',
  灾害地质: '#7048E8',
  矿产资源: '#3BC9DB'
};

/** 地质方案：土黄 / 赭石 / 橄榄 / 板岩大地色系 */
const GEOLOGY_PALETTE: Record<string, string> = {
  交通: '#8D6E63',
  水系: '#607D8B',
  居民地: '#A1887F',
  植被: '#689F38',
  地表覆盖: '#9E9D24',
  三维建筑物: '#795548',
  岩土体: '#6D4C41',
  灾害地质: '#BF360C',
  矿产资源: '#C79100'
};

/** 由填充色映射派生边框色映射（默认取填充色的加深变体） */
function toBorders(colors: Record<string, string>): Record<string, string> {
  return Object.fromEntries(Object.entries(colors).map(([key, value]) => [key, defaultBorderOf(value)]));
}

function preset(id: string, name: string, colors: Record<string, string>): PaletteScheme {
  return { id, name, builtin: true, colors: { ...colors }, borderColors: toBorders(colors) };
}

/** 4 套内置配色方案（标准沿用 CATEGORY_PALETTE） */
export const PALETTE_PRESETS: PaletteScheme[] = [
  preset('builtin-standard', '标准配色', CATEGORY_PALETTE),
  preset('builtin-warm', '暖色配色', WARM_PALETTE),
  preset('builtin-cool', '冷色配色', COOL_PALETTE),
  preset('builtin-geology', '地质配色', GEOLOGY_PALETTE)
];

/** 将 #RGB / #RRGGBB 填充色加深约 25% 作为默认边框色；非法输入原样返回 */
export function defaultBorderOf(color: string): string {
  const hex = String(color || '')
    .trim()
    .replace('#', '');
  if (!/^[0-9a-f]{6}$/i.test(hex)) return color;
  const num = Number.parseInt(hex, 16);
  const r = Math.round(((num >> 16) & 255) * 0.75);
  const g = Math.round(((num >> 8) & 255) * 0.75);
  const b = Math.round((num & 255) * 0.75);
  return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, '0')}`;
}

/** 按索引生成一个稳定的兜底色（HSL 均分色相），用于新增类别尚无配色时 */
export function fallbackColor(index: number, total: number = PRODUCT_TYPES.length): string {
  const hue = Math.round((index * 360) / Math.max(total, 1)) % 360;
  return `hsl(${hue}, 65%, 58%)`;
}

/**
 * 将一份 colors 对齐到给定类别集合：补齐缺失（回退 CATEGORY_PALETTE / 兜底色），剔除多余键，
 * 并按 categories 顺序返回新对象，保证地图 match 表达式键序稳定。
 * 默认类别为内置 9 类；产品类型管理增删类别后，调用方应传入当前配置的类别名。
 */
export function alignColors(colors: Record<string, string> | undefined, categories: readonly string[] = PRODUCT_TYPES): Record<string, string> {
  const source = colors ?? {};
  const out: Record<string, string> = {};
  categories.forEach((category, index) => {
    out[category] = source[category] || CATEGORY_PALETTE[category] || fallbackColor(index);
  });
  return out;
}

/** 克隆方案（用于复制 / 新建草稿），可覆写 id / name / builtin 等字段 */
export function cloneScheme(scheme: PaletteScheme, patch: Partial<PaletteScheme> = {}): PaletteScheme {
  return {
    id: scheme.id,
    name: scheme.name,
    builtin: scheme.builtin,
    colors: { ...scheme.colors },
    borderColors: { ...scheme.borderColors },
    ...patch
  };
}

/** 生成不与既有名称重复的方案名：自定义配色 / 自定义配色 2 / … */
export function nextSchemeName(existing: string[], base = '自定义配色'): string {
  const names = new Set(existing);
  if (!names.has(base)) return base;
  let seq = 2;
  while (names.has(`${base} ${seq}`)) seq++;
  return `${base} ${seq}`;
}

/** 由一份 colors（可选 borderColors）构造完整方案，边框缺省自动加深派生 */
export function schemeFromColors(
  id: string,
  name: string,
  colors: Record<string, string>,
  borderColors?: Record<string, string>,
  builtin = false,
  categories: readonly string[] = PRODUCT_TYPES
): PaletteScheme {
  const aligned = alignColors(colors, categories);
  return {
    id,
    name,
    builtin,
    colors: aligned,
    borderColors: alignColors(borderColors ?? toBorders(aligned), categories)
  };
}
