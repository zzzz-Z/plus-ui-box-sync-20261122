/**
 * 元数据管理模块 Mock 服务门面
 *
 * - 方法与返回结构与现有 Pont 服务（src/services/product.ts）保持一致：
 *   Promise<{ code: 0, data: {...}, message? }>，data 内为 items/total 或明细。
 * - 日后期望切换真实接口时，仅需将各面板对 './services/api' 的引用改为 Pont
 *   服务模块，面板代码无需改动（方法签名相同）。
 */
import type { AxiosResponse } from 'axios';
import {
  buildSampleRecordsForModel,
  findCategory,
  mockDb,
  persistModels,
  persistProductTypes,
  persistRecords,
  toCategoryTree
} from './db';
import { FIELD_TYPE_LABELS } from '../types';
import type { MetadataModel, ProductCategory } from '../types';

function delay(ms = 120) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * 与 Pont request<Payload> 的类型口径保持一致：
 * 返回对象形如 { code: 0, data: payload }，同时按 AxiosResponse<T> 类型暴露，
 * 以便 useAsyncData / Table 等消费方类型行为与真实接口一致。
 */
function ok<T>(data: T, message = 'success') {
  return { code: 0, data, message } as unknown as AxiosResponse<T>;
}

function paginate<T>(items: T[], pageNum = 1, pageSize = 10) {
  const start = (pageNum - 1) * pageSize;
  return { items: items.slice(start, start + pageSize), total: items.length };
}

/* ------------------------------------------------------------------ */
/* 元数据模型（规格 1：创建元数据模型）                                  */
/* ------------------------------------------------------------------ */

export async function getMetadataModelList(params: any = {}) {
  await delay();
  const { name, keyword, type, productCategory, pageNum = 1, pageSize = 10 } = params;
  const text = String(name || keyword || '').toLowerCase();
  let items = mockDb.models.filter((model) => {
    const matchedText = !text || `${model.modelName}${model.modelKey}${model.description ?? ''}`.toLowerCase().includes(text);
    const matchedCategory =
      !type ||
      model.modelCategory === type ||
      model.productCategoryIds.includes(type) ||
      model.productCategoryIds.includes(String(type).replace('-child-1', ''));
    const matchedProduct =
      !productCategory ||
      model.productCategoryIds.includes(productCategory) ||
      model.productCategoryIds.includes(String(productCategory).replace('-child-1', ''));
    return matchedText && matchedCategory && matchedProduct;
  });
  items = [...items].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  return ok(paginate(items, pageNum, pageSize));
}

/** 按关键字裁剪类别树：命中节点保留其全部子级，未命中但有命中后代的节点仅保留命中分支 */
function filterCategoryTree(tree: ProductCategory[], keyword: string): ProductCategory[] {
  const text = keyword.trim().toLowerCase();
  if (!text) return tree;
  return tree.reduce<ProductCategory[]>((kept, node) => {
    const children = filterCategoryTree(node.children ?? [], keyword);
    const hit = `${node.categoryName}${node.categoryKey ?? ''}${node.description ?? ''}`.toLowerCase().includes(text);
    if (hit || children.length) kept.push({ ...node, children: hit ? node.children : children });
    return kept;
  }, []);
}

/* ------------------------------------------------------------------ */
/* 产品类型管理（与产品管理模块共用 mockDb.productTypes；颜色由配色表管理） */
/* ------------------------------------------------------------------ */

/** 产品类型树（配置数据本身，不含派生的「XX初级产品」叶子；支持名称/编码/描述过滤） */
export async function getProductTypeList(params: any = {}) {
  await delay(80);
  const keyword = String(params.categoryName || params.keyword || '');
  const items = filterCategoryTree(toCategoryTree(mockDb.productTypes, false), keyword);
  return ok({ items, total: items.length });
}

/** 上级类别 uid 归一化：派生叶子（XX初级产品）落到其所属类别 */
function normalizeParent(uid?: string) {
  const value = String(uid ?? '').replace(/-child-1$/, '');
  return value || undefined;
}

/** 新增 / 更新产品类型（有 categoryUid 且命中则更新，否则新增） */
export async function saveProductType(data: Partial<ProductCategory> & { categoryName: string }) {
  await delay();
  const name = String(data.categoryName || '').trim();
  // 类别名是记录 category 与地图配色键：重名会让配色与记录归属混淆，直接拒绝
  if (mockDb.productTypes.some((type) => type.categoryName === name && type.categoryUid !== data.categoryUid))
    return { code: 1, data: null, message: `产品类型「${name}」已存在` };
  const existed = data.categoryUid ? mockDb.productTypes.find((type) => type.categoryUid === data.categoryUid) : undefined;
  const parentCategoryUid = normalizeParent(data.parentCategoryUid ?? existed?.parentCategoryUid);
  if (existed) {
    const previousName = existed.categoryName;
    Object.assign(existed, {
      categoryName: name,
      categoryKey: data.categoryKey ?? existed.categoryKey,
      description: data.description ?? '',
      parentCategoryUid: parentCategoryUid === existed.categoryUid ? undefined : parentCategoryUid
    });
    if (previousName !== existed.categoryName) renameCategoryReferences(previousName, existed.categoryName);
    persistProductTypes();
    return ok(existed, '产品类型已更新');
  }
  const row: ProductCategory = {
    categoryUid: data.categoryUid || `ptype-${Date.now()}`,
    categoryName: name,
    categoryKey: data.categoryKey || name,
    description: data.description ?? '',
    parentCategoryUid
  };
  mockDb.productTypes.push(row);
  persistProductTypes();
  return ok(row, '产品类型已新增');
}

/** 删除产品类型（含其子类别，并解除相关模型的产品类别关联） */
export async function deleteProductType(categoryUid: string) {
  await delay();
  const existed = mockDb.productTypes.find((type) => type.categoryUid === categoryUid);
  if (!existed) return { code: 1, data: null, message: '产品类型不存在' };
  const removed = collectSubtreeIds(categoryUid);
  mockDb.productTypes = mockDb.productTypes.filter((type) => !removed.includes(type.categoryUid));
  persistProductTypes();
  detachCategoryReferences(removed);
  return ok(null, '产品类型已删除');
}

/** 收集某类别及其全部后代的 uid */
function collectSubtreeIds(categoryUid: string) {
  const ids = [categoryUid];
  for (let index = 0; index < ids.length; index++) {
    mockDb.productTypes.filter((type) => type.parentCategoryUid === ids[index]).forEach((type) => ids.push(type.categoryUid));
  }
  return ids;
}

/**
 * 类别重命名的级联：记录类别（含 category 字段值、存储路径）与模型的关联展示名、枚举选项同步为新名称，
 * 否则地图按 category 着色、列表按 category 过滤都会与配置脱节。
 */
function renameCategoryReferences(from: string, to: string) {
  let recordsChanged = false;
  mockDb.records.forEach((record) => {
    if (record.category === from) {
      record.category = to;
      recordsChanged = true;
    }
    if (record.fields?.category === from) {
      record.fields.category = to;
      recordsChanged = true;
    }
    if (typeof record.fields?.storagePath === 'string' && record.fields.storagePath.includes(`/${from}/`)) {
      record.fields.storagePath = record.fields.storagePath.replace(`/${from}/`, `/${to}/`);
      recordsChanged = true;
    }
  });
  if (recordsChanged) persistRecords();

  let modelsChanged = false;
  mockDb.models.forEach((model) => {
    model.productCategories?.forEach((category) => {
      if (category.categoryName === from) {
        category.categoryName = to;
        modelsChanged = true;
      }
    });
    model.tables.forEach((table) => {
      table.fields.forEach((field) => {
        if (field.options?.includes(from)) {
          field.options = field.options.map((option) => (option === from ? to : option));
          modelsChanged = true;
        }
        if (field.defaultValue === from) {
          field.defaultValue = to;
          modelsChanged = true;
        }
      });
    });
  });
  if (modelsChanged) persistModels();
}

/** 类别删除的级联：解除模型（含派生叶子 uid）对类别的关联 */
function detachCategoryReferences(categoryUids: string[]) {
  const keys = new Set(categoryUids.flatMap((uid) => [uid, `${uid}-child-1`]));
  let changed = false;
  mockDb.models.forEach((model) => {
    const kept = model.productCategoryIds.filter((uid) => !keys.has(uid));
    if (kept.length !== model.productCategoryIds.length) {
      model.productCategoryIds = kept;
      changed = true;
    }
    const categories = (model.productCategories ?? []).filter((category) => !keys.has(category.categoryUid));
    if (categories.length !== (model.productCategories ?? []).length) {
      model.productCategories = categories;
      changed = true;
    }
  });
  if (changed) persistModels();
}

export async function getMetadataModelDetail(id: string) {
  await delay();
  const model = mockDb.models.find((item) => item.modelUid === id || item.modelKey === id);
  if (!model) return { code: 1, data: null, message: '模型不存在' };
  return ok(structuredClone(model));
}

export async function createMetadataModel(data: any) {
  await delay();
  const now = new Date().toLocaleString('zh-CN', { hour12: false });
  const model: MetadataModel = {
    modelUid: data.modelUid || `model-${Date.now()}`,
    modelName: data.modelName,
    modelKey: data.modelKey || data.modelName,
    modelCategory: data.modelCategory ?? '结构',
    description: data.description,
    productCategoryIds: data.productCategoryIds || [],
    // 关联的产品类别由当前配置的类别树递归解析（含子级类别，兼容派生的「XX初级产品」叶子）
    productCategories: (data.productCategoryIds || [])
      .map((uid: string) => {
        const node = findCategory(uid);
        return node ? { categoryUid: node.categoryUid, categoryName: node.categoryName } : undefined;
      })
      .filter(Boolean),
    tables: data.tables || [],
    locked: false,
    operator: '张工',
    createdAt: now,
    updatedAt: now
  };
  mockDb.models.unshift(model);
  persistModels();
  return ok(model, '元数据模型创建成功');
}

export async function updateMetadataModel(id: string, data: any) {
  await delay();
  const model = mockDb.models.find((item) => item.modelUid === id);
  if (!model) return { code: 1, data: null, message: '模型不存在' };
  Object.assign(model, data, {
    updatedAt: new Date().toLocaleString('zh-CN', { hour12: false })
  });
  persistModels();
  return ok(model, '元数据模型更新成功');
}

export async function deleteMetadataModel(id: string) {
  await delay();
  const index = mockDb.models.findIndex((item) => item.modelUid === id);
  if (index < 0) return { code: 1, data: null, message: '模型不存在' };
  mockDb.models.splice(index, 1);
  persistModels();
  return ok(null, '元数据模型已删除');
}

/* ------------------------------------------------------------------ */
/* 模板与字段库（规格 1：模板 / 拖拽建表）                              */
/* ------------------------------------------------------------------ */

export async function getTemplateList(params?: any) {
  await delay(80);
  const keyword = String(params?.keyword || '').toLowerCase();
  const items = mockDb.templates.filter(
    (template) => !keyword || `${template.modelName}${template.description ?? ''}`.toLowerCase().includes(keyword)
  );
  return ok({ items, total: items.length });
}

const FIELD_LIBRARY_GROUPS = [
  { categoryName: '基础信息', fields: ['产品名称|string', '产品类别|enum', '内容摘要|string'] },
  { categoryName: '结构信息', fields: ['空间范围|coordinate', '要素类型|enum', '几何精度|decimal', '生产方式|enum'] },
  {
    categoryName: '管理信息',
    fields: [
      '版本号|string',
      '数据级别|level',
      '更新时间|datetime',
      '操作人|string',
      '存储路径|path',
      '数据来源|string',
      '数据库配置|string',
      '负责人|string'
    ]
  },
  { categoryName: '发现信息', fields: ['关键词|string', '数据提供方|string', '在线访问地址|path', '使用限制|enum'] },
  { categoryName: '应用信息', fields: ['使用方|string', '应用场景|string', '共享方式|enum', '数据量|integer'] }
];

export async function getFieldLibraryList(params?: any) {
  await delay(80);
  const keyword = String(params?.keyword || '').toLowerCase();
  const categories = FIELD_LIBRARY_GROUPS.map((group) => ({
    categoryName: group.categoryName,
    fields: group.fields
      .filter((item) => !keyword || item.split('|')[0].includes(keyword))
      .map((item, index) => {
        const [displayName, type] = item.split('|');
        const name = displayName;
        return {
          uid: `lib-${index}-${name}`,
          name,
          displayName,
          type,
          typeLabel: FIELD_TYPE_LABELS[type as keyof typeof FIELD_TYPE_LABELS] ?? '文本',
          length: type === 'string' ? 50 : undefined,
          nullable: true
        };
      })
  })).filter((group) => group.fields.length);
  return ok({ categories });
}

/* ------------------------------------------------------------------ */
/* 系统管理 · 电子地图底图                                              */
/* ------------------------------------------------------------------ */
/**
 * 底图已切换为真实接口：见 `../platform/basemap.ts`
 * （GET/POST /platform/basemaps、DELETE /platform/basemaps/{uid}）。
 *
 * WHY 保留本段空注释而不删整节：`mockDb.basemaps` 与 `buildSeedBasemaps`
 * 仍被 `resetMetadataMock()` 使用（「重置演示数据」需要重灌种子），
 * 只是不再有 mock 门面函数对外暴露 —— 删除它们会连带破坏 mockDb 结构与重置逻辑。
 */

/* ------------------------------------------------------------------ */
/* 工具                                                                */
/* ------------------------------------------------------------------ */

/** 按模型自动生成元数据表范例记录 */
export async function generateModelSamples(modelUid: string, perTable = 3) {
  await delay(120);
  const model = mockDb.models.find((item) => item.modelUid === modelUid || item.modelKey === modelUid);
  if (!model) return { code: 1, data: null, message: '模型不存在' };
  const created = buildSampleRecordsForModel(model, perTable);
  mockDb.records.push(...created);
  persistRecords();
  return ok({ count: created.length }, '元数据表范例生成成功');
}
