import type { AxiosResponse } from 'axios';
import {
  persistResultExtractTasks,
  persistResultModels,
  persistResultRecords,
  persistResultSamples,
  persistResultStoreTasks,
  persistResultUpdateTasks,
  resetResultMock,
  resultMockDb
} from './result-db';
import type { ModelResult, ResultRecord, SampleResult } from '../types/result';

const delay = (ms = 120) => new Promise((r) => setTimeout(r, ms));
const ok = <T>(data: T, message = 'success') => ({ code: 0, data, message }) as unknown as AxiosResponse<T>;
function paginate<T>(items: T[], pageNum = 1, pageSize = 10) {
  const s = (pageNum - 1) * pageSize;
  return { items: items.slice(s, s + pageSize), total: items.length };
}

export async function getAllResultRecords() {
  await delay(60);
  return ok([...resultMockDb.records]);
}

export async function getResultRecordList(params: any = {}) {
  await delay(80);
  const { keyword, moduleType, resultType, archiveStatus, pageNum = 1, pageSize = 10 } = params;
  const text = String(keyword || '').toLowerCase();
  const items = resultMockDb.records.filter(
    (r) =>
      (!text || `${r.name}${r.resultType}${r.region}${r.targetLib || ''}`.toLowerCase().includes(text)) &&
      (!moduleType || r.moduleType === moduleType) &&
      (!resultType || r.resultType === resultType) &&
      (!archiveStatus || r.archiveStatus === archiveStatus)
  );
  return ok(paginate(items, pageNum, pageSize));
}

export async function saveResultRecords(records: ResultRecord[]) {
  await delay();
  records.forEach((r) => {
    const i = resultMockDb.records.findIndex((x) => x.recordUid === r.recordUid);
    if (i >= 0) resultMockDb.records[i] = r;
    else resultMockDb.records.unshift(r);
  });
  persistResultRecords();
  return ok(null, `已保存 ${records.length} 条记录`);
}

export async function archiveToQqpt(recordUid: string) {
  await delay(300);
  const r = resultMockDb.records.find((x) => x.recordUid === recordUid);
  if (!r) return { code: 1, data: null, message: '记录不存在' };
  const archiveId = `QQPT-ARC-${Date.now().toString().slice(-8)}`;
  r.archiveStatus = 'archiving';
  r.archiveId = archiveId;
  persistResultRecords();
  return ok({ archiveId }, '已提交 qqpt 归档，正在处理');
}

export async function queryArchiveStatus(archiveId: string) {
  await delay(150);
  const r = resultMockDb.records.find((x) => x.archiveId === archiveId);
  if (!r) return { code: 1, data: null, message: '归档任务不存在' };
  if (Math.random() > 0.2) {
    r.archiveStatus = 'archived';
    r.archivedAt = new Date().toLocaleString('zh-CN', { hour12: false });
    r.archiveError = undefined;
  } else {
    r.archiveStatus = 'failed';
    r.archiveError = 'qqpt 接口调用超时';
  }
  persistResultRecords();
  return ok({ status: r.archiveStatus, archiveId });
}

export async function batchArchiveToQqpt(recordUids: string[]) {
  await delay(200);
  const results: { recordUid: string; archiveId: string }[] = [];
  recordUids.forEach((uid, i) => {
    const r = resultMockDb.records.find((x) => x.recordUid === uid);
    if (r) {
      const archiveId = `QQPT-ARC-${Date.now().toString().slice(-8)}-${i}`;
      r.archiveStatus = 'archiving';
      r.archiveId = archiveId;
      results.push({ recordUid: uid, archiveId });
    }
  });
  persistResultRecords();
  return ok({ count: results.length, tasks: results }, `已提交 ${results.length} 个归档任务`);
}

export async function getModelResultList(params: any = {}) {
  await delay(80);
  const { keyword, category, algorithm, pageNum = 1, pageSize = 10 } = params;
  const text = String(keyword || '').toLowerCase();
  const items = resultMockDb.models.filter(
    (m) =>
      (!text || `${m.name}${m.category}${m.algorithm}${m.sensor}`.toLowerCase().includes(text)) &&
      (!category || m.category === category) &&
      (!algorithm || m.algorithm === algorithm)
  );
  return ok(paginate(items, pageNum, pageSize));
}

export async function getSampleResultList(params: any = {}) {
  await delay(80);
  const { keyword, category, sheetNo, resolution, pageNum = 1, pageSize = 10 } = params;
  const text = String(keyword || '').toLowerCase();
  const items = resultMockDb.samples.filter(
    (s) =>
      (!text || `${s.name}${s.category}${s.sheetNo}${s.sensor}`.toLowerCase().includes(text)) &&
      (!category || s.category === category) &&
      (!sheetNo || s.sheetNo.includes(sheetNo)) &&
      (!resolution || s.resolution === resolution)
  );
  return ok(paginate(items, pageNum, pageSize));
}

export async function saveModelResult(data: ModelResult) {
  await delay();
  const i = resultMockDb.models.findIndex((m) => m.id === data.id);
  if (i >= 0) resultMockDb.models[i] = data;
  else resultMockDb.models.unshift({ ...data, id: Date.now() });
  persistResultModels();
  return ok(null, '模型成果已保存');
}

export async function saveSampleResult(data: SampleResult) {
  await delay();
  const i = resultMockDb.samples.findIndex((s) => s.id === data.id);
  if (i >= 0) resultMockDb.samples[i] = data;
  else resultMockDb.samples.unshift({ ...data, id: Date.now() });
  persistResultSamples();
  return ok(null, '样本成果已保存');
}

export async function getResultStoreTaskList() {
  await delay(60);
  return ok([...resultMockDb.storeTasks]);
}
export async function getResultExtractionTaskList() {
  await delay(60);
  return ok([...resultMockDb.extractTasks]);
}
export async function getResultUpdateTaskList() {
  await delay(60);
  return ok([...resultMockDb.updateTasks]);
}

export const persistStoreTaskData = persistResultStoreTasks;
export const persistExtractTaskData = persistResultExtractTasks;
export const persistUpdateTaskData = persistResultUpdateTasks;

export async function resetResultDb() {
  await delay(100);
  resetResultMock();
  return ok(null, '产品成果演示数据已重置');
}
