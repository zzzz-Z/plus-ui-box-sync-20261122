import type {
  ArchiveStatus,
  ModelResult,
  ResultExtractionTask,
  ResultRecord,
  ResultStoreTask,
  ResultUpdateTask,
  SampleResult
} from '../types/result';
import { MODULE_RESULT_TYPES, RESULT_MODULE_TYPES, RESULT_TARGET_LIB } from '../types/result';

const KEY = {
  records: 'mdm.result.records',
  models: 'mdm.result.models',
  samples: 'mdm.result.samples',
  storeTasks: 'mdm.result.storeTasks',
  extractTasks: 'mdm.result.extractTasks',
  updateTasks: 'mdm.result.updateTasks'
} as const;

const STAGES: ArchiveStatus[] = ['archived', 'archived', 'archiving', 'failed', 'pending'];
const pad2 = (v: number) => String(v).padStart(2, '0');
const fmtDate = (d: Date) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
const fmtDT = (d: Date) => `${fmtDate(d)} ${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`;

export function buildSeedResultRecords(): ResultRecord[] {
  const out: ResultRecord[] = [];
  let id = 1;
  const base = new Date('2026-09-08T10:00:00').getTime();
  RESULT_MODULE_TYPES.forEach((moduleType, mi) => {
    if (moduleType === '样本与模型成果') return;
    MODULE_RESULT_TYPES[moduleType].forEach((resultType, si) => {
      const n = 2 + ((mi + si) % 3);
      for (let i = 0; i < n; i++) {
        const arch = STAGES[(mi + si + i) % STAGES.length];
        const lng = 116.1 + mi * 0.15 + si * 0.05 + i * 0.01;
        const lat = 38.7 + mi * 0.12 + si * 0.04 + i * 0.01;
        const seq = String(i + 1).padStart(2, '0');
        const ver = `V${1 + (i % 3)}.${i % 10}`;
        const targetLib = RESULT_TARGET_LIB[resultType] || '产品成果库';
        out.push({
          id: id++,
          recordUid: `result-${mi}-${si}-${seq}`,
          modelUid: `model-result-${mi}`,
          tableUid: `table-${mi}-${si}`,
          tableName: `${resultType}成果表`,
          category: resultType,
          name: `${resultType}-${seq}`,
          version: ver,
          dataLevel: i % 3 === 0 ? '公开' : '内部',
          region: ['北京市', '上海市', '广东省', '四川省'][i % 4],
          bbox: [lng, lat, lng + 0.06, lat + 0.05],
          description: `${resultType}产品成果，目标库：${targetLib}`,
          operator: ['张工', '李工', '王工'][(mi + i) % 3],
          createdAt: fmtDate(new Date(base - 86400000 * (10 + i))),
          updatedAt: fmtDate(new Date(base - 86400000 * i)),
          fields: {
            name: `${resultType}-${seq}`,
            category: resultType,
            version: ver,
            dataLevel: i % 3 === 0 ? '公开' : '内部',
            storagePath: `/data/result/${mi}/${si}/${seq}`
          },
          checkStatus: 'passed',
          moduleType,
          resultType,
          archiveStatus: arch,
          archiveId: arch === 'archived' ? `QQPT-ARC-${String(id).padStart(6, '0')}` : undefined,
          archivedAt: arch === 'archived' ? fmtDT(new Date(base - 3600000 * i)) : undefined,
          targetLib,
          archiveError: arch === 'failed' ? 'qqpt 接口调用超时，请检查网络或重试' : undefined
        });
      }
    });
  });
  return out;
}

export function buildSeedModelResults(): ModelResult[] {
  const sensors = ['GF-1', 'GF-2', 'GF-6', 'ZY-3', 'BJ-2'];
  const algs = ['YOLOv8', 'MaskRCNN', 'UNet', 'DeepLabV3+', 'SegFormer'];
  const pts = ['正射影像', '倾斜摄影', '矢量成果', '样本切片'];
  const trs: ModelResult['training'][] = ['已收敛', '训练中', '待优化', '过拟合'];
  return MODULE_RESULT_TYPES['样本与模型成果'].map((category, i) => ({
    id: i + 1,
    name: `${category}提取模型`,
    category,
    sensor: sensors[i % sensors.length],
    featureCode: `GB-2026-${String(i + 1).padStart(2, '0')}`,
    algorithm: algs[i % algs.length],
    productType: pts[i % pts.length],
    accuracy: Number((0.85 + (i % 10) * 0.01).toFixed(2)),
    version: `V${1 + (i % 3)}.${i % 10}`,
    size: `${(50 + i * 8).toFixed(1)} MB`,
    training: trs[i % trs.length],
    usageCount: 10 + i * 3,
    path: `/models/${category}/model-${i + 1}.pth`,
    archiveStatus: STAGES[i % STAGES.length],
    description: `${category}要素提取模型，基于${algs[i % algs.length]}训练`,
    createdAt: fmtDate(new Date(Date.now() - 86400000 * (30 + i))),
    updatedAt: fmtDate(new Date(Date.now() - 86400000 * i))
  }));
}

export function buildSeedSampleResults(): SampleResult[] {
  const sensors = ['GF-1', 'GF-2', 'GF-6', 'ZY-3', 'BJ-2'];
  const res = ['0.5m', '1m', '2m', '5m', '10m'];
  const lvls = ['L10', 'L12', 'L14', 'L16', 'L18'];
  const specs = ['256×256', '512×512', '1024×1024'];
  return MODULE_RESULT_TYPES['样本与模型成果'].map((category, i) => {
    const lng = 116.2 + (i % 5) * 0.1;
    const lat = 38.8 + (i % 4) * 0.1;
    return {
      id: i + 1,
      name: `${category}样本`,
      category,
      sensor: sensors[i % sensors.length],
      sheetNo: `J50G${String(i + 1).padStart(3, '0')}`,
      resolution: res[i % res.length],
      featureCode: `GB-2026-${String(i + 1).padStart(2, '0')}`,
      tileLevel: lvls[i % lvls.length],
      tileSpec: specs[i % specs.length],
      productType: '样本切片',
      tileCount: 100 + i * 50,
      imagePath: `/samples/${category}/images/`,
      labelPath: `/samples/${category}/labels/`,
      reportPath: `/samples/${category}/report.pdf`,
      bbox: [lng, lat, lng + 0.08, lat + 0.06] as [number, number, number, number],
      usageCount: 5 + i * 2,
      archiveStatus: STAGES[i % STAGES.length],
      createdAt: fmtDate(new Date(Date.now() - 86400000 * (20 + i))),
      updatedAt: fmtDate(new Date(Date.now() - 86400000 * i))
    };
  });
}

function buildTaskBase(moduleType: ResultRecord['moduleType'], resultType: string, i: number) {
  const seq = String(i + 1).padStart(3, '0');
  const arch = STAGES[i % STAGES.length];
  return {
    id: i + 1,
    moduleType,
    resultType,
    batch: `B-20260908-${seq}`,
    archiveStatus: arch,
    archiveId: arch === 'archived' ? `QQPT-ARC-${String(i + 1).padStart(6, '0')}` : undefined,
    recordIds: [i + 1, i + 2]
  };
}

export function buildSeedStoreTasks(): ResultStoreTask[] {
  const out: ResultStoreTask[] = [];
  let i = 0;
  RESULT_MODULE_TYPES.forEach((m) => {
    if (m === '样本与模型成果') return;
    MODULE_RESULT_TYPES[m].forEach((rt) => {
      const sts: ResultStoreTask['status'][] = ['completed', 'running', 'paused', 'waiting', 'error'];
      const s = sts[i % sts.length];
      const p = s === 'completed' ? 100 : s === 'waiting' ? 0 : 30 + ((i * 7) % 60);
      const base = buildTaskBase(m, rt, i);
      out.push({
        ...base,
        name: `${rt}成果入库`,
        dataLevel: i % 3 === 0 ? '公开' : '内部',
        source: `/data/source/${base.batch}`,
        targetLib: RESULT_TARGET_LIB[rt] || '产品成果库',
        progress: p,
        status: s,
        message:
          s === 'completed'
            ? '入库完成，已归档至 qqpt'
            : s === 'running'
              ? `正在入库 ${p}%`
              : s === 'paused'
                ? '资源竞争，已自动暂停'
                : s === 'error'
                  ? '归档失败，请重试'
                  : '等待资源调度',
        error: s === 'error' ? 'qqpt 接口调用失败' : undefined
      });
      i++;
    });
  });
  return out;
}

export function buildSeedExtractionTasks(): ResultExtractionTask[] {
  const out: ResultExtractionTask[] = [];
  let i = 0;
  RESULT_MODULE_TYPES.forEach((m) => {
    if (m === '样本与模型成果') return;
    MODULE_RESULT_TYPES[m].forEach((rt) => {
      const sts: ResultExtractionTask['status'][] = ['completed', 'running', 'paused', 'waiting'];
      const s = sts[i % sts.length];
      const p = s === 'completed' ? 100 : s === 'waiting' ? 0 : 40 + ((i * 5) % 50);
      const base = buildTaskBase(m, rt, i);
      out.push({
        ...base,
        name: `${rt}成果提取`,
        requestSource: `业务系统需求-${base.batch}`,
        targetPath: `/delivery/${base.batch}`,
        progress: p,
        status: s,
        message: s === 'completed' ? '数据已推送至申请方路径' : s === 'running' ? `正在提取 ${p}%` : '等待提取'
      });
      i++;
    });
  });
  return out;
}

export function buildSeedUpdateTasks(): ResultUpdateTask[] {
  const out: ResultUpdateTask[] = [];
  let i = 0;
  RESULT_MODULE_TYPES.forEach((m) => {
    if (m === '样本与模型成果') return;
    MODULE_RESULT_TYPES[m].forEach((rt) => {
      const sts: ResultUpdateTask['status'][] = ['completed', 'running', 'error', 'waiting'];
      const s = sts[i % sts.length];
      const p = s === 'completed' ? 100 : s === 'waiting' ? 0 : 20 + ((i * 8) % 70);
      const base = buildTaskBase(m, rt, i);
      out.push({
        ...base,
        name: `${rt}成果更新`,
        source: `/data/update/${base.batch}`,
        targetLib: RESULT_TARGET_LIB[rt] || '产品成果库',
        progress: p,
        status: s,
        message: s === 'completed' ? '更新完成，已重新归档' : s === 'running' ? `正在更新 ${p}%` : s === 'error' ? '更新失败' : '等待更新',
        error: s === 'error' ? '存储路径访问失败' : undefined
      });
      i++;
    });
  });
  return out;
}

function readStore<T>(key: string, fallback: () => T): T {
  const v = localStorage.getItem(key);
  if (!v) {
    const x = fallback();
    localStorage.setItem(key, JSON.stringify(x));
    return x;
  }
  try {
    return JSON.parse(v) as T;
  } catch {
    const x = fallback();
    localStorage.setItem(key, JSON.stringify(x));
    return x;
  }
}
const saveStore = (k: string, v: unknown) => localStorage.setItem(k, JSON.stringify(v));

export interface ResultMockDb {
  records: ResultRecord[];
  models: ModelResult[];
  samples: SampleResult[];
  storeTasks: ResultStoreTask[];
  extractTasks: ResultExtractionTask[];
  updateTasks: ResultUpdateTask[];
}

export const resultMockDb: ResultMockDb = {
  records: readStore(KEY.records, buildSeedResultRecords),
  models: readStore(KEY.models, buildSeedModelResults),
  samples: readStore(KEY.samples, buildSeedSampleResults),
  storeTasks: readStore(KEY.storeTasks, buildSeedStoreTasks),
  extractTasks: readStore(KEY.extractTasks, buildSeedExtractionTasks),
  updateTasks: readStore(KEY.updateTasks, buildSeedUpdateTasks)
};

export const persistResultRecords = () => saveStore(KEY.records, resultMockDb.records);
export const persistResultModels = () => saveStore(KEY.models, resultMockDb.models);
export const persistResultSamples = () => saveStore(KEY.samples, resultMockDb.samples);
export const persistResultStoreTasks = () => saveStore(KEY.storeTasks, resultMockDb.storeTasks);
export const persistResultExtractTasks = () => saveStore(KEY.extractTasks, resultMockDb.extractTasks);
export const persistResultUpdateTasks = () => saveStore(KEY.updateTasks, resultMockDb.updateTasks);

export function resetResultMock() {
  Object.assign(resultMockDb, {
    records: buildSeedResultRecords(),
    models: buildSeedModelResults(),
    samples: buildSeedSampleResults(),
    storeTasks: buildSeedStoreTasks(),
    extractTasks: buildSeedExtractionTasks(),
    updateTasks: buildSeedUpdateTasks()
  });
  persistResultRecords();
  persistResultModels();
  persistResultSamples();
  persistResultStoreTasks();
  persistResultExtractTasks();
  persistResultUpdateTasks();
}
