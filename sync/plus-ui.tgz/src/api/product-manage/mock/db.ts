/**
 * 元数据管理模块 Mock 数据源
 *
 * - localStorage 持久化（key 前缀 mdm.），首次访问生成确定性的种子数据
 * - 提供 resetMetadataMock() 供「重置演示数据」场景使用
 * - 生成的模型/记录字段与 types.ts 领域类型一致
 */
import type {
  Basemap,
  CheckResult,
  CheckStatus,
  CheckTask,
  ExtractionStatus,
  ExtractionTask,
  FieldType,
  MetadataModel,
  MetadataRecord,
  MetadataTemplate,
  ModelCategory,
  ModelField,
  ModelTable,
  ProductCategory,
  ReportRow,
  SampleRecord,
  StoreStatus,
  VersionRow
} from '../types';
import { MODEL_CATEGORIES, PRODUCT_TYPES } from '../types';
import { alignColors, PALETTE_PRESETS } from './palette';
import type { PaletteScheme } from './palette';

const KEY = {
  models: 'mdm.models',
  templates: 'mdm.templates',
  records: 'mdm.records',
  productTypes: 'mdm.productTypes',
  paletteState: 'mdm.paletteState',
  basemaps: 'mdm.basemaps'
} as const;

export const PRODUCT_TYPE_LABELS = PRODUCT_TYPES;

/** 产品类别简称（用于生成记录名） */
const SHORT_NAMES: Record<string, string> = {
  交通: '交通路网',
  水系: '水系分布',
  居民地: '居民地轮廓',
  植被: '植被覆盖',
  地表覆盖: '地表覆盖',
  三维建筑物: '三维建筑',
  岩土体: '岩土体分布',
  灾害地质: '灾害地质分布',
  矿产资源: '矿产资源分布'
};

const VERSIONS = ['v1.0', 'v1.2', 'v1.5', 'v2.0', 'v2.1', 'v3.0'];
const OPERATORS = ['张工', '李工', '王工', '赵工'];
const REGIONS = ['北京市', '北京市', '北京市', '北京市海淀区', '北京市朝阳区', '北京市通州区'];
const DATA_LEVELS: Array<'公开' | '内部'> = ['公开', '内部'];

/** 确定性伪随机数，保证每次重置演示数据形态一致 */
function mulberry32(seed: number) {
  return function next() {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function hashCode(text: string) {
  let hash = 0;
  for (let i = 0; i < text.length; i++) hash = (hash * 31 + text.charCodeAt(i)) >>> 0;
  return hash;
}

function readStorage<T>(key: string, fallback: () => T): T {
  const stored = localStorage.getItem(key);
  if (!stored) {
    const value = fallback();
    localStorage.setItem(key, JSON.stringify(value));
    return value;
  }
  try {
    return JSON.parse(stored) as T;
  } catch {
    const value = fallback();
    localStorage.setItem(key, JSON.stringify(value));
    return value;
  }
}

function saveStorage(key: string, value: unknown) {
  localStorage.setItem(key, JSON.stringify(value));
}

function pad2(value: number) {
  return String(value).padStart(2, '0');
}

function formatDate(d: Date) {
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

function formatDateTime(d: Date) {
  return `${formatDate(d)} ${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`;
}

const PRODUCT_CATEGORY_IDS = ['traffic', 'water', 'settlement', 'vegetation', 'landCover', 'building3d', 'rockSoil', 'hazard', 'mineral'];

/** 产品类型（扁平 9 类，供产品类型管理增删改；颜色统一由配色表 palette 管理，不落在此处） */
export function buildSeedProductTypes(): ProductCategory[] {
  return PRODUCT_CATEGORY_IDS.map((uid, index) => ({
    categoryUid: uid,
    categoryName: PRODUCT_TYPE_LABELS[index],
    categoryKey: uid,
    description: `${PRODUCT_TYPE_LABELS[index]}分类要素初级产品`
  }));
}

/**
 * 扁平产品类型 → 类别树（结构同 Pont getProductCategory 返回的 tree）
 *
 * - 按 parentCategoryUid 归并层级：产品类型管理处「新增子级」即在此体现。
 * - withPrimaryLeaf 为真时，每个顶级类别附带一个「XX初级产品」叶子，保持与真实接口
 *   一致的树形（模型管理/元数据编辑的产品类别选择沿用该叶子）；产品类型管理自身
 *   展示配置数据，用 withPrimaryLeaf=false 避免出现不可编辑的派生节点。
 */
export function toCategoryTree(types: ProductCategory[], withPrimaryLeaf = true): ProductCategory[] {
  const nodes = new Map<string, ProductCategory>();
  types.forEach((type) => nodes.set(type.categoryUid, { ...type, children: [] }));
  const roots: ProductCategory[] = [];
  nodes.forEach((node) => {
    const parent = node.parentCategoryUid ? nodes.get(node.parentCategoryUid) : undefined;
    if (parent) parent.children!.push(node);
    else roots.push(node);
  });
  if (withPrimaryLeaf) {
    roots.forEach((root) =>
      root.children!.unshift({
        categoryUid: `${root.categoryUid}-child-1`,
        categoryName: `${root.categoryName}初级产品`
      })
    );
  }
  return roots;
}

/** 种子类别树：仅初始化/重置时使用，不读 mockDb，避免 mockDb 初始化期间的顺序依赖 */
function buildSeedCategoryTree(): ProductCategory[] {
  return toCategoryTree(buildSeedProductTypes());
}

/** 配色表持久化状态：内置 + 自定义方案、当前生效方案 id、当前生效的填充色 / 边框色 */
export interface PaletteState {
  schemes: PaletteScheme[];
  activeId: string;
  colors: Record<string, string>;
  borderColors: Record<string, string>;
}

/** 电子地图底图种子（系统管理增删改查初始数据） */
export function buildSeedBasemaps(): Basemap[] {
  return [
    {
      uid: 'bm-offline-china',
      name: '离线·中国',
      type: 'offline',
      url: '',
      tileSize: 256,
      description: '本地内置中国省级边界，无需联网即可显示底图'
    },
    {
      uid: 'bm-positron',
      name: '浅色 Positron',
      type: 'xyz',
      url: 'https://tiles.openfreemap.org/styles/positron',
      tileSize: 256,
      description: 'OpenFreeMap 浅色底图（需联网）'
    },
    {
      uid: 'bm-liberty',
      name: '标准 Liberty',
      type: 'xyz',
      url: 'https://tiles.openfreemap.org/styles/liberty',
      tileSize: 256,
      description: 'OpenFreeMap 标准底图（需联网）'
    },
    {
      uid: 'bm-osm',
      name: 'OpenStreetMap',
      type: 'xyz',
      url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
      tileSize: 256,
      description: 'OSM 公共瓦片服务（需联网）'
    }
  ];
}

function buildSeedPaletteState(): PaletteState {
  const standard = PALETTE_PRESETS[0];
  const categories = buildSeedProductTypes().map((type) => type.categoryName);
  return {
    schemes: PALETTE_PRESETS.map((scheme) => ({ ...scheme, colors: { ...scheme.colors }, borderColors: { ...scheme.borderColors } })),
    activeId: standard.id,
    colors: alignColors(standard.colors, categories),
    borderColors: alignColors(standard.borderColors, categories)
  };
}

/** 元数据字段定义压缩种子：[name, displayName, type, nullable, range, constraint, options?, default?, description?] */
type FieldSeed = [string, string, FieldType, boolean?, string?, string?, string[]?, unknown?, string?];

function buildField(tableUid: string, index: number, seed: FieldSeed): ModelField {
  const [name, displayName, type, nullable, range, constraint, options, defaultValue, description] = seed;
  return {
    uid: `${tableUid}-f${index}`,
    name,
    displayName,
    type,
    nullable: nullable ?? true,
    range,
    constraint,
    options,
    defaultValue,
    description
  };
}

function commonSeeds(label: string, code: string): FieldSeed[] {
  return [
    ['name', '产品名称', 'string', false, '1~50', '必填，唯一', undefined, undefined, '元数据记录名称'],
    ['category', '产品类别', 'enum', false, undefined, '必填', [...PRODUCT_TYPE_LABELS], label, '分类要素初级产品类别'],
    ['version', '版本号', 'string', false, '1~20', '必填', undefined, 'v1.0', '数据版本'],
    ['dataLevel', '数据级别', 'level', false, undefined, '必填', undefined, '内部', '公开/内部'],
    ['updateTime', '更新时间', 'datetime', true, undefined, undefined, undefined, undefined, '最近变更时间'],
    ['operator', '操作人', 'string', true, undefined, undefined, undefined, undefined, '最近操作人'],
    ['description', '内容摘要', 'string', true, '0~200', undefined, undefined, undefined, '数据内容描述'],
    ['storagePath', '存储路径', 'path', false, undefined, '入库时校验可访问', undefined, `/data/primary/${code}`, '实际存储路径']
  ];
}

function categorySeeds(modelCategory: ModelCategory): FieldSeed[] {
  if (modelCategory === '管理') {
    return [
      ['dataSource', '数据来源/生产记录', 'string', true, undefined, undefined, undefined, undefined, '生产记录、入库记录'],
      ['dbConfig', '数据库配置', 'string', true, undefined, undefined, undefined, undefined, '数据库地址/连接配置'],
      ['owner', '负责人', 'string', true, undefined, undefined, undefined, undefined, '数据维护责任人'],
      ['auditLog', '变更审计', 'string', true, undefined, undefined, undefined, undefined, '变更日志位置']
    ];
  }
  if (modelCategory === '发现') {
    return [
      ['keywords', '关键词', 'string', true, undefined, undefined, undefined, undefined, '检索关键词'],
      ['provider', '数据提供方', 'string', true, undefined, undefined, undefined, undefined, '提供单位/系统'],
      ['onlineUrl', '在线访问地址', 'path', true, undefined, undefined, undefined, undefined, '目录/服务地址'],
      ['useRestriction', '使用限制', 'enum', true, undefined, undefined, ['公开使用', '授权使用', '不公开'], '授权使用', '使用限制说明']
    ];
  }
  if (modelCategory === '应用') {
    return [
      ['users', '使用方/业务系统', 'string', true, undefined, undefined, undefined, undefined, '使用单位'],
      ['scenario', '应用场景', 'string', true, '0~100', undefined, undefined, undefined, '应用场景描述'],
      ['shareWay', '共享方式', 'enum', true, undefined, undefined, ['审核共享', '直接共享', '不共享'], '审核共享', '共享方式'],
      ['dataVolume', '数据量(条)', 'integer', true, '0~1000000', undefined, undefined, 0, '记录条数']
    ];
  }
  // 结构
  return [
    ['spatialExtent', '空间范围(四至)', 'coordinate', true, undefined, undefined, undefined, undefined, '地图模式矩形展示依据'],
    ['featureType', '要素类型', 'enum', true, undefined, undefined, ['面', '线', '点', '注记'], '面', '要素几何类型'],
    ['accuracy', '精度', 'decimal', true, '0~10', undefined, undefined, undefined, '几何精度/比例尺'],
    ['sourceType', '生产方式', 'enum', true, undefined, undefined, ['测绘', '遥感解译', '数据融合', '人工录入'], '遥感解译', '生产来源方式']
  ];
}

/** 依据模型类别组装一张表的字段 */
function tableFields(label: string, code: string, modelCategory: ModelCategory) {
  return [...commonSeeds(label, code), ...categorySeeds(modelCategory)];
}

/** 依据数据类别、模型类别创建一个模型种子 */
function buildModelSeed(key: string, modelName: string, modelCategory: ModelCategory, productIndex: number, tableNames: string[]): MetadataModel {
  const now = Date.now();
  const productCategory = buildSeedCategoryTree()[productIndex];
  const label = productCategory.categoryName;
  const code = productCategory.categoryUid;
  const tables: ModelTable[] = tableNames.map((tableName, tIndex) => {
    const uid = `${key}-t${tIndex + 1}`;
    const fields = tableFields(label, code, modelCategory).map((seed, fIndex) => buildField(uid, fIndex, seed));
    return { uid, name: tableName, fields };
  });
  return {
    modelUid: key,
    modelName,
    modelKey: key,
    modelCategory,
    description: `${label}${modelCategory}元数据模型，用于${label}初级产品元数据的${modelCategory === '结构' ? '建模与抽取' : modelCategory === '管理' ? '管理维护' : modelCategory === '发现' ? '目录发现' : '共享应用'}`,
    productCategoryIds: [code],
    productCategories: [{ categoryUid: code, categoryName: label }],
    tables,
    locked: false,
    operator: '张工',
    createdAt: formatDateTime(new Date(now - 86400000 * 30)),
    updatedAt: formatDateTime(new Date(now - 86400000 * 2))
  };
}

function buildSeedModels(): MetadataModel[] {
  const defs: Array<{ key: string; name: string; category: ModelCategory; product: number; tables: string[] }> = [
    { key: 'traffic-structure', name: '交通路网结构元数据模型', category: '结构', product: 0, tables: ['交通路网要素表', '交通路网属性表'] },
    { key: 'traffic-mgmt', name: '交通路网管理元数据模型', category: '管理', product: 0, tables: ['交通数据管理记录表'] },
    { key: 'traffic-discovery', name: '交通路网发现元数据模型', category: '发现', product: 0, tables: ['交通目录发现信息表'] },
    { key: 'water-structure', name: '水系分布结构元数据模型', category: '结构', product: 1, tables: ['水系要素表'] },
    { key: 'settlement-structure', name: '居民地轮廓结构元数据模型', category: '结构', product: 2, tables: ['居民地要素表'] },
    { key: 'vegetation-app', name: '植被覆盖应用元数据模型', category: '应用', product: 3, tables: ['植被应用记录表'] },
    { key: 'landcover-structure', name: '地表覆盖结构元数据模型', category: '结构', product: 4, tables: ['地表覆盖要素表'] },
    { key: 'rocksoil-mgmt', name: '岩土体管理元数据模型', category: '管理', product: 6, tables: ['岩土体管理记录表'] },
    { key: 'mineral-discovery', name: '矿产资源发现元数据模型', category: '发现', product: 8, tables: ['矿产资源目录表'] },
    { key: 'building-app', name: '三维建筑应用元数据模型', category: '应用', product: 5, tables: ['三维建筑应用表'] }
  ];
  return defs.map((def) => buildModelSeed(def.key, def.name, def.category, def.product, def.tables));
}

/** 结构化种子：表数量/名称按模型类别生成模板 */
export function buildSeedTemplates(): MetadataTemplate[] {
  return MODEL_CATEGORIES.map((category, index) => {
    const key = `tpl-${category}`;
    const label = '分类要素初级产品';
    const code = 'primary';
    const tables: ModelTable[] = [
      {
        uid: `${key}-t1`,
        name: `${label}${category}信息表`,
        fields: tableFields(label, code, category).map((seed, fIndex) => buildField(`${key}-t1`, fIndex, seed))
      }
    ];
    return {
      templateUid: key,
      modelName: `${category}元数据模板${index + 1}`,
      description: `${category}类元数据字段模板，可一键生成模型并自动生成范例记录`,
      modelCategory: category,
      tables
    };
  });
}

const TYPE_VALUE_GENERATORS: Record<string, (field: ModelField, rand: () => number) => string> = {
  enum: (field) => field.options?.[Math.floor(Math.random() * field.options.length)] ?? '',
  date: () => formatDate(new Date(Date.now() - Math.floor(Math.random() * 86400000 * 60))),
  datetime: () => formatDateTime(new Date(Date.now() - Math.floor(Math.random() * 86400000 * 60))),
  integer: () => String(Math.floor(Math.random() * 10000)),
  decimal: () => (Math.random() * 10).toFixed(2),
  coordinate: () => '116.30°E, 39.90°N'
};

function randomBBox(rand: () => number): [number, number, number, number] {
  const lng = 116.1 + rand() * 1.1;
  const lat = 38.7 + rand() * 1.0;
  const width = 0.03 + rand() * 0.08;
  const height = 0.03 + rand() * 0.07;
  return [lng, lat, lng + width, lat + height];
}

function randomDate(rand: () => number) {
  return formatDate(new Date(Date.now() - Math.floor(rand() * 86400000 * 180)));
}

/** 每类产品生成的记录条数（交通最多、用于演示地图聚合） */
const RECORD_COUNTS: Record<string, number> = {
  traffic: 9,
  water: 7,
  settlement: 6,
  vegetation: 5,
  landCover: 6,
  building3d: 4,
  rockSoil: 5,
  hazard: 4,
  mineral: 5
};

export function buildSeedRecords(models: MetadataModel[]): MetadataRecord[] {
  const records: MetadataRecord[] = [];
  let id = 1;
  models.forEach((model) => {
    const label = model.productCategories?.[0]?.categoryName ?? '分类要素';
    const code = model.productCategoryIds[0];
    const count = RECORD_COUNTS[code] ?? 4;
    model.tables.forEach((table) => {
      const rand = mulberry32(hashCode(`${model.modelUid}-${table.uid}`));
      for (let i = 0; i < count; i++) {
        const bbox = randomBBox(rand);
        const version = VERSIONS[i % VERSIONS.length];
        const dataLevel = DATA_LEVELS[i % DATA_LEVELS.length];
        const fields: Record<string, any> = {};
        table.fields.forEach((field) => {
          if (field.name === 'name') {
            fields[field.name] = `${SHORT_NAMES[label] ?? label}·${REGIONS[i % REGIONS.length]}·${String(i + 1).padStart(2, '0')}`;
          } else if (field.name === 'category') {
            fields[field.name] = label;
          } else if (field.name === 'version') {
            fields[field.name] = version;
          } else if (field.name === 'dataLevel') {
            fields[field.name] = dataLevel;
          } else if (field.name === 'updateTime') {
            fields[field.name] = formatDateTime(new Date(Date.now() - Math.floor(rand() * 86400000 * 60)));
          } else if (field.name === 'operator') {
            fields[field.name] = OPERATORS[Math.floor(rand() * OPERATORS.length)];
          } else if (field.name === 'storagePath') {
            fields[field.name] = `/data/primary/${code}/${SHORT_NAMES[label] ?? label}/${version}`;
          } else if (field.name === 'description') {
            fields[field.name] = `${label}初级产品 ${REGIONS[i % REGIONS.length]} 数据，共 1 个批次。`;
          } else {
            const gen = TYPE_VALUE_GENERATORS[field.type];
            fields[field.name] = gen ? gen(field, rand) : `${field.displayName}-${i + 1}`;
          }
        });
        records.push({
          id: id++,
          recordUid: `rec-${model.modelUid}-${table.uid}-${i + 1}`,
          modelUid: model.modelUid,
          tableUid: table.uid,
          tableName: table.name,
          category: label,
          name: fields.name ?? `${label}-${i + 1}`,
          version,
          dataLevel,
          region: REGIONS[i % REGIONS.length],
          bbox,
          description: fields.description ?? '',
          operator: fields.operator ?? '',
          createdAt: randomDate(rand),
          updatedAt: fields.updateTime ?? randomDate(rand),
          fields,
          checkStatus: i % 7 === 3 ? 'failed' : 'passed'
        });
      }
    });
  });
  return records;
}

function loadAll() {
  const models = readStorage<MetadataModel[]>(KEY.models, buildSeedModels);
  const templates = readStorage<MetadataTemplate[]>(KEY.templates, buildSeedTemplates);
  const records = readStorage<MetadataRecord[]>(KEY.records, () => buildSeedRecords(models));
  const productTypes = readStorage<ProductCategory[]>(KEY.productTypes, buildSeedProductTypes);
  const palette = readStorage<PaletteState>(KEY.paletteState, buildSeedPaletteState);
  const basemaps = readStorage<Basemap[]>(KEY.basemaps, buildSeedBasemaps);
  return { models, templates, records, productTypes, palette, basemaps };
}

interface MockDb {
  models: MetadataModel[];
  templates: MetadataTemplate[];
  records: MetadataRecord[];
  productTypes: ProductCategory[];
  palette: PaletteState;
  basemaps: Basemap[];
}

const db = loadAll();

export const mockDb: MockDb = db;

/* ------------------------------------------------------------------ */
/* 配置 → 模块 的派生查询（读实时 mockDb，产品类型管理增删改后立即生效）  */
/* ------------------------------------------------------------------ */

/** 当前配置的类别树（产品类型管理增删改后，模块侧选择器/筛选项随之变化） */
export function buildCategoryTree(): ProductCategory[] {
  return toCategoryTree(mockDb.productTypes);
}

/** 当前配置的顶级产品类别名（地图配色、图例与记录类别的对齐基准） */
export function productTypeNames(): string[] {
  return mockDb.productTypes.filter((type) => !type.parentCategoryUid).map((type) => type.categoryName);
}

/** 按 uid 在配置的类别树中递归查找（兼容顶级类别的「XX初级产品」叶子 uid） */
export function findCategory(uid: string): ProductCategory | undefined {
  const target = String(uid || '').replace(/-child-1$/, '');
  const walk = (nodes: ProductCategory[]): ProductCategory | undefined => {
    for (const node of nodes) {
      if (node.categoryUid === target) return node;
      const found = walk(node.children ?? []);
      if (found) return found;
    }
    return undefined;
  };
  return walk(buildCategoryTree());
}

export function persistModels() {
  saveStorage(KEY.models, db.models);
}

export function persistRecords() {
  saveStorage(KEY.records, db.records);
}

export function persistTemplates() {
  saveStorage(KEY.templates, db.templates);
}

export function persistProductTypes() {
  saveStorage(KEY.productTypes, db.productTypes);
}

export function persistPalette() {
  saveStorage(KEY.paletteState, db.palette);
}

export function persistBasemaps() {
  saveStorage(KEY.basemaps, db.basemaps);
}

/** 清空并重新生成演示数据 */
export function resetMetadataMock() {
  const models = buildSeedModels();
  const templates = buildSeedTemplates();
  const records = buildSeedRecords(models);
  db.models = models;
  db.templates = templates;
  db.records = records;
  db.productTypes = buildSeedProductTypes();
  db.palette = buildSeedPaletteState();
  db.basemaps = buildSeedBasemaps();
  persistModels();
  persistTemplates();
  persistRecords();
  persistProductTypes();
  persistPalette();
  persistBasemaps();
}

/** 依据模型自动生成「元数据表范例」记录（规格 1：自动生成元数据表范例） */
export function buildSampleRecordsForModel(model: MetadataModel, perTable = 3): MetadataRecord[] {
  const created: MetadataRecord[] = [];
  const label = model.productCategories?.[0]?.categoryName ?? '分类要素';
  const short = SHORT_NAMES[label] ?? label;
  model.tables.forEach((table) => {
    for (let i = 0; i < perTable; i++) {
      const rand = mulberry32(hashCode(`sample-${model.modelUid}-${table.uid}-${i}`));
      const bbox = randomBBox(rand);
      const version = VERSIONS[i % VERSIONS.length];
      const dataLevel = DATA_LEVELS[i % DATA_LEVELS.length];
      const fields: Record<string, any> = {};
      table.fields.forEach((field) => {
        if (field.name === 'name') {
          fields[field.name] = `${short} 范例数据 ${i + 1}`;
        } else if (field.name === 'category') {
          fields[field.name] = label;
        } else if (field.name === 'version') {
          fields[field.name] = version;
        } else if (field.name === 'dataLevel') {
          fields[field.name] = dataLevel;
        } else if (field.name === 'operator') {
          fields[field.name] = OPERATORS[0];
        } else if (field.name === 'updateTime') {
          fields[field.name] = formatDateTime(new Date());
        } else if (field.name === 'storagePath') {
          fields[field.name] = `/data/primary/${model.productCategoryIds[0] ?? 'sample'}/sample`;
        } else {
          const gen = TYPE_VALUE_GENERATORS[field.type];
          fields[field.name] = gen ? gen(field, rand) : `${field.displayName}-${i + 1}`;
        }
      });
      created.push({
        id: Date.now() + created.length + 1,
        recordUid: `rec-sample-${model.modelUid}-${table.uid}-${i + 1}-${Date.now()}`,
        modelUid: model.modelUid,
        tableUid: table.uid,
        tableName: table.name,
        category: label,
        name: fields.name ?? `${label}-范例-${i + 1}`,
        version,
        dataLevel,
        region: '北京市',
        bbox,
        description: fields.description ?? `${label}元数据表范例`,
        operator: fields.operator ?? OPERATORS[0],
        createdAt: formatDate(new Date()),
        updatedAt: fields.updateTime ?? formatDateTime(new Date()),
        fields,
        checkStatus: 'passed'
      });
    }
  });
  return created;
}

/* ------------------------------------------------------------------ */
/* 数据查询样本 enrich：在元数据记录上派生传感器/图号/分辨率等扩展字段   */
/* ------------------------------------------------------------------ */

const SENSOR_OPTIONS = ['GF-1', 'GF-2', 'GF-6', 'ZY-3', 'BJ-2', 'Sentinel-2'];
const RESOLUTION_OPTIONS = ['0.5m', '1m', '2m', '5m', '10m'];
const TILE_LEVEL_OPTIONS = ['L10', 'L12', 'L14', 'L16', 'L18'];
const TILE_SPEC_OPTIONS = ['256×256', '512×512', '1024×1024'];
const TRAINING_OPTIONS = ['已收敛', '训练中', '待优化', '过拟合'];
/** 影像成果类型（区别于产品类别 category） */
const SAMPLE_PRODUCT_TYPES = ['正射影像', '倾斜摄影', '矢量成果', '样本切片'];

function pick<T>(list: readonly T[], index: number): T {
  return list[index % list.length];
}

/**
 * 元数据记录 → 数据查询样本记录。
 * 以 record.id 为确定性索引（不依赖数组下标，records 增删后派生值仍稳定）。
 */
export function toSampleRecord(record: MetadataRecord): SampleRecord {
  const id = record.id;
  const sheetNo = `J50G${String(id).padStart(3, '0')}`;
  return {
    ...record,
    sensor: pick(SENSOR_OPTIONS, id),
    sheetNo,
    resolution: pick(RESOLUTION_OPTIONS, id),
    featureCode: `GB-2026-${String(id).padStart(2, '0')}`,
    tileLevel: pick(TILE_LEVEL_OPTIONS, id),
    tileSpec: pick(TILE_SPEC_OPTIONS, id),
    productType: pick(SAMPLE_PRODUCT_TYPES, id),
    taskId: `TASK-2026-${String(id).padStart(3, '0')}`,
    training: pick(TRAINING_OPTIONS, id),
    path: `/samples/${record.category}/sheet-${sheetNo}/${record.name}.tif`
  };
}

export function buildSampleRecords(records: MetadataRecord[]): SampleRecord[] {
  return records.map(toSampleRecord);
}

/* ------------------------------------------------------------------ */
/* 任务 / 版本 / 报告 种子数据（组件首次无本地缓存时经 service 拉取）     */
/* ------------------------------------------------------------------ */

/** 生命周期阶段状态（检查/入库/提取三阶段） */
interface StageState {
  check: CheckStatus;
  store: StoreStatus;
  extract: ExtractionStatus;
}

/** 单个产品类别的生命周期链派生信息（检查→入库→提取→版本→报告 共享） */
interface ProductChain {
  index: number;
  category: string;
  code: string;
  shortName: string;
  rootPath: string;
  recordCount: number;
  recordIds: number[];
  failedCount: number;
  version: string;
  baseVersion: string;
  dataLevel: string;
  operator: string;
  latestUpdatedAt: string;
  batchSeq: number;
  batch: string;
  extractBatch: string;
  stage: StageState;
}

/** 生命周期阶段档位：确定性分配，保证 check→store→extract 状态逻辑自洽 */
const STAGES: StageState[] = [
  { check: 'passed', store: 'completed', extract: 'completed' },
  { check: 'passed', store: 'running', extract: 'waiting' },
  { check: 'checking', store: 'waiting', extract: 'waiting' },
  { check: 'failed', store: 'error', extract: 'error' },
  { check: 'passed', store: 'completed', extract: 'running' },
  { check: 'passed', store: 'paused', extract: 'waiting' },
  { check: 'waiting', store: 'waiting', extract: 'waiting' },
  { check: 'passed', store: 'completed', extract: 'paused' },
  { check: 'waiting', store: 'waiting', extract: 'waiting' }
];

/** 由状态派生确定性进度：完成态 100、等待态 0、其余 20~90 的稳定中间值 */
function progressOf(status: string, seedKey: string) {
  if (status === 'passed' || status === 'completed') return 100;
  if (status === 'waiting') return 0;
  return 20 + Math.floor(mulberry32(hashCode(`${seedKey}-${status}`))() * 70);
}

/** 以配置的顶级产品类别为骨架，从 records 聚合每类的记录数/版本/密级/失败数/批次/阶段 */
function buildProductChains(records: MetadataRecord[]): ProductChain[] {
  return mockDb.productTypes
    .filter((type) => !type.parentCategoryUid)
    .map((type, index) => {
      const category = type.categoryName;
      const list = records.filter((record) => record.category === category);
      const code = type.categoryUid;
      const versions = [...new Set(list.map((record) => record.version))];
      const version = versions.length ? versions.slice().sort((a, b) => VERSIONS.indexOf(b) - VERSIONS.indexOf(a))[0] : VERSIONS[0];
      const publicCount = list.filter((record) => record.dataLevel === '公开').length;
      const batchSeq = Math.floor(index / 3);
      return {
        index,
        category,
        code,
        shortName: SHORT_NAMES[category] ?? category,
        rootPath: `/data/primary/${code}`,
        recordCount: list.length,
        recordIds: list.map((record) => record.id),
        failedCount: list.filter((record) => record.checkStatus === 'failed').length,
        version,
        baseVersion: VERSIONS[Math.max(0, VERSIONS.indexOf(version) - 1)],
        dataLevel: list.length && publicCount * 2 < list.length ? '内部' : '公开',
        operator: list[0]?.operator ?? OPERATORS[index % OPERATORS.length],
        latestUpdatedAt: list.length
          ? list
              .map((record) => record.updatedAt)
              .sort()
              .slice(-1)[0]
          : formatDateTime(new Date()),
        batchSeq,
        batch: `B-20260908-00${batchSeq + 1}`,
        extractBatch: `E-20260908-00${batchSeq + 1}`,
        stage: STAGES[index] ?? STAGES[0]
      };
    });
}

export function buildSeedCheckTasks(records: MetadataRecord[]): CheckTask[] {
  return buildProductChains(records).map((chain) => {
    const { check } = chain.stage;
    const progress = progressOf(check, chain.category);
    const seq = String(chain.index + 1).padStart(3, '0');
    let integrity: CheckResult = 'waiting';
    let accuracy: CheckResult = 'waiting';
    let message = '等待检查任务调度';
    let error: string | undefined;
    if (check === 'passed') {
      integrity = 'passed';
      accuracy = 'passed';
      message = '完整性、准确性检查通过，可进入数据入库';
    } else if (check === 'checking') {
      if (progress < 50) {
        integrity = 'checking';
        message = `正在进行完整性检查，已处理 ${progress}% 记录`;
      } else {
        integrity = 'passed';
        accuracy = 'checking';
        message = `完整性检查通过，正在进行准确性检查（${progress}%）`;
      }
    } else if (check === 'failed') {
      integrity = 'failed';
      message = `完整性检查失败，共 ${chain.recordCount} 条记录、${chain.failedCount} 条不合格`;
      error = `必填字段缺失或取值超范围，${chain.failedCount} 条记录未通过完整性校验`;
    }
    return {
      id: chain.index + 1,
      fileName: `${chain.code}-metadata-${seq}.xml`,
      productType: chain.category,
      rootPath: chain.rootPath,
      recordCount: chain.recordCount,
      progress,
      status: check,
      integrity,
      accuracy,
      message,
      error,
      batch: chain.batch,
      recordIds: chain.recordIds
    };
  });
}

export function buildSeedExtractionTasks(records: MetadataRecord[]): ExtractionTask[] {
  return buildProductChains(records).map((chain) => {
    const { extract } = chain.stage;
    const progress = progressOf(extract, chain.category);
    const seq = String(chain.index + 1).padStart(3, '0');
    const source = mulberry32(hashCode(`extract-${chain.category}`))() > 0.5 ? '业务系统需求' : '用户提交需求';
    let message = '等待任务调度';
    let error: string | undefined;
    if (extract === 'completed') {
      message = '数据已推送至申请方路径';
    } else if (extract === 'running') {
      message = `正在生成数据路径目录，当前进度 ${progress}%`;
    } else if (extract === 'paused') {
      message = '网络故障，任务已自动暂停';
    } else if (extract === 'error') {
      message = '上游检查未通过，无法提取';
      error = `关联检查任务失败（批次 ${chain.batch}），${chain.failedCount} 条记录不合格`;
    }
    return {
      id: chain.index + 1,
      name: `${chain.shortName}提取-${seq}`,
      productType: chain.category,
      batch: chain.extractBatch,
      requestSource: `${source}-${chain.category}-${seq}`,
      targetPath: `/delivery/${chain.code}-${seq}`,
      progress,
      status: extract,
      message,
      error,
      recordIds: chain.recordIds
    };
  });
}

export function buildSeedVersions(records: MetadataRecord[]): VersionRow[] {
  const changeTypes = ['数据更新', '属性修订', '结构变更'];
  return buildProductChains(records).map((chain) => {
    const changeType = changeTypes[chain.index % changeTypes.length];
    return {
      id: chain.index + 1,
      product: chain.shortName,
      category: chain.category,
      version: chain.version,
      baseVersion: chain.baseVersion,
      changeType,
      operator: chain.operator,
      updatedAt: chain.latestUpdatedAt,
      status: chain.stage.store === 'completed' ? '当前版本' : '历史版本',
      changes: `本次${changeType}覆盖 ${chain.recordCount} 条记录，来源批次 ${chain.batch}`,
      batch: chain.batch,
      recordCount: chain.recordCount
    };
  });
}

export function buildSeedReports(records: MetadataRecord[]): ReportRow[] {
  const chains = buildProductChains(records);
  const reports: ReportRow[] = [];

  /**
   * 汇总报告：以全部 records 聚合的类别数、记录数与最近更新时间，
   * 时间锚定在 records 真实 updatedAt 上，避免硬编码日期与数据脱节。
   */
  const latestUpdated = records.length
    ? records
        .map((record) => record.updatedAt)
        .sort()
        .slice(-1)[0]
    : formatDateTime(new Date());
  reports.push({
    id: 1,
    name: `${new Date().getFullYear()}年初级产品资产总报告`,
    products: `${chains.length} 类产品`,
    format: 'Docx',
    createdAt: latestUpdated,
    status: '已生成',
    totalRecords: records.length,
    categories: chains.map((chain) => chain.category)
  });

  /**
   * 单类产品报告：为每个有记录的类别生成独立报告，
   * 名称、记录数、最近更新时间全部来自该类的真实 records 聚合结果。
   */
  chains
    .filter((chain) => chain.recordCount > 0)
    .forEach((chain, index) => {
      reports.push({
        id: index + 2,
        name: `${chain.category}数据资产报告`,
        products: `${chain.recordCount} 条记录`,
        format: 'Docx',
        createdAt: chain.latestUpdatedAt,
        status: '已生成',
        totalRecords: chain.recordCount,
        categories: [chain.category]
      });
    });

  /**
   * 批次报告：按批次的类别聚合，列出该批次覆盖的类别名与合计记录数，
   * 时间取批次内最新记录的时间。
   */
  const batchSeqs = [...new Set(chains.map((chain) => chain.batchSeq))].sort((a, b) => a - b);
  batchSeqs.forEach((seq, i) => {
    const batchChains = chains.filter((chain) => chain.batchSeq === seq);
    if (!batchChains.length) return;
    const batchRecords = records.filter((record) => batchChains.some((chain) => chain.recordIds.includes(record.id)));
    const batchLatest = batchRecords.length
      ? batchRecords
          .map((record) => record.updatedAt)
          .sort()
          .slice(-1)[0]
      : batchChains[0].latestUpdatedAt;
    const batchName = batchChains[0].batch;
    reports.push({
      id: reports.length + 1,
      name: `批次 ${batchName} 入库资产报告`,
      products: batchChains.map((chain) => chain.category).join('、') || '（空批次）',
      format: 'Docx',
      createdAt: batchLatest,
      status: '已生成',
      totalRecords: batchChains.reduce((sum, chain) => sum + chain.recordCount, 0),
      categories: batchChains.map((chain) => chain.category),
      batch: batchName
    });
  });

  return reports;
}

/** 生成批次名：前缀-日期-毫秒尾三位（原 components/shared.ts 迁入） */
export function createBatchName(prefix: string) {
  return `${prefix}-${new Date().toISOString().slice(0, 10).replaceAll('-', '')}-${Date.now().toString().slice(-3)}`;
}
