/**
 * 数据集浏览 Mock 数据源
 *
 * 对应后端「图幅元数据」的 GeoJSON FeatureCollection：每个 Feature = 一个图幅数据集，
 * properties 保存完整属性表，geometry 描述覆盖范围。为控制文件体积，此处仅保留列表
 * 展示所需的摘要字段 + 详情展示所需的属性表（以 metaRecords 文本形式内联，前端解析）。
 *
 * metaRecords 每行形如 "序号\t中文名\t值"，parseMetaRecords 解析为 DatasetAttribute[]。
 * 生产环境应改为调用后端接口，本文件仅提供样本数据用于开发与演示。
 */

export interface DatasetAttribute {
  index: number;
  name: string;
  value: string;
}

export interface DatasetRecord {
  id: number;
  /** 图号（如 DN06510251） */
  zoneNumber: string;
  /** 产品类别名（与产品类别树顶级节点 categoryName 对齐，供类别树过滤） */
  category: string;
  /** 图名（部分数据为 NULL） */
  graphName: string;
  /** 产品生产单位 */
  manufactureInstitution: string;
  /** 产品生产日期（YYYYMMDD） */
  manuDate: string;
  /** 地图比例尺分母（50000 表示 1:5万） */
  mapScale: number;
  /** 数据质量总评价 */
  qualityEvaluate: string;
  /** 大地基准 */
  geodeticDatum: string;
  /** 坐标单位 */
  coordUnit: string;
  /** 空间范围 [minLng, minLat, maxLng, maxLat] */
  bbox: [number, number, number, number];
  /** 完整属性表（由 metaRecords 解析而来） */
  attributes: DatasetAttribute[];
}

/** 解析 "序号\t中文名\t值" 形式的 metaRecords 文本为结构化属性数组 */
function parseMetaRecords(text: string): DatasetAttribute[] {
  if (!text) return [];
  return text
    .split('\n')
    .map((line) => {
      const parts = line.split('\t');
      return {
        index: Number(parts[0]),
        name: parts[1] ?? '',
        value: parts.slice(2).join('\t')
      };
    })
    .filter((item) => !Number.isNaN(item.index) && item.name);
}

const M1 =
  '1\t产品生产单位\t某某生产测绘单位\n2\t产品生产日期\t20220324\n3\t产品更新日期\tNULL\n4\t参照图式编号\tGJB414A-2004\n5\t参照要素分类编码编号\tGJB1839B-2012\n6\t图名\tNULL\n7\t图号\tDN06510251\n8\t图幅等高距\t20\n9\t地图比例尺分母\t50000\n10\t图廓角点经度范围\t1200353-1201500\n11\t图廓角点纬度范围\t231001-231958\n12\t西南图廓角点横坐标\t13365567.29\n13\t西南图廓角点纵坐标\t2652226.97\n14\t东南图廓角点横坐标\t13386168.77\n15\t东南图廓角点纵坐标\t2652226.97\n16\t东北图廓角点横坐标\t13386168.77\n17\t东北图廓角点纵坐标\t2672339.13\n18\t西北图廓角点横坐标\t13365567.29\n19\t西北图廓角点纵坐标\t2672339.13\n20\t椭球长半径\t6378137.00\n21\t椭球扁率\t0.003352811\n22\t大地基准\tWGS_1984\n23\t地图投影\tWeb墨卡托\n24\t中央经线\t0\n27\t分带方式\t6度带\n29\t坐标单位\t米\n30\t坐标维数\t2\n37\t高程系统名\t正常高\n38\t高程基准\t1985国家高程基准\n39\t深度基准\t理论最低潮面\n47\t影像地面分辨率\t0.500000\n48\t数据来源\tOpenStreetMap\n71\t西边接边状况\t已接\n72\t北边接边状况\t已接\n73\t东边接边状况\t已接\n74\t南边接边状况\t已接\n77\t属性精度\t符合要求\n78\t逻辑一致性\t一致\n79\t完整性\t完整\n80\t接边质量评价\t合格\n81\t结论总分\t85\n84\t数据质量总评价\t良好\n93\t政区说明\t中国、云南省、临沧市、镇康县、缅甸、掸邦\n94\t总层数\t10';
const M2 =
  '1\t产品生产单位\t某某生产测绘单位\n2\t产品生产日期\t20220324\n3\t产品更新日期\tNULL\n4\t参照图式编号\tGJB414A-2004\n5\t参照要素分类编码编号\tGJB1839B-2012\n6\t图名\tNULL\n7\t图号\tDN06510252\n8\t图幅等高距\t20\n9\t地图比例尺分母\t50000\n10\t图廓角点经度范围\t1201500-1203000\n11\t图廓角点纬度范围\t231001-231958\n12\t西南图廓角点横坐标\t13386168.77\n13\t西南图廓角点纵坐标\t2652226.97\n14\t东南图廓角点横坐标\t13413997.79\n15\t东南图廓角点纵坐标\t2652226.97\n16\t东北图廓角点横坐标\t13413997.79\n17\t东北图廓角点纵坐标\t2672339.36\n18\t西北图廓角点横坐标\t13386168.77\n19\t西北图廓角点纵坐标\t2672339.36\n22\t大地基准\tWGS_1984\n23\t地图投影\tWeb墨卡托\n24\t中央经线\t0\n27\t分带方式\t6度带\n29\t坐标单位\t米\n30\t坐标维数\t2\n37\t高程系统名\t正常高\n38\t高程基准\t1985国家高程基准\n39\t深度基准\t理论最低潮面\n47\t影像地面分辨率\t0.500000\n48\t数据来源\tOpenStreetMap\n71\t西边接边状况\t已接\n72\t北边接边状况\t已接\n73\t东边接边状况\t已接\n74\t南边接边状况\t已接\n77\t属性精度\t符合要求\n78\t逻辑一致性\t一致\n79\t完整性\t完整\n80\t接边质量评价\t合格\n81\t结论总分\t85\n84\t数据质量总评价\t良好\n93\t政区说明\t中国、云南省、临沧市、镇康县、缅甸、掸邦\n94\t总层数\t9';
const M3 =
  '1\t产品生产单位\t某某生产测绘单位\n2\t产品生产日期\t20220324\n3\t产品更新日期\tNULL\n4\t参照图式编号\tGJB414A-2004\n5\t参照要素分类编码编号\tGJB1839B-2012\n6\t图名\tNULL\n7\t图号\tDN06510253\n8\t图幅等高距\t20\n9\t地图比例尺分母\t50000\n10\t图廓角点经度范围\t1200201-1201500\n11\t图廓角点纬度范围\t230000-231001\n12\t西南图廓角点横坐标\t13362093.65\n13\t西南图廓角点纵坐标\t2632018.64\n14\t东南图廓角点横坐标\t13386168.77\n15\t东南图廓角点纵坐标\t2632018.64\n16\t东北图廓角点横坐标\t13386168.77\n17\t东北图廓角点纵坐标\t2652226.74\n18\t西北图廓角点横坐标\t13362093.65\n19\t西北图廓角点纵坐标\t2652226.74\n22\t大地基准\tWGS_1984\n23\t地图投影\tWeb墨卡托\n24\t中央经线\t0\n27\t分带方式\t6度带\n29\t坐标单位\t米\n30\t坐标维数\t2\n37\t高程系统名\t正常高\n38\t高程基准\t1985国家高程基准\n39\t深度基准\t理论最低潮面\n47\t影像地面分辨率\t0.500000\n48\t数据来源\tOpenStreetMap\n71\t西边接边状况\t已接\n72\t北边接边状况\t已接\n73\t东边接边状况\t已接\n74\t南边接边状况\t已接\n77\t属性精度\t符合要求\n78\t逻辑一致性\t一致\n79\t完整性\t完整\n80\t接边质量评价\t合格\n81\t结论总分\t85\n84\t数据质量总评价\t良好\n93\t政区说明\t中国、云南省、临沧市、镇康县、缅甸、掸邦\n94\t总层数\t10';
const M4 =
  '1\t产品生产单位\t某某生产测绘单位\n2\t产品生产日期\t20220324\n3\t产品更新日期\tNULL\n4\t参照图式编号\tGJB414A-2004\n5\t参照要素分类编码编号\tGJB1839B-2012\n6\t图名\tNULL\n7\t图号\tDN06510254\n8\t图幅等高距\t20\n9\t地图比例尺分母\t50000\n10\t图廓角点经度范围\t1201500-1203000\n11\t图廓角点纬度范围\t230000-231001\n12\t西南图廓角点横坐标\t13386168.77\n13\t西南图廓角点纵坐标\t2632018.64\n14\t东南图廓角点横坐标\t13413998.64\n15\t东南图廓角点纵坐标\t2632018.64\n16\t东北图廓角点横坐标\t13413998.64\n17\t东北图廓角点纵坐标\t2652226.97\n18\t西北图廓角点横坐标\t13386168.77\n19\t西北图廓角点纵坐标\t2652226.97\n22\t大地基准\tWGS_1984\n23\t地图投影\tWeb墨卡托\n24\t中央经线\t0\n27\t分带方式\t6度带\n29\t坐标单位\t米\n30\t坐标维数\t2\n37\t高程系统名\t正常高\n38\t高程基准\t1985国家高程基准\n39\t深度基准\t理论最低潮面\n47\t影像地面分辨率\t0.500000\n48\t数据来源\tOpenStreetMap\n71\t西边接边状况\t已接\n72\t北边接边状况\t已接\n73\t东边接边状况\t已接\n74\t南边接边状况\t已接\n77\t属性精度\t符合要求\n78\t逻辑一致性\t一致\n79\t完整性\t完整\n80\t接边质量评价\t合格\n81\t结论总分\t85\n84\t数据质量总评价\t良好\n93\t政区说明\t中国、云南省、临沧市、镇康县、缅甸、掸邦\n94\t总层数\t8';

export const DATASET_RECORDS: DatasetRecord[] = [
  {
    id: 1,
    zoneNumber: 'DN06510251',
    category: '交通',
    graphName: 'DN06510251',
    manufactureInstitution: '某某生产测绘单位',
    manuDate: '20220324',
    mapScale: 50000,
    qualityEvaluate: '良好',
    geodeticDatum: 'WGS_1984',
    coordUnit: '米',
    bbox: [120.06472222222222, 23.166944444444447, 120.25, 23.332777777777778],
    attributes: parseMetaRecords(M1)
  },
  {
    id: 2,
    zoneNumber: 'DN06510252',
    category: '交通',
    graphName: 'DN06510252',
    manufactureInstitution: '某某生产测绘单位',
    manuDate: '20220324',
    mapScale: 50000,
    qualityEvaluate: '良好',
    geodeticDatum: 'WGS_1984',
    coordUnit: '米',
    bbox: [120.25, 23.166944444444447, 120.5, 23.332777777777778],
    attributes: parseMetaRecords(M2)
  },
  {
    id: 3,
    zoneNumber: 'DN06510253',
    category: '交通',
    graphName: 'DN06510253',
    manufactureInstitution: '某某生产测绘单位',
    manuDate: '20220324',
    mapScale: 50000,
    qualityEvaluate: '良好',
    geodeticDatum: 'WGS_1984',
    coordUnit: '米',
    bbox: [120.03361111111111, 23.0, 120.25, 23.166944444444447],
    attributes: parseMetaRecords(M3)
  },
  {
    id: 4,
    zoneNumber: 'DN06510254',
    category: '交通',
    graphName: 'DN06510254',
    manufactureInstitution: '某某生产测绘单位',
    manuDate: '20220324',
    mapScale: 50000,
    qualityEvaluate: '良好',
    geodeticDatum: 'WGS_1984',
    coordUnit: '米',
    bbox: [120.25, 23.0, 120.5, 23.166944444444447],
    attributes: parseMetaRecords(M4)
  }
];
