/**
 * 产品成果管理模块领域类型
 *
 * 包含：模块枚举、子类型枚举、目标库映射、归档状态、
 * 记录类型、样本与模型类型、任务类型、表单类型
 */
import type { MetadataRecord } from './index';

/* ============================================================
 * 产品成果模块类型
 * ============================================================ */
/** 产品成果的 6 个模块（顶层分类） */
export const RESULT_MODULE_TYPES = [
  '分类要素产品成果',
  '分类要素属性产品成果',
  '地质要素产品成果',
  'lh融合产品成果',
  '样本与模型成果',
  '矢量组网产品成果'
] as const;
/** 产品成果模块类型 */
export type ResultModuleType = (typeof RESULT_MODULE_TYPES)[number];

/** 产品成果模块的下拉选项（label = value = 模块名） */
export const RESULT_MODULE_TYPE_OPTIONS = RESULT_MODULE_TYPES.map((v) => ({ label: v, value: v }));

/* ============================================================
 * 各模块的子类型
 * ============================================================ */

/** 分类要素产品成果（6 种） */
export const CLASSIFICATION_RESULT_TYPES = [
  '分类要素矢量产品(GDB)',
  '分类要素标准分幅产品(GJB入库)',
  '注记要素产品',
  'lh专题图产品',
  '地表覆盖产品',
  '变化检测产品'
] as const;

/** 分类要素属性产品成果（2 种） */
export const ATTRIBUTE_RESULT_TYPES = ['人文地理产品', '互联网挖掘产品'] as const;

/** 地质要素产品成果（3 种） */
export const GEOLOGY_RESULT_TYPES = ['民用基础地质数据', '地质基础数据', '地质专题数据'] as const;

/** lh融合产品成果（7 种） */
export const LH_RESULT_TYPES = ['浅海典型地理要素', '浅海水下激光控制点', '垂直基准转换模型', '浅海地理信息', '水深地形', '海岸线精化'] as const;

/** 样本与模型成果（14 种） */
export const MODEL_SAMPLE_TYPES = [
  '交通',
  '水系',
  '居民地',
  '植被',
  '要素',
  '重要设施',
  '地表覆盖',
  '三维建筑物',
  '变化检测',
  '岩土体',
  '灾害地质',
  '矿产资源',
  '潮间带地理信息',
  '浅海典型海底底质'
] as const;
/** 样本与模型成果子类型的下拉选项 */
export const MODEL_SAMPLE_TYPE_OPTIONS = MODEL_SAMPLE_TYPES.map((v) => ({ label: v, value: v }));

/** 矢量组网产品成果（1 种） */
export const VECTOR_NETWORK_RESULT_TYPE = 'qq地理信息组网框架产品';

/** 模块 → 子类型 映射 */
export const MODULE_RESULT_TYPES: Record<ResultModuleType, readonly string[]> = {
  分类要素产品成果: CLASSIFICATION_RESULT_TYPES,
  分类要素属性产品成果: ATTRIBUTE_RESULT_TYPES,
  地质要素产品成果: GEOLOGY_RESULT_TYPES,
  lh融合产品成果: LH_RESULT_TYPES,
  样本与模型成果: MODEL_SAMPLE_TYPES,
  矢量组网产品成果: [VECTOR_NETWORK_RESULT_TYPE]
};

/* ============================================================
 * 子类型 → 目标产品库
 * ============================================================ */
export const RESULT_TARGET_LIB: Record<string, string> = {
  '分类要素矢量产品(GDB)': '矢量产品库',
  '分类要素标准分幅产品(GJB入库)': '分幅产品库',
  '注记要素产品': '注记要素产品库',
  'lh专题图产品': 'lh专题图产品库',
  '地表覆盖产品': '地表覆盖产品库',
  '变化检测产品': '变化检测产品库',
  '人文地理产品': '人文地理产品成果库',
  '互联网挖掘产品': '互联网挖掘产品成果库',
  '民用基础地质数据': '民用基础地质数据产品库',
  '地质基础数据': '地质基础数据产品库',
  '地质专题数据': '地质专题数据产品库',
  '浅海典型地理要素': '浅海典型地理要素产品库',
  '浅海水下激光控制点': '浅海水下激光控制点产品库',
  '垂直基准转换模型': '垂直基准转换模型产品库',
  '浅海地理信息': '浅海地理信息产品库',
  '水深地形': '水深地形产品库',
  '海岸线精化': '海岸线精化产品库',
  [VECTOR_NETWORK_RESULT_TYPE]: '矢量组网产品成果库'
};

/* ============================================================
 * 归档状态（qqpt 侧）
 * ============================================================ */
export type ArchiveStatus = 'pending' | 'archiving' | 'archived' | 'failed';

/** 归档状态 → 显示文案与标签色 */
export const ARCHIVE_STATUS_MAP: Record<
  ArchiveStatus,
  {
    label: string;
    type: 'info' | 'primary' | 'success' | 'danger';
    color: string;
  }
> = {
  pending: { label: '待归档', type: 'info', color: '#909399' },
  archiving: { label: '归档中', type: 'primary', color: '#409eff' },
  archived: { label: '已归档', type: 'success', color: '#67c23a' },
  failed: { label: '归档失败', type: 'danger', color: '#f56c6c' }
};

/* ============================================================
 * 产品成果记录
 * ============================================================ */
export interface ResultRecord extends MetadataRecord {
  /** 所属产品成果模块 */
  moduleType: ResultModuleType;
  /** 子类型（模块内细分产品类型） */
  resultType: string;
  /** 归档状态 */
  archiveStatus: ArchiveStatus;
  /** 归档任务 id（已发起归档时有值） */
  archiveId?: string;
  /** 归档完成时间 */
  archivedAt?: string;
  /** 目标产品库名称（由子类型映射而来） */
  targetLib?: string;
  /** 归档失败原因 */
  archiveError?: string;
}

/* ============================================================
 * 样本与模型成果
 * ============================================================ */
export type TrainingState = '已收敛' | '训练中' | '待优化' | '过拟合';

/** 样本与模型成果中的模型记录 */
export interface ModelResult {
  /** 主键 */
  id: number;
  /** 模型名称 */
  name: string;
  /** 产品类别 */
  category: string;
  /** 传感器类型 */
  sensor: string;
  /** 要素编码 */
  featureCode: string;
  /** 训练算法 */
  algorithm: string;
  /** 产品类型 */
  productType: string;
  /** 精度指标（百分比） */
  accuracy: number;
  /** 模型版本号 */
  version: string;
  /** 模型文件大小（含单位的可读字符串） */
  size: string;
  /** 训练状态 */
  training: TrainingState;
  /** 累计使用次数 */
  usageCount: number;
  /** 模型文件存储路径 */
  path: string;
  /** 归档状态 */
  archiveStatus: ArchiveStatus;
  /** 模型描述 */
  description: string;
  /** 创建时间 */
  createdAt: string;
  /** 最后更新时间 */
  updatedAt: string;
}

/** 样本与模型成果中的样本记录 */
export interface SampleResult {
  /** 主键 */
  id: number;
  /** 样本名称 */
  name: string;
  /** 产品类别 */
  category: string;
  /** 传感器类型 */
  sensor: string;
  /** 图幅号 */
  sheetNo: string;
  /** 分辨率 */
  resolution: string;
  /** 要素编码 */
  featureCode: string;
  /** 瓦片层级 */
  tileLevel: string;
  /** 瓦片规格 */
  tileSpec: string;
  /** 产品类型 */
  productType: string;
  /** 瓦片数量 */
  tileCount: number;
  /** 影像存储路径 */
  imagePath: string;
  /** 标注文件路径 */
  labelPath: string;
  /** 报告文件路径 */
  reportPath: string;
  /** 空间范围 [minLng, minLat, maxLng, maxLat] */
  bbox: [number, number, number, number];
  /** 累计使用次数 */
  usageCount: number;
  /** 归档状态 */
  archiveStatus: ArchiveStatus;
  /** 创建时间 */
  createdAt: string;
  /** 最后更新时间 */
  updatedAt: string;
}

/* ============================================================
 * 任务状态
 * ============================================================ */
export type ResultTaskStatus = 'waiting' | 'running' | 'paused' | 'completed' | 'error';

/* ============================================================
 * 三种任务类型
 * ============================================================ */

/** 数据入库任务 */
export interface ResultStoreTask {
  /** 任务主键 */
  id: number;
  /** 任务名称 */
  name: string;
  /** 所属产品成果模块 */
  moduleType: ResultModuleType;
  /** 子类型 */
  resultType: string;
  /** 批次号 */
  batch: string;
  /** 数据密级 */
  dataLevel: string;
  /** 数据来源 */
  source: string;
  /** 目标产品库 */
  targetLib: string;
  /** 进度百分比（0-100） */
  progress: number;
  /** 任务状态 */
  status: ResultTaskStatus;
  /** 归档状态 */
  archiveStatus: ArchiveStatus;
  /** 归档任务 id */
  archiveId?: string;
  /** 状态描述信息 */
  message: string;
  /** 错误信息（失败时有值） */
  error?: string;
  /** 关联的元数据记录 id 列表（生命周期链） */
  recordIds?: number[];
}

/** 数据提取任务 */
export interface ResultExtractionTask {
  /** 任务主键 */
  id: number;
  /** 任务名称 */
  name: string;
  /** 所属产品成果模块 */
  moduleType: ResultModuleType;
  /** 子类型 */
  resultType: string;
  /** 批次号 */
  batch: string;
  /** 请求来源 */
  requestSource: string;
  /** 提取结果的目标路径 */
  targetPath: string;
  /** 进度百分比（0-100） */
  progress: number;
  /** 任务状态 */
  status: ResultTaskStatus;
  /** 归档状态 */
  archiveStatus: ArchiveStatus;
  /** 归档任务 id */
  archiveId?: string;
  /** 状态描述信息 */
  message: string;
  /** 错误信息（失败时有值） */
  error?: string;
  /** 关联的元数据记录 id 列表（生命周期链） */
  recordIds?: number[];
}

/** 数据更新任务 */
export interface ResultUpdateTask {
  /** 任务主键 */
  id: number;
  /** 任务名称 */
  name: string;
  /** 所属产品成果模块 */
  moduleType: ResultModuleType;
  /** 子类型 */
  resultType: string;
  /** 批次号 */
  batch: string;
  /** 更新来源 */
  source: string;
  /** 目标产品库 */
  targetLib: string;
  /** 进度百分比（0-100） */
  progress: number;
  /** 任务状态 */
  status: ResultTaskStatus;
  /** 归档状态 */
  archiveStatus: ArchiveStatus;
  /** 归档任务 id */
  archiveId?: string;
  /** 状态描述信息 */
  message: string;
  /** 错误信息（失败时有值） */
  error?: string;
  /** 关联的元数据记录 id 列表（生命周期链） */
  recordIds?: number[];
}

/* ============================================================
 * 三种表单类型
 * ============================================================ */

/** 数据入库表单 */
export interface ResultStoreForm {
  /** 数据来源地址 */
  url: string;
  /** 批次号 */
  batch: string;
  /** 所属产品成果模块 */
  moduleType: ResultModuleType;
  /** 待入库的子类型（可多选） */
  resultTypes: string[];
  /** 优先级（数值越大越优先） */
  priority: number;
}

/** 数据提取表单 */
export interface ResultExtractionForm {
  /** 任务名称 */
  name: string;
  /** 批次号 */
  batch: string;
  /** 所属产品成果模块 */
  moduleType: ResultModuleType;
  /** 待提取的子类型（可多选） */
  resultTypes: string[];
  /** 请求来源 */
  requestSource: string;
  /** 提取结果的目标路径 */
  targetPath: string;
  /** 优先级（数值越大越优先） */
  priority: number;
}

/** 数据更新表单 */
export interface ResultUpdateForm {
  /** 任务名称 */
  name: string;
  /** 批次号 */
  batch: string;
  /** 所属产品成果模块 */
  moduleType: ResultModuleType;
  /** 待更新的子类型（可多选） */
  resultTypes: string[];
  /** 更新来源 */
  source: string;
  /** 目标产品库 */
  targetLib: string;
  /** 优先级（数值越大越优先） */
  priority: number;
}
