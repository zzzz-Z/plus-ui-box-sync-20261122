/**
 * 元数据管理模块领域类型
 *
 * 这些类型同时服务于「模型管理、抽取、编辑、浏览、查询、检查」等功能面板，
 * 并保持与现有 Pont 服务返回结构（modelUid/modelName/productCategories 等）兼容，
 * 便于日后将 Mock 门面切换回真实接口。
 */

/** 元数据类别：结构 / 管理 / 发现 / 应用 */
export const MODEL_CATEGORIES = ['结构', '管理', '发现', '应用'] as const;
/** 元数据类别（结构 / 管理 / 发现 / 应用） */
export type ModelCategory = (typeof MODEL_CATEGORIES)[number];

/** 元数据类别的下拉选项（label = value = 类别名） */
export const MODEL_CATEGORY_OPTIONS = MODEL_CATEGORIES.map((value) => ({ label: value, value }));

/** 字段类型（含校验所需的取值范围/约束） */
export const FIELD_TYPES = ['string', 'integer', 'decimal', 'date', 'datetime', 'enum', 'coordinate', 'path', 'level'] as const;
/** 字段类型（文本/整型/小数/日期/日期时间/枚举/坐标/存储路径/数据级别） */
export type FieldType = (typeof FIELD_TYPES)[number];

/** 字段类型 → 中文显示名 */
export const FIELD_TYPE_LABELS: Record<FieldType, string> = {
  string: '文本',
  integer: '整型',
  decimal: '小数',
  date: '日期',
  datetime: '日期时间',
  enum: '枚举',
  coordinate: '坐标',
  path: '存储路径',
  level: '数据级别'
};

/** 产品类别（树形结构，供分类选择与地图配色使用） */
export interface ProductCategory {
  /** 类别唯一标识 */
  categoryUid: string;
  /** 类别名称（展示用） */
  categoryName: string;
  /** 类别编码（产品类型管理维护） */
  categoryKey?: string;
  /** 描述（产品类型管理维护） */
  description?: string;
  /** 上级类别 uid（产品类型管理维护；为空即顶级类别） */
  parentCategoryUid?: string;
  /** 子类别列表（树形结构；叶子节点无此字段） */
  children?: ProductCategory[];
}

/** 元数据模型字段定义 */
export interface ModelField {
  /** 字段唯一标识 */
  uid: string;
  /** 字段名（英文标识，对应记录 fields 的 key） */
  name: string;
  /** 字段显示名（中文，供表单/表头展示） */
  displayName: string;
  /** 字段类型（决定校验与控件形态） */
  type: FieldType;
  /** 字段长度（字符串类字段的上限） */
  length?: number;
  /** 是否可为空 */
  nullable: boolean;
  /** 取值范围（如 1-50、0-100、枚举列表） */
  range?: string;
  /** 约束条件说明（如 必填、正则等） */
  constraint?: string;
  /** 备注 */
  description?: string;
  /** 枚举选项 */
  options?: string[];
  /** 默认值 */
  defaultValue?: unknown;
}

/** 元数据模型表（一类数据可对应多个元数据模型表） */
export interface ModelTable {
  /** 表唯一标识 */
  uid: string;
  /** 表名（对应记录 tableName） */
  name: string;
  /** 备注 */
  remark?: string;
  /** 该表包含的字段定义 */
  fields: ModelField[];
}

/** 元数据模型 */
export interface MetadataModel {
  /** 模型唯一标识 */
  modelUid: string;
  /** 模型名称（展示用） */
  modelName: string;
  /** 模型编码（英文标识，用于接口与关联） */
  modelKey: string;
  /** 模型所属元数据类别 */
  modelCategory: ModelCategory;
  /** 模型描述 */
  description?: string;
  /** 关联的产品类别 id */
  productCategoryIds: string[];
  /** 关联的产品类别（冗余展示用） */
  productCategories?: ProductCategory[];
  /** 模型包含的元数据表定义 */
  tables: ModelTable[];
  /** 是否仅管理员可修改（规格：模型创建后保持相对固定） */
  locked?: boolean;
  /** 创建/最后修改人 */
  operator: string;
  /** 创建时间 */
  createdAt: string;
  /** 最后更新时间 */
  updatedAt: string;
}

/** 元数据模型模板 */
export interface MetadataTemplate {
  /** 模板唯一标识 */
  templateUid: string;
  /** 模板名称（作为新建模型的默认名） */
  modelName: string;
  /** 模板描述 */
  description?: string;
  /** 模板所属元数据类别 */
  modelCategory: ModelCategory;
  /** 模板预置的表与字段定义 */
  tables: ModelTable[];
}

/** 元数据记录（元数据表的一行），bbox 用于地图模式绘制元数据矩形 */
export interface MetadataRecord {
  /** 自增主键（前端列表 key） */
  id: number;
  /** 记录唯一标识 */
  recordUid: string;
  /** 所属模型 uid */
  modelUid: string;
  /** 所属表 uid */
  tableUid: string;
  /** 所属表名 */
  tableName: string;
  /** 产品类别名（地图配色键） */
  category: string;
  /** 记录名称 */
  name: string;
  /** 数据版本号 */
  version: string;
  /** 数据密级 */
  dataLevel: '公开' | '内部';
  /** 覆盖区域 */
  region: string;
  /** 空间范围 [minLng, minLat, maxLng, maxLat] */
  bbox: [number, number, number, number];
  /** 记录描述 */
  description: string;
  /** 操作人 */
  operator: string;
  /** 创建时间 */
  createdAt: string;
  /** 最后更新时间 */
  updatedAt: string;
  /** 模型表字段值，key = ModelField.name */
  fields: Record<string, any>;
  /** 检查状态：完整性/准确性是否通过 */
  checkStatus?: 'passed' | 'failed' | 'pending';
  /** 检查失败原因（checkStatus = failed 时有值） */
  errorMessage?: string;
}

/** 元数据记录列表查询参数 */
export interface RecordQueryParams {
  /** 关键字（匹配名称/描述等） */
  keyword?: string;
  /** 产品类别过滤 */
  category?: string;
  /** 数据密级过滤 */
  dataLevel?: string;
  /** 版本号过滤 */
  version?: string;
  /** 区域过滤 */
  region?: string;
  /** 所属表过滤 */
  tableUid?: string;
  /** 所属模型过滤 */
  modelUid?: string;
}

/* ------------------------------------------------------------------ */
/* 分类要素初级产品：产品类别常量                                        */
/* ------------------------------------------------------------------ */

/** 分类要素初级产品 9 类产品类别（与地图配色键、mock 记录 category 一致） */
export const PRODUCT_TYPES = ['交通', '水系', '居民地', '植被', '地表覆盖', '三维建筑物', '岩土体', '灾害地质', '矿产资源'] as const;
/** 分类要素初级产品的 9 类产品类别 */
export type ProductType = (typeof PRODUCT_TYPES)[number];

/** 产品类别的下拉选项（label = value = 类别名） */
export const PRODUCT_TYPE_OPTIONS = PRODUCT_TYPES.map((type) => ({ label: type, value: type }));
/** 产品类别列表（可写副本，供需要可变数组的场景） */
export const PRODUCT_CATEGORIES = [...PRODUCT_TYPES];

/* ------------------------------------------------------------------ */
/* 系统管理 · 电子地图底图                                               */
/* ------------------------------------------------------------------ */

/** 底图类型：XYZ 栅格 / WMS 服务 / WMTS 瓦片模板 / 离线（本地内置矢量） */
export type BasemapType = 'xyz' | 'wms' | 'wmts' | 'offline';

/** 电子地图底图配置（XYZ / WMS / WMTS） */
export interface Basemap {
  /** 底图唯一标识 */
  uid: string;
  /** 底图名称 */
  name: string;
  /** 底图类型 */
  type: BasemapType;
  /** XYZ/WMTS 使用 {z}/{x}/{y} 占位符；WMS 为 GetMap 服务 URL */
  url: string;
  /** 瓦片尺寸（像素，常用 256 / 512） */
  tileSize: number;
  /** WMS：图层（workspace:layer） */
  wmsLayers?: string;
  /** WMS：样式 */
  wmsStyles?: string;
  /** WMS：图片格式（image/png 等） */
  wmsFormat?: string;
  /** WMS：版本（1.1.1 / 1.3.0） */
  wmsVersion?: string;
  /** WMS：透明背景 */
  wmsTransparent?: boolean;
  /** 底图描述 */
  description?: string;
  /**
   * 是否默认地理底图（实测 2026-11-03：GET /platform/basemaps 必返，文档 required 未列）。
   * 未删除底图中最多一条为 true；地图组件应选 isDefault=true 的底图。
   * 声明为可选：列表历史数据/其它端点可能不带。
   */
  isDefault?: boolean;
}

/**
 * 数据查询样本记录：在元数据记录基础上补充传感器/图号/分辨率等扩展字段，
 * 由 mock 层 toSampleRecord 以 record.id 为确定性索引派生，供数据查询列表使用。
 */
export interface SampleRecord extends MetadataRecord {
  /** 传感器类型 */
  sensor: string;
  /** 图幅号 */
  sheetNo: string;
  /** 分辨率 */
  resolution: string;
  /** 要素编码 */
  featureCode: string;
  /** 瓦片层级 */
  tileLevel: string;
  /** 瓦片规格 */
  tileSpec: string;
  /** 影像成果类型（正射影像/倾斜摄影/矢量成果/样本切片），区别于产品类别 category */
  productType: string;
  /** 关联任务 id */
  taskId: string;
  /** 训练状态 */
  training: string;
  /** 存储路径 */
  path: string;
  /** 资源状态（后端出参为中文：就绪/待处理等；来自 /platform/resources） */
  state?: string;
  /** 数据条数（来自 /platform/resources） */
  dataCount?: number;
  /** 版本数（来自 /platform/resources） */
  versionCount?: number;
}

/* ------------------------------------------------------------------ */
/* 元数据检查任务                                                       */
/* ------------------------------------------------------------------ */

export type CheckStatus = 'waiting' | 'checking' | 'passed' | 'failed';
/** 单项检查结果（完整性 / 准确性各自的结论） */
export type CheckResult = 'waiting' | 'checking' | 'passed' | 'failed';

/** 元数据检查任务（完整性 + 准确性检查） */
export interface CheckTask {
  /** 任务主键 */
  id: number;
  /** 检查文件名 */
  fileName: string;
  /** 产品类型 */
  productType: string;
  /** 根目录路径 */
  rootPath: string;
  /** 记录条数 */
  recordCount: number;
  /** 进度百分比（0-100） */
  progress: number;
  /** 任务状态 */
  status: CheckStatus;
  /** 完整性检查结果 */
  integrity: CheckResult;
  /** 准确性检查结果 */
  accuracy: CheckResult;
  /** 状态描述信息 */
  message: string;
  /** 错误信息（失败时有值） */
  error?: string;
  /** 关联入库/提取批次号（生命周期链） */
  batch?: string;
  /** 关联的元数据记录 id 列表（生命周期链） */
  recordIds?: number[];
  /**
   * 执行真实检查所需：元数据模型 uid（POST /checks/structure 与 /checks/values 的入参）。
   * 任务若不带此字段，则执行检查动作回退到 mock 假进度模式（用于演示数据）。
   */
  modelUid?: string;
  /** 执行真实检查所需：资产版本 uid */
  assetVersionUid?: string;
}

/** 待检查的本地数据文件（名称 + 大小） */
export interface CheckFormFile {
  /** 文件名 */
  name: string;
  /** 文件大小（字节） */
  size: number;
}

/** 元数据检查表单 */
export interface CheckForm {
  /** 待检查的产品类型（可多选） */
  productTypes: string[];
  /** 数据根目录路径 */
  rootPath: string;
  /** 是否递归扫描子目录 */
  recursive: boolean;
  /** 本地数据文件（可选）；上传后按文件逐个创建检查任务，与 rootPath 至少提供一项 */
  files?: CheckFormFile[];
  /** 执行真实检查的元数据模型 uid（不填则走 mock 演示模式） */
  modelUid?: string;
  /** 执行真实检查的资产版本 uid */
  assetVersionUid?: string;
}

/* ------------------------------------------------------------------ */
/* 数据提取任务                                                         */
/* ------------------------------------------------------------------ */

export type ExtractionStatus = 'waiting' | 'running' | 'paused' | 'completed' | 'error';

/** 数据提取任务 */
export interface ExtractionTask {
  /** 任务主键 */
  id: number;
  /** 任务名称 */
  name: string;
  /** 产品类型 */
  productType: string;
  /** 批次号 */
  batch: string;
  /** 请求来源 */
  requestSource: string;
  /** 目标路径 */
  targetPath: string;
  /** 进度百分比（0-100） */
  progress: number;
  /** 任务状态 */
  status: ExtractionStatus;
  /** 状态描述信息 */
  message: string;
  /** 错误信息（失败时有值） */
  error?: string;
  /** 关联的元数据记录 id 列表（生命周期链） */
  recordIds?: number[];
}

/** 数据提取表单 */
export interface ExtractionForm {
  /** 任务名称 */
  name: string;
  /** 待提取的产品类型（可多选） */
  productTypes: string[];
  /** 请求来源 */
  requestSource: string;
  /** 提取结果的目标路径 */
  targetPath: string;
  /** 批次号 */
  batch: string;
  /** 优先级（数值越大越优先） */
  priority: number;
}

/* ------------------------------------------------------------------ */
/* 数据入库任务                                                         */
/* ------------------------------------------------------------------ */

export type StoreStatus = 'waiting' | 'running' | 'paused' | 'completed' | 'error';

/* ------------------------------------------------------------------ */
/* 版本管理 / 数据资产报告                                               */
/* ------------------------------------------------------------------ */

export interface VersionRow {
  /** 主键 */
  id: number;
  /** 产品名称 */
  product: string;
  /** 产品类别 */
  category: string;
  /** 版本号 */
  version: string;
  /** 基线版本号 */
  baseVersion: string;
  /** 变更类型 */
  changeType: string;
  /** 操作人 */
  operator: string;
  /** 更新时间 */
  updatedAt: string;
  /** 版本状态 */
  status: '当前版本' | '历史版本';
  /** 变更内容描述 */
  changes: string;
  /** 关联入库批次号（生命周期链） */
  batch?: string;
  /** 关联该类元数据记录条数（生命周期链） */
  recordCount?: number;
}

/** 数据资产报告行（报告列表） */
export interface ReportRow {
  /** 主键 */
  id: number;
  /** 报告名称 */
  name: string;
  /** 覆盖产品 */
  products: string;
  /** 报告格式 */
  format: string;
  /** 创建时间 */
  createdAt: string;
  /** 生成状态 */
  status: '已生成' | '生成中';
  /** 报告覆盖的记录总数（由 records 聚合） */
  totalRecords?: number;
  /** 报告覆盖的产品类别 */
  categories?: string[];
  /** 关联批次号（批次报告） */
  batch?: string;
}
