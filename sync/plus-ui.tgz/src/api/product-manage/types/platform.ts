/** platform 接口层共享领域类型；字段语义以 综合管理.md 为准 */

/** 通用状态枚举 */
export type TaskStatus = 'pending' | 'running' | 'paused' | 'succeeded' | 'failed' | 'canceled';

/** 产品类别（与 product-category-api.ts 保持一致，此处仅作类型引用） */
export interface ProductCategory {
  /** 类别唯一标识 */
  categoryUid: string;
  /** 类别编码（英文标识，用于模型关联与推荐） */
  categoryKey: string;
  /** 类别名称（展示用） */
  categoryName: string;
  /** 上级类别 uid（null 即顶级类别） */
  parentCategoryUid: string | null;
  /** 类别描述 */
  description: string;
  /** 是否启用 */
  enabled: boolean;
  /** 同级排序号（升序） */
  sortOrder: number;
}

/* -------- 配置类：能力 / 集成 / 配置版本 -------- */

export interface CapabilityItem {
  /** 能力唯一标识 */
  capabilityUid: string;
  /** 能力编码 */
  capabilityKey: string;
  /** 能力名称 */
  capabilityName: string;
  /** 能力描述 */
  description?: string;
  /** 是否启用 */
  enabled: boolean;
}

/** 第三方集成项（如 OA / 消息网关等） */
export interface IntegrationItem {
  /** 集成项唯一标识 */
  integrationUid: string;
  /** 集成项编码 */
  integrationKey: string;
  /** 集成项名称 */
  integrationName: string;
  /** 集成项描述 */
  description?: string;
  /** 是否启用 */
  enabled: boolean;
}

/** 配置类型项（配置中心的分类枚举） */
export interface ConfigTypeItem {
  /** 配置类型编码 */
  type: string;
  /** 配置类型显示名 */
  displayName: string;
  /** 配置类型描述 */
  description?: string;
}

/** 配置版本摘要（版本列表行） */
export interface ConfigVersionSummary {
  /** 版本号（自增） */
  version: number;
  /** 是否为当前生效版本 */
  active: boolean;
  /** 创建时间 */
  createdAt: string;
  /** 创建人 */
  createdBy?: string;
  /** 版本备注 */
  comment?: string;
}

/* -------- 配置类：存储连接 / 位置 / 后端 / 矢量库 -------- */

export interface StorageConnection {
  /** 连接唯一标识 */
  connectionUid: string;
  /** 连接名称 */
  connectionName: string;
  /** 连接类型（如 S3 / HDFS / NAS） */
  connectionType: string;
  /** 服务端点地址 */
  endpoint?: string;
  /** 是否启用 */
  enabled: boolean;
  /** 配置版本号 */
  version?: number;
}

/** 存储位置（连接下的具体目录或对象桶） */
export interface StorageLocation {
  /** 位置唯一标识 */
  locationUid: string;
  /** 位置名称 */
  locationName: string;
  /** 位置类型（如 目录 / 对象桶） */
  locationType: string;
  /** 关联的存储连接 uid */
  connectionUid?: string;
  /** 位置路径 */
  path?: string;
  /** 是否启用 */
  enabled: boolean;
}

/** 存储后端（可挂载的存储类型） */
export interface StorageBackend {
  /** 后端唯一标识 */
  backendUid: string;
  /** 后端编码 */
  backendKey: string;
  /** 后端名称 */
  backendName: string;
  /** 是否启用 */
  enabled: boolean;
}

/** 矢量数据库（对外暴露的矢量库视图） */
export interface VectorDatabase {
  /** 位置唯一标识（复用 StorageLocation 的 uid） */
  locationUid: string;
  /** 矢量库名称 */
  locationName: string;
  /** 关联的存储连接 uid */
  connectionUid?: string;
  /** 是否启用 */
  enabled: boolean;
}

/* -------- 任务通用 -------- */

export interface TaskSummary {
  /** 任务唯一标识 */
  taskUid: string;
  /** 任务类型 */
  taskType: string;
  /** 任务状态 */
  status: TaskStatus;
  /** 进度百分比（0-100） */
  progress?: number;
  /** 创建时间 */
  createdAt: string;
  /** 最后更新时间 */
  updatedAt?: string;
  /** 状态描述信息 */
  message?: string;
}

/** 任务产物（任务执行产生的文件） */
export interface TaskArtifact {
  /** 产物唯一标识 */
  artifactUid: string;
  /** 产物名称 */
  artifactName: string;
  /** 产物类型 */
  artifactType: string;
  /** 文件大小（字节） */
  size?: number;
  /** 下载地址 */
  downloadUrl?: string;
  /** 下载地址过期时间 */
  expiresAt?: string;
}

/** 任务错误明细（统一任务契约：错误账本 17 字段） */
export interface TaskError {
  /** 错误唯一标识 */
  errorUid?: string;
  /** 所属任务 uid */
  taskUid?: string;
  /** 所属任务尝试 uid */
  attemptUid?: string;
  /** 关联数据项 uid */
  itemUid?: string;
  /** 字段键 */
  fieldKey?: string;
  /** 错误码 */
  code?: string;
  /** 错误信息 */
  message?: string;
  /** 修复令牌（用于定位与修复） */
  repairToken?: string;
  /** 来源层键 */
  sourceLayerKey?: string;
  /** 来源要素 uid */
  sourceFeatureUid?: string;
  /** 是否已解决 */
  resolved?: boolean;
  /** 创建时间 */
  createdAt?: string;
  /** 解决时间 */
  resolvedAt?: string;
  /** 资源 uid */
  resourceUid?: string;
  /** 任务类型 */
  taskKind?: string;
  /** 模型 uid */
  modelUid?: string;
  /** 数据键 */
  dataKey?: string;
  /** 出错位置（兼容旧字段；新契约用 fieldKey/itemUid/sourceLayerKey 组合定位） */
  location?: string;
  /** 是否可重试 */
  retryable?: boolean;
}

/* -------- 资源 / 数据 -------- */

export interface ResourceSummary {
  /** 资源唯一标识 */
  resourceUid: string;
  /** 资源名称（后端实际字段 name；resourceName 是旧类型名，保留兼容） */
  name?: string;
  resourceName?: string;
  /** 资源类型（后端实际字段 dataType：vector/raster） */
  dataType?: string;
  resourceType?: string;
  /** 资源描述 */
  description?: string;
  /** 产品类别 UID */
  categoryUid?: string;
  /** 资源状态（就绪/异常等） */
  state?: string;
  /** 数据条数 */
  dataCount?: number;
  /** 版本数 */
  versionCount?: number;
  /** schema 状态 */
  schemaState?: string;
  /** 元数据 schema 状态 */
  metadataSchemaState?: string;
  /** 模型绑定状态：bound / unconfigured */
  modelBindingState?: string;
  /** 资源英文名 */
  nameEn?: string;
  /** 产品类别中文名（列表「类别」列应展示此字段） */
  categoryName?: string;
  /** 创建人引用，可为空 */
  createdByRef?: string;
  /** 资源版本号 */
  version?: number;
  /** 问题数 */
  problemCount?: number;
  /** 能力标识，当前为空数组 */
  capabilities?: string[];
  /** 创建时间 */
  createdAt?: string | null;
  /** 最后更新时间 */
  updatedAt?: string | null;
}

/**
 * 资源目录树节点（GET /platform/resources/tree 的 data.items[]）。
 *
 * 响应是**异构联合**：类别节点（容器）与资源叶子（nodeType:'resource'）字段不同。
 * 类别节点无 `uid`，资源叶子无 `categoryName`，渲染 label 时必须按 `nodeType` 区分
 * （resource → displayName，category → categoryName）。
 */
export type ResourceTreeNode = ResourceTreeCategoryNode | ResourceTreeResourceNode;

/** 类别节点（容器：product-category-root 的 primary/result，及其子类别） */
export interface ResourceTreeCategoryNode {
  /** 类别编码（非 UUID，如 primary / result）；产品线 provide('product-category-root') 的值即顶级 categoryKey */
  categoryKey: string;
  /** 类别中文名 */
  categoryName: string;
  /** 子节点（类别或资源叶子） */
  children?: ResourceTreeNode[];
  [key: string]: unknown;
}

/** 资源叶子（nodeType:'resource'） */
export interface ResourceTreeResourceNode {
  /** 父类别 UUID */
  categoryUid: string;
  /** 资源 UID（= resourceUid） */
  uid: string;
  /** 资源中文展示名（叶子无 categoryName，label 一律用此字段） */
  displayName: string;
  /** 资源英文名（可为空） */
  nameEn?: string | null;
  /** 数据类型 vector / raster ... */
  dataType?: string;
  /** 状态，响应为**中文**（就绪/待处理/异常） */
  state?: string;
  /** 图层数 */
  layerCount?: number;
  /** 版本号 */
  version?: number;
  /** 创建时间，形如 2026/11/02 14:56 */
  createdAt?: string | null;
  /** 更新时间 */
  updatedAt?: string | null;
  /** 节点类型，固定 'resource' */
  nodeType: 'resource';
  /** 资源叶子无子节点，恒为 [] */
  children?: ResourceTreeNode[];
  [key: string]: unknown;
}

/** 资源卡片（资源概览的卡片视图） */
export interface ResourceCard {
  /** 资源唯一标识 */
  resourceUid: string;
  /** 资源名称 */
  resourceName: string;
  /** 资源类型 */
  resourceType: string;
  /** 数据条数 */
  dataCount?: number;
  /** 版本数 */
  versionCount?: number;
}

/** 数据版本（资源的某个版本快照） */
export interface DataVersion {
  /** 版本唯一标识 */
  versionUid: string;
  /** 版本名称 */
  versionName: string;
  /** 创建时间 */
  createdAt: string;
  /** 包含的图层数 */
  layerCount?: number;
}

/** 图层摘要（版本下的单个图层信息） */
export interface LayerSummary {
  /** 图层唯一标识 */
  layerUid: string;
  /** 图层名称 */
  layerName: string;
  /** 几何类型（Point / LineString / Polygon 等） */
  geometryType?: string;
  /** 要素数量 */
  featureCount?: number;
}

/* -------- 备份 / 安全策略 -------- */

/**
 * 元数据库备份契约类型（Apifox「元数据备份恢复」接口族）
 *
 * 全部字段以 docId 532352875–532352937 为准；旧版 policyUid/backupName/backupType/status
 * 这套字段契约里不存在，已按最新契约重写。备份是**整库级**操作，没有 resourceUid 维度。
 */

/** 备份模式：完整 / 增量 */
export type BackupMode = 'full' | 'incremental';

/** 备份存储位置：本地 / 异地 / 离线 */
export type BackupLocation = 'local' | 'remote' | 'offline';

/** 备份保留策略 */
export interface BackupRetention {
  maxCount?: number;
  maxAgeDays?: number;
  keepLatest?: boolean;
}

/** 备份策略（GET/PUT /backup/policy） */
export interface BackupPolicy {
  mode: BackupMode;
  /** 自动备份间隔（秒）；0 = 仅手动 */
  intervalSeconds: number;
  /** 备份名前缀；1-32 位字母数字点横线 */
  namePrefix: string;
  location: BackupLocation;
  retention: BackupRetention;
  /** 是否允许恢复；false 时执行恢复返回 503 RESTORE_DISABLED_BY_POLICY */
  allowRestore: boolean;
  maxTables?: number;
  maxRows?: number;
  maxBytes?: number;
  queryTimeoutMs?: number;
  scheduledExecution?: string;
}

/** 更新策略的请求体（未提交字段沿用原值） */
export interface BackupPolicyUpdate extends Partial<BackupPolicy> {}

/** 备份列表行（GET /backup/backups） */
export interface BackupSummary {
  backupUid: string;
  name: string;
  mode: BackupMode;
  createdAt: string;
  createdBy?: string;
  tableCount?: number;
  totalRows?: number;
  fileBytes?: number;
}

/** 备份的表摘要 */
export interface BackupTableStat {
  schema: string;
  table: string;
  rowCount?: number;
  sha256?: string;
}

/** 立即备份结果（POST /backup/runs） */
export interface BackupRunResult extends BackupSummary {
  database?: string;
  fileSha256?: string;
  tables?: BackupTableStat[];
  skippedTables?: Array<{ schema: string; table: string; reason: 'NO_CURSOR_COLUMN' | 'NO_ROWS' }>;
}

/** 备份详情（GET /backup/backups/{backupUid}） */
export interface BackupDetail {
  backupUid: string;
  name: string;
  mode: BackupMode;
  createdAt: string;
  /** 契约未约束表摘要 item 的属性，按通用对象渲染，能取到 schema/table 就显示 */
  tables: Array<Record<string, unknown>>;
  verification: { verified: boolean; errorCode?: string };
}

/** 清理预览候选 */
export interface BackupCleanupCandidate {
  backupUid: string;
  name: string;
  createdAt: string;
  fileBytes?: number;
}

/**
 * 清理预览返回的保留策略（实测后端结构）
 *
 * 2026-11-19 E2E 实测：后端 /backup/cleanup-preview 返回的 retention 是 daily/weekly/monthly
 * 这套分档结构，与契约文档 BackupRetention（maxCount/maxAgeDays）不同。按 SOP「文档与实测
 * 冲突以实测为准」落类型；同时保留契约字段以兼容不同部署版本。UI 不消费该字段。
 */
export interface BackupCleanupRetention {
  autoDelete?: boolean;
  daily?: number;
  weekly?: number;
  monthly?: number;
  minCopiesForAutoDelete?: number;
  protectChains?: boolean;
  keepLatest?: boolean;
  /** 契约文档字段，部分部署版本可能返回 */
  maxCount?: number;
  maxAgeDays?: number;
}

/** 清理预览结果（POST /backup/cleanup-preview） */
export interface BackupCleanupPreview {
  candidates: BackupCleanupCandidate[];
  retention?: BackupCleanupRetention;
  candidateCount: number;
  /** 实测返回的执行说明文案 */
  execute?: string;
}

/** 执行清理结果（POST /backup/cleanup） */
export interface BackupCleanupResult {
  deleted: Array<{ backupUid: string; name: string }>;
  deletedCount: number;
  note?: string;
}

/** 备份演练单项检查 */
export interface BackupDrillCheck {
  name: string;
  passed: boolean;
  detail?: string;
}

/** 备份演练结果（POST /backup/backups/{backupUid}/drill） */
export interface BackupDrillResult {
  backupUid: string;
  name: string;
  verified: boolean;
  errorCode?: string;
  checks: BackupDrillCheck[];
  totalRows?: number;
  tableCount?: number;
  fileBytes?: number;
  note?: string;
}

/** 恢复计划（恢复向导预览） */
export interface BackupRestorePlan {
  backupUid: string;
  name: string;
  mode: BackupMode;
  createdAt: string;
  database?: string;
  tableCount?: number;
  totalRows?: number;
  baseBackupUid?: string;
  warnings?: string[];
  guidance?: string[];
}

/** 恢复预览结果（POST /backup/restore/preview） */
export interface BackupRestorePreview {
  planToken: string;
  planDigest: string;
  expiresInSeconds: number;
  plan: BackupRestorePlan;
}

/** 恢复确认结果（POST /backup/restore/confirm） */
export interface BackupRestoreConfirm {
  confirmationToken: string;
  backupUid: string;
  planDigest: string;
  expiresInSeconds: number;
  note?: string;
}

/** 恢复执行结果（POST /backup/restore/apply） */
export interface BackupRestoreApplyResult {
  state: 'committed' | 'dry-run' | 'rolled-back';
  dryRun?: boolean;
  committed?: boolean;
  totalRows?: number;
  tableCount?: number;
  tables?: Array<{ schema: string; table: string; rowsDeleted?: number; rowsInserted?: number; expectedRows?: number }>;
  backupUid: string;
  name: string;
  mode: BackupMode;
  planDigest?: string;
  fileSha256?: string;
  note?: string;
}

/** 安全策略（数据访问控制规则） */
export interface SecurityPolicy {
  /** 策略唯一标识 */
  policyUid: string;
  /** 策略名称 */
  policyName: string;
  /** 策略描述 */
  description?: string;
  /** 是否启用 */
  enabled: boolean;
  /** 策略版本号 */
  version?: number;
}

/* -------- 数据入库（/platform/imports） -------- */

/**
 * 入库批次结论状态；开放枚举，UI 映射未列举值归 info。
 *
 * CREATED 是创建接口受理后的初始态（任务尚未入队），T6a 批次对象把它列为正常状态机取值，
 * 早期实现只发了 QUEUED 起的值，页面若缺它会把新建批次显示成「未知」。
 */
export type ImportState = 'CREATED' | 'QUEUED' | 'RUNNING' | 'SUCCEEDED' | 'PARTIAL_SUCCESS' | 'FAILED' | 'PAUSED' | 'CANCELLED';

/** 入库优先级 */
export type ImportPriorityLevel = 'high' | 'medium' | 'low';

/**
 * 检查策略（T6a 契约 2026-11-08；2026-11-11 策略固定）。
 *
 * - require_passed：默认，必须显式绑定 checkUid，服务端按检查记录复核清单/大小/摘要；
 * - direct：显式直接入库，**不再要求/接收原因字段**（历史审计字段 reason 可为空），
 *   不得带 checkUid，资源初始 PENDING_METADATA（待补元数据）；
 * - run_if_needed：**已从新受理移除**（新请求 400「导入检查策略无效」）；
 *   仅历史批次的执行侧兼容读取，前端不得再传。
 */
export type ImportCheckPolicy = 'require_passed' | 'direct' | 'run_if_needed';

/**
 * 元数据补录状态（direct 批次的生命周期字段）。
 *
 * not_required=非 direct 批次无需补录；pending=待补录（资源 metadata_completeness 为
 * pending_backfill）；completed=补录完成（转 complete，**批次状态不变**）。
 */
export type ImportMetadataBackfillState = 'not_required' | 'pending' | 'completed';

/** direct 直接入库的审计信息；非 direct 批次为 null */
export interface ImportDirectIngestAudit {
  /** 直接入库原因（1–500 字符） */
  reason: string;
  /** 受理操作人引用 */
  actorRef?: string;
  /** 受理时间（UTC ISO-8601 文本） */
  ingestedAt?: string;
}

/** 元数据补录状态投影；创建/详情/补录完成接口共用 */
export interface ImportMetadataBackfill {
  state?: ImportMetadataBackfillState;
  /** 是否要求补录元数据（direct 且未完成时为 true） */
  required?: boolean;
  /** 补录完成时间；未完成为 null */
  completedAt?: string | null;
  /** 补录操作人引用；未完成为 null */
  completedBy?: string | null;
}

/** 入库进度；percent/total 在目录扫描期可为 null */
export interface ImportProgress {
  completed: number;
  total?: number | null;
  percent?: number | null;
  stage?: string;
}

/** 入库批次列表项（GET /platform/imports 的 items[]） */
export interface ImportBatch {
  importUid: string;
  batchName: string;
  taskName: string;
  categoryName: string;
  securityLevel: string;
  progress: ImportProgress;
  state: ImportState;
  hint?: string | null;
  errorCount: number;
  taskUid: string;
  createdAt: string;
  finishedAt?: string | null;
}

/**
 * 入库批次详情（创建响应 / GET /platform/imports/{importUid} / 补录完成响应共用同一投影）。
 *
 * T6a 新增检查绑定（checkUid）、冻结选择清单（files）、数据文件子集（dataFiles）、
 * direct 审计（directIngest）与补录状态（metadataBackfill）。
 * CONSTRAINT resourceUid 是契约 required 字段（创建接口即返回本批次创建的任务资源 uid），
 * 早期声明为可选会让页面读它时静默落空；历史批次同样返回，故收紧为必填。
 */
export interface ImportBatchDetail {
  importUid: string;
  batchName: string;
  taskName?: string;
  /** 本批次创建的任务资源 uid；契约 required */
  resourceUid: string;
  categoryUid?: string;
  categoryName?: string;
  checkPolicy?: ImportCheckPolicy;
  /**
   * 绑定的检查单号；direct 与历史批次为 null。
   *
   * WHY 必须显式 `string | null`：这是"未绑定"的确定信号，与字段缺失（老后端不返回）语义不同，
   * 页面据此决定是展示「已绑定检查」还是「直接入库」。
   */
  checkUid?: string | null;
  /** 受理时冻结的完整选中文件清单（string[]，保持顺序）；历史批次为空数组 */
  files?: string[];
  /** 服务端按检查记录分类的入库数据文件子集；历史批次为空数组 */
  dataFiles?: string[];
  /** direct 直接入库审计；非 direct 批次为 null */
  directIngest?: ImportDirectIngestAudit | null;
  /** 元数据补录状态；非 direct 批次 state=not_required */
  metadataBackfill?: ImportMetadataBackfill;
  /** 首次执行冻结的逻辑存储根；历史批次为空串 */
  storageRootKey?: string;
  /** 批次描述；未填写为空串 */
  description?: string;
  securityLevel?: string;
  priorityLevel?: ImportPriorityLevel;
  state: ImportState;
  progress?: ImportProgress;
  hint?: string | null;
  errorCount?: number;
  /** 稳定业务错误码；执行期失败时回显（可选字段） */
  errorCode?: string;
  taskUid: string;
  dataUid?: string | null;
  versionUid?: string | null;
  createdBy?: string;
  createdAt?: string;
  updatedAt?: string;
  finishedAt?: string | null;
  /** 来源元数据解析结论；无账本行为 null */
  metadataStatus?: string | null;
  /** 运行中暂停检查点 */
  checkpoint?: {
    /** 已完成文件数 */
    fileIndex?: number;
    /** 最后完成文件相对路径 */
    relativePath?: string;
  };
  /** 暂停原因；未暂停为 null */
  pausedReason?: string | null;
}

/** 入库数据项（GET /platform/imports/{importUid}/items 的 items[]） */
export interface ImportItem {
  itemUid: string;
  state: string;
  /** 关联的统一任务 UID；item 级重试后进度走该任务 SSE */
  taskUid?: string;
  errorCode?: string | null;
  errorMessage?: string | null;
}

/**
 * 入库批次的来源元数据（GET /platform/imports/{importUid}/metadata）。
 *
 * CONSTRAINT developing：字段随验收演进；model.bound=false 时 values 通常为空。
 * status 是中文结论文案（如「已入库」），与批次 state 属不同编码，勿混用。
 */
export interface ImportMetadata {
  importUid: string;
  /** 批次创建时间 */
  batchCreatedAt?: string;
  /** 元数据采集时间 */
  collectedAt?: string;
  createdAt?: string;
  /** 内部英文枚举（如 CREATED），与批次 state 不同源 */
  importState?: string;
  /** 模型绑定信息；bound=false 表示该类别尚无通过的元数据检查记录 */
  model?: ImportMetadataModel;
  /** 采集到的元数据记录条数 */
  recordCount?: number;
  source?: ImportMetadataSource;
  /** 中文结论文案（如「已入库」）；开放枚举，UI 直接展示 */
  status?: string;
  /** 扁平键值对：键为元数据字段 key，值为字符串化后的内容 */
  values?: Record<string, string>;
}

/** 来源元数据绑定的模型 */
export interface ImportMetadataModel {
  bound: boolean;
  modelUid?: string;
  modelName?: string;
  modelVersionUid?: string;
  modelVersionNo?: string;
}

/** 来源文件描述 */
export interface ImportMetadataSource {
  file?: string;
  /** 文件类型机器码（如 sms） */
  kind?: string;
  /** 文件类型中文（如「SMS 记录文件」） */
  kindText?: string;
}
/** 上传会话（分片上传的整体会话） */
export interface UploadSession {
  /** 上传会话唯一标识 */
  uploadUid: string;
  /** 上传文件名 */
  uploadName: string;
  /** 会话创建时间 */
  createdAt: string;
}

/** 上传分片（会话下的单个分片状态） */
export interface UploadPart {
  /** 文件唯一标识 */
  fileUid: string;
  /** 分片序号（从 1 开始） */
  partNo: number;
  /** 该分片是否已接收 */
  received: boolean;
}

/* -------- 元数据检查 -------- */

export interface CheckRun {
  /** 检查唯一标识 */
  checkUid: string;
  /** 检查类型（如 结构检查 / 值域检查） */
  checkType: string;
  /** 检查状态 */
  status: TaskStatus;
  /** 创建时间 */
  createdAt: string;
  /** 发现的问题数 */
  issueCount?: number;
}

/** 检查发现项（单条检查问题记录） */
export interface CheckFinding {
  /** 问题唯一标识 */
  findingUid: string;
  /** 严重级别（error / warning / info） */
  severity: string;
  /** 涉及的字段名 */
  field?: string;
  /** 问题描述 */
  message: string;
}

/* -------- 数据提取 -------- */

export interface DataExtractionTask {
  /** 任务唯一标识 */
  taskUid: string;
  /** 任务名称 */
  taskName: string;
  /** 任务状态 */
  status: TaskStatus;
  /** 优先级（数值越大越优先） */
  priority?: number;
  /** 进度百分比（0-100） */
  progress?: number;
  /** 创建时间 */
  createdAt: string;
}

/* -------- 通知 -------- */

export interface NotificationItem {
  /** 通知唯一标识 */
  notificationUid: string;
  /** 通知标题 */
  title: string;
  /** 通知内容 */
  content?: string;
  /** 是否已读 */
  read: boolean;
  /** 创建时间 */
  createdAt: string;
}

/* -------- 元数据编辑（/platform/resources/{resourceUid}/metadata-tables/{tableKey}/...） -------- */

/**
 * 元数据表记录的编辑字段定义（`GET .../edit-schema`）
 *
 * 契约 docId 531575178。字段的每个属性（`writable` / `required` / `options` …）都是
 * 「渲染编辑表单」与「提交前本地校验」的唯一依据，页面不得自行猜测字段规则。
 */
export interface MetadataEditField {
  /** 模型字段键；提交 `values` 时用作键，**必须**用它而不是中文 label */
  fieldKey: string;
  /** 中文显示名 */
  label?: string;
  description?: string;
  /** 规范值类型（string/integer/number/boolean/date/...） */
  valueType?: string;
  /** 输入控件类型（text/number/select/checkbox/date/...） */
  widget?: string;
  visible?: boolean;
  /** 只读；即便 writable 为真也不可编辑 */
  readOnly?: boolean;
  readable?: boolean;
  /** 允许写入；为 false 的字段不得出现在提交载荷里 */
  writable?: boolean;
  /** 必填；服务端还会再校验一次 */
  required?: boolean;
  nullable?: boolean;
  sortable?: boolean;
  filterable?: boolean;
  width?: number;
  maxLength?: number;
  precision?: number;
  scale?: number;
  /** 正则约束（字符串字段） */
  pattern?: string;
  minimum?: number;
  maximum?: number;
  /** 枚举选项 */
  options?: Array<{ value: string; label: string }>;
  defaultValue?: string;
  /** 依赖字段键：这些字段变化会影响本字段的可用性或取值 */
  dependsOn?: string[];
  /** 敏感字段不对外投影 */
  sensitive?: boolean;
  modelUid?: string;
  modelVersionUid?: string;
  tableKey?: string;
  /** 支持的比较操作符（供查询面板的 fieldFilters 使用） */
  operator?: string[];
}

/** 当前实现能力（仍受来源 / 权限 / 配置约束，前端只做 UI 显隐，不做安全判定） */
export interface MetadataEditCapabilities {
  create?: boolean;
  update?: boolean;
  delete?: boolean;
  batch?: boolean;
  undo?: boolean;
  lock?: boolean;
}

/** 几何能力 */
export interface MetadataEditGeometry {
  /** 允许输入的空间参考系（契约实测为 4326 / 4490） */
  inputSrids?: number[];
  /** 输出 srid（契约固定 4326） */
  srid?: number;
}

export interface MetadataEditPermissions {
  /** 仅可信有权限的用户可编辑 */
  administratorOnly?: boolean;
}

/** `GET .../{tableKey}/edit-schema` 的 data */
export interface MetadataEditSchema {
  resourceUid?: string;
  tableKey?: string;
  /** 中文表名 */
  tableName?: string;
  versionUid?: string;
  fields?: MetadataEditField[];
  capabilities?: MetadataEditCapabilities;
  geometry?: MetadataEditGeometry;
  permissions?: MetadataEditPermissions;
}

/** 一条元数据记录（`GET .../records/{metadataUid}` 的 data） */
export interface MetadataRecordDetail {
  /** 物理元数据记录 UUID；地图 featureUid 与它相同 */
  metadataUid?: string;
  resourceUid?: string;
  tableKey?: string;
  /** 乐观并发判据；更新 / 删除 / 撤销都必须回传 */
  rowVersion?: number;
  /** 业务字段与值（契约声明值为 string） */
  values?: Record<string, string>;
  /** 服务端归一化后的值（只读展示用） */
  normalizedValues?: Record<string, string>;
  valid?: boolean;
  /** 字段级问题明细 */
  issues?: MetadataRecordIssue[];
  geometry?: MetadataRecordGeometry;
  history?: Array<{
    historyUid?: string;
    operation?: string;
    rowVersion?: number;
    createdAt?: string;
  }>;
  createdAt?: string;
  updatedAt?: string;
}

/** 字段 / 记录级问题项（编辑、校验、批量、撤销共用同一形状） */
export interface MetadataRecordIssue {
  metadataUid?: string;
  fieldKey?: string;
  /** 稳定问题代码 */
  code?: string;
  /** 中文问题说明，可直接展示 */
  message?: string;
  /** 可选修复提示 */
  repairHint?: string;
}

/** 几何（GeoJSON 子集；coordinates 契约写 string[]，实测可能为数字数组，故放宽为 unknown） */
export interface MetadataRecordGeometry {
  type?: string;
  coordinates?: unknown;
}

/**
 * 历史项的操作类型（契约 api-531665055.md 明示四值：create/update/delete/undo）。
 *
 * WHY 收窄成字面量联合而不是 `string`：页面要按操作类型给不同文案与图标，
 * 开放 `string` 时 TS 不会提示「漏处理 undo」，新增值也会静默落到默认分支。
 */
export type MetadataRecordHistoryOperation = 'create' | 'update' | 'delete' | 'undo';

/** 记录的变更历史项（`GET .../records/{metadataUid}/history`） */
export interface MetadataRecordHistoryItem {
  historyUid?: string;
  operation?: MetadataRecordHistoryOperation;
  changedFields?: string[];
  beforeValues?: Record<string, string>;
  afterValues?: Record<string, string>;
  rowVersionBefore?: number;
  rowVersionAfter?: number;
  actor?: string;
  createdAt?: string;
}

/**
 * 历史查询响应（契约 `data.metadataUid` / `data.items` / `data.total`）。
 *
 * CONSTRAINT `items` 必须是**可选**：契约里它标「否」（非必填）。后端对「有记录但无历史」
 * 完全可能只返 `{metadataUid, total: 0}` 而不带 items，消费侧读 `res.items.length` 会直接 TypeError。
 * 消费侧一律 `res.items ?? []`。
 */
export interface MetadataRecordHistoryResult {
  metadataUid?: string;
  items?: MetadataRecordHistoryItem[];
  total?: number;
}

/**
 * 写操作的统一响应（创建 / 更新 / 删除 / 批量 / 撤销共用同一套 data）。
 *
 * 契约 docId：531575505 / 531575547 / 531575510 / 531714898 / 531665133。
 * WHY 合并成一个类型：这四个接口的 data 成员名逐一相同（requested/affected/preview/indexState…），
 * 拆成四个几乎一样的接口只会让调用方多记四个名字，收益为负。
 */
export interface MetadataRecordMutationResult {
  requested?: number;
  metadataUid?: string;
  /** 地图 featureUid 与 metadataUid 相同 */
  featureUid?: string;
  historyUid?: string;
  historyUids?: string[];
  rowVersion?: number;
  updatedFields?: string[];
  /**
   * 删除结果。**单条删除是 boolean，批量删除是数量**（契约 api-531575510.md:80 与
   * api-531714898.md:52 的差异）。契约对撤销还有「单条为布尔值，批量删除为删除数量；预览可为 null」。
   *
   * WHY 不能用 `number | null`：单条删除时服务端返 `true`，按数字判成功（`deleted === 1`）恒 false，
   * 会把成功的删除报成失败。消费侧统一用「非 falsy 即成功」判断，不做数字比较。
   */
  deleted?: boolean | number | null;
  updated?: number;
  failed?: number;
  affected?: number;
  valid?: boolean;
  issues?: MetadataRecordIssue[];
  /** 批量 dry-run / 预演的前后值 */
  preview?: Array<{ metadataUid?: string; before?: Record<string, string>; after?: Record<string, string> }>;
  /**
   * 平台索引状态（契约 api-531714898.md:57 明示 `pending/ready/failed`）。
   * WHY 不能只写 `'pending'`：类型上无法表达 ready/failed，消费侧只能靠 any 绕过类型，
   * 等于把「索引是否就绪」这个真实状态藏起来。
   */
  indexState?: 'pending' | 'ready' | 'failed';
  createdAt?: string;
  updatedAt?: string;
}

/**
 * 编辑租约（`POST .../edit-sessions` 的 data；释放接口复用）。
 *
 * ## 字段名以契约文档为准（实测被权限门挡住，无法正向取证）
 *
 * 契约 api-531663707.md:45-49 返回：`lockToken` / `mode` / `expiresAt` / **`revision`** /
 * `holder` / **`lockedMetadataUids`**。
 *
 * WHY 同时保留 `lockRevision` / `metadataUids` 两个旧名（标 deprecated 可选）：
 * 旧类型把它们声明成真字段，接口层 `acquireEditLock()` 归一 `EditLock` 时仍兼容读 `lockRevision`——
 * 契约名一旦与后端实际不符，只写新名会让「租约代际校验」静默失效（传 undefined 不报错）。
 * 兼容读 `revision ?? lockRevision` 两种都能拿到值，待后端确认后可删旧名（见 01-contract-diff-round2 §五-2）。
 */
export interface MetadataEditSession {
  lockToken?: string;
  /** 锁到期时间 */
  expiresAt?: string;
  /** 锁模式：table 为整表锁，records 为按记录锁 */
  mode?: 'table' | 'records';
  /** 锁版本（契约字段名）；写操作回传 `lockRevision` 做租约代际校验 */
  revision?: number;
  /** @deprecated 旧名，契约实际叫 `revision`；保留仅为兼容，新代码请读 `revision` */
  lockRevision?: number;
  /** 记录锁目标（契约字段名）；表锁为空 */
  lockedMetadataUids?: string[];
  /** @deprecated 旧名，契约实际叫 `lockedMetadataUids` */
  metadataUids?: string[];
  /** 稳定服务端主体标识，不是保证显示名 */
  holder?: string;
  released?: boolean;
}

/* -------- 元数据查询（/platform/metadata-records/query...） -------- */

/** 查询入参的 `state` 枚举（**英文**，与资源列表出参的中文状态不同，见 STATE_ALIAS） */
export type MetadataQueryState = 'pending' | 'ready' | 'failed';

/** `fieldFilters[].operator` 契约枚举 */
export type MetadataQueryFieldOperator = 'eq' | 'ne' | 'contains' | 'prefix' | 'in' | 'between' | 'isNull' | 'isNotNull';

/** `spatial.type` 契约枚举 */
export type MetadataQuerySpatialType =
  | 'bbox'
  | 'polygon'
  | 'polyline'
  | 'point'
  | 'circle'
  | 'buffer'
  | 'adminArea'
  | 'mapSheets'
  | 'coordinateRanges';

/** 单个字段过滤项 */
export interface MetadataQueryFieldFilter {
  fieldKey: string;
  operator: MetadataQueryFieldOperator;
  values?: string[];
  /** 与相邻条件的连接方式；默认 and */
  connector?: 'and' | 'or';
}

/** 空间范围过滤（契约把范围类条件全部收进 spatial，不再平铺在顶层） */
export interface MetadataQuerySpatial {
  type: MetadataQuerySpatialType;
  /** 契约枚举只有 4326 */
  srid?: 4326;
  /** [minLon, minLat, maxLon, maxLat] */
  bbox?: number[];
  geometry?: { type?: string; coordinates?: unknown };
  /** [lon, lat] */
  center?: number[];
  radiusMeters?: number;
  bufferMeters?: number;
  adminCodes?: string[];
  mapSheetNumbers?: string[];
  coordinateRanges?: Array<{ minLon: number; minLat: number; maxLon: number; maxLat: number }>;
}

/** 统一查询请求体（`POST /platform/metadata-records/query`） */
export interface MetadataQueryPayload {
  // —— 必填 ——
  page: number;
  /** 1–200，默认 20 */
  pageSize: number;
  // —— 过滤 ——
  categoryUids?: string[];
  dataVersionUids?: string[];
  modelUid?: string;
  modelVersionUid?: string;
  /** 资源 UUID 列表（**不是**模型 uid，也不是类别编码） */
  resourceUids?: string[];
  /** 模型表键列表 */
  tableKeys?: string[];
  state?: MetadataQueryState;
  keyword?: string;
  fieldFilters?: MetadataQueryFieldFilter[];
  spatial?: MetadataQuerySpatial;
  /**
   * 行政区划 UID（A1 增量）：服务端按 UID 取边界注入 spatial polygon 谓词。
   * 与 spatial 互斥（同时提供后端 400 METADATA_QUERY_INVALID）。
   */
  administrativeDivisionUid?: string;
  /** 范围文件导入受理后拿到的导入令牌 */
  importToken?: string;
  /** 跨页游标；翻页须原样回传上一页返回的 queryToken */
  queryToken?: string;
  // —— 输出控制 ——
  includeGeometry?: boolean;
  includeFieldSchema?: boolean;
  sort?: Array<{ field: 'updatedAt' | 'createdAt' | 'metadataUid'; direction?: 'asc' | 'desc' }>;
}

/** 统一查询结果条目 */
export interface MetadataQueryItem {
  metadataUid?: string;
  /** 与 metadataUid 相同 */
  featureUid?: string;
  resourceUid?: string;
  resourceName?: string;
  categoryUid?: string;
  categoryName?: string;
  categoryColor?: string;
  tableKey?: string;
  modelUid?: string;
  modelVersionUid?: string;
  versionUid?: string;
  versionNo?: number;
  /** 业务字段与值（**不是** fields） */
  attributes?: Record<string, string>;
  rowVersion?: number;
}

/** 统一查询结果 */
export interface MetadataQueryResult {
  page?: number;
  pageSize?: number;
  total?: number;
  /** 翻页游标；空则只能从头查 */
  queryToken?: string;
  expiresAt?: string;
  /** 字段定义；includeFieldSchema=true（默认）时返回 */
  fields?: MetadataEditField[];
  items: MetadataQueryItem[];
}

/** 查询下拉选项（`GET /query/options`） */
export interface MetadataQueryOptions {
  categories?: Array<{ uid?: string; name?: string; color?: string }>;
  versions?: Array<{ uid?: string; versionNo?: number; name?: string }>;
  models?: Array<{ uid?: string; versions?: Array<{ uid?: string; versionNo?: number }> }>;
  tables?: Array<{
    tableKey?: string;
    tableName?: string;
    modelUid?: string;
    modelVersionUid?: string;
    fields?: MetadataEditField[];
  }>;
}

/** 选择集操作（契约 7 值） */
export type MetadataSelectionOperation = 'replace' | 'add' | 'subtract' | 'intersect' | 'invert' | 'all' | 'none';

/** 选择集响应（`POST /query/selection`） */
export interface MetadataSelectionResult {
  selectionToken?: string;
  /** include 为白名单包含，exclude 为反向排除 */
  mode?: 'include' | 'exclude';
  count?: number;
  revision?: number;
  sampleFeatureUids?: string[];
  expiresAt?: string;
}

/** 异步任务受理（导入 / 报表共用的 202 data） */
export interface MetadataQueryTaskAccepted {
  taskUid?: string;
  /** 报表任务用 reportTaskUid */
  reportTaskUid?: string;
  /** 导入令牌；ready 后供查询使用 */
  importToken?: string;
  /** 受理态固定 queued */
  state?: 'queued';
  /** 导入用的实际格式 txt/csv/xlsx；报表固定 html */
  format?: string;
  parsedCount?: number;
  estimatedCount?: number;
  warnings?: MetadataRecordIssue[];
}

/** 异步任务进度（导入状态 / 报表状态共用） */
export interface MetadataQueryTaskProgress {
  taskUid?: string;
  kind?: string;
  /** 任务状态（后端出参为字符串，取值待权限开通后实测） */
  state?: string;
  taskName?: string;
  progress?: {
    completed?: number;
    total?: number;
    percent?: number;
    stage?: string;
  };
  priority?: number;
  queuePosition?: number;
  resourceUid?: string;
  reportArtifactUid?: string;
  createdAt?: string;
  updatedAt?: string;
  version?: number;
  errorCount?: number;
  artifactCount?: number;
  errors?: MetadataRecordIssue[];
  artifacts?: Array<{ artifactUid?: string; name?: string; mediaType?: string; sizeBytes?: number; expiresAt?: string }>;
}
