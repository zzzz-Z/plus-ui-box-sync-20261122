/**
 * 本地派生数据源
 *
 * 版本列表 / 数据资产报告 / 数据更新任务在后端没有对应的列表接口，
 * 它们是从真实元数据记录本地派生的业务视图，不是 mock 接口。
 * 输入统一来自 useProductRecords()（已接真实查询接口），保证与页面其他部分同源。
 */
import type { MetadataRecord, VersionRow, ReportRow, ExtractionTask } from '../types';
import { PRODUCT_TYPES } from '../types';

/** 生成批次名：前缀-日期-毫秒尾三位（原 components/shared.ts 迁入） */
export function createBatchName(prefix: string) {
  return prefix + '-' + new Date().toISOString().slice(0, 10).replaceAll('-', '') + '-' + Date.now().toString().slice(-3);
}

const CATEGORY_UIDS = ['traffic', 'water', 'settlement', 'vegetation', 'landCover', 'building3d', 'rockSoil', 'hazard', 'mineral'];
const SHORT_NAMES: Record<string, string> = {
  交通: '交通路网', 水系: '水系分布', 居民地: '居民地轮廓', 植被: '植被覆盖', 地表覆盖: '地表覆盖',
  三维建筑物: '三维建筑', 岩土体: '岩土体分布', 灾害地质: '灾害地质分布', 矿产资源: '矿产资源分布'
};
const VERSIONS = ['v1.0', 'v1.2', 'v1.5', 'v2.0', 'v2.1', 'v3.0'];
const OPERATORS = ['张工', '李工', '王工', '赵工'];
const CHANGE_TYPES = ['数据更新', '属性修订', '结构变更'];

/** 三阶段状态档位：确定性分配，保证 check/store/extract 逻辑自洽 */
const STAGES: Array<{ check: string; store: string; extract: ExtractionTask['status'] }> = [
  { check: 'passed', store: 'completed', extract: 'completed' },
  { check: 'passed', store: 'running', extract: 'waiting' },
  { check: 'checking', store: 'waiting', extract: 'waiting' },
  { check: 'failed', store: 'error', extract: 'error' },
  { check: 'passed', store: 'completed', extract: 'running' },
  { check: 'passed', store: 'paused', extract: 'waiting' },
  { check: 'waiting', store: 'waiting', extract: 'waiting' },
  { check: 'passed', store: 'completed', extract: 'paused' },
  { check: 'waiting', store: 'waiting', extract: 'waiting' }
];

function pad2(value: number) { return String(value).padStart(2, '0'); }
function formatDateTime(d: Date) {
  return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) + ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes()) + ':' + pad2(d.getSeconds());
}
function progressOf(status: string, seedKey: string) {
  if (status === 'passed' || status === 'completed') return 100;
  if (status === 'waiting') return 0;
  let hash = 0;
  for (let i = 0; i < seedKey.length; i++) hash = (hash * 31 + seedKey.charCodeAt(i)) >>> 0;
  return 20 + Math.floor(((hash >>> 0) / 4294967296) * 70);
}

interface Chain {
  index: number;
  category: string;
  code: string;
  shortName: string;
  rootPath: string;
  recordCount: number;
  recordIds: number[];
  failedCount: number;
  version: string;
  baseVersion: string;
  operator: string;
  latestUpdatedAt: string;
  batchSeq: number;
  batch: string;
  extractBatch: string;
  stage: { check: string; store: string; extract: ExtractionTask['status'] };
}

/** 以产品类别为骨架，从真实记录聚合每类的数量/版本/密级/失败数/批次/阶段 */
function buildChains(records: MetadataRecord[]): Chain[] {
  return PRODUCT_TYPES.map((category, index) => {
    const list = records.filter((record) => record.category === category);
    const code = CATEGORY_UIDS[index];
    const versions = [...new Set(list.map((record) => record.version))];
    const version = versions.length ? versions.slice().sort((a, b) => VERSIONS.indexOf(b) - VERSIONS.indexOf(a))[0] : VERSIONS[0];
    const batchSeq = Math.floor(index / 3);
    return {
      index,
      category,
      code,
      shortName: SHORT_NAMES[category] ?? category,
      rootPath: '/data/primary/' + code,
      recordCount: list.length,
      recordIds: list.map((record) => record.id),
      failedCount: list.filter((record) => record.checkStatus === 'failed').length,
      version,
      baseVersion: VERSIONS[Math.max(0, VERSIONS.indexOf(version) - 1)],
      operator: list[0]?.operator ?? OPERATORS[index % OPERATORS.length],
      latestUpdatedAt: list.length ? list.map((record) => record.updatedAt).sort().slice(-1)[0] : formatDateTime(new Date()),
      batchSeq,
      batch: 'B-20260908-00' + (batchSeq + 1),
      extractBatch: 'E-20260908-00' + (batchSeq + 1),
      stage: STAGES[index] ?? STAGES[0]
    };
  });
}

/** 版本列表：从真实记录按类别派生 */
export function buildVersionRows(records: MetadataRecord[]): VersionRow[] {
  return buildChains(records).map((chain) => {
    const changeType = CHANGE_TYPES[chain.index % CHANGE_TYPES.length];
    return {
      id: chain.index + 1,
      product: chain.shortName,
      category: chain.category,
      version: chain.version,
      baseVersion: chain.baseVersion,
      changeType,
      operator: chain.operator,
      updatedAt: chain.latestUpdatedAt,
      status: chain.stage.store === 'completed' ? '当前版本' : '历史版本',
      changes: '本次' + changeType + '覆盖 ' + chain.recordCount + ' 条记录，来源批次 ' + chain.batch,
      batch: chain.batch,
      recordCount: chain.recordCount
    } as VersionRow;
  });
}

/** 数据资产报告：从真实记录聚合生成汇总 + 分类报告 */
export function buildReportRows(records: MetadataRecord[]): ReportRow[] {
  const chains = buildChains(records);
  const latestUpdated = records.length ? records.map((record) => record.updatedAt).sort().slice(-1)[0] : formatDateTime(new Date());
  const reports: ReportRow[] = [{
    id: 1,
    name: new Date().getFullYear() + '年初级产品资产总报告',
    products: chains.length + ' 类产品',
    format: 'Docx',
    createdAt: latestUpdated,
    status: '已生成',
    totalRecords: records.length,
    categories: chains.map((chain) => chain.category)
  }];
  chains.filter((chain) => chain.recordCount > 0).forEach((chain, index) => {
    reports.push({
      id: index + 2,
      name: chain.category + '数据资产报告',
      products: chain.recordCount + ' 条记录',
      format: 'Docx',
      createdAt: chain.latestUpdatedAt,
      status: '已生成',
      totalRecords: chain.recordCount,
      categories: [chain.category]
    } as ReportRow);
  });
  return reports;
}

/** 数据更新任务：从真实记录按类别派生 */
export function buildUpdateTasks(records: MetadataRecord[]): ExtractionTask[] {
  return buildChains(records).map((chain) => {
    const extract = chain.stage.extract;
    const progress = progressOf(extract, chain.category);
    const seq = String(chain.index + 1).padStart(3, '0');
    let message = '等待任务调度';
    let error: string | undefined;
    if (extract === 'completed') message = '数据已推送至申请方路径';
    else if (extract === 'running') message = '正在生成数据路径目录，当前进度 ' + progress + '%';
    else if (extract === 'paused') message = '网络故障，任务已自动暂停';
    else if (extract === 'error') {
      message = '上游检查未通过，无法提取';
      error = '关联检查任务失败（批次 ' + chain.batch + '），' + chain.failedCount + ' 条记录不合格';
    }
    return {
      id: chain.index + 1,
      name: chain.shortName + '提取-' + seq,
      productType: chain.category,
      batch: chain.extractBatch,
      requestSource: '业务系统需求-' + chain.category + '-' + seq,
      targetPath: '/delivery/' + chain.code + '-' + seq,
      progress,
      status: extract,
      message,
      error,
      recordIds: chain.recordIds
    } as ExtractionTask;
  });
}
