/**
 * platform 接口层共享请求 helper
 *
 * 复用主应用 request 实例，仅覆盖 baseURL 指向产品管理独立网关。
 * 响应拦截器已把 AxiosResponse 解包为业务体，故第二泛型直接声明 R = ApiResult<T>。
 */
import request from '@/utils/request';

// const PRODUCT_API = '/product-api';
/** 产品管理独立后端网关；主 request 的 baseURL 指向主应用后端，此处必须覆盖 */
export const PRODUCT_BASE_URL = import.meta.env.VITE_APP_BASE_API + '/datamanage/api';
// const PRODUCT_BASE_URL = import.meta.env.VITE_APP_BASE_API || '/product-api';

/** 合并产品网关 baseURL；调用方显式传入的 baseURL 优先 */
export const withProductBase = (config?: object) => ({ baseURL: PRODUCT_BASE_URL, ...config });

/** 后端统一包装体 */
export interface ApiResult<T = unknown> {
  code: number;
  message: string;
  data: T;
}

/** 后端统一错误明细（4xx/5xx 的 data 结构） */
export interface ApiErrorIssue {
  field: string;
  reason: string;
}

export interface ApiErrorDetail {
  errorCode: string;
  requestId: string;
  issues: ApiErrorIssue[];
  retryable: boolean;
}

/** 分页响应包装 */
export interface Paged<T> {
  items: T[];
  total: number;
}

export function apiGet<T>(url: string, config?: object) {
  return request.get<T, ApiResult<T>>(url, withProductBase(config));
}

export function apiPost<T, B = unknown>(url: string, body?: B, config?: object) {
  return request.post<T, ApiResult<T>, B>(url, body, withProductBase(config));
}

export function apiPut<T, B = unknown>(url: string, body?: B, config?: object) {
  return request.put<T, ApiResult<T>, B>(url, body, withProductBase(config));
}

export function apiPatch<T, B = unknown>(url: string, body?: B, config?: object) {
  return request.patch<T, ApiResult<T>, B>(url, body, withProductBase(config));
}

export function apiDelete<T>(url: string, config?: object) {
  return request.delete<T, ApiResult<T>>(url, withProductBase(config));
}

/** 路径参数编码；用于 {categoryKey} 等含特殊字符的段 */
export function seg(value: string) {
  return encodeURIComponent(value);
}
