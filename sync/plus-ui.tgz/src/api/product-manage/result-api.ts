/**
 * 兼容旧引用路径（成果模块任务列表接口）。
 *
 * 这三个 mock 接口已并入 `./mock/result`，但 `result-product` 下仍在用旧路径
 * `@/api/product-manage/result-api`。这里只做转发，避免重复维护。
 */
export {
  getResultStoreTaskList,
  getResultExtractionTaskList,
  getResultUpdateTaskList
} from './mock/result';
