/**
 * 兼容旧引用路径（成果领域类型）。
 *
 * 成果相关类型已统一收敛到 `./types/result`，但 `views/product-manage/result-product/**`
 * 下仍有大量 `@/api/product-manage/result-types` 的历史引用，
 * 目录里没有这个文件时打包会报 “Could not load .../result-types”。
 * 这里只做转发，避免重复维护两份定义。
 *
 * 后续建议：把这些引用统一改成 `@/api/product-manage/types/result`，然后删除本文件。
 */
export * from './types/result';
