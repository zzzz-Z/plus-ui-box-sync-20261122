/**
 * 元数据表矢量瓦片（MVT）
 *
 * 契约：GET /platform/resources/{resourceUid}/metadata-tables/{tableKey}/tiles/{z}/{x}/{y}.pbf
 * metadata-layer 接口的每张表已直接返回 `tileTemplate`，形如
 *   /api/platform/resources/{uid}/metadata-tables/{tableKey}/tiles/{z}/{x}/{y}.pbf
 * 这里只负责把模板转成 maplibre 的 `tiles: []` 数组，并统一补产品网关前缀。
 *
 * ## 实测（2026-11-02）
 *   - 产品网关 10.61.129.66:18083：z=2~13 有瓦片（约 2KB），z≥14 返回 404（服务端未出该级瓦片）；
 *   - MVT 图层名恒为 `metadata`（不是表名），属性键即字段英文名；
 *   - 统一网关 19999 对瓦片要 token，而 maplibre 取瓦片不经 axios，不会自动带 Authorization，
 *     故必须走 transformRequest 注入（见 map/vector-tile-layer.ts）。
 */
import { PRODUCT_BASE_URL } from '../http';

/**
 * tileTemplate → maplibre 源 URL。
 *
 * 模板来自后端，形如 `/api/platform/resources/...`；前端 baseURL 是 `/product-api`（会 rewrite 到
 * `/api`），故要先把模板里的 `/api` 前缀剥掉，再拼 PRODUCT_BASE_URL。
 *
 * CONSTRAINT 不硬编码 z/x/y：模板里就是 maplibre 认的 `{z}/{x}/{y}` 占位符，原样保留。
 */
export function toTileUrl(resourceUid: string, tableKey: string, tileTemplate?: string): string {
  const tpl =
    tileTemplate && tileTemplate.includes('{z}')
      ? tileTemplate
      : `/api/platform/resources/${resourceUid}/metadata-tables/${tableKey}/tiles/{z}/{x}/{y}.pbf`;
  // 去掉模板自带的 /api 前缀（网关内部路径），再由 PRODUCT_BASE_URL 统一补上
  const rel = tpl.replace(/^\/api/, '');
  const base = PRODUCT_BASE_URL.replace(/\/$/, '');
  return `${base}${rel}`;
}

/** 瓦片集的 MVT 图层名：后端固定 `metadata`，与 tableKey / 物理表名都无关 */
export const MVT_SOURCE_LAYER = 'metadata';
