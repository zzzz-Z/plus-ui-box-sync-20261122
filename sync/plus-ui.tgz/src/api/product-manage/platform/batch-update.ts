/**
 * 批量更新预览与事务提交接口
 *
 * 路径 /platform/metadata/updates；baseURL 由 request.ts 注入。
 * 两阶段协议：先 preview 冻结校验快照拿到 previewUid，再 commit 按该快照提交；
 * previewUid 过期或被并发修改则提交失败，需重新 preview。
 */
import { apiGet, apiPost, seg } from '../http';

const BATCH_BASE = '/platform/metadata/updates';

/** 单条校验问题 */
export interface BatchIssue {
  /** 出问题的记录 uid（整批级问题时为 undefined） */
  recordUid?: string;
  /** 出问题的字段名 */
  field?: string;
  /** 校验失败原因 */
  reason: string;
}

/** 预览结果；previewUid 为冻结快照句柄，可提交 */
export interface BatchPreview {
  /** 冻结快照句柄（提交时回传，过期需重新预览） */
  previewUid: string;
  /** 待更新记录总数 */
  total: number;
  /** 校验通过的记录数 */
  validCount: number;
  /** 校验失败的记录数 */
  invalidCount: number;
  /** 校验问题明细 */
  issues: BatchIssue[];
  /** 快照过期时间 */
  expiresAt?: string;
}

/** 提交结果 */
export interface BatchCommitResult {
  /** 异步提交任务 uid（同步提交完成时为空） */
  taskUid?: string;
  /** 成功提交的记录数 */
  committed: number;
  /** 因校验未通过被跳过的记录数 */
  skipped: number;
}

/** 预览整批元数据更新并校验；不产生写入 */
export function previewBatchUpdate(payload: { modelUid?: string; recordUids: string[]; patch: Record<string, unknown> }) {
  return apiPost<BatchPreview, typeof payload>(BATCH_BASE + '/preview', payload);
}

/** 读取已冻结的预览结果 */
export function getBatchPreview(previewUid: string) {
  return apiGet<BatchPreview>(BATCH_BASE + '/preview/' + seg(previewUid));
}

/** 按冻结预览事务提交更新；previewUid 失效时 409 */
export function commitBatchUpdate(previewUid: string) {
  return apiPost<BatchCommitResult, { previewUid: string }>(BATCH_BASE + '/commit', { previewUid });
}
