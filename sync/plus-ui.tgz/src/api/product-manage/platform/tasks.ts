/**
 * 统一任务与上传接口：任务查询 / 状态 / 错误 / 报告产物 / 上传会话
 * 文档：综合管理.md「resources」「配置类/元数据提取」统一任务部分
 */
import type { TaskArtifact, TaskError, UploadSession } from '../types/platform';
import { apiDelete, apiGet, apiPost, apiPut, PRODUCT_BASE_URL } from '../http';
import { globalHeaders } from '@/utils/request';

const BASE = '/platform';

/* -------- 任务文件层级（任务详情页 Contents） -------- */

/** 文件层级查询参数；prefix 为空表示任务根目录 */
export interface TaskFilesParams {
  /** 当前目录相对路径；空=任务根目录 */
  prefix?: string;
  /** 上一页的 nextCursor */
  cursor?: string;
  /** 每页条数，默认 50，最大 200 */
  limit?: number;
}

/** 文件层级条目：kind=目录 时无 downloadUrl；kind=文件 时必有 downloadUrl */
export interface TaskFileEntry {
  name: string;
  relativePath: string;
  kind: string;
  childCount?: number;
  sizeBytes?: number | null;
  mimeType?: string;
  sha256?: string;
  status?: string;
  artifactUid?: string;
  downloadUrl?: string;
}

/** 文件层级分页结果 */
export interface TaskFilesPage {
  prefix: string;
  count: number;
  fileCount: number;
  limit: number;
  total: number;
  totalRelation: string;
  hasMore: boolean;
  truncated: boolean;
  nextCursor?: string;
  files: TaskFileEntry[];
}

/** 查询任务下某一层的文件列表（GET /platform/tasks/{taskUid}/files） */
export function listTaskFiles(taskUid: string, params: TaskFilesParams = {}) {
  return apiGet<TaskFilesPage>(`${BASE}/tasks/${encodeURIComponent(taskUid)}/files`, { params });
}

/** 整任务 ZIP 下载（GET /platform/tasks/{taskUid}/origin-package），返回二进制流 */
export function downloadOriginPackage(taskUid: string) {
  return apiGet<Blob>(`${BASE}/tasks/${encodeURIComponent(taskUid)}/origin-package`, { responseType: 'blob' });
}

/* -------- 统一任务 -------- */

/** 统一任务进度；契约 progress 为对象而非旧版数字 */
export interface TaskProgress {
  /** 已完成数量 */
  completed: number;
  /** 总数量 */
  total: number;
  /** 完成百分比（0-100） */
  percent: number;
  /** 当前阶段描述 */
  stage: string;
}

export interface TaskListParams {
  /** 上一页的 nextCursor */
  cursor?: string;
  /** 每页条数 */
  limit?: number;
  /** 过滤条件（任务类型 / 状态 / 关键字等，由后端解释） */
  filter?: string;
}

/** 查询统一任务列表（游标分页） */
export function listTasks(params: TaskListParams = {}) {
  return apiGet<{ items: Array<{ taskUid: string; kind: string; state: string; progress?: TaskProgress; createdAt: string }>; nextCursor?: string }>(`${BASE}/tasks`, {
    params
  });
}

/** 查询任务详情 */
export function getTask(taskUid: string) {
  return apiGet<{ taskUid: string; kind: string; state: string; progress?: TaskProgress; message?: string }>(`${BASE}/tasks/${taskUid}`);
}

/** 查询任务状态（轻量，供轮询） */
export function getTaskStatus(taskUid: string) {
  return apiGet<{ state: string; progress?: TaskProgress }>(`${BASE}/tasks/${taskUid}`);
}

/** 查询任务错误明细列表 */
export function listTaskErrors(taskUid: string, params: TaskListParams = {}) {
  return apiGet<{ items: TaskError[]; nextCursor?: string }>(`${BASE}/tasks/${taskUid}/errors`, { params });
}

/** 查询任务报告 */
export function getTaskReport(taskUid: string) {
  return apiGet<{ report: unknown }>(`${BASE}/tasks/${taskUid}/report`);
}

/** 查询任务产物列表 */
export function listTaskArtifacts(taskUid: string, params: TaskListParams = {}) {
  return apiGet<{ items: TaskArtifact[]; nextCursor?: string }>(`${BASE}/tasks/${taskUid}/artifacts`, { params });
}

/** 查询产物详情 */
export function getArtifact(artifactUid: string) {
  return apiGet<TaskArtifact>(`${BASE}/artifacts/${artifactUid}`);
}

/** 下载产物文件 */
export function downloadArtifact(artifactUid: string) {
  return apiGet<Blob>(`${BASE}/artifacts/${artifactUid}/download`);
}

/* -------- 解析任务 -------- */

export function createParseTask(payload: { resourceUid?: string; dataUid?: string }) {
  return apiPost<{ taskUid: string }>(`${BASE}/parse-tasks`, payload);
}

/** 查询解析任务结果 */
export function getParseTaskResult(taskUid: string) {
  return apiGet<{ structure: unknown }>(`${BASE}/parse-tasks/${taskUid}/result`);
}

/* -------- 报告 / 通知 -------- */

/** 报告生成任务载荷；以下 7 个字段为契约必填，dateFrom/dateTo/requestId 可选 */
export interface ReportTaskPayload {
  /** 报告名称 */
  reportName: string;
  /** 目录 UID 列表，契约必填 */
  categoryUids: string[];
  /** 报告格式，契约必填 */
  formatCode: 'html' | 'pdf' | 'doc' | 'docx' | 'wps' | 'xls' | 'xlsx';
  /** 是否包含封面图，契约必填 */
  includeCoverMap: boolean;
  /** 是否包含元数据概览，契约必填 */
  includeMetadataOverview: boolean;
  /** 是否包含质量统计，契约必填 */
  includeQualityStats: boolean;
  /** 是否包含版本变更，契约必填 */
  includeVersionChange: boolean;
  /** 起始日期（可选） */
  dateFrom?: string;
  /** 结束日期（可选） */
  dateTo?: string;
  /** 幂等请求 ID（可选） */
  requestId?: string;
}

export function createReportTask(payload: ReportTaskPayload) {
  return apiPost<{ taskUid: string; kind: string; state: string; progress?: TaskProgress; reportArtifactUid?: string }>(`${BASE}/reports`, payload);
}

/** 查询通知列表 */
export function listNotifications(params: { read?: boolean } = {}) {
  return apiGet<{ items: Array<{ notificationUid: string; title: string; read: boolean; createdAt: string }>; total: number }>(
    `${BASE}/notifications`,
    { params }
  );
}

/* -------- 上传会话 -------- */

export interface UploadSessionPayload {
  /** 上传批次名称 */
  uploadName: string;
  /** 待上传文件清单（路径 + 字节大小） */
  manifest: Array<{ filePath: string; fileSize: number }>;
}

/** 创建上传会话 */
export function createUploadSession(payload: UploadSessionPayload) {
  return apiPost<UploadSession>(`${BASE}/uploads`, payload);
}

/** 查询上传会话与分片状态 */
export function getUploadSession(uploadUid: string) {
  return apiGet<{ uploadUid: string; parts: Array<{ fileUid: string; partNo: number; received: boolean }> }>(`${BASE}/uploads/${uploadUid}`);
}

/** 中止上传会话 */
export function abortUploadSession(uploadUid: string) {
  return apiDelete<{ uploadUid: string }>(`${BASE}/uploads/${uploadUid}`);
}

/** 上传单个分片 */
export function putUploadPart(uploadUid: string, fileUid: string, partNo: number, payload: { data: Blob }) {
  return apiPut<{ fileUid: string; partNo: number }>(`${BASE}/uploads/${uploadUid}/files/${fileUid}/parts/${partNo}`, payload);
}

/** 完成上传会话（合并分片） */
export function completeUploadSession(uploadUid: string, payload: { checksum?: string } = {}) {
  return apiPost<{ uploadUid: string; completed: boolean }>(`${BASE}/uploads/${uploadUid}/finalize`, payload);
}

/* -------- 统一任务实时订阅（SSE） -------- */

/**
 * 构造任务 SSE 订阅 URL。
 *
 * 契约要求网关关闭响应缓冲并支持长连接；浏览器原生 EventSource 不支持自定义
 * Authorization 头，故不能走 EventSource，需由调用方用 fetch + ReadableStream 消费。
 */
export function buildTaskEventsUrl(taskUid: string): string {
  return `${PRODUCT_BASE_URL}${BASE}/tasks/${taskUid}/events`;
}

/** SSE 事件载荷；契约事件名为 task.progress 与 task.terminal，data 与 GET /tasks/{uid} 同形 */
export interface TaskEventPayload {
  /** 事件名：task.progress / task.terminal / task.error 或其他自定义名 */
  event: string;
  /** SSE 事件序号（断线续订时作为 Last-Event-ID 回传） */
  id?: string;
  /** 任务快照；结构随任务类型而定 */
  data: unknown;
}

export interface TaskEventHandlers {
  /** 每次收到事件即回调 */
  onEvent?: (payload: TaskEventPayload) => void;
  /** 收到 task.terminal 时额外回调；之后连接会被服务端关闭 */
  onTerminal?: (payload: TaskEventPayload) => void;
  /** 连接或解析异常；不会 throw，由调用方决定是否重连 */
  onError?: (error: unknown) => void;
}

/**
 * 订阅任务实时进度。
 *
 * WHY 不返回 EventSource：契约要求携带 Authorization Bearer + clientid，原生
 * EventSource 不允许设置自定义请求头；用 fetch 读取 ReadableStream 自行解析 SSE。
 * CONSTRAINT 断线不回放历史事件（不支持 Last-Event-ID），重连需调用方自行发起。
 */
/**
 * 订阅任务实时进度。
 *
 * @param sinceId 断线续订用：上次收到的事件序号，会以 Last-Event-ID 头回传。
 */
export async function subscribeTaskEvents(taskUid: string, handlers: TaskEventHandlers, signal?: AbortSignal, sinceId?: string): Promise<void> {
  console.log(taskUid);

  try {
    // WHY Last-Event-ID：后端支持按序号续订，重连时带上可避免漏事件
    const headers: Record<string, string> = { ...(globalHeaders() as Record<string, string>), Accept: 'text/event-stream' };
    if (sinceId) headers['Last-Event-ID'] = String(sinceId);
    const res = await fetch(buildTaskEventsUrl(taskUid), { headers, signal });
    if (!res.ok || !res.body) {
      handlers.onError?.(new Error(`SSE 连接失败：HTTP ${res.status}`));
      return;
    }
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let sep = buffer.indexOf('\n\n');
      while (sep >= 0) {
        const raw = buffer.slice(0, sep);
        buffer = buffer.slice(sep + 2);
        sep = buffer.indexOf('\n\n');
        if (!raw || raw.startsWith(':')) continue;
        let eventName = 'message';
        let eventId: string | undefined;
        const dataLines: string[] = [];
        for (const line of raw.split('\n')) {
          if (line.startsWith('id:')) eventId = line.slice(3).trim();
          else if (line.startsWith('event:')) eventName = line.slice(6).trim();
          else if (line.startsWith('data:')) dataLines.push(line.slice(5).replace(/^ /, ''));
        }
        if (!dataLines.length) continue;
        const rawData = dataLines.join('\n');
        let parsed: unknown = rawData;
        try {
          parsed = JSON.parse(rawData);
        } catch {
          /* 契约 data 为 JSON；解析失败时保留原文，避免中断整个流 */
        }
        const payload: TaskEventPayload = { event: eventName, id: eventId, data: parsed };
        handlers.onEvent?.(payload);
        // 契约：task.terminal 后服务端关闭连接；task.error 表示事件流不可用
        if (eventName === 'task.terminal') handlers.onTerminal?.(payload);
        else if (eventName === 'task.error') handlers.onError?.(payload.data);
      }
    }
  } catch (error) {
    handlers.onError?.(error);
  }
}

/**
 * 订阅任务进度，并在 SSE 不可用时降级为 2 秒轮询。
 *
 * WHY 降级：网关/中间层可能缓冲或不支持 SSE；此时 fetch 会非 200 或立即结束，
 * 若不降级用户就永远看不到进度。轮询命中终态后自动停止。
 */
export async function subscribeTaskWithFallback(taskUid: string, handlers: TaskEventHandlers, signal?: AbortSignal, sinceId?: string): Promise<void> {
  let terminal = false;
  let sseFailed = false;

  const wrapped: TaskEventHandlers = {
    onEvent: (p) => handlers.onEvent?.(p),
    onTerminal: (p) => {
      terminal = true;
      handlers.onTerminal?.(p);
    },
    onError: (e) => {
      sseFailed = true;
      handlers.onError?.(e);
    }
  };

  await subscribeTaskEvents(taskUid, wrapped, signal, sinceId);

  if (terminal || signal?.aborted) return;

  // SSE 结束但未收到终态（网关缓冲 / 断流 / 非 200）→ 轮询兜底
  if (!sseFailed && !terminal) return;

  while (!terminal && !signal?.aborted) {
    await new Promise((r) => setTimeout(r, 2000));
    if (signal?.aborted) return;
    try {
      const res: any = await getTask(taskUid);
      const task = res?.data ?? res;
      if (!task) continue;
      // 契约：快照状态读 state、进度读 progress.percent（旧版为 status / 数字 progress）；data 透传完整任务快照
      const payload: TaskEventPayload = { event: 'task.progress', data: task };
      handlers.onEvent?.(payload);
      const state = String(task.state ?? '');
      if (state && !/待处理|排队|QUEUED|RUNNING|运行中|处理中/.test(state)) {
        terminal = true;
        handlers.onTerminal?.({ event: 'task.terminal', data: task });
      }
    } catch (e) {
      handlers.onError?.(e);
      return;
    }
  }
}
