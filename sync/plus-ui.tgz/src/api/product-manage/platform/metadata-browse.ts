/**
 * 元数据浏览接口族：浏览树 / 单资源元数据图层 / 地图要素属性表
 *
 * 契约来源：Apifox「元数据管理模块 / 元数据 / 元数据浏览」
 *   - GET /api/platform/metadata/tree                          docId 529576518
 *   - GET /api/platform/resources/{resourceUid}/metadata-layer  docId 529630822
 *   - GET /api/platform/resources/{resourceUid}/metadata-attributes docId 529576519
 *
 * ## 上线状态（2026-11-02 实测）
 *
 * 统一网关 `10.61.129.27:19999/datamanage/api` 仍无这三个路由（drogon HTML 404），
 * 但**产品管理独立网关 `10.61.129.66:18083/api`（前端 `/product-api` 代理目标）已全部上线**：
 *   - GET /platform/metadata/tree                                  → 200，code 0，87 节点
 *   - GET /platform/resources/{uid}/metadata-layer                 → 200，带 metadataTables
 *   - GET /platform/resources/{uid}/metadata-attributes            → 路由存在（该资源无表时业务码 40404）
 *
 * 前端 `http.ts` 的 PRODUCT_BASE_URL 恒为 `/product-api`，走的正是后者，故页面可直接接入。
 * 元数据浏览树的页面主链路已切到 `getMetadataBrowseTree()`（见 data-browse/index.vue），
 * 不再由 `getProductCategoryTree() + listResources()` 在前端拼装。
 *
 * ⚠️ 部署口径：生产 nginx 必须与开发一致地把 `/product-api` 反代到产品网关，
 * 否则整块产品管理（含本树）会 404。
 *
 * WHY 独立文件而不是塞进 resources.ts：这是「元数据浏览」这条业务链路自己的资源族
 * （树的语义、图层的多表语义、属性表的分页语义都不同），塞进 resources.ts 会让那个文件
 * 同时承担资源 CRUD 与浏览链路两种关注点。
 */
import { apiGet, seg } from '../http';

/** 元数据浏览树的节点类型（契约 enum） */
export type MetadataTreeNodeType = 'category' | 'resource';

/**
 * 元数据浏览树节点（GET /platform/metadata/tree）
 *
 * 与资源目录树节点（`ResourceTreeCategoryNode`/`ResourceTreeResourceNode`，按 `nodeType` 异构）
 * **字段名完全不同**，不可互相赋值。
 * 契约要求只有两级语义：「产品类别 → 任务（资源）」，不返回图层节点。
 */
export interface MetadataTreeNode {
  /** 节点类型；`resource` 是资源叶子，`category` 是产品类别 */
  nodeType: MetadataTreeNodeType;
  /** 节点唯一标识（资源节点即 resourceUid，类别节点即 categoryUid） */
  uid: string;
  /** 展示名 */
  displayName: string;
  /** 产品类别中文名（类别节点） */
  categoryName?: string;
  /** 产品类别 key（类别节点） */
  categoryKey?: string;
  /** 父类别 UID；顶层为 null */
  parentCategoryUid?: string | null;
  /** 节点状态：类别节点是「可用」等，资源节点是中文状态（就绪 / 待处理） */
  state?: string;
  /** 类别节点状态（实测返回「可用」，与 state 并存，按需取用） */
  status?: string;
  /** 该类别下资源数（类别节点有意义） */
  resourceCount?: number;
  /**
   * 该资源持有的矢量图层数（资源节点有意义）。
   *
   * 契约明确：**没有矢量图层的资源仍然保留在树中，layerCount=0，不伪造图层**。
   * 故前端不能按 `layerCount > 0` 过滤节点。
   */
  layerCount?: number;
  /** 资源所属类别 UID（资源节点）；等价于父类别节点的 uid */
  categoryUid?: string;
  /** 资源数据类型（资源节点；vector / raster / table / text） */
  dataType?: string;
  /** 资源英文名（资源节点，可为 null） */
  nameEn?: string | null;
  /** 资源版本号（资源节点） */
  version?: number;
  /** 创建 / 更新时间（资源节点，实测格式 `2026/10/31 16:21`） */
  createdAt?: string;
  updatedAt?: string;
  /** 子节点；资源节点的 children 恒为空数组 */
  children?: MetadataTreeNode[];
}

/** 浏览树响应 */
export interface MetadataTreeResult {
  items: MetadataTreeNode[];
  /** 顶层节点数 */
  total: number;
}

/**
 * 查询元数据浏览树。
 *
 * 已上线（2026-11-02 实测，产品网关 `/product-api` 下 200 / code 0）。
 * 后端**不返回图层节点**，且没有矢量图层的资源也保留在树中（`layerCount=0`），
 * 前端不得按 `layerCount > 0` 过滤，否则用户看到的分类体系与账本不一致。
 */
export function getMetadataBrowseTree() {
  return apiGet<MetadataTreeResult>('/platform/metadata/tree');
}

/**
 * 单个资源的元数据图层（GET /platform/resources/{resourceUid}/metadata-layer）
 *
 * 与 `listMetadataLayers` 的区别：那个是**按条件分页列出多个资源**的图层，
 * 这个是**按 resourceUid 拿单个资源**的全部元数据表。
 */
export interface ResourceMetadataLayer {
  resourceUid: string;
  resourceName: string;
  /** 一个模型可有多张表，每张表一份 GeoJSON（契约 required） */
  metadataTables: Array<{
    /** 账本 table_key，**不是**物理表名 */
    metadataTableKey: string;
    /** PostgreSQL 物理表名 `md_<清洗值>_<8位哈希>` */
    metadataTableName: string;
    /** 表注释，只记来源元数据文件主名 */
    metadataTableComment: string;
    /**
     * 表的中文展示名（2026-11-03 实测新增）。
     *
     * WHY 单列：`metadataTableKey` 是英文账本键（如 `flys_sx`），直接当页签/图例文案
     * 用户看不懂；后端补了 `displayName` 就是为了给前端做展示名。
     * 契约文档尚未写该字段，故声明为可选，调用方按 `displayName → layerName → key` 兜底。
     */
    displayName?: string;
    /** 图层展示名（与 displayName 同值的情况居多，作兜底） */
    layerName?: string;
    /** 经纬度范围 [minLng, minLat, maxLng, maxLat] */
    extent2d?: number[];
    /** 瓦片模板（含 {z}/{x}/{y}） */
    tileTemplate?: string;
    geojson?: { type?: string; features?: any[] };
  }>;
}

/**
 * 查询单个资源的元数据图层。
 *
 * 2026-11-03 实测已上线（网关 200）。契约错误码 401 / 404，
 * 其中 404 语义是「该资源没有元数据表」，UI 应显示空态而非报错。
 *
 * @param config 透传 axios 配置。选资源探表场景传 { headers: { 'x-best-effort': '1' } }，
 *   让无表资源的 404 不弹全局错误 toast，由调用方 catch 后显示空态。
 */
export function getResourceMetadataLayer(resourceUid: string, config?: object) {
  return apiGet<ResourceMetadataLayer>(`/platform/resources/${seg(resourceUid)}/metadata-layer`, config);
}

/**
 * 地图要素属性表记录（GET /platform/resources/{resourceUid}/metadata-attributes）
 *
 * `values` 是一行的列值对象（列名 → 值），**不是**数组。
 */
export interface MetadataAttributeRecord {
  /** 该行所属的账本 table_key */
  tableKey: string;
  /** PostgreSQL 物理表名 */
  pgTable: string;
  /** 列名 → 值 */
  values: Record<string, unknown>;
}

/** 要素属性表响应 */
export interface MetadataAttributesResult {
  resourceUid: string;
  /** 本次查询的表键；为空表示查了全部表 */
  tableKey?: string;
  versionUid?: string;
  metadataSchema?: string;
  /** 列名列表（按后端顺序） */
  fields: string[];
  records: MetadataAttributeRecord[];
  total: number;
  page: number;
}

/** `listMetadataAttributes` 的业务输入 */
export interface MetadataAttributesQueryInput {
  /** 账本 table_key；为空则返回该资源全部表 */
  tableKey?: string;
  /** 页码，从 1 开始（**注意不是项目的 pageNum**） */
  page?: number;
  /** 每页条数，1-200，默认 50 */
  pageSize?: number;
}

/** 属性表单页条数上限（契约 1-200） */
export const METADATA_ATTR_PAGE_SIZE_MAX = 200;
/** 属性表单页条数默认值（契约默认 50） */
export const METADATA_ATTR_PAGE_SIZE_DEFAULT = 50;

/**
 * 载荷拼装：唯一出口。
 *
 * 契约分页字段是 `page` / `pageSize`，与项目通用分页 `pageNum` / `pageSize` 不同名，
 * 页面直接透传 Table 的 params 会把 `pageNum` 送上去被后端忽略 —— 收敛在这里避免。
 */
export function buildMetadataAttributesQuery(input: MetadataAttributesQueryInput = {}): MetadataAttributesQueryInput {
  const size = Number(input.pageSize ?? METADATA_ATTR_PAGE_SIZE_DEFAULT);
  const page = Number(input.page ?? 1);
  return {
    tableKey: input.tableKey || undefined,
    page: Number.isFinite(page) && page > 0 ? Math.trunc(page) : 1,
    pageSize: Math.min(METADATA_ATTR_PAGE_SIZE_MAX, Math.max(1, Number.isFinite(size) ? Math.trunc(size) : METADATA_ATTR_PAGE_SIZE_DEFAULT))
  };
}

/**
 * 查询地图要素属性表。
 *
 * 文档明确的使用时机：点击地图要素后，用该要素所属的 `metadataTableKey` 调本接口。
 *
 * ⚠️ 后端未上线（网关 404）。
 */
export function listMetadataAttributes(resourceUid: string, input: MetadataAttributesQueryInput = {}) {
  return apiGet<MetadataAttributesResult>(`/platform/resources/${seg(resourceUid)}/metadata-attributes`, {
    params: buildMetadataAttributesQuery(input)
  });
}

/**
 * 探测三个接口是否已上线。
 *
 * WHY：后端上线是异步事件，页面不能靠「改代码」感知。留一个可复跑的探针，
 * 上线当天先跑它再接线，避免拿 404 当「没数据」排查半天。
 *
 * 返回每个接口的可用性；任一失败不抛错（探针语义是「报告」不是「断言」）。
 */
export async function probeMetadataBrowseApis(resourceUid?: string): Promise<Record<string, boolean>> {
  const result: Record<string, boolean> = { tree: false, layer: false, attributes: false };
  await Promise.all([
    getMetadataBrowseTree()
      .then(() => (result.tree = true))
      .catch(() => (result.tree = false)),
    resourceUid
      ? getResourceMetadataLayer(resourceUid)
          .then(() => (result.layer = true))
          .catch(() => (result.layer = false))
      : Promise.resolve(),
    resourceUid
      ? listMetadataAttributes(resourceUid)
          .then(() => (result.attributes = true))
          .catch(() => (result.attributes = false))
      : Promise.resolve()
  ]);
  return result;
}
