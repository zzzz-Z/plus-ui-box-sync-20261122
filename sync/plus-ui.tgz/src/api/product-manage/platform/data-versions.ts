/**
 * 产品数据版本接口层（doc-9701308）
 *
 * 面向 tb_resource_data 的产品数据版本（resourceUid + dataKey），
 * 与 metadata-versions.ts 的「元数据记录版本」是两套不同口径。
 * 版本管理页的版本日志 / 详情 / 文件变更列表均走本接口族。
 *
 * 契约示例里 items[] 多为空数组，元素字段靠正文说明，故类型全部宽松可选，
 * 页面侧再做别名兼容（normalizeXxx），避免后端字段漂移导致整页空白。
 */
import { apiGet, apiPost, seg } from '../http';

const RESOURCE_BASE = '/platform/resources';

export function dataVersionsBase(resourceUid: string) {
  return `${RESOURCE_BASE}/${seg(resourceUid)}/data-versions`;
}

/** 版本日志项（SVN 式一行一版本）；后端字段可能漂移，全部可选 */
export interface DataVersionLogItem {
  versionUid?: string;
  versionNo?: number;
  dataKey?: string;
  name?: string;
  /** commit message（2026-11-19 新增字段） */
  information?: string;
  message?: string;
  summary?: string;
  changeSummary?: string | Record<string, unknown>;
  operation?: string;
  operationText?: string;
  op?: string;
  createdByRef?: string;
  createdBy?: string;
  author?: string;
  actor?: string;
  createdAt?: string;
  createdTime?: string;
  date?: string;
  isCurrent?: boolean;
  isLatest?: boolean;
  parentVersionUid?: string;
  parentVersionNo?: number;
  layerCount?: number;
  featureCount?: number;
  dataChanged?: number;
  changeCount?: number;
  [key: string]: unknown;
}

export interface DataVersionLogResult {
  resourceUid?: string;
  items?: DataVersionLogItem[];
  total?: number;
  page?: number;
  pageSize?: number;
}

/** 数据版本列表项 */
export interface DataVersionItem extends DataVersionLogItem {
  state?: string;
  stateText?: string;
  importUid?: string;
  truncated?: boolean;
}

export interface DataVersionListResult {
  resourceUid?: string;
  items?: DataVersionItem[];
  total?: number;
  page?: number;
  pageSize?: number;
  truncated?: boolean;
}

/** 变更数量汇总 */
export interface DataVersionChangeSummary {
  dataChanged?: number;
  fileAdded?: number;
  fileChanged?: number;
  fileRemoved?: number;
  layerAdded?: number;
  layerChanged?: number;
  layerRemoved?: number;
  metadataTableAdded?: number;
  metadataTableChanged?: number;
  metadataTableRemoved?: number;
  [key: string]: unknown;
}

/** 版本文件条目（文件变更列表数据源） */
export interface DataVersionFile {
  relativePath?: string;
  path?: string;
  name?: string;
  sizeBytes?: number;
  sha256?: string;
  artifactUid?: string;
  /** added / changed / removed / modified */
  status?: string;
  inheritedFromVersionUid?: string;
  addLines?: number;
  addedLines?: number;
  linesAdded?: number;
  insertLines?: number;
  delLines?: number;
  deletedLines?: number;
  linesDeleted?: number;
  deleteLines?: number;
  [key: string]: unknown;
}

/** 版本详情（信息区 + 文件变更列表） */
export interface DataVersionDetail {
  versionUid: string;
  versionNo: number;
  dataKey?: string;
  name?: string;
  state?: string;
  stateText?: string;
  information?: string;
  message?: string;
  changeSummary?: DataVersionChangeSummary;
  files?: DataVersionFile[];
  layers?: unknown[];
  metadataTables?: unknown[];
  lineage?: unknown;
  previousVersionUid?: string | null;
  changeManifest?: {
    added?: unknown[];
    changed?: unknown[];
    removed?: unknown[];
    files?: { added?: unknown[]; changed?: unknown[]; removed?: unknown[] };
    [key: string]: unknown;
  };
  createdAt?: string;
  createdByRef?: string;
  [key: string]: unknown;
}

/** 比较结果中的三类变更分组 */
export interface DataVersionChangeGroup {
  added?: DataVersionFile[];
  changed?: DataVersionFile[];
  removed?: DataVersionFile[];
}

export interface DataVersionCompareResult {
  resourceUid?: string;
  dataKey?: string;
  from?: { versionUid?: string; versionNo?: number };
  to?: { versionUid?: string; versionNo?: number };
  dataChanges?: unknown[];
  layerChanges?: DataVersionChangeGroup;
  metadataTableChanges?: DataVersionChangeGroup;
  fileChanges?: DataVersionChangeGroup;
  summary?: DataVersionChangeSummary;
}

export interface DataVersionLogQuery {
  page?: number;
  pageSize?: number;
}

/** 版本日志（截图「版本树 | 操作 | 信息 | 作者 | 日期」数据源） */
export function getDataVersionLog(resourceUid: string, params: DataVersionLogQuery = {}) {
  return apiGet<DataVersionLogResult>(`${RESOURCE_BASE}/${seg(resourceUid)}/data-version-log`, {
    params: { page: params.page ?? 1, pageSize: Math.min(params.pageSize ?? 20, 200) }
  });
}

export interface DataVersionListQuery {
  page?: number;
  pageSize?: number;
  dataKey?: string;
  state?: string;
  keyword?: string;
  fromTime?: string;
  toTime?: string;
  includeDeleted?: boolean;
}

/** 数据版本列表（版本日志为空时的回退数据源） */
export function listDataVersions(resourceUid: string, params: DataVersionListQuery = {}) {
  const query: Record<string, string | number | boolean> = {
    page: params.page ?? 1,
    pageSize: Math.min(params.pageSize ?? 20, 200)
  };
  if (params.dataKey) query.dataKey = params.dataKey;
  if (params.state) query.state = params.state;
  if (params.keyword) query.keyword = params.keyword;
  if (params.fromTime) query.fromTime = params.fromTime;
  if (params.toTime) query.toTime = params.toTime;
  if (params.includeDeleted) query.includeDeleted = true;
  return apiGet<DataVersionListResult>(dataVersionsBase(resourceUid), { params: query });
}

/** 版本详情 */
export function getDataVersionDetail(resourceUid: string, versionUid: string) {
  return apiGet<DataVersionDetail>(`${dataVersionsBase(resourceUid)}/${seg(versionUid)}`);
}

/** 版本比较（文件变更列表的 added/changed/removed 数据源） */
export function compareDataVersions(resourceUid: string, fromVersionUid: string, toVersionUid: string) {
  return apiGet<DataVersionCompareResult>(`${dataVersionsBase(resourceUid)}/compare`, {
    params: { fromVersionUid, toVersionUid }
  });
}

/** 恢复数据版本请求体（requestId 幂等、expectedLatestVersionNo 乐观并发） */
export interface RestoreDataVersionBody {
  requestId?: string;
  expectedLatestVersionNo?: number;
  reason?: string;
}

/** 恢复数据版本结果（生成新版本，旧版本保留） */
export interface RestoreDataVersionResult {
  newVersionUid?: string;
  newVersionNo?: number;
  restoredFromVersionUid?: string;
  copiedLayers?: number;
  copiedMetadataTables?: number;
  copiedFiles?: number;
  idempotentReplay?: boolean;
  [key: string]: unknown;
}

/** 恢复数据版本：POST /data-versions/{versionUid}/restore */
export function restoreDataVersion(resourceUid: string, versionUid: string, body: RestoreDataVersionBody = {}) {
  return apiPost<RestoreDataVersionResult>(`${dataVersionsBase(resourceUid)}/${seg(versionUid)}/restore`, body);
}

/** 资源存储容量（注意路径不在 data-versions 前缀下） */
export interface ResourceStorageSummary {
  resourceUid?: string;
  currentLogicalBytes?: number;
  totalObjectBytes?: number;
  versionCount?: number;
  currentVersions?: unknown[];
  [key: string]: unknown;
}

/** 资源存储容量：GET /platform/resources/{resourceUid}/storage-summary */
export function getResourceStorageSummary(resourceUid: string) {
  return apiGet<ResourceStorageSummary>(`${RESOURCE_BASE}/${seg(resourceUid)}/storage-summary`);
}
