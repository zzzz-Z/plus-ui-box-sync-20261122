/**
 * 存储配置接口：连接 / 位置 / 后端 / 矢量库 / 位置操作任务
 * 文档：综合管理.md 「配置类/存储配置」
 */
import type { StorageBackend, StorageConnection, StorageLocation, VectorDatabase } from '../types/platform';
import { apiDelete, apiGet, apiPatch, apiPost } from '../http';

const BASE = '/platform/config/storage';

/** 存储后端运行状态接口独立前缀；契约明确非 /config/storage 子路径 */
const BACKEND_BASE = '/platform/storage/backends';

/* -------- 连接 -------- */

export interface ConnectionListParams {
  /** 按启用状态过滤 */
  enabled?: boolean;
  /** 关键字（匹配连接名称/类型） */
  keyword?: string;
}

/** 查询存储连接列表 */
export function listConnections(params: ConnectionListParams = {}) {
  return apiGet<{ items: StorageConnection[]; total: number }>(`${BASE}/connections`, { params });
}

/** 存储连接新增/修改请求体 */
export interface ConnectionPayload {
  /** 连接名称 */
  connectionName: string;
  /** 连接类型（如 S3 / HDFS / NAS） */
  connectionType: string;
  /** 服务端点地址 */
  endpoint?: string;
  /** 凭据键值对（如 accessKey / secretKey） */
  credentials?: Record<string, string>;
  /** 是否启用（缺省由服务端决定） */
  enabled?: boolean;
}

/** 新增存储连接 */
export function createConnection(payload: ConnectionPayload) {
  return apiPost<StorageConnection>(`${BASE}/connections`, payload);
}

/** 查询存储连接详情 */
export function getConnection(connectionUid: string) {
  return apiGet<StorageConnection>(`${BASE}/connections/${connectionUid}`);
}

/** 修改存储连接 */
export function updateConnection(connectionUid: string, payload: Partial<ConnectionPayload>) {
  return apiPatch<StorageConnection>(`${BASE}/connections/${connectionUid}`, payload);
}

/** 删除存储连接 */
export function deleteConnection(connectionUid: string) {
  return apiDelete<{ connectionUid: string }>(`${BASE}/connections/${connectionUid}`);
}

/** 将指定连接版本设为生效版本 */
export function activateConnectionVersion(connectionUid: string, version: number) {
  return apiPost<StorageConnection>(`${BASE}/connections/${connectionUid}/versions/${version}/activate`);
}

/** 检测存储连接可用性 */
export function checkConnection(connectionUid: string) {
  return apiPost<{ ok: boolean; message?: string }>(`${BASE}/connections/${connectionUid}/checks`);
}

/** 查询连接下的对象桶列表 */
export function listConnectionBuckets(connectionUid: string) {
  return apiGet<{ items: string[] }>(`${BASE}/connections/${connectionUid}/buckets`);
}

/** 查询连接下的共享目录列表 */
export function listConnectionSharedDirectories(connectionUid: string) {
  return apiGet<{ items: string[] }>(`${BASE}/connections/${connectionUid}/shared-directories`);
}

/* -------- 位置 -------- */

export interface LocationListParams {
  /** 限定所属连接 uid */
  connectionUid?: string;
  /** 关键字（匹配位置名称/路径） */
  keyword?: string;
  /** 按启用状态过滤 */
  enabled?: boolean;
}

/**
 * 查询已登记共享位置列表。
 *
 * CONSTRAINT 后端**没有** `/platform/config/storage/locations` 列表接口（404）。
 * 真实列表是 `/storage?kind=shared_directory`（storage-config.ts 的 listStorageConfigs）；
 * 返回项用 uid/displayName 命名，与 StorageLocation 的 locationUid/locationName 不是同一形状。
 * 保留本函数仅为兼容旧引用；新代码请用 listStorageConfigs({ kind: 'shared_directory' })。
 */
export function listLocations(params: LocationListParams = {}) {
  return apiGet<{ items: StorageLocation[]; total: number }>(`${BASE}/locations`, { params });
}

/** 存储位置新增/修改请求体 */
export interface LocationPayload {
  /** 位置名称 */
  locationName: string;
  /** 位置类型（如 目录 / 对象桶） */
  locationType: string;
  /** 所属存储连接 uid */
  connectionUid?: string;
  /** 位置路径 */
  path?: string;
  /** 是否启用（缺省由服务端决定） */
  enabled?: boolean;
}

/** 新增存储位置 */
export function createLocation(payload: LocationPayload) {
  return apiPost<StorageLocation>(`${BASE}/locations`, payload);
}

/** 查询存储位置详情 */
export function getLocation(locationUid: string) {
  return apiGet<StorageLocation>(`${BASE}/locations/${locationUid}`);
}

/** 修改存储位置 */
export function updateLocation(locationUid: string, payload: Partial<LocationPayload>) {
  return apiPatch<StorageLocation>(`${BASE}/locations/${locationUid}`, payload);
}

/** 删除存储位置 */
export function deleteLocation(locationUid: string) {
  return apiDelete<{ locationUid: string }>(`${BASE}/locations/${locationUid}`);
}

/** 检测存储位置可用性 */
export function checkLocation(locationUid: string) {
  return apiPost<{ ok: boolean; message?: string }>(`${BASE}/locations/${locationUid}/checks`);
}

/** 强制删除存储位置（异步任务） */
export function forceDeleteLocation(locationUid: string) {
  return apiPost<{ jobUid: string }>(`${BASE}/locations/${locationUid}/force-delete`);
}

/** 查询位置强制删除任务列表 */
export function listForceDeletionJobs(locationUid: string) {
  return apiGet<{ items: unknown[] }>(`${BASE}/locations/${locationUid}/force-deletion-jobs`);
}
/**
 * browse 目录项（T6a 契约 2026-11-08）。
 *
 * CONSTRAINT 三个路径字段语义不同，混用会把错误值当 files 提交：
 *   - `path`：**登记根相对路径，导航语义**（进入目录用），不要直接当 files 元素；
 *   - `relativePath`：相对**本次浏览目录**的路径，**这才是 files 元素**；
 *   - `fullPath`（在 StorageBrowseResult 上）：完整共享路径，只用于展示。
 */
export interface StorageBrowseEntry {
  /** 登记根相对路径（导航语义，不要直接当 files） */
  path: string;
  /** 名称（不含路径） */
  name: string;
  /** 类型；契约仅此二值 */
  type: 'file' | 'directory';
  /** 字节数；目录项为 null */
  size: number | null;
  /** 修改时间（Unix epoch 毫秒） */
  modifiedTime: number;
  /** 相对**本次浏览目录**的路径，直接作为检查/入库 files 元素 */
  relativePath: string;
  /** 是否可在入库页选择：目录 false，所有普通文件 true */
  selectable: boolean;
  /**
   * 是否可在检查页选择：仅 SMS/GeoJSON 元数据文件 true。
   *
   * WHY 必须按它过滤：entries 现在返回**全部普通文件**（.shp/.zip 都在），
   * 检查页若不滤会选到 .zip 之类非元数据文件，提交后端必然 400。
   */
  checkable: boolean;
  /**
   * 父目录（相对当前浏览目录）；recursive=true 时由后端给出，用于扁平 entries 建树。
   * 非递归响应可能没有该字段，建树时按 path 自行推导兜底。
   */
  parentPath?: string;
  /** 相对当前浏览目录的深度；recursive=true 时 >0 表示嵌套层，非递归恒为直接子项 */
  depth?: number;
}

/**
 * browse 响应数据体。
 *
 * CONSTRAINT 来源描述 5 字段（sourceType/sourceStorageUid/sourceKind/sourceKindCode/
 * dataRootPath）可直接拼检查/入库请求：把 `dataRootPath` 与 `entries[].relativePath`
 * 原样交出即可，**不要**用 fullPath 提交、也不要自己裁剪前缀。
 */
export interface StorageBrowseResult {
  /** 登记位置 uid，入参回显（UNC 浏览时为 null/空） */
  locationUid?: string;
  /** 本次列举的相对路径；空字符串表示根 */
  path: string;
  /** 登记共享根原始文本（UNC 或挂载路径），仅供展示 */
  rootPath?: string;
  /** 登记位置内的子路径（/ 分隔，可为空） */
  registeredSubPath?: string;
  /** 完整共享路径（根 + 子路径 + 当前相对路径），仅供展示，不要当 dataRootPath 提交 */
  fullPath?: string;
  /** 服务端生效的 limit */
  limit?: number;
  /**
   * 是否被截断；原因见 truncatedReason（2026-11-12 契约新增）。
   *
   * CONSTRAINT 判断「要不要续页」看 nextCursor 而不是 truncated 本身：
   * truncatedReason=max_depth 时没有 nextCursor，得进入子目录继续浏览。
   */
  truncated: boolean;
  /** 截断原因：limit（还有下一页，用 nextCursor）/ max_depth（达深度上限，需进子目录） */
  truncatedReason?: string;
  /** 下一页游标；空表示没有更多（仅 recursive=true 且 truncatedReason=limit 时有值） */
  nextCursor?: string;
  /** 服务端生效的 maxDepth（仅递归） */
  maxDepth?: number;
  /** 是否本次为递归列举 */
  recursive?: boolean;
  /** 条目列表；recursive=true 时是**扁平**的多层 entries，按 depth/parentPath 建树 */
  entries: StorageBrowseEntry[];
  /** 来源类型机器码；已登记共享固定 registered_share，UNC 浏览为 direct_shared_path */
  sourceType?: string;
  /** 已登记共享存储位置 uid；UNC 浏览时为 null */
  sourceStorageUid?: string | null;
  /** 来源类型中文展示（已登记共享路径） */
  sourceKind?: string;
  /** 来源类型机器码（与 sourceKind 对应） */
  sourceKindCode?: string;
  /** 根路径（UNC 浏览时是用户输入的完整 UNC），作为检查/入库的 dataRootPath */
  dataRootPath?: string;
}

/** browse 请求参数（两个 browse 接口共用） */
export interface StorageBrowseParams {
  /** 相对路径（登记根内，或相对 uncPath）；空/省略表示根 */
  path?: string;
  /** 是否递归列出多层；默认 false（保持旧行为） */
  recursive?: boolean;
  /** 每页条数；建议 1000 */
  limit?: number;
  /** 仅 recursive=true 且上一页 truncatedReason=limit 时使用 */
  cursor?: string;
  /** 递归最大深度 1..256，默认 16；仅 recursive=true 使用 */
  maxDepth?: number;
}

/**
 * 实时浏览已登记共享目录（逐层选择文件/目录）。
 *
 * CONSTRAINT 只读、不上传/不复制、不创建上传记录；服务端用位置 UID 解析已登记的
 * 加密凭据建共享会话后枚举，**不返回密码或物理根路径**。path 省略或空串表示登记根，
 * 子目录用 / 分隔的相对路径。该 UID 可随后作为提交检查任务的 sourceStorageUid 复用。
 *
 * 2026-11-12 起支持 recursive/cursor/maxDepth：一次性返回多层扁平 entries，
 * 由调用方按 depth/parentPath 建树；truncatedReason=limit 用 nextCursor 续页。
 */
export function browseLocation(locationUid: string, params: StorageBrowseParams = {}) {
  return apiGet<StorageBrowseResult>(`${BASE}/locations/${locationUid}/browse`, { params });
}

/**
 * 浏览**用户输入的 UNC 路径**（未登记共享目录）。
 *
 * WHY 单独一个端点：`/locations/{uid}/browse` 必须已有登记位置与凭据；
 * 用户直接粘 UNC 时没有 uid，服务端按最长前缀匹配已登记且 active 的共享目录并复用其凭据，
 * 没有匹配才尝试匿名 guest。响应额外带 sourceType=direct_shared_path 与 dataRootPath。
 */
export function browseUncPath(uncPath: string, params: StorageBrowseParams = {}) {
  return apiGet<StorageBrowseResult>(`${BASE}/browse`, { params: { ...params, uncPath } });
}

/** 解析 browse 响应里的截断原因，决定是续页还是提示进子目录 */
export function describeBrowseTruncation(result?: StorageBrowseResult | null): string {
  if (!result?.truncated) return '';
  if (result.truncatedReason === 'max_depth') return '已达到递归深度上限，请进入子目录继续浏览';
  if (result.truncatedReason === 'limit') return result.nextCursor ? '还有更多内容，可点「继续加载」' : '已达到单页上限，请缩小浏览目录';
  return '结果已截断，请缩小浏览目录';
}

/* -------- 存储后端 -------- */

/** 存储后端运行状态：契约字段见 StorageController::backendToJson */
export interface StorageBackendStatus {
  /** 后端代码 */
  backendCode: string;
  /** 后端类型（如 minio / shared_fs） */
  type: string;
  /** 展示名 */
  displayName: string;
  /** 是否为默认后端 */
  default: boolean;
  /** 健康检查是否可用 */
  available: boolean;
  /** 可用性说明 */
  message: string;
  /** 当前实现恒为 true */
  supportsResume: boolean;
  /** 是否支持客户端直传 */
  supportsDirectClientUpload: boolean;
  /** 上传模式 */
  uploadMode: string;
  /** 容量信息（结构由后端定义） */
  capacity: unknown;
}

/** 查询全部存储后端运行状态；返回 items + defaultBackendCode（非分页结构） */
export function listBackends() {
  return apiGet<{ items: StorageBackendStatus[]; defaultBackendCode: string }>(BACKEND_BASE);
}

/** 查询单个存储后端运行状态；data 即后端对象本身，不套 items */
export function getBackend(backendCode: string) {
  return apiGet<StorageBackendStatus>(`${BACKEND_BASE}/${backendCode}`);
}

/* -------- 矢量数据库 -------- */

/** 查询矢量数据库列表 */
export function listVectorDatabases() {
  return apiGet<{ items: VectorDatabase[]; total: number }>(`${BASE}/vector-databases`);
}

/** 矢量数据库新增请求体 */
export interface VectorDatabasePayload {
  /** 矢量库名称 */
  locationName: string;
  /** 关联的存储连接 uid */
  connectionUid?: string;
  /** 是否启用（缺省由服务端决定） */
  enabled?: boolean;
}

/** 新增矢量数据库 */
export function createVectorDatabase(payload: VectorDatabasePayload) {
  return apiPost<VectorDatabase>(`${BASE}/vector-databases`, payload);
}

/** 删除矢量数据库 */
export function deleteVectorDatabase(locationUid: string) {
  return apiDelete<{ locationUid: string }>(`${BASE}/vector-databases/${locationUid}`);
}

/* -------- 位置操作任务 -------- */

/** 查询存储任务状态 */
export function getStorageJob(jobUid: string) {
  return apiGet<{ jobUid: string; status: string; progress?: number }>(`${BASE}/jobs/${jobUid}`);
}

/** 重试存储任务 */
export function retryStorageJob(jobUid: string) {
  return apiPost<{ jobUid: string }>(`${BASE}/jobs/${jobUid}/retry`);
}
