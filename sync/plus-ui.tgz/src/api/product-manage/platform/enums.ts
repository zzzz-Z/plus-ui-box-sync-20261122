/**
 * 轻量枚举与定位查询：数据类型 / 数据格式 / 任务类型 / 行政区 / 图幅 / 行政区划树
 * 文档：综合管理.md；行政区划树见 Apifox「综合管理-行政区划」（2026-11-10 released）
 */
import { apiGet, seg } from '../http';

const BASE = '/platform';

/** 通用枚举项（值 + 显示名） */
export interface EnumItem {
  /** 枚举值 */
  value: string;
  /** 枚举显示名 */
  label: string;
  /** 枚举说明 */
  description?: string;
}

/** 查询数据类型枚举 */
export function listDataTypes() {
  return apiGet<{ items: EnumItem[]; total: number }>(`${BASE}/data-types`);
}

/** 查询数据格式枚举 */
export function listDataFormats() {
  return apiGet<{ items: EnumItem[]; total: number }>(`${BASE}/formats`);
}

/** 查询任务类型枚举 */
export function listTaskTypes() {
  return apiGet<{ items: EnumItem[]; total: number }>(`${BASE}/task-types`);
}

/* -------- 行政区与图幅定位 -------- */

/** @deprecated 旧「按上级编码查列表」桩，已被行政区划树接口取代；保留仅为兼容旧引用 */
export interface AdministrativeArea {
  /** 行政区划编码 */
  code: string;
  /** 行政区划名称 */
  name: string;
  /** 行政级别（省 / 市 / 县） */
  level: string;
  /** 上级区划编码（顶级为空） */
  parentCode?: string;
}

/** @deprecated 旧逐层列表接口，字段与新树契约不同；新代码请用 listAdministrativeDivisionTree */
export function listAdministrativeAreas(params: { parentCode?: string } = {}) {
  return apiGet<{ items: AdministrativeArea[]; total: number }>(`${BASE}/metadata/administrative-areas`, { params });
}

/* -------- 行政区划树（Apifox「综合管理-行政区划」2026-11-10 released） -------- */

/**
 * 行政区划节点（A1 契约 Node）。
 * - 树接口 GET /platform/administrative-divisions/tree → data.items[]
 * - 详情 GET /platform/administrative-divisions/{divisionUid} → data 为单个 Node，
 *   includeGeometry=true 时追加 geometry（EPSG:4326 GeoJSON）
 * - 数据源 platform.tb_region（天地图 edition，缺省取最新 tianditu-20261110）
 */
export interface AdministrativeDivisionNode {
  /** 行政区划 UID（division_uid，UUID） */
  uid: string;
  /** 源行政区划编码（省 2 位 / 市 4-6 位 / 县 6-9 位） */
  code: string;
  /** 行政区划名称 */
  name: string;
  /** 层级：1 省 / 2 市 / 3 县 */
  levelNo: 1 | 2 | 3;
  /** 层级机器名 */
  levelName: 'province' | 'city' | 'county';
  /** 父级 UID；省级为 null */
  parentUid: string | null;
  /** 源父级编码；省级为 null */
  parentCode: string | null;
  /** 源层级路径（空格分隔名称） */
  path: string;
  /** 数据版本 */
  edition: string;
  /** 是否存在有效边界几何 */
  geometryAvailable: boolean;
  /** 同一 edition 是否有直接下级 */
  hasChildren: boolean;
  /** 中心点 WGS84 经度 */
  centerWgsLng?: number | null;
  /** 中心点 WGS84 纬度 */
  centerWgsLat?: number | null;
  /** 详情 includeGeometry=true 时返回的 EPSG:4326 GeoJSON 几何 */
  geometry?: { type: string; coordinates: unknown } | null;
}

/** 行政区划树响应 data 包络 */
export interface AdministrativeDivisionTreeData {
  /** 实际使用的数据版本 */
  edition: string;
  /** 请求的父级 UID；省级根节点请求为 null */
  parentUid: string | null;
  /** 请求允许返回的最大层级（1..3） */
  maxLevel: number;
  /** 本次返回的节点数 */
  total: number;
  /** 行政区划节点列表 */
  items: AdministrativeDivisionNode[];
}

/**
 * 查询行政区划树（前端按需懒加载）。
 * - parentUid 省略 → 省级根节点（34 条）；提供 → 该父级的直接下级
 * - maxLevel 1..3 默认 3（父级层级 ≥ maxLevel 时返回空数组）
 * - edition 缺省取最新版本
 * 权限：需网关声明 metadata.query；401 触发登录、403(code=40301) 提示无权限，前端不构造权限字段。
 * @param config 透传 axios 配置（如 x-best-effort header，避免选项加载失败弹「登录过期」锁页）
 */
export function listAdministrativeDivisionTree(
  params: { parentUid?: string; maxLevel?: number; edition?: string } = {},
  config?: object
) {
  return apiGet<AdministrativeDivisionTreeData>(`${BASE}/administrative-divisions/tree`, { params, ...config });
}

/** 查询单个行政区划详情；includeGeometry=true 时返回 EPSG:4326 边界几何（用于空间求交） */
export function getAdministrativeDivision(divisionUid: string, includeGeometry = false, config?: object) {
  return apiGet<AdministrativeDivisionNode>(`${BASE}/administrative-divisions/${seg(divisionUid)}`, {
    params: { includeGeometry },
    ...config
  });
}

/** 图幅信息（编号 + 名称 + 范围） */
export interface MapSheet {
  /** 图幅编号 */
  sheetCode: string;
  /** 图幅名称 */
  sheetName: string;
  /** 图幅范围 [minLng, minLat, maxLng, maxLat] */
  extent?: number[];
}

/** 按图幅编号批量定位图幅信息；契约 GET，图幅编号走 query 参数 */
export function locateMapSheets(sheetCodes: string[]) {
  const qs = sheetCodes.map((c) => 'sheetCodes=' + encodeURIComponent(c)).join('&');
  return apiGet<{ items: MapSheet[] }>(`${BASE}/metadata/map-sheets?${qs}`);
}
