/**
 * 资源接口：资源 CRUD / 目录树 / 卡片 / 数据版本 / 图层 / 要素 / 导出
 * 文档：综合管理.md「resources」
 */
import type { DataVersion, LayerSummary, ResourceCard, ResourceSummary, ResourceTreeCategoryNode, ResourceTreeResourceNode } from '../types/platform';
import { apiDelete, apiGet, apiPatch, apiPost } from '../http';

const BASE = '/platform/resources';

/* -------- 资源 CRUD -------- */

export interface ResourceListParams {
  /** 关键字（匹配资源名/描述） */
  keyword?: string;
  /** 资源类型过滤 */
  resourceType?: string;
  /** 产品类别 UID（实测后端支持，但原类型未声明） */
  categoryUid?: string;
  /** 页码（从 1 开始）；契约参数名 page */
  page?: number;
  /** 每页条数；契约参数名 pageSize（实测 size 会被后端忽略，恒返默认 20 条） */
  pageSize?: number;
  /** @deprecated 契约参数名是 pageSize，size 后端不识别；保留仅为兼容旧调用点，勿在新代码使用 */
  size?: number;
  state?: string;
}

/** 查询资源列表（分页） */
export function listResources(params: ResourceListParams = {}) {
  return apiGet<{ items: ResourceSummary[]; total: number }>(BASE, { params });
}

/** 资源新增/修改请求体 */
export interface ResourcePayload {
  /** 资源名称 */
  resourceName: string;
  /** 资源类型 */
  resourceType: string;
  /** 资源描述 */
  description?: string;
}

/** 新增资源 */
export function createResource(payload: ResourcePayload) {
  return apiPost<ResourceSummary>(BASE, payload);
}

/** 查询资源详情 */
export function getResource(resourceUid: string) {
  return apiGet<ResourceSummary>(`${BASE}/${resourceUid}`);
}

/** 修改资源 */
export function updateResource(resourceUid: string, payload: Partial<ResourcePayload>) {
  return apiPatch<ResourceSummary>(`${BASE}/${resourceUid}`, payload);
}

/** 删除资源 */
export function deleteResource(resourceUid: string) {
  return apiDelete<{ resourceUid: string }>(`${BASE}/${resourceUid}`);
}

/** 查询全局资源目录树 */
export function getResourceTree() {
  return apiGet<{ items: Array<ResourceTreeCategoryNode | ResourceTreeResourceNode>; total: number }>(`${BASE}/tree`);
}

/**
 * 元数据空间图层的 GeoJSON FeatureCollection。
 *
 * 服务端用 `ST_AsGeoJSON(geom)` 生成，不做坐标系转换；
 * features 的元素结构与源空间表一致，前端只透传不解释。
 */
export interface MetadataGeoJson {
  type?: string;
  features?: any[];
}

/**
 * 单张元数据表（`metadataTables[]` 的一项）。
 *
 * 一个资源（模型）可能有多张元数据表，每张表各自带一份 GeoJSON。
 * 契约里这 4 个字段全为 required。
 */
export interface MetadataTableItem {
  /** 元数据模型表键 —— 是账本里的 `table_key`，**不是**物理表名 */
  metadataTableKey: string;
  /** PostgreSQL 物理表名，新表规则 `md_<清洗值>_<8位哈希>` */
  metadataTableName: string;
  /** 表注释，只记录来源元数据文件主名（不含路径/扩展名） */
  metadataTableComment: string;
  /** 该表的 FeatureCollection */
  geojson: MetadataGeoJson;
}

/**
 * 元数据图层条目（GET /platform/resources/metadata-layers）
 *
 * WHY 单独拉这个接口：/platform/resources 列表不返回几何，
 * 地图要画要素必须从这里拿 geojson。
 *
 * 字段按契约原样声明，不做「友好命名」适配（展示别名留在视图层）。
 * `metadataTableComment` / `metadataTables` 契约标 required，
 * 但 2026-10-29 实测 24/24 条均未返回 —— 故声明为可选，调用方必须兜底。
 */
export interface MetadataLayerItem {
  resourceUid: string;
  resourceName?: string;
  categoryUid?: string;
  categoryName?: string;
  /** 资源状态，**响应里是中文**（如「就绪」）；入参枚举是英文，见 MetadataLayerState */
  state?: string;
  /** 关联任务 UID，可空 */
  taskUid?: string | null;
  /** 入库批次 UID */
  importUid?: string | null;
  /** 数据版本 UID */
  versionUid?: string;
  /** metadata 库 schema，形如 `metadata_20261021175841430_f2f79764` */
  metadataSchema?: string;
  /** 模型表键（账本 table_key，不是物理表名） */
  metadataTableKey?: string;
  /** 物理表名 */
  metadataTableName?: string;
  /** PostgreSQL 表注释；新表为「来源元数据文件：<文件名>」 */
  metadataTableComment?: string;
  /** 该资源每张元数据表一项（多表模型才有意义；实测可能不返回） */
  metadataTables?: MetadataTableItem[];
  /** 元数据更新时间；文档 example 是 ISO，实测形如 `2026/10/27 18:11` */
  updatedAt?: string;
  /** 图层展示名（表注释/图层名），实测存在 */
  displayName?: string;
  /** 图层名（一个资源可切多个图层） */
  layerName?: string;
  /**
   * 空间范围 `[minLng, minLat, maxLng, maxLat]`（EPSG:4326）。
   *
   * WHY 必须声明：实测 2026-11-04 的 5 条资源 `geojson.features` 全为 0 —— 几何只进了
   * MVT 瓦片，而这个服务端对任意 z/x/y 都返回同一份瓦片、几何退化到 (0,0)，无法用来定位。
   * `extent2d` 是这批数据唯一可用的空间范围，空间查询的兜底求交靠它（见 map/query/state.ts）。
   */
  extent2d?: [number, number, number, number];
  /** 几何类型描述（如「线」「面」），仅展示/调试用 */
  geometryType?: string;
  /** 该图层的要素条数 */
  featureCount?: number;
  /** MVT 瓦片模板，形如 `/api/platform/resources/{uid}/metadata-tables/{key}/tiles/{z}/{x}/{y}.pbf` */
  tileTemplate?: string;
  /** 来自空间表 geom 的 FeatureCollection（首张表的几何，多表时以 metadataTables 为准） */
  geojson?: MetadataGeoJson;
}

/** 元数据图层分页响应 */
export interface MetadataLayerPage {
  items: MetadataLayerItem[];
  /** 下一页游标；空串表示结束（契约 required，可空串） */
  nextCursor: string;
  hasMore: boolean;
}

/**
 * `state` 入参机器枚举。
 *
 * WHY 单独一个类型：契约入参只接受英文，但响应返回中文（实测 24/24 条为「就绪」）。
 * 传中文会 400「资源状态必须是 pending/ready/failed」，传大写 READY 同样 400。
 */
export type MetadataLayerState = 'ready' | 'pending' | 'failed';

/**
 * 状态归一：英文机器枚举 ↔ 中文展示值。
 *
 * 内部一律用英文键（`ready`/`pending`/`failed`），响应里的中文值经此映射回键，
 * 展示时再映射回中文。未列举的状态归 `unknown`，**绝不默认归 ready**。
 */
export const METADATA_STATE_ALIAS: Record<string, MetadataLayerState | 'unknown'> = {
  ready: 'ready',
  pending: 'pending',
  failed: 'failed',
  就绪: 'ready',
  待处理: 'pending',
  处理中: 'pending',
  待配置: 'pending',
  异常: 'failed',
  失败: 'failed'
};

/** 中文展示值（供状态列直接渲染） */
export const METADATA_STATE_LABEL: Record<string, string> = {
  ready: '就绪',
  pending: '待处理',
  failed: '异常',
  unknown: '未知'
};

/** 把响应里的状态（可能是中文，也可能是英文）归一成内部键 */
export function normalizeMetadataState(raw?: string | null): MetadataLayerState | 'unknown' {
  if (!raw) return 'unknown';
  return METADATA_STATE_ALIAS[String(raw).trim()] ?? METADATA_STATE_ALIAS[String(raw).trim().toLowerCase()] ?? 'unknown';
}

/** 图层分页单页条数上限（契约 limit 1-200） */
export const METADATA_LAYER_LIMIT_MAX = 200;
/** 图层分页单页条数默认值（契约默认 50） */
export const METADATA_LAYER_LIMIT_DEFAULT = 50;

/** `listMetadataLayers` 的业务输入（调用方只传业务语义，不碰契约字段名） */
export interface MetadataLayerQueryInput {
  /** 资源 UID，精确查询 */
  resourceUid?: string;
  /** 产品类别 UID */
  categoryUid?: string;
  /** 资源状态；数据浏览固定 `ready`。传中文会被后端 400 */
  state?: MetadataLayerState;
  /** 上一页返回的 nextCursor，原样回传，不要自己解析 */
  cursor?: string;
  /** 每页条数，自动 clamp 到 1-200 */
  limit?: number;
}

/**
 * 载荷拼装：唯一出口。
 *
 * 页面禁止自己拼 `{ resourceUid, limit, cursor }` —— 契约变更后必漏。
 * 这里负责：limit clamp、空串归一为 undefined（tansParams 会丢弃空值）。
 */
export function buildMetadataLayerQuery(input: MetadataLayerQueryInput = {}): MetadataLayerQueryInput {
  const limit = Number(input.limit ?? METADATA_LAYER_LIMIT_DEFAULT);
  return {
    resourceUid: input.resourceUid || undefined,
    categoryUid: input.categoryUid || undefined,
    state: input.state || undefined,
    cursor: input.cursor || undefined,
    limit: Math.min(METADATA_LAYER_LIMIT_MAX, Math.max(1, Number.isFinite(limit) ? Math.trunc(limit) : METADATA_LAYER_LIMIT_DEFAULT))
  };
}

/** 查询元数据空间图层（含真实 GeoJSON 几何）
 *
 * 契约：支持 resourceUid 精确查询；categoryUid + state 组合筛选；
 * 分页走 cursor / limit（limit 1-200，建议固定 50），返回 nextCursor 与 hasMore。
 */
export function listMetadataLayers(input: MetadataLayerQueryInput = {}) {
  return apiGet<MetadataLayerPage>(`${BASE}/metadata-layers`, { params: buildMetadataLayerQuery(input) });
}

/**
 * 从一个图层条目里取全部要素（多表模型会把每张表的几何都取出来）。
 *
 * WHY 需要它：`item.geojson` 只是首张表的几何；契约新增 `metadataTables[]` 后，
 * 一个资源可能有多张表，只读 `item.geojson` 会漏几何。实测当前 24/24 条都没有
 * `metadataTables`，故必须兼容两种形态。
 */
export function collectLayerFeatures(item: MetadataLayerItem): any[] {
  const out: any[] = [];
  const push = (gj?: MetadataGeoJson) => {
    for (const f of gj?.features ?? []) {
      if (f?.geometry) out.push(f);
    }
  };
  if (Array.isArray(item.metadataTables) && item.metadataTables.length) {
    for (const t of item.metadataTables) push(t.geojson);
    // 首表几何与 metadataTables 可能重复，去重交给调用方按 feature 内容处理；
    // 这里保证「至少不丢」优先于「不重」。
    if (!out.length) push(item.geojson);
  } else {
    push(item.geojson);
  }
  return out;
}

/** 查询指定资源的目录树 */
export function getResourceTreeById(resourceUid: string) {
  return apiGet<{ items: Array<ResourceTreeCategoryNode | ResourceTreeResourceNode>; total: number }>(`${BASE}/${resourceUid}/tree`);
}

/** 查询资源卡片列表 */
export function listResourceCards(params: ResourceListParams = {}) {
  return apiGet<{ items: ResourceCard[]; total: number }>(`${BASE}/cards`, { params });
}

/* -------- 数据版本与图层 -------- */

/** 查询资源下的数据列表 */
export function listResourceData(resourceUid: string) {
  return apiGet<{ items: Array<{ dataUid: string; dataName: string }>; total: number }>(`${BASE}/${resourceUid}/data`);
}

/** 查询某数据的版本列表 */
export function listDataVersions(resourceUid: string, dataUid: string) {
  return apiGet<{ items: DataVersion[]; total: number }>(`${BASE}/${resourceUid}/data/${dataUid}/versions`);
}

/** 对比两个数据版本的差异 */
export function compareDataVersions(resourceUid: string, dataUid: string, payload: { fromVersionUid: string; toVersionUid: string }) {
  return apiPost<{ changes: unknown[] }>(`${BASE}/${resourceUid}/data/${dataUid}/versions/compare`, payload);
}

/** 回滚数据到指定版本 */
export function restoreDataVersion(resourceUid: string, dataUid: string, payload: { versionUid: string }) {
  return apiPost<{ versionUid: string }>(`${BASE}/${resourceUid}/data/${dataUid}/versions/restore`, payload);
}

/** 导出指定数据版本 */
export function exportDataVersion(resourceUid: string, dataUid: string, versionUid: string, payload: { format?: string } = {}) {
  return apiPost<{ taskUid: string }>(`${BASE}/${resourceUid}/data/${dataUid}/versions/${versionUid}/export`, payload);
}

/** 查询版本下的图层列表 */
export function listVersionLayers(resourceUid: string, dataUid: string, versionUid: string) {
  return apiGet<{ items: LayerSummary[]; total: number }>(`${BASE}/${resourceUid}/data/${dataUid}/versions/${versionUid}/layers`);
}

/** 预览图层内容 */
export function previewLayer(resourceUid: string, dataUid: string, versionUid: string, layerUid: string) {
  return apiGet<{ preview: unknown }>(`${BASE}/${resourceUid}/data/${dataUid}/versions/${versionUid}/layers/${layerUid}/preview`);
}

/** 查询图层要素（按范围/条件） */
export function queryLayerFeatures(
  resourceUid: string,
  dataUid: string,
  versionUid: string,
  layerUid: string,
  payload: { bbox?: number[]; limit?: number; filters?: Record<string, unknown> } = {}
) {
  return apiPost<{ items: unknown[] }>(`${BASE}/${resourceUid}/data/${dataUid}/versions/${versionUid}/layers/${layerUid}/query`, payload);
}

/** 创建数据迁移任务 */
export function createMigrationTask(resourceUid: string, payload: { targetLocationUid: string; dataUids?: string[] }) {
  return apiPost<{ taskUid: string }>(`${BASE}/${resourceUid}/migration-tasks`, payload);
}
