/**
 * 数据更新接口层（Apifox 目录 97354330，业务说明 doc-9701307）
 *
 * 数据更新 = 已有资源/已有 dataKey 产生新版本，与文件提取（/platform/data-extractions）是两套语义。
 * 路径分两段：
 *   /platform/resources/{resourceUid}/updates  —— 预览、创建、按资源查列表
 *   /platform/updates/{updateUid}              —— 详情、改参、控制、日志、报告
 * baseURL 由 http.ts 注入（含 /datamanage/api），clientid 由主 request 拦截器统一带上。
 */
import { apiGet, apiPatch, apiPost, seg, type Paged } from '../http';

const RESOURCE_UPDATES = '/platform/resources';
const UPDATES = '/platform/updates';

/** 更新任务状态（列表示例另见 ready，按版本态兜底） */
export type UpdateState = 'CREATED' | 'QUEUED' | 'RUNNING' | 'PAUSED' | 'SUCCEEDED' | 'FAILED' | 'CANCELLED' | 'ready';

/** 优先级 */
export type PriorityLevel = 'high' | 'medium' | 'low';

/** 更新模式：incremental=提交新增/修改文件；replace=提交完整清单，缺失旧文件在新版本删除 */
export type UpdateMode = 'incremental' | 'replace';

/** 文件级更新动作 */
export type FileActionType = 'delete' | 'move' | 'rename';

/** 预览/创建时单个文件的来源定位（三字段按组合用） */
export interface UpdateFileSource {
  /** 存储 uid */
  storageUid?: string;
  /** 根目录路径 */
  rootPath?: string;
  /** 上传批次 uid */
  uploadUid?: string;
}

/** 预览/创建时的单个文件条目 */
export interface UpdateFileInput {
  /** 来源内相对路径 */
  sourcePath: string;
  /** 目标路径，缺省沿用 sourcePath */
  targetPath?: string;
  /** 来源定位 */
  source: UpdateFileSource;
}

/** 增量模式下的文件级动作 */
export interface FileAction {
  action: FileActionType;
  path: string;
  newPath?: string;
}

/** 更新进度 */
export interface UpdateProgress {
  current?: number;
  total?: number;
  percent?: number;
}

/** 更新清单条目（契约未固定字段，保留宽松结构） */
export interface UpdateManifestItem {
  [key: string]: unknown;
}

/** 更新任务实体（列表/详情/改参/控制共用） */
export interface UpdateTask {
  updateUid: string;
  taskUid?: string;
  resourceUid: string;
  dataKey: string;
  baseVersionUid?: string;
  newVersionUid?: string | null;
  newVersionNo?: number;
  state: UpdateState;
  progress?: UpdateProgress;
  previewFingerprint?: string;
  rolledBack?: boolean;
  updateManifest?: UpdateManifestItem[];
  /** 更新时间/名称等审计字段后端若返回则展示，契约未固定 */
  createdAt?: string;
  updatedAt?: string;
  [key: string]: unknown;
}

/** 按资源查更新任务列表参数 */
export interface ListUpdatesParams {
  page?: number;
  pageSize?: number;
  state?: string;
}

/** 预览请求 */
export interface PreviewUpdatePayload {
  dataKey?: string;
  files: UpdateFileInput[];
  previewFingerprint?: string;
  updateMode?: UpdateMode;
  information?: string;
  fileActions?: FileAction[];
}

/** 预览结果中的当前基线版本信息 */
export interface PreviewCurrentVersion {
  versionUid?: string;
  versionNo?: number;
  state?: string;
  [key: string]: unknown;
}

/** 预览结果中的单个文件比对条目 */
export interface PreviewFileResult {
  sourcePath: string;
  targetPath?: string;
  sizeBytes?: number;
  sha256?: string;
  status: 'added' | 'updated' | 'unchanged' | 'removed';
  previous?: Record<string, unknown>;
  [key: string]: unknown;
}

/** 预览响应 */
export interface PreviewUpdateResult {
  resourceUid: string;
  resourceName?: string;
  dataKey?: string;
  displayName?: string;
  current?: PreviewCurrentVersion;
  files: PreviewFileResult[];
  summary?: {
    fileCount?: number;
    added?: number;
    updated?: number;
    unchanged?: number;
    removed?: number;
    sourceCount?: number;
    [key: string]: unknown;
  };
  warnings?: string[];
  canUpdate: boolean;
  blockedReason?: string | null;
  previewFingerprint: string;
}

/** 创建请求（在预览载荷基础上补任务参数） */
export interface CreateUpdatePayload extends PreviewUpdatePayload {
  previewFingerprint?: string;
  importName?: string;
  priorityLevel?: PriorityLevel;
  description?: string;
  requestId?: string;
  autoStart?: boolean;
}

/** 修改任务参数请求 */
export interface PatchUpdatePayload {
  description?: string;
  priorityLevel?: PriorityLevel;
}

/** 控制动作 */
export type UpdateAction = 'start' | 'pause' | 'resume' | 'cancel';

/** 更新日志条目（接口实际返回 at/type/stateText 等，message/createdAt 未必存在） */
export interface UpdateLogItem {
  type: string;
  message?: string;
  at?: string;
  state?: string;
  stateText?: string;
  versionNo?: number;
  sourcePath?: string;
  targetPath?: string;
  createdAt?: string;
  [key: string]: unknown;
}

/** 分页日志响应 */
export interface UpdateLogResult {
  items: UpdateLogItem[];
  nextCursor?: string;
}

/** 更新报告（接口实际返回顶层 fileCount/completedFiles/newVersionNo/stateText/errorCount 等字段） */
export interface UpdateReport {
  resourceUid: string;
  dataKey: string;
  fileCount?: number;
  completedFiles?: number;
  newVersionNo?: number;
  newVersionState?: string;
  state?: string;
  stateText?: string;
  errorCount?: number;
  errorCode?: string;
  errorMessage?: string;
  createdAt?: string;
  finishedAt?: string;
  files?: Array<{ sourcePath?: string; targetPath?: string; sizeBytes?: number; sha256?: string }>;
  summary?: {
    fileCount?: number;
    added?: number;
    updated?: number;
    [key: string]: unknown;
  };
  errors?: Array<Record<string, unknown>>;
  version?: {
    newVersionNo?: number;
    [key: string]: unknown;
  };
  rollback?: Record<string, unknown>;
}

/** 预览数据更新（只读，不建版本；返回 previewFingerprint 供创建校验） */
export function previewUpdate(resourceUid: string, payload: PreviewUpdatePayload) {
  return apiPost<PreviewUpdateResult, PreviewUpdatePayload>(`${RESOURCE_UPDATES}/${seg(resourceUid)}/updates/preview`, payload);
}

/** 创建数据更新任务（HTTP 202；previewFingerprint 校验失败 409，requestId 幂等） */
export function createUpdate(resourceUid: string, payload: CreateUpdatePayload) {
  return apiPost<UpdateTask, CreateUpdatePayload>(`${RESOURCE_UPDATES}/${seg(resourceUid)}/updates`, payload);
}

/** 按资源查询更新任务列表 */
export function listUpdates(resourceUid: string, params: ListUpdatesParams = {}) {
  return apiGet<Paged<UpdateTask>>(`${RESOURCE_UPDATES}/${seg(resourceUid)}/updates`, { params });
}

/** 查询更新任务详情 */
export function getUpdate(updateUid: string) {
  return apiGet<UpdateTask>(`${UPDATES}/${seg(updateUid)}`);
}

/** 修改更新任务参数（运行中调整优先级走此接口） */
export function patchUpdate(updateUid: string, payload: PatchUpdatePayload) {
  return apiPatch<UpdateTask, PatchUpdatePayload>(`${UPDATES}/${seg(updateUid)}`, payload);
}

/** 控制更新任务（start/pause/resume/cancel，非法状态 409） */
export function controlUpdate(updateUid: string, action: UpdateAction) {
  return apiPost<UpdateTask>(`${UPDATES}/${seg(updateUid)}/${seg(action)}`);
}

/** 分页读取更新日志（nextCursor 空=末页） */
export function getUpdateLog(updateUid: string, params: { cursor?: string; limit?: number } = {}) {
  return apiGet<UpdateLogResult>(`${UPDATES}/${seg(updateUid)}/log`, { params });
}

/** 查询更新报告（文件统计/错误/版本/回滚结果） */
export function getUpdateReport(updateUid: string) {
  return apiGet<UpdateReport>(`${UPDATES}/${seg(updateUid)}/report`);
}

/** 载荷白名单拼装结果 */
interface BuildResult<T> {
  ok: boolean;
  payload?: T;
  message?: string;
}

/**
 * 拼装创建更新任务载荷（逐字段白名单，过滤空值；校验交由调用方补充业务规则）。
 * strictNullChecks 关闭，无需判别联合。
 */
export function buildCreateUpdatePayload(input: CreateUpdatePayload): BuildResult<CreateUpdatePayload> {
  const { dataKey, files, previewFingerprint, importName, priorityLevel, description, requestId, autoStart, updateMode, information, fileActions } =
    input;
  if (!Array.isArray(files) || !files.length) {
    return { ok: false, message: '至少选择一个来源文件' };
  }
  const payload: CreateUpdatePayload = {
    files: files.map((f) => ({
      sourcePath: f.sourcePath,
      ...(f.targetPath ? { targetPath: f.targetPath } : {}),
      source: f.source
    }))
  };
  if (dataKey) payload.dataKey = dataKey;
  if (previewFingerprint) payload.previewFingerprint = previewFingerprint;
  if (importName) payload.importName = importName;
  if (priorityLevel) payload.priorityLevel = priorityLevel;
  if (description) payload.description = description;
  if (requestId) payload.requestId = requestId;
  if (typeof autoStart === 'boolean') payload.autoStart = autoStart;
  if (updateMode) payload.updateMode = updateMode;
  if (information) payload.information = information;
  if (Array.isArray(fileActions) && fileActions.length) payload.fileActions = fileActions;
  return { ok: true, payload };
}
