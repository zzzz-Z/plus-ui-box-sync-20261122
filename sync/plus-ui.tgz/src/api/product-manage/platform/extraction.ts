/**
 * 数据提取 / 元数据抽取接口
 *
 * 元数据抽取段对齐 Apifox「元数据抽取」分组 7 个契约接口（run / report /
 * errors / locate / correct / resolve / delete），路径前缀与产品网关 baseURL
 * （VITE_APP_BASE_API + /datamanage/api）拼接后即契约中的 /api/platform/...。
 * clientid 请求头由 src/utils/request.ts 拦截器统一注入。
 */
import type { DataExtractionTask, TaskStatus } from '../types/platform';
import { apiDelete, apiGet, apiPatch, apiPost, seg } from '../http';

const DATA_BASE = '/platform/data-extractions';
const META_BASE = '/platform/metadata/extractions';
const ERROR_BASE = '/platform/metadata/extraction-errors';

/* -------- 数据提取（既有接口，保持不动） -------- */

export interface ExtractionListParams {
  /** 任务状态过滤 */
  status?: TaskStatus;
  /** 关键字（匹配任务名） */
  keyword?: string;
  /** 页码（从 1 开始） */
  page?: number;
  /** 每页条数 */
  size?: number;
}

/** 查询数据提取任务列表 */
export function listDataExtractions(params: ExtractionListParams = {}) {
  return apiGet<{ items: DataExtractionTask[]; total: number }>(DATA_BASE, { params });
}

/** 数据提取任务的创建/预览请求体 */
export interface DataExtractionPayload {
  /** 任务名称 */
  taskName: string;
  /** 待提取的数据节点 uid 列表 */
  nodeUids: string[];
  /** 优先级（数值越大越优先） */
  priority?: number;
  /** 任务描述 */
  description?: string;
}

/** 创建数据提取任务 */
export function createDataExtraction(payload: DataExtractionPayload) {
  return apiPost<DataExtractionTask>(DATA_BASE, payload);
}

/** 预览数据提取范围与节点数（不落库） */
export function previewDataExtraction(payload: DataExtractionPayload) {
  return apiPost<{ extent?: number[]; nodeCount: number }>(DATA_BASE + '/preview', payload);
}

/** 查询数据提取任务详情 */
export function getDataExtraction(taskUid: string) {
  return apiGet<DataExtractionTask>(DATA_BASE + '/' + taskUid);
}

/** 调整数据提取任务优先级 */
export function updateDataExtractionPriority(taskUid: string, payload: { priority: number }) {
  return apiPatch<DataExtractionTask>(DATA_BASE + '/' + taskUid, payload);
}

/** 启动数据提取任务 */
export function startDataExtraction(taskUid: string) {
  return apiPost<DataExtractionTask>(DATA_BASE + '/' + taskUid + '/start');
}

/** 暂停数据提取任务 */
export function pauseDataExtraction(taskUid: string) {
  return apiPost<DataExtractionTask>(DATA_BASE + '/' + taskUid + '/pause');
}

/** 继续数据提取任务 */
export function resumeDataExtraction(taskUid: string) {
  return apiPost<DataExtractionTask>(DATA_BASE + '/' + taskUid + '/resume');
}

/** 取消数据提取任务 */
export function cancelDataExtraction(taskUid: string) {
  return apiPost<DataExtractionTask>(DATA_BASE + '/' + taskUid + '/cancel');
}

/* ================================================================== *
 * 元数据抽取（对齐 Apifox 契约 · 7 接口）
 * 说明：契约状态为 developing（源码静态核对，未部署 HTTP 实测）；
 *       不可用场景仍返回 code=0，由 extraction.available 区分。
 * ================================================================== */

/* -------- 契约 #1 执行四来源自动抽取 -------- */

/** resourceUid / importUid / taskUid 至少其一 */
export interface RunExtractionPayload {
  resourceUid?: string;
  importUid?: string;
  taskUid?: string;
  /** 是否写回元数据表，默认 true */
  write?: boolean;
  /** 是否记录抽取错误，默认 true */
  recordErrors?: boolean;
}

/** 抽取来源明细（四来源：元数据文件 / 数据生产记录 / 数据库配置 / 入库记录） */
export interface ExtractionSource {
  layer?: string;
  kind?: string;
  count?: number;
  [key: string]: unknown;
}

/** 抽取结果：available=false 时 errorCode 给出原因，其余字段可缺省 */
export interface ExtractionRunResult {
  available: boolean;
  errorCode?: string;
  injectedFieldCount?: number;
  sources?: ExtractionSource[];
  missingRequiredFields?: string[];
  undescribedTables?: string[];
  check?: Record<string, unknown>;
  recordedErrorCount?: number;
  write?: boolean;
  [key: string]: unknown;
}

export interface RunExtractionResult {
  context: Record<string, unknown>;
  extraction: ExtractionRunResult;
}

/** POST /platform/metadata/extractions/run */
export function runExtraction(payload: RunExtractionPayload) {
  return apiPost<RunExtractionResult, RunExtractionPayload>(META_BASE + '/run', payload);
}

/* -------- 契约 #2 获取抽取报告 -------- */

export interface ExtractionReportParams {
  resourceUid?: string;
  importUid?: string;
  /** 已入库 / 无来源元数据 / 未绑定模型 / 来源不可用 / 入库失败 / 尚未抽取 */
  status?: string;
  /** 默认 20，最大 200 */
  limit?: number;
  /** 默认 0 */
  offset?: number;
}

export interface ExtractionReportBatch {
  importUid: string;
  importStateText?: string;
  metadataStatus?: string;
  sourceKind?: string;
  sourceFile?: string;
  recordCount?: number;
  errorCount?: number;
  [key: string]: unknown;
}

export interface ExtractionReport {
  overview: {
    statusCounts?: Record<string, number>;
    taskStateCounts?: Record<string, number>;
    importCount?: number;
    metadataRowCount?: number;
    [key: string]: unknown;
  };
  errors: {
    total?: number;
    open?: number;
    resolved?: number;
    counts?: Record<string, number>;
    [key: string]: unknown;
  };
  /** 实测返回对象 { items: [...] }，而非裸数组；早期文档误标为数组 */
  batches: { items: ExtractionReportBatch[]; total?: number; [key: string]: unknown };
  filter?: Record<string, unknown>;
}

/** GET /platform/metadata/extractions/report */
export function getExtractionReport(params: ExtractionReportParams = {}) {
  return apiGet<ExtractionReport>(META_BASE + '/report', { params });
}

/* -------- 契约 #3 查询抽取错误 -------- */

export interface ExtractionErrorListParams {
  resourceUid?: string;
  taskUid?: string;
  fieldKey?: string;
  code?: string;
  /** 仅 open | resolved；其他值后端返回 400 */
  scope?: 'open' | 'resolved';
  /** 默认 50 */
  limit?: number;
  offset?: number;
}

export interface ExtractionErrorItem {
  errorUid: string;
  taskUid?: string;
  fieldKey?: string;
  code?: string;
  message?: string;
  repairToken?: string;
  sourceLayerKey?: string;
  resolved: boolean;
  createdAt?: string;
  resolvedAt?: string;
  resourceUid?: string;
  taskKind?: string;
  modelUid?: string;
  dataKey?: string;
  [key: string]: unknown;
}

export interface ExtractionErrorListResult {
  items: ExtractionErrorItem[];
  total: number;
  openCount?: number;
  counts?: Record<string, number>;
}

/** GET /platform/metadata/extraction-errors */
export function listExtractionErrors(params: ExtractionErrorListParams = {}) {
  return apiGet<ExtractionErrorListResult>(ERROR_BASE, { params });
}

/* -------- 契约 #4 错误定位详情 -------- */

export interface ExtractionErrorLocate {
  tableKey?: string;
  tableName?: string;
  fieldKey?: string;
  displayName?: string;
  valueType?: string;
  required?: boolean;
  /** 定位不到时给出原因，不伪造字段 */
  reason?: string;
  [key: string]: unknown;
}

/** 冻结模型字段定义 */
export interface ExtractionFieldDef {
  name?: string;
  displayName?: string;
  type?: string;
  valueType?: string;
  required?: boolean;
  nullable?: boolean;
  fieldLength?: number;
  options?: string[];
  [key: string]: unknown;
}

export interface ExtractionErrorDetail {
  error: ExtractionErrorItem;
  locate: ExtractionErrorLocate;
  field?: ExtractionFieldDef | null;
  fieldLocated?: boolean;
  [key: string]: unknown;
}

/** GET /platform/metadata/extraction-errors/{errorUid} */
export function getExtractionErrorDetail(errorUid: string) {
  return apiGet<ExtractionErrorDetail>(ERROR_BASE + "/" + seg(errorUid));
}

/* -------- 契约 #5 纠正并消除错误（推荐的新流程） -------- */

export interface CorrectExtractionErrorPayload {
  /** 纠正值；按字段类型（整数/数值/布尔）+ fieldLength 校验，必填禁空 */
  value: string | number | boolean;
  /** 只入审计，不记取值原文 */
  note?: string;
}

export interface CorrectExtractionErrorResult {
  resolved: boolean;
  locate?: ExtractionErrorLocate;
  correction?: {
    provided?: unknown;
    accepted?: boolean;
    valueType?: string;
    valueLength?: number;
    note?: string;
    [key: string]: unknown;
  };
  [key: string]: unknown;
}

/** POST /platform/metadata/extraction-errors/{errorUid}/correct */
export function correctExtractionError(errorUid: string, payload: CorrectExtractionErrorPayload) {
  return apiPost<CorrectExtractionErrorResult, CorrectExtractionErrorPayload>(ERROR_BASE + "/" + seg(errorUid) + "/correct", payload);
}

/* -------- 契约 #6 处理提取错误（旧 mark-resolved 入口，新流程优先 correct） -------- */

export interface ResolveExtractionErrorPayload {
  field?: string;
  reason?: string;
}

/** POST /platform/metadata/extraction-errors/{errorUid}/resolve */
export function resolveExtractionError(errorUid: string, payload: ResolveExtractionErrorPayload = {}) {
  return apiPost<ExtractionErrorItem, ResolveExtractionErrorPayload>(ERROR_BASE + "/" + seg(errorUid) + "/resolve", payload);
}

/* -------- 契约 #7 删除已纠正错误 -------- */

export interface DeleteExtractionErrorResult {
  errorUid: string;
  deleted: boolean;
}

/** DELETE /platform/metadata/extraction-errors/{errorUid}；body 必须显式 confirm:true */
export function deleteExtractionError(errorUid: string) {
  return apiDelete<DeleteExtractionErrorResult>(ERROR_BASE + '/' + seg(errorUid), { data: { confirm: true } });
}

