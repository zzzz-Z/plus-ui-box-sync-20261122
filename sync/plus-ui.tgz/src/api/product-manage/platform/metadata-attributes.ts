/**
 * 资源元数据属性表接口（元数据浏览 · 详情列表）
 *
 * 契约：GET /api/platform/resources/{resourceUid}/metadata-attributes
 *   - Apifox docId 529576519，本地存档 artifacts/metadata-browse/01-contract/api-529576519.md
 *
 * 与 metadata-browse.ts 中 `listMetadataAttributes` 的差异（有意为之，不要合并）：
 *   - 那条函数是「点地图要素后取属性」用的，注释里仍标着「后端未上线」的旧状态；
 *   - 本文件是「详情列表页」的主数据源，额外承担表清单探测与业务码 40404 归一，
 *     属浏览链路的列表语义，故单独成文件，避免把探测逻辑塞进浏览树接口族。
 *
 * 关键契约事实（踩过）：
 *   - 分页参数是 `page` / `pageSize`，**不是**项目的 `pageNum`；直接透传 Table 的 params 会被后端忽略；
 *   - `records[].values` 是「列名 → 值」的**对象**，不是数组；
 *   - 资源没有元数据表时后端返回业务码 40404，语义是「无数据」，不是错误。
 */
import { apiGet, seg } from '../http';
import { getResourceMetadataLayer } from './metadata-browse';

const RESOURCE_BASE = '/platform/resources';

/** 后端业务码：资源或元数据表不存在（按空态处理，不弹错误） */
export const METADATA_ATTRIBUTES_EMPTY_CODE = 40404;

/** 属性表单页条数上限（契约 1-200） */
export const METADATA_ATTR_PAGE_SIZE_MAX = 200;
/** 属性表单页条数默认值（契约默认 50） */
export const METADATA_ATTR_PAGE_SIZE_DEFAULT = 50;

/** 属性表一行记录 */
export interface MetadataAttributeRecord {
  /** 该行所属的账本 table_key */
  tableKey: string;
  /** PostgreSQL 物理表名 */
  pgTable: string;
  /** 列名 → 值 */
  values: Record<string, unknown>;
}

/** 属性表响应 */
export interface MetadataAttributesResult {
  resourceUid: string;
  /** 本次查询的表键；为空表示查了全部表 */
  tableKey?: string;
  versionUid?: string;
  metadataSchema?: string;
  /**
   * 列名 → 中文标签（**产品网关实际返回的字段，不是 `fields`**）。
   *
   * 契约文档写的是 `fields: string[]`，但产品网关实测（2026-11-02）返回
   * `fieldLabels: Record<string, string>`：键是列名、值是中文名；键集合恰好等于
   * `records[].values` 里的**业务字段**（不含 created_at / metadata_uid 这类系统字段），
   * 且顺序即后端希望的展示顺序。
   *
   * WHY 必须以实测为准：按契约读 `fields` 会恒为空数组 → 表格一列都渲染不出来、
   * 页面只剩「暂无属性记录」，即使 records 里明明有数据。
   */
  fieldLabels?: Record<string, string>;
  /** 列名列表（契约声明字段；实测产品网关**不返回**，保留以兼容其它网关实现） */
  fields?: string[];
  /**
   * 本次查询的表展示名（2026-11-03 实测新增）。
   *
   * WHY 单列：以前页签直接显示 `tableKey`（`flys_sx` 这种英文账本键），用户看不懂；
   * 后端补了 `displayName` 就是为了给前端做页签文案。查全部表时它只代表首张表，
   * 多表场景要以 `listAttributeTables()` 的结果为准。
   */
  displayName?: string;
  /** 图层展示名（与 displayName 同值居多，作兜底） */
  layerName?: string;
  records: MetadataAttributeRecord[];
  total: number;
  /** 契约分页字段（不是 pageNum） */
  page: number;
  pageSize?: number;
}

/** 查询输入（业务语义，不碰契约字段名） */
export interface MetadataAttributesQueryInput {
  /** 账本 table_key；为空则返回该资源全部表 */
  tableKey?: string;
  /** 页码，从 1 开始 */
  page?: number;
  /** 每页条数，1-200 */
  pageSize?: number;
}

/**
 * 载荷拼装：唯一出口。
 *
 * WHY 不把 Table 给的 params 直接转出去：Table 的 params 里恒有 `pageNum`，
 * 后端只认 `page`，两者同时出现时前端会误以为翻页生效、其实一直停在第一页。
 */
export function buildMetadataAttributesQuery(input: MetadataAttributesQueryInput = {}): MetadataAttributesQueryInput {
  const rawSize = Number(input.pageSize ?? METADATA_ATTR_PAGE_SIZE_DEFAULT);
  const rawPage = Number(input.page ?? 1);
  const size = Number.isFinite(rawSize) ? Math.trunc(rawSize) : METADATA_ATTR_PAGE_SIZE_DEFAULT;
  const page = Number.isFinite(rawPage) ? Math.trunc(rawPage) : 1;
  return {
    tableKey: input.tableKey || undefined,
    page: page > 0 ? page : 1,
    pageSize: Math.min(METADATA_ATTR_PAGE_SIZE_MAX, Math.max(1, size))
  };
}

/** 查询资源属性表（分页） */
export function listResourceAttributes(resourceUid: string, input: MetadataAttributesQueryInput = {}) {
  return apiGet<MetadataAttributesResult>(`${RESOURCE_BASE}/${seg(resourceUid)}/metadata-attributes`, {
    params: buildMetadataAttributesQuery(input)
  });
}

/** 属性表的一列：列名 + 展示标签 */
export interface MetadataAttributeColumn {
  /** `records[].values` 里的键，取单元格值用 */
  key: string;
  /** 表头展示文案：一律中文（后端中文名 → 内置中文名 → 隐藏该列） */
  label: string;
}

/**
 * 系统字段的中文名。
 *
 * WHY 需要：`fieldLabels` 只覆盖业务字段，`created_at` / `metadata_uid` 这类系统字段
 * 只存在于 `values` 里，没有任何中文标签。它们对排查数据问题有用，直接隐藏会丢信息，
 * 所以先在这里查一遍中文名；查不到的纯英文列一律不展示（表头不许出现英文）。
 *
 * 只登记「确定语义」的字段，不按后缀猜——猜出来的中文名（如把 `_at` 统一叫「时间」）
 * 会造出比英文更难懂的表头。
 */
const SYSTEM_FIELD_LABELS: Record<string, string> = {
  created_at: '创建时间',
  create_time: '创建时间',
  updated_at: '更新时间',
  update_time: '更新时间',
  create_by: '创建人',
  update_by: '更新人',
  metadata_uid: '元数据唯一标识',
  resource_uid: '资源唯一标识',
  row_version: '行版本',
  del_flag: '删除标记',
  tenant_id: '租户标识',
  pg_table: '物理表名',
  table_key: '账本表键'
};

/** 是否含中日韩汉字（有汉字就算已本地化，不需要再处理） */
function hasCJK(text: string): boolean {
  return /[\u4e00-\u9fa5]/.test(text);
}

/**
 * 列名 → 中文表头。
 *
 * 优先级：后端给的中文名 → 内置系统字段中文名 → 空串（表示「这列没有中文名」）。
 *
 * WHY 返回空串而不是退回列名：调用方据此决定「不展示该列」，
 * 把「没有中文名」的判定收在这一处，页面就不用各自写正则。
 * 注意后端把「列名」原样当标签给回来（如 `created_at: "created_at"`）也算没有中文名。
 */
export function localizeFieldLabel(key: string, label?: string): string {
  const given = String(label ?? '').trim();
  // 有汉字就算已本地化（「生产流程实例ID（Flowable）」这类夹英文的也算），原样保留
  if (given && hasCJK(given)) return given;
  const mapped = SYSTEM_FIELD_LABELS[key];
  if (mapped) return mapped;
  return '';
}

/**
 * 过滤掉没有中文表头的列；但**保底留一列**。
 *
 * WHY 兜底：换个网关实现只返回 `fields: string[]`（纯英文列名）时，
 * 过滤后一列不剩就是空表 —— 那比看到英文表头更糟。此时退回原始列，
 * 表头虽是英文，至少数据能读。
 */
function dropUnlabeledColumns(cols: MetadataAttributeColumn[]): MetadataAttributeColumn[] {
  const kept = cols.filter((c) => !!c.label);
  if (kept.length) return kept;
  return cols;
}

/**
 * 把响应归一成「列清单」——页面取列的唯一出口。
 *
 * WHY 需要归一：契约写 `fields: string[]`，产品网关实际返回 `fieldLabels: Record<string,string>`。
 * 两种形态都要能出列，否则换个网关实现（或后端回退到契约形态）页面就又白屏。
 * 优先级：`fieldLabels`（带中文名，键序即展示顺序）→ `fields`（只有列名）→ 兜底取首行 values 的键。
 */
export function resolveAttributeColumns(data?: MetadataAttributesResult | null): MetadataAttributeColumn[] {
  const labels = data?.fieldLabels ?? {};
  const labelKeys = Object.keys(labels);
  let cols: MetadataAttributeColumn[];
  if (labelKeys.length) {
    cols = labelKeys.map((key) => ({ key, label: localizeFieldLabel(key, labels[key]) }));
  } else {
    const fields = data?.fields ?? [];
    if (fields.length) {
      cols = fields.map((key) => ({ key, label: localizeFieldLabel(key) }));
    } else {
      // 兜底：后端两个字段都没给时，用首行的键——至少让用户看到数据，而不是空表
      const first = data?.records?.[0]?.values ?? {};
      cols = Object.keys(first).map((key) => ({ key, label: localizeFieldLabel(key) }));
    }
  }

  // WHY 按展示名去重：后端字段清单里同一信息会同时给英文键列和中文名列
  // （如 product_name 与「产品名称」），表格里就是两列重复内容；保留先出现的那列
  // （中文名优先，因为 fieldLabels 键序即展示顺序），把 label 重复的后续列剔掉。
  const seen = new Set<string>();
  const deduped = cols.filter((c) => {
    if (!c.label || seen.has(c.label)) return false;
    seen.add(c.label);
    return true;
  });
  // 去重后可能一列不剩（全是查不到中文名的英文列），此时退回去重前的列
  return deduped.length ? deduped : dropUnlabeledColumns(cols);
}

/**
 * 详情 / 表格共用的「重要字段优先」展示顺序。
 *
 * WHY 不直接取后端顺序：后端 `fieldLabels` 按列名字母序给，前几个全是坐标系参数，
 * 一眼看不出是哪个产品、什么要素、多少条；把能定位一条记录的字段排前，其余原序跟在后面。
 * WHY 收口到 api 层：两张属性表与地图要素详情必须给出完全相同的字段顺序，
 * 各写一份必然走样（地图详情曾用后端原序、列表用重要字段优先，被指出「和列表不一致」）。
 */
const DETAIL_IMPORTANT_FIELD_KEYS = ['product_name', 'product_code', 'element_type', 'data_format', 'feature_count', 'data_status'];

export function orderAttributeColumns(columns: MetadataAttributeColumn[]): MetadataAttributeColumn[] {
  const byKey = new Map(columns.map((c) => [c.key, c]));
  const picked: MetadataAttributeColumn[] = [];
  for (const key of DETAIL_IMPORTANT_FIELD_KEYS) {
    const col = byKey.get(key);
    if (!col) continue;
    picked.push(col);
    byKey.delete(key);
  }
  for (const col of columns) {
    if (!byKey.has(col.key)) continue;
    picked.push(col);
    byKey.delete(col.key);
  }
  return picked;
}

/** 页签选项：英文账本键（查询用）+ 中文展示名（渲染用） */
export interface AttributeTableOption {
  /** 账本 `table_key`，查询参数用它 */
  key: string;
  /** 页签文案：`displayName` → `layerName` → 退回 key */
  label: string;
}

/**
 * 取资源的元数据表清单（key + 展示名），属性表页签的唯一数据源。
 *
 * WHY 走 metadata-layer 而不是属性表接口：
 *   `displayName` 是「每张表各自的中文名」，属性表接口一次只能返回**当前查询表**的那一个
 *   （查全部表时只代表首张表），拿它渲染多页签会把所有页签写成同一个名字。
 *   metadata-layer 的 `metadataTables[]` 才是完整的「key → 展示名」映射。
 *
 * 两级兜底：metadata-layer 失败（如 404 无表、网关抖动）→ 退回 `probeAttributeTableKeys`
 * 探 key，此时没有中文名，页签显示 key 本身——有信息总比空页签好。
 */
export async function listAttributeTables(resourceUid: string): Promise<AttributeTableOption[]> {
  try {
    const res = await getResourceMetadataLayer(resourceUid);
    const tables = res?.data?.metadataTables ?? [];
    const options: AttributeTableOption[] = [];
    for (const t of tables) {
      const key = t?.metadataTableKey;
      if (!key || options.some((o) => o.key === key)) continue;
      options.push({ key, label: t.displayName || t.layerName || key });
    }
    if (options.length) return options;
  } catch {
    // 落到下面的探测兜底
  }
  const keys = await probeAttributeTableKeys(resourceUid);
  return keys.map((key) => ({ key, label: key }));
}

/**
 * 探测资源有哪些元数据表（供多 tab 使用）。
 *
 * 用 `pageSize=1` 打一次属性表接口取 `records[].tableKey`：
 * 契约里没有「表清单」独立接口，而 metadata-layer 只给几何、不保证字段顺序与属性表一致；
 * 这里只关心「有哪些 tableKey」，1 条记录足够，且不会因为大表把首屏拖慢。
 * 失败（含 40404）一律返回空数组 —— 表清单探测失败不该阻塞列表本身。
 */
export async function probeAttributeTableKeys(resourceUid: string): Promise<string[]> {
  try {
    const res = await listResourceAttributes(resourceUid, { page: 1, pageSize: METADATA_ATTR_PAGE_SIZE_MAX });
    const records = res?.data?.records ?? [];
    const keys: string[] = [];
    for (const r of records) {
      const key = r?.tableKey;
      if (key && !keys.includes(key)) keys.push(key);
    }
    // 记录为空但响应带 tableKey：单表资源只有空表时靠这个兜底
    const topKey = res?.data?.tableKey;
    if (topKey && !keys.includes(topKey)) keys.unshift(topKey);
    return keys;
  } catch {
    return [];
  }
}
