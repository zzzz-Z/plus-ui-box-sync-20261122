/**
 * 后端存储管理接口门面（对齐 Apifox 2026-10-14 v5 契约）
 *
 * 统一前缀 /api/storage，涵盖 PostGIS / 对象存储（S3/MinIO）/ 共享目录三类配置的
 * 列表、详情、删除、连通性测试、创建与更新。baseURL 由 http.ts 的 withProductBase 注入。
 */
import { apiDelete, apiGet, apiPost, apiPut } from '../http';

const BASE = '/storage';

/** 存储类型；MinIO 按 s3 归类 */
export type StorageKind = 'postgis' | 's3' | 'minio' | 'shared_directory';

/** 存储用途；PostGIS 仅支持两种数据库用途，文件后端固定 raw */
export type StoragePurpose = 'businessDatabase' | 'vectorDatabase' | 'metadataDatabase' | 'raw';

/** 配置状态，不等同任务状态 */
export type StorageStatus = 'disabled' | 'provisioning' | 'active' | 'error';

/** 供给模式：validate_only 仅验证；create_if_missing 允许建缺失目标 */
export type StorageProvisionMode = 'validate_only' | 'create_if_missing';

/** SSL 模式 */
export type PostgisSslMode = 'disable' | 'require' | 'verify-ca' | 'verify-full';

/** 列表行（GET /storage data.items 元素） */
export interface StorageConfigSummary {
  uid: string;
  displayName: string;
  kind: StorageKind;
  purpose: StoragePurpose;
  status: StorageStatus;
  enabled: boolean;
  version: number;
  connectionSummary: string;
  createdAt: string;
  updatedAt: string;
}

/** 详情；connection/credentials/target 因 kind 而异，密钥仅返回掩码 */
export interface StorageConfigDetail extends StorageConfigSummary {
  connection: Record<string, unknown>;
  credentials: Record<string, unknown> | null;
  credentialsConfigured: boolean;
  target: Record<string, unknown>;
  provisionMode: StorageProvisionMode;
  createdByRef?: string;
  updatedByRef?: string;
}

export interface StorageConfigListParams {
  kind?: StorageKind;
  purpose?: StoragePurpose;
  status?: StorageStatus;
  enabled?: boolean;
  page?: number;
  pageSize?: number;
}

export interface StorageConfigListResult {
  items: StorageConfigSummary[];
  total: number;
  page: number;
  pageSize: number;
}

export function listStorageConfigs(params: StorageConfigListParams = {}) {
  return apiGet<StorageConfigListResult>(BASE, { params });
}

export function getStorageConfig(uid: string) {
  return apiGet<StorageConfigDetail>(BASE + '/' + uid);
}

export function deleteStorageConfig(uid: string) {
  return apiDelete<{ uid: string; deleted: boolean }>(BASE + '/' + uid);
}

/** 连通性测试；HTTP 200 后仍需检查 data.connected */
export function testStorageConnection(uid: string, body?: { timeoutSeconds?: number }) {
  return apiPost<{
    connected: boolean;
    details?: Record<string, unknown>;
    message?: string;
  }>(BASE + '/' + uid + '/test', body);
}

/* -------- PostGIS -------- */

export interface PostgisStoragePayload {
  displayName: string;
  /** 业务库/矢量库/元数据库；省略默认 vectorDatabase */
  purpose?: 'businessDatabase' | 'vectorDatabase' | 'metadataDatabase';
  enabled?: boolean;
  provisionMode?: StorageProvisionMode;
  /** 以下 custom 模式连接参数 */
  host?: string;
  port?: number;
  /** 已有管理连接库（非目标库）；省略用运行配置 */
  database?: string;
  sslMode?: PostgisSslMode;
  username?: string;
  password?: string;
  /** 目标数据库：受控 ASCII 标识符，最长 63 字节 */
  targetDatabase: string;
  /** 目标 schema，默认 public */
  targetSchema?: string;
}

/** 更新载荷；version 必填 */
export interface PostgisStorageUpdatePayload extends Partial<PostgisStoragePayload> {
  version: number;
}

export function createPostgisStorage(payload: PostgisStoragePayload) {
  return apiPost<{ uid: string; version: number; status: StorageStatus }>(BASE + '/postgis', payload);
}

export function updatePostgisStorage(uid: string, payload: PostgisStorageUpdatePayload) {
  return apiPut<{ uid: string; version: number; status: StorageStatus }>(BASE + '/postgis/' + uid, payload);
}

/* -------- 对象存储（S3 兼容，含 MinIO） -------- */

export interface ObjectStoragePayload {
  displayName: string;
  /** 固定 raw */
  purpose?: 'raw';
  enabled?: boolean;
  provisionMode?: StorageProvisionMode;
  /** S3 API 端点（非控制台端口） */
  endpoint: string;
  region: string;
  accessKeyId: string;
  secretAccessKey: string;
  bucket: string;
  /** 受控相对前缀，默认空 */
  prefix?: string;
}

export interface ObjectStorageUpdatePayload extends Partial<ObjectStoragePayload> {
  version: number;
}

export function createObjectStorage(payload: ObjectStoragePayload) {
  return apiPost<{ uid: string; version: number; status: StorageStatus }>(BASE + '/object-storage', payload);
}

export function updateObjectStorage(uid: string, payload: ObjectStorageUpdatePayload) {
  return apiPut<{ uid: string; version: number; status: StorageStatus }>(BASE + '/object-storage/' + uid, payload);
}

/* -------- 共享目录 -------- */

export interface SharedFsStoragePayload {
  displayName: string;
  /** 固定 raw */
  purpose?: 'raw';
  enabled?: boolean;
  provisionMode?: StorageProvisionMode;
  /** 服务进程可访问的绝对共享根；UNC 使用 JSON 正确转义 */
  basePath: string;
  /** 可选根内相对目录，默认空 */
  relativePath?: string;
  username?: string;
  password?: string;
  /** 可选域或远端计算机名 */
  domain?: string;
}

export interface SharedFsStorageUpdatePayload extends Partial<SharedFsStoragePayload> {
  version: number;
}

export function createSharedFsStorage(payload: SharedFsStoragePayload) {
  return apiPost<{ uid: string; version: number; status: StorageStatus }>(BASE + '/shared', payload);
}

export function updateSharedFsStorage(uid: string, payload: SharedFsStorageUpdatePayload) {
  return apiPut<{ uid: string; version: number; status: StorageStatus }>(BASE + '/shared/' + uid, payload);
}
