/**
 * 元数据编辑接口族（v6 契约）：字段定义 / 记录增删改查 / 校验 / 历史 / 撤销 / 编辑租约
 *
 * 契约来源：Apifox「元数据管理模块/元数据/元数据编辑」，baseURL 由 http.ts 的 withProductBase 注入。
 * 快照：`artifacts/metadata-edit-query/01-contract/api-531575178.md` 等 11 份（原样存，未改写）。
 *
 * 前缀：`/platform/resources/{resourceUid}/metadata-tables/{tableKey}/...`
 * ⚠️ 与旧版（v5）的差异——**这是本文件被整体重写的原因**：
 *   旧路径 `/platform/resources/{resourceUid}/data/{dataUid}/versions/{versionUid}/metadata-records`
 *   已不存在（实测 HTML 404）。v6 去掉了 data/versions 两段，改用 `metadata-tables/{tableKey}` 定位，
 *   且记录主键从 `recordUid` 改为 `metadataUid`。旧路径与旧字段名一律不得再出现。
 *
 * ## 一份载荷只有一个拼装处（SKILL 铁律 2）
 *
 * 所有请求体/查询参数只能由 `buildRecord*Payload()` 与 `buildRecordDeleteQuery()` 产出。
 * 页面禁止自己拼 `values` / `lockToken` / `expectedRowVersion` —— 契约变更后多处副本必然漏改，
 * 这正是「探针全绿但用户点击 400」的根因（见 refs/pitfalls.md §F 事故复盘）。
 *
 * ## 实测事实（2026-11-03，见 artifacts/metadata-edit-query/04-probe.log）
 *
 * - 11 个接口**路径全部已上线**（不是 404）；
 * - 其中 9 个被平台权限门拦住：`HTTP 403 / code=40301 / errorCode=METADATA_PERMISSION_REQUIRED`，
 *   缺 `metadata.edit` 权限。若依侧 admin 的 `*:*:*` 对该门**无效**。
 * - `DELETE` 与 `records/batch` 两个接口穿过了权限门，返回 `40001` 参数校验错误
 *   （`INVALID_ROW_VERSION` / `INVALID_BATCH_OPERATION`），证明载荷构造必须严格按照契约。
 *
 * ## 三级前置条件（页面按此顺序走，不要跳级）
 *
 * 1. `getEditSchema()` 拿字段定义（`fields[]` 的 `writable`/`required`/`options` 是唯一校验依据）；
 * 2. `acquireEditSession()` 拿 `lockToken`（**创建记录必须持表锁**，契约原文）；
 * 3. 写操作全部带 `lockToken` + 并发判据；结束时 `releaseEditSession()`。
 *
 * 顺序颠倒的典型后果：先写后取锁 → 服务端以「本人持有且未过期的编辑锁」校验失败。
 */
import type {
  MetadataEditSession,
  MetadataEditSchema,
  MetadataRecordDetail,
  MetadataRecordGeometry,
  MetadataRecordHistoryResult,
  MetadataRecordMutationResult
} from '../types/platform';
import { apiDelete, apiGet, apiPatch, apiPost, seg } from '../http';

const RESOURCE_BASE = '/platform/resources';

/**
 * 业务码：元数据记录 / 表不存在（40404）。
 *
 * 契约明确「404 固定 40404」。语义是「没有这条数据」，UI 应显示空态而非弹错误框
 * —— 与 `metadata-attributes.ts` 的 `METADATA_ATTRIBUTES_EMPTY_CODE` 同口径。
 */
export const METADATA_RECORD_NOT_FOUND_CODE = 40404;

/** 业务码：权限不足（40301）；页面据此显示「待开通 metadata.edit 权限」而不是「系统异常」 */
export const METADATA_PERMISSION_REQUIRED_CODE = 40301;

/** 批量编辑单次条数上限（契约 api-531714898.md 明示「1—200 条」） */
export const METADATA_BATCH_MAX = 200;

/**
 * 判断一个异常是否为「平台权限门」拒绝（40301 / METADATA_PERMISSION_REQUIRED）。
 *
 * WHY 需要单独一个函数：写接口在无权限时返回 **HTTP 403**，axios 走的是 error 分支，
 * 业务码在 `error.response.data.code`（=40301）里，**不在** `error.code` 上。
 * 早前各处统一写 `Number(e?.code) === 40301` 在 HTTP 403 场景下恒为 false，
 * 导致「缺 metadata.edit 权限」被显示成「Request failed with status code 403」，
 * 用户看不出到底缺什么权限（本轮 UI E2E 实测复现）。
 *
 * 判据同时覆盖三种可达形态：
 *   1. `e.response.data.code === 40301`（HTTP 403 真实场景）；
 *   2. `e.code === 40301`（某些包装层把业务码提升到顶层时）；
 *   3. `e.response.data.data.errorCode === 'METADATA_PERMISSION_REQUIRED'`（错误明细里的稳定码）。
 */
export function isMetadataPermissionDenied(error: any): boolean {
  const body = error?.response?.data;
  if (Number(error?.code) === METADATA_PERMISSION_REQUIRED_CODE) return true;
  if (Number(body?.code) === METADATA_PERMISSION_REQUIRED_CODE) return true;
  const errorCode = body?.data?.errorCode ?? body?.errorCode;
  return errorCode === 'METADATA_PERMISSION_REQUIRED';
}

/** 记录族路径；resourceUid 与 tableKey 缺一即路径不成立 */
function recordsBase(resourceUid: string, tableKey: string) {
  return `${RESOURCE_BASE}/${seg(resourceUid)}/metadata-tables/${seg(tableKey)}`;
}

/** values 的键必须是模型字段键，值必须是**字符串**（契约 `additionalProperties:{type:string}`） */
export type MetadataFieldValues = Record<string, string>;

/* ------------------------------------------------------------------ */
/* 载荷构造（唯一拼装处）                                              */
/* ------------------------------------------------------------------ */

/** 创建记录的业务输入（页面只传这些，不碰契约字段名） */
export interface RecordCreateInput {
  /** 业务字段与值（键取自 edit-schema 的 fieldKey） */
  values: MetadataFieldValues;
  /** 编辑租约令牌；**创建必须持表锁**，缺它服务端拒绝 */
  lockToken: string;
  geometry?: MetadataRecordGeometry;
  /** 契约枚举 4326 / 4490，默认 4326 */
  geometrySrid?: 4326 | 4490;
  lockRevision?: number;
  /** 幂等 ID，≤128 字节；同主体/资源/表下相同 ID 必须对应相同请求 */
  requestId?: string;
}

/**
 * 创建记录载荷。
 *
 * WHY 在这里做「字符串化」：契约把 `values` 声明为 `additionalProperties:{type:string}`，
 * 页面表单天然会产出数字 / 布尔；直接透传会被服务端拒收。统一在此串化，调用方不必关心。
 */
export function buildRecordCreatePayload(input: RecordCreateInput) {
  if (!input?.lockToken) throw new Error('创建元数据记录必须提供 lockToken（需先获取编辑租约）');
  const payload: Record<string, unknown> = {
    values: normalizeFieldValues(input.values),
    lockToken: input.lockToken
  };
  if (input.geometry) payload.geometry = input.geometry;
  if (input.geometrySrid != null) payload.geometrySrid = input.geometrySrid;
  if (input.lockRevision != null) payload.lockRevision = input.lockRevision;
  if (input.requestId) payload.requestId = input.requestId;
  return payload;
}

/** 更新记录的业务输入 */
export interface RecordUpdateInput {
  values: MetadataFieldValues;
  /** 当前记录版本；不匹配时服务端以 409 拒绝（乐观并发） */
  expectedRowVersion: number;
  lockToken: string;
  geometry?: MetadataRecordGeometry;
  geometrySrid?: 4326 | 4490;
  lockRevision?: number;
  requestId?: string;
}

/** 更新记录载荷。三个必填：`values` / `expectedRowVersion` / `lockToken` */
export function buildRecordUpdatePayload(input: RecordUpdateInput) {
  if (input?.expectedRowVersion == null || Number.isNaN(Number(input.expectedRowVersion))) {
    throw new Error('更新元数据记录必须提供 expectedRowVersion（整数）');
  }
  if (!input?.lockToken) throw new Error('更新元数据记录必须提供 lockToken');
  const payload: Record<string, unknown> = {
    values: normalizeFieldValues(input.values),
    expectedRowVersion: Math.trunc(Number(input.expectedRowVersion)),
    lockToken: input.lockToken
  };
  if (input.geometry) payload.geometry = input.geometry;
  if (input.geometrySrid != null) payload.geometrySrid = input.geometrySrid;
  if (input.lockRevision != null) payload.lockRevision = input.lockRevision;
  if (input.requestId) payload.requestId = input.requestId;
  return payload;
}

/** 删除记录的业务输入（全部走 query 参数，没有请求体） */
export interface RecordDeleteInput {
  /** 契约标 required；实测缺省返回 40001 INVALID_ROW_VERSION */
  expectedRowVersion: number;
  /** 契约标 required；「本人持有且未过期的编辑锁」 */
  lockToken: string;
  /** 契约标 required，且必须为 true —— 防止误删 */
  confirm: true;
  requestId?: string;
}

/** 删除记录的 query 参数 */
export function buildRecordDeleteQuery(input: RecordDeleteInput) {
  if (input?.expectedRowVersion == null || Number.isNaN(Number(input.expectedRowVersion))) {
    throw new Error('删除元数据记录必须提供 expectedRowVersion（实测缺失会 40001 INVALID_ROW_VERSION）');
  }
  if (!input?.lockToken) throw new Error('删除元数据记录必须提供 lockToken');
  if (input?.confirm !== true) throw new Error('删除元数据记录必须显式 confirm=true，避免误删');
  return {
    expectedRowVersion: Math.trunc(Number(input.expectedRowVersion)),
    lockToken: input.lockToken,
    confirm: true,
    requestId: input.requestId || undefined
  };
}

/** 批量编辑的业务输入 */
export interface RecordBatchInput {
  operation: 'update' | 'delete';
  /** 目标记录 UUID 列表 */
  metadataUids: string[];
  lockToken: string;
  /** update 时必填：统一的字段值 */
  values?: MetadataFieldValues;
  /** update 时的逐条并发判据：键为 metadataUid，值为期望 rowVersion */
  expectedRowVersions?: Record<string, number>;
  /** 只预演不落库 */
  dryRun?: boolean;
  /** 要么全成要么全败 */
  atomic?: boolean;
  /** delete 时必须 true */
  confirm?: true;
  requestId?: string;
}

/**
 * 批量编辑载荷。
 *
 * ⚠️ 契约缺口：`expectedRowVersions` 只声明为 `object`，未描述键结构。
 * 本函数按「键 = metadataUid」组装，**权限开通后须实测确认**（已记入 01-contract-diff.md §四-5）。
 */
export function buildRecordBatchPayload(input: RecordBatchInput) {
  if (!input?.operation) throw new Error('批量编辑必须指定 operation（update / delete）');
  if (!input.metadataUids?.length) throw new Error('批量编辑必须提供非空的 metadataUids');
  // 契约 api-531714898.md 明示「1—200 条」；超限时后端整批 400 拒收，
  // 在构造期拦掉能把「点了没反应/整批失败」变成一句明确提示，与 ttlSeconds 的边界夹取同一风格。
  if (input.metadataUids.length > METADATA_BATCH_MAX) {
    throw new Error(`批量编辑单次最多 ${METADATA_BATCH_MAX} 条，当前 ${input.metadataUids.length} 条，请分批提交`);
  }
  if (!input.lockToken) throw new Error('批量编辑必须提供 lockToken');
  if (input.operation === 'delete' && input.confirm !== true) throw new Error('批量删除必须显式 confirm=true');

  const payload: Record<string, unknown> = {
    operation: input.operation,
    metadataUids: input.metadataUids,
    lockToken: input.lockToken
  };
  if (input.operation === 'update' && input.values) payload.values = normalizeFieldValues(input.values);
  if (input.expectedRowVersions) {
    payload.expectedRowVersions = Object.fromEntries(
      Object.entries(input.expectedRowVersions).map(([uid, version]) => [uid, Math.trunc(Number(version))])
    );
  }
  if (input.dryRun != null) payload.dryRun = input.dryRun;
  if (input.atomic != null) payload.atomic = input.atomic;
  if (input.operation === 'delete') payload.confirm = true;
  if (input.requestId) payload.requestId = input.requestId;
  return payload;
}

/** 校验 / 预演的业务输入（`POST /records/validate`） */
export interface RecordValidateInput {
  values: MetadataFieldValues;
  geometry?: MetadataRecordGeometry;
  geometrySrid?: 4326 | 4490;
  /** 编辑既有记录时提供，用于并发判据 */
  metadataUid?: string;
  lockToken?: string;
  lockRevision?: number;
  expectedRowVersion?: number;
}

/** 校验载荷（只有 `values` 是必填，其余可选） */
export function buildRecordValidatePayload(input: RecordValidateInput) {
  const payload: Record<string, unknown> = { values: normalizeFieldValues(input.values) };
  if (input.geometry) payload.geometry = input.geometry;
  if (input.geometrySrid != null) payload.geometrySrid = input.geometrySrid;
  if (input.metadataUid) payload.metadataUid = input.metadataUid;
  if (input.lockToken) payload.lockToken = input.lockToken;
  if (input.lockRevision != null) payload.lockRevision = input.lockRevision;
  if (input.expectedRowVersion != null) payload.expectedRowVersion = Math.trunc(Number(input.expectedRowVersion));
  return payload;
}

/** 撤销的业务输入 */
export interface RecordUndoInput {
  historyUid: string;
  expectedRowVersion: number;
  lockToken: string;
  lockRevision?: number;
  requestId?: string;
}

/** 撤销载荷（三个必填：historyUid / expectedRowVersion / lockToken） */
export function buildRecordUndoPayload(input: RecordUndoInput) {
  if (!input?.historyUid) throw new Error('撤销必须提供 historyUid');
  if (input.expectedRowVersion == null) throw new Error('撤销必须提供 expectedRowVersion');
  if (!input.lockToken) throw new Error('撤销必须提供 lockToken');
  const payload: Record<string, unknown> = {
    historyUid: input.historyUid,
    expectedRowVersion: Math.trunc(Number(input.expectedRowVersion)),
    lockToken: input.lockToken
  };
  if (input.lockRevision != null) payload.lockRevision = input.lockRevision;
  if (input.requestId) payload.requestId = input.requestId;
  return payload;
}

/** 获取编辑租约的业务输入（全部可选） */
export interface EditSessionInput {
  /** 只锁指定记录；不传则按 mode 全表锁 */
  metadataUids?: string[];
  /** table = 整表锁（创建记录必须用这个）；records = 按记录锁 */
  mode?: 'table' | 'records';
  /** 租约时长 1–3600 秒，默认 900 */
  ttlSeconds?: number;
}

/** 获取编辑租约载荷 */
export function buildEditSessionPayload(input: EditSessionInput = {}) {
  const payload: Record<string, unknown> = {};
  if (input.metadataUids?.length) payload.metadataUids = input.metadataUids;
  if (input.mode) payload.mode = input.mode;
  if (input.ttlSeconds != null) {
    const ttl = Math.trunc(Number(input.ttlSeconds));
    payload.ttlSeconds = Math.min(3600, Math.max(1, Number.isFinite(ttl) ? ttl : 900));
  }
  return payload;
}

/**
 * 字段值串化：契约要求 `values` 的每个值都是字符串。
 *
 * WHY 不直接 `String(v)` 一把梭：`null` / `undefined` 会被串成 "null" / "undefined" 两个**假值**，
 * 后端会当成真实字符串写进库。这类脏数据的排查成本极高，故统一转空串，让「没填」与「填了空」同义。
 */
export function normalizeFieldValues(values?: MetadataFieldValues | Record<string, unknown>): MetadataFieldValues {
  const out: MetadataFieldValues = {};
  for (const [key, raw] of Object.entries(values ?? {})) {
    out[key] = raw == null ? '' : String(raw);
  }
  return out;
}

/* ------------------------------------------------------------------ */
/* 查询门面（只读）                                                    */
/* ------------------------------------------------------------------ */

/** 获取编辑字段定义（进入编辑页时先调它） */
export function getEditSchema(resourceUid: string, tableKey: string) {
  return apiGet<MetadataEditSchema>(`${recordsBase(resourceUid, tableKey)}/edit-schema`);
}

/** 记录详情 */
export function getMetadataRecordDetail(resourceUid: string, tableKey: string, metadataUid: string) {
  return apiGet<MetadataRecordDetail>(`${recordsBase(resourceUid, tableKey)}/records/${seg(metadataUid)}`);
}

/**
 * 记录变更历史。
 *
 * 分页参数是 `page` / `pageSize`（与项目通用 `pageNum` 不同名），页面直接透传 Table 的 params
 * 会把 `pageNum` 送上去被后端忽略 —— 故此处显式白名单。
 */
export function listMetadataRecordHistory(
  resourceUid: string,
  tableKey: string,
  metadataUid: string,
  params: { page?: number; pageSize?: number } = {}
) {
  const query: Record<string, number> = {};
  if (params.page != null) query.page = Math.max(1, Math.trunc(Number(params.page)));
  if (params.pageSize != null) query.pageSize = Math.min(200, Math.max(1, Math.trunc(Number(params.pageSize))));
  return apiGet<MetadataRecordHistoryResult>(`${recordsBase(resourceUid, tableKey)}/records/${seg(metadataUid)}/history`, {
    params: query
  });
}

/* ------------------------------------------------------------------ */
/* 写门面                                                              */
/* ------------------------------------------------------------------ */

/** 创建记录（必须持表锁，见文件头「三级前置条件」） */
export function createMetadataRecord(resourceUid: string, tableKey: string, input: RecordCreateInput) {
  return apiPost<MetadataRecordMutationResult>(`${recordsBase(resourceUid, tableKey)}/records`, buildRecordCreatePayload(input));
}

/** 更新记录（乐观并发：expectedRowVersion 不匹配时服务端 409） */
export function updateMetadataRecord(resourceUid: string, tableKey: string, metadataUid: string, input: RecordUpdateInput) {
  return apiPatch<MetadataRecordMutationResult>(`${recordsBase(resourceUid, tableKey)}/records/${seg(metadataUid)}`, buildRecordUpdatePayload(input));
}

/** 删除记录（三个 query 参数在契约里都是必填） */
export function deleteMetadataRecord(resourceUid: string, tableKey: string, metadataUid: string, input: RecordDeleteInput) {
  return apiDelete<MetadataRecordMutationResult>(`${recordsBase(resourceUid, tableKey)}/records/${seg(metadataUid)}`, {
    params: buildRecordDeleteQuery(input)
  });
}

/** 批量编辑 / 批量删除 */
export function batchEditMetadataRecords(resourceUid: string, tableKey: string, input: RecordBatchInput) {
  return apiPost<MetadataRecordMutationResult>(`${recordsBase(resourceUid, tableKey)}/records/batch`, buildRecordBatchPayload(input));
}

/** 字段与几何校验（不落库，编辑表单实时校验用） */
export function validateMetadataRecord(resourceUid: string, tableKey: string, input: RecordValidateInput) {
  return apiPost<MetadataRecordDetail>(`${recordsBase(resourceUid, tableKey)}/records/validate`, buildRecordValidatePayload(input));
}

/** 撤销最近一次编辑，回到指定历史版本 */
export function undoMetadataRecord(resourceUid: string, tableKey: string, metadataUid: string, input: RecordUndoInput) {
  return apiPost<MetadataRecordMutationResult>(
    `${recordsBase(resourceUid, tableKey)}/records/${seg(metadataUid)}/undo`,
    buildRecordUndoPayload(input)
  );
}

/* ------------------------------------------------------------------ */
/* 编辑租约                                                            */
/* ------------------------------------------------------------------ */

/** 获取编辑租约（创建记录前必须拿 table 锁） */
export function acquireEditSession(resourceUid: string, tableKey: string, input: EditSessionInput = {}) {
  return apiPost<MetadataEditSession>(`${recordsBase(resourceUid, tableKey)}/edit-sessions`, buildEditSessionPayload(input));
}

/** 释放编辑租约（非持锁方调用应被服务端拒绝，不是匿名强制解锁） */
export function releaseEditSession(resourceUid: string, tableKey: string, lockToken: string) {
  return apiDelete<MetadataEditSession>(`${recordsBase(resourceUid, tableKey)}/edit-sessions/${seg(lockToken)}`);
}

/**
 * 取锁结果：把契约里的两个易混淆字段一次性归一，避免每个调用方各写一遍兼容表达式。
 *
 * WHY 需要归一：契约字段名是 `revision` / `lockedMetadataUids`，而历史代码读的是
 * `lockRevision` / `metadataUids`（见 types/platform.ts 的 deprecated 说明）。实测被权限门挡住、
 * 暂时无法确定后端到底返哪个，故两种都认。**必须在接口层收敛**：若让 4 个调用点各写一遍
 * `revision ?? lockRevision`，将来某处漏改就又变成「静默传 undefined」的老问题。
 */
export interface EditLock {
  lockToken: string;
  /** 契约名 `revision`，兼容旧名 `lockRevision`；可能为 undefined（后端未返） */
  lockRevision?: number;
  /** 锁模式 */
  mode?: 'table' | 'records';
}

/**
 * 获取编辑租约并归一为写操作可直接使用的 `EditLock`。
 *
 * 三级前置条件的第 2 级（SKILL 要求页面按顺序走、不跳级）：
 *   1. `getEditSchema()` 拿字段定义；
 *   2. 本函数拿锁；
 *   3. 写操作带 `lockToken`，结束 `releaseEditSession()`。
 *
 * CONSTRAINT 拿不到 `lockToken` 一律视为取锁失败并抛错：继续往下写必然被服务端拒绝，
 * 提前抛错能把「保存失败但不知道原因」变成一句明确提示。
 */
export async function acquireEditLock(resourceUid: string, tableKey: string, input: EditSessionInput = {}): Promise<EditLock> {
  const res = await acquireEditSession(resourceUid, tableKey, input);
  const data = res?.data;
  const lockToken = data?.lockToken ?? '';
  if (!lockToken) throw new Error('未获取到编辑锁（lockToken），请稍后重试');
  return { lockToken, lockRevision: data?.revision ?? data?.lockRevision, mode: data?.mode };
}

/**
 * 在持锁范围内执行一次写操作，并保证释放锁。
 *
 * WHY 收敛：取锁 / 写 / 放锁这三步在创建、更新、删除、批量、撤销五个功能里都要走一遍。
 * 各写一遍的典型事故是「某条错误分支提前 return 没放锁」→ 整张表被本会话持续占用到租约到期。
 * 这里把放锁放进 finally，调用方只关心业务载荷。
 *
 * 释放失败**不**向上抛：租约到期会自动回收，不该让「已经成功的写入」因为放锁失败变成报错。
 */
export async function withEditLock<T>(
  resourceUid: string,
  tableKey: string,
  lockInput: EditSessionInput,
  fn: (lock: EditLock) => Promise<T>
): Promise<T> {
  let lock: EditLock | null = null;
  try {
    lock = await acquireEditLock(resourceUid, tableKey, lockInput);
    return await fn(lock);
  } finally {
    if (lock?.lockToken) {
      releaseEditSession(resourceUid, tableKey, lock.lockToken).catch(() => undefined);
    }
  }
}
