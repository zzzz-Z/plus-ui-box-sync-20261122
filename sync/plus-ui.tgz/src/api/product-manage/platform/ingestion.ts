/**
 * 数据入库批次接口
 *
 * 路径 /platform/imports；baseURL 由 http.ts 的 withProductBase 注入。
 * 契约（产品管理/产品数据入库族）：批次主表 platform.tb_import，数据项表 platform.tb_import_item。
 * 批次无独立 events 路由——进度复用 GET /platform/tasks/{taskUid}/events 的 SSE。
 * 契约状态 developing：HTTP 200 仅表示批次已受理，不表示原件保存与资源发布完成。
 *
 * T6a（2026-11-08）关键约束：
 *   - 创建改为按 checkPolicy 条件必填；默认 require_passed（必须带 checkUid），
 *     run_if_needed 已从新受理移除，direct 不再要求原因；
 *   - 批次对象新增 checkUid / files / dataFiles / directIngest / metadataBackfill，创建、
 *     详情、补录完成三个接口共用同一投影；
 *   - 原件产物清单是独立游标分页接口 /imports/{uid}/files，与冻结的选择清单语义不同。
 * 实测（2026-11-09）：入库**列表**仍用 page/pageSize（与检查列表的 cursor/limit 不同源，别一起换）。
 */
import { apiDelete, apiGet, apiPost, PRODUCT_BASE_URL, seg, withProductBase } from '../http';
import { validateMetadataFilePaths } from './metadata-check';
import request, { globalHeaders } from '@/utils/request';
import type { Paged } from '../http';
import type { ApiResult } from '../http';
import type {
  ImportBatch,
  ImportBatchDetail,
  ImportCheckPolicy,
  ImportItem,
  ImportMetadata,
  ImportPriorityLevel,
  ImportState
} from '../types/platform';

export type { ImportBatch, ImportBatchDetail, ImportCheckPolicy, ImportItem, ImportMetadata, ImportPriorityLevel, ImportState };

const IMPORT_BASE = '/platform/imports';

/** 列表查询参数；keyword 模糊匹配批次名/资源名/产品类型名，pageSize 上限 200 */
export interface ImportListParams {
  keyword?: string;
  state?: ImportState;
  /** 产品类别 uid；不传=全部类别 */
  categoryUid?: string;
  page?: number;
  pageSize?: number;
}

/**
 * 创建入库请求体（POST /platform/imports，2026-11-18 双清单契约）。
 *
 * ### 2026-11-18 破坏性变更（据 Apifox 在线文档 api-524944844 / api-535157358）
 *
 *   1. 批次名 `batchName` → **`importName`（必填，1–160）**；旧名会导致
 *      「batchName 已存在，请使用 importName」这类 400；
 *   2. 旧 `files` 清单停用，改为 **`metadataFiles`（必填非空）+ `dataFiles`（可空）**；
 *      与旧 files 混传 400；
 *   3. `checkPolicy` 创建侧**仅接受 require_passed**；direct / run_if_needed 已停用；
 *   4. `autoStart` 默认 false，只有显式 true 才自动入队，否则需再调 /start。
 *
 * 来源优先级：逐文件 source > 任务级 source > 检查单来源（仅 metadataFiles 且无任务级 source）。
 * 来源对象只含 storageUid/rootPath/uploadUid 三字段，不含 type（多给 type 400「数据文件来源无效」）。
 *
 * CONSTRAINT 唯一拼装点是 buildImportPayload：页面不得自行挑字段或补默认值。
 */
export interface CreateImportPayload {
  /** 入库任务名称（1–160，去空白）；from-check 省略时服务端按 checkUid 生成缺省名 */
  importName?: string;
  categoryUid?: string;
  priorityLevel?: ImportPriorityLevel;
  /** 创建侧仅 require_passed；保留了字段只为读历史批次兼容 */
  checkPolicy?: ImportCheckPolicy;
  securityLevel?: string;
  requestId?: string;
  /** 已通过检查单号（require_passed 必填） */
  checkUid?: string;
  /** 新元数据清单，必填且至少 1 项；元素不带 source 时回落任务级/检查单来源 */
  metadataFiles?: ImportFileSelection[];
  /** 新数据清单，可空；元素可用逐文件 source 或继承任务级 source */
  dataFiles?: ImportFileSelection[];
  /** 受理完成后是否立即排队执行；默认 false（需显式 true 才自动入队） */
  autoStart?: boolean;
  /** 批次描述，≤500 字符；去空白后为空按 null 保存 */
  description?: string;
  /** 任务级来源缺省值（三字段，无 type），逐文件 source 优先覆盖 */
  source?: ImportFileSource;
}

/**
 * 入库清单的单条落位映射（2026-11-12 多来源契约）。
 *
 * WHY source 挂在条目上而不是任务级：同一次入库可以混排多个来源实例
 * （如「登记共享目录 A 的两个文件 + 本地上传的三个文件 + 未登记 UNC 的一个文件」），
 * 每条必须各自声明自己相对哪个根解析 `sourcePath`。
 */
export interface ImportFileSelection {
  /**
   * 该条目的来源定位（只含 storageUid/rootPath/uploadUid，**不含 type**）。
   *
   * WHY 不含 type：后端按「实际给了哪个字段」判定类型，多给 type 反而与字段冲突
   * 会触发 400「数据文件来源无效」。前端声明类型只用于拼出正确字段集。
   *
   * 元数据项（role=metadata）不得带 source：其来源由检查单决定，
   * 否则 400「元数据文件来源由检查单决定」。
   */
  source?: ImportFileSource;
  /** 相对**该条目自己 source 根**的路径；目录允许，服务端递归展开 */
  sourcePath: string;
  /** 入库后相对路径；省略时等于 sourcePath；归一后全清单唯一，冲突 400 */
  targetPath?: string;
}

/**
 * 文件级来源定位对象（不含 type，由后端按字段判定类型）。
 *
 * CONSTRAINT 三型字段互斥：
 *   upload → uploadUid 单独出现；
 *   registered_share → storageUid（rootPath 可空，空串=登记根）；
 *   direct_shared_path → rootPath 为完整 UNC/绝对路径，且不带 storageUid/uploadUid。
 *   跨类同时出现 → 400「数据文件来源无效」；全无 → 400「数据文件来源缺失」。
 */
export interface ImportFileSource {
  /** 已登记共享存储 UID（存在即按 registered_share） */
  storageUid?: string;
  /** 来源根：registered_share 为登记根内相对路径；仅给完整 UNC 时按 direct_shared_path */
  rootPath?: string;
  /** 数据上传会话 UID（存在即按 upload） */
  uploadUid?: string;
}

/** 数据来源三型（2026-11-12 契约，与检查单来源解耦） */
export type ImportSourceType = 'registered_share' | 'direct_shared_path' | 'upload';

/**
 * 数据来源声明。
 *
 * CONSTRAINT 每种类型只用对应字段：
 *   registered_share → storageUid + rootPath（登记根内相对路径，空串=登记根）；
 *   direct_shared_path → rootPath 为完整 UNC；
 *   upload → uploadUid（须为 finalize 后 READY 的会话）。
 */
export interface ImportSource {
  type: ImportSourceType;
  /** 已登记共享位置 uid（registered_share 专用） */
  storageUid?: string;
  /** registered_share：登记根内相对路径；direct_shared_path：完整 UNC */
  rootPath?: string;
  /** 数据上传会话 uid（upload 专用，须 READY） */
  uploadUid?: string;
}

/** 查询数据入库批次列表 */
export function listImportBatches(params: ImportListParams = {}) {
  return apiGet<Paged<ImportBatch>>(IMPORT_BASE, { params });
}

/**
 * 创建数据入库批次，响应返回 importUid 与 taskUid。
 *
 * CONSTRAINT requestId 为客户端幂等键，同键重放服务端返回 409 IMPORT_IDEMPOTENT_REPLAY；
 * 调用方应回读列表/详情确认，而不是当失败重试。
 */
export function createImportBatch(payload: CreateImportPayload) {
  return apiPost<ImportBatchDetail, CreateImportPayload>(IMPORT_BASE, payload);
}

/** 查询数据入库批次详情 */
export function getImportBatch(importUid: string) {
  return apiGet<ImportBatchDetail>(IMPORT_BASE + '/' + seg(importUid));
}

/** 开始入库批次；QUEUED 重复 start 只回读当前批次，PAUSED 恢复入队，其他状态 409 */
export function startImportBatch(importUid: string) {
  return apiPost<ImportBatchDetail>(IMPORT_BASE + '/' + seg(importUid) + '/start');
}

/** 暂停入库批次；当前仅 QUEUED 可暂停，RUNNING 未接 worker 检查点会返回 409 */
export function pauseImportBatch(importUid: string) {
  return apiPost<ImportBatchDetail>(IMPORT_BASE + '/' + seg(importUid) + '/pause');
}

/** 恢复入库批次；仅 PAUSED 可恢复，其他状态 409 */
export function resumeImportBatch(importUid: string) {
  return apiPost<ImportBatchDetail>(IMPORT_BASE + '/' + seg(importUid) + '/resume');
}

/** 取消入库批次；排队任务直接取消，运行中由 Worker 在安全点终止 */
export function cancelImportBatch(importUid: string) {
  return apiPost<ImportBatchDetail>(IMPORT_BASE + '/' + seg(importUid) + '/cancel');
}

/**
 * 删除数据入库批次（物理删除，用于清掉失败/取消的批次）。
 *
 * CONSTRAINT 状态门禁：统一任务处于 RUNNING / QUEUED / PAUSING 时后端返回 409
 * 「入库任务正在执行，请先取消再删除」；批次状态不在可删集合时按 404 处理。
 * SUCCEEDED / PARTIAL_SUCCESS 允许删批次记录，但不动已发布的图层与数据。
 * 响应 resourceDeleted=false 表示资源仍有图层/数据/元数据行而保留。
 */
export function deleteImportBatch(importUid: string) {
  return apiDelete<{ importUid: string; state: string; resourceDeleted: boolean }>(IMPORT_BASE + '/' + seg(importUid));
}

/** 查询批次下的数据项列表 */
export function listImportItems(importUid: string, params: { page?: number; pageSize?: number } = {}) {
  return apiGet<Paged<ImportItem>>(IMPORT_BASE + '/' + seg(importUid) + '/items', { params });
}

/** 重试失败数据项；响应返回关联批次 taskUid，进度走任务 SSE */
export function retryImportItem(importUid: string, itemUid: string) {
  return apiPost<{ importUid: string; itemUid: string; state: string; taskUid: string }>(
    IMPORT_BASE + '/' + seg(importUid) + '/items/' + seg(itemUid) + '/retry'
  );
}

/**
 * 查询批次的来源元数据（GET /platform/imports/{importUid}/metadata）。
 *
 * 返回该批次绑定模型的采集记录与结论；模型未绑定时 model.bound=false。
 * 契约状态 developing：字段随验收演进。
 */
export function getImportMetadata(importUid: string) {
  return apiGet<ImportMetadata>(IMPORT_BASE + '/' + seg(importUid) + '/metadata');
}

/** 构造来源元数据 SSE 订阅 URL；不能走原生 EventSource（需 Authorization 头） */
export function buildImportMetadataEventsUrl(importUid: string): string {
  return PRODUCT_BASE_URL + IMPORT_BASE + '/' + seg(importUid) + '/metadata/events';
}

/** 来源元数据 SSE 事件；实测事件名 ready / metadata（后续可能新增） */
export interface ImportMetadataEventPayload {
  event: string;
  data: unknown;
}

export interface ImportMetadataEventHandlers {
  onEvent?: (payload: ImportMetadataEventPayload) => void;
  onError?: (error: unknown) => void;
}

/**
 * 订阅批次来源元数据 SSE（GET /platform/imports/{importUid}/metadata/events）。
 *
 * WHY 独立实现而非复用 tasks.ts：语义不同（元数据采集流 vs 任务进度流），
 * 且契约可能各自演进；共用只会让两处的字段口径互相牵制。
 * CONSTRAINT 断线不回放，重连需调用方发起；服务端在采集完成后关闭连接。
 */
export async function subscribeImportMetadataEvents(importUid: string, handlers: ImportMetadataEventHandlers, signal?: AbortSignal): Promise<void> {
  try {
    const res = await fetch(buildImportMetadataEventsUrl(importUid), {
      headers: { ...globalHeaders(), Accept: 'text/event-stream' },
      signal
    });
    if (!res.ok || !res.body) {
      handlers.onError?.(new Error(`SSE 连接失败：HTTP ${res.status}`));
      return;
    }
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let sep = buffer.indexOf('\n\n');
      while (sep >= 0) {
        const raw = buffer.slice(0, sep);
        buffer = buffer.slice(sep + 2);
        sep = buffer.indexOf('\n\n');
        if (!raw || raw.startsWith(':')) continue;
        let eventName = 'message';
        const dataLines: string[] = [];
        for (const line of raw.split('\n')) {
          if (line.startsWith('event:')) eventName = line.slice(6).trim();
          else if (line.startsWith('data:')) dataLines.push(line.slice(5).replace(/^ /, ''));
        }
        if (!dataLines.length) continue;
        const rawData = dataLines.join('\n');
        let parsed: unknown = rawData;
        try {
          parsed = JSON.parse(rawData);
        } catch {
          /* 契约 data 为 JSON；解析失败保留原文，避免中断整个流 */
        }
        handlers.onEvent?.({ event: eventName, data: parsed });
      }
    }
  } catch (error) {
    handlers.onError?.(error);
  }
}

/** 单页条数默认值（入库文件清单契约默认 100） */
export const IMPORT_FILES_PAGE_DEFAULT = 100;

/** 单页条数上限（入库文件清单契约 1–500） */
export const IMPORT_FILES_PAGE_MAX = 500;

/** 直接入库原因长度上下限（历史审计字段；2026-11-11 起新请求不再要求/接收原因） */
export const DIRECT_INGEST_REASON_MIN = 1;
export const DIRECT_INGEST_REASON_MAX = 500;

/** 批次描述长度上限（契约 maxLength 500） */
export const IMPORT_DESCRIPTION_MAX = 500;

/** 入库批次名称长度上限（契约 1–160 字符，不强制唯一） */
export const IMPORT_BATCH_NAME_MAX = 160;

/**
 * 入库批次运行期原件产物（GET /platform/imports/{importUid}/files 的 items[]）。
 *
 * CONSTRAINT 这是**执行后登记的原件产物**（tb_task_artifact，AVAILABLE 状态），
 * 不是创建批次时的选中文件清单。选中清单只在创建/详情接口的 files 字段（string[]），
 * 不得用本接口反推选择清单。
 */
export interface ImportArtifactFile {
  /** 产物 uid */
  artifactUid: string;
  /** 文件名（不含路径） */
  name?: string;
  /** 相对批次来源目录的路径，`/` 分隔 */
  relativePath?: string;
  /** MIME 类型 */
  mediaType?: string;
  /** 字节数 */
  sizeBytes?: number;
  /** 内容摘要（小写 64 位十六进制） */
  sha256?: string;
  /** 产物状态；正常为 AVAILABLE */
  status?: string;
  /** 登记时间（UTC ISO-8601） */
  createdAt?: string;
}

/** 原件产物清单查询参数；游标分页 */
export interface ImportFilesParams {
  /** 上一页响应里的 nextCursor；首次不传 */
  cursor?: string | null;
  /** 每页条数 1–500，默认 100 */
  limit?: number;
  /** 相对路径前缀（字面匹配）；目录过滤需带尾部 `/` */
  prefix?: string | null;
}

/** 原件产物清单分页壳（与项目 Paged 的 page/pageSize 语义不同，勿混用） */
export interface ImportFilesPage {
  items: ImportArtifactFile[];
  /** 服务端生效的每页条数 */
  pageSize?: number;
  /** 下一页游标；空/null 表示没有更多 */
  nextCursor?: string | null;
  /** 是否还有下一页（与 nextCursor 同源，便于直接判空） */
  hasMore?: boolean;
}

/**
 * 游标分页查询批次的原件产物清单（GET /platform/imports/{importUid}/files）。
 *
 * CONSTRAINT 语义边界：返回运行期产物，不是选中清单（见 ImportArtifactFile 的 WHY）。
 * 检查页与入库页必须区分展示这两者，否则用户会以为入库只处理了这几个文件。
 */
export function getImportFiles(importUid: string, params: ImportFilesParams = {}) {
  const query: { cursor?: string; limit: number; prefix?: string } = { limit: IMPORT_FILES_PAGE_DEFAULT };
  const cursor = String(params.cursor ?? '').trim();
  if (cursor) query.cursor = cursor;
  const prefix = String(params.prefix ?? '');
  if (prefix) query.prefix = prefix;
  const limit = Number(params.limit ?? IMPORT_FILES_PAGE_DEFAULT);
  query.limit = Math.min(IMPORT_FILES_PAGE_MAX, Math.max(1, Math.trunc(limit) || IMPORT_FILES_PAGE_DEFAULT));
  return apiGet<ImportFilesPage>(IMPORT_BASE + '/' + seg(importUid) + '/files', { params: query });
}

/**
 * from-check 候选清单查询参数（GET /platform/imports/from-check/{checkUid}/candidates）。
 *
 * 不传来源参数时保持旧行为（使用检查单来源）；传 sourceType 时按指定来源列候选，
 * 用于「检查后换数据目录 / 换上传批次」的场景。
 */
export interface FromCheckCandidatesParams {
  sourceType?: ImportSourceType;
  /** registered_share 专用 */
  sourceStorageUid?: string;
  /** registered_share：登记根内相对路径；direct_shared_path：完整 UNC */
  sourceRootPath?: string;
  /** upload 专用 */
  sourceUploadUid?: string;
  /** 相对来源根的浏览子路径 */
  path?: string;
  cursor?: string;
  limit?: number;
}

/** from-check 候选里的单个条目 */
export interface FromCheckCandidateItem {
  /** 来源根相对路径（导航语义） */
  path?: string;
  /** 相对当前浏览目录的路径；作为 files[].sourcePath */
  relativePath: string;
  name?: string;
  type?: 'file' | 'directory' | string;
  /**
   * 角色：metadata 来自检查单（锁定、不可换不可删）；data 为用户可选的数据文件。
   * CONSTRAINT 前端不要自己判定角色，一律以此字段为准。
   */
  role?: 'metadata' | 'data' | string;
  /** 可被选为数据文件 */
  selectable?: boolean;
  /** 是否锁定（不可换不可删） */
  locked?: boolean;
  /** 是否默认选中 */
  defaultSelected?: boolean;
  /** 父级路径 */
  parentPath?: string;
  /** 不可用原因 */
  unavailableReason?: string;
  sizeBytes?: number;
  /** 指纹（服务端复核用） */
  sha256?: string;
}

/** 候选清单里的目录节点（选择节点，后端提交时递归展开） */
export interface FromCheckCandidateFolder {
  relativePath: string;
  name: string;
  parentPath: string;
  type: 'directory';
  fileCount: number;
  metadataCount: number;
  lockedMetadataCount: number;
  selectableFileCount: number;
  selectable: boolean;
}

/** 候选清单里权威子清单的元素（metadataFiles / dataFiles） */
export interface FromCheckCandidateFileRef {
  /** 相对来源根的路径；作为 files[].sourcePath */
  relativePath: string;
  sizeBytes?: number;
  sha256?: string;
}

/**
 * from-check 候选清单响应（契约 api-535210221「可入库候选」）。
 *
 * CONSTRAINT 权威清单在 metadataFiles / dataFiles，不在 items：
 *   items 受 path/cursor/limit 分页（默认 200、hasMore 可续页），只用于浏览/勾选；
 *   metadataFiles 是本次入库锁定的**全部**元数据（不受分页影响），是锁定行的唯一真源。
 *   旧实现从 items 里 filter role=metadata，数据量大时会漏行（实测 74 个元数据只返回 10 个）。
 */
export interface FromCheckCandidatesResult {
  /** 本次检查 uid */
  checkUid?: string;
  sourceType?: string;
  sourceStorageUid?: string | null;
  /** upload 数据来源会话 UID（后端若回传，供 dataFiles 逐条 source 使用） */
  sourceUploadUid?: string | null;
  /** 本次列出的来源根：direct_shared_path 为完整 UNC，registered_share 为登记根内相对路径 */
  rootPath?: string;
  /** 当前列出路径（根为空串） */
  path?: string;
  /** 扁平条目（分页，仅用于浏览/勾选，禁止当作完整清单） */
  items: FromCheckCandidateItem[];
  folders?: FromCheckCandidateFolder[];
  hasMore?: boolean;
  nextCursor?: string;
  truncated?: boolean;
  /** 权威元数据清单（锁定行的真源，不受分页影响） */
  metadataFiles?: FromCheckCandidateFileRef[];
  /** 权威数据文件清单（可选数据来源） */
  dataFiles?: FromCheckCandidateFileRef[];
  /** 元数据/数据文件计数 */
  fileCounts?: { metadata: number; data: number };
  /** 元数据文件判定依据：manifest 或 sha256 */
  manifestBasis?: 'manifest' | 'sha256';
  manifestBasisName?: string;
  /** 回落判定时的固定提示；无则 null */
  manifestNotice?: string | null;
  /** 是否没有数据文件 */
  missingDataFiles?: boolean;
}

/**
 * 列出 from-check 入库的候选文件（含检查单锁定的元数据项）。
 *
 * WHY 必须调它而不是复用检查详情里的 files：候选会把元数据标成 role=metadata（锁定）、
 * 把同目录下的数据文件标成 selectable，前端据此渲染「哪些能删、哪些只能改 targetPath」；
 * 自己按扩展名猜角色必然与后端冻结口径不一致，提交即 409。
 */
export function listFromCheckCandidates(checkUid: string, params: FromCheckCandidatesParams = {}) {
  return apiGet<FromCheckCandidatesResult>(IMPORT_BASE + '/from-check/' + seg(checkUid) + '/candidates', { params });
}

/**
 * from-check 入库提交（POST /platform/imports/from-check/{checkUid}）。
 *
 * 载荷与 direct 同形（source + files），但**多一条纪律**：检查单里的元数据文件
 * 会自动补齐，元数据 sourcePath 不可换、不可删，只有 targetPath 可在 files 中覆盖。
 */
export function createFromCheckImport(checkUid: string, payload: CreateImportPayload) {
  return apiPost<ImportBatchDetail, CreateImportPayload>(IMPORT_BASE + '/from-check/' + seg(checkUid), payload);
}

/* -------- 数据上传会话（2026-11-12 契约，独立于旧元数据上传） -------- */

const DATA_UPLOAD_BASE = IMPORT_BASE + '/data-uploads';

/** 创建上传会话时声明的单个文件 */
export interface DataUploadFileDecl {
  /** 相对路径；最终成为 files[].sourcePath */
  path: string;
  sizeBytes: number;
  /** 64 位十六进制 sha256（前端计算，服务端 finalize 时复核） */
  sha256: string;
}

/** 创建上传会话响应里的单个文件上传指令 */
export interface DataUploadFileTicket {
  fileUid: string;
  path: string;
  sizeBytes?: number;
  sha256?: string;
  /** direct=直传对象存储；relay=走服务中转 */
  uploadMode?: 'direct' | 'relay' | string;
  /** 单文件 PUT 时的预签名地址 */
  uploadUrl?: string;
  /** multipart 时的分片预签名地址（>16MiB） */
  parts?: Array<{ partNumber: number; uploadUrl: string; sizeBytes?: number; offsetBytes?: number }>;
}

/** 创建上传会话响应 */
export interface DataUploadSession {
  uploadUid: string;
  mode?: string;
  files: DataUploadFileTicket[];
  /** 直传不可用时的中转兜底 */
  fallback?: { mode: 'relay' | string; baseUrl?: string };
}

/** 上传会话查询响应（GET /imports/data-uploads/{uploadUid}） */
export interface DataUploadSessionDetail {
  uploadUid?: string;
  /** 会话状态；READY 才可放进 source */
  state?: string;
  expired?: boolean;
  expiresAt?: string;
  fileCount?: number;
  totalBytes?: number;
  files?: DataUploadFileTicket[];
  /** finalize 成功后才有的清单 */
  manifest?: {
    fileCount?: number;
    totalBytes?: number;
    sha256?: string;
    files?: Array<{ path: string; sizeBytes?: number; sha256?: string }>;
  };
}

/** 创建数据上传会话：声明文件清单，拿到每文件的直传地址 */
export function createDataUploadSession(files: DataUploadFileDecl[]) {
  return apiPost<DataUploadSession, { files: DataUploadFileDecl[] }>(DATA_UPLOAD_BASE, { files });
}

/**
 * 中转上传单个分片（PUT /imports/data-uploads/{uploadUid}/files/{fileUid}/parts/{partNo}）。
 *
 * CONSTRAINT 请求体是**原始字节**，不是 JSON；单文件也走这个接口且 partNo=1。
 * 因此不走 apiPut helper（它序列化 JSON），直接用 request.put 并声明 R。
 */
export function putDataUploadPart(
  uploadUid: string,
  fileUid: string,
  partNo: number,
  bytes: Blob | ArrayBuffer,
  onProgress?: (percent: number) => void
) {
  return request.put<{ partNo: number; receivedBytes?: number }, ApiResult<{ partNo: number; receivedBytes?: number }>>(
    `${DATA_UPLOAD_BASE}/${seg(uploadUid)}/files/${seg(fileUid)}/parts/${partNo}`,
    bytes,
    withProductBase({
      headers: { 'Content-Type': 'application/octet-stream' },
      onUploadProgress: (e: any) => {
        if (!onProgress) return;
        const total = e?.total || 0;
        if (total > 0) onProgress(Math.min(100, Math.round(((e.loaded || 0) / total) * 100)));
      }
    })
  );
}

/** finalize 上传会话：成功后 state=READY，manifest 才可信 */
export function finalizeDataUploadSession(uploadUid: string) {
  return apiPost<DataUploadSessionDetail>(`${DATA_UPLOAD_BASE}/${seg(uploadUid)}/finalize`);
}

/** 查询上传会话状态（轮询用） */
export function getDataUploadSession(uploadUid: string) {
  return apiGet<DataUploadSessionDetail>(`${DATA_UPLOAD_BASE}/${seg(uploadUid)}`);
}

/** 直传一个已签名 URL（单文件 PUT 或 multiplex 分片）；不经过产品网关 baseURL */
export async function putToSignedUrl(url: string, bytes: Blob | ArrayBuffer, onProgress?: (percent: number) => void): Promise<void> {
  await request.put(url, bytes, {
    baseURL: '',
    // 预签名 URL 的鉴权在 query（X-Amz-Signature）里；拦截器自动加的 Authorization
    // 会与之冲突，MinIO 报「multiple authentication types」→ 400。用 isToken:false 跳过。
    headers: { 'Content-Type': 'application/octet-stream', isToken: false },
    onUploadProgress: (e: any) => {
      if (!onProgress) return;
      const total = e?.total || 0;
      if (total > 0) onProgress(Math.min(100, Math.round(((e.loaded || 0) / total) * 100)));
    }
  });
}

/** 会话是否 READY（可放进 source） */
export function isDataUploadReady(detail?: DataUploadSessionDetail | null): boolean {
  const state = String(detail?.state ?? '').toUpperCase();
  return state === 'READY' && !detail?.expired;
}
export function completeMetadataBackfill(importUid: string) {
  return apiPost<ImportBatchDetail, Record<string, never>>(IMPORT_BASE + '/' + seg(importUid) + '/metadata-backfill/complete', {});
}

/** 载荷构造结果；不用判别联合——本仓 strictNullChecks 关闭，窄化不生效 */
export interface ImportPayloadBuildResult {
  ok: boolean;
  payload?: CreateImportPayload;
  message?: string;
  /**
   * 弃用策略标记。run_if_needed 改为硬拒（见下方 buildImportPayload）后，
   * 该字段不再有生产路径会置 true，保留是因为 `DEPRECATED_CHECK_POLICY_NOTICE`
   * 仍被页面用于历史批次行的提示文案，删除会牵连展示层。
   */
  deprecated?: boolean;
  /** 弃用提示文案；页面对历史 run_if_needed 批次仍展示该文案 */
  notice?: string;
}

/** 已弃用策略的提示文案；UI 与 build 结果共用同一份，避免两处措辞漂移 */
export const DEPRECATED_CHECK_POLICY_NOTICE = 'run_if_needed 是迁移期兼容策略，已弃用：请改用 require_passed（绑定检查单）或 direct（显式直接入库）';

/**
 * 由业务输入构造创建入库批次的载荷，并做按策略的条件必填校验与默认值填充。
 *
 * WHY 单独抽出：新建弹窗与列表页可能各自拼字段，契约变更时会漏改（曾出现只改一处、点击即 400）。
 * 调用方只传业务输入，默认值（priorityLevel/checkPolicy/securityLevel）在此收口。
 *
 * 2026-11-18 双清单契约（**破坏性**，据在线文档 api-524944844 / api-535157358）：
 *   - 批次名改为 `importName`（旧 `batchName` 会让后端报「batchName 已存在」类 400）；
 *   - 旧 `files` 清单停用，改为 `metadataFiles`（必填非空）+ `dataFiles`（可空），混传 400；
 *   - 创建侧只有 require_passed 可用；direct / run_if_needed 已停用；
 *   - 来源优先级：逐文件 source > 任务级 source > 检查单来源（仅 metadataFiles）。
 */
export function buildImportPayload(input: {
  /** 入库任务名称；from-check 省略时服务端按 checkUid 生成缺省名 */
  importName?: string | null;
  /** @deprecated 旧批次名别名，等价于 importName；新代码请用 importName */
  batchName?: string | null;
  categoryUid?: string | null;
  priorityLevel?: ImportPriorityLevel | null;
  checkPolicy?: ImportCheckPolicy | null;
  securityLevel?: string | null;
  requestId?: string | null;
  checkUid?: string | null;
  /** 新元数据清单（必填非空）；元素不带 source 时来源回落任务级/检查单 */
  metadataFiles?: Array<string | ImportFileSelection> | null;
  /** 新数据清单（可空）；元素各自带 source 或继承任务级 source */
  dataFiles?: Array<string | ImportFileSelection> | null;
  /** @deprecated 旧 files 清单已停用（2026-11-18）；仅用于兼容旧调用，请改用双清单 */
  files?: Array<string | ImportFileSelection> | null;
  autoStart?: boolean | null;
  description?: string | null;
  /** 任务级来源缺省值（三字段，无 type），逐文件 source 优先覆盖 */
  source?: ImportFileSource | null;
}): ImportPayloadBuildResult {
  const importName = String(input?.importName ?? input?.batchName ?? '').trim();
  if (importName && importName.length > IMPORT_BATCH_NAME_MAX) {
    return { ok: false, message: `入库任务名称不能超过 ${IMPORT_BATCH_NAME_MAX} 字符` };
  }

  const checkPolicy = (input?.checkPolicy || 'require_passed') as ImportCheckPolicy;
  // 创建侧仅接受 require_passed（在线文档 api-524944844：direct/run_if_needed 已停用）
  if (checkPolicy !== 'require_passed') {
    return { ok: false, message: '创建入库仅支持「检查通过后入库」；直接入库与 run_if_needed 已停用' };
  }

  const payload: CreateImportPayload = {
    priorityLevel: input.priorityLevel || 'medium',
    securityLevel: input.securityLevel || 'public'
  };
  // 新契约 from-check 请求体不含 checkPolicy（require_passed 为默认），上面只用于入参校验
  if (importName) payload.importName = importName;
  if (input.requestId) payload.requestId = input.requestId;
  if (input.autoStart != null) payload.autoStart = Boolean(input.autoStart);

  const description = String(input.description ?? '');
  if (description.length > IMPORT_DESCRIPTION_MAX) return { ok: false, message: `批次描述不能超过 ${IMPORT_DESCRIPTION_MAX} 字符` };
  if (description.trim()) payload.description = description.trim();

  const checkUid = String(input.checkUid ?? '').trim();
  if (!checkUid) return { ok: false, message: '「检查通过后入库」必须绑定一条检查记录（checkUid）' };
  payload.checkUid = checkUid;

  // 任务级 source（三字段无 type）：逐文件 source 优先覆盖
  if (input.source) {
    const normalizedSource = normalizeFileSource(input.source);
    if (normalizedSource.error) return { ok: false, message: normalizedSource.error };
    if (normalizedSource.value) payload.source = normalizedSource.value;
  }

  // 兼容旧调用：只给了 files 时按 role 猜不出来，统一当 dataFiles；metadataFiles 交给调用方显式传
  const legacyFiles = input.files ?? [];
  const metadataRaw = input.metadataFiles ?? null;
  const dataRaw = input.dataFiles ?? (metadataRaw ? null : legacyFiles);

  // 元数据清单必填非空；元素可带逐文件 source，缺省回落任务级/检查单来源
  const metadata = normalizeImportFiles(metadataRaw);
  if (metadata.error) return { ok: false, message: '元数据文件：' + metadata.error };
  if (!metadata.list.length) return { ok: false, message: '请选择至少一个元数据文件（metadataFiles 必填）' };
  payload.metadataFiles = metadata.list;

  // 数据清单可空；每条自带 source（缺来源后端 400「数据文件来源缺失」）
  const data = normalizeImportFiles(dataRaw);
  if (data.error) return { ok: false, message: '数据文件：' + data.error };
  if (data.list.length) payload.dataFiles = data.list;

  if (input.categoryUid) payload.categoryUid = input.categoryUid;
  return { ok: true, payload };
}

/**
 * 规范化数据来源。
 *
 * 三种入参形态按优先级收敛：
 *   1. 显式 source → 原样校验后透传（sourcePath/UNC/upload 三型任一）；
 *   2. sourceStorageUid + dataRootPath → registered_share；
 *   3. 只有 dataRootPath → direct_shared_path（完整 UNC）。
 *
 * CONSTRAINT registered_share 的空串 rootPath 是合法值（登记根），不能用判空丢弃；
 * 因此这里用 null/undefined 判缺，不用 falsy。
 */
export function normalizeImportSource(
  source?: ImportSource | null,
  sourceStorageUid?: string | null,
  dataRootPath?: string | null
): { value?: ImportSource; error?: string } {
  if (source && source.type) {
    const type = source.type;
    if (type !== 'registered_share' && type !== 'direct_shared_path' && type !== 'upload') {
      return { error: '数据来源类型无效：只能是 registered_share / direct_shared_path / upload' };
    }
    if (type === 'upload') {
      if (!source.uploadUid) return { error: '数据来源为上传时必填 uploadUid' };
      return { value: { type, uploadUid: source.uploadUid } };
    }
    if (source.rootPath == null) return { error: '数据来源必填 rootPath' };
    if (type === 'registered_share') {
      if (!source.storageUid) return { error: '已登记共享目录来源必填 storageUid' };
      return { value: { type, storageUid: source.storageUid, rootPath: String(source.rootPath) } };
    }
    return { value: { type, rootPath: String(source.rootPath) } };
  }
  const uid = String(sourceStorageUid ?? '').trim();
  if (uid && dataRootPath != null) return { value: { type: 'registered_share', storageUid: uid, rootPath: String(dataRootPath) } };
  if (dataRootPath != null && String(dataRootPath).trim()) return { value: { type: 'direct_shared_path', rootPath: String(dataRootPath) } };
  return {};
}

/**
 * 规范化单条文件来源（2026-11-12 多来源契约）。
 *
 * 后端只认三个字段、且按字段判定类型（不传 type）：
 *   - uploadUid          → upload
 *   - storageUid         → registered_share（rootPath 可空，空串=登记根）
 *   - 只有完整 UNC rootPath → direct_shared_path
 *   - 都没有              → 由调用方报「数据文件来源缺失」
 * 跨类混传（如同时给 storageUid 与 uploadUid）后端报「数据文件来源无效」，这里提前拦截。
 */
function normalizeFileSource(raw?: ImportFileSource | null): { value?: ImportFileSource; error?: string } {
  if (!raw || typeof raw !== 'object') return {};
  const storageUid = String(raw.storageUid ?? '').trim();
  const uploadUid = String(raw.uploadUid ?? '').trim();
  const hasRoot = raw.rootPath != null;
  const rootPath = hasRoot ? String(raw.rootPath) : '';

  const kinds = [!!storageUid, !!uploadUid, hasRoot].filter(Boolean).length;
  if (kinds === 0) return {};
  if (storageUid && uploadUid) return { error: '数据文件来源无效：storageUid 与 uploadUid 不能同时出现' };
  if (uploadUid) {
    if (hasRoot) return { error: '数据文件来源无效：uploadUid 不能与 rootPath 同时出现' };
    return { value: { uploadUid } };
  }
  if (storageUid) return { value: { storageUid, rootPath } };
  // 仅 rootPath：direct_shared_path 要求是完整 UNC（\\主机\共享）
  if (!/^\\\\[^\\]+\\[^\\]+/.test(rootPath)) {
    return { error: `数据文件来源无效：只有 rootPath 时必须是完整 UNC（如 \\\\主机\\共享），收到「${rootPath}」` };
  }
  return { value: { rootPath } };
}

/**
 * 规范化文件清单：字符串元素按「targetPath=sourcePath」补齐成对象，并逐条收敛 source。
 *
 * CONSTRAINT 只校验 sourcePath（契约禁绝对路径/盘符/..），targetPath 不强制：
 * 目录元素允许作为 sourcePath（后端递归展开），因此不能要求它「看起来像文件」。
 * CONSTRAINT 2026-11-12 起 source 必须**逐条保留**：任务级 source 已停用，
 * 丢了 source 的 data 条目会被后端判「数据文件来源缺失」。
 * CONSTRAINT files 与 dataFiles 互斥：本函数只产出 files，调用方不得再发 dataFiles。
 */
export function normalizeImportFiles(raw?: Array<string | ImportFileSelection> | null): { list: ImportFileSelection[]; error?: string } {
  const arr = Array.isArray(raw) ? raw : [];
  const list: ImportFileSelection[] = [];
  const sourcePaths: string[] = [];
  for (const item of arr) {
    if (typeof item === 'string') {
      if (!item) continue;
      sourcePaths.push(item);
      list.push({ sourcePath: item, targetPath: item });
      continue;
    }
    if (!item || typeof item !== 'object') continue;
    const sourcePath = String(item.sourcePath ?? '').trim();
    if (!sourcePath) continue;
    sourcePaths.push(sourcePath);
    const targetPath = item.targetPath == null ? sourcePath : String(item.targetPath).trim();
    const source = normalizeFileSource(item.source);
    if (source.error) return { list: [], error: `${source.error}（${sourcePath}）` };
    const selection: ImportFileSelection = targetPath ? { sourcePath, targetPath } : { sourcePath };
    if (source.value) selection.source = source.value;
    list.push(selection);
  }
  if (!list.length) return { list: [] };
  const filesError = validateMetadataFilePaths(sourcePaths);
  if (filesError) return { list: [], error: filesError };
  /**
   * targetPath 归一后必须全清单唯一：不同来源下同名 sourcePath 是合法的，
   * 但落到同一个 targetPath 会互相覆盖，后端直接 400「数据文件目标路径冲突」。
   * WHY 前端也拦：给出具体冲突路径比等后端回一句话更可诊断。
   */
  const seen = new Map<string, string>();
  for (const item of list) {
    const target = String(item.targetPath || item.sourcePath);
    const prev = seen.get(target);
    if (prev != null && prev !== item.sourcePath) {
      return { list: [], error: `数据文件目标路径冲突：「${target}」被多个文件占用，请为其中一个改名` };
    }
    seen.set(target, item.sourcePath);
  }
  return { list };
}
