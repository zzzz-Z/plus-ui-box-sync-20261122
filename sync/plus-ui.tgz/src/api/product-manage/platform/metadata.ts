/**
 * 平台元数据真实接口门面
 *
 * 统一前缀 /api/platform/metadata：baseURL=/api 由 src/utils/request.ts 注入，
 * 故此处只拼 /platform/metadata/...，最终请求路径与后端文档一致。
 *
 * 与 src/services/api.ts（Mock 门面）并存：切换时页面只需改 import 来源，
 * 方法名与返回口径保持 { code, message, data }，页面逻辑不动（AGENTS.md「接真实接口」）。
 */
import request from '@/utils/request';
import { withProductBase, type Paged } from '../http';

const MODEL_BASE = '/platform/metadata/models';
const TEMPLATE_BASE = '/platform/metadata/templates';
const FIELD_LIB_BASE = '/platform/metadata/field-library';
const FIELD_TYPES_BASE = '/platform/metadata/field-types';
const SOURCE_BASE = '/platform/metadata/sources';
const CHECK_BASE = '/platform/metadata/checks';

/**
 * 后端统一包装体 { code, message, data }。
 * request.ts 的响应拦截器已把 AxiosResponse 解包到业务层，实际返回即本结构；
 * 但 axios 默认第二泛型 R = AxiosResponse<T> 与之不符，故下方 helper 通过 axios
 * 第二泛型直接声明 R = ApiResult<T>，免除类型断言。
 * （types/axios.d.ts 只增强 AxiosResponse 字段，不改变 get/post 的返回类型）
 */
export interface ApiResult<T = unknown> {
  /** 业务状态码（200 为成功） */
  code: number;
  /** 业务提示信息 */
  message: string;
  /** 业务数据体 */
  data: T;
}

/**
 * axios 第二泛型 helper：返回值声明为 ApiResult<T>，与拦截器解包行为一致。
 * B 为请求体类型，未显式指定时从实参推断。
 */
function apiGet<T>(url: string) {
  return request.get<T, ApiResult<T>>(url, withProductBase());
}
function apiPost<T, B = unknown>(url: string, body?: B) {
  return request.post<T, ApiResult<T>, B>(url, body, withProductBase());
}
function apiPatch<T, B = unknown>(url: string, body?: B) {
  return request.patch<T, ApiResult<T>, B>(url, body, withProductBase());
}
function apiPut<T, B = unknown>(url: string, body?: B) {
  return request.put<T, ApiResult<T>, B>(url, body, withProductBase());
}
function apiDelete<T>(url: string, config?: object) {
  return request.delete<T, ApiResult<T>>(url, withProductBase(config));
}

/* ------------------------------------------------------------------ */
/* 类型：字段 / 表 / 模型 / 字段库分类                                    */
/* ------------------------------------------------------------------ */

/** 字段校验规则；保持开放索引以兼容后端后续新增规则字段 */
export interface FieldValidationRule {
  /** 最小长度（字符串类） */
  minLength?: number;
  /** 最大长度（字符串类） */
  maxLength?: number;
  /** 正则表达式（字符串类） */
  pattern?: string;
  /** 最小值（数值类） */
  min?: number;
  /** 最大值（数值类） */
  max?: number;
  [key: string]: unknown;
}

/** 模型字段定义（含类型、控件、校验与展示元数据） */
export interface ModelFieldDefinition {
  /** 字段标识（英文） */
  fieldKey: string;
  /** 字段在模型中的完整路径 */
  fieldPath: string;
  /** 字段显示名 */
  displayName: string;
  /** 字段所属类别（结构/管理/发现/应用） */
  category: string;
  /** 值类型（string / integer / date 等） */
  valueType: string;
  /** 输入控件类型 */
  inputWidget: string;
  /** 取值来源（用户输入 / 字典 / 引用等） */
  valueSource: string;
  /** 是否可编辑 */
  editable: boolean;
  /** 是否必填 */
  required: boolean;
  /** 是否可为空 */
  nullable: boolean;
  /** 是否可重复（数组语义） */
  repeatable: boolean;
  /** 字段长度（字符串类上限） */
  fieldLength?: number;
  /**
   * 字段长度（后端真实落库并返回的键；fieldLength 出参恒为 null，见 02-api-layer.md 三坑）。
   * 展示层应读本字段。
   */
  length?: number;
  /** 精度（仅数值字段携带） */
  precision?: number;
  /** 小数位（仅存量数据携带该值时返回） */
  scale?: number;
  /** 枚举选项 */
  options: string[];
  /** 校验规则（长度/正则/数值范围等） */
  validationRule?: FieldValidationRule;
  /** 示例值（表单提示用） */
  exampleValue?: string;
  /** 默认值 */
  defaultValue?: string;
  /** 字段描述 */
  description?: string;
  /** 帮助文本（表单说明） */
  helpText?: string;
  /** 排序号（同级内升序） */
  sortOrder: number;
  /** 扩展元数据（后端可附加业务字段） */
  metadata?: Record<string, unknown>;
}

/** 模型表定义（表元信息 + 字段列表） */
export interface ModelTableDefinition {
  /** 表唯一标识（服务端生成，仅响应携带） */
  tableUid?: string;
  /** 表标识（英文） */
  tableKey: string;
  /** 表标识（后端 name 字段，与 tableKey 语义相同，兼容保留） */
  name?: string;
  /** 表名 */
  tableName: string;
  /** 表类型（主表 / 子表 / 关联表等） */
  tableType: string;
  /** 表描述 */
  description?: string;
  /** 排序号（同级内升序） */
  sortOrder: number;
  /** 表包含的字段数量（列表接口用，避免拉全表结构） */
  fieldCount?: number;
  /** 空间约束（仅设置时返回） */
  spatialConstraint?: Record<string, unknown>;
  /** 表包含的字段定义 */
  fields: ModelFieldDefinition[];
}

/** 创建/更新模型的请求体 */
export interface MetadataModelPayload {
  /** 模型编码（英文标识，唯一） */
  modelKey: string;
  /** 模型名称 */
  modelName: string;
  /** 模型描述 */
  description?: string;
  /** 关联的产品类别编码列表 */
  productCategoryKeys: string[];
  /** 模型包含的表定义 */
  tables: ModelTableDefinition[];
  /** 乐观并发版本号；PATCH 更新必填正整数，POST 新建不传 */
  expectedVersionNo?: number;
}

/** 后端返回的模型定义；在请求体基础上追加服务端生成字段 */
export interface MetadataModel extends MetadataModelPayload {
  /** 模型唯一标识（服务端生成） */
  modelUid: string;
  /** 关联的产品类别（后端返回完整节点，含 categoryUid / categoryKey / categoryName） */
  productCategories?: Array<{ categoryUid: string; categoryKey: string; categoryName: string }>;
  /** 模型包含的表数量（列表接口用，避免拉全表结构） */
  tableCount?: number;
  /** 模型包含的字段总数 */
  fieldCount?: number;
  /** 是否为模板模型 */
  isTemplate?: boolean;
  /** 创建人展示名 */
  createdByDisplayName?: string;
  /** 创建人用户名 */
  createdByUsername?: string;
  /** 创建人对象 */
  creator?: { displayName?: string; username?: string };
  /** 版本号 */
  versionNo?: number;
  /** 当前用户是否可删除 */
  canDelete?: boolean;
  /** 当前用户是否可编辑 */
  canEdit?: boolean;
  /** 操作人与时间戳在文档中未强制，标记可选以兼容不同后端版本 */
  operator?: string;
  /** 创建时间 */
  createdAt?: string;
  /** 最后更新时间 */
  updatedAt?: string;
}

/** 字段库分类节点（可挂载字段列表） */
export interface FieldLibraryCategory {
  /** 分类唯一标识 */
  categoryUid: string;
  /** 分类编码（英文标识） */
  categoryKey: string;
  /** 分类名称 */
  categoryName: string;
  /** 分类描述 */
  description?: string;
  /** 同级排序号 */
  sortOrder?: number;
  /** 分类下字段；契约返回字段预设结构（含 fieldUid / categoryUid），与 FieldLibraryField 一致 */
  fields?: FieldLibraryField[];
}

/**
 * 字段库字段（数据库存储，模型引用时复制一份定义，不依赖字段库后续修改）。
 * 结构与 ModelFieldDefinition 高度一致，多出 categoryUid / fieldUid 用于归属与寻址。
 * TODO: 与后端确认 fieldUid 是否即 fieldKey，或另有一套 id 体系。
 */
export interface FieldLibraryField extends ModelFieldDefinition {
  /** 字段库字段唯一标识 */
  fieldUid: string;
  /** 所属字段库分类 uid */
  categoryUid: string;
}

/**
 * 字段类型下拉选项（GET /field-types 返回）。
 * 契约仅声明 code / displayName / numeric / nullable 四项；widgets / rules 为早期推断字段，
 * 后端可能在未来版本追加，标记为可选以兼容。
 */
export interface FieldTypeOption {
  /** 类型代码（闭合枚举：string / integer / number / boolean / date / datetime / json / geometry） */
  code: string;
  /** 中文展示名 */
  displayName: string;
  /** 是否数值类型 */
  numeric: boolean;
  /** 类型能力：恒为 true，不代表某字段已选择 nullable */
  nullable: boolean;
  /** 可用输入控件代码（文档未声明，可选） */
  widgets?: string[];
  /** 可用校验规则（文档未声明，可选） */
  rules?: string[];
}

/**
 * 已入库资产（GET /sources/assets 返回），供模型创建页面选择解析来源。
 * TODO: 待后端确认字段集，先按常见命名列出。
 */
export interface SourceAsset {
  /** 资产唯一标识 */
  assetUid: string;
  /** 资产名称 */
  assetName: string;
  /** 资产版本 uid */
  assetVersionUid?: string;
  /** 资产描述 */
  description?: string;
  /** 最后更新时间 */
  updatedAt?: string;
}

/**
 * 源结构解析结果（inspect-source / inspect-file）：可编辑的模型草稿。
 * 与 MetadataModelPayload 结构一致，但未保存 —— 由用户确认后再调 createMetadataModel。
 */
export type InspectSourceResult = MetadataModelPayload;

/**
 * POST /checks/structure 返回：结构检查结果。
 * TODO: 与后端确认字段命名；此处按「总体结论 + 问题清单」推断。
 */
export interface StructureCheckResult {
  /** 是否整体通过 */
  passed: boolean;
  /** 问题数量（不含信息级） */
  issueCount: number;
  /** 问题明细清单 */
  issues: Array<{
    /** 表标识 / 字段路径等定位信息 */
    target: string;
    /** 问题类别：missing-table / missing-field / type-mismatch / ... */
    kind: string;
    /** 问题描述 */
    message: string;
  }>;
}

/**
 * POST /checks/values 返回：记录级完整性 / 准确性检查结果。
 * TODO: 与后端确认字段命名。
 */
export interface ValueCheckResult {
  /** 是否整体通过 */
  passed: boolean;
  /** 总记录数 */
  total: number;
  /** 未通过记录数 */
  failedCount: number;
  /** 错误明细清单 */
  errors: Array<{
    /** 记录 uid / id */
    recordUid: string;
    /** 字段路径 */
    fieldPath: string;
    /** 未通过原因 */
    reason: string;
  }>;
}

/**
 * GET /checks 返回：历史检查记录。
 * TODO: 与后端确认字段命名。
 */
export interface MetadataCheckRecord {
  /** 检查记录唯一标识 */
  checkUid: string;
  /** 被检查的资产版本 uid */
  assetVersionUid: string;
  /** 关联的模型 uid（可为空） */
  modelUid?: string;
  /** 检查类型：structure / values */
  checkType: string;
  /** 是否通过 */
  passed: boolean;
  /** 结果描述 */
  message?: string;
  /** 检查时间 */
  createdAt?: string;
}

/* ------------------------------------------------------------------ */
/* 一、元数据模型                                                       */
/* ------------------------------------------------------------------ */

/** 查询当前用户可见的元数据模型列表；后端返回 { items, total } 对象 */
export function getMetadataModelList() {
  return apiGet<{ items: MetadataModel[]; total: number }>(MODEL_BASE);
}

/** 创建元数据模型（含表、字段、产品类别关联与校验规则） */
export function createMetadataModel(payload: MetadataModelPayload) {
  return apiPost<MetadataModel>(MODEL_BASE, payload);
}

/** 查询模型完整定义（含表、字段、允许值与校验规则） */
export function getMetadataModelDetail(modelUid: string) {
  return apiGet<MetadataModel>(`${MODEL_BASE}/${modelUid}`);
}

/** 修改模型名称/说明/产品类别/表与字段定义 */
export function updateMetadataModel(modelUid: string, payload: Partial<MetadataModelPayload>) {
  return apiPatch<MetadataModel>(`${MODEL_BASE}/${modelUid}`, payload);
}

/** 逻辑删除结果形状（类别、模型、字段预设共用） */
export interface DeleteResult {
  /** 被删除的 uid */
  uid: string;
  /** 版本号；类别与字段预设恒为 0，模型为删除时的版本号 */
  versionNo: number;
  /** 恒为 true */
  deleted: boolean;
}

/** 逻辑删除模型，按后端要求显式携带 confirm:true */
export function deleteMetadataModel(modelUid: string) {
  return apiDelete<DeleteResult>(`${MODEL_BASE}/${modelUid}`, { data: { confirm: true } });
}

/* ------------------------------------------------------------------ */
/* 二、模型模板                                                         */
/* ------------------------------------------------------------------ */

/** 将普通模型复制为模板（原模型不变） */
export function saveModelAsTemplate(modelUid: string, payload: { modelName: string; description?: string }) {
  return apiPost<MetadataModel>(`${MODEL_BASE}/${modelUid}/save-as-template`, payload);
}

/**
 * 查询可用元数据模型模板列表。
 * 返回口径不固定（纯数组、{ items, total } 都出现过），调用方需自行归一化后再渲染。
 */
export function getMetadataTemplateList() {
  return apiGet<MetadataModel[] | Paged<MetadataModel>>(TEMPLATE_BASE);
}

/** 查询模板完整定义 */
export function getMetadataTemplateDetail(modelUid: string) {
  return apiGet<MetadataModel>(`${TEMPLATE_BASE}/${modelUid}`);
}

/** 由模板实例化出一个新的普通模型 */
export function instantiateMetadataTemplate(modelUid: string, payload: { modelName: string; description?: string }) {
  return apiPost<MetadataModel>(`${TEMPLATE_BASE}/${modelUid}/instantiate`, payload);
}
/* 说明：模板的 PATCH / DELETE 后端未注册（实测 404，drogon 直接拒），
   模板只支持 GET 与 POST /templates/{uid}/instantiate，故不提供写接口。 */

/* ------------------------------------------------------------------ */
/* 三、模型范例数据                                                     */
/* ------------------------------------------------------------------ */

/** 按模型真实表/字段生成属性表形式范例数据（不生成 SQL） */
export function generateMetadataModelSampleData(modelUid: string, rowCount = 5) {
  return apiPost<Record<string, unknown>[]>(`${MODEL_BASE}/${modelUid}/sample-data`, { rowCount });
}

/* ------------------------------------------------------------------ */
/* 四、字段库与字段分类                                                 */
/* ------------------------------------------------------------------ */

/** 查询字段库分类及分类下的字段 */
export function getFieldLibrary() {
  return apiGet<FieldLibraryCategory[]>(FIELD_LIB_BASE);
}

/** 新增字段库分类 */
export function createFieldLibraryCategory(payload: { categoryKey: string; categoryName: string; description?: string }) {
  return apiPost<FieldLibraryCategory>(`${FIELD_LIB_BASE}/categories`, payload);
}

/** 修改字段库分类名称与说明 */
export function updateFieldLibraryCategory(categoryUid: string, payload: { categoryName?: string; description?: string }) {
  return apiPatch<FieldLibraryCategory>(`${FIELD_LIB_BASE}/categories/${categoryUid}`, payload);
}

/** 保存字段库分类拖拽排序（按数组顺序）；契约返回排序后的完整分类数组 */
export function saveFieldLibraryCategoryOrder(categoryUids: string[]) {
  return apiPut<FieldLibraryCategory[]>(`${FIELD_LIB_BASE}/category-order`, { categoryUids });
}

/** 删除字段库分类（分类下仍有字段时后端应拒绝） */
export function deleteFieldLibraryCategory(categoryUid: string) {
  return apiDelete<DeleteResult>(`${FIELD_LIB_BASE}/categories/${categoryUid}`);
}

/* ------------------------------------------------------------------ */
/* 五、字段库字段（字段级 CRUD，供拖拽设计模式消费）                     */
/* ------------------------------------------------------------------ */

/** 新增字段库字段（供拖拽模式和表单模式选择） */
export function createFieldLibraryField(payload: Omit<FieldLibraryField, 'fieldUid'>) {
  return apiPost<FieldLibraryField>(`${FIELD_LIB_BASE}/fields`, payload);
}

/** 修改字段库字段定义（fieldKey / categoryUid 等主键字段不可改） */
export function updateFieldLibraryField(fieldUid: string, payload: Partial<Omit<FieldLibraryField, 'fieldUid' | 'categoryUid'>>) {
  return apiPatch<FieldLibraryField>(`${FIELD_LIB_BASE}/fields/${fieldUid}`, payload);
}

/** 删除字段库字段（不删除已保存到模型中的副本） */
export function deleteFieldLibraryField(fieldUid: string) {
  return apiDelete<DeleteResult>(`${FIELD_LIB_BASE}/fields/${fieldUid}`);
}

/* ------------------------------------------------------------------ */
/* 六、模型创建辅助接口                                                 */
/* ------------------------------------------------------------------ */

/** 模型字段类型下拉选项 */
export function getFieldTypes() {
  return apiGet<FieldTypeOption[]>(FIELD_TYPES_BASE);
}

/**
 * 读取已入库资产 / 资产版本 / 产物的表和字段结构，返回可编辑的模型草稿（不创建模型）。
 * 三个 uid 至少提供一个，由后端校验；此处 typescript 侧用联合类型表达。
 */
export function inspectModelSource(payload: { assetVersionUid: string } | { assetUid: string } | { artifactUid: string }) {
  return apiPost<InspectSourceResult>(`${MODEL_BASE}/inspect-source`, payload);
}

/**
 * 解析用户上传的文件，返回表 / 字段 / 类型等技术信息，用于生成模型草稿（不保存模型）。
 * CONSTRAINT multipart/form-data：不能手动设置 Content-Type，需交给 axios 自动补 boundary；
 * 因此不走 apiPost helper（它只处理 JSON），直接调 request.post 并显式声明 R = ApiResult<T>。
 */
export function inspectModelFile(file: File | Blob) {
  const formData = new FormData();
  formData.append('file', file);
  return request.post<InspectSourceResult, ApiResult<InspectSourceResult>>(`${MODEL_BASE}/inspect-file`, formData, withProductBase());
}

/** 按关键字搜索已入库资产，供模型创建页面选择解析来源 */
export function searchSourceAssets(query: string) {
  return apiGet<SourceAsset[]>(`${SOURCE_BASE}/assets?query=${encodeURIComponent(query)}`);
}

/* ------------------------------------------------------------------ */
/* 七、使用模型执行元数据检查                                           */
/* ------------------------------------------------------------------ */

/**
 * 使用模型检查资产版本的表 / 字段 / 字段类型 / 空间结构。
 * 对应接口文档「六、使用模型执行元数据检查」POST /checks/structure。
 */
export function checkStructure(payload: { modelUid: string; assetVersionUid: string }) {
  return apiPost<StructureCheckResult>(`${CHECK_BASE}/structure`, payload);
}

/**
 * 使用模型检查元数据记录的完整性 / 准确性 / 字段校验规则。
 * scope 取值：completeness / accuracy / full；不传时后端按 full 处理。
 */
export function checkValues(payload: { modelUid: string; assetVersionUid: string; scope?: 'completeness' | 'accuracy' | 'full' }) {
  return apiPost<ValueCheckResult>(`${CHECK_BASE}/values`, payload);
}

/**
 * 查询资产版本的历史元数据检查记录。
 * 未传 assetVersionUid 时后端可返回全部（具体行为以后端为准）。
 */
export function getCheckHistory(params: { assetVersionUid?: string } = {}) {
  const query = params.assetVersionUid ? `?assetVersionUid=${encodeURIComponent(params.assetVersionUid)}` : '';
  return apiGet<MetadataCheckRecord[]>(`${CHECK_BASE}${query}`);
}
