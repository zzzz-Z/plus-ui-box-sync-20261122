/**
 * 地理底图真实接口门面（系统管理 · 电子地图底图）
 *
 * 契约：Apifox 「统一模块/地理底图」，三个端点
 *   - GET    /platform/basemaps            查询底图列表（items + total）
 *   - POST   /platform/basemaps            新增或更新（uid 有值且命中 → 更新，否则新增）
 *   - DELETE /platform/basemaps/{uid}      删除（逻辑删除，uid 需 URL 编码）
 *
 * 文档中路径写作 /api/platform/basemaps（Apifox server = 统一网关 /datamanage）；
 * 本仓 baseURL 已由 withProductBase() 注入 `/dev-api/datamanage/api`，故这里只拼 `/platform/basemaps`。
 *
 * ## 实测校正（2026-11-03，带有效 token + clientid）
 *   - 列表壳字段恒为 `data.items` + `data.total`，所有 query 变体（无分页 / 带分页 / keyword）一致，无 nodes/rows 漂移；
 *   - 不传 pageNum/pageSize 时返回**全量**（适配地图组件无分页调用）；
 *   - 节点实返字段含 `isDefault`（文档 required 未列，实测必返）；
 *   - 新增时 uid 由服务端生成（`bm-` 前缀），前端不传 uid 即新增；
 *   - 错误口径：400 参数错 / 404 底图不存在 / 409 名称冲突，均为 HTTP 状态 + body.code 同步。
 */
import type { Basemap } from '../types';
import { apiDelete, apiGet, apiPost, seg } from '../http';

/** 底图资源路径（不含 baseURL；baseURL 由 withProductBase 注入） */
const BASEMAP_BASE = '/platform/basemaps';

/**
 * 底图类型 → 中文标签。
 * CONSTRAINT 必须覆盖契约枚举全集（xyz/wms/wmts/offline）：
 * 后端 `bm-offline-china` 是 offline 类型，漏映射会让列表在「类型」列直接裸露英文 `offline`。
 */
export const BASEMAP_TYPE_LABELS: Record<Basemap['type'], string> = {
  xyz: 'XYZ',
  wms: 'WMS',
  wmts: 'WMTS',
  offline: '离线'
};

/** 列表查询参数（全部可选；白名单，绝不透传 Table 注入的其它字段） */
export interface BasemapListParams {
  /** 关键字：对名称、服务地址、描述做不区分大小写的模糊匹配 */
  keyword?: string;
  /** 页码，从 1 开始；缺省 1。地图组件不传时等同全量 */
  pageNum?: number;
  /** 每页条数，1~200；缺省 20。不传 pageSize 时返回全量 */
  pageSize?: number;
}

/** 列表响应壳：实测恒为 items + total */
export interface BasemapListResult {
  /** 底图配置数组；离线/默认底图排在最前 */
  items: Basemap[];
  /** 过滤后的总条数 */
  total: number;
}

/**
 * 查询底图列表。
 * WHY 不在这里塞默认 pageSize：地图组件要全量（不传分页），列表页要分页（由 Table 注入），
 * 二者共用同一门面时，默认值会让地图侧被截断到 20 条。
 */
export function listBasemaps(params: BasemapListParams = {}) {
  return apiGet<BasemapListResult>(BASEMAP_BASE, { params });
}

/**
 * 保存载荷的业务输入（前端表单可直接满足）。
 * WHY 单列 Input 类型：调用方只描述业务字段，字段名/可选性由 buildBasemapPayload 统一翻译，
 * 契约变更时只改一个函数。
 */
export interface BasemapInput {
  /** 底图唯一标识；新增时不传，更新时传已有值 */
  uid?: string;
  /** 底图名称（trim 后不能为空，全局唯一） */
  name: string;
  /** 底图类型 */
  type: Basemap['type'];
  /** 服务地址；type≠offline 时必填，XYZ/WMTS 用 {z}/{x}/{y} 占位 */
  url?: string;
  /** 瓦片尺寸 64~1024，缺省 256 */
  tileSize?: number;
  /** WMS 图层 workspace:layer */
  wmsLayers?: string;
  /** WMS 样式 */
  wmsStyles?: string;
  /** WMS 图片格式，缺省 image/png */
  wmsFormat?: string;
  /** WMS 版本，缺省 1.1.1 */
  wmsVersion?: string;
  /** WMS 是否透明背景，缺省 true */
  wmsTransparent?: boolean;
  /** 描述 */
  description?: string;
  /** 是否设为默认底图；true 时服务端会自动取消其它默认 */
  isDefault?: boolean;
}

/** 保存载荷（与契约 requestBody 逐字段对齐，additionalProperties 显式列出，不用 Record 兜底） */
export interface BasemapPayload {
  uid?: string;
  name: string;
  type: Basemap['type'];
  url: string;
  tileSize: number;
  wmsLayers: string;
  wmsStyles: string;
  wmsFormat: string;
  wmsVersion: string;
  wmsTransparent: boolean;
  description: string;
  isDefault?: boolean;
}

/**
 * 底图保存载荷构造器 —— **全仓唯一拼装处**。
 *
 * 职责：
 *   1. 字段白名单投影（不把表单里的临时态/UI 字段漏给后端）；
 *   2. 契约必填与互斥校验（name 非空、type≠offline 时 url 必填）；
 *   3. 缺省值填充（tileSize 256 / wmsFormat image/png / wmsVersion 1.1.1 / wmsTransparent true）；
 *   4. 数值约束（tileSize 收敛到 64~1024）。
 *
 * CONSTRAINT 校验失败抛 Error（不是返回 {code:1}）：
 * 调用方（createDialog 的 submit）以「抛错 = 中断提交」为准，返回值语义只表示业务成功。
 */
export function buildBasemapPayload(input: BasemapInput): BasemapPayload {
  const name = String(input.name ?? '').trim();
  if (!name) throw new Error('请填写图层名称');

  const type = input.type;
  if (!BASEMAP_TYPE_LABELS[type]) throw new Error('底图类型不合法');

  const url = String(input.url ?? '').trim();
  // 离线底图为本地内置矢量，服务地址无意义；其余类型必须有地址
  if (type !== 'offline' && !url) throw new Error('请填写服务地址');

  // 契约 64~1024；越界时收敛到边界而不是报错，避免用户手输 0 / 9999 直接失败
  const rawTileSize = Number(input.tileSize ?? 256);
  const tileSize = Number.isFinite(rawTileSize) ? Math.min(1024, Math.max(64, Math.round(rawTileSize))) : 256;

  return {
    // 空串视为「新增」：契约规定 uid 缺失/空串/未命中都按新增处理
    ...(input.uid ? { uid: input.uid } : {}),
    name,
    type,
    url,
    tileSize,
    wmsLayers: String(input.wmsLayers ?? ''),
    wmsStyles: String(input.wmsStyles ?? ''),
    wmsFormat: (input.wmsFormat || 'image/png').trim(),
    wmsVersion: (input.wmsVersion || '1.1.1').trim(),
    wmsTransparent: input.wmsTransparent !== false,
    description: String(input.description ?? '').trim(),
    // 仅在显式传入时带上，避免覆盖后端已有默认值（契约：不传时更新保留原值、新增为 false）
    ...(input.isDefault === undefined ? {} : { isDefault: input.isDefault })
  };
}

/** 新增或更新底图（服务端按 uid 是否命中判定），返回完整底图对象 */
export function saveBasemap(payload: BasemapPayload) {
  return apiPost<Basemap>(BASEMAP_BASE, payload);
}

/**
 * 删除底图（逻辑删除）。
 * CONSTRAINT uid 必须 URL 编码：uid 由服务端生成（`bm-<uuid>`），理论上安全，
 * 但表单早期数据可能含特殊字符，编码后路径不会因 `/`、`?` 被截断。
 */
export function deleteBasemap(uid: string) {
  return apiDelete<null>(`${BASEMAP_BASE}/${seg(uid)}`);
}
