/**
 * 资源仓库（Repository）接口
 *
 * 路径 /platform/resources/{resourceUid}/repository；baseURL 由 http.ts 的 withProductBase 注入。
 * 契约：source.coop 风格仓库视图，供任务详情页头部 Details 与文件详情使用。
 */
import request from '@/utils/request';
import { apiGet, seg, withProductBase } from '../http';

const RESOURCE_BASE = '/platform/resources';

/**
 * 单条已入库元数据记录（repository 概览口径，只含业务字段）。
 *
 * WHY 挂在 repository 而不是 metadata-browse.ts：这条链路的语义是「仓库概览页读到的元数据快照」，
 * 与 `getResourceMetadataLayer`（按表出 GeoJSON 图层，供地图渲染）是两个资源族 ——
 * 那个返回几何，这个返回**业务属性记录**，字段口径与用途都不同，合并会让两边被对方语义污染。
 */
export interface RepositoryMetadataRecord {
  /** 模型表键 */
  tableKey: string;
  /** 实际 PostgreSQL 物理表名 */
  pgTable: string;
  /** 英文字段键 → 值（值类型混合：string / number / null）；展示时经 fieldLabels 映射中文列名 */
  values: Record<string, unknown>;
  /**
   * 来源元数据文件相对路径（契约 2026-11-10 新增）。
   *
   * 契约写「旧行 source_file 为空时仍返回条目」，**实测该 key 整个不返回**（不是空串）——
   * 后端序列化省略空字段。故标可选，页面缺失即不显示，不做猜测回填。
   */
  sourceFile?: string;
}

/** 仓库概览里的最新已入库元数据（GET /repository 的 `data.metadata`） */
export interface RepositoryMetadata {
  /** 是否有可读元数据表；false 时读 errorCode / errorMessage */
  available: boolean;
  /** 元数据所属数据版本 UID；契约 nullable，实测为 null */
  versionUid?: string | null;
  /** 元数据库 schema */
  metadataSchema?: string;
  /** 元数据记录数 */
  recordCount?: number;
  /** 不可读取时的稳定错误分类 */
  errorCode?: string;
  /** 不可读取时的安全说明 */
  errorMessage?: string;
  /** 英文字段键 → 模型中文标签；页面据此显示中文列名 */
  fieldLabels?: Record<string, string>;
  /** 元数据记录列表；一个资源可以有多条记录 */
  items?: RepositoryMetadataRecord[];
}

/** 仓库详情（对应任务详情页头部 / Details 面板） */
export interface ResourceRepository {
  resourceUid: string;
  name: string;
  description?: string;
  state?: string;
  owner?: string;
  /** private / dept / internal / public */
  visibility?: string;
  category?: { key: string; name: string };
  createdAt?: string;
  updatedAt?: string;
  fileCount?: number;
  totalBytes?: number;
  /** 契约无 createdAt：入库时间不在此对象内，页面不得凭空造一行 */
  latestImport?: { importUid: string; batchName: string; state: string };
  /** 最新已入库元数据（契约 required）；页面按 available 决定渲染记录还是错误说明 */
  metadata?: RepositoryMetadata;
}

/** 仓库内单个文件详情 */
export interface RepositoryFileDetail {
  artifactUid: string;
  name: string;
  relativePath: string;
  mediaType?: string;
  sizeBytes?: number;
  sha256?: string;
  createdAt?: string;
  importUid?: string;
  batchName?: string;
  downloadPath?: string;
}

/** 查询资源仓库详情（GET /platform/resources/{resourceUid}/repository） */
export function getRepository(resourceUid: string) {
  return apiGet<ResourceRepository>(RESOURCE_BASE + '/' + seg(resourceUid) + '/repository');
}

/** 仓库目录条目 */
export interface RepositoryEntry {
  name: string;
  isDir: boolean;
  fileCount?: number;
  sizeBytes?: number;
  artifactUid?: string;
  downloadPath?: string;
  mediaType?: string;
  sha256?: string;
  updatedAt?: string;
}

/** 仓库目录列表结果 */
export interface RepositoryContentsResult {
  entries: RepositoryEntry[];
  path: string;
  hasMore?: boolean;
  nextCursor?: string;
}

/** 查询仓库指定目录内容（GET /platform/resources/{uid}/repository/contents?path=xxx） */
export function listRepositoryContents(resourceUid: string, params: { path?: string; cursor?: string; limit?: number } = {}) {
  return apiGet<RepositoryContentsResult>(RESOURCE_BASE + '/' + seg(resourceUid) + '/repository/contents', { params });
}

/** 查询仓库内文件详情（GET /platform/resources/{resourceUid}/repository/files/{artifactUid}） */
export function getRepositoryFile(resourceUid: string, artifactUid: string) {
  return apiGet<RepositoryFileDetail>(RESOURCE_BASE + '/' + seg(resourceUid) + '/repository/files/' + seg(artifactUid));
}

/**
 * 下载仓库产物文件（GET /platform/artifacts/{artifactUid}/download）。
 *
 * WHY 不走 apiGet：该 helper 期望后端返回 JSON 业务体，而这里是二进制流；
 * request 拦截器对 responseType==='blob' 会直接透传 res.data，故显式声明 responseType。
 */
export function downloadArtifact(artifactUid: string) {
  return request.get<Blob, Blob>('/platform/artifacts/' + seg(artifactUid) + '/download', withProductBase({ responseType: 'blob' }));
}
