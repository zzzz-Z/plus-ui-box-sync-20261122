/**
 * 【已废弃】旧「统一查询 / 报表投递」门面 —— 仅保留向后兼容的再导出
 *
 * ## 为什么整份重写
 *
 * 本文件原有两条路径常量，**实测均不存在（HTTP 404 HTML）**：一条指向旧「统一查询」前缀，
 * 一条指向旧「报表投递」前缀。后端起实际生效的是 `/platform/metadata-records/query...`（见 `01-contract/api-531574257.md`）。
 * 旧载荷形状（`view` + `scope`）也与新契约不兼容：新契约 `additionalProperties: false`，
 * 顶层带 `view` / `scope` / `size` 任一成员都会被拒（字段名是 `page` / `pageSize`）。
 *
 * 保留错路径等于在仓里埋一把「以后谁 import 谁就 404」的枪，故这些常量与函数**全部删除**，
 * 只把正确的门面再导出，让历史 import 路径不会静默失效。
 *
 * ## 迁移指引
 *
 * 旧的两个查询/报表投递函数与新门面的逐条映射、以及被删除的旧路径字面量，
 * 完整记录在 `artifacts/metadata-edit-query/02-impact.md` §二 / §三（不在本文件重复书写，
 * 以免旧标识符在源码里留下可被 grep 命中的残影）。
 *
 * 三个要点：
 * 1. 旧的「范围」入参里 `modelUids` 被当成模型 uid，新契约对应的是**资源 uid**（`resourceUids`），语义不同，勿照搬；
 * 2. 旧「报表投递」概念在新契约里没有对应物 —— 新链路是
 *    `createQueryReportTask` + `getQueryReportTaskStatus` + `downloadQueryReport`；
 * 3. 新门面见 `./metadata-query.ts`。
 */
export {
  buildMetadataQueryPayload,
  createQueryReportTask,
  downloadQueryReport,
  getImportTaskStatus,
  getMetadataQueryOptions,
  getQueryReportTaskStatus,
  importQueryScope,
  applyQuerySelection,
  normalizeQueryState,
  queryMetadataRecords,
  STATE_ALIAS,
  METADATA_QUERY_PAGE_SIZE_DEFAULT,
  METADATA_QUERY_PAGE_SIZE_MAX,
  METADATA_QUERY_PERMISSION_CODE
} from './metadata-query';
export type { MetadataQueryInput, QueryReportInput, SelectionInput } from './metadata-query';
