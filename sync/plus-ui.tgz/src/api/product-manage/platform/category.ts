/**
 * 产品类别真实接口门面
 *
 * 统一前缀 /api/platform/product-categories：baseURL=/api 由 src/utils/request.ts 注入，
 * 此处只拼 /platform/product-categories/...。
 *
 * 与 metadata-api.ts 的差异：
 *   - 产品类别与字段库分类、结构/管理/发现/应用等元数据维度不是同一接口；
 *   - categoryUid 用于修改/删除/指定父级，categoryKey 用于模型关联与推荐，两者不可混用；
 *   - POST/PATCH 响应不重算 categoryPath/modelCount/children，写后必须重查树。
 */
import type { ApiResult } from './metadata';
import request from '@/utils/request';
import { withProductBase } from '../http';

const CATEGORY_BASE = '/platform/product-categories';

/**
 * 本模块的局部 helper。
 * WHY 每个都要透传 config：调用方需要带 headers（如 x-best-effort）等请求级配置。
 * 漏传 config 时 axios 不会报错，只是把它丢掉 —— 表现为「参数传了但请求头里没有」，
 * 排查成本很高（2026-10-24 实测：x-best-effort 一直发不出去，误判为 Vite 缓存问题）。
 */
function apiGet<T>(url: string, config?: object) {
  return request.get<T, ApiResult<T>>(url, withProductBase(config));
}
function apiPost<T, B = unknown>(url: string, body?: B, config?: object) {
  return request.post<T, ApiResult<T>, B>(url, body, withProductBase(config));
}
function apiPatch<T, B = unknown>(url: string, body?: B, config?: object) {
  return request.patch<T, ApiResult<T>, B>(url, body, withProductBase(config));
}
function apiDelete<T>(url: string, config?: object) {
  return request.delete<T, ApiResult<T>>(url, withProductBase(config));
}

/** 类别节点：tree 项含 children，items 项不含；根节点 parentCategoryUid 为空字符串 */
export interface ProductCategory {
  /** 类别唯一标识 */
  categoryUid: string;
  /** 类别编码（小写字母开头，用于模型关联与推荐） */
  categoryKey: string;
  /** 类别名称 */
  categoryName: string;
  /** 类别描述 */
  description?: string;
  /** 类别颜色，#RRGGBB 或空串表示未设置 */
  color?: string;
  /** 上级类别 uid（根节点为空字符串） */
  parentCategoryUid?: string;
  /** 类别完整路径（由服务端计算，写操作后需重查） */
  categoryPath?: string;
  /** 同级排序号（由服务端计算） */
  sortOrder?: number;
  /** 关联的模型数量（由服务端计算） */
  modelCount?: number;
  /** 子类别（仅 tree 项含，items 项不含） */
  children?: ProductCategory[];
}

/** 类别树查询结果（同时返回平铺与树形两种形态） */
export interface ProductCategoryTreeResult {
  /** 平铺列表（不含 children） */
  items: ProductCategory[];
  /** 树形结构（含 children） */
  tree: ProductCategory[];
  /** 类别总数 */
  total: number;
}

/** 新增类别的请求体 */
export interface ProductCategoryPayload {
  /** 类别名称 */
  categoryName: string;
  /** 类别编码（小写字母开头，≤32 位） */
  categoryKey: string;
  /** 上级类别 uid（null 表示创建根类别） */
  parentCategoryUid?: string | null;
  /** 类别描述 */
  description?: string | null;
  /** 类别颜色，#RRGGBB 或空串表示未设置 */
  color?: string | null;
}

/** PATCH 载荷：categoryKey 可不传，若传必须与原值相同 */
export interface ProductCategoryUpdatePayload {
  /** 类别名称 */
  categoryName?: string;
  /** 类别编码（不可改，若传必须与原值相同） */
  categoryKey?: string;
  /** 上级类别 uid（null 表示提升为根类别） */
  parentCategoryUid?: string | null;
  /** 类别描述 */
  description?: string | null;
  /** 类别颜色，#RRGGBB 或空串表示未设置 */
  color?: string | null;
}

/**
 * POST/PATCH 返回的单个类别：data 直接是类别对象，无 category 包装。
 * 契约差异：响应 data 不含 categoryPath/modelCount/children，写后需重查树。
 */
export interface ProductCategoryResponse {
  /** 类别唯一标识 */
  categoryUid: string;
  /** 类别编码 */
  categoryKey: string;
  /** 类别名称 */
  categoryName: string;
  /** 说明；无说明时为空字符串 */
  description: string;
  /** 上级类别 uid；根类别为 null */
  parentCategoryUid: string | null;
  /** 类别颜色，#RRGGBB 或空串 */
  color?: string;
  /** 是否启用；新建后恒为 true */
  enabled: boolean;
  /** 同级排序号 */
  sortOrder: number;
}

/** 逻辑删除结果（类别与元数据模型共用同一形状） */
export interface ProductCategoryDeleteResult {
  /** 被删除的类别 uid */
  uid: string;
  /** 版本号；契约恒为 0（类别无独立并发版本） */
  versionNo: number;
  /** 恒为 true */
  deleted: boolean;
}

/** 按类别查询适用模型的返回项 */
export interface CategoryMatchedModel {
  /** 模型唯一标识 */
  modelUid: string;
  /** 模型编码 */
  modelKey: string;
  /** 模型名称 */
  modelName: string;
  /** 模型描述 */
  description?: string;
  /** 是否为模板模型 */
  isTemplate: boolean;
  /** 模型包含的表数量 */
  tableCount: number;
  /** 模型包含的字段总数 */
  fieldCount: number;
  /** 命中的类别编码（可能来自祖先类别） */
  matchedCategoryKey: string;
}

/** 按类别查询适用模型的结果 */
export interface CategoryMetadataModelsResult {
  /** 查询所用的类别编码（入参回显，契约未声明该字段，保留以兼容不同后端版本） */
  categoryKey?: string;
  /** 适用的模型列表（已按祖先匹配去重） */
  items: CategoryMatchedModel[];
  /** 模型总数 */
  total: number;
  /** 分页游标；本接口无分页，恒为 null */
  nextCursor: string | null;
}

/**
 * 把平铺类别列表按 parentCategoryUid 组装为树。
 *
 * WHY 在平台层组树而非页面：契约 `GET /platform/product-categories` 只返回平铺 `{ items, total }`，
 * 无 tree 字段；页面统一消费 `category.tree`，故在此收口一次组装。
 * CONSTRAINT 根节点判定：parentCategoryUid 为 null、空串或未在 items 中出现。
 */
function buildCategoryTree(flatList: ProductCategory[]): ProductCategory[] {
  const byUid = new Map<string, ProductCategory>();
  const roots: ProductCategory[] = [];
  for (const item of flatList) byUid.set(item.categoryUid, { ...item, children: [] });
  for (const item of flatList) {
    const node = byUid.get(item.categoryUid)!;
    const pid = item.parentCategoryUid;
    if (!pid || pid === '' || !byUid.has(pid)) {
      roots.push(node);
    } else {
      (byUid.get(pid)!.children ??= []).push(node);
    }
  }
  return roots;
}

/** 查询产品类别树：契约只返回平铺 { items, total }，此处组树后输出 { items, tree, total }
 *  config 可传 headers 等；传 { headers: { 'x-best-effort': '1' } } 时 401 不弹全局会话过期框 */
export async function getProductCategoryTree(config?: object) {
  const res = await apiGet<ProductCategoryListResult>(CATEGORY_BASE, config);
  const items = (res.code === 0 ? (res.data?.items ?? []) : []) as unknown as ProductCategory[];
  const tree = buildCategoryTree(items);
  return {
    code: res.code,
    message: res.message,
    data: { items, tree, total: items.length }
  } as unknown as ApiResult<ProductCategoryTreeResult>;
}

/** 类别颜色格式：空串/null 表示未设置，非空必须是 #RRGGBB */
export const CATEGORY_COLOR_PATTERN = /^#[0-9a-fA-F]{6}$/;

/** 校验类别颜色：允许空值；返回 null 表示通过，否则返回错误文案（与后端一致） */
export function validateCategoryColor(color?: string | null): string | null {
  if (color === undefined || color === null || color === '') return null;
  return CATEGORY_COLOR_PATTERN.test(color) ? null : 'color 必须是 #RRGGBB 格式';
}

/** 新增产品类别（根或子）；排序值由服务端计算，成功后应重查树 */
export function createProductCategory(payload: ProductCategoryPayload) {
  return apiPost<ProductCategoryResponse>(CATEGORY_BASE, payload);
}

/** 修改产品类别名称/说明/父级；categoryKey 不可改，若传必须与原值相同 */
export function updateProductCategory(categoryUid: string, payload: ProductCategoryUpdatePayload) {
  return apiPatch<ProductCategoryResponse>(`${CATEGORY_BASE}/${categoryUid}`, payload);
}

/** 逻辑删除类别及其全部后代，并解除模型关联；必须显式携带 confirm:true */
export function deleteProductCategory(categoryUid: string) {
  return apiDelete<ProductCategoryDeleteResult>(`${CATEGORY_BASE}/${categoryUid}`, { data: { confirm: true } });
}

/**
 * 按类别编码查询适用模型（含祖先匹配、去重、含模板）。
 * CONSTRAINT 路径参数是 categoryKey，不是 categoryUid；无匹配返回空 items。
 */
export function getMetadataModelsByCategoryKey(categoryKey: string) {
  return apiGet<CategoryMetadataModelsResult>(`${CATEGORY_BASE}/${encodeURIComponent(categoryKey)}/metadata-models`);
}
/* ------------------------------------------------------------------ */
/* v5 契约 api-design-v5-20261008：已启用未删除产品类别平铺列表          */
/* ------------------------------------------------------------------ */

/**
 * v5 契约定义的平铺列表项。
 *
 * 与树形 ProductCategory 的差异：
 *   - 必含 enabled（启用状态），服务端已过滤未启用与已删除项；
 *   - parentCategoryUid 必填（根为 null），不接受省略；
 *   - 无 children/categoryPath/modelCount，层级由调用方按 parentCategoryUid 组树。
 */
export interface ProductCategoryListItem {
  /** 类别唯一标识 */
  categoryUid: string;
  /** 类别编码 */
  categoryKey: string;
  /** 类别名称 */
  categoryName: string;
  /** 上级类别 uid（根为 null，必填） */
  parentCategoryUid: string | null;
  /** 类别描述 */
  description: string;
  /** 类别颜色，#RRGGBB 或空串 */
  color?: string;
  /** 是否启用（服务端已过滤未启用与已删除项） */
  enabled: boolean;
  /** 同级排序号 */
  sortOrder: number;
}

/** v5 契约的类别平铺列表结果 */
export interface ProductCategoryListResult {
  /** 平铺列表（不含 children，层级由 parentCategoryUid 组装） */
  items: ProductCategoryListItem[];
  /** 类别总数 */
  total: number;
}

/**
 * 查询已启用未删除产品类别平铺列表（GET /api/platform/product-categories）。
 *
 * 与 getProductCategoryTree 同端点同方法，差异仅返回口径：本函数严格按 v5 契约
 * 返回 { items, total }，不返回顶层 tree；需要树形结构时调用方按 parentCategoryUid 组装。
 * 契约未定义分页/搜索参数，前端本地过滤；只读、可安全重放。
 */
export function listProductCategories(config?: object) {
  return apiGet<ProductCategoryListResult>(CATEGORY_BASE, config);
}
