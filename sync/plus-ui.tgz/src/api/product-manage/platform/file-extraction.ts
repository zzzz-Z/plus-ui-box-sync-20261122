/**
 * 数据提取接口：资源树 / 预览 / 创建 / 启动 / 查询 / 列表 / 暂停恢复取消重试
 * 契约快照：.dsh/artifacts/data-extraction/01-contract/（Apifox released docId 538395xxx）
 *
 * 关键口径（2026-11-19 契约核对）：
 * - 创建四选一 previewToken / resources / items / requirementList（**没有 uid**）；
 *   交付目标 target{storageUid,path} 与 targetPath 二选一，都为空只生成 ZIP。
 * - 预览支持 uid（单 UUID）/ resources / items / requirementList + archiveStrategy；
 *   预览阶段不收 target/targetPath。
 * - 后端 operationStatus 全中文，前端不映射英文枚举。
 * - 状态四态：等待提取 / 正在提取 / 完成提取 / 提取错误。
 */
import { apiDelete, apiGet, apiPatch, apiPost, PRODUCT_BASE_URL, seg, type Paged } from '../http';
import { globalHeaders } from '@/utils/request';

// 后端实际挂载路径为 data-extractions；历史文档中的 file-extractions 已 404（drogon）。
const EXTRACTION_BASE = '/platform/data-extractions';

export interface ResourceTreeNode {
  uid: string;
  nodeType: 'category' | 'task' | 'folder' | 'file';
  name: string;
  path?: string;
  categoryUid?: string;
  importUid?: string;
  artifactUid?: string;
  sizeBytes?: number;
  mimeType?: string;
  hasChildren: boolean;
  downloadUrl?: string;
}

export interface ResourceTreeResult {
  /** 契约不一致：文档写 items，实测是 nodes；两者都兜 */
  items?: ResourceTreeNode[];
  nodes?: ResourceTreeNode[];
  hasMore?: boolean;
  nextCursor?: string;
  parent?: { nodeType: string; path: string; uid: string };
}

export interface ResourceTreeParams {
  type?: 'import';
  parentType?: 'category' | 'task' | 'folder' | '';
  /** 必须是 UUID；根层不传 */
  parentUid?: string;
  path?: string;
  cursor?: string;
  limit?: number;
  onlyWithTasks?: boolean;
  /** 默认 true 时逐节点带图层层级、极慢（1.9-2.3s）；提取只需 uid/name/结构，默认关闭提速 */
  includeLayers?: boolean;
}

/** 数据浏览树（懒加载，每次只取下一层） */
export function getImportTree(params: ResourceTreeParams = {}) {
  return apiGet<ResourceTreeResult>('/platform/resources/tree', { params: { type: 'import', includeLayers: false, ...params } });
}

/* -------- 勾选清单 -------- */

export interface ExtractionItem {
  importUid: string;
  paths: string[];
}

/** 跨资源选择项（契约 create/preview 的 resources[] 元素） */
export interface ExtractionResource {
  resourceUid: string;
  versionUid?: string;
  selectAll?: boolean;
  fileUids?: string[];
  paths?: string[];
}

/** 已登记共享目录目标；与 targetPath 互斥 */
export interface ExtractionTarget {
  storageUid: string;
  /** 登记根内相对目录，可为空 */
  path?: string;
}

/** 无目标时的 ZIP 生成策略；目标目录交付不能指定 */
export type ArchiveStrategy = 'prepared' | 'live';

export interface ExtractionCategoryRef {
  categoryUid: string;
  categoryName: string;
}

/** 预览结果里的单个文件条目 */
export interface ExtractionPreviewFile {
  fileUid: string;
  relativePath: string;
  displayPath: string;
  sizeBytes: number;
  sha256: string;
}

/** 预览结果里的单个资源分组（含该资源展开出的文件清单） */
export interface ExtractionPreviewItem {
  resourceUid: string;
  resourceName?: string;
  resourceDir?: string;
  sourceKind?: string;
  selectAll: boolean;
  versionNo?: number;
  versionUid?: string;
  categoryUid?: string;
  categoryName?: string;
  fileCount: number;
  paths?: string[];
  files: ExtractionPreviewFile[];
}

export interface ExtractionPreviewResult {
  previewToken: string;
  archiveStrategy: ArchiveStrategy;
  fileCount: number;
  sourceBytes: number;
  categories: ExtractionCategoryRef[];
  items: ExtractionPreviewItem[];
  expiresAt: string;
}

/** 预览载荷：四选一（uid / resources / items / requirementList）+ 可选 ZIP 策略 */
export interface ExtractionPreviewPayload {
  /** 单 UUID：资源整选 / 任务 / 文件 / 类别 UID */
  uid?: string;
  resources?: ExtractionResource[];
  items?: ExtractionItem[];
  requirementList?: string;
  archiveStrategy?: ArchiveStrategy;
}

/**
 * 预览：返回一次性 token 与文件数/类别。
 *
 * @param config 透传 axios 配置。勾选资源探测文件列表时传 { headers: { 'x-best-effort': '1' } }，
 *   让「资源无可用文件」的 422 不弹全局错误 toast，由调用方自行静默跳过。
 */
export function previewExtraction(payload: ExtractionPreviewPayload, config?: object) {
  return apiPost<ExtractionPreviewResult, ExtractionPreviewPayload>(EXTRACTION_BASE + '/preview', payload, config);
}

/* -------- 创建 -------- */

export type ExtractionPriority = 'high' | 'medium' | 'low';

export interface CreateExtractionPayload {
  /** 可选，缺省“数据提取”，仅展示/ZIP 文件名，不是交付目录 */
  taskName?: string;
  previewToken?: string;
  resources?: ExtractionResource[];
  items?: ExtractionItem[];
  requirementList?: string;
  /** 已登记共享目录目标；与 targetPath 互斥 */
  target?: ExtractionTarget;
  /** 完整绝对/共享路径；与 target 互斥 */
  targetPath?: string;
  /** 无目标时的 ZIP 策略 */
  archiveStrategy?: ArchiveStrategy;
  priority?: ExtractionPriority;
  requestId?: string;
}

export interface ExtractionProgress {
  completed: number;
  total: number;
  percent: number;
  stage: string;
  /** 契约新增：阶段的中文描述 */
  stageText?: string;
}

export interface ExtractionArtifact {
  name: string;
  sizeBytes: number;
  sha256: string;
}

export interface ExtractionResult {
  archiveName: string;
  fileCount: number;
  sourceBytes: number;
  downloadUrl: string;
  artifacts: ExtractionArtifact[];
  delivery: ExtractionDelivery | null;
}

export interface ExtractionDelivery {
  relativePath: string;
  name: string;
  sizeBytes: number;
  sha256: string;
  status: string;
  deliveredAt: string;
  targetPath: string;
}

/** 创建返回值（HTTP 202）：含各控制地址 */
export interface CreateExtractionResult {
  taskUid: string;
  state: string;
  eventsUrl?: string;
  startUrl?: string;
  cancelUrl?: string;
  pauseUrl?: string;
  resumeUrl?: string;
  retryUrl?: string;
}

/** 创建提取任务（previewToken / resources / items / requirementList 四选一） */
export function createExtraction(payload: CreateExtractionPayload) {
  return apiPost<CreateExtractionResult, CreateExtractionPayload>(EXTRACTION_BASE, payload);
}

/* -------- 详情 / 列表 -------- */

export interface ExtractionTaskDetail {
  taskUid: string;
  taskName: string;
  state: string;
  operationStatus: string;
  progress?: ExtractionProgress;
  fileCount: number;
  sourceBytes: number;
  categories: ExtractionCategoryRef[];
  errorCount: number;
  result: ExtractionResult | null;
  /** archive=ZIP 下载；tree=目标目录投递 */
  deliveryMode?: 'archive' | 'tree';
  archiveStrategy?: ArchiveStrategy;
  target?: ExtractionTarget | null;
  /** tree 交付回执；ZIP 为 null */
  delivery: ExtractionDelivery | null;
  /** 成功后才返回，勿自行拼接 */
  downloadUrl?: string;
  eventsUrl?: string;
  items?: unknown[];
  errors?: unknown[];
}

/** 查询单个提取任务详情（用于轮询 / SSE 兜底） */
export function getExtraction(taskUid: string) {
  return apiGet<ExtractionTaskDetail>(EXTRACTION_BASE + '/' + seg(taskUid));
}

export interface ExtractionListParams {
  categoryUid?: string;
  state?: string;
  page?: number;
  pageSize?: number;
}

export interface ExtractionListItem {
  taskUid: string;
  taskName: string;
  state: string;
  operationStatus: string;
  categories: ExtractionCategoryRef[];
  fileCount: number;
  sourceBytes: number;
  targetPath: string | null;
  createdAt: string;
  finishedAt: string | null;
  errorCount: number;
}

/** 任务列表 */
export function listExtractions(params: ExtractionListParams = {}) {
  return apiGet<Paged<ExtractionListItem>>(EXTRACTION_BASE, { params });
}

/* -------- 状态操作 -------- */

export function startExtraction(taskUid: string) {
  return apiPost<ExtractionTaskDetail>(EXTRACTION_BASE + '/' + seg(taskUid) + '/start');
}

export function pauseExtraction(taskUid: string) {
  return apiPost<ExtractionTaskDetail>(EXTRACTION_BASE + '/' + seg(taskUid) + '/pause');
}

export function resumeExtraction(taskUid: string) {
  return apiPost<ExtractionTaskDetail>(EXTRACTION_BASE + '/' + seg(taskUid) + '/resume');
}

export function cancelExtraction(taskUid: string) {
  return apiPost<ExtractionTaskDetail>(EXTRACTION_BASE + '/' + seg(taskUid) + '/cancel');
}

/** 删除提取任务（仅终态：完成/失败/取消） */
export function deleteExtraction(taskUid: string) {
  return apiDelete<{ deleted: boolean; message: string; taskUid: string }>(EXTRACTION_BASE + '/' + seg(taskUid));
}

export function retryExtraction(taskUid: string) {
  return apiPost<ExtractionTaskDetail>(EXTRACTION_BASE + '/' + seg(taskUid) + '/retry');
}

/* -------- 调整优先级（契约 538395398） -------- */

/**
 * 调整排队中提取任务的优先级，不改变任务状态、已冻结的文件清单和交付目标。
 * 409 = 版本已变化或当前状态不允许调整（expectedVersion CAS）。
 */
export interface UpdateExtractionPriorityPayload {
  /** high / medium / low */
  priority: ExtractionPriority;
  /** 统一任务版本 CAS；可选 */
  expectedVersion?: number;
}

export interface UpdateExtractionPriorityResult {
  taskUid: string;
  priority: ExtractionPriority;
  version: number;
}

export function updateExtractionPriority(taskUid: string, payload: UpdateExtractionPriorityPayload) {
  return apiPatch<UpdateExtractionPriorityResult, UpdateExtractionPriorityPayload>(EXTRACTION_BASE + '/' + seg(taskUid), payload);
}

/* -------- 提取错误查询 / 报表（契约 538395414 / 538395416） -------- */

/** 单条提取错误。定位字段可能为空；不得把空位置伪造成 filePath。 */
export interface ExtractionError {
  errorUid: string;
  code?: string;
  message?: string;
  filePath?: string | null;
  repairToken?: string | null;
  /** 后端可能给出额外位置字段（资源/图层/行列等），仅原样展示 */
  location?: string | null;
  [key: string]: unknown;
}

export interface ExtractionErrorListParams {
  page?: number;
  pageSize?: number;
}

/** 分页查询单个提取任务的错误记录；503 = 错误账本暂不可用。 */
export function getExtractionErrors(taskUid: string, params: ExtractionErrorListParams = {}) {
  return apiGet<Paged<ExtractionError>>(EXTRACTION_BASE + '/' + seg(taskUid) + '/errors', { params });
}

export interface ExtractionErrorReportSummary {
  taskCount?: number;
  errorCount?: number;
  byCode?: Record<string, number>;
  [key: string]: unknown;
}

export interface ExtractionErrorReport {
  summary: ExtractionErrorReportSummary;
  items: unknown[];
}

/** 全局提取错误报表（按任务聚合）；单任务明细请用 getExtractionErrors。 */
export function getExtractionErrorReport(params: ExtractionErrorListParams = {}) {
  return apiGet<ExtractionErrorReport>(EXTRACTION_BASE + '/errors/report', { params });
}

/* -------- 提取专用实时订阅 SSE（契约 538395383） -------- */

/**
 * 提取任务专用 SSE 端点：`GET /platform/data-extractions/{taskUid}/events`。
 *
 * WHY 独立实现而非复用通用任务 SSE：
 * - 端点不同（本端点在 data-extractions 下，通用任务在 /platform/tasks 下）；
 * - 事件名不同（ready / selection / progress / done，非 task.progress / task.terminal）；
 * - 终态事件是 `done`（通用任务用 task.terminal）；
 * - `selection` 携带资源空间范围 resourceExtents，是地图模式矩形着色的数据源。
 *
 * CONSTRAINT 原生 EventSource 不能带 Authorization/clientid 头，故用 fetch + ReadableStream 解析。
 */
export type ExtractionEventName = 'ready' | 'selection' | 'progress' | 'done' | string;

export interface ExtractionEventPayload {
  event: ExtractionEventName;
  id?: string;
  data: any;
}

export interface ExtractionEventHandlers {
  onEvent?: (payload: ExtractionEventPayload) => void;
  /** `done` 是唯一终止事件；收到后连接会关闭 */
  onDone?: (payload: ExtractionEventPayload) => void;
  onError?: (error: unknown) => void;
}

export function buildExtractionEventsUrl(taskUid: string) {
  return `${PRODUCT_BASE_URL}${EXTRACTION_BASE}/${seg(taskUid)}/events`;
}

export async function subscribeExtractionEvents(taskUid: string, handlers: ExtractionEventHandlers, signal?: AbortSignal): Promise<void> {
  try {
    const headers: Record<string, string> = { ...(globalHeaders() as Record<string, string>), Accept: 'text/event-stream' };
    const res = await fetch(buildExtractionEventsUrl(taskUid), { headers, signal });
    if (!res.ok || !res.body) {
      handlers.onError?.(new Error(`提取事件订阅失败：HTTP ${res.status}`));
      return;
    }
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    while (true) {
      const { value, done: readerDone } = await reader.read();
      if (readerDone) break;
      buffer += decoder.decode(value, { stream: true });
      let sep = buffer.indexOf('\n\n');
      while (sep >= 0) {
        const raw = buffer.slice(0, sep);
        buffer = buffer.slice(sep + 2);
        sep = buffer.indexOf('\n\n');
        if (!raw || raw.startsWith(':')) continue;
        let eventName = 'message';
        let eventId: string | undefined;
        const dataLines: string[] = [];
        for (const line of raw.split('\n')) {
          if (line.startsWith('id:')) eventId = line.slice(3).trim();
          else if (line.startsWith('event:')) eventName = line.slice(6).trim();
          else if (line.startsWith('data:')) dataLines.push(line.slice(5).replace(/^ /, ''));
        }
        if (!dataLines.length) continue;
        const rawData = dataLines.join('\n');
        let parsed: unknown = rawData;
        try {
          parsed = JSON.parse(rawData);
        } catch {
          /* data 契约是 JSON；解析失败保留原文，不中断流 */
        }
        const payload: ExtractionEventPayload = { event: eventName, id: eventId, data: parsed };
        handlers.onEvent?.(payload);
        if (eventName === 'done') handlers.onDone?.(payload);
      }
    }
  } catch (error) {
    handlers.onError?.(error);
  }
}

/* -------- 载荷构造 -------- */

/**
 * 构造创建载荷并做契约校验：四选一 + 交付目标互斥。
 *
 * WHY 单独抽出：createExtraction 的数据源（previewToken/resources/items/requirementList）
 * 与交付目标（target/targetPath）在弹窗、Tab 表单等多处都会拼，契约变更易漏改
 * （本仓历史踩过「一处改一处漏」400）。调用方只传业务输入，字段拼装与校验在此收口。
 *
 * tsconfig 关闭 strictNullChecks 时窄化不生效，返回 { ok, payload?, message? } 而非判别联合。
 */
export interface BuildExtractionPayloadInput {
  taskName?: string | null;
  previewToken?: string | null;
  resources?: ExtractionResource[] | null;
  items?: ExtractionItem[] | null;
  requirementList?: string | null;
  target?: ExtractionTarget | null;
  targetPath?: string | null;
  archiveStrategy?: ArchiveStrategy | null;
  priority?: ExtractionPriority | null;
  requestId?: string | null;
}

export interface BuildExtractionPayloadResult {
  ok: boolean;
  payload?: CreateExtractionPayload;
  message?: string;
}

export function buildCreateExtractionPayload(input: BuildExtractionPayloadInput): BuildExtractionPayloadResult {
  const taskName = String(input.taskName ?? '').trim();
  if (taskName.length > 200) return { ok: false, message: '任务名不能超过 200 字符' };

  const hasToken = !!input.previewToken;
  const hasResources = Array.isArray(input.resources) && input.resources.length > 0;
  const hasItems = Array.isArray(input.items) && input.items.length > 0;
  const hasReq = !!(input.requirementList && input.requirementList.trim());
  const sourceCount = (hasToken ? 1 : 0) + (hasResources ? 1 : 0) + (hasItems ? 1 : 0) + (hasReq ? 1 : 0);
  if (sourceCount === 0) return { ok: false, message: '请先选择要提取的节点' };
  if (sourceCount > 1) return { ok: false, message: 'previewToken / resources / items / requirementList 只能四选一' };

  // 交付目标二选一：两者都为空只生成 ZIP；同时给出则非法
  const hasTarget = !!input.target && !!input.target.storageUid;
  const hasTargetPath = !!(input.targetPath && input.targetPath.trim());
  if (hasTarget && hasTargetPath) return { ok: false, message: '共享目录目标与完整路径只能二选一' };

  const payload: CreateExtractionPayload = {};
  if (taskName) payload.taskName = taskName;
  if (hasToken) payload.previewToken = input.previewToken as string;
  if (hasResources) payload.resources = input.resources as ExtractionResource[];
  if (hasItems) payload.items = input.items as ExtractionItem[];
  if (hasReq) payload.requirementList = input.requirementList as string;
  if (hasTarget) payload.target = input.target as ExtractionTarget;
  if (hasTargetPath) payload.targetPath = input.targetPath as string;
  // 目标目录交付不能显式指定 archiveStrategy
  if (input.archiveStrategy && !hasTarget && !hasTargetPath) payload.archiveStrategy = input.archiveStrategy;
  if (input.priority) payload.priority = input.priority;
  if (input.requestId) payload.requestId = input.requestId;
  return { ok: true, payload };
}

/* -------- 在线 ZIP 下载（契约 538395419） -------- */

/** 从服务端返回的 downloadUrl 解析出的归档引用 */
export interface ExtractionArchiveRef {
  taskUid: string;
  /** live 归档 generation，必须来自 downloadUrl */
  generation: string;
  /** 绑定令牌，必须来自 downloadUrl */
  token: string;
}

/**
 * 解析详情返回的 downloadUrl，提取 generation / token。
 *
 * 契约要求 generation 与 token 都必须来自服务端地址，禁止前端自行生成或拼接这两项。
 * 这里只做读取：兼容绝对地址与各种相对前缀，取 archive/live/{generation} 段与 ?token= 查询参数。
 * 解析失败（缺 generation 或 token）返回 null，由调用方降级为「暂无在线下载」。
 */
export function parseExtractionArchiveUrl(downloadUrl: string | null | undefined, fallbackTaskUid?: string): ExtractionArchiveRef | null {
  if (!downloadUrl || !downloadUrl.trim()) return null;
  try {
    const raw = downloadUrl.trim();
    // 相对地址补一个占位 host，仅用于 URL 解析；不会作为实际请求地址
    const probe = /^https?:\/\//i.test(raw) ? raw : 'http://archive.local' + (raw.startsWith('/') ? raw : '/' + raw);
    const u = new URL(probe);
    const parts = u.pathname.split('/').filter(Boolean);
    const liveIdx = parts.lastIndexOf('live');
    const generation = liveIdx >= 0 ? decodeURIComponent(parts[liveIdx + 1] || '') : '';
    const token = u.searchParams.get('token') || '';
    const taskUid = liveIdx >= 2 ? decodeURIComponent(parts[liveIdx - 2] || '') : fallbackTaskUid || '';
    if (!generation || !token) return null;
    return { taskUid: taskUid || fallbackTaskUid || '', generation, token };
  } catch {
    return null;
  }
}

export interface DownloadArchiveOptions {
  /** 单段字节范围，如 bytes=0-1048575 */
  range?: string;
  /** Range 的条件 ETag */
  ifRange?: string;
  signal?: AbortSignal;
}

export interface ArchiveDownloadResult {
  blob: Blob;
  /** 200 完整流 / 206 部分内容 */
  status: number;
  contentRange?: string | null;
  acceptRanges?: string | null;
  /** 归档总字节数（从 Content-Range 解析） */
  total?: number | null;
}

/**
 * 在线 ZIP 下载：fetch + blob，携带 clientid / Authorization 头。
 *
 * 契约（538395419）说明浏览器下载需带网关客户端标识，window.open 无法附带自定义头，
 * 因此走 fetch；generation / token 由调用方从详情 downloadUrl 通过 parseExtractionArchiveUrl 取得。
 * 200=完整归档流，206=Range 部分内容；416/503/404 分别给出明确错误。
 */
export async function downloadExtractionArchive(ref: ExtractionArchiveRef, options: DownloadArchiveOptions = {}): Promise<ArchiveDownloadResult> {
  const url = `${PRODUCT_BASE_URL}${EXTRACTION_BASE}/${seg(ref.taskUid)}/archive/live/${encodeURIComponent(ref.generation)}?token=${encodeURIComponent(ref.token)}`;
  const headers: Record<string, string> = { ...globalHeaders() };
  if (options.range) headers['Range'] = options.range;
  if (options.ifRange) headers['If-Range'] = options.ifRange;

  const resp = await fetch(url, { headers, signal: options.signal });
  if (resp.status === 416) throw new Error('下载范围超出归档长度');
  if (resp.status === 503) throw new Error('归档尚未生成或下载暂不可用');
  if (resp.status === 404) throw new Error('任务或归档不存在');
  if (resp.status !== 200 && resp.status !== 206) throw new Error('下载失败，HTTP ' + resp.status);

  const blob = await resp.blob();
  const cr = resp.headers.get('content-range');
  const total = cr && cr.includes('/') ? Number(cr.split('/').pop()) : NaN;
  return {
    blob,
    status: resp.status,
    contentRange: cr,
    acceptRanges: resp.headers.get('accept-ranges'),
    total: Number.isFinite(total) ? total : null
  };
}
