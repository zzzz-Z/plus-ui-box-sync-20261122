/**
 * 统一 OAuth 鉴权接口
 *
 * 路径以 /platform/oauth 开头，baseURL 由 request.ts 注入。
 * 与 src/api/system/oauth 的区别：后者是旧 OAuth 客户端 CRUD（listOauth/getOauth 等），
 * 本文件是统一身份鉴权，不依赖本地 tb_user；令牌、授权码、原始登录态不得落库或打日志。
 */
import type { ApiResult } from '../http';
import { apiGet, apiPost } from '../http';

const OAUTH_BASE = '/platform/oauth';

/** 受控 userinfo 查证后的身份；不含 password 与原始凭据 */
export interface AuthUser {
  /** 用户唯一标识 */
  userUid: string;
  /** 登录名 */
  userName?: string;
  /** 显示名 */
  displayName?: string;
  /** 角色列表 */
  roles?: string[];
}

/** 令牌对；refreshToken 仅由刷新接口返回 */
export interface TokenPair {
  /** 访问令牌 */
  accessToken: string;
  /** 刷新令牌（仅刷新接口返回） */
  refreshToken?: string;
  /** 令牌有效期（秒） */
  expiresIn?: number;
  /** 令牌类型（通常为 Bearer） */
  tokenType?: string;
}

/** 发起统一 OAuth 登录；返回授权地址由调用方跳转，不接受 returnTo 等未知 query */
export function beginOAuthLogin() {
  return apiPost<{ authorizeUrl: string }>(OAUTH_BASE + '/authorize');
}

/** 处理授权回调；无效 state 400，过期或已用 409，error 优先于 code */
export function handleOAuthCallback(params: { code?: string; state: string; error?: string; errorDescription?: string }) {
  return apiGet<TokenPair & { user: AuthUser }>(OAUTH_BASE + '/callback', { params });
}

/** 刷新统一令牌；请求体仅含 refreshToken，上游调用由服务端适配 */
export function refreshOAuthToken(refreshToken: string) {
  return apiPost<TokenPair, { refreshToken: string }>(OAUTH_BASE + '/refresh', { refreshToken });
}

/** 撤销当前访问令牌；仅作用于当前 access token，不承诺注销 refresh 或其他平台会话 */
export function revokeOAuthToken() {
  return apiPost<null>(OAUTH_BASE + '/revoke');
}

/** 查证当前统一身份；缺 userId 401，非法身份 502 */
export function getCurrentAuthUser() {
  return apiGet<AuthUser>(OAUTH_BASE + '/userinfo');
}
