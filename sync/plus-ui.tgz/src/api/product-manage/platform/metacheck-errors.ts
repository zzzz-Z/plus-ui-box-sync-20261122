/**
 * 元数据检查 / 数据入库的稳定错误码判定（T6a 契约 2026-11-08）
 *
 * WHY 单独成文件：`request.ts` 的响应拦截器对所有 4xx 统一 `ElMessage.error(body.message)`，
 * 不消费 `errorCode`；页面想「按错误码分派动作」（回检查页 / 重新选文件 / 打开原因输入）
 * 只能自己从异常对象里挖。挖法有三条可达路径，散落在各页面必然漂移：
 *   1. `error.response.data.data.errorCode`（HTTP 4xx 真实形态，契约 409 示例即此结构）；
 *   2. `error.response.data.errorCode`（部分包装层把明细提到 body 顶层）；
 *   3. `error.data.errorCode` / `error.errorCode`（已被拦截器解包或自定义 reject 时）。
 *
 * CONSTRAINT 契约把部分错误写成**中文短语**（「直接入库原因必填」等），英文稳定码只有
 * SOURCE_CHANGED_SINCE_CHECK / CHECK_BINDING_MISMATCH / CHECK_NOT_FOUND 三个。
 * 因此判定同时接受「英文 errorCode 精确匹配」与「中文短语出现在 errorCode 或 message 中」，
 * 再统一归一成本文件的内部码，页面只需对内部码分派。
 */

/**
 * 归一后的错误码。
 *
 * 英文三个是契约 errorCode 原值直接透传；其余中文短语按语义归一为稳定内部码
 * （后端若改文案只影响识别表，不影响页面分支）。
 *
 * CONSTRAINT DIRECT_INGEST_REASON_* 自 2026-11-11 契约起已无生产来源（direct 不再要求原因），
 * 保留是因为历史批次的执行期错误账本仍可能出现这两条短语，展示层要能识别。
 */
export type MetacheckErrorCode =
  | 'SOURCE_CHANGED_SINCE_CHECK'
  | 'CHECK_BINDING_MISMATCH'
  | 'CHECK_NOT_FOUND'
  | 'DIRECT_INGEST_REASON_REQUIRED'
  | 'DIRECT_INGEST_REASON_INVALID'
  | 'DIRECT_INGEST_STRATEGY_CONFLICT'
  | 'DIRECT_INGEST_CATEGORY_MISMATCH'
  | 'DIRECT_INGEST_SOURCE_UNAVAILABLE'
  | 'DIRECT_INGEST_FILES_UNAVAILABLE'
  | 'DIRECT_INGEST_MODEL_UNAVAILABLE'
  | 'IMPORT_FILES_INVALID'
  | 'IMPORT_CHECK_POLICY_NOT_PASSED'
  | 'IMPORT_CHECK_POLICY_INVALID'
  | 'IMPORT_CHECK_UID_REQUIRED'
  | 'IMPORT_IDEMPOTENT_REPLAY'
  | 'METADATA_BACKFILL_NOT_ALLOWED'
  /* -------- 2026-11-12 后端改定新增的中文 errorCode -------- */
  | 'IMPORT_FILES_CONFLICT'
  | 'DATA_SOURCE_TYPE_INVALID'
  | 'DATA_SOURCE_UNAVAILABLE'
  | 'DATA_SOURCE_ROOT_UNAVAILABLE'
  | 'DATA_FILE_NOT_FOUND'
  | 'DATA_FILE_LIST_EMPTY'
  | 'DATA_FILE_PATH_INVALID'
  | 'DATA_FILE_DIGEST_MISMATCH'
  | 'DATA_UPLOAD_SESSION_NOT_FOUND'
  | 'DATA_UPLOAD_SESSION_EXPIRED'
  | 'DATA_UPLOAD_NOT_COMPLETED'
  | 'OBJECT_STORAGE_UNAVAILABLE'
  | 'METADATA_FILE_PATH_INVALID'
  | 'IMPORT_CHECK_RECORD_UNAVAILABLE';

/**
 * 页面应执行的动作。
 *
 * - recheck：回检查页对新选文件重新检查（来源已变 / 绑定不一致 / 检查单失效）；
 * - pickFiles：重选文件；
 * - enterReason：历史 direct 批次的原因缺失/无效（新契约已无此校验，仅历史兼容）；
 * - clearCheckUid：清掉 checkUid 后重试（策略字段冲突）；
 * - pickCategory：回类别选择；
 * - checkSource：检查本地共享 / 路径可用性；
 * - pickModel：先配置或选择模型（或改走正常检查）；
 * - refresh：刷新详情后重试（幂等重放 / 补录状态不允许）。
 */
export type MetacheckErrorAction =
  | 'recheck'
  | 'pickFiles'
  | 'enterReason'
  | 'clearCheckUid'
  | 'pickCategory'
  | 'checkSource'
  | 'pickModel'
  | 'refresh';

/** 中文短语识别表；顺序优先「更长更具体」的短语，避免「直接入库原因」吞掉「直接入库原因无效」 */
const CHINESE_CODE_TABLE: Array<{ phrase: string; code: MetacheckErrorCode }> = [
  { phrase: '直接入库原因无效', code: 'DIRECT_INGEST_REASON_INVALID' },
  { phrase: '直接入库原因必填', code: 'DIRECT_INGEST_REASON_REQUIRED' },
  { phrase: '直接入库策略字段冲突', code: 'DIRECT_INGEST_STRATEGY_CONFLICT' },
  { phrase: '直接入库类别不一致', code: 'DIRECT_INGEST_CATEGORY_MISMATCH' },
  { phrase: '直接入库来源不可用', code: 'DIRECT_INGEST_SOURCE_UNAVAILABLE' },
  { phrase: '直接入库文件不可用', code: 'DIRECT_INGEST_FILES_UNAVAILABLE' },
  { phrase: '直接入库模型不可用', code: 'DIRECT_INGEST_MODEL_UNAVAILABLE' },
  { phrase: '入库文件清单非法', code: 'IMPORT_FILES_INVALID' },
  { phrase: '数据来源未通过元数据检查', code: 'IMPORT_CHECK_POLICY_NOT_PASSED' },
  // 2026-11-11：run_if_needed 已从新受理移除，新请求的 400 文案是「导入检查策略无效」
  { phrase: '导入检查策略无效', code: 'IMPORT_CHECK_POLICY_INVALID' },
  // 契约：require_passed 缺 checkUid 时 400，errorCode 即这句
  { phrase: '检查通过入库必须携带 checkUid', code: 'IMPORT_CHECK_UID_REQUIRED' },
  { phrase: '补录状态不允许', code: 'METADATA_BACKFILL_NOT_ALLOWED' },
  { phrase: 'IMPORT_IDEMPOTENT_REPLAY', code: 'IMPORT_IDEMPOTENT_REPLAY' },
  /* -------- 2026-11-12 后端改定：source + files[{sourcePath,targetPath}] 与数据上传会话 -------- */
  // 长短语在前，避免「数据来源不可用」吞掉「数据来源根不可用」
  { phrase: '数据上传批次已过期', code: 'DATA_UPLOAD_SESSION_EXPIRED' },
  { phrase: '数据上传批次不存在', code: 'DATA_UPLOAD_SESSION_NOT_FOUND' },
  { phrase: '数据上传尚未完成', code: 'DATA_UPLOAD_NOT_COMPLETED' },
  { phrase: '对象存储不可达', code: 'OBJECT_STORAGE_UNAVAILABLE' },
  { phrase: '数据来源根不可用', code: 'DATA_SOURCE_ROOT_UNAVAILABLE' },
  { phrase: '数据来源类型无效', code: 'DATA_SOURCE_TYPE_INVALID' },
  { phrase: '数据来源不可用', code: 'DATA_SOURCE_UNAVAILABLE' },
  { phrase: '数据文件大小或摘要不一致', code: 'DATA_FILE_DIGEST_MISMATCH' },
  { phrase: '数据文件清单为空', code: 'DATA_FILE_LIST_EMPTY' },
  { phrase: '数据文件路径非法', code: 'DATA_FILE_PATH_INVALID' },
  { phrase: '数据文件不存在', code: 'DATA_FILE_NOT_FOUND' },
  { phrase: '元数据文件位置非法', code: 'METADATA_FILE_PATH_INVALID' },
  { phrase: '检查记录不可用', code: 'IMPORT_CHECK_RECORD_UNAVAILABLE' },
  { phrase: '文件清单冲突', code: 'IMPORT_FILES_CONFLICT' }
];

/** 内部码 → 页面动作；未列出的码返回 undefined，由调用方走通用兜底 */
const CODE_ACTION: Partial<Record<MetacheckErrorCode, MetacheckErrorAction>> = {
  SOURCE_CHANGED_SINCE_CHECK: 'recheck',
  CHECK_BINDING_MISMATCH: 'recheck',
  CHECK_NOT_FOUND: 'recheck',
  IMPORT_CHECK_POLICY_NOT_PASSED: 'recheck',
  // 新受理里 run_if_needed 已被移除，撞到这条说明请求侧传了废弃值（前端已无入口）
  IMPORT_CHECK_POLICY_INVALID: 'refresh',
  // require_passed 缺 checkUid：回到「选择检查单」这一步
  IMPORT_CHECK_UID_REQUIRED: 'clearCheckUid',
  DIRECT_INGEST_REASON_REQUIRED: 'enterReason',
  DIRECT_INGEST_REASON_INVALID: 'enterReason',
  DIRECT_INGEST_STRATEGY_CONFLICT: 'clearCheckUid',
  DIRECT_INGEST_CATEGORY_MISMATCH: 'pickCategory',
  DIRECT_INGEST_SOURCE_UNAVAILABLE: 'checkSource',
  DIRECT_INGEST_FILES_UNAVAILABLE: 'pickFiles',
  DIRECT_INGEST_MODEL_UNAVAILABLE: 'pickModel',
  IMPORT_FILES_INVALID: 'pickFiles',
  IMPORT_IDEMPOTENT_REPLAY: 'refresh',
  METADATA_BACKFILL_NOT_ALLOWED: 'refresh',
  // 2026-11-12：files 与 dataFiles 同时非空的硬冲突；前端已只发一种，撞到说明有残留逻辑
  IMPORT_FILES_CONFLICT: 'refresh',
  DATA_SOURCE_TYPE_INVALID: 'checkSource',
  DATA_SOURCE_UNAVAILABLE: 'checkSource',
  DATA_SOURCE_ROOT_UNAVAILABLE: 'checkSource',
  DATA_FILE_NOT_FOUND: 'pickFiles',
  DATA_FILE_LIST_EMPTY: 'pickFiles',
  DATA_FILE_PATH_INVALID: 'pickFiles',
  DATA_FILE_DIGEST_MISMATCH: 'pickFiles',
  DATA_UPLOAD_SESSION_NOT_FOUND: 'checkSource',
  DATA_UPLOAD_SESSION_EXPIRED: 'checkSource',
  DATA_UPLOAD_NOT_COMPLETED: 'checkSource',
  OBJECT_STORAGE_UNAVAILABLE: 'checkSource',
  METADATA_FILE_PATH_INVALID: 'pickFiles',
  IMPORT_CHECK_RECORD_UNAVAILABLE: 'recheck'
};

/**
 * 从 axios 异常里取出候选错误码与原始文案。
 *
 * WHY 不只看一个字段：HTTP 4xx 走 axios 的 error 分支（明细在 error.response.data.data），
 * 业务码非 0 时拦截器又把响应体 reject 成字符串 'error'（此时只剩下 error.message 可读）。
 * 两条路径都要覆盖，否则页面拿到的永远是空。
 */
export function extractMetacheckErrorDetail(error: any): { errorCode: string; message: string; httpStatus: number } {
  const response = error?.response;
  const body = response?.data;
  const errorCode = String(body?.data?.errorCode ?? body?.errorCode ?? error?.data?.errorCode ?? error?.errorCode ?? '');
  const message = String(body?.message ?? body?.msg ?? error?.message ?? (typeof error === 'string' ? error : ''));
  const httpStatus = Number(response?.status ?? error?.status ?? 0);
  return { errorCode, message, httpStatus };
}

/**
 * 把任意异常归一为契约错误码；识别不出返回 null（不是错误码类失败，走通用提示）。
 *
 * CONSTRAINT 判定顺序：先精确比对英文稳定码，再按「最长中文短语优先」匹配
 * errorCode 与 message，避免短短语误命中。命中英文码时即使文案被本地化也能正确分派。
 */
export function resolveMetacheckErrorCode(error: any): MetacheckErrorCode | null {
  const { errorCode, message } = extractMetacheckErrorDetail(error);
  const haystack = (errorCode + ' ' + message).trim();
  if (!haystack) return null;
  const upper = haystack.toUpperCase();
  if (upper.includes('SOURCE_CHANGED_SINCE_CHECK')) return 'SOURCE_CHANGED_SINCE_CHECK';
  if (upper.includes('CHECK_BINDING_MISMATCH')) return 'CHECK_BINDING_MISMATCH';
  if (upper.includes('CHECK_NOT_FOUND')) return 'CHECK_NOT_FOUND';
  for (const row of CHINESE_CODE_TABLE) {
    if (haystack.includes(row.phrase)) return row.code;
  }
  return null;
}

/**
 * 错误码 → 页面动作；识别不出返回 null。
 *
 * WHY 与「提示文案」分开：动作是页面行为（切 tab / 开输入框），文案可能随后端调整，
 * 两者耦合会让「后端改一句话，前端就跳错页面」。
 */
export function resolveMetacheckErrorAction(error: any): MetacheckErrorAction | null {
  const code = resolveMetacheckErrorCode(error);
  return code ? CODE_ACTION[code] || null : null;
}

/**
 * 判断异常是否属于指定错误码之一。
 *
 * 用法：`if (isMetacheckError(e, 'CHECK_NOT_FOUND')) ElMessage.warning('检查记录已失效，请重新检查')`
 */
export function isMetacheckError(error: any, ...codes: MetacheckErrorCode[]): boolean {
  const code = resolveMetacheckErrorCode(error);
  if (!code) return false;
  return codes.length === 0 || codes.includes(code);
}

/**
 * 生成可直接展示的中文提示，并附带应执行动作。
 *
 * CONSTRAINT **不吞掉后端原始文案**：后端 message 通常比本地文案更具体（含文件名、字段名），
 * 有 message 时优先返回它；本地文案只在后端没给或给的是拦截器兜底串（'error' 等）时兜底。
 */
export function describeMetacheckError(error: any): { code: MetacheckErrorCode | null; action: MetacheckErrorAction | null; message: string } {
  const { message } = extractMetacheckErrorDetail(error);
  const code = resolveMetacheckErrorCode(error);
  const action = code ? CODE_ACTION[code] || null : null;
  const fallback: Partial<Record<MetacheckErrorCode, string>> = {
    SOURCE_CHANGED_SINCE_CHECK: '来源文件自上次检查后已变化，请重新检查',
    CHECK_BINDING_MISMATCH: '检查记录与所选文件/类别不一致，请重新检查',
    CHECK_NOT_FOUND: '检查记录不存在或已失效，请重新检查',
    DIRECT_INGEST_REASON_REQUIRED: '请填写直接入库原因（1–500 字）',
    DIRECT_INGEST_REASON_INVALID: '直接入库原因需为 1–500 个字符',
    DIRECT_INGEST_STRATEGY_CONFLICT: '直接入库不能绑定检查单，请清空检查单后重试',
    DIRECT_INGEST_CATEGORY_MISMATCH: '所选类别与检查记录不一致，请重新选择类别',
    DIRECT_INGEST_SOURCE_UNAVAILABLE: '来源共享目录不可用，请检查共享与路径',
    DIRECT_INGEST_FILES_UNAVAILABLE: '所选文件不可用，请重新选择',
    DIRECT_INGEST_MODEL_UNAVAILABLE: '元数据模型不可用，请先配置模型或改走正常检查',
    IMPORT_FILES_INVALID: '文件清单非法，请重新选择文件',
    IMPORT_CHECK_POLICY_NOT_PASSED: '数据来源未通过元数据检查，请先完成检查',
    IMPORT_CHECK_POLICY_INVALID: '导入检查策略无效：请改用「检查通过后入库」或「直接入库」',
    IMPORT_CHECK_UID_REQUIRED: '检查通过后入库必须绑定一条已通过检查的记录',
    IMPORT_IDEMPOTENT_REPLAY: '该请求已受理，正在刷新最新状态',
    METADATA_BACKFILL_NOT_ALLOWED: '当前批次状态不允许补录，请刷新详情后重试'
  };
  const isGeneric = !message || message === 'error' || message === 'Error' || message === 'undefined';
  if (!isGeneric) return { code, action, message };
  return { code, action, message: (code && fallback[code]) || '操作失败，请稍后重试' };
}
