/**
 * 元数据文件检查与上传接口（T6a 契约 2026-11-08）
 *
 * 路径 /platform/metadata/files/uploads（上传批次）与 /platform/metadata/checks/files
 * （检查任务），baseURL 由 http.ts 的 withProductBase 注入。
 *
 * 与 metadata.ts 的分工：metadata.ts 的 CHECK_BASE 面向「用模型检查资产版本的结构/值」；
 * 本模块面向「上传文件或读取已登记共享位置后做文件级元数据检查」，来源解析与任务载体不同。
 *
 * 实测优先（2026-11-09，10.61.129.27:19999/datamanage/api）：
 *   - 检查列表**只认 cursor/limit**，`page`/`size` 被完全忽略（后端返回全量，前端翻不了页）；
 *   - 详情 `files` 实测是 `string[]`（旧类型写成对象数组属类型说谎）；
 *   - `state` 实测中文「成功」、`decision` 实测中文「接受/拒绝」，与 Apifox 示例的英文不符（C5）。
 */
import { apiDelete, apiGet, apiPost } from '../http';
import request from '@/utils/request';
import { seg, withProductBase } from '../http';
import type { ApiResult } from '../http';

const UPLOAD_BASE = '/platform/metadata/files/uploads';
const CHECK_BASE = '/platform/metadata/checks/files';
/** 检查清单（2026-11-18 实测）：按 taskUid 过滤、DELETE 为软删除 */
const MANIFEST_BASE = '/platform/metadata/checks/manifests';
/** 检查候选扫描（2026-11-12 契约新增）：提交检查前先列出可检查的 SMS/GeoJSON */
const SCAN_BASE = '/platform/metadata/checks/scan';

/** 上传批次摘要；契约不暴露内部存储根或物理路径 */
export interface MetadataUploadSummary {
  /** 上传批次 uid */
  uploadUid: string;
  /** 批次状态 */
  status: string;
  /** 文件数量 */
  fileCount: number;
  /** 文件总字节数 */
  totalBytes?: number;
  /** 上传清单 SHA-256 */
  manifestSha256?: string;
  /** 上传用途（固定 metadata_check） */
  uploadPurpose?: string;
  /** 其他摘要字段由后端定义 */
  [key: string]: unknown;
}

/** 按模型 uid 查询已登记的上传批次 */
export function listMetadataUploads(modelUid: string, limit?: number) {
  const params: { modelUid: string; limit?: number } = { modelUid };
  if (typeof limit === 'number' && limit > 0) params.limit = Math.min(200, Math.max(1, Math.trunc(limit)));
  return apiGet<{ modelUid?: string; modelKey?: string; items: MetadataUploadSummary[]; itemCount?: number }>(UPLOAD_BASE, { params });
}

/** 元数据单文件大小上限：50 MB（后端 maxFileBytes 同步值） */
export const MAX_METADATA_FILE_BYTES = 50 * 1024 * 1024;

/** 元数据单批文件数上限：5000（后端 maxFilesPerUpload 同步值） */
export const MAX_METADATA_FILES_PER_UPLOAD = 5000;

/** 检查列表单页条数下限（契约 1–200） */
export const METADATA_CHECK_PAGE_MIN = 1;

/** 检查列表单页条数上限（契约 1–200，超出后端返回 400） */
export const METADATA_CHECK_PAGE_MAX = 200;

/** 检查列表单页条数默认值（契约默认 20） */
export const METADATA_CHECK_PAGE_DEFAULT = 20;

/** 任务名称长度上限（契约 maxLength 200） */
export const MAX_METADATA_CHECK_TASK_NAME = 200;

/**
 * 上传前本地预校验：返回 null 表示通过，否则返回应展示给用户的错误文案。
 * 文案与后端一致（「元数据文件超过 maxFileBytes 限制：<文件名>」等），便于联调时直接比对。
 */
export function precheckMetadataFiles(files: Array<File | Blob>): string | null {
  if (files.length > MAX_METADATA_FILES_PER_UPLOAD) return '本次上传文件数超过 maxFilesPerUpload 限制';
  for (const f of files) {
    const name = (f as File).name || '';
    if (f.size > MAX_METADATA_FILE_BYTES) return '元数据文件超过 maxFileBytes 限制：' + name;
  }
  return null;
}

/**
 * 批量上传元数据文件到受控暂存目录（一次请求 = 一个上传批次 = 一个 uploadUid）。
 *
 * CONSTRAINT multipart/form-data：不能手动设置 Content-Type，需交给 axios 自动补 boundary；
 * 因此不走 apiPost helper（它只处理 JSON），直接调 request.post 并显式声明 R = ApiResult<T>。
 * CONSTRAINT 多文件/文件夹上传：files 逐项重复 append('file', f)；relativePaths 与 files
 * **同序同长**（取 file.webkitRelativePath || file.name），后端按此重建并校验目录树，
 * 前端无需自行建树。提交检查时 files 元素必须是该批次清单的子集，故两端取值须一致。
 * 空目录无法从普通 FileList 获取，可选填 directories。
 */
export function uploadMetadataFile(modelUid: string, files: Array<File | Blob>, options: { relativePaths?: string[]; directories?: string[] } = {}) {
  const formData = new FormData();
  formData.append('modelUid', modelUid);
  files.forEach((file) => formData.append('file', file));
  if (options.relativePaths?.length) formData.append('relativePaths', JSON.stringify(options.relativePaths));
  if (options.directories?.length) formData.append('directories', JSON.stringify(options.directories));
  // 契约：响应 data 直接是上传批次摘要（不再包一层 summary）
  return request.post<MetadataUploadSummary, ApiResult<MetadataUploadSummary>>(UPLOAD_BASE, formData, withProductBase());
}

/** 检查范围；契约默认 full，不接受自定义值 */
export type MetadataCheckScope = 'completeness' | 'accuracy' | 'full';

/**
 * 来源类型机器码（提交与响应同值域）。
 *
 * CONSTRAINT 响应里 `sourceKindCode` 是另一套码（client_upload / registered_share /
 * direct_shared_path），与 `sourceType` 不等价（C4）。分支判断**统一用 sourceType**，
 * `sourceKind`/`sourceKindCode` 只用于展示。
 */
export type MetadataCheckSourceType = 'upload' | 'registered_share' | 'direct_shared_path';

/**
 * 提交检查任务的载荷（POST /platform/metadata/checks/files）。
 *
 * 必填：taskName / modelUid / files。来源三选一，字段组合决定来源：
 *   - upload：只传 uploadUid，**禁止** sourceStorageUid / dataRootPath；
 *   - registered_share：sourceStorageUid + dataRootPath（登记根内相对路径，可空串）；
 *   - direct_shared_path：只传完整 dataRootPath。
 * 别名：categoryUid / dataRootPath 是规范名，productCategoryUid / sourcePath 是兼容别名，
 * 二者**不能同时发**——buildMetadataCheckPayload 已保证只出现一种。
 */
export interface MetadataCheckPayload {
  modelUid: string;
  /** 任务名称，必填，≤200 字符，用于列表展示 */
  taskName: string;
  /**
   * 选中文件清单，必填非空。
   *
   * CONSTRAINT 元素是相对 dataRootPath 的规范化相对路径（`/` 分隔），禁止绝对路径/盘符/
   * `..`/空段/控制字符/首尾空白；upload 来源时必须是该上传批次清单的子集。
   */
  files: string[];
  /** 检查范围；省略时后端按 full */
  scope?: MetadataCheckScope;
  /** 产品类别 uid（规范名；省略时由模型关联的唯一类别确定） */
  categoryUid?: string;
  /** 产品类别 uid（兼容别名，与 categoryUid 二选一） */
  productCategoryUid?: string;
  /** 来源数据根（规范名）。registered_share=登记根内相对路径（空串=登记根）；direct_shared_path=完整路径原文 */
  dataRootPath?: string;
  /** 来源数据根（兼容别名，与 dataRootPath 二选一） */
  sourcePath?: string;
  /** 来源类型机器码；由字段组合推导后回填，避免调用方声明与组合不一致 */
  sourceType?: MetadataCheckSourceType;
  /** 上传批次 uid（upload 来源专用） */
  uploadUid?: string;
  /** 已登记共享位置 uid（registered_share 专用） */
  sourceStorageUid?: string;
  /** 可选；省略时后端在提交时冻结模型当前版本 */
  modelVersionUid?: string;
  /** 单次检查的文件数上限（契约 2026-11-12 新增，可选；后端另有默认策略） */
  maxFiles?: number;
  /** 单文件最大记录数（契约 2026-11-12 新增，可选） */
  maxRecordsPerFile?: number;
  /** 字段别名映射：键为模型字段键，值为来源文件实际字段名；来源字段名与模型声明不一致时使用 */
  fieldAliases?: Record<string, string>;
  /** 检查预算：maxIssues 单次最多登记错误数（默认 512），maxValueBytes 单值检查字节预算（默认 1048576） */
  limits?: { maxIssues?: number; maxValueBytes?: number };
  /** 值级检查开关；指定时须同时提供 accuracy，且不得与 scope 同时提供 */
  completeness?: boolean;
  /** 值级检查开关；指定时须同时提供 completeness，且不得与 scope 同时提供 */
  accuracy?: boolean;
  /** 客户端请求关联标识（追踪用）；与 idempotencyKey 互斥 */
  requestId?: string;
  /** requestId 的幂等替代键（最长 256 字符）；与 requestId 互斥 */
  idempotencyKey?: string;
}

/** 载荷构造输入：来自任务行或新建表单，字段可空（在 build 内统一校验） */
export interface MetadataCheckPayloadInput {
  modelUid?: string | null;
  /** 产品类别 uid（规范名，首选） */
  categoryUid?: string | null;
  /** 产品类别 uid（兼容别名；仅在 categoryUid 缺失时使用） */
  productCategoryUid?: string | null;
  scope?: string | null;
  /** 任务名称：新建表单必填，重新检查时可从任务行带入 */
  taskName?: string | null;
  /** 选中文件清单（相对 dataRootPath） */
  files?: string[] | null;
  /** 来源类型声明；仅用于校验字段组合，不一致时直接拒绝而不是发出矛盾请求 */
  sourceType?: string | null;
  uploadUid?: string | null;
  sourceStorageUid?: string | null;
  /** 来源数据根（规范名，首选） */
  dataRootPath?: string | null;
  /** 来源数据根（兼容别名；仅在 dataRootPath 缺失时使用） */
  sourcePath?: string | null;
  modelVersionUid?: string | null;
  /** 单次检查文件数上限（可选） */
  maxFiles?: number | null;
  /** 单文件最大记录数（可选） */
  maxRecordsPerFile?: number | null;
  /** 字段别名映射（可选） */
  fieldAliases?: Record<string, string> | null;
  /** 检查预算（可选） */
  limits?: { maxIssues?: number; maxValueBytes?: number } | null;
  /** 值级检查开关（可选，须与 accuracy 同时提供，且不得与 scope 同时提供） */
  completeness?: boolean | null;
  /** 值级检查开关（可选，须与 completeness 同时提供，且不得与 scope 同时提供） */
  accuracy?: boolean | null;
  /** 客户端请求关联标识（可选，与 idempotencyKey 互斥） */
  requestId?: string | null;
  /** 幂等键（可选，与 requestId 互斥） */
  idempotencyKey?: string | null;
}

/**
 * 载荷构造结果。
 *
 * WHY 不用「判别联合 + 字面量 ok」：本项目 tsconfig 关闭了 strictNullChecks，
 * vue-tsc 对 `!build.ok` 的窄化不生效，调用侧会误报 `message`/`payload` 不存在。
 * 用可选字段表达后，调用侧 `if (!build.ok || !build.payload)` 一次判空即可。
 */
export interface MetadataCheckPayloadBuildResult {
  ok: boolean;
  payload?: MetadataCheckPayload;
  message?: string;
}

/**
 * 校验单个 files 元素是否满足契约的「规范化相对路径」规则。
 *
 * WHY 不在提交前静默 trim/替换：契约明令禁止首尾空白与 `\` 分隔，静默修正会让
 * 前端以为自己发对了，服务端按规范化路径去重/比对时反而对不上（405 类问题难查）。
 * 返回 null 表示通过，否则返回可直接展示的中文原因（含具体路径）。
 */
export function validateMetadataFilePath(path: string): string | null {
  if (typeof path !== 'string') return 'files 元素必须是字符串';
  const text = path;
  if (!text) return 'files 不能包含空元素';
  if (text !== text.trim()) return 'files 元素不能含首尾空白：' + text;

  if (/[\u0000-\u001f\u007f]/.test(text)) return 'files 元素不能含控制字符：' + text;
  if (/^[\\/]/.test(text)) return 'files 元素必须是相对路径（不能以 / 或 \\ 开头）：' + text;
  if (/^[A-Za-z]:/.test(text)) return 'files 元素不能含盘符：' + text;
  if (text.includes('\\')) return 'files 元素必须以 / 分隔：' + text;
  const segments = text.split('/');
  if (segments.some((part) => part === '')) return 'files 元素不能含空段（重复 / 或首尾 /）：' + text;
  if (segments.some((part) => part === '.' || part === '..')) return 'files 元素不能含 . 或 ..：' + text;
  return null;
}

/**
 * 批量校验 files 清单：空清单与任一元素非法都返回原因。
 *
 * WHY 独立导出：检查页（多选回填）与入库页（direct 直接入库）都要在提交前给即时反馈，
 * 规则只应有一份；两处各写一套必然漂移。
 */
export function validateMetadataFilePaths(files: string[]): string | null {
  if (!Array.isArray(files) || files.length === 0) return 'files 不能为空（至少选择一个文件）';
  for (const item of files) {
    const problem = validateMetadataFilePath(item);
    if (problem) return problem;
  }
  return null;
}

/** 规范化检查范围：非法值返回 undefined（由 build 转成明确报错，不做静默兜底） */
function normalizeScope(raw?: string | null): MetadataCheckScope | undefined {
  if (raw == null || raw === '') return 'full';
  return raw === 'completeness' || raw === 'accuracy' || raw === 'full' ? raw : undefined;
}

/** 别名取值：规范名优先；规范名未提供（null/undefined）时才回落到别名 */
function pickAlias(primary?: string | null, alias?: string | null): string | undefined {
  if (primary != null) return primary;
  if (alias != null) return alias;
  return undefined;
}

/**
 * 由来源输入构造提交检查任务的载荷，并做必填与来源三选一校验。
 *
 * WHY 单独抽出：载荷 shape 属后端契约（additionalProperties:false，字段名不得臆造：
 * 范围字段是 scope 不是 checkScope）。页面多处（列表重新检查 / 新建表单提交）若各写
 * 一份构造逻辑，契约变更时极易漏改——曾出现仅改一处、点击即 400 的先例。
 * 所有调用方只传来源输入，字段拼装与校验在此收口。
 *
 * CONSTRAINT 别名只发一种：categoryUid / dataRootPath 有值时绝不再发
 * productCategoryUid / sourcePath（契约：同时提供必须相同，不同则 400）。
 * 来源由字段组合推导，调用方传入的 sourceType 只用于**校验**，不会原样透传。
 */
export function buildMetadataCheckPayload(input: MetadataCheckPayloadInput): MetadataCheckPayloadBuildResult {
  if (!input?.modelUid) return { ok: false, message: '缺少 modelUid' };
  const taskName = String(input.taskName ?? '').trim();
  if (!taskName) return { ok: false, message: '缺少 taskName' };
  if (taskName.length > MAX_METADATA_CHECK_TASK_NAME) return { ok: false, message: 'taskName 不能超过 200 字符' };
  const files = Array.isArray(input.files) ? input.files.slice() : [];
  const filesError = validateMetadataFilePaths(files);
  if (filesError) return { ok: false, message: filesError };
  const scope = normalizeScope(input.scope);
  if (!scope) return { ok: false, message: 'scope 只能是 completeness / accuracy / full' };

  const payload: MetadataCheckPayload = { modelUid: input.modelUid, taskName, files, scope };

  // 类别：契约允许省略（由模型关联的唯一类别确定），故只在有值时透传，不再强行必填
  const categoryUid = pickAlias(input.categoryUid, input.productCategoryUid);
  if (categoryUid) {
    if (input.categoryUid != null) payload.categoryUid = categoryUid;
    else payload.productCategoryUid = categoryUid;
  }

  if (input.modelVersionUid) payload.modelVersionUid = input.modelVersionUid;
  // 2026-11-12 契约新增的可选上限：仅在调用方显式给正整数时透传，不做前端默认值猜测
  if (typeof input.maxFiles === 'number' && input.maxFiles > 0) payload.maxFiles = Math.trunc(input.maxFiles);
  if (typeof input.maxRecordsPerFile === 'number' && input.maxRecordsPerFile > 0) {
    payload.maxRecordsPerFile = Math.trunc(input.maxRecordsPerFile);
  }
  // 互斥校验：requestId 与 idempotencyKey 同时提供会被后端 400，前端提前拦截
  if (input.requestId != null && input.idempotencyKey != null) {
    return { ok: false, message: 'requestId 与 idempotencyKey 不能同时提供' };
  }
  if (input.requestId) payload.requestId = String(input.requestId);
  if (input.idempotencyKey) {
    const key = String(input.idempotencyKey);
    if (key.length > 256) return { ok: false, message: 'idempotencyKey 不能超过 256 字符' };
    payload.idempotencyKey = key;
  }
  // 字段别名映射：仅透传非空对象，值必须是字符串
  if (input.fieldAliases && typeof input.fieldAliases === 'object') {
    const aliases: Record<string, string> = {};
    for (const [k, v] of Object.entries(input.fieldAliases)) {
      if (typeof v === 'string') aliases[k] = v;
    }
    if (Object.keys(aliases).length) payload.fieldAliases = aliases;
  }
  // 检查预算：正整数才透传
  if (input.limits && typeof input.limits === 'object') {
    const limits: { maxIssues?: number; maxValueBytes?: number } = {};
    if (typeof input.limits.maxIssues === 'number' && input.limits.maxIssues > 0) limits.maxIssues = Math.trunc(input.limits.maxIssues);
    if (typeof input.limits.maxValueBytes === 'number' && input.limits.maxValueBytes > 0)
      limits.maxValueBytes = Math.trunc(input.limits.maxValueBytes);
    if (Object.keys(limits).length) payload.limits = limits;
  }
  // 值级检查开关：须成对出现且不得与 scope 同时提供（scope 默认 full 已赋值，故仅在显式提供开关时处理）
  if (input.completeness != null || input.accuracy != null) {
    if (input.completeness == null || input.accuracy == null) {
      return { ok: false, message: 'completeness 与 accuracy 必须同时提供' };
    }
    if (!input.completeness && !input.accuracy) return { ok: false, message: 'completeness 与 accuracy 至少一个为 true' };
    if (input.scope != null && input.scope !== '') return { ok: false, message: 'completeness/accuracy 与 scope 不能同时提供' };
    payload.completeness = input.completeness;
    payload.accuracy = input.accuracy;
    delete payload.scope;
  }

  // dataRootPath 空串是合法值（registered_share 的登记根），所以判空必须用 != null
  const dataRootPath = pickAlias(input.dataRootPath, input.sourcePath);
  const hasDataRootPath = dataRootPath != null;

  const uploadUid = input.uploadUid || '';
  const sourceStorageUid = input.sourceStorageUid || '';

  /** 由字段组合推导来源；组合本身有歧义时返回 null 交给下方报错 */
  const derived = uploadUid ? 'upload' : sourceStorageUid ? 'registered_share' : hasDataRootPath ? 'direct_shared_path' : null;
  if (!derived) return { ok: false, message: '缺少来源信息（需 uploadUid / sourceStorageUid + dataRootPath / dataRootPath 之一）' };

  const declared = input.sourceType || '';
  if (declared && declared !== derived) {
    return { ok: false, message: `来源字段组合对应 ${derived}，与声明 sourceType=${declared} 不一致，请检查表单来源选择` };
  }

  payload.sourceType = derived;
  if (derived === 'upload') {
    // 契约：upload 来源禁止 sourceStorageUid / dataRootPath，带上会被判字段冲突
    payload.uploadUid = uploadUid;
    return { ok: true, payload };
  }
  if (derived === 'registered_share') {
    payload.sourceStorageUid = sourceStorageUid;
    if (input.dataRootPath != null) payload.dataRootPath = String(input.dataRootPath);
    else if (input.sourcePath != null) payload.sourcePath = String(input.sourcePath);
    else payload.dataRootPath = '';
    return { ok: true, payload };
  }
  // direct_shared_path：只传完整 dataRootPath，不得带 sourceStorageUid
  if (input.dataRootPath != null) payload.dataRootPath = String(input.dataRootPath);
  else payload.sourcePath = String(dataRootPath);
  return { ok: true, payload };
}

/**
 * 提交元数据文件检查任务；载荷由 buildMetadataCheckPayload 构造。
 *
 * CONSTRAINT 202 只表示**受理**：响应里 accepted 为 null、decision 为 pending，
 * 是否可入库要看详情接口（用 isMetadataCheckAccepted 判定）。
 */
export function submitMetadataFileCheck(payload: MetadataCheckPayload) {
  return apiPost<MetadataCheckTaskSummary, MetadataCheckPayload>(CHECK_BASE, payload);
}

/** 扫描粒度：folder 递归扫描目录，file 只扫描指定文件 */
export type MetadataScanSelectionMode = 'folder' | 'file';

/**
 * 检查候选扫描请求（POST /platform/metadata/checks/scan，2026-11-12 新增）。
 *
 * 来源三型与 checks/files 同一套口径（由字段组合推导）：
 *   registered_share → sourceStorageUid + dataRootPath；
 *   direct_shared_path → dataRootPath 为完整 UNC；
 *   upload → uploadUid（+ modelUid）。
 */
export interface MetadataScanPayload {
  sourceType: MetadataCheckSourceType;
  sourceStorageUid?: string;
  /** registered_share：登记根内相对路径（空串=登记根）；direct_shared_path：完整 UNC */
  dataRootPath?: string;
  uploadUid?: string;
  modelUid: string;
  selectionMode: MetadataScanSelectionMode;
  /** 分页起点，默认 0 */
  offset?: number;
  /** 单页条数，默认 200 */
  limit?: number;
}

/** 扫描出的一个候选文件 */
export interface MetadataScanCandidate {
  /** 相对 dataRootPath 的路径，直接作为 checks/files 的 files 元素 */
  relativePath: string;
  /** 登记根相对路径（导航语义，不要当 files） */
  path?: string;
  name?: string;
  /** 字节数 */
  sizeBytes?: number;
  /** 后端判定可检查（SMS/GeoJSON）；前端不再按扩展名二次筛 */
  checkable?: boolean;
  /** 类型；目录项在 folder 模式下也可能出现 */
  type?: string;
}

/** 扫描响应 */
export interface MetadataScanResult {
  items?: MetadataScanCandidate[];
  /** 明确可提交的候选（部分后端实现会单独给一份） */
  candidates?: MetadataScanCandidate[];
  total?: number;
  offset?: number;
  limit?: number;
  /** 是否还有下一页（按 offset+limit 续） */
  hasMore?: boolean;
  /** 扫描过的目录数 / 跳过的项数等统计，仅展示 */
  scannedDirectories?: number;
  skippedFiles?: number;
}

/**
 * 扫描可检查的元数据候选（提交 checks/files 之前的一步）。
 *
 * WHY 需要这一步：目录递归场景下用户并不知道目录里到底有哪些 SMS/GeoJSON，
 * 直接提交目录会得到 200 empty/partial（checkUid=null），表现为「提交成功但没有任务」。
 * 先 scan 让用户看到候选清单再确认，能把这类假成功挡在提交之前。
 */
export function scanMetadataCheckCandidates(payload: MetadataScanPayload) {
  return apiPost<MetadataScanResult, MetadataScanPayload>(SCAN_BASE, payload);
}

/** 从扫描响应里取候选数组；兼容 items / candidates 两种命名 */
export function pickScanCandidates(result?: MetadataScanResult | null): MetadataScanCandidate[] {
  const list = result?.candidates ?? result?.items;
  return Array.isArray(list) ? list : [];
}

/**
 * 判断一次提交是否**未被受理**（200 empty / partial，契约 2026-11-10）。
 *
 * 背景：目录 / 任意文件放开勾选后，用户很容易选出「没有 SMS/GeoJSON」或「超过 5000」的清单。
 * 后端这类响应是 HTTP 200 + code=0（与 202 受理同码），但 data 里
 * `checkUid=null`、`accepted=false`、`canStartImport=false`，并没有真正创建任务。
 * create-dialog 只按 `code === 0` 关弹窗并提示成功，因此调用方必须在拿到响应后
 * 用本函数复核，否则用户会看到「保存成功」却永远等不到检查记录。
 *
 * 判据用 `checkUid` 缺失（受理响应必有），并辅以 `accepted === false` / `state` 兜底，
 * 避免后端字段微调时静默放行。
 */
export function isMetadataCheckNotAccepted(res?: { data?: MetadataCheckTaskSummary | null } | null): boolean {
  const data = res?.data;
  if (!data || typeof data !== 'object') return false;
  if (data.checkUid) return false;
  return data.accepted === false || data.canStartImport === false || data.state === 'empty' || data.state === 'partial';
}

/** 取「未受理」响应的用户可读原因：优先 data.message（顶层 message 恒为「成功」） */
export function metadataCheckNotAcceptedMessage(res?: { data?: MetadataCheckTaskSummary | null } | null): string {
  const data = res?.data;
  const reason = String(data?.message || '').trim();
  if (reason) return reason;
  return data?.state === 'partial' ? '元数据文件超过单次检查上限，请分批检查' : '没有可检查的 SMS / GeoJSON 元数据文件';
}

/**
 * 逐文件检查结果（详情接口 fileResults[]）。
 *
 * CONSTRAINT status 是**中文词表**（成功/失败/警告/跳过/未检查），warning 不阻断入库；
 * 只有实际参与元数据解析的 SMS/GeoJSON 才有条目，数据文件只在 dataFiles 里出现。
 */
export interface MetadataCheckFileResult {
  /** 规范化相对路径，必属于 checkedFiles */
  path: string;
  /** 元数据文件格式；契约仅 sms/geojson */
  kind?: string;
  /** 单文件状态中文词表：成功 / 失败 / 警告 / 跳过 / 未检查 */
  status?: string;
  /** 该文件 error 数（warning 不计入阻断） */
  errorCount?: number;
  /** 解析记录数（可选） */
  recordCount?: number;
  /** 服务端实测字节数（可选） */
  sizeBytes?: number;
  /** 小写 64 位十六进制内容摘要（可选） */
  sha256?: string;
}

/**
 * 元数据文件检查任务（GET/POST /platform/metadata/checks/files 响应项）。
 *
 * 字段与后端 T6a 契约同名同形，页面直接消费，不做二次映射。
 * 列表接口不返回逐文件明细（checkedFiles/dataFiles/fileResults 只在详情接口出现）。
 */
export interface MetadataCheckTaskSummary {
  /** 检查任务业务 uid（与 taskUid 同值） */
  checkUid: string;
  /** 任务名称（提交时填写；T6a 前创建的任务可能为空串） */
  taskName?: string;
  /** 底层统一任务 uid（列表与详情均返回） */
  taskUid?: string;
  /**
   * 任务状态。
   *
   * 实测（2026-11-09）：恒为中文「成功」（9/9 条记录），文档示例的 SUCCEEDED 在真实环境不存在；
   * 保留英文别名兜底，避免后端某天切回英文时判据静默失效。SUCCEEDED 只表示执行完成，
   * **不代表元数据合格**——能否入库一律用 isMetadataCheckAccepted 判定。
   */
  state?: string;
  /**
   * 检查决定。
   *
   * 实测：中文「接受」/「拒绝」；受理时为 pending，英文 accept/reject 为文档示例值（保留兜底）。
   */
  decision?: string;
  /** 结论布尔（无歧义，判据优先级最高）；任务完成前为 null */
  accepted?: boolean | null;
  /** 检查范围；契约默认 full */
  checkScope?: string;
  /** 模型 uid */
  modelUid?: string;
  /** 模型版本 uid（不可变快照） */
  modelVersionUid?: string;
  /** 模型版本号 */
  modelVersionNo?: number;
  /** 产品类别 uid（规范名） */
  categoryUid?: string;
  /** 产品类别 uid（兼容别名，与 categoryUid 同值） */
  productCategoryUid?: string;
  /** 产品类别完整路径（含祖先） */
  productCategoryPath?: string;
  /** 来源类型中文展示：已登记共享路径 / 共享路径 / 用户上传；仅展示，分支判断请用 sourceType */
  sourceKind?: string;
  /** 来源机器码：registered_share / direct_shared_path / client_upload；仅展示（与 sourceType 不等价） */
  sourceKindCode?: string;
  /** 来源类型机器码：upload / registered_share / direct_shared_path；**分支判断统一用它** */
  sourceType?: string;
  /** 来源数据根（规范名）：registered_share 为登记根内相对路径；direct_shared_path 不回显完整路径；upload 不返回 */
  dataRootPath?: string;
  /** 来源数据根（兼容别名，与 dataRootPath 同值） */
  sourcePath?: string;
  /** 已登记共享位置 uid；上传来源为 null */
  sourceStorageUid?: string;
  /** 上传批次 uid；共享位置来源为 null */
  uploadUid?: string | null;
  /** 文件数量；列表项取受理时冻结的清单（受理即知），详情在扫描完成前可为 null */
  fileCount?: number | null;
  /** 记录条数；目录扫描期间可为 null */
  recordCount?: number | null;
  /**
   * 冻结的完整选择清单，**string[]**（相对 dataRootPath 的路径，保持提交顺序）。
   *
   * WHY 必须写明类型：旧代码把它声明成 `Array<{name,size}>` 属类型说谎，页面按对象取值
   * 会渲染出空白行。实测响应就是 string[]（例如 ["分类要素属性元数据一.SMS"]）。
   */
  files?: string[];
  /**
   * 实际参与元数据检查的 SMS/GeoJSON 子集（保持 files 顺序）。
   *
   * CONSTRAINT **尚未扫描完成时为空数组**，历史检查记录也可能为空数组（实测 cd4037b6：
   * files 有 2 项、checkedFiles/dataFiles/fileResults 均为 []）。页面必须能区分
   * 「空」与「未扫描」，不能把空数组渲染成「0 个文件检查通过」。
   */
  checkedFiles?: string[];
  /** files 中作为入库数据文件的子集（服务端分类）；未扫描完成时为空数组 */
  dataFiles?: string[];
  /** 逐文件检查结果（checkedFiles 的明细）；未扫描完成时为空数组 */
  fileResults?: MetadataCheckFileResult[];
  /** 进度；percent 在目录扫描期间可为 null */
  progress?: {
    /** 已完成数量 */
    completed?: number;
    /** 总数量 */
    total?: number;
    /** 百分比；扫描期间可为 null */
    percent?: number | null;
    /** 阶段名，如 SCANNING / CHECKING / FAILED */
    stage?: string;
  };
  /** 错误账本条目；detail 接口返回，列表项可能缺省 */
  errors?: Array<{
    code?: string;
    errorUid?: string;
    message?: string;
    resolved?: boolean;
    fieldKey?: string | null;
    itemUid?: string | null;
    repairToken?: string | null;
    sourceFeatureUid?: string | null;
    sourceLayerKey?: string | null;
  }>;
  /** 检查结果明细；详情接口返回 */
  result?: unknown;
  /** 结果摘要（各计数） */
  summary?: Record<string, unknown>;
  /** 底层统一任务快照（含 artifacts/context/input/errors 等） */
  task?: Record<string, unknown>;

  /**
   * 提交接口 200 empty / partial 的「未受理」专属字段（2026-11-10 契约更新）。
   *
   * CONSTRAINT 这两个响应同样是 HTTP 200 + code=0，与 202 受理共用 data shape，
   * **唯一可靠区分是 checkUid=null / accepted=false / canStartImport=false**。
   * 调用方若只按 `code === 0` 判成功，会误把「没有可检查文件」当成检查已受理。
   * 顶层 ApiResult.message 恒为「成功」，具体原因在 **data.message**。
   *   - empty：files 里没有 SMS/GeoJSON（ignoredDataFiles 列出被忽略的数据文件）；
   *   - partial：原始清单超过单次检查上限 5000，data.files 只回前 5000 个，提示分批。
   */
  /** 未受理原因 / 分批提示（200 响应 data.message） */
  message?: string;
  /** 是否可据此开始入库；200 恒 false，202 不返回该字段 */
  canStartImport?: boolean;
  /** state=empty 且只提交了数据文件时，列出被忽略的数据文件 */
  ignoredDataFiles?: string[];
  /** state=partial：实际提交的原始文件数（大于 fileCount） */
  totalFileCount?: number;
  /** state=partial：是否还有未返回的文件 */
  hasMore?: boolean;
  /** state=partial：是否发生截断 */
  truncated?: boolean;

  /**
   * 目录展开前的**原始选择清单**（2026-11-11 契约：files 允许目录）。
   *
   * 后端在任务执行期把目录递归展开为叶子文件：提交响应 202 的 files 仍是原始选择
   * （可能含目录），而详情里本字段保留原始选择、files 变为展开后的叶子文件，
   * 是否发生展开见 result.expanded。目录本身不参与指纹与检查。
   */
  requestedFiles?: string[];
}

/**
 * 判断一条检查记录是否「通过、可用于入库」。
 *
 * 契约语义：state=SUCCEEDED 仅表示执行完成；**accepted=true 才可入库**。
 *
 * WHY 判据顺序是 accepted > decision，且**不用 state 兜底放行**：
 *   - accepted 是无歧义布尔，优先；
 *   - decision 实测中文「接受/拒绝」（文档示例 accept/reject 一并兜底）；
 *   - state 实测中文「成功」只表示「跑完了」，实测 9 条里有 4 条「成功 + 拒绝」——
 *     拿 state 当通过判据会把这 4 条直接放行入库，是会把不合格数据写进资源库的错误。
 * 因此 accepted 缺失且 decision 无法识别时一律返回 false（fail-closed），把「不确定」
 * 交给人看详情，而不是默认通过。
 */
export function isMetadataCheckAccepted(summary: MetadataCheckTaskSummary): boolean {
  if (typeof summary?.accepted === 'boolean') return summary.accepted;
  const decision = String(summary?.decision ?? '')
    .trim()
    .toLowerCase();
  if (decision === 'accept' || decision === 'accepted' || decision === '接受') return true;
  if (decision === 'reject' || decision === 'rejected' || decision === '拒绝') return false;
  return false;
}

/**
 * 检查任务状态的规范键（取值域唯一来源）。
 *
 * CONSTRAINT 键名与契约 `state` 枚举一一对应（CREATED/QUEUED/RUNNING/PAUSING/PAUSED/
 * SUCCEEDED/PARTIAL_SUCCESS/FAILED/CANCELLED），只做两处收敛：
 *   - SUCCEEDED → SUCCESS、CANCELLED → CANCELED（契约拼写不统一，内部统一为一个键）；
 *   - ACCEPTED（旧前端自造的「等待受理」值）作为别名并入 CREATED。
 * 后端实测返中文（「成功」），文档示例是英文（SUCCEEDED），两者都要能落下。
 */
export type MetadataCheckStateKey = 'CREATED' | 'QUEUED' | 'RUNNING' | 'PAUSING' | 'PAUSED' | 'PARTIAL_SUCCESS' | 'SUCCESS' | 'FAILED' | 'CANCELED';

/** 单个状态的展示口径：筛选项文案与列表标签共用，禁止页面另行拼字面量 */
export interface MetadataCheckStateView {
  /** 规范键；未识别时为空串 */
  key: MetadataCheckStateKey | '';
  /** 展示文案（筛选项 label 与状态列标签同值） */
  label: string;
  /** el-tag 类型 */
  type: 'success' | 'warning' | 'info' | 'primary' | 'danger';
  /** 是否终态（结束才有结论可谈） */
  finished: boolean;
  /** 是否活跃（这些状态需建立/保持 SSE 订阅） */
  active: boolean;
}

/**
 * 规范键 → 展示口径。
 *
 * WHY SUCCESS 的 label 是「执行完成」而不是「成功」：state=SUCCEEDED 只表示跑完了，
 * 实测 9 条里 4 条「成功 + 拒绝」；写「成功」会被读成「检查通过」。
 */
export const METADATA_CHECK_STATE_VIEW: Record<MetadataCheckStateKey, MetadataCheckStateView> = {
  CREATED: { key: 'CREATED', label: '已创建', type: 'info', finished: false, active: true },
  QUEUED: { key: 'QUEUED', label: '排队中', type: 'info', finished: false, active: true },
  RUNNING: { key: 'RUNNING', label: '检查中', type: 'primary', finished: false, active: true },
  PAUSING: { key: 'PAUSING', label: '暂停中', type: 'warning', finished: false, active: true },
  PAUSED: { key: 'PAUSED', label: '已暂停', type: 'warning', finished: false, active: false },
  PARTIAL_SUCCESS: { key: 'PARTIAL_SUCCESS', label: '部分成功', type: 'warning', finished: true, active: false },
  SUCCESS: { key: 'SUCCESS', label: '执行完成', type: 'success', finished: true, active: false },
  FAILED: { key: 'FAILED', label: '失败', type: 'danger', finished: true, active: false },
  CANCELED: { key: 'CANCELED', label: '已取消', type: 'info', finished: true, active: false }
};

/**
 * 状态筛选下拉选项：**直接由词表派生**。
 *
 * WHY 不手写第二份：手写列表与时列表必然漂移（曾出现筛选项「通过」而列表显示
 * 「执行完成」，用户以为筛的是可入库）。label 与状态列同值后，「筛什么就看到什么」。
 */
export const METADATA_CHECK_STATE_OPTIONS: Array<{ label: string; value: MetadataCheckStateKey }> = [
  'CREATED',
  'QUEUED',
  'RUNNING',
  'PAUSING',
  'PAUSED',
  'PARTIAL_SUCCESS',
  'SUCCESS',
  'FAILED',
  'CANCELED'
].map((key) => ({ label: METADATA_CHECK_STATE_VIEW[key as MetadataCheckStateKey].label, value: key as MetadataCheckStateKey }));

/** 英文/中文别名 → 规范键（精确匹配） */
const STATE_KEY_ALIAS: Record<string, MetadataCheckStateKey> = {
  CREATED: 'CREATED',
  ACCEPTED: 'CREATED',
  QUEUED: 'QUEUED',
  PENDING: 'QUEUED',
  RUNNING: 'RUNNING',
  CHECKING: 'RUNNING',
  PROCESSING: 'RUNNING',
  PAUSING: 'PAUSING',
  PAUSED: 'PAUSED',
  SUCCEEDED: 'SUCCESS',
  SUCCESS: 'SUCCESS',
  DONE: 'SUCCESS',
  COMPLETED: 'SUCCESS',
  PARTIAL_SUCCESS: 'PARTIAL_SUCCESS',
  PARTIAL: 'PARTIAL_SUCCESS',
  FAILED: 'FAILED',
  FAILURE: 'FAILED',
  ERROR: 'FAILED',
  REJECTED: 'FAILED',
  CANCELED: 'CANCELED',
  CANCELLED: 'CANCELED',
  // 中文（后端实测写法）
  已创建: 'CREATED',
  等待受理: 'CREATED',
  已受理: 'CREATED',
  排队中: 'QUEUED',
  队列中: 'QUEUED',
  等待中: 'QUEUED',
  待执行: 'QUEUED',
  检查中: 'RUNNING',
  执行中: 'RUNNING',
  处理中: 'RUNNING',
  运行中: 'RUNNING',
  暂停中: 'PAUSING',
  已暂停: 'PAUSED',
  暂停: 'PAUSED',
  部分成功: 'PARTIAL_SUCCESS',
  成功: 'SUCCESS',
  已成功: 'SUCCESS',
  已完成: 'SUCCESS',
  执行完成: 'SUCCESS',
  检查完成: 'SUCCESS',
  失败: 'FAILED',
  已失败: 'FAILED',
  错误: 'FAILED',
  已取消: 'CANCELED',
  取消: 'CANCELED'
};

/**
 * 包含关系兜底（按长→短），兼容「检查成功」「任务执行完成」等带前后缀写法。
 *
 * CONSTRAINT 顺序不能乱：长词必须排在前，否则「已暂停」会先被「暂停」截走、
 * 「已完成」会先被「完成」类词截走。
 */
const STATE_KEY_FALLBACK: Array<[string, MetadataCheckStateKey]> = [
  ['部分成功', 'PARTIAL_SUCCESS'],
  ['等待受理', 'CREATED'],
  ['已受理', 'CREATED'],
  ['已创建', 'CREATED'],
  ['排队中', 'QUEUED'],
  ['队列中', 'QUEUED'],
  ['等待中', 'QUEUED'],
  ['检查中', 'RUNNING'],
  ['执行中', 'RUNNING'],
  ['处理中', 'RUNNING'],
  ['运行中', 'RUNNING'],
  ['暂停中', 'PAUSING'],
  ['已暂停', 'PAUSED'],
  ['执行完成', 'SUCCESS'],
  ['检查完成', 'SUCCESS'],
  ['已完成', 'SUCCESS'],
  ['已成功', 'SUCCESS'],
  ['已失败', 'FAILED'],
  ['已取消', 'CANCELED'],
  ['成功', 'SUCCESS'],
  ['失败', 'FAILED'],
  ['取消', 'CANCELED'],
  ['暂停', 'PAUSED'],
  ['错误', 'FAILED']
];

/**
 * 把后端任意 state 写法归一为规范键；未识别返回空串（调用方不得当成「成功」）。
 *
 * 三级：① 精确英文枚举；② 精确中文别名；③ 包含关系兜底。
 */
export function normalizeMetadataCheckState(state?: string | null): MetadataCheckStateKey | '' {
  const raw = String(state ?? '').trim();
  if (!raw) return '';
  const exact = STATE_KEY_ALIAS[raw] || STATE_KEY_ALIAS[raw.toUpperCase()];
  if (exact) return exact;
  for (const [kw, key] of STATE_KEY_FALLBACK) {
    if (raw.includes(kw)) return key;
  }
  return '';
}

/**
 * state → 展示口径；未识别时**保留后端原文**、按 info 展示。
 *
 * WHY 不显示「未知」：原文更有诊断价值，也不会让人以为前端把状态吞掉了。
 */
export function metadataCheckStateOf(state?: string | null): MetadataCheckStateView {
  const key = normalizeMetadataCheckState(state);
  if (key) return METADATA_CHECK_STATE_VIEW[key];
  const raw = String(state ?? '').trim();
  return { key: '', label: raw || '-', type: 'info', finished: false, active: false };
}

/**
 * 是否为活跃态（需 SSE 订阅 / 禁止删除）。
 *
 * 判据直接取词表的 `active` 字段，不再维护第二份集合——两处各写一份必然漂移
 * （曾出现「列表认 PAUSING 活跃、删除按钮却可点」的不一致）。
 * 未知状态按「不活跃」处理，避免把未知状态误判成运行中。
 */
export function isMetadataCheckStateActive(state?: string | null): boolean {
  return metadataCheckStateOf(state).active;
}

/**
 * 判断检查任务是否已执行结束（不代表通过）。
 *
 * WHY 与 isMetadataCheckAccepted 分开：页面「状态」列要显示「成功/失败」，而「能否入库」
 * 只看 accepted。把两者合成一个布尔是既有 bug 的根源（成功即放行）。
 * 兼容实测中文「成功」与文档英文 SUCCEEDED/SUCCESS/CANCELLED/FAILED。
 */
export function isMetadataCheckFinished(summary: MetadataCheckTaskSummary): boolean {
  return metadataCheckStateOf(summary?.state).finished;
}

/**
 * 检查任务列表查询参数；页码分页（2026-11-17 契约变更：cursor 模型废弃，改 page/pageSize）。
 *
 * CONSTRAINT 后端已废弃 cursor：**传 cursor 直接 400**（实测 `?cursor=NA==` → HTTP 400），
 * 旧游标补页逻辑必须整体移除。limit 仅作 pageSize 的兼容别名，新代码统一传 pageSize。
 * 旧版「单条响应被服务端页大小静默截断」的问题已消失：先过滤再分页，除末页外条数恒等于 pageSize。
 */
export interface MetadataCheckListParams {
  /** 页码，从 1 开始；必须大于 0（非法值后端 400） */
  page?: number;
  /** 每页条数 1–200，默认 20 */
  pageSize?: number;
  /** true 时包含已被入库/补录消费的检查单；默认 false（被引用的检查单隐藏） */
  includeConsumed?: boolean;
}

/** 页码分页响应壳（检查列表专用；total 是过滤 consumed/deleted 后的可见条数，不是任务表总数） */
export interface MetadataCheckListPage<T> {
  items: T[];
  page: number;
  pageSize: number;
  /** 可见检查单总数（不含被隐藏的已消费项，除非 includeConsumed=true） */
  total: number;
  totalPages: number;
  /** 是否还有下一页；超出末页 items 为空且 hasMore=false */
  hasMore: boolean;
  includeConsumed: boolean;
}

/**
 * 页码分页查询元数据文件检查任务列表。
 *
 * 排序 created_at DESC, check_uid DESC；页大小 1–200（越界 400，中文说明范围）。
 * includeConsumed 默认 false：被入库/补录引用的检查单不返回（23 条任务表 → 19 条可见是默认行为，
 * 不是数据丢失；审计口径需要全量时显式传 includeConsumed=true）。
 */
export function listMetadataFileChecks(params: MetadataCheckListParams = {}) {
  const query: { page: number; pageSize: number; includeConsumed?: boolean } = {
    page: Math.max(1, Math.trunc(Number(params.page ?? 1)) || 1),
    pageSize: Math.min(
      METADATA_CHECK_PAGE_MAX,
      Math.max(METADATA_CHECK_PAGE_MIN, Math.trunc(Number(params.pageSize ?? METADATA_CHECK_PAGE_DEFAULT)) || METADATA_CHECK_PAGE_DEFAULT)
    )
  };
  if (params.includeConsumed) query.includeConsumed = true;
  return apiGet<MetadataCheckListPage<MetadataCheckTaskSummary>>(CHECK_BASE, { params: query });
}

/**
 * 删除元数据文件检查任务（物理删除，用于清掉失败或不再需要的检查记录）。
 *
 * CONSTRAINT 状态门禁：统一任务处于 RUNNING / QUEUED / PAUSING 时后端返回 409
 * 「检查任务正在执行，请先取消再删除」；其余状态（含 SUCCEEDED 且结论不合格、FAILED）
 * 允许删除；账本行不存在时 404「元数据检查不存在」。
 * 响应 reportDeleted=false 表示磁盘报告未删除（仅记日志，不影响删除结论）。
 */
export function deleteMetadataFileCheck(checkUid: string) {
  return apiDelete<{ checkUid: string; taskState: string; reportDeleted: boolean }>(`${CHECK_BASE}/${checkUid}`);
}

/**
 * 检查清单（2026-11-18 实测契约，/platform/metadata/checks/manifests）
 *
 * CONSTRAINT 实测口径（10.61.129.27:19999/datamanage/api）：
 *   - GET 列表返回 { items, nextCursor, total }；items 内 task.uid 与检查任务的 taskUid 同值，
 *     故弹窗按 taskUid 过滤；limit 生效、includeDeleted=true 才返回软删除行；keyword 不生效；
 *   - DELETE /{manifestUid} 为软删除，响应 { deleted, deletedAt, manifestUid, task }；
 *   - POST 当前返回 405、GET /{manifestUid} 返回 404，故本门面只暴露列表与删除，
 *     不做前端造清单或单条详情，避免契约变动时静默 4xx。
 */
export interface MetadataManifestFile {
  fileName?: string;
  format?: string;
  formatName?: string;
  relativePath?: string;
  sha256?: string;
  sizeBytes?: number;
}

export interface MetadataManifestSummary {
  manifestUid: string;
  createdAt?: string;
  deletedAt?: string | null;
  fileCount?: number;
  totalBytes?: number;
  manifestSha256?: string;
  files?: MetadataManifestFile[];
  task?: { uid?: string; taskName?: string };
  [key: string]: unknown;
}

export interface MetadataManifestListResult {
  items: MetadataManifestSummary[];
  nextCursor?: string | null;
  total?: number;
}

/** 清单列表；taskUid 过滤、limit 上限、includeDeleted 皆按后端实测参数 */
export function listCheckManifests(params: { taskUid?: string; limit?: number; includeDeleted?: boolean } = {}) {
  const query: { taskUid?: string; limit?: number; includeDeleted?: boolean } = {};
  if (params.taskUid) query.taskUid = params.taskUid;
  if (typeof params.limit === 'number' && params.limit > 0) query.limit = Math.min(100, Math.max(1, Math.trunc(params.limit)));
  if (params.includeDeleted) query.includeDeleted = true;
  return apiGet<MetadataManifestListResult>(MANIFEST_BASE, { params: query });
}

/** 软删除单条清单；后端做状态门禁，失败原因由响应拦截器统一提示 */
export function deleteCheckManifest(manifestUid: string) {
  return apiDelete<{ deleted: boolean; deletedAt?: string; manifestUid: string; task?: { taskName?: string; uid?: string } }>(
    `${MANIFEST_BASE}/${seg(manifestUid)}`
  );
}

/**
 * 读取单个检查任务的阶段、文件级进度、结论、SHA-256、错误明细与报告摘要。
 *
 * 返回顶层 files（string[] 完整选择清单）/ checkedFiles / dataFiles / fileResults，
 * 以及规范名 categoryUid / dataRootPath（productCategoryUid / sourcePath 为兼容别名）。
 *
 * CONSTRAINT result.report.files 仍是对象数组，只是过渡期兜底，**不属于冻结公开契约**；
 * 新代码一律用顶层字段，不要再去 report.files 里取。
 */
export function getMetadataFileCheck(checkUid: string) {
  return apiGet<MetadataCheckTaskSummary>(`${CHECK_BASE}/${checkUid}`);
}
