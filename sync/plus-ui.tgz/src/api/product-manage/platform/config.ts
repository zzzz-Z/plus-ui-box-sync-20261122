/**
 * 配置类接口：能力登记 / 集成登记 / 配置类型与版本
 * 文档：综合管理.md 「配置类/通用配置」
 */
import type { CapabilityItem, ConfigTypeItem, ConfigVersionSummary, IntegrationItem } from '../types/platform';
import { apiDelete, apiGet, apiPatch, apiPost, apiPut } from '../http';

const CONFIG_BASE = '/platform/config';

/* -------- 能力登记 -------- */

export interface CapabilityListParams {
  /** 按启用状态过滤 */
  enabled?: boolean;
  /** 关键字（匹配能力编码/名称） */
  keyword?: string;
}

/** 查询能力登记列表 */
export function listCapabilities(params: CapabilityListParams = {}) {
  return apiGet<{ items: CapabilityItem[]; total: number }>(`${CONFIG_BASE}/capabilities`, { params });
}

/** 能力登记的新增/修改请求体 */
export interface CapabilityPayload {
  /** 能力编码（英文标识，唯一） */
  capabilityKey: string;
  /** 能力名称 */
  capabilityName: string;
  /** 能力描述 */
  description?: string;
  /** 是否启用（缺省由服务端决定） */
  enabled?: boolean;
}

/** 新增能力登记 */
export function createCapability(payload: CapabilityPayload) {
  return apiPost<CapabilityItem>(`${CONFIG_BASE}/capabilities`, payload);
}

/** 修改能力登记 */
export function updateCapability(configurationUid: string, payload: Partial<CapabilityPayload>) {
  return apiPatch<CapabilityItem>(`${CONFIG_BASE}/capabilities/${configurationUid}`, payload);
}

/** 删除能力登记 */
export function deleteCapability(configurationUid: string) {
  return apiDelete<{ configurationUid: string }>(`${CONFIG_BASE}/capabilities/${configurationUid}`);
}

/* -------- 集成登记 -------- */

export interface IntegrationListParams {
  /** 按启用状态过滤 */
  enabled?: boolean;
  /** 关键字（匹配集成编码/名称） */
  keyword?: string;
}

/** 查询集成登记列表 */
export function listIntegrations(params: IntegrationListParams = {}) {
  return apiGet<{ items: IntegrationItem[]; total: number }>(`${CONFIG_BASE}/integrations`, { params });
}

/** 集成登记的新增/修改请求体 */
export interface IntegrationPayload {
  /** 集成编码（英文标识，唯一） */
  integrationKey: string;
  /** 集成名称 */
  integrationName: string;
  /** 集成描述 */
  description?: string;
  /** 是否启用（缺省由服务端决定） */
  enabled?: boolean;
}

/** 新增集成登记 */
export function createIntegration(payload: IntegrationPayload) {
  return apiPost<IntegrationItem>(`${CONFIG_BASE}/integrations`, payload);
}

/** 修改集成登记 */
export function updateIntegration(configurationUid: string, payload: Partial<IntegrationPayload>) {
  return apiPatch<IntegrationItem>(`${CONFIG_BASE}/integrations/${configurationUid}`, payload);
}

/** 删除集成登记 */
export function deleteIntegration(configurationUid: string) {
  return apiDelete<{ configurationUid: string }>(`${CONFIG_BASE}/integrations/${configurationUid}`);
}

/* -------- 配置类型 -------- */

export function listConfigTypes() {
  return apiGet<{ items: ConfigTypeItem[]; total: number }>(`${CONFIG_BASE}/types`);
}

/** 查询某配置类型的当前生效内容 */
export function getConfigCurrent(type: string) {
  return apiGet<{ type: string; version: number; content: unknown }>(`${CONFIG_BASE}/types/${type}`);
}

/** 查询某配置类型的指定版本内容 */
export function getConfigVersion(type: string, version: number) {
  return apiGet<{ type: string; version: number; content: unknown }>(`${CONFIG_BASE}/types/${type}/versions/${version}`);
}

/** 查询某配置类型的版本历史 */
export function listConfigVersions(type: string) {
  return apiGet<{ items: ConfigVersionSummary[]; total: number }>(`${CONFIG_BASE}/types/${type}/versions`);
}

/** 保存配置版本（PUT 覆盖式写入）的请求体 */
export interface SaveConfigPayload {
  /** 配置内容（结构由各配置类型自定义） */
  content: unknown;
  /** 版本备注 */
  comment?: string;
}

/** 保存新版本配置（PUT 覆盖式写入） */
export function saveConfigVersion(type: string, payload: SaveConfigPayload) {
  return apiPut<ConfigVersionSummary>(`${CONFIG_BASE}/types/${type}`, payload);
}

/** 将指定版本设为当前生效版本 */
export function activateConfigVersion(type: string, version: number) {
  return apiPost<ConfigVersionSummary>(`${CONFIG_BASE}/types/${type}/versions/${version}/activate`);
}
