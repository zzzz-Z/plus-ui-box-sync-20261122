/**
 * 元数据变更向导接口层（真实契约，Apifox docId 532351495 / 532351496）
 *
 * plan 为只读影响计划，apply 在同一元数据库事务内落库 + 权威历史 + outbox。
 * 与已下线的 /platform/metadata/updates/preview|commit（batch-update.ts，本机 404）无关：
 * 实测 change-wizard/plan 与 /apply 路由真实存在（空 body 分别返回
 * INVALID_WIZARD_OPERATION / INVALID_UID 业务错），是数据更新向导唯一有效数据源。
 *
 * 字段全部照契约原文：resourceUid / tableKey / operation / metadataUids /
 * values / expectedRowVersions / lockToken（+ 可选 lockRevision/requestId/atomic/confirm）。
 * 不套 adapter、不改名透传；载荷只在本文件的 build*Payload 一处拼装。
 */
import { apiPost } from '../http';

const WIZARD_BASE = '/platform/metadata/change-wizard';

export type WizardOperation = 'update' | 'delete';

/** plan 契约请求（532351495） */
export interface ChangeWizardPlanInput {
  resourceUid: string;
  tableKey: string;
  operation: WizardOperation;
  metadataUids: string[];
  values?: Record<string, string>;
}

/** plan 契约单条变更明细 */
export interface WizardChange {
  fieldKey: string;
  label: string;
  changeType: 'added' | 'removed' | 'changed';
  beforeValue?: string;
  afterValue?: string;
}

/** plan 契约 steps[] 元素 */
export interface WizardStep {
  metadataUid: string;
  action: string;
  exists: boolean;
  rowVersion: number;
  changes: WizardChange[];
  proposedValues?: Record<string, string>;
}

/** plan 契约响应 data */
export interface ChangeWizardPlan {
  resourceUid: string;
  tableKey: string;
  operation: WizardOperation;
  steps: WizardStep[];
  summary: {
    requested: number;
    missing: number;
    requiresLock: boolean;
    availableAtomic: boolean;
  };
  next: string;
}

/** apply 契约请求（532351496） */
export interface ChangeWizardApplyInput {
  resourceUid: string;
  tableKey: string;
  operation: WizardOperation;
  metadataUids: string[];
  values?: Record<string, string>;
  /** 每条目标记录当前 rowVersion（乐观并发，不匹配 409） */
  expectedRowVersions: Record<string, number>;
  lockToken: string;
  lockRevision?: number;
  requestId?: string;
  atomic?: boolean;
  /** operation=delete 时契约要求 true */
  confirm?: boolean;
}

/** apply 契约响应 data（复用批量编辑事务结果） */
export interface WizardIssue {
  field?: string;
  reason?: string;
  metadataUid?: string;
}

export interface ChangeWizardApplyResult {
  requested: number;
  updated: number;
  failed: number;
  affected: number;
  valid: number;
  issues: WizardIssue[];
  preview?: unknown[];
  metadataUid?: string;
  historyUid?: string;
  historyUids?: string[];
  rowVersion?: number;
  updatedFields?: string[];
  indexState?: string;
  createdAt?: string;
  updatedAt?: string;
  deleted?: boolean | number | null;
}

/** values 串化：null/undefined → 空串，避免把 "null"/"undefined" 当真值写入（同契约字段值必须为 string） */
function stringifyValues(values?: Record<string, unknown>): Record<string, string> | undefined {
  if (!values) return undefined;
  const out: Record<string, string> = {};
  for (const [key, raw] of Object.entries(values)) out[key] = raw == null ? '' : String(raw);
  return out;
}

/** plan 载荷白名单拼装（唯一拼装处） */
export function buildWizardPlanPayload(input: ChangeWizardPlanInput): Record<string, unknown> {
  const payload: Record<string, unknown> = {
    resourceUid: input.resourceUid,
    tableKey: input.tableKey,
    operation: input.operation,
    metadataUids: input.metadataUids
  };
  const values = stringifyValues(input.values);
  if (values && Object.keys(values).length) payload.values = values;
  return payload;
}

/** apply 载荷白名单拼装（唯一拼装处） */
export function buildWizardApplyPayload(input: ChangeWizardApplyInput): Record<string, unknown> {
  const payload: Record<string, unknown> = {
    resourceUid: input.resourceUid,
    tableKey: input.tableKey,
    operation: input.operation,
    metadataUids: input.metadataUids,
    lockToken: input.lockToken,
    expectedRowVersions: input.expectedRowVersions
  };
  const values = stringifyValues(input.values);
  if (values && Object.keys(values).length) payload.values = values;
  if (input.lockRevision != null) payload.lockRevision = input.lockRevision;
  if (input.requestId) payload.requestId = input.requestId;
  if (input.atomic != null) payload.atomic = input.atomic;
  if (input.confirm != null) payload.confirm = input.confirm;
  return payload;
}

/** 只读影响计划（不写库） */
export function planChangeWizard(input: ChangeWizardPlanInput) {
  return apiPost<ChangeWizardPlan, Record<string, unknown>>(`${WIZARD_BASE}/plan`, buildWizardPlanPayload(input));
}

/** 应用变更（真实写操作，需先 acquireEditSession 拿 lockToken） */
export function applyChangeWizard(input: ChangeWizardApplyInput) {
  return apiPost<ChangeWizardApplyResult, Record<string, unknown>>(`${WIZARD_BASE}/apply`, buildWizardApplyPayload(input));
}
