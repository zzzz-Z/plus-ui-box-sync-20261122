/**
 * 安全策略设计接口
 *
 * 路径 /platform/metadata-security/policy；baseURL 由 request.ts 注入。
 * 复用 types.ts 已有的 SecurityPolicy，不重复定义。
 */
import { apiDelete, apiGet, apiPost, apiPut, seg } from '../http';
import type { SecurityPolicy } from '../types/platform';

const SECURITY_BASE = '/platform/metadata-security/policy';

/** 查询安全策略设计 */
export function listSecurityPolicies() {
  return apiGet<SecurityPolicy[]>(SECURITY_BASE);
}

/**
 * 保存安全策略设计
 *
 * @deprecated 契约已移除，保留仅为兼容；调用将抛出错误。
 */
export function createSecurityPolicy(payload: Omit<SecurityPolicy, 'policyUid'>) {
  void payload;
  throw new Error('createSecurityPolicy: 契约已移除，保留仅为兼容');
}

/** 修改安全策略设计 */
export function updateSecurityPolicy(policyUid: string, payload: Partial<SecurityPolicy>) {
  return apiPut<SecurityPolicy, Partial<SecurityPolicy>>(SECURITY_BASE + '/' + seg(policyUid), payload);
}

/**
 * 删除安全策略设计
 *
 * @deprecated 契约已移除，保留仅为兼容；调用将抛出错误。
 */
export function deleteSecurityPolicy(policyUid: string) {
  void policyUid;
  throw new Error('deleteSecurityPolicy: 契约已移除，保留仅为兼容');
}
