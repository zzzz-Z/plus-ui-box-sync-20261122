/**
 * 元数据库备份 / 恢复接口
 *
 * 契约来源：Apifox「元数据管理 / 元数据备份恢复」（docId 532352875–532352937）。
 * 全部接口走产品网关（http.ts 的 PRODUCT_BASE_URL = /dev-api/datamanage/api）；
 * clientid 请求头由 utils/request.ts 全局注入，业务层无需重复设置。
 *
 * 注意：备份是**元数据库整库级**操作，契约里没有 resourceUid 维度。
 * 左侧资源树（metadata/tree）仅用于展示「哪些资源在元数据库里」，不作为备份的过滤参数。
 */
import { apiDelete, apiGet, apiPost, apiPut, seg } from '../http';
import type {
  BackupCleanupPreview,
  BackupCleanupResult,
  BackupDetail,
  BackupDrillResult,
  BackupPolicy,
  BackupPolicyUpdate,
  BackupRestoreApplyResult,
  BackupRestoreConfirm,
  BackupRestorePreview,
  BackupRunResult,
  BackupSummary
} from '../types/platform';

const BACKUP_BASE = '/platform/metadata-io/backup';
const POLICY_PATH = `${BACKUP_BASE}/policy`;
const RUNS_PATH = `${BACKUP_BASE}/runs`;
const BACKUPS_PATH = `${BACKUP_BASE}/backups`;
const CLEANUP_PREVIEW_PATH = `${BACKUP_BASE}/cleanup-preview`;
const CLEANUP_PATH = `${BACKUP_BASE}/cleanup`;
const RESTORE_BASE = `${BACKUP_BASE}/restore`;

/** 读取备份策略（GET /backup/policy） */
export function getBackupPolicy() {
  return apiGet<BackupPolicy>(POLICY_PATH);
}

/** 更新备份策略（PUT /backup/policy）；未提交字段沿用原值 */
export function updateBackupPolicy(payload: BackupPolicyUpdate) {
  return apiPut<BackupPolicy, BackupPolicyUpdate>(POLICY_PATH, { policy: payload });
}

/** 立即执行一次备份（POST /backup/runs）；mode 缺省取策略 */
export function runBackupNow(payload: { mode?: BackupPolicy['mode'] } = {}) {
  return apiPost<BackupRunResult, { mode?: BackupPolicy['mode'] }>(RUNS_PATH, payload);
}

/** 列出备份（GET /backup/backups）；分页字段契约用 page/pageSize */
export function listBackups(params: { page?: number; pageSize?: number } = {}) {
  return apiGet<{ items: BackupSummary[]; total: number; page?: number; pageSize?: number }>(BACKUPS_PATH, { params });
}

/** 读取备份详情（GET /backup/backups/{backupUid}） */
export function getBackupDetail(backupUid: string) {
  return apiGet<BackupDetail>(`${BACKUPS_PATH}/${seg(backupUid)}`);
}

/** 重命名备份（POST /backup/backups/{backupUid}/rename） */
export function renameBackup(backupUid: string, name: string) {
  return apiPost<{ backupUid: string; name: string; renamed: boolean }, { name: string }>(`${BACKUPS_PATH}/${seg(backupUid)}/rename`, { name });
}

/** 删除备份（DELETE /backup/backups/{backupUid}）；契约要求 body { confirm: true } */
export function deleteBackup(backupUid: string) {
  return apiDelete<{ backupUid: string; deleted: boolean; note?: string }>(`${BACKUPS_PATH}/${seg(backupUid)}`, { data: { confirm: true } });
}

/** 预览按策略清理（POST /backup/cleanup-preview），无 body */
export function previewCleanup() {
  return apiPost<BackupCleanupPreview>(CLEANUP_PREVIEW_PATH);
}

/** 执行备份清理（POST /backup/cleanup）；契约要求 body { confirm: true } */
export function executeCleanup() {
  return apiPost<BackupCleanupResult, { confirm: boolean }>(CLEANUP_PATH, { confirm: true });
}

/** 备份演练核验（POST /backup/backups/{backupUid}/drill），只读不恢复 */
export function drillBackup(backupUid: string) {
  return apiPost<BackupDrillResult>(`${BACKUPS_PATH}/${seg(backupUid)}/drill`);
}

/** 恢复向导：预览计划（POST /backup/restore/preview） */
export function previewRestore(backupUid: string) {
  return apiPost<BackupRestorePreview, { backupUid: string }>(`${RESTORE_BASE}/preview`, { backupUid });
}

/** 恢复向导：确认计划（POST /backup/restore/confirm） */
export function confirmRestore(planToken: string) {
  return apiPost<BackupRestoreConfirm, { planToken: string }>(`${RESTORE_BASE}/confirm`, { planToken });
}

/** 恢复向导：执行受控恢复（POST /backup/restore/apply）；dryRun 也消耗 confirmationToken */
export function applyRestore(payload: { confirmationToken: string; confirm: true; dryRun?: boolean }) {
  return apiPost<BackupRestoreApplyResult, typeof payload>(`${RESTORE_BASE}/apply`, payload);
}

/* -------- 旧接口兼容别名：旧调用方若仍存在，映射到新契约 -------- */

/** @deprecated 契约已无「策略列表」，改调 getBackupPolicy() */
export function listBackupPolicies() {
  return getBackupPolicy().then((res) => ({ ...res, data: [res.data] }));
}

/** @deprecated 契约已移除创建策略接口，保留仅为兼容；调用将抛出错误 */
export function createBackupPolicy(payload: unknown) {
  void payload;
  throw new Error('createBackupPolicy: 契约已移除，保留仅为兼容');
}

/** @deprecated 契约已移除删除策略接口，保留仅为兼容；调用将抛出错误 */
export function deleteBackupPolicy(policyUid: string) {
  void policyUid;
  throw new Error('deleteBackupPolicy: 契约已移除，保留仅为兼容');
}

/** @deprecated createBackupTask 更名为 runBackupNow() */
export const createBackupTask = runBackupNow;

/** @deprecated createRestoreTask 已拆为 previewRestore / confirmRestore / applyRestore 三步 */
export function createRestoreTask(backupUid: string) {
  return previewRestore(backupUid);
}
