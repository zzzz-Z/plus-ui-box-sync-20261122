/**
 * 元数据查询接口族（v6 契约）：查询选项 / 统一查询 / 选择集 / 范围导入 / 报表
 *
 * 契约来源：Apifox「元数据管理模块/元数据/元数据查询」，baseURL 由 http.ts 的 withProductBase 注入。
 * 快照：`artifacts/metadata-edit-query/01-contract/api-531574885.md` 等 8 份（原样存，未改写）。
 *
 * 前缀：`/platform/metadata-records/query...`
 *
 * ## 为什么必须新建文件，而不是改 `unified-query.ts`
 *
 * `unified-query.ts` 里原本那条查询门面打的是旧「统一查询」前缀 —— **实测 HTML 404，路径根本不存在**。
 * 那条门面是早期按设计稿写的，后端最终落地的路径是 `/platform/metadata-records/query`。
 * 两者字段名也完全不同（旧载荷是 `view` + `scope`，新契约 `additionalProperties:false` 只认 24 个具名成员，
 * 载荷里带 `view`/`scope` 必然被拒）。故不兼容改写，而是新建独立门面，旧门面按影响面表处置。
 * 旧路径字面量与旧函数名的完整清单见 `artifacts/metadata-edit-query/02-impact.md`。
 *
 * ## 实测事实（2026-11-03，见 artifacts/metadata-edit-query/04-probe.log）
 *
 * 8 个接口**路径全部已上线**，但全部被平台权限门拦住：
 * `HTTP 403 / code=40301 / errorCode=METADATA_PERMISSION_REQUIRED`，缺 `metadata.query` 权限。
 * 若依侧 admin 的 `*:*:*` 对该门**无效**（那是 Java 侧权限，C++ 侧另有一套）。
 *
 * ## 关键契约纪律（写错了页面必然 400）
 *
 * 1. **`POST /query` 顶层 `additionalProperties: false`** —— 只允许 `payload` 里列出的成员。
 *    旧门面的 `view` / `scope` / `size` **不在白名单**，带上去就会被拒。翻页字段叫 `pageSize` 不是 `size`。
 * 2. **分页是 `page` / `pageSize`**（1–200，默认 20），不是项目的 `pageNum`。
 *    页面禁用 Table 的 params 直接透传，必须过 `buildMetadataQueryPayload()` 的白名单。
 * 3. **`state` 入参是英文枚举**（`pending`/`ready`/`failed`），而出参 `/platform/resources` 的 `state` 是**中文**
 *    （「就绪」）。两者必须经 `STATE_ALIAS` 归一，绝不能把中文状态塞进入参 —— 这是历史踩过的坑
 *    （refs/pitfalls.md §B「状态列全显示未知 + 按钮全灰」）。
 * 4. **`queryToken` 是跨页游标**：上一页返回后翻页须原样回传，否则翻页语义不成立（服务端会退回从头查）。
 * 5. **选择集 / 报表都要先有 `queryToken`**：它们是「查询结果之上的二次操作」，依赖查询令牌。
 */
import type {
  MetadataQueryPayload,
  MetadataQueryResult,
  MetadataQueryOptions,
  MetadataSelectionResult,
  MetadataSelectionOperation,
  MetadataQueryTaskAccepted,
  MetadataQueryTaskProgress
} from '../types/platform';
import { apiGet, apiPost } from '../http';

const QUERY_BASE = '/platform/metadata-records/query';

/** 业务码：权限不足（40301）；页面据此提示「待开通 metadata.query 权限」而非「系统异常」 */
export const METADATA_QUERY_PERMISSION_CODE = 40301;

/** 单页条数上限（契约 1–200） */
export const METADATA_QUERY_PAGE_SIZE_MAX = 200;
/** 单页条数默认值（契约默认 20） */
export const METADATA_QUERY_PAGE_SIZE_DEFAULT = 20;

/**
 * 查询入参 state 的中英归一表。
 *
 * WHY：契约入参是 `pending` / `ready` / `failed`（英文），而 `/platform/resources` 的出参 state
 * 实测是「就绪」「待处理」这类**中文**。页面两处都用，若不归一，把出参值直接回填筛选框就会失配，
 * 表现为「筛选项选了却没结果」或「状态列全未知」。
 *
 * 归一口径：**英文为内部键**，中文只在下拉展示时使用。
 */
export const STATE_ALIAS: Record<string, 'pending' | 'ready' | 'failed'> = {
  pending: 'pending',
  ready: 'ready',
  failed: 'failed',
  // 中文出参 → 英文内部键（覆盖 /platform/resources 实测值与常见同义词）
  待处理: 'pending',
  等待中: 'pending',
  排队中: 'pending',
  就绪: 'ready',
  已完成: 'ready',
  成功: 'ready',
  失败: 'failed',
  异常: 'failed',
  错误: 'failed'
};

/**
 * 把任意来源的状态值归一到契约入参枚举。
 *
 * 保守兜底：**未列举的值返回 undefined**（不猜），让调用方丢弃该过滤条件，
 * 而不是默认塞 `ready` —— 默认归 ready 会把「筛选失败」悄悄变成「筛选成功」，比不筛更糟。
 */
export function normalizeQueryState(value?: string | null): 'pending' | 'ready' | 'failed' | undefined {
  if (!value) return undefined;
  const key = String(value).trim();
  return STATE_ALIAS[key] ?? undefined;
}

/**
 * 查询载荷的**唯一拼装处**。
 *
 * 页面只传业务输入（关键字 / 类别 / 空间范围 / 分页），契约字段名一律在此映射。
 * 三条纪律写进代码而不是注释：白名单字段、`pageSize` 改名、`state` 归一。
 */
export interface MetadataQueryInput {
  /** 页码，从 1 开始 */
  page?: number;
  /** 每页条数 1–200 */
  pageSize?: number;
  /** 关键字 */
  keyword?: string;
  /** 产品类别 UID 列表（**不是**类别编码） */
  categoryUids?: string[];
  /** 资源 UID 列表（**不是**模型 uid） */
  resourceUids?: string[];
  /** 模型表键列表 */
  tableKeys?: string[];
  /** 资源状态；接受中文或英文，内部统一归一为英文枚举 */
  state?: string;
  /** 空间范围 [minLon, minLat, maxLon, maxLat] */
  bbox?: number[];
  /** 跨页游标：翻页时回传上一页的 queryToken */
  queryToken?: string;
  /** 是否返回几何 */
  includeGeometry?: boolean;
  /** 是否返回字段定义（默认 true） */
  includeFieldSchema?: boolean;
  /** 字段过滤（透传给契约同名结构，不做二次解释） */
  fieldFilters?: MetadataQueryPayload['fieldFilters'];
  /** 空间条件（复杂空间查询直接给契约结构，避免本层再造一层语义） */
  spatial?: MetadataQueryPayload['spatial'];
  /**
   * 行政区划 UID（A1 增量，2026-11-10）：服务端按 UID 取 EPSG:4326 边界注入空间过滤。
   * 与 spatial 互斥（同时提供后端 400 METADATA_QUERY_INVALID）；非 UUID / 不存在 / 无几何 → 400。
   */
  administrativeDivisionUid?: string;
  /** 排序 */
  sort?: MetadataQueryPayload['sort'];
}

export function buildMetadataQueryPayload(input: MetadataQueryInput = {}): MetadataQueryPayload {
  const rawPage = Number(input.page ?? 1);
  const rawSize = Number(input.pageSize ?? METADATA_QUERY_PAGE_SIZE_DEFAULT);
  const page = Number.isFinite(rawPage) && rawPage > 0 ? Math.trunc(rawPage) : 1;
  const pageSize = Number.isFinite(rawSize)
    ? Math.min(METADATA_QUERY_PAGE_SIZE_MAX, Math.max(1, Math.trunc(rawSize)))
    : METADATA_QUERY_PAGE_SIZE_DEFAULT;

  // 必填项先落，其余按「有值才带」——空数组/空串一律不带，避免服务端把空条件当成「必须为空」
  const payload: MetadataQueryPayload = { page, pageSize };

  const keyword = input.keyword?.trim();
  if (keyword) payload.keyword = keyword;
  if (input.categoryUids?.length) payload.categoryUids = input.categoryUids;
  if (input.resourceUids?.length) payload.resourceUids = input.resourceUids;
  if (input.tableKeys?.length) payload.tableKeys = input.tableKeys;

  const state = normalizeQueryState(input.state);
  if (state) payload.state = state;

  if (input.bbox?.length === 4) {
    payload.spatial = { type: 'bbox', srid: 4326, bbox: input.bbox };
  }
  // 调用方显式给了 spatial 就优先（复杂空间查询：polygon/circle/adminArea/mapSheets/coordinateRanges…）
  if (input.spatial) payload.spatial = input.spatial;

  // 行政区划 UID 过滤（A1 增量）：服务端按 UID 取边界注入空间谓词。
  // 与 spatial 互斥（同时提供后端 400 METADATA_QUERY_INVALID），由调用方保证二选一；本层仅做白名单透传。
  if (input.administrativeDivisionUid) payload.administrativeDivisionUid = input.administrativeDivisionUid;

  if (input.queryToken) payload.queryToken = input.queryToken;
  if (input.includeGeometry != null) payload.includeGeometry = input.includeGeometry;
  if (input.includeFieldSchema != null) payload.includeFieldSchema = input.includeFieldSchema;
  if (input.fieldFilters?.length) payload.fieldFilters = input.fieldFilters;
  if (input.sort?.length) payload.sort = input.sort;

  return payload;
}

/** 查询下拉选项（类别 / 版本 / 模型 / 表与字段定义）；替代前端「类别树 + 资源列表」拼装方案 */
export function getMetadataQueryOptions() {
  return apiGet<MetadataQueryOptions>(`${QUERY_BASE}/options`);
}

/**
 * 统一查询。
 *
 * 注意返回的 `queryToken` 是**跨页游标**：后续翻页、建选择集、建报表都要用它，
 * 调用方必须持有并回传，不能每次重新起查。
 */
export function queryMetadataRecords(input: MetadataQueryInput = {}) {
  return apiPost<MetadataQueryResult, MetadataQueryPayload>(QUERY_BASE, buildMetadataQueryPayload(input));
}

/** 选择集操作的业务输入 */
export interface SelectionInput {
  /** 查询令牌；必填，来自 queryMetadataRecords 的返回值 */
  queryToken: string;
  operation: MetadataSelectionOperation;
  /** 具体要素 UUID 列表；operation=all/none/invert 时可省略 */
  featureUids?: string[];
  /** 期望的选择集版本；用于并发保护 */
  expectedRevision?: number;
}

/** 选择集载荷（唯一拼装处） */
export function buildSelectionPayload(input: SelectionInput) {
  if (!input?.queryToken) throw new Error('选择集操作必须提供 queryToken（先执行一次查询）');
  if (!input.operation) throw new Error('选择集操作必须指定 operation');
  const payload: Record<string, unknown> = { queryToken: input.queryToken, operation: input.operation };
  if (input.featureUids?.length) payload.featureUids = input.featureUids;
  if (input.expectedRevision != null) payload.expectedRevision = Math.max(0, Math.trunc(Number(input.expectedRevision)));
  return payload;
}

/** 选择集操作（replace/add/subtract/intersect/invert/all/none） */
export function applyQuerySelection(input: SelectionInput) {
  return apiPost<MetadataSelectionResult, ReturnType<typeof buildSelectionPayload>>(`${QUERY_BASE}/selection`, buildSelectionPayload(input));
}

/**
 * 范围文件导入（multipart/form-data）。
 *
 * 支持 TXT / CSV / XLSX，或包含 SHP / FileGDB 的 ZIP。
 * WHY 不手写 `Content-Type: multipart/form-data`：boundary 必须由浏览器/axios 生成，
 * 手写会导致「丢 boundary 报 400」（refs/pitfalls.md §B）。
 * 成功后返回 `taskUid`（轮询状态）+ `importToken`（ready 后供查询使用）。
 */
export function importQueryScope(file: File, options: { kind?: 'coordinates' | 'ranges'; queryToken?: string; name?: string } = {}) {
  const form = new FormData();
  form.append('file', file);
  if (options.kind) form.append('kind', options.kind);
  if (options.queryToken) form.append('queryToken', options.queryToken);
  if (options.name) form.append('name', options.name);
  return apiPost<MetadataQueryTaskAccepted, FormData>(`${QUERY_BASE}/import`, form);
}

/** 查询导入任务状态（`state` 为 `ready` 时 `importToken` 才可用于查询） */
export function getImportTaskStatus(taskUid: string) {
  return apiGet<MetadataQueryTaskProgress>(`${QUERY_BASE}/import/${taskUid}`);
}

/** 创建查询报表任务的业务输入 */
export interface QueryReportInput {
  queryToken: string;
  /** 仅支持 html（契约唯一枚举值） */
  format?: 'html';
  /** 选择集令牌；限定报表范围 */
  selectionToken?: string;
  /** 报表包含的字段键列表 */
  fields?: string[];
  title?: string;
}

/** 报表载荷（唯一拼装处；`format` 默认 html 且不接受其它值） */
export function buildQueryReportPayload(input: QueryReportInput) {
  if (!input?.queryToken) throw new Error('创建报表任务必须提供 queryToken（先执行一次查询）');
  const payload: Record<string, unknown> = {
    queryToken: input.queryToken,
    format: input.format || 'html'
  };
  if (input.selectionToken) payload.selectionToken = input.selectionToken;
  if (input.fields?.length) payload.fields = input.fields;
  if (input.title) payload.title = input.title;
  return payload;
}

/** 创建查询报表任务（返回 202 受理，`reportTaskUid` 用于轮询与下载） */
export function createQueryReportTask(input: QueryReportInput) {
  return apiPost<MetadataQueryTaskAccepted, ReturnType<typeof buildQueryReportPayload>>(`${QUERY_BASE}/report`, buildQueryReportPayload(input));
}

/** 查询报表任务状态 */
export function getQueryReportTaskStatus(reportTaskUid: string) {
  return apiGet<MetadataQueryTaskProgress>(`${QUERY_BASE}/report/${reportTaskUid}`);
}

/**
 * 下载报表产物（HTML）。
 *
 * WHY `responseType: 'blob'`：这是文件下载不是 JSON 业务体；响应拦截器对 blob 直接返回 res.data，
 * 调用方拿到的是 Blob，自行用 download 插件落盘。
 */
export function downloadQueryReport(reportTaskUid: string) {
  return apiGet<Blob>(`${QUERY_BASE}/report/${reportTaskUid}/download`, { responseType: 'blob' });
}
