/**
 * 元数据模型表选项聚合
 *
 * 表只在模型详情响应里，列表仅给 tableCount，故先取列表再并发取详情。
 * 直接消费后端字段（tableKey / tableName），不做前端字段映射。
 */
import { getMetadataModelDetail, getMetadataModelList } from './metadata';

/** 跨模型的扁平表项，供浏览/编辑面板的下拉与动态列渲染消费 */
export interface ModelTableOption {
  /** 所属模型 uid */
  modelUid: string;
  /** 模型名称 */
  modelName: string;
  /** 模型所属元数据类别 */
  modelCategory?: string;
  /** 表 uid */
  tableUid: string;
  /** 表名 */
  tableName: string;
  /** 表字段定义（透传后端结构，此处不约束形状） */
  fields: any[];
}

/**
 * 聚合全部模型的表选项。
 *
 * 后端列表接口一次性返回全部模型（无分页），无需 pageSize。
 */
export async function listModelTableOptions(): Promise<any> {
  const listRes: any = await getMetadataModelList();
  const models: any[] = listRes?.data?.items ?? [];
  const details: any[] = await Promise.all(models.map((model: any) => getMetadataModelDetail(model.modelUid)));
  const items: ModelTableOption[] = [];
  details.forEach((detail: any) => {
    const model = detail?.data;
    if (!model) return;
    for (const table of model.tables ?? []) {
      items.push({
        modelUid: model.modelUid,
        modelName: model.modelName,
        modelCategory: model.modelCategory,
        tableUid: String(table.tableKey ?? ''),
        tableName: String(table.tableName ?? ''),
        fields: table.fields ?? []
      });
    }
  });
  return { code: 0, message: 'ok', data: { items, total: items.length } };
}
