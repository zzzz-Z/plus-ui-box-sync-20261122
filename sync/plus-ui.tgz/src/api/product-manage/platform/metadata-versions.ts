/**
 * 元数据记录版本接口族（契约 v6）：版本列表 / 版本快照 / 版本比较 / 版本恢复
 *
 * 契约来源：Apifox「元数据管理模块/元数据/元数据版本管理」，在线 SSOT 快照原样留存于
 * .dsh/artifacts/version-manage/01-contract/api-532351480.md、483、485、486（4 份）。
 * 这 4 个接口 `x-apifox-status: released`（已上线）—— 与「模型版本历史」526465623 等
 * `design-not-implemented` 的设计态新能力不同，版本管理页只以这 4 个已上线接口为数据源。
 *
 * 路径前缀与 metadata-records.ts 完全一致：`/platform/resources/{resourceUid}/metadata-tables/{tableKey}/...`
 * 记录主键是 metadataUid（不是旧版 recordUid），版本号是 rowVersion（正整数，列表按倒序）。
 * clientid 请求头由 request 拦截器统一注入，与编辑族接口口径一致，页面不重复拼装。
 *
 * ## 载荷只有一个拼装处（frontend-api-sync-e2e SKILL 铁律）
 * 比较 query 与恢复 body 一律经 buildMetadataVersionCompareQuery / buildMetadataVersionRestorePayload
 * 产出；页面禁止自拼 fromVersion / expectedRowVersion —— 契约变更后多处副本必然漏改。
 */
import { apiGet, apiPost, seg } from '../http';

const RESOURCE_BASE = '/platform/resources';

/** 版本族路径；resourceUid 与 tableKey 缺一即路径不成立 */
function versionsBase(resourceUid: string, tableKey: string) {
  return `${RESOURCE_BASE}/${seg(resourceUid)}/metadata-tables/${seg(tableKey)}`;
}

/* ------------------------------------------------------------------ */
/* 契约类型（逐字段对齐在线文档，可选性以 required 为准）              */
/* ------------------------------------------------------------------ */

/** 记录版本历史摘要（契约 532351480）：不含前后值，前后值走快照 / 比较接口 */
export interface MetadataVersionItem {
  /** 版本号（= rowVersion，正整数）；后端真实出参缺此字段时由 rowVersion 归一化补齐 */
  versionNo: number;
  createdAt?: string;
  createdByRef?: string;
  /** 变更字段键（fieldKey 数组） */
  changeFields?: string[];
  /** create / update / delete / undo / restore（中文 operation 已归一化成英文） */
  operation?: string;
  /* —— 后端真实出参（docId 532351480 实现与文档不一致，保留原始字段便于核对）—— */
  /** 后端真实行版本号，versionNo 的回退源 */
  rowVersion?: number;
  /** 后端真实操作人链（JSON 字符串），createdByRef 的回退源 */
  actor?: string;
  /** 后端真实变更字段（对象数组，自带中文 label） */
  changedFields?: Array<{ fieldKey?: string; label?: string; column?: string; valueType?: string }>;
  /** 由 changedFields 提取的 fieldKey → 中文标签，供页面优先展示 */
  changeFieldLabels?: Record<string, string>;
}

/** 版本列表响应（契约 items/total 必填，page/pageSize 可选） */
export interface MetadataVersionListResult {
  items: MetadataVersionItem[];
  total: number;
  page?: number;
  pageSize?: number;
}

/** 版本快照（契约 532351483：versionNo / values 必填，墓碑 deleted=true 时 values 可能残缺） */
export interface MetadataVersionSnapshot {
  versionNo: number;
  values: Record<string, unknown>;
  /** EPSG:4326 几何（契约 geometry 为 object） */
  geometry?: Record<string, unknown>;
  createdAt?: string;
  createdByRef?: string;
  deleted?: boolean;
}

/** 版本比较的逐字段差异（契约 532351485） */
export interface MetadataVersionChange {
  fieldKey: string;
  /** 冻结模型里的中文标签 */
  label?: string;
  from?: unknown;
  to?: unknown;
  /** 新增 / 删除 / 变化 / 未变 */
  operation?: string;
  /* —— 后端真实出参别名（与 beforeValues/afterValues 字典一起兼容，见 normalizeCompareResult）—— */
  before?: unknown;
  after?: unknown;
  beforeValue?: unknown;
  afterValue?: unknown;
  op?: string;
}

export interface MetadataVersionCompareResult {
  fromVersion: number;
  toVersion: number;
  changes: MetadataVersionChange[];
  summary?: Record<string, number>;
  /* —— 后端可能整包返回的值字典（与历史接口同风格）—— */
  beforeValues?: Record<string, unknown>;
  afterValues?: Record<string, unknown>;
  changedFields?: Array<{ fieldKey?: string; label?: string }>;
}

/** 恢复业务输入（契约 532351486）：need 编辑锁 + 当前行版本作并发判据 */
export interface MetadataVersionRestoreInput {
  lockToken: string;
  /** 当前 rowVersion，不匹配服务端 409 */
  expectedRowVersion: number;
  requestId?: string;
}

export interface MetadataVersionRestoreResult {
  versionNo: number;
  rowVersion: number;
  restoredFromVersion?: number;
  indexState?: string;
}

/* ------------------------------------------------------------------ */
/* 载荷构造（唯一拼装处）                                              */
/* ------------------------------------------------------------------ */

/** 比较 query：契约 fromVersion/toVersion 是 string，统一在此转换 */
export function buildMetadataVersionCompareQuery(fromVersion: number, toVersion: number) {
  return { fromVersion: String(fromVersion), toVersion: String(toVersion) };
}

/** 恢复 body：白名单透传，ID 仅在给出时携带 */
export function buildMetadataVersionRestorePayload(input: MetadataVersionRestoreInput) {
  const payload: MetadataVersionRestoreInput = {
    lockToken: input.lockToken,
    expectedRowVersion: Math.max(1, Math.trunc(Number(input.expectedRowVersion)))
  };
  if (input.requestId) payload.requestId = input.requestId;
  return payload;
}

/* ------------------------------------------------------------------ */
/* 出参归一化（后端实现 vs 契约文档差异的兼容层）                      */
/* ------------------------------------------------------------------ */

/**
 * 列表接口（docId 532351480）后端真实出参与 Apifox 文档不一致，此处单点归一化：
 *   - rowVersion        → versionNo（文档说 versionNo，后端只给 rowVersion）
 *   - changedFields[]   → changeFields: string[]（文档说 fieldKey 数组，后端给对象数组）
 *   - 中文 operation    → 英文枚举（文档说 create/update/...，后端给「更新」等中文）
 *   - actor（JSON 串）  → createdByRef
 * 保留原始字段于 item 上便于核对；后端若哪天按文档修正，?? 回退天然兼容，无需再改。
 */
const CN_OPERATION: Record<string, string> = {
  创建: 'create',
  新增: 'create',
  更新: 'update',
  修改: 'update',
  删除: 'delete',
  撤销: 'undo',
  恢复: 'restore'
};

function normalizeOperation(op?: string): string | undefined {
  if (!op) return op;
  return CN_OPERATION[op] ?? op;
}

/** actor 后端返回 JSON 数组串（含空占位项），只在回退 createdByRef 时可读化 */
function readableActor(raw: Record<string, any>): string | undefined {
  if (raw.createdByRef != null) return raw.createdByRef;
  if (typeof raw.actor !== 'string') return raw.actor;
  try {
    const parsed = JSON.parse(raw.actor);
    if (Array.isArray(parsed)) {
      const parts = parsed.map((x) => String(x ?? '').trim()).filter(Boolean);
      return parts.join(' / ') || undefined;
    }
    return String(parsed);
  } catch {
    return raw.actor;
  }
}

function normalizeVersionItem(raw: Record<string, any>): MetadataVersionItem {
  const versionNo = Number(raw.versionNo ?? raw.rowVersion);
  const changedFields = Array.isArray(raw.changedFields) ? raw.changedFields : [];
  const changeFields = Array.isArray(raw.changeFields) ? raw.changeFields : changedFields.map((c: any) => c?.fieldKey).filter(Boolean);
  const changeFieldLabels: Record<string, string> = {};
  for (const c of changedFields) {
    if (c?.fieldKey && c?.label) changeFieldLabels[c.fieldKey] = c.label;
  }
  return {
    ...raw,
    versionNo: Number.isFinite(versionNo) ? versionNo : 0,
    changeFields,
    operation: normalizeOperation(raw.operation),
    createdByRef: readableActor(raw),
    changedFields,
    changeFieldLabels
  } as MetadataVersionItem;
}

/**
 * 比较接口（docId 532351485）后端真实出参与契约 example 不一致，单点归一化：
 *   - 变更项数组：文档/后端可能用 changes 或 changedFields（对象数组，含 fieldKey/label）
 *   - 前后值：文档 example 写 from/to；后端这套系统（见 history 契约 531665055）实际用
 *     before/after、beforeValue/afterValue 或整包 beforeValues/afterValues 字典
 *   - operation：文档说英文枚举，后端可能给中文（「修改」「未变」等）
 * 契约字段优先，别名/字典兜底；后端哪天按文档修正，?? 回退天然兼容。
 */
function normalizeCompareResult(raw: any): MetadataVersionCompareResult {
  const data: any = raw ?? {};
  const rawChanges: any[] = Array.isArray(data.changes) ? data.changes : Array.isArray(data.changedFields) ? data.changedFields : [];
  const beforeValues: Record<string, unknown> = data.beforeValues ?? {};
  const afterValues: Record<string, unknown> = data.afterValues ?? {};
  const changes = rawChanges.map((c: any) => {
    const fieldKey = String(c.fieldKey ?? c.column ?? c.key ?? '');
    const from = c.from ?? c.before ?? c.beforeValue ?? beforeValues[fieldKey];
    const to = c.to ?? c.after ?? c.afterValue ?? afterValues[fieldKey];
    const op = normalizeOperation(c.operation ?? c.op ?? c.changeType ?? c.type);
    return { ...c, fieldKey, from, to, operation: op } as MetadataVersionChange;
  });
  return { ...data, changes } as MetadataVersionCompareResult;
}

/* ------------------------------------------------------------------ */
/* 查询门面（只读）                                                    */
/* ------------------------------------------------------------------ */

/**
 * 记录版本列表。
 *
 * 分页参数是 `page` / `pageSize`（不是页面通用 pageNum），显式白名单避免 Table 的 params
 * 改名透传被后端忽略；契约上限 pageSize ≤ 200。
 */
export function listMetadataVersions(resourceUid: string, tableKey: string, metadataUid: string, params: { page?: number; pageSize?: number } = {}) {
  const query: Record<string, number> = {};
  if (params.page != null) query.page = Math.max(1, Math.trunc(Number(params.page)));
  if (params.pageSize != null) query.pageSize = Math.min(200, Math.max(1, Math.trunc(Number(params.pageSize))));
  return apiGet<MetadataVersionListResult>(`${versionsBase(resourceUid, tableKey)}/records/${seg(metadataUid)}/versions`, {
    params: query
  }).then((res) => {
    const data = res?.data;
    if (data?.items) {
      data.items = data.items.map((it: any) => normalizeVersionItem(it));
    }
    return res;
  });
}

/** 指定版本快照（冻结模型字段值 + 几何）；versionNo 为正整数路径参数 */
export function getMetadataVersionSnapshot(resourceUid: string, tableKey: string, metadataUid: string, versionNo: number) {
  return apiGet<MetadataVersionSnapshot>(`${versionsBase(resourceUid, tableKey)}/records/${seg(metadataUid)}/versions/${seg(String(versionNo))}`);
}

/** 逐字段比较两个版本（相差的字段、中文标签、前后值） */
export function compareMetadataVersions(resourceUid: string, tableKey: string, metadataUid: string, fromVersion: number, toVersion: number) {
  return apiGet<MetadataVersionCompareResult>(`${versionsBase(resourceUid, tableKey)}/records/${seg(metadataUid)}/versions/compare`, {
    params: buildMetadataVersionCompareQuery(fromVersion, toVersion)
  }).then((res) => {
    if (res?.data) res.data = normalizeCompareResult(res.data);
    return res;
  });
}

/* ------------------------------------------------------------------ */
/* 写门面                                                              */
/* ------------------------------------------------------------------ */

/**
 * 恢复到指定版本：生成 row_version = 当前 + 1 的新版本，不是回滚覆盖历史。
 * 调用方必须先用 withEditLock 取锁（见 metadata-records.ts 的三级前置条件）。
 */
export function restoreMetadataVersion(
  resourceUid: string,
  tableKey: string,
  metadataUid: string,
  versionNo: number,
  input: MetadataVersionRestoreInput
) {
  return apiPost<MetadataVersionRestoreResult>(
    `${versionsBase(resourceUid, tableKey)}/records/${seg(metadataUid)}/versions/${seg(String(versionNo))}/restore`,
    buildMetadataVersionRestorePayload(input)
  );
}
