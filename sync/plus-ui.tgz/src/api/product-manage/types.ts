/**
 * 元数据管理领域类型（历史带后缀路径 shim）
 *
 * 消费方写 '@/api/product-manage/types.ts' 时，Vite 不做目录补全，
 * 而 types 实际是目录（实现在 types/index.ts）。此文件承接该后缀写法，避免解析失败。
 */
export * from './types/index';
