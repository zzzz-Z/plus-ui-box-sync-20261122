/**
 * 兼容旧引用路径（成果模块内存 mock 库）。
 *
 * mock 数据已经拆到 `./mock/result-db`，但 `result-product` 下仍有
 * `await import('@/api/product-manage/result-mock')` 取 `resultMockDb` 的历史写法。
 * 这里只做转发，避免重复维护。
 */
export * from './mock/result-db';
