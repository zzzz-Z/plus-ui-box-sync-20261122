import request from '@/utils/request';

/**
 * 作业资料管理接口
 * 申请域 / 接收域来自 ruoyi-task-manage 的 JobDataApplyController、JobDataReceiveController；
 * 资料目录查询与推送执行来自对外接口 JobDataOpenController（/resource/workdata）。
 */
const BASE = '/dolphinscheduler/job-data';
const OPEN_BASE = '/dolphinscheduler/resource/workdata';

/** 申请单查询参数 */
export interface JobDataQuery {
  /** 申请单号 / 标题 / 任务名称 模糊查询 */
  searchName?: string;
  /** QQPT=向综合调度与运维管理系统申请，BIZ=工程内业务系统互申 */
  applyType?: string;
  /** 业务状态：0草稿 1待审批 3已通过 4已驳回 5已取消 6已下发 7部分接收 8已完成 */
  bizStatus?: string;
  /** 主任务ID */
  mainProjectId?: number;
  /** 归档标记：1=已归档 */
  archiveFlag?: string;
  pageNo?: number;
  pageSize?: number;
}

/** 申请明细（所需数据资源的种类、格式、要求、用途） */
export interface JobDataApplyItem {
  /** 明细ID（修改时必填） */
  id?: number;
  dataName?: string;
  /** 资料种类：影像/矢量/地名/地形图/控制点/文档 */
  dataCategory?: string;
  /** 资料格式：GDB/SHP/TIFF/DWG/CSV/文档 */
  dataFormat?: string;
  /** 数据量或规模描述 */
  dataScale?: string;
  /** 空间范围 */
  spatialRange?: string;
  /** 时相要求 */
  timeRange?: string;
  /** 资料要求（分辨率/精度/坐标系/保密要求） */
  requirement?: string;
  /** 用途 */
  purpose?: string;
  remark?: string;
  sortOrder?: number;
}

/** 申请单保存参数 */
export interface JobDataApplyPayload {
  id?: number;
  applyType?: string;
  applyTitle?: string;
  mainProjectId?: number;
  projectId?: number;
  taskNo?: string;
  taskName?: string;
  nodeCode?: string;
  nodeName?: string;
  workPostId?: number;
  workPostCode?: string;
  workPostName?: string;
  /** 目标系统标识（BIZ 申请必填） */
  targetSystem?: string;
  targetSystemName?: string;
  applyDept?: string;
  contactInfo?: string;
  /** HIGH=紧急 MID=普通 LOW=一般 */
  urgency?: string;
  /** 期望获取时间 yyyy-MM-dd HH:mm:ss */
  expectTime?: string;
  applyPurpose?: string;
  applyRemark?: string;
  items?: JobDataApplyItem[];
}

/** 申请单分页列表 */
export function listJobDataApplies(params: JobDataQuery) {
  return request({ url: `${BASE}/apply/list`, method: 'get', params });
}

/** 详情（含资料明细 items 与流转记录 flows） */
export function getJobDataApply(id: number | string) {
  return request({ url: `${BASE}/apply/${id}`, method: 'get' });
}

/** 新增 / 修改申请单（不带 status，保存即草稿） */
export function saveJobDataApply(data: JobDataApplyPayload) {
  return request({ url: `${BASE}/apply`, method: 'post', data });
}

/** 提交审批 */
export function submitJobDataApply(id: number | string) {
  return request({ url: `${BASE}/apply/${id}/submit`, method: 'post' });
}

/** 审批（PASS / REJECT + 意见） */
export function approveJobDataApply(id: number | string, data: { approveResult: 'PASS' | 'REJECT'; opinion?: string }) {
  return request({ url: `${BASE}/apply/${id}/approve`, method: 'post', data });
}

/** 取消申请 */
export function cancelJobDataApply(id: number | string) {
  return request({ url: `${BASE}/apply/${id}/cancel`, method: 'post' });
}

/**
 * 回执登记
 * RECEIPT=对方已受理，APPROVE=对方审批通过，REJECT=对方驳回，
 * PROVIDE=资料已提供（需带 items 回填提供结果与资料路径）
 */
export function feedbackJobDataApply(
  id: number | string,
  data: {
    feedbackType: 'RECEIPT' | 'APPROVE' | 'REJECT' | 'PROVIDE';
    opinion?: string;
    items?: Array<{ itemId?: number; provideStatus?: string; resourcePath?: string }>;
  }
) {
  return request({ url: `${BASE}/apply/${id}/feedback`, method: 'post', data });
}

/** 长期归档（archivePath 留空时后端按申请单号生成） */
export function archiveJobDataApply(id: number | string, archivePath?: string) {
  return request({ url: `${BASE}/apply/${id}/archive`, method: 'put', params: { archivePath } });
}

/** 流转记录 */
export function listJobDataFlows(id: number | string) {
  return request({ url: `${BASE}/apply/${id}/flows`, method: 'get' });
}

/** 删除 */
export function deleteJobDataApply(ids: number | string | Array<number | string>) {
  return request({ url: `${BASE}/apply/${Array.isArray(ids) ? ids.join(',') : ids}`, method: 'delete' });
}

/** 申请单状态统计（total / byStatus / archived） */
export function getJobDataApplyStats(mainProjectId?: number) {
  return request({ url: `${BASE}/apply/stats`, method: 'get', params: { mainProjectId } });
}

/** 接收记录查询参数 */
export interface JobDataReceiveQuery {
  receiveNo?: string;
  pushNo?: string;
  sourceSystem?: string;
  /** 2已接收 7部分完成 8已完成 9失败 */
  bizStatus?: string;
  taskNo?: string;
  pageNum?: number;
  pageSize?: number;
}

/** 接收记录分页列表 */
export function listJobDataReceives(params: JobDataReceiveQuery) {
  return request({ url: `${BASE}/receives`, method: 'get', params });
}

/** 接收记录详情（含资料明细 itemList 与流转记录 flowList） */
export function getJobDataReceive(receiveNo: string) {
  return request({ url: `${BASE}/receives/${encodeURIComponent(receiveNo)}`, method: 'get' });
}

/** 重发接收反馈回执 */
export function resendReceiveFeedback(receiveNo: string) {
  return request({ url: `${BASE}/receives/${encodeURIComponent(receiveNo)}/feedback`, method: 'post' });
}

/** 资料目录查询（数据管理分系统已发布的作业资料，推送处理时核对资料用） */
export function listWorkdataMaterials(params: {
  materialName?: string;
  materialType?: string;
  dataFormat?: string;
  pageNum?: number;
  pageSize?: number;
}) {
  return request({ url: `${OPEN_BASE}/list`, method: 'get', params });
}

/**
 * 执行作业资料推送
 * 后端按申请单明细查询资料路径 → 定位/开通临时空间 → 挂接目录 → 回写推送结果，
 * 返回 pushStatus / tempSpacePath / materialList（含 filePath）。
 */
export function pushWorkdata(data: { applyNo: string; force?: string; receivePath?: string; applyUse?: string; applyPasswd?: string }) {
  return request({ url: `${OPEN_BASE}/push`, method: 'post', data });
}
