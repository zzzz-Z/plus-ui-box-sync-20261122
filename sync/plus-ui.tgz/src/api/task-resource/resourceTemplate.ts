import request from '@/utils/request';

/**
 * 资源配置模板（真实接口）
 *
 * 后端：ruoyi-task-manage / ResourceTemplateController → /resource-templates
 * 网关前缀必须带 /dolphinscheduler（断言 /dolphinscheduler/** + StripPrefix=1），否则 404。
 *
 * 模型要点：一个模板 = 一行（带 version / version_group / is_latest），
 * 改模板不是原地改，而是新增一行新版本；资源分配策略落在 items（通用策略项 + specJson）。
 */
export const RESOURCE_TEMPLATE_BASE = '/dolphinscheduler/resource-templates';

/** 资源类型（与后端 ResourceTemplateItem.TYPE_* 一致） */
export const RESOURCE_TYPES = [
  { value: 'POST', label: '作业岗位' },
  { value: 'WORK_UNIT', label: '作业单元' },
  { value: 'COMPUTE', label: '算力' },
  { value: 'STORAGE', label: '存储' },
  { value: 'BANDWIDTH', label: '带宽' },
  { value: 'DATA', label: '作业资料' }
] as const;

export type ResourceTypeValue = (typeof RESOURCE_TYPES)[number]['value'];

/** 分页查询参数 */
export interface ResourceTemplateQuery {
  pageNo?: number;
  pageSize?: number;
  taskType?: string;
  productCategory?: string;
  taskScale?: string;
  /** 模板名称 / 编码 模糊 */
  keyword?: string;
  /** 0=启用 1=已废除 */
  abolishFlag?: number;
}

/** 策略项 */
export interface ResourceTemplateItem {
  id?: number;
  templateId?: number;
  templateVersion?: number;
  resourceType?: ResourceTypeValue | string;
  resourceTypeName?: string;
  resourceId?: number;
  resourceCode?: string;
  resourceName?: string;
  quantity?: number;
  unit?: string;
  /** 1=必配 */
  requireFlag?: number;
  /** 1=独占 0=共享 */
  exclusiveFlag?: number;
  /** 参数规格 JSON 字符串（算力/存储/带宽/单元参数的载体） */
  specJson?: string;
  sortOrder?: number;
  remark?: string;
}

/** 模板保存参数 */
export interface ResourceTemplateBo {
  id?: number;
  templateCode?: string;
  templateName?: string;
  taskType?: string;
  productCategory?: string;
  taskScale?: string;
  description?: string;
  approveBy?: string;
  /** 修改/回滚时填写的变更说明，会写进版本日志 */
  changeDesc?: string;
  items?: ResourceTemplateItem[];
}

/** 模板分页列表 */
export function listResourceTemplates(params: ResourceTemplateQuery) {
  return request({ url: RESOURCE_TEMPLATE_BASE, method: 'get', params });
}

/** 模板详情（含 items 明细） */
export function getResourceTemplate(templateId: number | string) {
  return request({ url: `${RESOURCE_TEMPLATE_BASE}/${templateId}`, method: 'get' });
}

/** 版本历史（同一 version_group 的所有版本） */
export function listResourceTemplateVersions(templateId: number | string) {
  return request({ url: `${RESOURCE_TEMPLATE_BASE}/${templateId}/versions`, method: 'get' });
}

/** 指定版本的策略明细（version 为空取当前版本） */
export function listResourceTemplateItems(templateId: number | string, version?: number) {
  return request({ url: `${RESOURCE_TEMPLATE_BASE}/${templateId}/items`, method: 'get', params: { version } });
}

/** 部署图 / 思维导图数据：nodes + edges + typeStats */
export function getResourceTemplateGraph(templateId: number | string, version?: number) {
  return request({ url: `${RESOURCE_TEMPLATE_BASE}/${templateId}/graph`, method: 'get', params: { version } });
}

/** 变更日志（按版本族返回） */
export function listResourceTemplateLogs(templateId: number | string) {
  return request({ url: `${RESOURCE_TEMPLATE_BASE}/${templateId}/logs`, method: 'get' });
}

/** 新建模板（生成 v1） */
export function createResourceTemplate(data: ResourceTemplateBo) {
  return request({ url: RESOURCE_TEMPLATE_BASE, method: 'post', data });
}

/** 修改模板（生成 v+1，旧版本保留） */
export function updateResourceTemplate(data: ResourceTemplateBo) {
  return request({ url: RESOURCE_TEMPLATE_BASE, method: 'put', data });
}

/** 回滚到历史版本（生成一个新版本） */
export function rollbackResourceTemplate(templateId: number | string, version: number, changeDesc?: string) {
  return request({ url: `${RESOURCE_TEMPLATE_BASE}/${templateId}/rollback`, method: 'post', params: { version, changeDesc } });
}

/** 删除模板（逻辑删除） */
export function deleteResourceTemplate(templateId: number | string) {
  return request({ url: `${RESOURCE_TEMPLATE_BASE}/${templateId}`, method: 'delete' });
}

/** 标记（废除）模板：不删记录，只是不能再被引用 */
export function abolishResourceTemplate(templateId: number | string) {
  return request({ url: `${RESOURCE_TEMPLATE_BASE}/${templateId}/abolish`, method: 'post' });
}

/** 登记模板使用记录（资源配置模块生成任务资源时调用） */
export function recordResourceTemplateRef(data: {
  templateId: number;
  templateVersion?: number;
  templateVersionGroup?: string;
  mainProjectId?: number;
  taskId?: number;
  projectId?: number;
  remark?: string;
}) {
  return request({ url: `${RESOURCE_TEMPLATE_BASE}/ref`, method: 'post', data });
}
