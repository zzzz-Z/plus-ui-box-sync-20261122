import request from '@/utils/request';

/**
 * 临时空间管理（真实接口）
 *
 * 后端：ruoyi-task-manage / TaskTempSpaceController（/temp-space）、TempTransferController（/temp-space/transfers）
 * 网关前缀：/dolphinscheduler
 */
export const TEMP_SPACE_BASE = '/dolphinscheduler/temp-space';

/** 空间申请 / 释放入参 */
export interface TempSpaceApplyBo {
  /** OPEN=申请开通 RELEASE=释放 */
  applyType?: string;
  spaceType?: string;
  spaceId?: number;
  mainProjectId?: number;
  projectId?: number;
  taskNo?: string;
  taskName?: string;
  nodeCode?: string;
  nodeName?: string;
  quotaSize?: number;
  quotaUnit?: string;
  useDeadline?: string;
  autoRelease?: string;
  applyReason?: string;
  spaceName?: string;
}

/** 空间列表查询（后端 TaskTempSpaceController.list 的参数名） */
export interface TempSpaceQuery {
  /** 空间名称/编码模糊（后端参数名就叫 searchName） */
  searchName?: string;
  spaceType?: string;
  spaceStatus?: string;
  mainProjectId?: number;
  pageNo?: number;
  pageSize?: number;
}

export interface TempDirBo {
  id?: number;
  spaceId?: number;
  parentId?: number;
  dirName?: string;
  sortOrder?: number;
  permission?: string;
  accessPassword?: string;
}

export interface TempResourceBo {
  id?: number;
  dirId?: number;
  resourcePaths?: string[];
  resourceName?: string;
  resourceNo?: string;
  resourceType?: string;
  resourceFormat?: string;
  purpose?: string;
  sourceModule?: string;
  sourceRefId?: string;
  applicant?: string;
}

// ---------------- 空间 ----------------
/** 申请开通 / 释放临时空间 */
export function applyTempSpace(data: TempSpaceApplyBo) {
  return request({ url: `${TEMP_SPACE_BASE}/apply`, method: 'post', data });
}

/** 空间分页列表 */
export function listTempSpaces(params: TempSpaceQuery) {
  return request({ url: `${TEMP_SPACE_BASE}/list`, method: 'get', params });
}

/** 空间详情 */
export function getTempSpace(id: number | string) {
  return request({ url: `${TEMP_SPACE_BASE}/${id}`, method: 'get' });
}

/** 即将到期的空间 */
export function listExpiringTempSpaces() {
  return request({ url: `${TEMP_SPACE_BASE}/expiring`, method: 'get' });
}

/** 释放前警示（返回是否可释放/占用情况） */
export function warnBeforeRelease(id: number | string) {
  return request({ url: `${TEMP_SPACE_BASE}/${id}/warn`, method: 'post' });
}

/** 自动释放已到期的空间 */
export function releaseExpiredTempSpaces() {
  return request({ url: `${TEMP_SPACE_BASE}/release-expired`, method: 'post' });
}

/** 空间申请单列表（返回 TableDataInfo：{rows,total}） */
export function listTempSpaceApplies(params?: { applyType?: string; applyStatus?: string; pageNo?: number; pageSize?: number }) {
  return request({ url: `${TEMP_SPACE_BASE}/applies`, method: 'get', params });
}

/** 空间操作日志 */
export function listTempSpaceLogs(spaceId: number | string) {
  return request({ url: `${TEMP_SPACE_BASE}/${spaceId}/logs`, method: 'get' });
}

// ---------------- 目录 ----------------
/** 目录树 */
export function getTempDirTree(spaceId: number | string) {
  return request({ url: `${TEMP_SPACE_BASE}/${spaceId}/dirs/tree`, method: 'get' });
}

/** 目录下的子目录与数据资源 */
export function getTempDirChildren(dirId: number | string) {
  return request({ url: `${TEMP_SPACE_BASE}/dirs/${dirId}/children`, method: 'get' });
}

/** 新增目录 */
export function createTempDir(data: TempDirBo) {
  return request({ url: `${TEMP_SPACE_BASE}/dirs`, method: 'post', data });
}

/** 修改目录（重命名/排序/权限） */
export function updateTempDir(data: TempDirBo) {
  return request({ url: `${TEMP_SPACE_BASE}/dirs`, method: 'put', data });
}

/** 删除目录前确认（是否含资源） */
export function checkTempDirDelete(dirId: number | string) {
  return request({ url: `${TEMP_SPACE_BASE}/dirs/${dirId}/delete-check`, method: 'get' });
}

/** 删除目录（后端需 confirm=true 才真正执行，否则只返回影响范围） */
export function deleteTempDir(dirId: number | string, confirm = true) {
  return request({ url: `${TEMP_SPACE_BASE}/dirs/${dirId}`, method: 'delete', params: { confirm } });
}

/** 按组织架构批量生成目录结构 */
export function generateTempDirs(spaceId: number | string) {
  return request({ url: `${TEMP_SPACE_BASE}/${spaceId}/dirs/generate`, method: 'post' });
}

// ---------------- 权限 ----------------
/** 配置目录访问权限（permission: PUBLIC/APPLY/PRIVATE，password 可选） */
export function setTempDirPermission(dirId: number | string, data: { permission: string; accessPassword?: string }) {
  return request({ url: `${TEMP_SPACE_BASE}/dirs/${dirId}/permission`, method: 'put', data });
}

/** 目录访问权限校验 */
export function checkTempDirPermission(dirId: number | string) {
  return request({ url: `${TEMP_SPACE_BASE}/dirs/${dirId}/permission/check`, method: 'get' });
}

// ---------------- 数据资源（挂接） ----------------
/** 挂接数据资源路径 */
export function mountTempResources(dirId: number | string, data: TempResourceBo) {
  return request({ url: `${TEMP_SPACE_BASE}/dirs/${dirId}/resources`, method: 'post', data });
}

/** 数据资源重命名 */
export function renameTempResource(id: number | string, resourceName: string) {
  return request({ url: `${TEMP_SPACE_BASE}/resources/${id}/rename`, method: 'put', params: { resourceName } });
}

/** 解挂数据资源 */
export function unmountTempResource(id: number | string) {
  return request({ url: `${TEMP_SPACE_BASE}/resources/${id}`, method: 'delete' });
}

/** 空间内数据资源查询（后端：TableDataInfo；参数 keyword / pageNo / pageSize） */
export function listTempResources(spaceId: number | string, params?: { keyword?: string; pageNo?: number; pageSize?: number }) {
  return request({ url: `${TEMP_SPACE_BASE}/${spaceId}/resources`, method: 'get', params });
}

/** 数据资源详情 */
export function getTempResource(id: number | string) {
  return request({ url: `${TEMP_SPACE_BASE}/resources/${id}`, method: 'get' });
}

// ---------------- 传输（上传/下载） ----------------
/** 初始化上传任务 */
export function initTransferUpload(data: { spaceId: number; dirId: number; fileNames: string[]; totalSize?: number }) {
  return request({ url: `${TEMP_SPACE_BASE}/transfers/upload/init`, method: 'post', data });
}

/** 上传分片（multipart） */
export function uploadTransferChunk(form: FormData) {
  return request({
    url: `${TEMP_SPACE_BASE}/transfers/upload/chunk`,
    method: 'post',
    data: form,
    headers: { 'Content-Type': 'multipart/form-data' }
  });
}

/** 合并上传分片 */
export function completeTransferUpload(data: { transferNo: string }) {
  return request({ url: `${TEMP_SPACE_BASE}/transfers/upload/complete`, method: 'post', data });
}

/** 初始化下载任务 */
export function initTransferDownload(data: { spaceId: number; resourceId: number }) {
  return request({ url: `${TEMP_SPACE_BASE}/transfers/download/init`, method: 'post', data });
}

/** 传输任务列表 */
export function listTransfers(params?: { spaceId?: number; transferType?: string; status?: string; pageNum?: number; pageSize?: number }) {
  return request({ url: `${TEMP_SPACE_BASE}/transfers`, method: 'get', params });
}

/** 传输任务详情 */
export function getTransfer(transferNo: string) {
  return request({ url: `${TEMP_SPACE_BASE}/transfers/${transferNo}`, method: 'get' });
}

/** 取消传输 */
export function cancelTransfer(transferNo: string) {
  return request({ url: `${TEMP_SPACE_BASE}/transfers/${transferNo}/cancel`, method: 'post' });
}

/** 重试传输 */
export function retryTransfer(transferNo: string) {
  return request({ url: `${TEMP_SPACE_BASE}/transfers/${transferNo}/retry`, method: 'post' });
}

/** 传输操作审计 */
export function listTransferLogs(transferNo: string) {
  return request({ url: `${TEMP_SPACE_BASE}/transfers/${transferNo}/logs`, method: 'get' });
}
