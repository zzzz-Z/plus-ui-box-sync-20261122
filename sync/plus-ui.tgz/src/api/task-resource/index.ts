// ============================================================
// MOCK DATA
// ============================================================

/* ---------- 岗位管理 mock data ---------- */
const mockPostList: any[] = [
  { id: 'P-001', name: '智能提取-席位01', postType: '智能提取作业岗位', ipAddress: '192.168.1.101', deptName: '数据平台部', status: '作业中', operatorId: 'op1', operatorName: '张建国', permission: 'public', remark: '全国矢量要素提取任务专用', loginEnabled: true, lockedByTask: '全国矢量要素更新(第一期)' },
  { id: 'P-002', name: '智能提取-席位02', postType: '智能提取作业岗位', ipAddress: '192.168.1.102', deptName: '数据平台部', status: '空闲', operatorId: 'op5', operatorName: '刘卫东', permission: 'public', remark: '', loginEnabled: true, lockedByTask: '' },
  { id: 'P-003', name: '属性挖掘-席位01', postType: '属性挖掘作业岗位', ipAddress: '192.168.2.101', deptName: '数据分析部', status: '空闲', operatorId: '', operatorName: '', permission: 'apply', remark: '属性信息智能提取与分析', loginEnabled: true, lockedByTask: '' },
  { id: 'P-004', name: '属性挖掘-席位02', postType: '属性挖掘作业岗位', ipAddress: '192.168.2.102', deptName: '数据分析部', status: '空闲', operatorId: 'op6', operatorName: '赵晓燕', permission: 'public', remark: '', loginEnabled: true, lockedByTask: '' },
  { id: 'P-005', name: '军事地质-席位01', postType: '军事地质作业岗位', ipAddress: '192.168.3.101', deptName: '军事地质部', status: '作业中', operatorId: 'op2', operatorName: '李明远', permission: 'private', remark: '涉密岗位，需审批访问', loginEnabled: true, lockedByTask: '军事地质数据采集' },
  { id: 'P-006', name: '军事地质-席位02', postType: '军事地质作业岗位', ipAddress: '192.168.3.102', deptName: '军事地质部', status: '空闲', operatorId: '', operatorName: '', permission: 'private', remark: '备用席位', loginEnabled: false, lockedByTask: '' },
  { id: 'P-007', name: '陆海融合-席位01', postType: '陆海融合作业岗位', ipAddress: '192.168.4.101', deptName: '陆海融合中心', status: '已锁定', operatorId: 'op3', operatorName: '王海峰', permission: 'public', remark: '南海陆海专题图制作', loginEnabled: true, lockedByTask: '南海陆海专题图' },
  { id: 'P-008', name: '陆海融合-席位02', postType: '陆海融合作业岗位', ipAddress: '192.168.4.102', deptName: '陆海融合中心', status: '空闲', operatorId: '', operatorName: '', permission: 'apply', remark: '', loginEnabled: true, lockedByTask: '' },
  { id: 'P-009', name: '人机协同-席位01', postType: '人机协同作业岗位', ipAddress: '192.168.5.101', deptName: 'AI协同部', status: '空闲', operatorId: 'op4', operatorName: '陈志强', permission: 'public', remark: '城市三维建模协同处理', loginEnabled: true, lockedByTask: '' },
  { id: 'P-010', name: '人机协同-席位02', postType: '人机协同作业岗位', ipAddress: '192.168.5.102', deptName: 'AI协同部', status: '空闲', operatorId: '', operatorName: '', permission: 'apply', remark: '', loginEnabled: true, lockedByTask: '' },
  { id: 'P-011', name: '矢量组网-席位01', postType: '矢量组网作业岗位', ipAddress: '192.168.6.101', deptName: '矢量组网部', status: '空闲', operatorId: '', operatorName: '', permission: 'public', remark: '全球框架数据组网同步', loginEnabled: true, lockedByTask: '' },
  { id: 'P-012', name: '矢量组网-席位02', postType: '矢量组网作业岗位', ipAddress: '192.168.6.102', deptName: '矢量组网部', status: '空闲', operatorId: '', operatorName: '', permission: 'public', remark: '', loginEnabled: false, lockedByTask: '' },
];

const mockPostAuditLogs: Record<string, AuditLog[]> = {
  'P-001': [
    { time: '2026-07-20 09:30:00', operator: '张伟', action: '岗位信息更新', content: '将岗位级别从"中级"调整为"高级"' },
    { time: '2026-07-15 14:20:00', operator: '李娜', action: '审核通过', content: '审批通过岗位编制调整申请' },
    { time: '2026-06-28 10:00:00', operator: '王强', action: '创建岗位', content: '新建"系统管理员"岗位，编制人数3人' },
    { time: '2026-06-10 16:45:00', operator: '赵敏', action: '编制变更', content: '将requiredCount从2变更为3' },
    { time: '2026-05-22 08:30:00', operator: '刘洋', action: '权限配置', content: '配置岗位关联的角色与菜单权限' },
    { time: '2026-04-18 11:15:00', operator: '陈静', action: '初始创建', content: '系统初始化时创建默认管理岗位' },
  ],
  'P-002': [
    { time: '2026-07-18 10:30:00', operator: '周杰', action: '人员变动', content: '新员工孙磊分配到数据工程师岗位' },
    { time: '2026-06-15 09:00:00', operator: '张伟', action: '岗位信息更新', content: '更新岗位职责描述，增加数据安全相关要求' },
  ],
};

/* ---------- 单位管理 mock data ---------- */
const mockUnitList: any[] = [
  {
    id: 'UT-001', name: '遥感影像辐射定标工具', category: '智能提取', toolType: 'tool',
    currentVersion: '2.1.0', publishStatus: '已发布', accessUrl: 'http://toolhost:8080/radiometric',
    exePath: '/opt/tools/radiometric_calib/run.sh', docPath: '/docs/tools/radiometric_calib_v2.1.pdf',
    metadataPath: 'radiometric_calib_params.json', registrant: '张建国', registerTime: '2026-06-15 09:30:00',
    description: 'FY-4A/B遥感影像辐射定标处理工具，支持可见光和红外波段',
    params: [
      { paramName: 'input_dir', paramType: 'path', required: true, defaultValue: '/data/raw', description: '原始影像目录' },
      { paramName: 'output_dir', paramType: 'path', required: true, defaultValue: '/data/calibrated', description: '定标后输出目录' },
      { paramName: 'band', paramType: 'string', required: false, defaultValue: 'VIS', description: '处理波段: VIS/IR/WV' },
      { paramName: 'threads', paramType: 'number', required: false, defaultValue: '8', description: '并行线程数' }
    ]
  },
  {
    id: 'UT-002', name: '矢量要素提取插件', category: '智能提取', toolType: 'plugin',
    currentVersion: '1.5.3', publishStatus: '已发布', accessUrl: 'http://toolhost:8080/feature_extract',
    exePath: '/opt/plugins/feature_extract.so', docPath: '/docs/plugins/feature_extract_v1.5.pdf',
    metadataPath: 'feature_extract_config.yaml', registrant: '李明远', registerTime: '2026-07-01 14:20:00',
    description: '基于深度学习的矢量要素自动提取插件，支持道路、建筑、水体等多类要素',
    params: [
      { paramName: 'config_file', paramType: 'path', required: true, defaultValue: '/etc/feature_extract/config.yaml', description: '模型配置文件' },
      { paramName: 'batch_size', paramType: 'number', required: false, defaultValue: '64', description: '推理批处理大小' },
      { paramName: 'enable_gpu', paramType: 'boolean', required: false, defaultValue: 'true', description: '是否启用GPU加速' }
    ]
  },
  {
    id: 'UT-003', name: '属性挖掘分析软件', category: '属性挖掘', toolType: 'software',
    currentVersion: '3.0.1', publishStatus: '已发布', accessUrl: 'http://toolhost:8080/attr_mining',
    exePath: '/opt/software/attr_mining/bin/main', docPath: '/docs/software/attr_mining_v3.pdf',
    metadataPath: 'attr_mining_schema.xml', registrant: '王海峰', registerTime: '2026-05-20 10:00:00',
    description: '多源地理信息属性数据挖掘与分析软件，支持统计分析、关联规则挖掘和异常检测',
    params: [
      { paramName: 'source_path', paramType: 'path', required: true, defaultValue: '/data/attr_source', description: '属性数据源路径' },
      { paramName: 'target_path', paramType: 'path', required: true, defaultValue: '/data/attr_result', description: '分析结果输出路径' },
      { paramName: 'max_memory', paramType: 'number', required: false, defaultValue: '16384', description: '最大内存限制(MB)' },
      { paramName: 'algorithm', paramType: 'string', required: false, defaultValue: 'apriori', description: '挖掘算法: apriori/fpgrowth/eclat' },
      { paramName: 'min_support', paramType: 'number', required: false, defaultValue: '0.05', description: '最小支持度阈值' }
    ]
  },
  {
    id: 'UT-004', name: '地质建模工具集', category: '军事地质', toolType: 'tool',
    currentVersion: '1.2.0', publishStatus: '已发布', accessUrl: 'http://toolhost:8080/geology',
    exePath: '/opt/tools/geology_modeling/run.py', docPath: '/docs/tools/geology_modeling_v1.2.pdf',
    metadataPath: 'geology_modeling_params.json', registrant: '陈志强', registerTime: '2026-07-10 08:45:00',
    description: '军事地质三维建模与可视化工具，支持地形分析、地质剖面和工程地质评价',
    params: [
      { paramName: 'dem_path', paramType: 'path', required: true, defaultValue: '/data/geology/dem', description: 'DEM高程数据路径' },
      { paramName: 'geology_path', paramType: 'path', required: true, defaultValue: '/data/geology/survey', description: '地质调查数据路径' },
      { paramName: 'resolution', paramType: 'number', required: false, defaultValue: '30', description: '网格分辨率(米)' }
    ]
  },
  {
    id: 'UT-005', name: '陆海融合渲染引擎', category: '陆海融合', toolType: 'software',
    currentVersion: '2.3.0', publishStatus: '已发布', accessUrl: 'http://toolhost:8080/landsea',
    exePath: '/opt/software/landsea_render/bin/render', docPath: '/docs/software/landsea_render_v2.3.pdf',
    metadataPath: 'landsea_render_config.yaml', registrant: '刘卫东', registerTime: '2026-04-18 13:15:00',
    description: '陆海一体化渲染引擎，支持海岸带三维可视化、水下地形渲染和动态效果',
    params: [
      { paramName: 'config_file', paramType: 'path', required: true, defaultValue: '/etc/landsea/config.yaml', description: '渲染配置文件' },
      { paramName: 'enable_gpu', paramType: 'boolean', required: false, defaultValue: 'true', description: 'GPU加速渲染' },
      { paramName: 'output_format', paramType: 'string', required: false, defaultValue: 'PNG', description: '输出格式: PNG/JPEG/TIFF/GeoTIFF' },
      { paramName: 'dpi', paramType: 'number', required: false, defaultValue: '300', description: '输出分辨率DPI' }
    ]
  },
  {
    id: 'UT-006', name: '人机协同标注平台', category: '人机协同', toolType: 'software',
    currentVersion: '4.0.2', publishStatus: '已发布', accessUrl: 'http://toolhost:8080/labeling',
    exePath: '/opt/software/labeling_platform/bin/server', docPath: '/docs/software/labeling_platform_v4.pdf',
    metadataPath: 'labeling_schema.json', registrant: '赵晓燕', registerTime: '2026-03-22 11:00:00',
    description: 'AI辅助人机协同标注平台，支持图像、点云和矢量数据标注',
    params: [
      { paramName: 'project_id', paramType: 'string', required: true, defaultValue: '', description: '标注项目ID' },
      { paramName: 'data_path', paramType: 'path', required: true, defaultValue: '/data/labeling', description: '待标注数据路径' },
      { paramName: 'model_version', paramType: 'string', required: false, defaultValue: 'latest', description: 'AI预标注模型版本' }
    ]
  },
  {
    id: 'UT-007', name: '矢量网络分析工具', category: '矢量组网', toolType: 'tool',
    currentVersion: '1.8.0', publishStatus: '未发布', accessUrl: '',
    exePath: '/opt/tools/vector_network/run.sh', docPath: '/docs/tools/vector_network_v1.8.pdf',
    metadataPath: '', registrant: '张建国', registerTime: '2026-07-25 16:30:00',
    description: '矢量组网拓扑分析与优化工具，支持网络连通性分析、路径优化和冗余检测',
    params: []
  },
  {
    id: 'UT-008', name: '全球框架同步插件', category: '矢量组网', toolType: 'plugin',
    currentVersion: '1.1.0', publishStatus: '已下线', accessUrl: 'http://toolhost:8080/global_sync',
    exePath: '/opt/plugins/global_sync.so', docPath: '/docs/plugins/global_sync_v1.1.pdf',
    metadataPath: 'global_sync_config.xml', registrant: '王海峰', registerTime: '2026-02-10 09:00:00',
    description: '全球地理信息框架数据同步插件（已下线，存在兼容性问题待修复）',
    params: [
      { paramName: 'source_url', paramType: 'string', required: true, defaultValue: '', description: '源数据服务URL' },
      { paramName: 'sync_interval', paramType: 'number', required: false, defaultValue: '3600', description: '同步间隔(秒)' },
      { paramName: 'compress', paramType: 'boolean', required: false, defaultValue: 'true', description: '是否启用数据压缩' }
    ]
  }
];

const mockUnitVersions: Record<string, UnitVersionVO[]> = {
  'UT-001': [
    { version: 'v3.2.1', updateTime: '2026-07-20 16:30:00', operator: '陈建国', changes: '更新成员数量：新增5名研发工程师' },
    { version: 'v3.2.0', updateTime: '2026-06-15 10:00:00', operator: '张伟', changes: '升级单位版本，增加GPU资源配额' },
    { version: 'v3.1.0', updateTime: '2026-05-10 14:00:00', operator: '李娜', changes: '调整组织结构，新增AI研究小组' },
  ],
  'UT-003': [
    { version: 'v3.0.2', updateTime: '2026-07-15 09:45:00', operator: '黄志远', changes: '扩容存储节点至120TB' },
    { version: 'v3.0.1', updateTime: '2026-06-20 11:30:00', operator: '王强', changes: '修复数据同步策略配置' },
  ],
};

/* ---------- 云基础设施 mock data ---------- */
const mockLocalInfra: InfraNode = {
  id: 'LOCAL-001',
  nodeName: '北京主节点',
  nodeType: 'master',
  ip: '192.168.10.100',
  cpu: 'Intel Xeon Gold 6248R (48核 @ 3.0GHz)',
  cpuUsage: 67.5,
  memory: '256GB DDR4 ECC',
  memoryUsage: 72.3,
  gpu: 'NVIDIA A100 80GB x4',
  storage: 'SSD RAID5 4.8TB + HDD RAID6 32TB',
  storageUsage: 58.9,
  bandwidth: '10Gbps 双路冗余',
  status: '运行中',
  os: 'Ubuntu 22.04.3 LTS',
  description: '本地核心管理节点，负责集群调度与任务资源分配',
  location: '北京市海淀区中关村数据中心A栋3层',
  relatedNodes: [
    {
      id: 'LOCAL-002',
      nodeName: '北京计算节点-01',
      nodeType: 'compute',
      ip: '192.168.10.101',
      cpu: 'Intel Xeon Gold 6248R (48核)',
      cpuUsage: 85.2,
      memory: '128GB DDR4',
      memoryUsage: 60.1,
      gpu: 'NVIDIA A100 80GB x2',
      storage: 'SSD 2.4TB',
      storageUsage: 45.3,
      bandwidth: '10Gbps',
      status: '运行中',
      os: 'Ubuntu 22.04.3 LTS',
      description: '通用计算节点01',
      location: '北京市海淀区中关村数据中心A栋3层',
    },
    {
      id: 'LOCAL-003',
      nodeName: '北京存储节点-01',
      nodeType: 'storage',
      ip: '192.168.10.102',
      cpu: 'Intel Xeon Silver 4214 (24核)',
      cpuUsage: 32.1,
      memory: '64GB DDR4',
      memoryUsage: 45.6,
      gpu: '无',
      storage: 'HDD RAID6 64TB',
      storageUsage: 68.4,
      bandwidth: '10Gbps',
      status: '运行中',
      os: 'CentOS 8.5',
      description: '分布式存储节点01',
      location: '北京市海淀区中关村数据中心A栋3层',
    },
  ],
  connections: [
    { source: 'LOCAL-001', target: 'LOCAL-002', type: 'InfiniBand', bandwidth: '100Gbps' },
    { source: 'LOCAL-001', target: 'LOCAL-003', type: 'InfiniBand', bandwidth: '100Gbps' },
    { source: 'LOCAL-002', target: 'LOCAL-003', type: 'Ethernet', bandwidth: '25Gbps' },
  ],
};

const mockRemoteInfraList: InfraNode[] = [
  {
    id: 'REM-001',
    nodeName: '上海云节点-A1',
    nodeType: 'compute',
    ip: '10.20.30.10',
    cpu: 'AMD EPYC 7742 (64核 @ 2.25GHz)',
    cpuUsage: 54.8,
    memory: '256GB DDR4',
    memoryUsage: 63.2,
    gpu: 'NVIDIA V100 32GB x8',
    storage: 'NVMe SSD 3.2TB',
    storageUsage: 41.7,
    bandwidth: '25Gbps',
    status: '运行中',
    os: 'CentOS 8.5',
    description: '华东高性能计算节点',
    location: '上海市浦东新区',
  },
  {
    id: 'REM-002',
    nodeName: '上海存储节点-S1',
    nodeType: 'storage',
    ip: '10.20.30.20',
    cpu: 'Intel Xeon Silver 4214 (24核)',
    cpuUsage: 28.3,
    memory: '128GB DDR4',
    memoryUsage: 52.1,
    gpu: '无',
    storage: 'HDD RAID6 96TB',
    storageUsage: 72.9,
    bandwidth: '25Gbps',
    status: '运行中',
    os: 'CentOS 8.5',
    description: '华东区域存储主节点',
    location: '上海市浦东新区',
  },
  {
    id: 'REM-003',
    nodeName: '深圳推理节点-G1',
    nodeType: 'gpu',
    ip: '10.30.40.10',
    cpu: 'Intel Xeon Platinum 8380 (40核)',
    cpuUsage: 78.6,
    memory: '512GB DDR4 ECC',
    memoryUsage: 85.4,
    gpu: 'NVIDIA H100 80GB x8',
    storage: 'NVMe SSD 7.68TB x4',
    storageUsage: 53.2,
    bandwidth: '100Gbps',
    status: '运行中',
    os: 'Ubuntu 22.04.3 LTS',
    description: '华南GPU推理集群主节点',
    location: '深圳市南山区',
  },
  {
    id: 'REM-004',
    nodeName: '成都备份节点-B1',
    nodeType: 'backup',
    ip: '10.40.50.10',
    cpu: 'Intel Xeon E5-2680 v4 (28核)',
    cpuUsage: 18.9,
    memory: '128GB DDR4',
    memoryUsage: 35.7,
    gpu: '无',
    storage: 'HDD RAID6 120TB',
    storageUsage: 88.2,
    bandwidth: '10Gbps',
    status: '运行中',
    os: 'CentOS 8.5',
    description: '西部灾备中心主存储节点',
    location: '成都市高新区',
  },
  {
    id: 'REM-005',
    nodeName: '杭州开发节点-D1',
    nodeType: 'development',
    ip: '10.50.60.10',
    cpu: 'Intel Xeon Gold 6248R (48核)',
    cpuUsage: 42.3,
    memory: '192GB DDR4',
    memoryUsage: 55.8,
    gpu: 'NVIDIA RTX 4090 x4',
    storage: 'SSD 4TB x2 RAID1',
    storageUsage: 37.5,
    bandwidth: '25Gbps',
    status: '维护中',
    os: 'Ubuntu 22.04.3 LTS',
    description: 'AI研究院开发调试节点',
    location: '杭州市西湖区',
  },
  {
    id: 'REM-006',
    nodeName: '武汉测试节点-T1',
    nodeType: 'testing',
    ip: '10.60.70.10',
    cpu: 'Intel Xeon Silver 4210 (20核)',
    cpuUsage: 25.1,
    memory: '96GB DDR4',
    memoryUsage: 40.3,
    gpu: 'NVIDIA T4 16GB x2',
    storage: 'SSD 1.92TB x2',
    storageUsage: 30.8,
    bandwidth: '10Gbps',
    status: '就绪',
    os: 'CentOS 8.5',
    description: '系统集成测试节点',
    location: '武汉市洪山区',
  },
];

const mockInfraPermList: InfraPermVO[] = [
  {
    id: 'IP-001',
    nodeName: '北京主节点',
    targetOrg: '上海运维中心',
    targetUser: '林晓峰',
    permission: '读写',
    expireTime: '2027-01-15 00:00:00',
    status: '生效中',
  },
  {
    id: 'IP-002',
    nodeName: '深圳推理节点-G1',
    targetOrg: '杭州AI研究院',
    targetUser: '郑博文',
    permission: '只读',
    expireTime: '2026-12-31 00:00:00',
    status: '生效中',
  },
  {
    id: 'IP-003',
    nodeName: '北京主节点',
    targetOrg: '成都安全实验室',
    targetUser: '吴雅琴',
    permission: '审计',
    expireTime: '2027-06-30 00:00:00',
    status: '生效中',
  },
];

const mockInfraPermLogs: AuditLog[] = [
  { time: '2026-07-20 14:30:00', operator: '张伟', action: '新增权限', content: '为上海运维中心授予北京主节点读写权限' },
  { time: '2026-07-18 09:15:00', operator: '李娜', action: '权限变更', content: '将深圳推理节点的杭州AI研究院权限从"只读"变更为"读写"' },
  { time: '2026-07-15 16:00:00', operator: '王强', action: '权限回收', content: '回收武汉测试中心对北京主节点的访问权限' },
  { time: '2026-07-10 11:00:00', operator: '赵敏', action: '权限续期', content: '成都安全实验室审计权限续期至2027年6月' },
];

/* ---------- 作业资料管理 mock data ---------- */
const mockApplyList: DataApplyVO[] = [
  {
    id: 'DA-001',
    dataName: '遥感影像数据集-Q3',
    dataType: '影像数据',
    format: 'GeoTIFF',
    size: '256GB',
    applyDirection: 'external',
    sourceSystem: '国家遥感中心',
    targetDesc: '用于Q3季度区域变化检测模型训练',
    approvalNode: 'standard',
    urgentLevel: '普通',
    applicant: '刘洋',
    applyTime: '2026-07-21 09:15:00',
    status: '审批中',
    approvalProgress: '部门审批',
    assignee: '陈建国',
  },
  {
    id: 'DA-002',
    dataName: '气象观测数据-2026H1',
    dataType: '结构化数据',
    format: 'CSV/Parquet',
    size: '12.8GB',
    applyDirection: 'internal',
    sourceSystem: '数据中台-气象域',
    targetDesc: '用于环境监测模型特征工程',
    approvalNode: 'simple',
    urgentLevel: '普通',
    applicant: '周杰',
    applyTime: '2026-07-20 14:30:00',
    status: '已通过',
    approvalProgress: '已完成',
    assignee: '林晓峰',
  },
  {
    id: 'DA-003',
    dataName: '用户行为日志-7月',
    dataType: '日志数据',
    format: 'JSON/GZIP',
    size: '48.5GB',
    applyDirection: 'internal',
    sourceSystem: '大数据平台-行为分析',
    targetDesc: '推荐算法召回模型训练',
    approvalNode: 'standard',
    urgentLevel: '加急',
    applicant: '孙磊',
    applyTime: '2026-07-19 10:00:00',
    status: '审批中',
    approvalProgress: '安全审批',
    assignee: '吴雅琴',
  },
  {
    id: 'DA-004',
    dataName: '三维点云地图-深圳',
    dataType: '点云数据',
    format: 'LAS/LAZ',
    size: '320GB',
    applyDirection: 'external',
    sourceSystem: '深圳市自然资源局',
    targetDesc: '自动驾驶仿真场景构建',
    approvalNode: 'standard',
    urgentLevel: '普通',
    applicant: '郑博文',
    applyTime: '2026-07-18 08:45:00',
    status: '已退回',
    approvalProgress: '部门审批-已退回',
    assignee: '陈建国',
  },
  {
    id: 'DA-005',
    dataName: '设备传感器数据-M6',
    dataType: '时序数据',
    format: 'Apache Arrow',
    size: '8.2GB',
    applyDirection: 'internal',
    sourceSystem: 'IoT平台',
    targetDesc: '设备故障预测模型训练',
    approvalNode: 'simple',
    urgentLevel: '普通',
    applicant: '黄志远',
    applyTime: '2026-07-16 15:20:00',
    status: '已通过',
    approvalProgress: '已完成',
    assignee: '林晓峰',
  },
  {
    id: 'DA-006',
    dataName: '网络安全事件库',
    dataType: '安全数据',
    format: 'JSON/STIX',
    size: '3.5GB',
    applyDirection: 'external',
    sourceSystem: '国家信息安全漏洞库',
    targetDesc: '威胁情报分析与预警系统构建',
    approvalNode: 'standard',
    urgentLevel: '加急',
    applicant: '吴雅琴',
    applyTime: '2026-07-15 11:00:00',
    status: '审批中',
    approvalProgress: '合规审查',
    assignee: '张伟',
  },
];

const mockReceiveList: DataReceiveVO[] = [
  {
    id: 'DR-001',
    sourceTask: 'TASK-2026-0710-A01',
    sourceNode: '上海云节点-A1',
    dataName: '模型训练中间结果-v3',
    dataType: '模型文件',
    format: 'ONNX/PTH',
    size: '45.6GB',
    sender: '林晓峰',
    sendTime: '2026-07-20 18:30:00',
    status: '待接收',
    analysisResult: '',
    mountSpace: '',
  },
  {
    id: 'DR-002',
    sourceTask: 'TASK-2026-0715-B02',
    sourceNode: '深圳推理节点-G1',
    dataName: '推理日志汇总-7月W3',
    dataType: '日志数据',
    format: 'JSON/GZIP',
    size: '2.3GB',
    sender: '黄志远',
    sendTime: '2026-07-19 09:00:00',
    status: '已接收',
    analysisResult: '数据完整，格式校验通过，已归档至/data/archive/logs/2026/07/w3/',
    mountSpace: 'TS-002',
  },
  {
    id: 'DR-003',
    sourceTask: 'TASK-2026-0718-C03',
    sourceNode: '杭州开发节点-D1',
    dataName: '预训练模型BERT-large',
    dataType: '模型文件',
    format: 'SafeTensors',
    size: '1.2GB',
    sender: '郑博文',
    sendTime: '2026-07-18 14:20:00',
    status: '已接收',
    analysisResult: '模型架构验证通过，参数量340M，已挂载至TS-001只读空间',
    mountSpace: 'TS-001',
  },
  {
    id: 'DR-004',
    sourceTask: 'TASK-2026-0720-D04',
    sourceNode: '成都备份节点-B1',
    dataName: '灾备演练报告-2026Q3',
    dataType: '文档数据',
    format: 'PDF/DOCX',
    size: '156MB',
    sender: '吴雅琴',
    sendTime: '2026-07-21 10:00:00',
    status: '待接收',
    analysisResult: '',
    mountSpace: '',
  },
  {
    id: 'DR-005',
    sourceTask: 'TASK-2026-0712-E05',
    sourceNode: '上海存储节点-S1',
    dataName: '遥感影像预处理结果',
    dataType: '影像数据',
    format: 'GeoTIFF',
    size: '180GB',
    sender: '刘洋',
    sendTime: '2026-07-17 16:45:00',
    status: '已退回',
    analysisResult: '数据校验失败：部分分块MD5不匹配，请联系发送方重新传输',
    mountSpace: '',
  },
];

const mockPushList: DataPushVO[] = [
  {
    id: 'DP-001',
    dataName: '模型预测结果-7月批次',
    dataType: '结果数据',
    targetSystem: '业务决策系统',
    targetNode: '上海运维中心',
    pushMethod: 'API直推',
    status: '已完成',
    pushStep: 3,
    operator: '周杰',
    pushTime: '2026-07-20 20:00:00',
  },
  {
    id: 'DP-002',
    dataName: '故障预测报告',
    dataType: '报告数据',
    targetSystem: '运维管理平台',
    targetNode: '上海运维中心',
    pushMethod: '消息队列',
    status: '推送中',
    pushStep: 2,
    operator: '黄志远',
    pushTime: '2026-07-21 08:00:00',
  },
  {
    id: 'DP-003',
    dataName: '安全审计报告-W28',
    dataType: '审计数据',
    targetSystem: '安全合规系统',
    targetNode: '成都安全实验室',
    pushMethod: '文件传输',
    status: '待推送',
    pushStep: 0,
    operator: '吴雅琴',
    pushTime: '2026-07-20 15:30:00',
  },
  {
    id: 'DP-004',
    dataName: '训练指标Dashboard',
    dataType: '指标数据',
    targetSystem: '可视化大屏',
    targetNode: '北京研发中心',
    pushMethod: 'API直推',
    status: '已完成',
    pushStep: 3,
    operator: '孙磊',
    pushTime: '2026-07-19 12:00:00',
  },
  {
    id: 'DP-005',
    dataName: '数据血缘图谱',
    dataType: '元数据',
    targetSystem: '数据治理平台',
    targetNode: '深圳数据基地',
    pushMethod: '消息队列',
    status: '失败',
    pushStep: 1,
    operator: '刘洋',
    pushTime: '2026-07-18 17:00:00',
  },
  {
    id: 'DP-006',
    dataName: '设备运行状态快照',
    dataType: '状态数据',
    targetSystem: '资源监控系统',
    targetNode: '北京研发中心',
    pushMethod: '文件传输',
    status: '已完成',
    pushStep: 3,
    operator: '林晓峰',
    pushTime: '2026-07-21 06:00:00',
  },
];

/* ---------- 临时空间管理 mock data ---------- */
const mockSpaceList: TempSpaceVO[] = [
  {
    id: 'TS-001',
    name: 'AI训练临时空间',
    spaceType: 'global',
    taskName: 'TASK-2026-0701-MODEL',
    nodeName: '北京主节点',
    totalSize: '2TB',
    usedSize: '1.35TB',
    mountPath: '/mnt/task-space/ai-training',
    rootDirName: 'ai-training',
    dirCount: 5,
    driver: 'NFSv4+CephFS',
    status: '使用中',
    mountedSources: [
      { name: 'NAS-01-训练数据', path: '/nas/training-data' },
      { name: 'OSS-模型仓库', path: '/oss/models' },
    ],
    creator: '郑博文',
    createTime: '2026-07-01 09:00:00',
    expireTime: '2026-08-01 09:00:00',
    auditLogs: [
      { time: '2026-07-01 09:00:00', operator: '郑博文', action: '创建空间', content: '申请创建2TB临时存储空间用于AI模型训练' },
      { time: '2026-07-01 09:30:00', operator: '张伟', action: '审批通过', content: '空间申请审批通过，分配配额2TB，有效期30天' },
      { time: '2026-07-03 14:00:00', operator: '郑博文', action: '挂载源', content: '挂载NAS-01-训练数据至输入目录' },
    ],
  },
  {
    id: 'TS-002',
    name: '数据接收暂存区',
    spaceType: 'node',
    taskName: 'TASK-2026-0710-RECV',
    nodeName: '上海云节点-A1',
    totalSize: '500GB',
    usedSize: '320GB',
    mountPath: '/mnt/task-space/data-recv',
    rootDirName: 'data-recv',
    dirCount: 4,
    driver: 'NFSv4',
    status: '使用中',
    mountedSources: [
      { name: '分布式存储-华东池', path: '/dfs/east-pool' },
    ],
    creator: '林晓峰',
    createTime: '2026-07-10 11:00:00',
    expireTime: '2026-07-25 11:00:00',
    auditLogs: [
      { time: '2026-07-10 11:00:00', operator: '林晓峰', action: '创建空间', content: '创建500GB节点临时空间用于数据接收' },
    ],
  },
  {
    id: 'TS-003',
    name: '推理任务工作区',
    spaceType: 'node',
    taskName: 'TASK-2026-0715-INFER',
    nodeName: '深圳推理节点-G1',
    totalSize: '1TB',
    usedSize: '680GB',
    mountPath: '/mnt/task-space/inference',
    rootDirName: 'inference',
    dirCount: 5,
    driver: 'NVMe-oF+CephFS',
    status: '使用中',
    mountedSources: [
      { name: 'OSS-模型仓库', path: '/oss/models' },
      { name: '本地NVMe池', path: '/local/nvme-pool' },
    ],
    creator: '黄志远',
    createTime: '2026-07-15 13:00:00',
    expireTime: '2026-08-15 13:00:00',
    auditLogs: [
      { time: '2026-07-15 13:00:00', operator: '黄志远', action: '创建空间', content: '创建1TB推理任务工作区' },
      { time: '2026-07-15 14:00:00', operator: '张伟', action: '审批通过', content: '推理工作区审批通过，有效期30天' },
    ],
  },
  {
    id: 'TS-004',
    name: '安全审计数据隔离区',
    spaceType: 'global',
    taskName: 'TASK-2026-0705-AUDIT',
    nodeName: '成都安全实验室',
    totalSize: '200GB',
    usedSize: '85GB',
    mountPath: '/mnt/task-space/audit',
    rootDirName: 'audit',
    dirCount: 3,
    driver: 'NFSv4(加密)',
    status: '使用中',
    mountedSources: [
      { name: '加密NAS-安全域', path: '/secure-nas/security' },
    ],
    creator: '吴雅琴',
    createTime: '2026-07-05 10:00:00',
    expireTime: '2026-07-30 10:00:00',
    auditLogs: [
      { time: '2026-07-05 10:00:00', operator: '吴雅琴', action: '创建空间', content: '创建200GB加密隔离区用于安全审计' },
    ],
  },
  {
    id: 'TS-005',
    name: '测试数据沙箱',
    spaceType: 'node',
    taskName: 'TASK-2026-0718-TEST',
    nodeName: '武汉测试节点-T1',
    totalSize: '100GB',
    usedSize: '12GB',
    mountPath: '/mnt/task-space/sandbox',
    rootDirName: 'sandbox',
    dirCount: 4,
    driver: 'tmpfs+overlay',
    status: '使用中',
    mountedSources: [
      { name: '测试数据集', path: '/test/datasets' },
    ],
    creator: '孙丽华',
    createTime: '2026-07-18 08:00:00',
    expireTime: '2026-07-23 08:00:00',
    auditLogs: [
      { time: '2026-07-18 08:00:00', operator: '孙丽华', action: '创建空间', content: '创建100GB测试沙箱空间' },
    ],
  },
];

const mockDirTree: DirNode[] = [
  {
    id: 'DIR-ROOT',
    name: 'ai-training',
    type: 'folder',
    permission: '读写',
    children: [
      {
        id: 'DIR-01',
        name: 'input',
        type: 'folder',
        permission: '只读',
        fileCount: 156,
        size: '820GB',
        modifyTime: '2026-07-20 18:30:00',
        modifier: '郑博文',
        children: [
          {
            id: 'DIR-01-01',
            name: 'remote-sensing',
            type: 'folder',
            permission: '只读',
            fileCount: 48,
            size: '256GB',
            modifyTime: '2026-07-21 09:15:00',
            modifier: '刘洋',
          },
          {
            id: 'DIR-01-02',
            name: 'weather-data',
            type: 'folder',
            permission: '只读',
            fileCount: 32,
            size: '12.8GB',
            modifyTime: '2026-07-20 14:30:00',
            modifier: '周杰',
          },
          {
            id: 'DIR-01-03',
            name: 'models-pretrained',
            type: 'folder',
            permission: '只读',
            fileCount: 76,
            size: '551.2GB',
            modifyTime: '2026-07-18 14:20:00',
            modifier: '郑博文',
          },
        ],
      },
      {
        id: 'DIR-02',
        name: 'temp',
        type: 'folder',
        permission: '读写',
        fileCount: 23,
        size: '45.6GB',
        modifyTime: '2026-07-20 20:00:00',
        modifier: '郑博文',
        children: [
          {
            id: 'DIR-02-01',
            name: 'checkpoints',
            type: 'folder',
            permission: '读写',
            fileCount: 15,
            size: '38.2GB',
            modifyTime: '2026-07-21 06:00:00',
            modifier: '孙磊',
          },
          {
            id: 'DIR-02-02',
            name: 'cache',
            type: 'folder',
            permission: '读写',
            fileCount: 8,
            size: '7.4GB',
            modifyTime: '2026-07-21 08:00:00',
            modifier: '孙磊',
          },
        ],
      },
      {
        id: 'DIR-03',
        name: 'output',
        type: 'folder',
        permission: '密码',
        fileCount: 34,
        size: '480GB',
        modifyTime: '2026-07-21 10:00:00',
        modifier: '郑博文',
        children: [
          {
            id: 'DIR-03-01',
            name: 'models-trained',
            type: 'folder',
            permission: '密码',
            fileCount: 12,
            size: '320GB',
            modifyTime: '2026-07-21 09:00:00',
            modifier: '郑博文',
          },
          {
            id: 'DIR-03-02',
            name: 'metrics',
            type: 'folder',
            permission: '只读',
            fileCount: 18,
            size: '120GB',
            modifyTime: '2026-07-21 09:30:00',
            modifier: '孙磊',
          },
          {
            id: 'DIR-03-03',
            name: 'predictions',
            type: 'folder',
            permission: '只读',
            fileCount: 4,
            size: '40GB',
            modifyTime: '2026-07-20 20:00:00',
            modifier: '周杰',
          },
        ],
      },
      {
        id: 'DIR-04',
        name: 'archive',
        type: 'folder',
        permission: '只读',
        fileCount: 8,
        size: '4.4GB',
        modifyTime: '2026-07-15 17:00:00',
        modifier: '张伟',
        children: [
          {
            id: 'DIR-04-01',
            name: 'logs',
            type: 'folder',
            permission: '只读',
            fileCount: 5,
            size: '2.8GB',
            modifyTime: '2026-07-15 17:00:00',
            modifier: '郑博文',
          },
          {
            id: 'DIR-04-02',
            name: 'reports',
            type: 'folder',
            permission: '密码',
            fileCount: 3,
            size: '1.6GB',
            modifyTime: '2026-07-14 12:00:00',
            modifier: '张伟',
          },
        ],
      },
      {
        id: 'DIR-05',
        name: 'configs',
        type: 'folder',
        permission: '读写',
        fileCount: 3,
        size: '256MB',
        modifyTime: '2026-07-20 09:00:00',
        modifier: '郑博文',
        children: [],
      },
    ],
  },
];

const mockPermUsers = [
  { id: 'PU-001', name: '张伟', type: 'user', dept: '技术部', role: '系统管理员' },
  { id: 'PU-002', name: '李娜', type: 'user', dept: '数据部', role: '数据部主管' },
  { id: 'PU-003', name: '技术部', type: 'role', dept: '技术部', role: '部门角色' },
  { id: 'PU-004', name: 'AI实验室', type: 'role', dept: 'AI实验室', role: '部门角色' },
  { id: 'PU-005', name: '安全审计组', type: 'role', dept: '安全部', role: '项目组角色' },
];

const mockMountSources: MountSource[] = [
  { id: 'MS-001', name: 'NAS-01-训练数据', path: '/nas/training-data', type: 'NFS', sourceNode: '北京存储节点-01', available: true },
  { id: 'MS-002', name: 'OSS-模型仓库', path: '/oss/models', type: '对象存储', sourceNode: '深圳数据基地', available: true },
  { id: 'MS-003', name: '分布式存储-华东池', path: '/dfs/east-pool', type: '分布式FS', sourceNode: '上海存储节点-S1', available: true },
  { id: 'MS-004', name: '加密NAS-安全域', path: '/secure-nas/security', type: '加密NAS', sourceNode: '成都备份节点-B1', available: true },
  { id: 'MS-005', name: '本地NVMe池', path: '/local/nvme-pool', type: '本地存储', sourceNode: '深圳推理节点-G1', available: false },
];

const mockBrowseFiles: BrowseFile[] = [
  {
    id: 'BF-001',
    name: 'model-checkpoint-epoch50.pth',
    resourceId: 'RES-20260721-001',
    dataType: '模型文件',
    format: 'PTH',
    size: '2.8GB',
    purpose: 'AI模型训练中间结果',
    fullPath: '/mnt/task-space/ai-training/temp/checkpoints/model-checkpoint-epoch50.pth',
    uploadTime: '2026-07-21 06:30:00',
    uploader: '孙磊',
  },
  {
    id: 'BF-002',
    name: 'sentinel-2-20260715.tif',
    resourceId: 'RES-20260715-002',
    dataType: '影像数据',
    format: 'GeoTIFF',
    size: '1.2GB',
    purpose: 'Sentinel-2卫星遥感影像',
    fullPath: '/mnt/task-space/ai-training/input/remote-sensing/sentinel-2-20260715.tif',
    uploadTime: '2026-07-15 14:00:00',
    uploader: '刘洋',
  },
  {
    id: 'BF-003',
    name: 'temperature-grid-202607.csv',
    resourceId: 'RES-20260718-003',
    dataType: '结构化数据',
    format: 'CSV',
    size: '380MB',
    purpose: '气象温度网格数据',
    fullPath: '/mnt/task-space/ai-training/input/weather-data/temperature-grid-202607.csv',
    uploadTime: '2026-07-18 10:00:00',
    uploader: '周杰',
  },
  {
    id: 'BF-004',
    name: 'detection-model-v3.onnx',
    resourceId: 'RES-20260721-004',
    dataType: '模型文件',
    format: 'ONNX',
    size: '850MB',
    purpose: '目标检测模型导出文件',
    fullPath: '/mnt/task-space/ai-training/output/models-trained/detection-model-v3.onnx',
    uploadTime: '2026-07-21 09:00:00',
    uploader: '郑博文',
  },
  {
    id: 'BF-005',
    name: 'training-log-20260720.log',
    resourceId: 'RES-20260720-005',
    dataType: '日志数据',
    format: 'LOG',
    size: '156MB',
    purpose: '模型训练过程日志',
    fullPath: '/mnt/task-space/ai-training/archive/logs/training-log-20260720.log',
    uploadTime: '2026-07-20 23:59:00',
    uploader: '孙磊',
  },
  {
    id: 'BF-006',
    name: 'accuracy-report-20260721.pdf',
    resourceId: 'RES-20260721-006',
    dataType: '文档数据',
    format: 'PDF',
    size: '4.2MB',
    purpose: '模型精度评估报告',
    fullPath: '/mnt/task-space/ai-training/output/metrics/accuracy-report-20260721.pdf',
    uploadTime: '2026-07-21 10:30:00',
    uploader: '郑博文',
  },
  {
    id: 'BF-007',
    name: 'feature-importance.json',
    resourceId: 'RES-20260721-007',
    dataType: '指标数据',
    format: 'JSON',
    size: '2.1MB',
    purpose: '特征重要性分析结果',
    fullPath: '/mnt/task-space/ai-training/output/metrics/feature-importance.json',
    uploadTime: '2026-07-21 09:45:00',
    uploader: '孙磊',
  },
  {
    id: 'BF-008',
    name: 'training-config.yaml',
    resourceId: 'RES-20260701-008',
    dataType: '配置文件',
    format: 'YAML',
    size: '8KB',
    purpose: '模型训练超参数配置',
    fullPath: '/mnt/task-space/ai-training/configs/training-config.yaml',
    uploadTime: '2026-07-01 09:00:00',
    uploader: '郑博文',
  },
  {
    id: 'BF-009',
    name: 'predictions-batch-20260720.json',
    resourceId: 'RES-20260720-009',
    dataType: '结果数据',
    format: 'JSON',
    size: '120MB',
    purpose: '模型预测结果批次数据',
    fullPath: '/mnt/task-space/ai-training/output/predictions/predictions-batch-20260720.json',
    uploadTime: '2026-07-20 20:00:00',
    uploader: '周杰',
  },
  {
    id: 'BF-010',
    name: 'bert-large-uncased.safetensors',
    resourceId: 'RES-20260718-010',
    dataType: '模型文件',
    format: 'SafeTensors',
    size: '1.2GB',
    purpose: 'BERT-large预训练模型权重',
    fullPath: '/mnt/task-space/ai-training/input/models-pretrained/bert-large-uncased.safetensors',
    uploadTime: '2026-07-18 14:20:00',
    uploader: '郑博文',
  },
  {
    id: 'BF-011',
    name: 'cache-manifest-20260721.db',
    resourceId: 'RES-20260721-011',
    dataType: '缓存数据',
    format: 'SQLite',
    size: '420MB',
    purpose: '训练数据缓存索引文件',
    fullPath: '/mnt/task-space/ai-training/temp/cache/cache-manifest-20260721.db',
    uploadTime: '2026-07-21 08:00:00',
    uploader: '孙磊',
  },
];

/* ---------- 资源监控 mock data ---------- */
const mockResourceOverview: ResourceOverview = {
  cpuTotal: 480,
  cpuUsed: 288,
  cpuUsage: 60.0,
  memoryTotal: 2048,
  memoryUsed: 1434,
  memoryUsage: 70.0,
  storageTotal: 51200,
  storageUsed: 30720,
  storageUsage: 60.0,
  nodeCount: 9,
  onlineNodes: 8,
};

const mockNodeResourceList: NodeResource[] = [
  {
    nodeId: 'LOCAL-001',
    nodeName: '北京主节点',
    cpuUsage: 67.5,
    memoryUsage: 72.3,
    storageUsage: 58.9,
    networkIn: 2560,
    networkOut: 1840,
    taskCount: 12,
    status: '运行中',
  },
  {
    nodeId: 'REM-001',
    nodeName: '上海云节点-A1',
    cpuUsage: 54.8,
    memoryUsage: 63.2,
    storageUsage: 41.7,
    networkIn: 1200,
    networkOut: 960,
    taskCount: 8,
    status: '运行中',
  },
  {
    nodeId: 'REM-003',
    nodeName: '深圳推理节点-G1',
    cpuUsage: 78.6,
    memoryUsage: 85.4,
    storageUsage: 53.2,
    networkIn: 4800,
    networkOut: 3600,
    taskCount: 20,
    status: '高负载',
  },
  {
    nodeId: 'REM-004',
    nodeName: '成都备份节点-B1',
    cpuUsage: 18.9,
    memoryUsage: 35.7,
    storageUsage: 88.2,
    networkIn: 600,
    networkOut: 400,
    taskCount: 2,
    status: '运行中',
  },
  {
    nodeId: 'REM-005',
    nodeName: '杭州开发节点-D1',
    cpuUsage: 42.3,
    memoryUsage: 55.8,
    storageUsage: 37.5,
    networkIn: 800,
    networkOut: 640,
    taskCount: 6,
    status: '维护中',
  },
];

const mockResourceTrend: ResourceTrendPoint[] = [
  { time: '2026-07-21 08:00', cpu: 45.2, memory: 55.8, storage: 52.1, network: 1200 },
  { time: '2026-07-21 10:00', cpu: 58.6, memory: 62.3, storage: 54.6, network: 1800 },
  { time: '2026-07-21 12:00', cpu: 72.1, memory: 75.4, storage: 57.2, network: 3200 },
  { time: '2026-07-21 14:00', cpu: 65.8, memory: 70.2, storage: 59.8, network: 2800 },
  { time: '2026-07-21 16:00', cpu: 60.3, memory: 68.9, storage: 60.5, network: 2400 },
  { time: '2026-07-21 18:00', cpu: 52.7, memory: 65.1, storage: 61.2, network: 1600 },
  { time: '2026-07-21 20:00', cpu: 48.9, memory: 60.4, storage: 61.8, network: 1300 },
];

const mockAlertThresholds: AlertThreshold[] = [
  {
    id: 'AT-001',
    name: 'CPU使用率告警',
    resource: 'cpu',
    warning: 80,
    critical: 95,
    enabled: true,
    notifyMethod: '短信+邮件',
  },
  {
    id: 'AT-002',
    name: '内存使用率告警',
    resource: 'memory',
    warning: 85,
    critical: 95,
    enabled: true,
    notifyMethod: '邮件+企业微信',
  },
  {
    id: 'AT-003',
    name: '存储使用率告警',
    resource: 'storage',
    warning: 80,
    critical: 90,
    enabled: true,
    notifyMethod: '邮件',
  },
  {
    id: 'AT-004',
    name: '网络带宽告警',
    resource: 'network',
    warning: 70,
    critical: 85,
    enabled: false,
    notifyMethod: '短信',
  },
];

const mockResourceReports: ResourceReportVO[] = [
  {
    id: 'RP-001',
    reportName: '2026年7月第三周资源使用周报',
    reportType: '周报',
    period: '2026-07-14 ~ 2026-07-20',
    format: 'PDF',
    status: '已生成',
    creator: '张伟',
    createTime: '2026-07-21 08:00:00',
  },
  {
    id: 'RP-002',
    reportName: '2026年7月资源使用日报-0720',
    reportType: '日报',
    period: '2026-07-20',
    format: 'PDF',
    status: '已生成',
    creator: '林晓峰',
    createTime: '2026-07-21 00:05:00',
  },
  {
    id: 'RP-003',
    reportName: '2026年Q3季度资源趋势分析',
    reportType: '季报',
    period: '2026-07-01 ~ 2026-09-30',
    format: 'Excel',
    status: '生成中',
    creator: '张伟',
    createTime: '2026-07-20 14:00:00',
  },
  {
    id: 'RP-004',
    reportName: '2026年6月资源使用月报',
    reportType: '月报',
    period: '2026-06-01 ~ 2026-06-30',
    format: 'PDF',
    status: '已生成',
    creator: '李娜',
    createTime: '2026-07-01 08:00:00',
  },
];

// ============================================================
// HELPER: wrap single item
// ============================================================
function res(data: any): any {
  return { code: 200, data, msg: 'ok' };
}

// HELPER: wrap paginated list
function pageRes(rows: any, total: number): any {
  return { code: 200, data: { rows, total }, msg: 'ok' };
}

// ============================================================
// 岗位管理 API
// ============================================================

/** real API: GET /task-resource/post/list */
export function getPostList(params?: any): Promise<any> {
  let list = [...mockPostList];
  if (params) {
    if (params.postType) {
      list = list.filter((p) => p.postType === params.postType);
    }
    if (params.name) {
      list = list.filter((p) => p.name?.includes(params!.name!));
    }
    if (params.operator) {
      list = list.filter((p) => p.operatorName?.includes(params!.operator!));
    }
    if (params.status) {
      list = list.filter((p) => p.status === params.status);
    }
  }
  return Promise.resolve(pageRes(list, list.length));
}

/** real API: GET /task-resource/post/logs/${id} */
export function getPostLogs(id: string): Promise<any> {
  const logs = mockPostAuditLogs[id] || [
    { time: '2026-07-01 08:00:00', operator: '系统', action: '初始化', content: '系统默认创建' },
  ];
  return Promise.resolve(res(logs));
}

/** real API: POST /task-resource/post */
export function createPost(data: any): Promise<any> {
  console.log('createPost mock:', data);
  return Promise.resolve(res(null));
}

/** real API: PUT /task-resource/post */
export function updatePost(data: any): Promise<any> {
  console.log('updatePost mock:', data);
  return Promise.resolve(res(null));
}

/** real API: DELETE /task-resource/post/${id} */
export function deletePost(id: string): Promise<any> {
  console.log('deletePost mock:', id);
  return Promise.resolve(res(null));
}

// ============================================================
// 单位管理 API
// ============================================================

/** real API: GET /task-resource/unit/list */
export function getUnitList(params?: any): Promise<any> {
  let list = [...mockUnitList];
  if (params) {
    if (params.unitName) {
      list = list.filter((u) => u.name?.includes(params!.unitName!));
    }
    if (params.category) {
      list = list.filter((u) => u.category === params.category);
    }
    if (params.status) {
      list = list.filter((u) => u.publishStatus === params.status || u.status === params.status);
    }
  }
  return Promise.resolve(pageRes(list, list.length));
}

/** real API: POST /task-resource/unit */
export function createUnit(data: any): Promise<any> {
  console.log('createUnit mock:', data);
  return Promise.resolve(res(null));
}

/** real API: PUT /task-resource/unit */
export function updateUnit(data: any): Promise<any> {
  console.log('updateUnit mock:', data);
  return Promise.resolve(res(null));
}

/** real API: DELETE /task-resource/unit/${id} */
export function deleteUnit(id: string): Promise<any> {
  console.log('deleteUnit mock:', id);
  return Promise.resolve(res(null));
}

/** real API: GET /task-resource/unit/versions/${id} */
export function getUnitVersions(id: string): Promise<any> {
  const versions = mockUnitVersions[id] || [];
  return Promise.resolve(res(versions));
}

/** real API: PUT /task-resource/unit/auth/${id} */
export function setUnitAuth(id: string, authConfig: any): Promise<any> {
  console.log('setUnitAuth mock:', { id, authConfig });
  return Promise.resolve(res(null));
}

// ============================================================
// 云基础设施 API
// ============================================================

/** real API: GET /task-resource/infra/local */
export function getLocalInfra(): Promise<any> {
  return Promise.resolve(res(mockLocalInfra));
}

/** real API: GET /task-resource/infra/remote/list */
export function getRemoteInfraList(params?: any): Promise<any> {
  let list = [...mockRemoteInfraList];
  if (params) {
    if (params.nodeName) {
      list = list.filter((n) => n.nodeName.includes(params!.nodeName!));
    }
    if (params.nodeType) {
      list = list.filter((n) => n.nodeType === params.nodeType);
    }
    if (params.status) {
      list = list.filter((n) => n.status === params.status);
    }
  }
  return Promise.resolve(pageRes(list, list.length));
}

/** real API: POST /task-resource/infra/remote/apply */
export function applyRemoteInfra(data: any): Promise<any> {
  console.log('applyRemoteInfra mock:', data);
  return Promise.resolve(res(null));
}

/** real API: GET /task-resource/infra/perm/list */
export function getInfraPermList(params?: any): Promise<any> {
  let list = [...mockInfraPermList];
  if (params) {
    if (params.nodeName) {
      list = list.filter((p) => p.nodeName.includes(params!.nodeName!));
    }
    if (params.status) {
      list = list.filter((p) => p.status === params.status);
    }
  }
  return Promise.resolve(pageRes(list, list.length));
}

/** real API: PUT /task-resource/infra/perm */
export function setInfraPerm(data: any): Promise<any> {
  console.log('setInfraPerm mock:', data);
  return Promise.resolve(res(null));
}

/** real API: GET /task-resource/infra/perm/logs */
export function getInfraPermLogs(): Promise<any> {
  return Promise.resolve(res(mockInfraPermLogs));
}

// ============================================================
// 作业资料管理 API
// ============================================================

/** real API: GET /task-resource/data/apply/list */
export function getApplyList(params?: any): Promise<any> {
  let list = [...mockApplyList];
  if (params) {
    if (params.dataName) {
      list = list.filter((a) => a.dataName.includes(params!.dataName!));
    }
    if (params.applyDirection) {
      list = list.filter((a) => a.applyDirection === params.applyDirection);
    }
    if (params.status) {
      list = list.filter((a) => a.status === params.status);
    }
  }
  return Promise.resolve(pageRes(list, list.length));
}

/** real API: POST /task-resource/data/apply */
export function createApply(data: any): Promise<any> {
  console.log('createApply mock:', data);
  return Promise.resolve(res(null));
}

/** real API: GET /task-resource/data/receive/list */
export function getReceiveList(params?: any): Promise<any> {
  let list = [...mockReceiveList];
  if (params) {
    if (params.dataName) {
      list = list.filter((r) => r.dataName.includes(params!.dataName!));
    }
    if (params.status) {
      list = list.filter((r) => r.status === params.status);
    }
  }
  return Promise.resolve(pageRes(list, list.length));
}

/** real API: PUT /task-resource/data/receive/process/${id} */
export function processReceive(id: string, action: string): Promise<any> {
  console.log('processReceive mock:', { id, action });
  return Promise.resolve(res(null));
}

/** real API: GET /task-resource/data/push/list */
export function getPushList(params?: any): Promise<any> {
  let list = [...mockPushList];
  if (params) {
    if (params.dataName) {
      list = list.filter((p) => p.dataName.includes(params!.dataName!));
    }
    if (params.status) {
      list = list.filter((p) => p.status === params.status);
    }
  }
  return Promise.resolve(pageRes(list, list.length));
}

/** real API: POST /task-resource/data/push */
export function executePush(data: any): Promise<any> {
  console.log('executePush mock:', data);
  return Promise.resolve(res(null));
}

// ============================================================
// 临时空间管理 API
// ============================================================

/** real API: GET /task-resource/space/list */
export function getSpaceList(params?: any): Promise<any> {
  let list = [...mockSpaceList];
  if (params) {
    if (params.name) {
      list = list.filter((s) => s.name.includes(params!.name!));
    }
    if (params.spaceType) {
      list = list.filter((s) => s.spaceType === params.spaceType);
    }
    if (params.status) {
      list = list.filter((s) => s.status === params.status);
    }
  }
  return Promise.resolve(pageRes(list, list.length));
}

/** real API: POST /task-resource/space */
export function applySpace(data: any): Promise<any> {
  console.log('applySpace mock:', data);
  return Promise.resolve(res(null));
}

/** real API: DELETE /task-resource/space/${id} */
export function deleteSpace(id: string): Promise<any> {
  console.log('deleteSpace mock:', id);
  return Promise.resolve(
    res({
      confirmText: '删除后将永久清除所有数据且不可恢复，请确认是否继续？',
      requirePassword: true,
    }),
  );
}

/** real API: GET /task-resource/space/dir-tree/${spaceId} */
export function getDirTree(spaceId: string): Promise<any> {
  console.log('getDirTree mock:', spaceId);
  return Promise.resolve(res(mockDirTree));
}

/** real API: GET /task-resource/space/perm-users */
export function getPermUsers(): Promise<any> {
  return Promise.resolve(res(mockPermUsers));
}

/** real API: PUT /task-resource/space/dir-perm */
export function setDirPerm(data: Record<string, any>): Promise<any> {
  console.log('setDirPerm mock:', data);
  return Promise.resolve(res(null));
}

/** real API: GET /task-resource/space/mount-sources */
export function getMountSources(): Promise<any> {
  return Promise.resolve(res(mockMountSources));
}

/** real API: POST /task-resource/space/mount */
export function mountPath(data: Record<string, any>): Promise<any> {
  console.log('mountPath mock:', data);
  return Promise.resolve(res(null));
}

/** real API: DELETE /task-resource/space/unmount/${spaceId}/${mountId} */
export function unmountPath(spaceId: string, mountId: string): Promise<any> {
  console.log('unmountPath mock:', { spaceId, mountId });
  return Promise.resolve(res(null));
}

/** real API: GET /task-resource/space/browse-files/${spaceId}/${dirId} */
export function getBrowseFiles(
  spaceId: string,
  dirId: string,
): Promise<any> {
  console.log('getBrowseFiles mock:', { spaceId, dirId });
  return Promise.resolve(res(mockBrowseFiles));
}

/** real API: POST /task-resource/space/upload/${spaceId}/${dirId} */
export function uploadFile(
  spaceId: string,
  dirId: string,
  data: Record<string, any>,
): Promise<any> {
  console.log('uploadFile mock:', { spaceId, dirId, data });
  return Promise.resolve(res(null));
}

/** real API: GET /task-resource/space/audit-logs/${spaceId} */
export function getSpaceAuditLogs(spaceId: string): Promise<any> {
  const space = mockSpaceList.find((s) => s.id === spaceId);
  const logs = space?.auditLogs || [];
  return Promise.resolve(res(logs));
}

// ============================================================
// 资源监控 API
// ============================================================

/** real API: GET /task-resource/monitor/overview */
export function getResourceOverview(): Promise<any> {
  return Promise.resolve(res(mockResourceOverview));
}

/** real API: GET /task-resource/monitor/node-list */
export function getNodeResourceList(): Promise<any> {
  return Promise.resolve(res(mockNodeResourceList));
}

/** real API: GET /task-resource/monitor/trend */
export function getResourceTrend(params?: { startTime?: string; endTime?: string }): Promise<any> {
  console.log('getResourceTrend mock:', params);
  return Promise.resolve(res(mockResourceTrend));
}

/** real API: GET /task-resource/monitor/alert-thresholds */
export function getAlertThresholds(): Promise<any> {
  return Promise.resolve(res(mockAlertThresholds));
}

/** real API: PUT /task-resource/monitor/alert-threshold */
export function saveAlertThreshold(data: any): Promise<any> {
  console.log('saveAlertThreshold mock:', data);
  return Promise.resolve(res(null));
}

/** real API: GET /task-resource/monitor/reports */
export function getResourceReports(params?: any): Promise<any> {
  let list = [...mockResourceReports];
  if (params) {
    if (params.reportType) {
      list = list.filter((r) => r.reportType === params.reportType);
    }
    if (params.status) {
      list = list.filter((r) => r.status === params.status);
    }
  }
  return Promise.resolve(res(list));
}

/** real API: POST /task-resource/monitor/report */
export function generateReport(data: any): Promise<any> {
  console.log('generateReport mock:', data);
  return Promise.resolve(res(null));
}
