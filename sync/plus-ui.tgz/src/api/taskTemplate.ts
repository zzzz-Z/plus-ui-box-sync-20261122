import request from '@/utils/request';

/**
 * 任务调度模板接口
 * 说明：接口带 /dolphinscheduler 前缀，与作业单元、作业岗位同属海豚服务
 */
export const TASK_TEMPLATE_BASE = '/dolphinscheduler/task-templates';

/** 模板子任务项 */
export interface TaskTemplateItem {
  /** 子任务名称 */
  subTaskName?: string;
  /** 排序 */
  sortOrder?: number;
  /** 执行方式 */
  execMode?: string;
  /** 备注 */
  remark?: string;
  /** 配置的作业单元 id 集合 */
  workUnitIds?: number[];
  [property: string]: any;
}

/** 任务调度模板请求体 */
export interface TaskTemplateRequest {
  /** 主键（修改时必传） */
  id?: string | number;
  /** 模板名称 */
  name?: string;
  /** 任务类型 */
  taskType?: string;
  /** 产品类别 */
  productCategory?: string;
  /** 任务规模 */
  taskScale?: string;
  /** 模板描述 */
  description?: string;
  /** 子任务清单 */
  items?: TaskTemplateItem[];
  [property: string]: any;
}

/** 分页查询任务调度模板 */
export const listTaskTemplates = (params: {
  pageNo: number;
  pageSize: number;
  taskType?: string;
  productCategory?: string;
  taskScale?: string;
  /** 创建人（后端存登录名 userName） */
  createBy?: string;
  /** 审批状态：pending 待审批 / approved 已通过 / rejected 已驳回 */
  approveStatus?: string;
  [property: string]: any;
}) => {
  return request({ url: TASK_TEMPLATE_BASE, method: 'get', params });
};

/**
 * 我的待审批模板（「待我审批」页签取数）
 * GET /task-templates/pageByMyApprove
 */
export const listMyApproveTemplates = (params: { pageNo: number; pageSize: number; [property: string]: any }) => {
  return request({ url: `${TASK_TEMPLATE_BASE}/pageByMyApprove`, method: 'get', params });
};

/** 查询任务调度模板详情（含子任务及作业单元） */
export const getTaskTemplate = (id: string | number) => {
  return request({ url: `${TASK_TEMPLATE_BASE}/${String(id)}`, method: 'get' });
};

/** 推荐任务调度模板（按主任务自动匹配） */
export const recommendTaskTemplates = (mainProjectId: string | number) => {
  return request({ url: `${TASK_TEMPLATE_BASE}/recommend`, method: 'get', params: { mainProjectId } });
};

/** 创建任务调度模板 */
export const createTaskTemplate = (data: TaskTemplateRequest) => {
  return request({ url: TASK_TEMPLATE_BASE, method: 'post', data });
};

/** 修改任务调度模板 */
export const updateTaskTemplate = (data: TaskTemplateRequest) => {
  return request({ url: TASK_TEMPLATE_BASE, method: 'put', data });
};

/** 标记（废除）任务调度模板 */
export const abolishTaskTemplate = (id: string | number) => {
  return request({ url: `${TASK_TEMPLATE_BASE}/${String(id)}/abolish`, method: 'post' });
};

/** 删除任务调度模板 */
export const deleteTaskTemplate = (id: string | number) => {
  return request({ url: `${TASK_TEMPLATE_BASE}/${String(id)}`, method: 'delete' });
};

/**
 * 提交模板审批：POST /task-templates/{id}/submit
 *
 * @param id         模板ID
 * @param approverId 审批人用户ID（后端写 approver_id 并把状态置为 pending）
 *
 * 后端会校验「提交人 == 创建人」。
 */
export const submitTaskTemplate = (id: string | number, approverId?: string | number) => {
  return request({
    url: `${TASK_TEMPLATE_BASE}/${String(id)}/submit`,
    method: 'post',
    params: approverId ? { approverId } : {}
  });
};

/**
 * 模板审批通过：POST /task-templates/{id}/approve
 *
 * 注意：改造后**不再传 approveBy**，后端一律取当前登录用户，
 * 并校验「当前登录用户 == approver_id」，否则返回无权限。
 */
export const approveTaskTemplate = (id: string | number) => {
  return request({ url: `${TASK_TEMPLATE_BASE}/${String(id)}/approve`, method: 'post' });
};

/**
 * 模板审批驳回：POST /task-templates/{id}/reject?opinion=
 * 后端校验同上，意见写入 approve_remark，状态置为 rejected。
 */
export const rejectTaskTemplate = (id: string | number, opinion: string) => {
  return request({
    url: `${TASK_TEMPLATE_BASE}/${String(id)}/reject`,
    method: 'post',
    params: { opinion }
  });
};
