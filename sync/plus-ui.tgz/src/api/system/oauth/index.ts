import request from '@/utils/request';
import { AxiosPromise } from 'axios';
import { OauthVO, OauthForm, OauthQuery } from './types';

/**
 * 查询客户端列表
 */
export function listOauth(query?: OauthQuery): AxiosPromise<OauthVO[]> {
  return request({
    url: '/system/oauth/client/list',
    method: 'get',
    params: query
  });
}

/**
 * 查询客户端详细
 */
export function getOauth(id: number | string): AxiosPromise<OauthVO> {
  return request({
    url: '/system/oauth/client/' + id,
    method: 'get'
  });
}

/**
 * 新增客户端
 */
export function addOauth(data: OauthForm) {
  return request({
    url: '/system/oauth/client',
    method: 'post',
    data: data
  });
}

/**
 * 修改客户端
 */
export function updateOauth(data: OauthForm) {
  return request({
    url: '/system/oauth/client',
    method: 'put',
    data: data
  });
}

/**
 * 删除客户端
 */
export function delOauth(id: number | string | Array<number | string>) {
  return request({
    url: '/system/oauth/client/' + id,
    method: 'delete'
  });
}
