/** OAuth 客户端 VO */
export interface OauthVO {
  /** id */
  id: number;
  /** 子系统名 */
  subSystemName: string;
  /** 客户端id */
  clientId: string;
  /** 客户端秘钥 */
  clientSecret: string;
  /** 授权类型 */
  grantTypeList: string[];
  /** 授权类型（拼接字符串） */
  grantType: string;
  /** 授权范围 */
  scope: string;
  /** 回调地址 */
  redirectUri: string;
  /** access_token有效期(秒) */
  accessTokenTimeout: number;
  /** refresh_token有效期(秒) */
  refreshTokenTimeout: number;
  /** 状态（0正常 1停用） */
  status: string;
}

/** OAuth 客户端表单 */
export interface OauthForm extends BaseEntity {
  /** id */
  id?: number;
  /** 子系统名 */
  subSystemName?: string;
  /** 客户端id */
  clientId?: string;
  /** 客户端秘钥 */
  clientSecret?: string;
  /** 授权类型 */
  grantTypeList?: string[];
  /** 授权类型（拼接字符串） */
  grantType?: string;
  /** 授权范围 */
  scope?: string;
  /** 回调地址 */
  redirectUri?: string;
  /** access_token有效期(秒) */
  accessTokenTimeout?: number;
  /** refresh_token有效期(秒) */
  refreshTokenTimeout?: number;
  /** 状态（0正常 1停用） */
  status?: string;
}

/** OAuth 客户端查询 */
export interface OauthQuery extends PageQuery {
  /** 子系统名 */
  subSystemName?: string;
  /** 状态 */
  status?: string;
}
