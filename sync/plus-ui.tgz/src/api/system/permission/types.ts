export interface PermissionTreeOption {
  id: string | number;
  label: string;
  parentId: string | number;
  weight: number;
  children?: PermissionTreeOption[];
}

export interface RolePermissionTree {
  permissions: PermissionTreeOption[];
  checkedKeys: string[];
}

export interface PermissionQuery {
  keywords?: string;
  permissionName?: string;
  permissionType?: string;
  category?: string;
  status?: string;
}

export interface PermissionVO extends BaseEntity {
  parentName: string;
  parentId: string | number;
  children: PermissionVO[];
  permissionId: string | number;
  permissionName: string;
  permissionCode: string;
  permissionType: string;
  category: string;
  actionType?: string;
  orderNum: number;
  status: string;
  icon?: string;
  remark: string;
  hasChildren?: boolean;
}

export interface PermissionForm {
  parentName?: string;
  parentId?: string | number;
  children?: PermissionForm[];
  permissionId?: string | number;
  permissionName: string;
  permissionCode: string;
  permissionType: string;
  category?: string;
  actionType?: string;
  orderNum: number;
  status?: string;
  icon?: string;
  remark?: string;
}
