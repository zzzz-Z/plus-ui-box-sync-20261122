import request from '@/utils/request';
import { AxiosPromise } from 'axios';
import { PermissionQuery, PermissionVO, PermissionForm, PermissionTreeOption, RolePermissionTree } from './types';

export const listPermission = (query?: PermissionQuery): AxiosPromise<PermissionVO[]> => {
  return request({
    url: '/system/permission/list',
    method: 'get',
    params: query
  });
};

export const getPermission = (permissionId: string | number): AxiosPromise<PermissionVO> => {
  return request({
    url: '/system/permission/' + permissionId,
    method: 'get'
  });
};

export const treeselect = (): AxiosPromise<PermissionTreeOption[]> => {
  return request({
    url: '/system/permission/treeselect',
    method: 'get'
  });
};

export const rolePermissionTreeselect = (roleId: string | number): AxiosPromise<RolePermissionTree> => {
  return request({
    url: '/system/permission/rolePermissionTreeselect/' + roleId,
    method: 'get'
  });
};

export const addPermission = (data: PermissionForm) => {
  return request({
    url: '/system/permission',
    method: 'post',
    data: data
  });
};

export const updatePermission = (data: PermissionForm) => {
  return request({
    url: '/system/permission',
    method: 'put',
    data: data
  });
};

export const delPermission = (permissionId: string | number) => {
  return request({
    url: '/system/permission/' + permissionId,
    method: 'delete'
  });
};

export const cascadeDelPermission = (permissionIds: Array<string | number>) => {
  return request({
    url: '/system/permission/cascade/' + permissionIds,
    method: 'delete'
  });
};
