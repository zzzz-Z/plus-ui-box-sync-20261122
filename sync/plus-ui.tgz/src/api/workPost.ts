import request, { parseJsonKeepLongIds } from '@/utils/request';

/**
 * 作业岗位接口基础路径
 * 说明：作业岗位接口需带 /dolphinscheduler 前缀，
 * 如后端路径调整，只需修改这一处即可。
 */
export const WORK_POST_BASE = '/dolphinscheduler/work-posts';

// 作业单元相关接口统一放在 @/api/workUnitDs，这里转发导出，保持既有引用可用
export { WORK_UNIT_BASE, AUTH_TYPE_OPTIONS, listWorkUnits } from '@/api/workUnitDs';
export type { WorkUnitQuery } from '@/api/workUnitDs';

/** 作业岗位查询参数 GET /work-posts */
export interface WorkPostQuery {
  /** 配置作业人员名称 */
  operatorName?: string;
  /** 页码（必填） */
  pageNo: number;
  /** 每页条数（必填） */
  pageSize: number;
  /** 岗位类型：智能提取 / 属性挖掘 / 地质 / lh融合 / 人机协同 / 矢量组网 */
  postType?: string;
  /** 岗位名称（模糊查询） */
  searchName?: string;
  [property: string]: any;
}

/** 作业岗位新增/修改参数 POST /work-posts */
export interface WorkPostRequest {
  /** 访问权限：公开 / 申请查看 / 不可查看 */
  accessPerm?: string;
  /** 所属部门 */
  deptName?: string;
  /** 描述 */
  description?: string;
  /** 主键（修改时必传） */
  id?: string | number;
  /** 配置作业人员 id（一个岗位一名） */
  operatorId?: string | number;
  /** 配置作业人员名称 */
  operatorName?: string;
  /** 岗位编号（对外标识，唯一） */
  postCode?: string;
  /** 岗位名称 */
  postName?: string;
  /** 岗位类型 */
  postType?: string;
  /** 席位地址 */
  seatAddress?: string;
  [property: string]: any;
}

/** 查询作业岗位列表 */
export const listWorkPost = (params: WorkPostQuery) => {
  return request({
    url: WORK_POST_BASE,
    method: 'get',
    params,
    // 岗位主键为长整型，解析时保留为字符串，避免精度丢失
    transformResponse: [parseJsonKeepLongIds]
  });
};

/**
 * 新增作业岗位
 *
 * 注意：只能用于新增。后端 `POST /work-posts` 走 createWorkPost，**不认 id**，
 * 且会校验 postCode 重复——拿它当"保存"去改已有岗位会报「岗位编码已存在」，
 * 改了编码则会被当成新岗位插入一条。修改请用 {@link updateWorkPost}。
 */
export const saveWorkPost = (data: WorkPostRequest) => {
  return request({ url: WORK_POST_BASE, method: 'post', data });
};

/**
 * 修改作业岗位（PUT，body 必须带 id）
 *
 * 与后端 `@PutMapping` 对应：校验 id 必填、岗位存在、改编码时查重，只更新非空字段。
 */
export const updateWorkPost = (data: WorkPostRequest) => {
  return request({ url: WORK_POST_BASE, method: 'put', data });
};

/** 删除作业岗位 */
export const deleteWorkPost = (id: string | number) => {
  return request({ url: `${WORK_POST_BASE}/${String(id)}`, method: 'delete' });
};

/** 岗位挂接作业单元参数 */
export interface WorkPostUnitRequest {
  /** 作业单元编码 */
  unitCode?: string;
  /** 使用权限：0=不可用，1=独占使用，2=共享使用 */
  authType?: string;
  /** 使用时限开始 */
  validStart?: string;
  /** 使用时限结束 */
  validEnd?: string;
}

/** 查询岗位已挂接的作业单元 */
export const listPostUnits = (id: string | number) => {
  return request({
    url: `${WORK_POST_BASE}/${String(id)}/units`,
    method: 'get',
    transformResponse: [parseJsonKeepLongIds]
  });
};

/** 挂接作业单元（批量，已挂接的自动覆盖） */
export const bindPostUnits = (id: string | number, data: WorkPostUnitRequest[]) => {
  return request({ url: `${WORK_POST_BASE}/${String(id)}/units`, method: 'post', data });
};

/** 修改岗位下某个作业单元的使用权限 */
export const updatePostUnitAuth = (
  id: string | number,
  unitCode: string,
  params: { authType: string; validStart?: string; validEnd?: string }
) => {
  return request({
    url: `${WORK_POST_BASE}/${String(id)}/units/${encodeURIComponent(String(unitCode))}/auth`,
    method: 'put',
    params
  });
};

/** 解除岗位与作业单元的挂接 */
export const unbindPostUnit = (id: string | number, unitCode: string) => {
  return request({
    url: `${WORK_POST_BASE}/${String(id)}/units/${encodeURIComponent(String(unitCode))}`,
    method: 'delete'
  });
};

/**
 * 作业岗位日志
 * 后端暂未提供日志接口，先沿用本地数据，接口给出后替换此处实现即可
 */
export { getPostLogs as getWorkPostLogs } from '@/api/task-resource';

/**
 * 作业人员候选名单（「分配人员」下拉）
 *
 * 复用审批人候选专用接口 GET /system/user/approver-options：
 * 只校验登录、只返回选人所需的 { userId, userName, nickName }，
 * 不依赖 system:user:list 这类系统管理权限（否则普通角色会 403、下拉为空）。
 */
export { queryApproverOptions as listOperatorOptions } from '@/api/dolphinscheduler/projects';
