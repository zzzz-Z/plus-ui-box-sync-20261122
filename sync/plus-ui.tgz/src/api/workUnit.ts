import request, { parseJsonKeepLongIds } from '@/utils/request';
import { WorkUnitForm, WorkUnitQuery } from '@/types/workUnit';

/** 分页查询作业单元 */
export const listWorkUnit = (params: WorkUnitQuery) => {
  return request({
    url: '/taskResource/workUnit/list',
    method: 'get',
    params,
    // 后端 Long 型 id 超过 JS 安全整数范围，需在解析时保留为字符串，避免精度丢失
    transformResponse: [parseJsonKeepLongIds]
  });
};

/** 新增作业单元 */
export const createWorkUnit = (data: WorkUnitForm) => {
  return request({ url: '/taskResource/workUnit', method: 'post', data });
};

/** 修改作业单元 */
export const updateWorkUnit = (data: WorkUnitForm) => {
  return request({ url: '/taskResource/workUnit', method: 'put', data });
};

/** 批量删除作业单元（ids 逗号分隔） */
export const deleteWorkUnit = (ids: string | number | Array<string | number>) => {
  const idList = (Array.isArray(ids) ? ids : [ids]).filter((id) => id !== undefined && id !== null && id !== '');
  const idString = idList.map((id) => String(id)).join(',');
  return request({ url: `/taskResource/workUnit/${idString}`, method: 'delete' });
};

/** 发布作业单元 */
export const publishWorkUnit = (id: string | number) => {
  return request({ url: `/taskResource/workUnit/${String(id)}/publish`, method: 'post' });
};

/** 下线作业单元 */
export const offlineWorkUnit = (id: string | number) => {
  return request({ url: `/taskResource/workUnit/${String(id)}/offline`, method: 'post' });
};
