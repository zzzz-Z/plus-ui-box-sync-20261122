import request, { parseJsonKeepLongIds } from '@/utils/request';

/**
 * 作业单元（海豚服务）接口基础路径
 * 使用权限、作业记录、节点 URL 等接口均在 /work-units 下
 */
export const WORK_UNIT_BASE = '/dolphinscheduler/work-units';

/**
 * 节点类型（唯一来源）：作业单元管理页、流程配置右侧面板都引用这里，
 * 避免多处各写一份导致"通用节点 / 通用"这类对不上的问题。
 */
export const WORK_UNIT_NODE_TYPES = [
  '智能提取',
  '属性挖掘',
  '军事地质',
  '陆海融合',
  '人机协同',
  '矢量组网',
  '通用',
  '其他'
] as const;

/** 逻辑节点条件：比较符 */
export const LOGIC_OPERATORS = [
  { value: 'EXISTS', label: '存在（有值）', needValue: false },
  { value: 'NOT_EXISTS', label: '不存在', needValue: false },
  { value: 'EMPTY', label: '为空', needValue: false },
  { value: 'NOT_EMPTY', label: '非空', needValue: false },
  { value: 'GT', label: '大于', needValue: true },
  { value: 'GTE', label: '大于等于', needValue: true },
  { value: 'LT', label: '小于', needValue: true },
  { value: 'LTE', label: '小于等于', needValue: true },
  { value: 'EQ', label: '等于', needValue: true },
  { value: 'NEQ', label: '不等于', needValue: true },
  { value: 'CONTAINS', label: '包含', needValue: true },
  { value: 'NOT_CONTAINS', label: '不包含', needValue: true }
] as const;

/** 逻辑节点条件：值类型 */
export const LOGIC_VALUE_TYPES = [
  { value: 'number', label: '数值' },
  { value: 'string', label: '字符串' },
  { value: 'boolean', label: '布尔' },
  { value: 'date', label: '日期' }
] as const;

/** 上游节点可用的现成字段（payload.* 由用户按作业单元回传的字段名填） */
export const LOGIC_NODE_FIELD_PRESETS = [
  { value: 'status', label: '执行状态(status)' },
  { value: 'progress', label: '进度(progress)' },
  { value: 'resultPath', label: '成果路径(resultPath)' },
  { value: 'errorInfo', label: '错误信息(errorInfo)' }
] as const;

/** 作业单元使用权限：0=不可用，1=独占使用，2=共享使用 */
export const AUTH_TYPE_OPTIONS = [
  { value: '1', label: '独占使用' },
  { value: '2', label: '共享使用' },
  { value: '0', label: '不可用' }
];

/** 作业单元列表查询参数 */
export interface WorkUnitQuery {
  searchName?: string;
  authType?: string;
  publishStatus?: string;
  pageNo: number;
  pageSize: number;
}

/** 作业单元注册/修改参数 */
export interface WorkUnitRequest {
  /** 修改时必传 */
  id?: string | number;
  /** 作业单元编码（唯一） */
  unitCode?: string;
  /** 作业单元名称 */
  unitName?: string;
  /** 业务系统 clientId */
  clientId?: string;
  /** 作业单元类型 */
  unitType?: string;
  /** 节点类型：智能提取/属性挖掘/军事地质/陆海融合/人机协同/矢量组网/通用/逻辑/其他 */
  nodeType?: string;
  /** 业务系统执行地址/服务地址 */
  baseUrl?: string;
  /** 参数模板 */
  paramsTemplate?: string;
  /**
   * 私有参数（全量覆盖语义）：
   *  - 不传（undefined/null）= 不修改；
   *  - 传 [] = 清空该单元全部私有参数；
   *  - 传数组 = 先删后插，以提交内容为准。
   */
  privateParams?: WorkUnitParam[];
  /** 可执行文件路径/入口（非 HTTP 类单元为必填阻断项） */
  execPath?: string;
  /** 技术文档路径（URL 或本地/UNC 路径） */
  docPath?: string;
  /** 元数据，必须是合法 JSON 字符串；修改时传空串表示清空 */
  metadata?: string;
  /** 版本号，不传默认 1.0.0；修改时非空才更新 */
  unitVersion?: string;
  /**
   * 扩展配置（JSON 字符串）。
   * 历史字段：早期"逻辑"类型作业单元用它存条件规则模板；
   * 逻辑节点现已改为流程画布里的内置节点（规则存在节点的 taskParams.logicConfig），
   * 这里保留仅为兼容存量数据。
   * 对应后端新增列 t_ds_work_unit.ext_config。
   */
  extConfig?: string;
  /** 描述 */
  description?: string;
  /** 使用权限：0=不可用，1=独占使用，2=共享使用 */
  authType?: string;
  /**
   * 调取上一级成果数据："1"=是（默认，接收全部直接上游的成果）/"0"=否（不接收，除非在流程节点里点名某个上游）
   * 注册时不传视为 "1"；修改时不传表示不修改
   */
  useUpstreamInput?: string;
  /**
   * 是否有成果数据："1"=有（默认，报成功后还要等成果上报才推进下游）/"0"=无（报成功即推进下游）
   * 注册时不传视为 "1"；修改时不传表示不修改
   */
  hasAchievement?: string;
  [property: string]: any;
}

/**
 * 作业单元参数（公有/私有共用结构）
 * 公有参数由后端固定返回（2026-10-12 实测 18 条，含 taskTypeName；前端不硬编码，按接口渲染），系统下发时统一组装填值，前端只读展示。
 */
export interface WorkUnitParam {
  id?: number;
  /** 参数名（私有参数必填，同单元内唯一，且不得与公有参数重名） */
  paramName: string;
  /** 参数说明 */
  paramDesc?: string;
  /** 参数类型：string / integer / number / date / dict */
  paramType: string;
  /** 字典类型编码，仅 paramType=dict 时必填 */
  dictType?: string | null;
  /** 是否必填："1"=是 "0"=否（缺省 0） */
  required?: string;
  /** 示例值 */
  exampleValue?: string;
  /** 显示顺序，缺省按提交顺序 */
  sortOrder?: number;
  /** common 公有 / private 私有 */
  scope?: string;
}

/** 作业单元详情（基本信息 + 公有参数 + 私有参数） */
export interface WorkUnitDetail {
  id: number;
  unitCode: string;
  unitName: string;
  clientId?: string;
  unitType?: string;
  nodeType?: string;
  baseUrl?: string | null;
  execPath?: string | null;
  docPath?: string | null;
  metadata?: string | null;
  unitVersion?: string | null;
  description?: string | null;
  authType?: string;
  publishStatus?: string;
  publishTime?: string | null;
  offlineTime?: string | null;
  createBy?: string | null;
  createTime?: string | null;
  updateBy?: string | null;
  updateTime?: string | null;
  occupied?: boolean;
  occupier?: string | null;
  fullOccupier?: string | null;
  /** 调取上一级成果数据："1"=是 / "0"=否；历史数据取不到值时后端按 "1" 返回 */
  useUpstreamInput?: string | null;
  /** 是否有成果数据："1"=有 / "0"=无；历史数据取不到值时后端按 "1" 返回 */
  hasAchievement?: string | null;
  commonParams?: WorkUnitParam[];
  privateParams?: WorkUnitParam[];
}

/** 发布前审核明细项 */
export interface WorkUnitCheckItem {
  /** BASIC_INFO / ENTRY_URL / EXEC_PATH / DOC_PATH / METADATA / PRIVATE_PARAM */
  item: string;
  itemName: string;
  /** 是否必填阻断项 */
  required: boolean;
  passed: boolean;
  message: string;
  path?: string | null;
}

/** 发布前完整性审核结果 */
export interface WorkUnitCheckResult {
  id: number;
  unitCode: string;
  unitName: string;
  /** 必填阻断项全部通过才可发布 */
  canPublish: boolean;
  requiredFailedCount: number;
  warnFailedCount: number;
  items: WorkUnitCheckItem[];
}

/** 路径可访问性测试结果 */
export interface WorkUnitPathTestResult {
  /** base / exec / doc */
  target: string;
  path?: string | null;
  /** url / file */
  pathType?: string | null;
  reachable: boolean;
  httpStatus?: number | null;
  costMs?: number | null;
  message: string;
}

/** 技术文档与版本信息 */
export interface WorkUnitDocInfo {
  id: number;
  unitCode: string;
  unitName: string;
  docPath?: string | null;
  /** null=未检测（需点测试按钮） */
  docReachable?: boolean | null;
  execPath?: string | null;
  metadata?: string | null;
  unitVersion?: string | null;
  publishStatus?: string;
  publishTime?: string | null;
  offlineTime?: string | null;
  createTime?: string | null;
  updateBy?: string | null;
  updateTime?: string | null;
  privateParamCount?: number;
}

/**
 * 参数类型选项。
 * 后端 param_type 是 varchar(32) 的自由字符串（无枚举校验），这里按约定给出可选类型；
 * object / array 的值按 JSON 文本存储。
 */
export const PARAM_TYPE_OPTIONS = [
  { value: 'string', label: '字符串' },
  { value: 'integer', label: '整数' },
  { value: 'number', label: '数值' },
  { value: 'date', label: '日期' },
  { value: 'dict', label: '字典' },
  { value: 'object', label: '对象' },
  { value: 'array', label: '数组' }
] as const;

/** 逻辑节点单条判断条件 */
export interface LogicRule {
  /**
   * 取值来源：
   *  - upstream：按顺序取上游节点（作业单元模板里用，落流程节点时解析成具体节点）
   *  - node：具体节点（流程节点级配置）
   *  - const：常量
   */
  sourceType: 'upstream' | 'node' | 'const';
  /** sourceType=upstream 时的上游序号（1 表示第一个上游节点） */
  upstreamIndex?: number;
  /** sourceType=node 时的上游节点 code */
  sourceNodeCode?: number | string;
  /** 取值字段：status / progress / resultPath / errorInfo / payload.<key> */
  field?: string;
  /** 值类型 */
  type: 'number' | 'string' | 'boolean' | 'date';
  /** 比较符 */
  operator: string;
  /** 比较目标值 */
  value?: string;
}

/** 逻辑节点分支定义 */
export interface LogicBranch {
  key: string;
  label: string;
  isDefault: boolean;
  /** 组内多条条件的关系 */
  logic: 'AND' | 'OR';
  rules: LogicRule[];
  /** 该分支的目标节点（由流程画布连线推导，模板层为空） */
  targets?: number[];
}

/** 逻辑节点条件配置（存 ext_config / 流程节点 taskParams.logicConfig） */
export interface LogicConfig {
  kind: 'condition';
  version: number;
  /** binary=二分（是/否），multi=多分支 */
  mode: 'binary' | 'multi';
  branches: LogicBranch[];
}

/** 注册作业单元 */
export const registerWorkUnit = (data: WorkUnitRequest) => {
  return request({ url: WORK_UNIT_BASE, method: 'post', data });
};

/** 修改作业单元 */
export const updateWorkUnitInfo = (data: WorkUnitRequest) => {
  return request({ url: WORK_UNIT_BASE, method: 'put', data });
};

/** 删除（撤销）作业单元 */
export const deleteWorkUnitById = (id: string | number) => {
  return request({ url: `${WORK_UNIT_BASE}/${String(id)}`, method: 'delete' });
};

/**
 * 发布作业单元
 * @param skipCheck true=跳过发布前完整性审核（强制发布，仅紧急情况使用）
 */
export const publishWorkUnitById = (id: string | number, skipCheck = false) => {
  return request({
    url: `${WORK_UNIT_BASE}/${String(id)}/publish`,
    method: 'post',
    params: skipCheck ? { skipCheck: true } : undefined
  });
};

/** 下线作业单元 */
export const offlineWorkUnitById = (id: string | number) => {
  return request({ url: `${WORK_UNIT_BASE}/${String(id)}/offline`, method: 'post' });
};

/** 查询作业单元列表 */
export const listWorkUnits = (params: WorkUnitQuery) => {
  return request({
    url: WORK_UNIT_BASE,
    method: 'get',
    params,
    transformResponse: [parseJsonKeepLongIds]
  });
};

/**
 * 私有参数字典类型可选项（层级字典 + 自定义字典）
 * 与「字典管理」页（/task-resource/hier-dict）同一套数据，返回 [{ code, name, source: 'hier'|'custom', sourceName, dataCount }]
 */
export const getWorkUnitDictTypes = (keyword?: string) => {
  return request({ url: `${WORK_UNIT_BASE}/params/dict-types`, method: 'get', params: { keyword } });
};

/**
 * 设置作业单元使用权限
 * 0=不可用，1=独占使用，2=共享使用；改为不可用时若存在执行中占用将被拒绝
 */
export const setWorkUnitAuthType = (id: string | number, authType: string) => {
  return request({
    url: `${WORK_UNIT_BASE}/${String(id)}/auth-type/${encodeURIComponent(authType)}`,
    method: 'post'
  });
};

/** 查询作业单元作业记录（未完成记录即当前占用） */
export const getWorkUnitRecords = (id: string | number, params?: { pageNo?: number; pageSize?: number }) => {
  return request({
    url: `${WORK_UNIT_BASE}/${String(id)}/records`,
    method: 'get',
    params,
    transformResponse: [parseJsonKeepLongIds]
  });
};

/** 生成作业单元标准节点 URL（不传子任务编号返回带占位符的模板 URL） */
export const getWorkUnitNodeUrl = (params: { unitCode: string; subTaskNo?: string }) => {
  return request({
    url: `${WORK_UNIT_BASE}/node-url`,
    method: 'get',
    params
  });
};

/** 公有参数定义列表（固定 18 个，前端不硬编码） */
export const getCommonParams = () => {
  return request({ url: `${WORK_UNIT_BASE}/params/common`, method: 'get' });
};

/** 作业单元详情（基本信息 + 公有参数 + 私有参数） */
export const getWorkUnitDetail = (id: string | number) => {
  return request({
    url: `${WORK_UNIT_BASE}/${String(id)}`,
    method: 'get',
    transformResponse: [parseJsonKeepLongIds]
  });
};

/** 发布前完整性审核（6 个审核项，canPublish=false 时不可发布） */
export const checkWorkUnit = (id: string | number) => {
  return request({ url: `${WORK_UNIT_BASE}/${String(id)}/check`, method: 'get' });
};

/** 路径可访问性测试：只测该单元已配置的三条路径 */
export const testWorkUnitPath = (id: string | number, target: 'base' | 'exec' | 'doc') => {
  return request({
    url: `${WORK_UNIT_BASE}/${String(id)}/check/path`,
    method: 'post',
    params: { target }
  });
};

/** 技术文档与版本信息 */
export const getWorkUnitDocInfo = (id: string | number) => {
  return request({ url: `${WORK_UNIT_BASE}/${String(id)}/doc-info`, method: 'get' });
};
