import request from '@/utils/request';

/**
 * 任务导出模块（初设 3.6.6.10：任务路径设置 + 任务导出 + 导出文件选择 + 文件打包）
 *
 * 后端落位：ruoyi-task-manage / dispatch / export，表 t_task_export_path / t_task_export_record。
 * 网关前缀必须带 /dolphinscheduler（断言 /dolphinscheduler/** + StripPrefix=1），否则 404。
 */
export const TASK_EXPORT_BASE = '/dolphinscheduler/taskExport';

/** 导出路径配置 */
export interface TaskExportPath {
  id?: number;
  pathName: string;
  /** local 本地目录 / nas 网络路径 / device 存储设备 */
  pathType: string;
  pathValue: string;
  /** Y 默认 / N 非默认 */
  isDefault?: string;
  /** 0 正常 / 1 停用 */
  status?: string;
  remark?: string;
  createTime?: string;
}

/** 可导出模块项（勾选用） */
export interface TaskExportModuleItem {
  code: string;
  name: string;
  description?: string;
  /** 该模块包含的文件清单 */
  files?: string[];
  defaultChecked?: boolean;
}

/** 导出请求体（预览 / 提交 / 同步导出共用） */
export interface TaskExportBo {
  /** 主任务 id 列表 */
  mainProjectIds: number[];
  /** 模块项 code；为空表示导出全部模块 */
  modules?: string[];
  /** 导出路径配置 id */
  pathId?: number;
  fileFormat?: string;
  /** 压缩级别 1-9 */
  compLevel?: number;
  encrypt?: boolean;
  /** encrypt=true 时必填；密码不落库，忘记无法找回 */
  password?: string;
  /** 分卷大小；0 表示不分卷 */
  splitSize?: number;
  /** 产物同时上传 MinIO */
  uploadOss?: boolean;
  remark?: string;
  secretLevel?: string;
}

/** 导出记录 */
export interface TaskExportRecord {
  id: number;
  exportNo?: string;
  /** RUNNING 执行中 / SUCCESS 成功 / FAILED 失败 */
  status: string;
  statusName?: string;
  progress?: number;
  /** 产物文件名（分卷时多个） */
  fileNames?: string[];
  fileSize?: number;
  fileSizeText?: string;
  /** 整包 SHA-256 */
  checksum?: string;
  ossUrls?: string[];
  moduleNames?: string[];
  errorInfo?: string;
  createBy?: string;
  createTime?: string;
  remark?: string;
  secretLevel?: string;
}

/* ==================== A. 导出路径设置 ==================== */

/** 路径配置列表 */
export function listExportPaths(params?: { keyword?: string }) {
  return request({
    url: `${TASK_EXPORT_BASE}/path/list`,
    method: 'get',
    params
  });
}

/** 路径详情 */
export function getExportPath(id: number | string) {
  return request({
    url: `${TASK_EXPORT_BASE}/path/${id}`,
    method: 'get'
  });
}

/** 新增路径 */
export function addExportPath(data: TaskExportPath) {
  return request({
    url: `${TASK_EXPORT_BASE}/path`,
    method: 'post',
    data
  });
}

/** 修改路径（body 需带 id） */
export function updateExportPath(data: TaskExportPath) {
  return request({
    url: `${TASK_EXPORT_BASE}/path`,
    method: 'put',
    data
  });
}

/** 删除路径（逗号分隔） */
export function deleteExportPath(ids: number | string) {
  return request({
    url: `${TASK_EXPORT_BASE}/path/${ids}`,
    method: 'delete'
  });
}

/** 设为默认导出路径 */
export function setDefaultExportPath(id: number | string) {
  return request({
    url: `${TASK_EXPORT_BASE}/path/default/${id}`,
    method: 'put'
  });
}

/** 服务端目录浏览（path 为空返回根目录） */
export function browseExportPath(path?: string) {
  return request({
    url: `${TASK_EXPORT_BASE}/path/browse`,
    method: 'get',
    params: { path: path || undefined }
  });
}

/** 路径可写性校验 */
export function validateExportPath(pathValue: string, createIfAbsent = false) {
  return request({
    url: `${TASK_EXPORT_BASE}/path/validate`,
    method: 'post',
    params: { pathValue, createIfAbsent }
  });
}

/* ==================== B. 导出执行与记录 ==================== */

/** 可导出模块项树 */
export function getExportContentTree() {
  return request({
    url: `${TASK_EXPORT_BASE}/content/tree`,
    method: 'get'
  });
}

/** 导出预览（文件清单 / 条目数 / 估算大小） */
export function previewExport(data: TaskExportBo) {
  return request({
    url: `${TASK_EXPORT_BASE}/preview`,
    method: 'post',
    data
  });
}

/** 提交导出（异步），返回 { recordId, exportNo } */
export function submitExport(data: TaskExportBo) {
  return request({
    url: `${TASK_EXPORT_BASE}/submit`,
    method: 'post',
    data
  });
}

/** 同步导出：直接返回 zip 文件流（大任务请用 submit） */
export function exportSync(data: TaskExportBo) {
  return request({
    url: `${TASK_EXPORT_BASE}/export`,
    method: 'post',
    data,
    responseType: 'blob'
  });
}

/** 导出记录分页（TableDataInfo：裸 rows / total） */
export function pageExportRecords(params: {
  pageNo: number;
  pageSize: number;
  status?: string;
  keyword?: string;
}) {
  return request({
    url: `${TASK_EXPORT_BASE}/record/page`,
    method: 'get',
    params
  });
}

/** 记录详情（含 progress，用于异步导出轮询） */
export function getExportRecord(id: number | string) {
  return request({
    url: `${TASK_EXPORT_BASE}/record/${id}`,
    method: 'get'
  });
}

/** 下载产物；分卷时 vol 从 1 开始 */
export function downloadExportFile(id: number | string, vol?: number) {
  return request({
    url: `${TASK_EXPORT_BASE}/download/${id}`,
    method: 'get',
    params: vol ? { vol } : undefined,
    responseType: 'blob'
  });
}

/** 删除记录及产物文件（逗号分隔） */
export function deleteExportRecords(ids: number | string) {
  return request({
    url: `${TASK_EXPORT_BASE}/record/${ids}`,
    method: 'delete'
  });
}
