/**
 * 海豚通用类型(原 dolphinscheduler-ui/src/common/types.ts 的一部分)
 * 由 workflow-instances/types.ts 等引用。
 */
export type ITaskState =
  | 'SUBMITTED_SUCCESS'
  | 'RUNNING_EXECUTION'
  | 'PAUSE'
  | 'FAILURE'
  | 'SUCCESS'
  | 'NEED_FAULT_TOLERANCE'
  | 'KILL'
  | 'DELAY_EXECUTION'
  | 'FORCED_SUCCESS'
  | 'DISPATCH'

export type IWorkflowExecutionState =
  | 'SUBMITTED_SUCCESS'
  | 'RUNNING_EXECUTION'
  | 'READY_PAUSE'
  | 'PAUSE'
  | 'READY_STOP'
  | 'STOP'
  | 'FAILURE'
  | 'SUCCESS'
  | 'SERIAL_WAIT'
  | 'FAILOVER'

export type ITaskStateConfig = {
  [key in ITaskState]: {
    id: number
    desc: string
    color: string
    icon: unknown
    isSpin: boolean
    classNames?: string
  }
}

export type IWorkflowExecutionStateConfig = {
  [key in IWorkflowExecutionState]: {
    id: number
    desc: string
    color: string
    icon: unknown
    isSpin: boolean
    classNames?: string
  }
}
