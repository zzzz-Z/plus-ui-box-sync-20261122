/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import request from '@/utils/request';
import { ListReq, ListIdReq, ProjectsReq, UserIdReq } from './types';

export function queryProjectListPaging(params: ListReq): any {
  return request({
    url: '/workflow/main/project/page',
    method: 'get',
    params
  });
}

/**
 * 我的待审批主任务（「待我审批」页签取数）
 * 后端把「我的流程待办 + 主任务」同构返回，分页/搜索都在服务端做：
 * 办完自动从列表消失，比用 approver_id 过滤更准（覆盖驳回重发、多级、转交）。
 */
export function queryMyApproveProjectPaging(params: ListReq): any {
  return request({
    url: '/workflow/main/project/pageByMyApprove',
    method: 'get',
    params
  });
}

/**
 * 审批人候选列表（专供「审批人下拉」使用）
 *
 * 为什么不复用 /system/user/list：那个接口受 system:user:list 权限保护（系统管理能力），
 * 而"选审批人"是审批业务动作，不该依赖系统管理权限——普通角色会 403、下拉为空。
 * 这个接口只校验登录，且只返回选人所需的最小字段。
 *
 * 注意：不要挂在 /main/project/approvers —— 那个控制器有 @GetMapping("/{id}")（Integer id），
 *       字面路径不存在时会被它命中并报"参数[id]要求 Integer"。这里挂在系统服务下更稳。
 *
 * 后端签名：GET /system/user/approver-options
 *           → R<List<Map>> [{ userId, userName, nickName }]（只含选人所需最小字段）
 */
export function queryApproverOptions(): any {
  return request({
    url: '/system/user/approver-options',
    method: 'get'
  });
}

export function queryProjectWithAuthorizedLevelListPaging(params: ListIdReq): any {
  return request({
    url: '/dolphinscheduler/projects/project-with-authorized-level-list-paging',
    method: 'get',
    params
  });
}

export function createProject(data: ProjectsReq): any {
  return request({
    url: '/dolphinscheduler/projects',
    method: 'post',
    data
  });
}

export function queryAuthorizedProject(params: UserIdReq): any {
  return request({
    url: '/dolphinscheduler/projects/authed-project',
    method: 'get',
    params
  });
}

export function queryProjectCreatedAndAuthorizedByUser(): any {
  return request({
    url: '/dolphinscheduler/projects/created-and-authed',
    method: 'get'
  });
}

export function queryAllProjectList(): any {
  return request({
    url: '/dolphinscheduler/projects/list',
    method: 'get'
  });
}

export function queryUnauthorizedProject(params: UserIdReq): any {
  return request({
    url: '/dolphinscheduler/projects/unauth-project',
    method: 'get',
    params
  });
}

export function queryProjectWithAuthorizedLevel(params: UserIdReq): any {
  return request({
    url: '/dolphinscheduler/projects/project-with-authorized-level',
    method: 'get',
    params
  });
}

export function queryProjectByCode(code: number): any {
  return request({
    url: `/dolphinscheduler/projects/${code}`,
    method: 'get'
  });
}

export function updateProject(data: ProjectsReq, code: number): any {
  return request({
    url: `/dolphinscheduler/projects/${code}`,
    method: 'put',
    data
  });
}

export function deleteProject(code: number): any {
  return request({
    url: `/dolphinscheduler/projects/${code}`,
    method: 'delete'
  });
}

export function queryAllProjectListForDependent(): any {
  return request({
    url: '/dolphinscheduler/projects/list-dependent',
    method: 'get'
  });
}
