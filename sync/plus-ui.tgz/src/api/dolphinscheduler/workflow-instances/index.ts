/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import request from '@/utils/request'
import { tansParams } from '@/utils/ruoyi'
import {
  CodeReq,
  WorkflowInstanceListReq,
  BatchDeleteReq,
  SubIdReq,
  TaskReq,
  LongestReq,
  WorkflowInstanceReq
} from './types'

export function queryWorkflowInstanceListPaging(
  params: WorkflowInstanceListReq,
  code: number
): any {
  return request({
    url: `/dolphinscheduler/projects/${code}/workflow-instances`,
    method: 'get',
    params
  })
}

export function batchDeleteWorkflowInstanceByIds(
  data: BatchDeleteReq,
  code: number
): any {
  return request({
    url: `/dolphinscheduler/projects/${code}/workflow-instances/batch-delete`,
    method: 'post',
    data
  })
}

export function queryParentInstanceBySubId(
  params: SubIdReq,
  code: CodeReq
): any {
  return request({
    url: `/dolphinscheduler/projects/${code}/workflow-instances/query-parent-by-sub`,
    method: 'get',
    params
  })
}

export function querySubWorkflowInstanceByTaskCode(
  params: TaskReq,
  code: CodeReq
): any {
  return request({
    url: `/dolphinscheduler/projects/${code.projectCode}/workflow-instances/query-sub-by-parent`,
    method: 'get',
    params
  })
}

export function queryTopNLongestRunningWorkflowInstance(
  params: LongestReq,
  code: CodeReq
): any {
  return request({
    url: `/dolphinscheduler/projects/${code}/workflow-instances/top-n`,
    method: 'get',
    params
  })
}

export function queryWorkflowInstanceById(
  instanceId: number,
  projectCode: number
): any {
  return request({
    url: `/dolphinscheduler/projects/${projectCode}/workflow-instances/${instanceId}`,
    method: 'get'
  })
}

export function updateWorkflowInstance(
  data: WorkflowInstanceReq,
  id: number,
  code: number
): any {
  return request({
    url: `/dolphinscheduler/projects/${code}/workflow-instances/${id}`,
    method: 'put',
    data
  })
}

export function deleteWorkflowInstanceById(id: number, code: number): any {
  return request({
    url: `/dolphinscheduler/projects/${code}/workflow-instances/${id}`,
    method: 'delete'
  })
}

export function queryTaskListByWorkflowId(id: number, code: number): any {
  return request({
    url: `/dolphinscheduler/projects/${code}/workflow-instances/${id}/tasks`,
    method: 'get'
  })
}

/**
 * 控制流程实例
 * executeType 取海豚 ExecuteType 枚举名：
 * STOP(终止) / PAUSE(暂停) / RECOVER_SUSPENDED_PROCESS(恢复暂停)
 * REPEAT_RUNNING(重跑) / START_FAILURE_TASK_PROCESS(从失败节点继续)
 * 海豚该接口用 @RequestParam 接收，必须表单提交
 */
export function controlWorkflowInstance(
  data: { workflowInstanceId: number; executeType: string },
  projectCode: number
): any {
  return request({
    url: `/dolphinscheduler/projects/${projectCode}/executors/execute`,
    method: 'post',
    data,
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
    },
    transformRequest: [tansParams]
  })
}

/** 查询任务实例日志（流程节点执行日志） */
export function queryTaskInstanceLog(params: {
  taskInstanceId: number
  skipLineNum?: number
  limit?: number
}): any {
  return request({
    url: '/dolphinscheduler/log/detail',
    method: 'get',
    params: {
      skipLineNum: 0,
      limit: 2000,
      ...params
    }
  })
}

export function viewGanttTree(id: number, code: number): any {
  return request({
    url: `/dolphinscheduler/projects/${code}/workflow-instances/${id}/view-gantt`,
    method: 'get'
  })
}

export function viewVariables(id: number, code: number): any {
  return request({
    url: `/dolphinscheduler/projects/${code}/workflow-instances/${id}/view-variables`,
    method: 'get'
  })
}
