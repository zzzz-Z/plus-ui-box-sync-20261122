/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import request from '@/utils/request'
import { ProjectCodeReq, TaskDefinitionJsonReq } from './types'

export function save(
  data: TaskDefinitionJsonReq,
  projectCode: ProjectCodeReq
): any {
  return request({
    url: `/dolphinscheduler/projects/${projectCode}/task-definition`,
    method: 'post',
    data
  })
}

export function genTaskCodeList(num: number, projectCode: number) {
  return request({
    url: `/dolphinscheduler/projects/${projectCode}/task-definition/gen-task-codes`,
    method: 'get',
    params: {
      genNum: num
    }
  }).then((res: any) => res?.data)
}


/**
 * 生成任务/节点 code，并保证不与「已有 code」撞号（按 JS 数值比较）。
 *
 * 背景：海豚 code 是 19 位雪花号，超过 JS 安全整数（2^53）。
 * 一次性申请多个 code 拿到的是连号（…394 / …395），它们经过 Number() 会被舍入成
 * **同一个值**：保存流程时按 code 去重会把两个节点合并成一个（静默丢节点），
 * 连线两端也会变成同一个 code，后端直接报「流程节点间存在循环依赖」。
 * 这里逐个申请 + 唯一性校验，撞号就丢弃重取，从源头杜绝。
 */
export async function genUniqueTaskCodes(
  num: number,
  projectCode: number,
  existing: (number | string)[] = []
): Promise<string[]> {
  const used = new Set<string>()
  existing.forEach((c) => {
    if (c !== undefined && c !== null && c !== "") used.add(String(Number(c)))
  })

  const out: string[] = []
  const maxTries = Math.max(num * 8, 20)
  for (let tries = 0; tries < maxTries && out.length < num; tries += 1) {
    let list: any = null
    try {
      list = await genTaskCodeList(1, projectCode)
    } catch {
      continue
    }
    const arr: any[] = Array.isArray(list) ? list : list !== undefined && list !== null ? [list] : []
    for (const raw of arr) {
      if (raw === undefined || raw === null || raw === "") continue
      const key = String(Number(raw))
      if (used.has(key)) continue // 与已有节点（或本次已取的）撞号 → 丢弃重取
      used.add(key)
      out.push(String(raw))
      if (out.length >= num) break
    }
  }
  return out
}
