/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import request from '@/utils/request'
import {
  CodeReq,
  CodesReq,
  NameReq,
  ReleaseStateReq,
  LimitReq,
  PageReq,
  ListReq,
  WorkflowDefinitionReq,
  TargetCodeReq
} from './types'

/**
 * 海豚工作流写接口（create / update / release / batch-*）的参数规整与提交。
 *
 * 背景：这些接口在海豚侧全部用 @RequestParam 取参，参数放 query string 或表单体都能被绑定。
 * 但 task-manage 代理层已改成「纯透传」，只保留 URL 上的参数、不再把表单体拼进 query，
 * 继续只发表单体就会丢参数，表现是 10107
 * 「更新工作流定义错误:Required request parameter 'name' ... is not present」。
 *
 * 提交策略（同一份参数只能走一个通道）：
 *  - URL 长度安全时只带 query：符合海豚原生文档，也是代理链路唯一保证可用的通道
 *  - 超长时只发表单体：网关对请求行有 4KB 硬上限（实测 4000 通过、4050 返回 414），
 *    大 JSON 塞不进 URL；这条链路依赖后端把表单体透传给海豚
 * 注意：两个通道同时携带同一参数会被海豚拼成 "值,值"（如 globalParams 变成 ","
 * 直接报 Invalid globalParams），所以绝不能同时发。
 */

/** 表单编码请求头：海豚 @RequestParam 接口按表单解析时必须显式声明 */
const FORM_HEADERS = { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' };
/** URL 安全长度阈值（网关硬上限 4096，留出余量） */
const URL_SAFE_LIMIT = 3800;

/**
 * 参数规整：
 *  - 对象 / 数组统一 JSON.stringify（locations、全局参数等）
 *  - null / undefined 不传
 *  - globalParams 为空时按后端文档传空字符串（实测空串 / "[]" / 不传 海豚都能接受，
 *    这里取空串，避免两边行为不一致）
 */
function toWorkflowParams(
  source: Record<string, any> = {},
  ensureGlobalParams = false
): Record<string, any> {
  const out: Record<string, any> = {};
  Object.keys(source).forEach((key) => {
    const value = source[key];
    if (value === null || value === undefined) return;
    const normalized = typeof value === 'object' ? JSON.stringify(value) : value;
    if (normalized === '[]' && key === 'globalParams') return;
    out[key] = normalized;
  });
  // 海豚 globalParams 是 String 入参，没有全局参数时传空串（只对创建/更新有效）
  if (ensureGlobalParams && out.globalParams === undefined) out.globalParams = '';
  return out;
}

/** 按 axios 默认序列化方式估算最终请求行长度（用于判断能否把参数带上 URL） */
function estimateUrlLength(url: string, params: Record<string, any>): number {
  let len = url.length + 1;
  Object.keys(params).forEach((key) => {
    len += encodeURIComponent(key).length + encodeURIComponent(String(params[key])).length + 2;
  });
  return len;
}

/** 表单体序列化（不用 tansParams：它会丢掉空字符串，而 globalParams 需要传空串） */
function toFormBody(params: Record<string, any>): string {
  return Object.keys(params)
    .map((key) => `${encodeURIComponent(key)}=${encodeURIComponent(String(params[key]))}`)
    .join('&');
}

/**
 * 统一提交入口：同一份参数只走一个通道。
 *  - 长度安全 → 只带 query（代理链路保证可用的通道）
 *  - 超长     → 只发表单体（4KB 上限制约，依赖后端透传）
 */
function submitWorkflowWrite(
  url: string,
  method: 'post' | 'put',
  data: Record<string, any>,
  ensureGlobalParams = false
): any {
  const payload = toWorkflowParams(data, ensureGlobalParams);
  const urlLength = estimateUrlLength(url, payload);
  if (urlLength < URL_SAFE_LIMIT) {
    console.info(`[海豚写接口] ${method.toUpperCase()} ${url}（参数走 URL，约 ${urlLength} 字节）`);
    return request({ url, method, params: payload });
  }
  console.warn(
    `[海豚写接口] ${method.toUpperCase()} ${url}（参数约 ${urlLength} 字节，超过 ${URL_SAFE_LIMIT}，` +
      '本次只发表单体提交；若后端代理只认 URL 参数，本次会失败，需要后端透传请求体）'
  );
  return request({
    url,
    method,
    data: payload,
    headers: FORM_HEADERS,
    transformRequest: [toFormBody]
  });
}

export function queryListPaging(params: PageReq & ListReq, code: number): any {
  return request({
    url: `/dolphinscheduler/projects/${code}/workflow-definition`,
    method: 'get',
    params
  })
}

export function createWorkflowDefinition(
  data: WorkflowDefinitionReq,
  projectCode: number
): any {
  return submitWorkflowWrite(
    `/dolphinscheduler/projects/${projectCode}/workflow-definition`,
    'post',
    data,
    true
  )
}

export function queryWorkflowDefinitionList(projectCode: number): any {
  return request({
    url: `/dolphinscheduler/projects/${projectCode}/workflow-definition/query-workflow-definition-list`,
    method: 'get'
  })
}

export function batchCopyByCodes(
  data: TargetCodeReq & CodesReq,
  code: number
): any {
  return submitWorkflowWrite(
    `/dolphinscheduler/projects/${code}/workflow-definition/batch-copy`,
    'post',
    data
  )
}

export function batchDeleteByCodes(data: CodesReq, code: number): any {
  return submitWorkflowWrite(
    `/dolphinscheduler/projects/${code}/workflow-definition/batch-delete`,
    'post',
    data
  )
}

export function batchMoveByCodes(
  data: TargetCodeReq & CodesReq,
  code: CodeReq
): any {
  return submitWorkflowWrite(
    `/dolphinscheduler/projects/${code}/workflow-definition/batch-move`,
    'post',
    data
  )
}

export function getTaskListByDefinitionCodes(
  params: CodesReq,
  code: number
): any {
  return request({
    url: `/dolphinscheduler/projects/${code}/workflow-definition/batch-query-tasks`,
    method: 'get',
    params
  })
}

export function queryList(code: CodeReq): any {
  return request({
    url: `/dolphinscheduler/projects/${code}/workflow-definition/list`,
    method: 'get'
  })
}

export function queryWorkflowDefinitionByName(
  params: NameReq,
  code: CodeReq
): any {
  return request({
    url: `/dolphinscheduler/projects/${code}/workflow-definition/query-by-name`,
    method: 'get',
    params
  })
}

export function querySimpleList(code: number): any {
  return request({
    url: `/dolphinscheduler/projects/${code}/workflow-definition/simple-list`,
    method: 'get'
  })
}

export function verifyName(
  params: { name: string; workflowCode?: number },
  projectCode: number
): any {
  return request({
    url: `/dolphinscheduler/projects/${projectCode}/workflow-definition/verify-name`,
    method: 'get',
    params
  })
}

export function queryWorkflowDefinitionByCode(
  code: number,
  projectCode: number
): any {
  return request({
    url: `/dolphinscheduler/projects/${projectCode}/workflow-definition/${code}`,
    method: 'get'
  })
}

export function updateWorkflowDefinition(
  data: WorkflowDefinitionReq & ReleaseStateReq,
  code: number,
  projectCode: number
): any {
  return submitWorkflowWrite(
    `/dolphinscheduler/projects/${projectCode}/workflow-definition/${code}`,
    'put',
    data,
    true
  )
}

export function deleteByCode(
  code: number,
  workflowDefinitionCode: number
): any {
  return request({
    url: `/dolphinscheduler/projects/${code}/workflow-definition/${workflowDefinitionCode}`,
    method: 'delete'
  })
}

export function release(
  data: NameReq & ReleaseStateReq,
  code: number,
  workflowDefinitionCode: number
): any {
  return submitWorkflowWrite(
    `/dolphinscheduler/projects/${code}/workflow-definition/${workflowDefinitionCode}/release`,
    'post',
    data
  )
}

export function getTasksByDefinitionList(
  projectCode: number,
  workflowDefinitionCode: number
): any {
  return request({
    url: `/dolphinscheduler/projects/${projectCode}/workflow-definition/query-task-definition-list`,
    method: 'get',
    params: {
      workflowDefinitionCode: workflowDefinitionCode
    }
  })
}

export function queryVersions(
  params: PageReq,
  code: number,
  workflowDefinitionCode: number
): any {
  return request({
    url: `/dolphinscheduler/projects/${code}/workflow-definition/${workflowDefinitionCode}/versions`,
    method: 'get',
    params
  })
}

export function switchVersion(
  code: number,
  workflowDefinitionCode: number,
  version: number
): any {
  return request({
    url: `/dolphinscheduler/projects/${code}/workflow-definition/${workflowDefinitionCode}/versions/${version}`,
    method: 'get'
  })
}

export function deleteVersion(
  code: number,
  workflowDefinitionCode: number,
  version: number
): any {
  return request({
    url: `/dolphinscheduler/projects/${code}/workflow-definition/${workflowDefinitionCode}/versions/${version}`,
    method: 'delete'
  })
}

export function viewTree(
  code: number,
  workflowDefinitionCode: number,
  params: LimitReq
): any {
  return request({
    url: `/dolphinscheduler/projects/${code}/workflow-definition/${workflowDefinitionCode}/view-tree`,
    method: 'get',
    params
  })
}

export function viewWorkflowDefinitionVariables(
  code: number,
  workflowDefinitionCode: number
): any {
  return request({
    url: `/dolphinscheduler/projects/${code}/workflow-definition/${workflowDefinitionCode}/view-variables`,
    method: 'get'
  })
}
