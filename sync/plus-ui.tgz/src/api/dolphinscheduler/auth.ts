/** 海豚项目编码(模板流程归属项目),取自 .env VITE_APP_DS_PROJECT_CODE */
export function getDsProjectCode(): number {
  return Number(import.meta.env.VITE_APP_DS_PROJECT_CODE) || 1
}
