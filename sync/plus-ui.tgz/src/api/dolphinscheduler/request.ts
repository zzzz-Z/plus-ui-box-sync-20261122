/**
 * 海豚(DolphinScheduler)后端专用 axios 实例
 *
 * 契约(与海豚前端 src/service/service.ts 一致):
 *  - baseURL: 开发环境 '/dolphinscheduler'(vite 代理到海豚后端),生产 'VITE_APP_DS_PROD_URL + /dolphinscheduler'
 *  - 认证: 请求头 sessionId(非 Bearer),由 ds-auth store 提供
 *  - 请求体/查询参数一律 qs.stringify(application/x-www-form-urlencoded, arrayFormat: 'repeat')
 *  - 响应包装 { code, msg, data },code===0 成功,拦截器解包只返回 data
 */
import axios, { AxiosRequestConfig, AxiosResponse, AxiosError, InternalAxiosRequestConfig } from 'axios';
import { useDsAuthStore } from '@/store/modules/ds-auth';
import qs from 'qs';
import _ from 'lodash';
import { ElMessage } from 'element-plus';
import i18n from '@/lang/index';
const t = (key: string) => i18n.global.t(key);

const prodUrl = (import.meta.env.VITE_APP_DS_PROD_URL as string) || '';

/**
 * @description 打印并提示错误
 * @param {Error} error Error object
 */
const handleError = (res: AxiosResponse<any, any>) => {
  ElMessage.error(res.data?.msg || t('common.dsRequestError'));
};

const baseRequestConfig: AxiosRequestConfig = {
  baseURL: import.meta.env.MODE === 'development' ? '/dolphinscheduler' : `${prodUrl}/dolphinscheduler`,
  timeout: 20000,
  transformRequest: (params) => {
    if (_.isPlainObject(params)) {
      return qs.stringify(params, { arrayFormat: 'repeat' });
    } else {
      return params;
    }
  },
  paramsSerializer: (params) => {
    return qs.stringify(params, { arrayFormat: 'repeat' });
  }
};

const service = axios.create(baseRequestConfig);

const err = (error: unknown): Promise<never> => {
  const axiosError = error as AxiosError;

  // 不再自动登录:会话失效时仅打印提示,保留 .env 配置的静态 sessionId
  if (axiosError.response?.status === 401) {
    console.warn('海豚接口返回 401:请检查 .env 中 VITE_APP_DS_SESSION_ID 是否为有效的 sessionId');
  }

  return Promise.reject(error);
};

service.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  config.headers.set('sessionId', useDsAuthStore().sessionId || '');
  // 自定义 transformRequest 只做了 qs.stringify，不会自动设置 Content-Type；
  // 不显式声明的话浏览器默认发 text/plain，海豚后端无法按表单解析 @RequestParam
  if (config.method === 'post' || config.method === 'put') {
    config.headers.set('Content-Type', 'application/x-www-form-urlencoded;charset=UTF-8');
  }
  return config;
}, err);

// The response to intercept
service.interceptors.response.use((res: AxiosResponse) => {
  // No code will be processed
  if (res.data.code === undefined) {
    return res.data;
  }

  switch (res.data.code) {
    case 0:
      return res.data.data;
    default:
      handleError(res);
      throw new Error(res.data?.msg || 'error');
  }
}, err);

export { service as axios };
