/*
 * 任务评价 —— 真实接口适配层（task-manage /evaluation/**）
 *
 * 背景：任务评价页面（views/task-monitor/task-evaluate.vue）原本整套数据来自
 *      api/task-monitor/index.ts 里的样例数据（无任何 request 调用）。
 *      后端已提供真实评价接口，这里做一层适配：调用真实接口 + 把后端 VO
 *      映射成页面既有的行结构，页面模板无需改动。
 *
 * 后端接口（task-manage，经网关 /dolphinscheduler 前缀访问）：
 *   GET  /evaluation/stat                       顶部统计（4 个卡片）
 *   GET  /evaluation/self/list?pageNo&pageSize  自评列表
 *   GET  /evaluation/self/options?mainProjectId 自评发起基础数据
 *   POST /evaluation/self                       提交自评
 *   PUT  /evaluation/self/{id}                  修改自评
 *   GET  /evaluation/mutual/list                互评列表
 *   GET  /evaluation/mutual/options?mainProjectId 互评发起基础数据（可选评价对象）
 *   POST /evaluation/mutual                     提交互评
 *   GET  /evaluation/query                      评价数据组合查询
 *   POST /evaluation/default?mainProjectId      默认评价（按自动指标折算星级）
 *
 * 仍为样例数据（后端暂无接口，直接复用原模块）：业务环节评价、任务综合评价、导出
 */
import request from '@/utils/request';

const BASE = '/dolphinscheduler/evaluation';

/** 评价类型中文 ↔ 后端码值（1自评 2互评 3管理评价） */
const EVAL_TYPE_CODE: Record<string, string> = {
  self: '1',
  mutual: '2',
  manager: '3',
  自评: '1',
  互评: '2',
  管理评价: '3'
};

/** 意见权限中文 ↔ 后端码值（1公开 2节点内公开 3不公开） */
const PERM_CODE: Record<string, string> = {
  公开: '1',
  节点内公开: '2',
  不公开: '3'
};

/**
 * 参与方类型 中文 ↔ 后端码值
 * 后端字典：1作业岗位 2作业组 3节点单位 4牵头单位 5管理者
 */
const PARTICIPANT_CODE: Record<string, string> = {
  作业岗位: '1',
  作业组: '2',
  节点单位: '3',
  牵头单位: '4',
  管理者: '5'
};

/** 参与方类型转码值（已是码值则原样返回） */
function participantCode(value: any): string | undefined {
  if (value === undefined || value === null || value === '') return undefined;
  const v = String(value);
  return PARTICIPANT_CODE[v] || v;
}

/** 参与方类型下拉（值=后端码值，标签=中文） */
export const PARTICIPANT_TYPE_OPTIONS = [
  { value: '1', label: '作业岗位' },
  { value: '2', label: '作业组' },
  { value: '3', label: '节点单位' },
  { value: '4', label: '牵头单位' }
];

/** 评价类型下拉（值=前端标识，提交时由 EVAL_TYPE_CODE 转码值） */
export const EVAL_TYPE_OPTIONS = [
  { value: 'self', label: '自评' },
  { value: 'mutual', label: '互评' },
  { value: 'manager', label: '管理评价' }
];

/** 意见权限下拉 */
export const OPINION_PERM_OPTIONS = [
  { value: '1', label: '公开' },
  { value: '2', label: '节点内公开' },
  { value: '3', label: '不公开' }
];

/** 评价类型码值 → 中文 */
export function evalTypeLabel(code: any): string {
  const map: Record<string, string> = { '1': '自评', '2': '互评', '3': '管理评价' };
  return map[String(code)] || String(code ?? '');
}

/** 评价指标字典（与后端 TaskEvaluationServiceImpl.INDICATOR_DICT 保持一致，前 4 项为自动读取） */
const INDICATOR_DICT = [
  { code: 'progress', name: '任务进度', unit: '%' },
  { code: 'output', name: '成果量', unit: '' },
  { code: 'quality', name: '质检合格率', unit: '%' },
  { code: 'rework', name: '返工次数', unit: '次' },
  { code: 'ontime', name: '按时完成率', unit: '%' },
  { code: 'resource', name: '资源利用率', unit: '%' },
  { code: 'efficiency', name: '执行效率', unit: '%' },
  { code: 'cooperation', name: '协作配合度', unit: '' },
  { code: 'completion', name: '任务完成率', unit: '%' },
  { code: 'outputQuality', name: '成果合格率', unit: '%' }
];

/** 后端 TaskEvaluationVO → 页面既有行结构（自评/互评/查询/管理评价共用） */
function mapEvalRow(vo: any): any {
  const indicators: Record<string, any> = {};
  (vo?.indicators || []).forEach((item: any) => {
    indicators[item.code] = item.value;
  });
  const star = vo?.star ?? 0;
  return {
    id: vo?.id,
    mainProjectId: vo?.mainProjectId,
    taskNo: vo?.taskNo,
    taskName: vo?.taskName,
    taskType: vo?.taskTypeName || '',
    // 自评列表列
    participantType: vo?.evaluatorTypeName || vo?.targetTypeName || '',
    participantName: vo?.evaluatorName || vo?.targetName || '',
    progress: vo?.progress ?? 0,
    outputVolume: indicators['output'] ?? '-',
    reworkCount: indicators['rework'] ?? 0,
    qualityRate: indicators['quality'] ?? '-',
    qualityScore: star,
    // 互评/管理评价列表列
    evaluatorType: vo?.evaluatorTypeName || '',
    evaluatorName: vo?.evaluatorName || '',
    evaluator: vo?.evaluatorName || '',
    submitter: vo?.evaluatorName || '',
    anonymous: vo?.anonymous === '1',
    anonymousName: vo?.anonymousName || '',
    targetType: vo?.targetTypeName || '',
    targetTypeCode: vo?.targetType || '',
    targetName: vo?.targetName || '',
    star,
    score: star ? star * 20 : 0,
    comment: vo?.opinion || '',
    // 意见可见性（后端按 opinionPerm + 是否本人过滤；false 时 opinion 为 null）
    opinionVisible: vo?.opinionVisible !== false,
    visibility: vo?.opinionPermName || '',
    opinionPerm: vo?.opinionPerm || '',
    evalType: vo?.evalType,
    evalTypeName: vo?.evalTypeName,
    evalTime: vo?.createTime,
    status: vo?.star ? '已评价' : '未评价',
    isDefault: vo?.isDefault === '1',
    indicators: vo?.indicators || [],
    // 页面其它列用到的兼容字段（用星级折算，避免出现空白）
    timelinessScore: star,
    collaborationScore: star,
    businessScore: star * 20,
    businessComment: vo?.opinion || '',
    // 管理评价列表列（管理评价的评价方固定是"管理者"）
    managerType: vo?.evaluatorTypeName || '',
    managerName: vo?.evaluatorName || '',
    manager: vo?.evaluatorName || ''
  };
}

/**
 * 统一分页结果 → 页面用的 { code, data:{ rows, total } }。
 *
 * 后端各版本分页包装不统一，这里全部兼容：
 *   ① TableDataInfo：{ code, rows, total }
 *   ② PageInfo 嵌在 data 里：{ code, data: { totalList, total } }
 *   ③ 若依分页：{ code, data: { records|list|rows, total } }
 *   ④ data 直接是数组
 */
function toPageResult(res: any, mapper = mapEvalRow) {
  const raw =
    (Array.isArray(res?.rows) && res.rows) ||
    (Array.isArray(res?.data?.totalList) && res.data.totalList) ||
    (Array.isArray(res?.data?.rows) && res.data.rows) ||
    (Array.isArray(res?.data?.records) && res.data.records) ||
    (Array.isArray(res?.data?.list) && res.data.list) ||
    (Array.isArray(res?.data) && res.data) ||
    [];
  const total = res?.total ?? res?.data?.total ?? raw.length;
  const rows = raw.map(mapper);
  return { code: 200, msg: 'ok', data: { rows, total } };
}

/**
 * 评价指标体系（字典来自后端指标模型，前端只读展示）。
 * 注意：返回结构必须与页面 `res.data.map(...)` 的用法一致 —— data 直接是数组。
 */
export function getIndicatorList() {
  return Promise.resolve({
    code: 200,
    msg: 'ok',
    data: INDICATOR_DICT.map((item, index) => {
      // 前 4 项由系统自动读取（后端 TaskEvaluationServiceImpl 口径）
      const readable = index < 4;
      return {
        id: item.code,
        code: item.code,
        name: item.name,
        category: readable ? '自动读取指标' : '人工评价指标',
        type: readable ? 'auto' : 'manual',
        // 后端暂无指标权重配置接口，先按 10 项均摊（合计 100）
        weight: 10,
        value: readable ? '-' : '',
        unit: item.unit,
        description: readable ? '系统自动采集，无需人工填写' : '由评价人按实际情况打分',
        readable,
        enabled: true
      };
    })
  });
}

/** 指标体系由后端统一维护，前端不支持保存 */
export function saveIndicators() {
  return Promise.resolve({ code: 500, msg: '评价指标体系由后端统一维护，暂不支持前端保存' });
}

/** 自评列表（真实：GET /evaluation/self/list） */
export async function getBizEvalList(params: any = {}) {
  const res: any = await request({
    url: `${BASE}/self/list`,
    method: 'get',
    params: { pageNo: params.pageNum || 1, pageSize: params.pageSize || 10 }
  });
  return toPageResult(res);
}

/** 评价记录/数据查看（真实：GET /evaluation/query，支持 evalType/evaluatorType/taskName/onlyMine） */
export async function getBizEvalRecords(params: any = {}) {
  const res: any = await request({
    url: `${BASE}/query`,
    method: 'get',
    params: {
      evalType: EVAL_TYPE_CODE[params.evalType] ?? params.evalType,
      evaluatorType: params.evaluatorType,
      taskName: params.taskName,
      onlyMine: params.onlyMine,
      pageNo: params.pageNum || 1,
      pageSize: params.pageSize || 200
    }
  });
  return toPageResult(res);
}

/** 可选评价对象（真实：GET /evaluation/mutual/options?mainProjectId=） */
export async function getBizEvalTargets(mainProjectId: any) {
  if (!mainProjectId) return { code: 200, msg: 'ok', data: [] };
  const res: any = await request({ url: `${BASE}/mutual/options`, method: 'get', params: { mainProjectId } });
  const data = res?.data || {};
  const targets = (data.participants || []).map((p: any) => ({
    targetId: p.participantId,
    targetName: p.participantName,
    targetType: p.participantTypeName,
    targetTypeCode: p.participantType
  }));
  return {
    code: 200,
    msg: 'ok',
    data: [
      {
        taskId: String(mainProjectId),
        taskName: data.taskName,
        progress: data.progress,
        indicators: data.indicators || [],
        participants: data.participants || [],
        targets
      }
    ]
  };
}

/** 自评发起基础数据（真实：GET /evaluation/self/options?mainProjectId=） */
export async function getSelfEvalOptions(mainProjectId: any) {
  const res: any = await request({ url: `${BASE}/self/options`, method: 'get', params: { mainProjectId } });
  return res;
}

/** 提交评价（真实：自评 POST /evaluation/self；互评 POST /evaluation/mutual） */
export async function submitBizEval(payload: any) {
  const body = {
    mainProjectId: Number(payload.taskId),
    evaluatorType: participantCode(payload.evaluatorType),
    evaluatorName: payload.evaluatorName,
    targetType: participantCode(payload.targetType || payload.evaluatorType),
    targetId: payload.targetId,
    targetName: payload.targetName,
    star: payload.star,
    opinion: payload.comment || '',
    opinionPerm: PERM_CODE[payload.visibility] || payload.visibility || '1',
    anonymous: payload.anonymous ? '1' : '0',
    autoIndicators: payload.autoIndicators
  };
  const isSelf = payload.evalType === 'self' || payload.evalType === '自评';
  return request({ url: isSelf ? `${BASE}/self` : `${BASE}/mutual`, method: 'post', data: body });
}

/** 更新自评（真实：PUT /evaluation/self/{id}，仅本人） */
export async function updateSelfEval(id: any, payload: any) {
  const body = {
    mainProjectId: Number(payload.taskId),
    evaluatorType: participantCode(payload.evaluatorType),
    evaluatorName: payload.evaluatorName,
    star: payload.star,
    opinion: payload.comment || '',
    opinionPerm: PERM_CODE[payload.visibility] || payload.visibility || '1'
  };
  return request({ url: `${BASE}/self/${id}`, method: 'put', data: body });
}

/** 当前用户是否任务管理者（真实：GET /evaluation/manager/check） */
export async function isManager(): Promise<boolean> {
  try {
    const res: any = await request({ url: `${BASE}/manager/check`, method: 'get' });
    return res?.data === true || res?.data === 'true';
  } catch {
    return false;
  }
}

/** 我的管理评价列表（真实：GET /evaluation/manager/list，返回我作为管理者提交的 evalType=3 记录） */
export async function getMgrEvalList(params: any = {}) {
  const res: any = await request({
    url: `${BASE}/manager/list`,
    method: 'get',
    params: { pageNo: params.pageNum || 1, pageSize: params.pageSize || 10 }
  });
  return toPageResult(res);
}

/** 管理评价数据查看（真实：GET /evaluation/query?evalType=3，按权限查看全部管理评价） */
export async function getMgrEvalRecords(params: any = {}) {
  const res: any = await request({
    url: `${BASE}/query`,
    method: 'get',
    params: {
      evalType: '3',
      taskName: params.taskName,
      evaluatorType: params.evaluatorType,
      onlyMine: params.onlyMine,
      pageNo: params.pageNum || 1,
      pageSize: params.pageSize || 200
    }
  });
  return toPageResult(res);
}

/** 管理评价对象候选（真实：GET /evaluation/manager/options，只含下级参与方、不含管理者自己） */
export async function getMgrEvalTargets(mainProjectId?: any) {
  if (!mainProjectId) return { code: 200, msg: 'ok', data: [] };
  const res: any = await request({ url: `${BASE}/manager/options`, method: 'get', params: { mainProjectId } });
  const data = res?.data || {};
  const targets = (data.participants || []).map((p: any) => ({
    targetId: p.participantId,
    targetName: p.participantName,
    targetType: p.participantTypeName,
    targetTypeCode: p.participantType
  }));
  return {
    code: 200,
    msg: 'ok',
    data: [{ taskId: String(mainProjectId), taskName: data.taskName, participants: data.participants || [], targets }]
  };
}

/**
 * 提交管理评价（真实：POST /evaluation/manager）。
 * 说明：evaluatorType/evaluatorName 可省略，服务端会按当前用户岗位补齐（后端 r80 修复）；
 *      管理评价强制实名（后端忽略 anonymous），评价对象必填。
 */
export async function submitMgrEval(payload: any) {
  const body = {
    mainProjectId: Number(payload.taskId),
    targetType: participantCode(payload.targetType),
    targetId: payload.targetId,
    targetName: payload.targetName,
    star: payload.star,
    opinion: payload.comment || '',
    opinionPerm: PERM_CODE[payload.visibility] || payload.visibility || '1'
  };
  return request({ url: `${BASE}/manager`, method: 'post', data: body });
}

/** 更新管理评价（真实：PUT /evaluation/manager/{id}，仅本人） */
export async function updateMgrEval(id: any, payload: any) {
  const body = {
    mainProjectId: Number(payload.taskId),
    targetType: participantCode(payload.targetType),
    targetId: payload.targetId,
    targetName: payload.targetName,
    star: payload.star,
    opinion: payload.comment || '',
    opinionPerm: PERM_CODE[payload.visibility] || payload.visibility || '1'
  };
  return request({ url: `${BASE}/manager/${id}`, method: 'put', data: body });
}

/** 默认评价（真实：POST /evaluation/default?mainProjectId=） */
export async function getDefaultEval(mainProjectId: any) {
  return request({ url: `${BASE}/default`, method: 'post', params: { mainProjectId } });
}

/** 评价顶部统计（真实：GET /evaluation/stat）→ 4 个卡片 */
export async function getEvalStat() {
  const res: any = await request({ url: `${BASE}/stat`, method: 'get' });
  return res?.data || res || {};
}

/** 评价数据组合查询（真实：GET /evaluation/query） */
export async function getEvalQueryList(params: any = {}) {
  const res: any = await request({
    url: `${BASE}/query`,
    method: 'get',
    params: {
      evalType: EVAL_TYPE_CODE[params.evalType] ?? params.evalType,
      evaluatorType: params.evaluatorType,
      taskName: params.taskName,
      onlyMine: params.onlyMine,
      pageNo: params.pageNo || 1,
      pageSize: params.pageSize || 200
    }
  });
  return toPageResult(res);
}

/* ---------- 以下为后端暂无接口的部分：继续沿用原样例数据模块 ---------- */
export {
  getProcessEvalList,
  getProcessEvalDetail,
  getComprehensiveEval,
  getComprehensiveEvalList,
  exportEvalData
} from './index';
