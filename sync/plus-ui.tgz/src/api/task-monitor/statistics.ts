/**
 * 任务统计 (Task Statistics) —— 自研报告模板 + 六大统计功能
 *
 * 功能清单：
 *  (1) 任务统计报告模板：自研拖拽设计器 DSL（文本/图形/表格/控件四类页面元素）
 *  (2) 任务工作量统计：按作业岗位/作业组/节点单位/任务总维度，自动或手工计算
 *  (3) 任务作业率统计：按作业岗位/作业组/节点单位/任务总维度
 *  (4) 任务质量统计：按质量标准与计算方法统计
 *  (5) 任务评价统计：依据任务评价模块各类评价数据
 *  (6) 任务综合分析：工作量+作业率+质量统计数据+评价数据+其他任务因素
 *
 * 报告导出格式：Word、WPS、PDF、HTML
 * 说明：报告模板为自研实现（无第三方开源依赖），页面元素 DSL 如下：
 *   element.type = text | chart | table | control
 *   element.x/y/w/h 画布绝对坐标（px），画布 A4 比例 820×1100
 */

/* ================================================================
 *  一、报告模板 DSL 类型与存储
 * ================================================================ */

/** 页面元素类型：文本、图形、表格、控件、流程图（AntV X6） */
export type StatElementType = 'text' | 'chart' | 'table' | 'control' | 'flow';

/** 流程图节点类型：开始/任务/判断/结束 */
export type FlowNodeKind = 'start' | 'task' | 'decision' | 'end';

/** 流程图节点（数据约定，存放在元素 dataSource.staticData 中） */
export interface FlowNodeData {
  id: string;
  name: string;
  kind?: FlowNodeKind;
  /** 画布坐标（左上角，X6 图坐标）；缺省时由自动分层布局计算 */
  x?: number;
  y?: number;
}

/** 流程图连线 */
export interface FlowEdgeData {
  source: string;
  target: string;
  label?: string;
}

/** 流程图数据根结构：{ nodes: [...], edges: [...] } */
export interface FlowGraphData {
  nodes: FlowNodeData[];
  edges: FlowEdgeData[];
}

/**
 * 元素数据源配置（go-view 风格：每元素独立 API）
 * - mode='mock'：使用元素自带静态 JSON（staticData，新建元素时自动填入默认示例，可编辑）
 * - mode='api'：自定义接口，测试成功后用 testData 渲染，支持轮询
 *
 * 对齐 go-view request 模型：Header / Params / Body(json|form-data) + 间隔轮询
 */
export interface DataSourceConfig {
  mode: 'mock' | 'api';
  /* ---- API 配置 ---- */
  apiUrl: string;
  method: 'GET' | 'POST';
  /** Query 参数（Params 键值对） */
  params: Record<string, any>;
  /** 请求头（Header 键值对） */
  headers: Record<string, string>;
  /** 请求体类型：none 无 / json 字符串 / form-data 键值对 */
  bodyType: 'none' | 'json' | 'form-data';
  /** bodyType=json 时的 JSON 文本 */
  bodyText: string;
  /** bodyType=form-data 时的键值对 */
  formBody: Record<string, string>;
  /** 轮询间隔（秒），0 表示不轮询（仅测试时请求一次） */
  interval: number;
  /* ---- mock 模式静态数据 ---- */
  /** 自定义静态 JSON 文本，非空且合法时覆盖内置 mock 字段数据 */
  staticData: string;
  /* ---- 测试状态 ---- */
  testStatus: 'idle' | 'testing' | 'success' | 'error';
  testMessage?: string;
  testData?: any;
}

/**
 * 数据字段映射：数据源结果（静态 JSON / API 返回）→ 元素渲染结构
 * 各元素类型只取用其中相关字段；所有元素统一通过 dataBinding 渲染
 */
export interface DataBindingConfig {
  /** 数据路径：从数据源结果内定位目标数据，如 'data.trend'，空表示根对象 */
  dataPath?: string;
  /* ---- 表格 ---- */
  columnsField?: string;      // 列名数组所在 key（默认 columns）
  rowsField?: string;         // 行数据数组 key（表格默认 rows；饼图复用为对象数组 key）
  visibleColumns?: string[];  // 实际展示的列（列名数组子集）
  /* ---- 统计卡片（对象数组逐字段映射） ---- */
  labelField?: string;
  valueField?: string;        // 饼图亦复用：数值字段
  unitField?: string;
  trendField?: string;
  /* ---- 统计卡片字段显示开关（关闭则不渲染对应部分，默认 true） ---- */
  labelEnabled?: boolean;
  valueEnabled?: boolean;
  unitEnabled?: boolean;
  trendEnabled?: boolean;
  /* ---- 柱线/雷达（平行数组结构） ---- */
  categoryField?: string;     // 柱线：类目数组 key；雷达：指标数组 key（[{name,max}]）
  seriesFields?: string[];    // 各系列数组 key
  seriesNames?: string[];     // 各系列显示名（与 seriesFields 对齐）
  /* ---- 饼图（对象数组，配合 rowsField） ---- */
  nameField?: string;
  /* ---- 流程图 ---- */
  nodesField?: string;        // 节点数组 key（默认 nodes）
  edgesField?: string;        // 连线数组 key（默认 edges）
  /* ---- 文本 ---- */
  paragraphsField?: string;   // 段落数组 key（缺省 paragraphs）
}

/**
 * 图形样式配置（参考 go-view 图表属性面板：图例/提示框/坐标轴/系列/网格/色板均可控）
 * 由 buildGenericChartOption 消费；缺失时自动补齐默认值（ensureChartStyle）。
 */
export interface ChartStyleConfig {
  /* ---- 图例 legend ---- */
  legendShow: boolean;                              // 是否显示图例
  legendPos: 'top' | 'bottom' | 'left' | 'right';   // 图例位置
  legendSize: number;                               // 图例字号
  legendColor: string;                              // 图例文字颜色
  /* ---- 提示框 tooltip ---- */
  tooltipShow: boolean;
  /* ---- 网格 grid 边距（px） ---- */
  gridTop: number;
  gridBottom: number;
  gridLeft: number;
  gridRight: number;
  /* ---- X 轴（柱状/折线类目轴） ---- */
  xAxisShow: boolean;
  xAxisName: string;                                // X 轴名称
  xAxisRotate: number;                              // 类目标签旋转角度 0-90
  xAxisLabelColor: string;
  xAxisLabelSize: number;
  /* ---- Y 轴（柱状/折线数值轴） ---- */
  yAxisShow: boolean;
  yAxisName: string;                                // Y 轴名称
  yAxisMin: number | null;                          // 数值轴最小值（null 自适应）
  yAxisMax: number | null;                          // 数值轴最大值（null 自适应）
  yAxisLabelColor: string;
  yAxisLabelSize: number;
  /* ---- 柱状图系列 ---- */
  barStack: boolean;                                // 是否堆叠
  barWidth: number | null;                          // 柱宽（null 自适应）
  barRadius: number;                                // 柱顶圆角 px
  /* ---- 折线图系列 ---- */
  lineSmooth: boolean;                              // 平滑曲线
  lineArea: boolean;                                // 面积填充
  lineWidth: number;                                // 线宽
  lineSymbol: boolean;                              // 显示数据点
  /* ---- 饼图 ---- */
  pieInner: number;                                 // 内半径（百分比 0-100）
  pieOuter: number;                                 // 外半径（百分比 0-100）
  pieRose: boolean;                                 // 南丁格尔玫瑰图
  pieLabel: boolean;                                // 显示扇区标签
  /* ---- 雷达图 ---- */
  radarArea: boolean;                               // 面积填充
  /* ---- 配色方案（对应 defaults.CHART_PALETTES 的 value） ---- */
  palette: string;
}

export interface StatElementProps {
  /* 文本 */
  text?: string;                                    // 文字内容
  fontSize?: number;                                // 字号
  fontColor?: string;                               // 字体颜色
  bold?: boolean;                                   // 加粗
  align?: 'left' | 'center' | 'right';              // 对齐方式
  bgColor?: string;                                 // 背景色
  /* 图形 */
  chartType?: 'bar' | 'line' | 'pie' | 'radar';     // 图形类型
  chartStyle?: ChartStyleConfig;                    // 图形样式（图例/坐标轴/系列等，通用渲染生效）
  /* 控件 */
  controlType?: 'stat' | 'progress';                // 控件类型：统计卡片/进度条
  /* 通用 */
  title?: string;                                   // 元素标题
  /** 历史遗留字段（旧版按 field 绑定内置 mock），新设计器元素不再使用 */
  field?: string;                                   // 绑定数据字段
  orderBy?: string;                                 // 排序字段
  sortBy?: 'default' | 'asc' | 'desc';              // 排序规则
  order?: number;                                    // 展示顺序
  columns?: string[];                               // 表格列定义
  striped?: boolean;                                 // 表格斑马纹
  headerBg?: string;                                 // 表头背景色
  unit?: string;                                     // 计量单位
  /* 数据源（go-view 风格：每元素独立 API，缺省走 mock） */
  dataSource?: DataSourceConfig;
  /* 数据字段映射（静态 JSON / API 返回 → 渲染结构） */
  dataBinding?: DataBindingConfig;
}

export interface StatTemplateElement {
  id: string;
  type: StatElementType;
  x: number;   // 画布内横坐标 px
  y: number;   // 画布内纵坐标 px
  w: number;   // 宽度 px
  h: number;   // 高度 px
  props: StatElementProps;
}

export interface StatTemplate {
  id: string;
  name: string;
  /** 报告模板：5 类统计报告；可视化方案：实时监控/资源监控/自定义等方案类型 */
  reportType: string;
  description: string;
  page: { width: number; height: number; padding: string; palette?: string; bgColor?: string };
  elements: StatTemplateElement[];
  creator: string;
  createTime: string;
  updateTime: string;
}

/** 报告类型（对应 5 类统计报告） */
export const STAT_REPORT_TYPES = [
  { label: '任务工作量', value: '任务工作量' },
  { label: '任务作业率', value: '任务作业率' },
  { label: '任务质量', value: '任务质量' },
  { label: '任务评价', value: '任务评价' },
  { label: '任务综合分析', value: '任务综合分析' },
];

/** 统计对象维度 */
export const STAT_DIMENSIONS = [
  { label: '作业岗位', value: 'post' },
  { label: '作业组', value: 'group' },
  { label: '节点单位', value: 'node' },
  { label: '任务总', value: 'total' },
];

/* ================================================================
 *  二、模板 Mock 存储（自研 DSL）
 * ================================================================ */

/** 模板存储：系统不再预置模板，初始为空；用户新建模板保存在当前会话内存中（待后端接口落地） */
const mockStatTemplateStore: StatTemplate[] = [];

/* ================================================================
 *  三、模板 CRUD API
 * ================================================================ */

function mockDelay<T>(data: T, ms = 200): Promise<T> {
  return new Promise((resolve) => setTimeout(() => resolve(data), ms));
}

/**
 * 获取报告模板列表
 * 真实接口: GET /task-monitor/stat/template/list
 * @param params.reportType 报告类型
 * @param params.keyword 模板名称关键字
 */
export function getReportTemplateList(params?: { reportType?: string; keyword?: string }): Promise<any> {
  let rows = [...mockStatTemplateStore];
  if (params?.reportType) {
    rows = rows.filter((r) => r.reportType === params.reportType);
  }
  if (params?.keyword) {
    const kw = String(params.keyword).trim();
    rows = rows.filter((r) => r.name?.includes(kw));
  }
  return mockDelay({ code: 200, data: rows, msg: 'ok' }, 150);
}

/**
 * 获取报告模板详情（含完整页面元素 DSL）
 * 真实接口: GET /task-monitor/stat/template/{id}
 */
export function getStatReportTemplateDetail(id: string): Promise<any> {
  const tpl = mockStatTemplateStore.find((t) => t.id === id);
  return mockDelay({ code: 200, data: tpl ? JSON.parse(JSON.stringify(tpl)) : null, msg: tpl ? 'ok' : '未找到模板' }, 100);
}

/**
 * 创建报告模板
 * 真实接口: POST /task-monitor/stat/template/create
 * @param data.name 模板名称
 * @param data.reportType 报告类型
 * @param data.description 模板说明
 * @param data.elements 页面元素 DSL 数组
 */
export function createReportTemplate(data: Partial<StatTemplate> & { elements?: StatTemplateElement[] }): Promise<any> {
  const now = new Date().toLocaleString('zh-CN', { hour12: false });
  const tpl: StatTemplate = {
    id: 'st' + Date.now(),
    name: data.name || '新建模板',
    reportType: data.reportType || '任务工作量',
    description: data.description || '',
    page: data.page || { width: 820, height: 1100, padding: '40px 32px' },
    elements: data.elements || [],
    creator: '当前用户',
    createTime: now,
    updateTime: now,
  };
  mockStatTemplateStore.push(tpl);
  return mockDelay({ code: 200, data: tpl, msg: '模板创建成功' }, 200);
}

/**
 * 更新报告模板（页面布局与显示风格修改）
 * 真实接口: PUT /task-monitor/stat/template/update
 */
export function updateReportTemplate(data: Partial<StatTemplate> & { id: string }): Promise<any> {
  const idx = mockStatTemplateStore.findIndex((t) => t.id === data.id);
  if (idx >= 0) {
    const now = new Date().toLocaleString('zh-CN', { hour12: false });
    mockStatTemplateStore[idx] = {
      ...mockStatTemplateStore[idx],
      ...data,
      id: mockStatTemplateStore[idx].id,
      updateTime: now,
    } as StatTemplate;
    return mockDelay({ code: 200, data: mockStatTemplateStore[idx], msg: '模板更新成功' }, 200);
  }
  return Promise.resolve({ code: 404, data: null, msg: '未找到模板' });
}

/**
 * 删除报告模板
 * 真实接口: DELETE /task-monitor/stat/template/{id}
 */
export function deleteReportTemplate(id: string): Promise<any> {
  const idx = mockStatTemplateStore.findIndex((t) => t.id === id);
  if (idx >= 0) mockStatTemplateStore.splice(idx, 1);
  return mockDelay({ code: 200, data: null, msg: '模板删除成功' }, 150);
}

/* ================================================================
 *  四、统计明细数据（按作业岗位/作业组/节点单位/任务总维度）
 * ================================================================ */

/** 作业岗位名称 */
const STAT_POSTS = ['智能提取作业岗位', '属性挖掘作业岗位', '地质要素作业岗位', '陆海融合作业岗位', '人机协同作业岗位', '矢量组网作业岗位'];
/** 作业组名称 */
const STAT_GROUPS = ['智能提取作业一组', '智能提取作业二组', '属性挖掘作业组', '地质要素作业组', '陆海融合作业组', '矢量组网作业组'];
/** 节点单位名称 */
const STAT_NODES = ['北京节点单位', '西安节点单位', '成都节点单位', '武汉节点单位', '哈尔滨节点单位'];

/** 按维度取统计对象名称列表 */
function getDimensionNames(dimension: string): string[] {
  if (dimension === 'group') return STAT_GROUPS;
  if (dimension === 'node') return STAT_NODES;
  if (dimension === 'total') return ['任务总（全部统计对象汇总）'];
  return STAT_POSTS;
}

/* ---------- (2) 任务工作量统计 ---------- */

/**
 * 获取任务工作量统计数据
 * 真实接口: GET /task-monitor/stat/workload
 * @param params.period 统计周期 month|quarter|year
 * @param params.calcMode 计算方式 auto|manual（自动/手工）
 * @param params.dimension 统计对象维度 post|group|node|total
 */
export function getWorkloadData(params?: Record<string, any>): Promise<any> {
  const dimension = params?.dimension || 'post';
  const names = getDimensionNames(dimension);
  const baseStd = [320, 280, 350, 260, 300, 240, 310, 270];
  const rows = names.map((name, i) => {
    const std = dimension === 'total' ? 1750 : baseStd[i % baseStd.length];
    const done = Math.round(std * (0.9 + ((i * 7) % 9) / 100) * 10) / 10;
    return {
      object: name,
      standardWorkload: std,                       // 标准工作量（工时）
      completedWorkload: done,                     // 完成工作量（工时）
      completionRate: Math.round((done / std) * 1000) / 10,  // 完成率 %
      taskCount: dimension === 'total' ? 213 : 30 + ((i * 11) % 18), // 承担任务数
      overtimeRate: Math.round((2 + (i * 1.7) % 6) * 10) / 10,      // 超时率 %
    };
  });
  const mockData = {
    dimension,
    overview: [
      { label: '任务总数', value: 213, unit: '项', trend: 8.2 },
      { label: '已完成任务', value: 196, unit: '项', trend: 6.5 },
      { label: '总标准工作量', value: 1750, unit: '工时', trend: 4.1 },
      { label: '总完成工作量', value: 1668.6, unit: '工时', trend: 5.3 },
      { label: '人均工作量', value: 51.8, unit: '工时/人', trend: 2.0 },
    ],
    trend: {
      categories: ['3月', '4月', '5月', '6月', '7月', '8月'],
      totalTasks: [178, 192, 201, 188, 207, 213],
      completedTasks: [165, 180, 189, 176, 193, 196],
      workHours: [1420, 1536, 1608, 1504, 1656, 1668.6],
    },
    pie: {
      data: [
        { value: 35, name: '数据核验' },
        { value: 28, name: '统计分析' },
        { value: 52, name: '流程作业' },
        { value: 20, name: '报表生成' },
        { value: 15, name: '安全巡检' },
        { value: 18, name: '文档处理' },
      ],
    },
    dimensionTable: {
      columns: ['统计对象', '标准工作量(工时)', '完成工作量(工时)', '完成率', '承担任务数', '超时率'],
      rows,
    },
  };
  return mockDelay({ code: 200, data: mockData, msg: 'ok' }, 300);
}

/* ---------- (3) 任务作业率统计 ---------- */

/**
 * 获取任务作业率统计数据
 * 真实接口: GET /task-monitor/stat/oprate
 * @param params.dimension 统计对象维度
 */
export function getOpRateData(params?: Record<string, any>): Promise<any> {
  const dimension = params?.dimension || 'post';
  const names = getDimensionNames(dimension);
  const rows = names.map((name, i) => {
    const planned = dimension === 'total' ? 1600 : [400, 360, 420, 380, 350, 320, 300, 280][i % 8];
    const actual = Math.round(planned * (0.86 + ((i * 5) % 11) / 100) * 10) / 10;
    return {
      object: name,
      plannedHours: planned,          // 计划作业工时
      actualHours: actual,            // 实际作业工时
      operationRate: Math.round((actual / planned) * 1000) / 10,  // 作业率 %
      efficiency: Math.round((3.5 + (i * 0.3) % 1.5) * 10) / 10,  // 效率评分
      bottleneck: i % 3 === 0 ? '数据等待' : i % 3 === 1 ? '无' : '环境切换',
      suggestion: i % 3 === 0 ? '优化上游数据推送节奏，减少等待。' : i % 3 === 1 ? '保持现有资源配置。' : '合并作业批次，降低环境切换损耗。',
    };
  });
  const mockData = {
    dimension,
    overview: [
      { label: '平均作业率', value: 91.2, unit: '%', trend: 1.6 },
      { label: '总计划工时', value: 2610, unit: '小时', trend: 3.2 },
      { label: '总实际工时', value: 2380.5, unit: '小时', trend: 4.8 },
      { label: '高效维度占比', value: 66.7, unit: '%', trend: 2.1 },
      { label: '瓶颈维度数', value: 4, unit: '个', trend: -12.5 },
    ],
    trend: {
      categories: ['第27周', '第28周', '第29周', '第30周', '第31周', '第32周'],
      plannedRate: [88, 88.5, 89, 89.5, 90, 90.5],
      actualRate: [85.2, 86.8, 88.1, 87.4, 89.6, 91.2],
    },
    compare: {
      categories: names,
      plannedHours: rows.map((r) => r.plannedHours),
      actualHours: rows.map((r) => r.actualHours),
    },
    dimensionTable: {
      columns: ['统计对象', '计划作业工时(h)', '实际作业工时(h)', '作业率', '效率评分', '瓶颈环节', '优化建议'],
      rows,
    },
  };
  return mockDelay({ code: 200, data: mockData, msg: 'ok' }, 300);
}

/* ---------- (4) 任务质量统计 ---------- */

/**
 * 获取任务质量统计数据
 * 真实接口: GET /task-monitor/stat/quality
 * @param params.dimension 统计对象维度
 */
export function getQualityData(params?: Record<string, any>): Promise<any> {
  const dimension = params?.dimension || 'post';
  const names = getDimensionNames(dimension);
  const rows = names.map((name, i) => {
    const score = Math.round((88 + ((i * 13) % 11)) * 10) / 10;
    return {
      object: name,
      qualityScore: score,                       // 质量得分
      dataQuality: Math.round((score + 2 - (i % 3)) * 10) / 10,   // 数据质量
      outputQuality: Math.round((score - 1 + (i % 3)) * 10) / 10, // 成果质量
      defectCount: 3 + ((i * 7) % 9),            // 缺陷数
      passRate: Math.round((93 + (i % 5)) * 10) / 10,             // 一次通过率 %
      reworkRate: Math.round((1.2 + (i * 0.4) % 2) * 10) / 10,    // 返工率 %
    };
  });
  const mockData = {
    dimension,
    overview: [
      { label: '综合质量得分', value: 93.6, unit: '分', trend: 1.2 },
      { label: '一次通过率', value: 95.4, unit: '%', trend: 0.8 },
      { label: '缺陷总数', value: 47, unit: '个', trend: -15.2 },
      { label: '严重缺陷数', value: 3, unit: '个', trend: -25.0 },
      { label: '返工率', value: 1.8, unit: '%', trend: -0.4 },
    ],
    radar: {
      indicators: [
        { name: '数据准确性', max: 100 },
        { name: '规格合规率', max: 100 },
        { name: '时效达标率', max: 100 },
        { name: '文档完整度', max: 100 },
        { name: '异常处理率', max: 100 },
        { name: '成果合格率', max: 100 },
      ],
      current: [96.8, 98.7, 93.5, 95.2, 89.4, 92.0],
      last: [94.5, 97.2, 91.0, 93.8, 86.5, 90.3],
    },
    defect: {
      data: [
        { value: 35, name: '数据格式错误' },
        { value: 25, name: '规格偏差' },
        { value: 18, name: '标签缺失' },
        { value: 12, name: '时间戳异常' },
        { value: 10, name: '其他' },
      ],
    },
    trend: {
      categories: ['3月', '4月', '5月', '6月', '7月', '8月'],
      dataQuality: [94.2, 94.5, 95.0, 95.3, 95.8, 96.2],
      outputQuality: [91.0, 91.5, 92.0, 92.5, 93.0, 93.4],
      overall: [92.6, 93.0, 93.5, 93.9, 94.4, 93.6],
    },
    dimensionTable: {
      columns: ['统计对象', '质量得分', '数据质量', '成果质量', '缺陷数', '一次通过率', '返工率'],
      rows,
    },
  };
  return mockDelay({ code: 200, data: mockData, msg: 'ok' }, 300);
}

/* ---------- (5) 任务评价统计 ---------- */

/**
 * 获取任务评价统计数据（依据任务评价模块各类评价数据）
 * 真实接口: GET /task-monitor/stat/eval
 * @param params.evalType 评价类型 all|business|manager|process|composite
 */
export function getEvalData(params?: Record<string, any>): Promise<any> {
  const evalType = params?.evalType || 'all';
  const taskRows = [
    { taskName: '工程测绘数据自动化处理流程', taskType: '计划任务', business: 92.5, manager: 90.0, process: 88.5, composite: 90.8, grade: '优秀', evaluators: 5, evalTime: '2026-08-14 17:00:00' },
    { taskName: '应急灾害响应数据采集', taskType: '应急任务', business: 88.0, manager: 85.5, process: 86.2, composite: 86.6, grade: '良好', evaluators: 4, evalTime: '2026-08-15 12:30:00' },
    { taskName: '卫星影像自动化配准与组网', taskType: '计划任务', business: 94.0, manager: 93.5, process: 92.0, composite: 93.3, grade: '优秀', evaluators: 6, evalTime: '2026-08-15 13:00:00' },
    { taskName: '矢量数据产品生成与分发', taskType: '计划任务', business: 90.5, manager: 89.0, process: 91.0, composite: 90.2, grade: '优秀', evaluators: 5, evalTime: '2026-08-14 17:30:00' },
    { taskName: '属性挖掘与要素关联分析', taskType: '自立任务', business: 82.0, manager: 80.5, process: 79.0, composite: 80.8, grade: '良好', evaluators: 3, evalTime: '2026-08-16 09:20:00' },
    { taskName: '陆海融合数据整编任务', taskType: '计划任务', business: 76.5, manager: 74.0, process: 78.0, composite: 76.2, grade: '合格', evaluators: 3, evalTime: '2026-08-16 10:40:00' },
    { taskName: '协同检核样本抽检任务', taskType: '自立任务', business: 68.0, manager: 65.5, process: 70.0, composite: 67.6, grade: '合格', evaluators: 2, evalTime: '2026-08-16 14:10:00' },
    { taskName: '临时空间数据清理任务', taskType: '其他任务', business: 58.0, manager: 62.0, process: 55.0, composite: 58.3, grade: '不合格', evaluators: 2, evalTime: '2026-08-16 16:00:00' },
  ];
  let rows = [...taskRows];
  if (evalType === 'business' || evalType === 'manager' || evalType === 'process') {
    // 过滤模拟：按评价类型仅调整综合得分口径
    rows = rows.map((r) => ({ ...r, composite: evalType === 'business' ? r.business : evalType === 'manager' ? r.manager : r.process }));
  }
  const mockData = {
    evalType,
    overview: [
      { label: '评价任务数', value: 8, unit: '项', trend: 14.3 },
      { label: '平均综合得分', value: 80.5, unit: '分', trend: 2.4 },
      { label: '优秀率', value: 37.5, unit: '%', trend: 5.0 },
      { label: '合格及以上占比', value: 87.5, unit: '%', trend: 3.1 },
      { label: '参与评价人数', value: 30, unit: '人', trend: 11.1 },
    ],
    grade: {
      data: [
        { value: 3, name: '优秀(≥90)' },
        { value: 2, name: '良好(75-89)' },
        { value: 2, name: '合格(60-74)' },
        { value: 1, name: '不合格(<60)' },
      ],
    },
    dimension: {
      categories: taskRows.map((r) => r.taskName.slice(0, 8)),
      business: taskRows.map((r) => r.business),
      manager: taskRows.map((r) => r.manager),
      process: taskRows.map((r) => r.process),
    },
    dimensionTable: {
      columns: ['任务名称', '任务类型', '业务用户评分', '管理用户评分', '业务环节评分', '综合得分', '评价等级', '评价人数', '评价时间'],
      rows,
    },
  };
  return mockDelay({ code: 200, data: mockData, msg: 'ok' }, 300);
}

/* ---------- (6) 任务综合分析 ---------- */

/**
 * 获取任务综合分析数据
 * 真实接口: GET /task-monitor/stat/analysis
 * 综合依据：任务工作量/作业率/质量统计数据 + 业务环节评价/任务综合评价 + 其他任务因素
 */
export function getAnalysisData(params?: Record<string, any>): Promise<any> {
  const mockData = {
    overview: [
      { label: '综合绩效指数', value: '87.5', unit: '', trend: 2.3, color: '#337ab7' },
      { label: '任务完成率', value: '92.0', unit: '%', trend: 1.5, color: '#5cb85c' },
      { label: '平均作业率', value: '91.2', unit: '%', trend: -0.8, color: '#f0ad4e' },
      { label: '质量达标率', value: '89.0', unit: '%', trend: 0.6, color: '#d9534f' },
      { label: '综合评价均分', value: '80.5', unit: '分', trend: 2.4, color: '#8e44ad' },
    ],
    matrix: {
      categories: ['工作量', '作业率', '质量', '环节评价', '综合评价', '协同水平'],
      current: [92.5, 91.2, 89.0, 82.6, 80.5, 84.2],
      last: [90.0, 92.0, 87.5, 80.1, 78.6, 82.0],
      target: [95.0, 93.0, 92.0, 85.0, 82.0, 86.0],
    },
    dimensionTable: {
      columns: ['分析维度', '当前值', '上期值', '环比变化', '目标值', '达成率', '分析结论'],
      // 注意：字段顺序必须与 columns 一一对应（前端按列顺序映射取值）
      rows: [
        { dimension: '工作量维度', current: '92.5%', last: '90.0%', change: '+2.5%', target: '95.0%', achievement: '97.4%', conclusion: '工作量完成情况良好，预计可达成月度目标。' },
        { dimension: '作业率维度', current: '91.2%', last: '92.0%', change: '-0.8%', target: '93.0%', achievement: '98.1%', conclusion: '作业率略有回落，需关注数据等待瓶颈。' },
        { dimension: '质量维度', current: '89.0%', last: '87.5%', change: '+1.5%', target: '92.0%', achievement: '96.7%', conclusion: '质量稳中有升，缺陷密度持续下降。' },
        { dimension: '业务环节评价', current: '82.6分', last: '80.1分', change: '+2.5分', target: '85.0分', achievement: '97.2%', conclusion: '关键环节评价改善，协同检核环节仍有提升空间。' },
        { dimension: '任务综合评价', current: '80.5分', last: '78.6分', change: '+1.9分', target: '82.0分', achievement: '98.2%', conclusion: '综合评价稳步提升，不合格评价占比下降。' },
        { dimension: '资源利用（其他因素）', current: '85.3%', last: '83.0%', change: '+2.3%', target: '88.0%', achievement: '96.9%', conclusion: '资源利用率持续优化，临时空间回收及时。' },
      ],
    },
    factors: [
      '一、总体结论：本统计周期任务组织与执行总体平稳，综合绩效指数 87.5，环比提升 2.3%。工作量、质量、评价三方面均呈上升趋势。',
      '二、主要亮点：卫星影像配准与组网任务综合评价 93.3 分（优秀）；矢量组网作业岗位工作量完成率 96.3%，位居各岗位前列。',
      '三、风险提示：应急任务「临时空间数据清理任务」综合评价 58.3 分（不合格），建议纳入重点督办；平均作业率环比下降 0.8%，主要受数据等待瓶颈影响。',
      '四、改进建议：1）优化上游数据推送节奏，压缩数据等待时长；2）针对不合格任务开展专项复盘；3）持续跟踪协同检核环节评价变化。',
    ],
  };
  return mockDelay({ code: 200, data: mockData, msg: 'ok' }, 350);
}

/* ================================================================
 *  五、报告生成（模板自包含数据，直接返回 DSL 副本）
 * ================================================================ */

/** 生成报告的入参 */
export interface GenerateReportParams {
  templateId: string;
  reportType: string;
  period?: string;      // 统计周期描述
  dimension?: string;   // 统计对象维度
}

/**
 * 使用统计报告模板生成报告。
 * 真实接口: POST /task-monitor/stat/report/generate
 *
 * 模板元素已自包含数据（dataSource.staticData / dataBinding），
 * 因此直接返回模板 DSL 副本 + 报告元信息，由报告渲染器消费。
 * 后续接入真实接口时，可在此按 period/dimension 替换各元素 API 数据。
 */
export async function generateStatReport(params: GenerateReportParams): Promise<any> {
  const tpl = mockStatTemplateStore.find((t) => t.id === params.templateId);
  if (!tpl) {
    return { code: 404, data: null, msg: '未找到报告模板' };
  }
  const report = {
    template: JSON.parse(JSON.stringify(tpl)),
    reportName: `${params.period || ''}${tpl.reportType}报告`.replace(/^\s*/, ''),
    reportType: tpl.reportType,
    generatedAt: new Date().toLocaleString('zh-CN', { hour12: false }),
    generatedBy: '当前用户',
  };
  return mockDelay({ code: 200, data: report, msg: '报告生成成功' }, 500);
}
