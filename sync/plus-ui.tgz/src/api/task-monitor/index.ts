/* ================================================================
 *  任务监控 (Task Monitor)
 *
 *  【数据来源说明】
 *   已接真实接口：
 *     · getTaskStatusList     → GET /dolphinscheduler/monitor/task-execution（子任务+作业单元明细，分页）
 *     · getTaskStatusPieData  → 按 lifecycle 状态聚合（饼图）
 *     · getTaskTypeBarData    → 按任务类型聚合（柱图）
 *   仍为示例数据（后端暂无对应接口，接入清单见《全业务流程深度排查报告》）：
 *     · 报表 / 可视化方案 / 报告模板 / 任务评价 / 资源趋势 / 节点负载
 * ================================================================ */

import request from '@/utils/request';
import { queryMainTaskMonitorList } from '@/api/task-scheduling/taskMonitor';

/** 任务执行情况查询参数（GET /monitor/task-execution） */
export interface TaskExecutionQuery {
  searchName?: string;
  taskType?: string;
  taskStatus?: string;
  mainProjectId?: number | string;
  subTaskNo?: string;
  pageNo: number;
  pageSize: number;
}

/**
 * 获取任务执行情况列表
 * 真实接口: GET /dolphinscheduler/monitor/task-execution
 * 子任务 + 作业单元明细，服务端分页
 * @param params 查询参数（searchName/taskStatus/mainProjectId/subTaskNo/pageNo/pageSize）
 */
export const getTaskStatusList = (params?: TaskExecutionQuery) => {
  return request({
    url: '/dolphinscheduler/monitor/task-execution',
    method: 'get',
    params
  });
};

/** 海豚任务暂停 */
export const pauseTask = (id: string) => {
  return request({
    url: `/taskApproval/exec/plan/${id}/pause`,
    method: 'post'
  });
};

/** 海豚任务恢复 */
export const resumeTask = (id: string) => {
  return request({
    url: `/taskApproval/exec/plan/${id}/resume`,
    method: 'post'
  });
};

/** 真实数据：按生命周期状态聚合（饼图） */
async function fetchRealStatusPie() {
  const res: any = await queryMainTaskMonitorList({ pageNo: 1, pageSize: 500 });
  const counter: Record<string, number> = {};
  ((res?.rows as any[]) || []).forEach((t: any) => {
    const key = t.taskLifeStatusName || t.taskLifeStatus || '未知';
    counter[key] = (counter[key] || 0) + 1;
  });
  const data = Object.keys(counter).map((name) => ({ name, value: counter[name] }));
  return { code: 200, msg: 'ok', data: { rows: data, data } };
}

/** 真实数据：按任务类型聚合（柱图） */
async function fetchRealTypeBar() {
  const res: any = await queryMainTaskMonitorList({ pageNo: 1, pageSize: 500 });
  const counter: Record<string, number> = {};
  ((res?.rows as any[]) || []).forEach((t: any) => {
    const key = t.taskTypeName || '未知';
    counter[key] = (counter[key] || 0) + 1;
  });
  const data = Object.keys(counter).map((name) => ({ name, value: counter[name] }));
  return { code: 200, msg: 'ok', data: { rows: data, data } };
}

/**
 * 获取系统资源使用概览
 * 真实接口: GET /task-monitor/resource/usage
 */
export function getResourceUsage(): Promise<any> {
  const mockData: any = {
    cpuTotal: 64,
    cpuUsed: 37.2,
    memoryTotal: 256,
    memoryUsed: 142.8,
    storageTotal: 4096,
    storageUsed: 1843.5,
    runningTasks: 3,
    waitingTasks: 2,
    completedTasks: 8
  };

  return Promise.resolve({ code: 200, data: mockData, msg: 'ok' });
}

/**
 * 获取节点资源列表
 * 真实接口: GET /task-monitor/resource/nodes
 */
export function getNodeResourceList(): Promise<any> {
  const mockData: any[] = [
    {
      nodeId: 'N001',
      nodeName: '数据采集节点集群',
      cpuUsage: 45.2,
      memoryUsage: 52.8,
      storageUsage: 38.1,
      networkIn: '125.6 MB/s',
      networkOut: '87.3 MB/s',
      taskCount: 3,
      status: 'normal'
    },
    {
      nodeId: 'N002',
      nodeName: '计算处理节点集群',
      cpuUsage: 78.5,
      memoryUsage: 65.3,
      storageUsage: 45.7,
      networkIn: '210.2 MB/s',
      networkOut: '156.8 MB/s',
      taskCount: 5,
      status: 'busy'
    },
    {
      nodeId: 'N003',
      nodeName: '数据存储节点集群',
      cpuUsage: 22.1,
      memoryUsage: 35.6,
      storageUsage: 72.4,
      networkIn: '340.1 MB/s',
      networkOut: '198.5 MB/s',
      taskCount: 2,
      status: 'normal'
    },
    {
      nodeId: 'N004',
      nodeName: '报表渲染节点集群',
      cpuUsage: 55.8,
      memoryUsage: 48.2,
      storageUsage: 25.3,
      networkIn: '98.7 MB/s',
      networkOut: '221.4 MB/s',
      taskCount: 4,
      status: 'normal'
    },
    {
      nodeId: 'N005',
      nodeName: '消息队列节点集群',
      cpuUsage: 12.4,
      memoryUsage: 28.9,
      storageUsage: 15.8,
      networkIn: '456.3 MB/s',
      networkOut: '389.2 MB/s',
      taskCount: 1,
      status: 'normal'
    }
  ];

  return Promise.resolve({ code: 200, data: mockData, msg: 'ok' });
}

/**
 * 获取任务运行日志
 * 真实接口: GET /task-monitor/task/{taskId}/logs
 */
export function getTaskLogs(taskId: string): Promise<any> {
  console.log('Fetching logs for task:', taskId);
  const mockData: any[] = [
    { time: '2026-07-23 08:15:00', level: 'info', content: '[任务调度] 任务 T20260723001 已分配至计算处理节点集群' },
    { time: '2026-07-23 08:15:01', level: 'info', content: '[环境准备] 正在初始化运行环境，分配 CPU 4核 / 内存 8GB' },
    { time: '2026-07-23 08:15:03', level: 'info', content: '[环境准备] 运行环境初始化完成，耗时 2.1s' },
    { time: '2026-07-23 08:15:05', level: 'info', content: '[数据加载] 开始加载成品钢材入库数据源，目标库表: wms_steel_inbound' },
    { time: '2026-07-23 08:16:12', level: 'info', content: '[数据加载] 数据加载完成，总计 125,830 条记录，数据大小 38.2MB' },
    { time: '2026-07-23 08:16:15', level: 'info', content: '[规则引擎] 加载核验规则 47 条，覆盖字段 23 个' },
    { time: '2026-07-23 08:20:30', level: 'warn', content: '[规则引擎] 发现疑似异常数据: 批次 BH20260718045 重量偏差超过阈值(±3%)，当前偏差 4.2%' },
    { time: '2026-07-23 08:20:35', level: 'info', content: '[规则引擎] 异常数据已标记，待人工审核 1 条' },
    { time: '2026-07-23 08:30:00', level: 'info', content: '[质检节点-2] 规格型号校验通过率 98.7%，不匹配记录 1638 条已隔离' },
    { time: '2026-07-23 08:45:22', level: 'warn', content: '[质检节点-3] 材质标签校验发现 23 条记录缺少材质证书编号' },
    { time: '2026-07-23 09:00:00', level: 'info', content: '[质检节点-3] 正在进行表面质量检测数据关联匹配' },
    { time: '2026-07-23 09:15:45', level: 'error', content: '[质检节点-3] 外部检测系统接口超时，第3次重试失败，等待 30s 后继续重试' },
    { time: '2026-07-23 09:16:15', level: 'info', content: '[质检节点-3] 外部检测系统接口恢复，重试成功' },
    { time: '2026-07-23 09:30:00', level: 'info', content: '[质检节点-3] 表面质量检测数据关联完成，已关联 124,592 条' },
    { time: '2026-07-23 09:45:33', level: 'info', content: '[进度更新] 当前任务进度 72%，预计剩余时间 2小时15分钟' },
    { time: '2026-07-23 10:00:00', level: 'warn', content: '[资源监控] 内存使用率 42.1%，接近预警线 50%' }
  ];

  return Promise.resolve({ code: 200, data: mockData, msg: 'ok' });
}

/**
 * 可视化方案内存存储（初始内置方案 + 用户保存的方案）
 */
const mockSchemeStore: any[] = [
  {
    id: 'S001',
    name: '系统资源全景监控',
    type: '实时监控',
    layout: [
      {
        uid: 'e1',
        type: 'chart',
        label: '图形',
        icon: 'DataAnalysis',
        title: 'CPU趋势',
        field: 'trend',
        colSpan: 2,
        rowHeight: 200,
        bgColor: '#fff',
        borderColor: '#e4e7ed',
        fontColor: '#303133',
        fontSize: 14,
        textAlign: 'left',
        order: 'default',
        sortBy: 'name',
        content: ''
      },
      {
        uid: 'e2',
        type: 'chart',
        label: '图形',
        icon: 'DataAnalysis',
        title: '节点负载',
        field: 'load',
        colSpan: 2,
        rowHeight: 200,
        bgColor: '#fff',
        borderColor: '#e4e7ed',
        fontColor: '#303133',
        fontSize: 14,
        textAlign: 'left',
        order: 'default',
        sortBy: 'name',
        content: ''
      },
      {
        uid: 'e3',
        type: 'table',
        label: '表格',
        icon: 'Grid',
        title: '资源列表',
        field: 'resource_list',
        colSpan: 4,
        rowHeight: 250,
        bgColor: '#fff',
        borderColor: '#e4e7ed',
        fontColor: '#303133',
        fontSize: 14,
        textAlign: 'left',
        order: 'default',
        sortBy: 'name',
        content: ''
      }
    ],
    gridColumns: 4,
    config: { refreshInterval: 30, defaultRange: '24h', alertCpu: 80, alertMem: 85, alertStorage: 90 },
    creator: '管理员',
    createTime: '2026-07-15 10:00:00'
  },
  {
    id: 'S002',
    name: '任务执行效率分析',
    type: '分析看板',
    layout: [
      {
        uid: 'e1',
        type: 'chart',
        label: '图形',
        icon: 'DataAnalysis',
        title: '任务状态分布',
        field: 'pie',
        colSpan: 2,
        rowHeight: 220,
        bgColor: '#fff',
        borderColor: '#e4e7ed',
        fontColor: '#303133',
        fontSize: 14,
        textAlign: 'left',
        order: 'default',
        sortBy: 'name',
        content: ''
      },
      {
        uid: 'e2',
        type: 'chart',
        label: '图形',
        icon: 'DataAnalysis',
        title: '任务类型统计',
        field: 'bar',
        colSpan: 2,
        rowHeight: 220,
        bgColor: '#fff',
        borderColor: '#e4e7ed',
        fontColor: '#303133',
        fontSize: 14,
        textAlign: 'left',
        order: 'default',
        sortBy: 'name',
        content: ''
      },
      {
        uid: 'e3',
        type: 'table',
        label: '表格',
        icon: 'Grid',
        title: '任务列表',
        field: 'task_list',
        colSpan: 4,
        rowHeight: 250,
        bgColor: '#fff',
        borderColor: '#e4e7ed',
        fontColor: '#303133',
        fontSize: 14,
        textAlign: 'left',
        order: 'default',
        sortBy: 'name',
        content: ''
      }
    ],
    gridColumns: 4,
    config: { refreshInterval: 60, defaultRange: '24h', alertCpu: 75, alertMem: 80, alertStorage: 85 },
    creator: '张建国',
    createTime: '2026-07-18 14:30:00'
  },
  {
    id: 'S003',
    name: '任务流程监控看板',
    type: '流程看板',
    layout: [
      {
        uid: 'e1',
        type: 'chart',
        label: '图形',
        icon: 'DataAnalysis',
        title: '任务甘特图',
        field: 'gantt',
        colSpan: 4,
        rowHeight: 300,
        bgColor: '#fff',
        borderColor: '#e4e7ed',
        fontColor: '#303133',
        fontSize: 14,
        textAlign: 'left',
        order: 'default',
        sortBy: 'name',
        content: ''
      },
      {
        uid: 'e2',
        type: 'text',
        label: '文本',
        icon: 'Document',
        title: '异常分析',
        field: 'alert_analysis',
        colSpan: 2,
        rowHeight: 150,
        bgColor: '#fef0f0',
        borderColor: '#f56c6c',
        fontColor: '#f56c6c',
        fontSize: 14,
        textAlign: 'left',
        order: 'default',
        sortBy: 'name',
        content: '异常任务统计与分析'
      },
      {
        uid: 'e3',
        type: 'table',
        label: '表格',
        icon: 'Grid',
        title: '异常任务',
        field: 'alert_list',
        colSpan: 2,
        rowHeight: 150,
        bgColor: '#fff',
        borderColor: '#e4e7ed',
        fontColor: '#303133',
        fontSize: 14,
        textAlign: 'left',
        order: 'default',
        sortBy: 'name',
        content: ''
      }
    ],
    gridColumns: 4,
    config: { refreshInterval: 10, defaultRange: '1h', alertCpu: 80, alertMem: 80, alertStorage: 85 },
    creator: '李明华',
    createTime: '2026-07-20 09:15:00'
  }
];

/**
 * 获取可视化方案列表
 * 真实接口: GET /task-monitor/scheme/list
 * 注意：返回深拷贝以触发前端响应式更新
 */
export function getSchemeList(): Promise<any> {
  return Promise.resolve({ code: 200, data: JSON.parse(JSON.stringify(mockSchemeStore)), msg: 'ok' });
}

/**
 * 获取单个可视化方案详情
 * 真实接口: GET /task-monitor/scheme/{id}
 */
export function getSchemeDetail(id: string): Promise<any> {
  const scheme = mockSchemeStore.find((s) => s.id === id);
  return Promise.resolve({ code: 200, data: scheme ? JSON.parse(JSON.stringify(scheme)) : null, msg: 'ok' });
}

/**
 * 保存可视化方案（新增/修改）
 * 真实接口: POST /task-monitor/scheme/save
 */
export function saveScheme(data: any): Promise<any> {
  if (data.id) {
    const idx = mockSchemeStore.findIndex((s) => s.id === data.id);
    if (idx >= 0) {
      mockSchemeStore[idx] = { ...mockSchemeStore[idx], ...data, createTime: mockSchemeStore[idx].createTime };
    } else {
      mockSchemeStore.push(data);
    }
  } else {
    const newId = 'S' + String(Date.now()).slice(-6);
    mockSchemeStore.push({ ...data, id: newId, creator: '当前用户', createTime: new Date().toLocaleString('zh-CN', { hour12: false }) });
  }
  return Promise.resolve({ code: 200, data: null, msg: '保存成功' });
}

/**
 * 删除可视化方案
 * 真实接口: DELETE /task-monitor/scheme/{id}
 */
export function deleteScheme(id: string): Promise<any> {
  const idx = mockSchemeStore.findIndex((s) => s.id === id);
  if (idx >= 0) mockSchemeStore.splice(idx, 1);
  return Promise.resolve({ code: 200, data: null, msg: '删除成功' });
}

/**
 * 获取报表列表
 * 真实接口: GET /task-monitor/report/list
 */
/**
 * 已生成报告列表（本地数据）。
 * 用模块级数组以便「生成报告 / 删除报告」能真实反映到列表上。
 */
const reportStore: any[] = [
  {
    id: 'RPT001',
    reportName: '2026年7月第4周任务执行日报',
    reportType: '日报',
    period: '2026-07-20 ~ 2026-07-23',
    format: 'PDF',
    status: '已生成',
    creator: '张建国',
    createTime: '2026-07-23 08:30:00'
  },
  {
    id: 'RPT002',
    reportName: '2026年7月第3周任务执行周报',
    reportType: '周报',
    period: '2026-07-13 ~ 2026-07-19',
    format: 'PDF',
    status: '已生成',
    creator: '李明华',
    createTime: '2026-07-20 09:00:00'
  },
  {
    id: 'RPT003',
    reportName: '2026年7月任务统计月报',
    reportType: '月报',
    period: '2026-07-01 ~ 2026-07-31',
    format: 'Excel',
    status: '生成中',
    creator: '赵志强',
    createTime: '2026-07-23 06:00:00'
  }
];

export function getReportList(params?: Record<string, any>): Promise<any> {
  // 真实接口: GET /task-monitor/report/list
  return Promise.resolve({ code: 200, data: { total: reportStore.length, rows: [...reportStore] }, msg: 'ok' });
}

/**
 * 生成报表
 * 真实接口: POST /task-monitor/report/generate
 */
export function generateReport(data: Record<string, any>): Promise<any> {
  console.log('Generating report with params:', data);
  const mockData: any = {
    id: 'RPT' + Date.now(),
    reportName: data.reportName || '新建报表',
    reportType: data.reportType || '自定义',
    period: data.period || '2026-07-23',
    format: data.format || 'PDF',
    status: '已生成',
    creator: '当前用户',
    createTime: '2026-07-23 10:30:00'
  };

  return Promise.resolve({ code: 200, data: mockData, msg: '报表生成成功' });
}

/* ================================================================
 *  任务运行报告：生成 / 删除 / 工程列表
 * ----------------------------------------------------------------
 *  说明：以下三个函数在原 2026-09-29 的改动中被页面引用，但实现缺失
 *        （构建报 "is not exported by .../task-monitor/index.ts"），此处补齐。
 *        生成结果的结构与 report-renderer.vue 对齐，便于直接预览。
 * ================================================================ */

/**
 * 生成任务运行报告（按报告模板）：POST /task-monitor/report/generate
 * 页面把返回的 data 直接交给报告渲染器预览，因此结构为：
 *   { template: { name, reportType, description, elements }, reportName, reportType, period, generatedAt, generatedBy }
 */
export function generateTaskReport(data: { templateId: string; formats?: string[]; [k: string]: any }): Promise<any> {
  const tpl: any = mockReportTemplates.find((t) => t.id === data.templateId);
  if (!tpl) {
    return Promise.resolve({ code: 500, msg: '报告模板不存在', data: null });
  }

  // 模板里声明的数据项 → 渲染器元素
  const ELEMENT_TYPE: Record<string, string> = { number: 'control', table: 'table', chart: 'chart', text: 'text' };
  const elements = (tpl.dataItems || []).map((it: any, i: number) => ({
    id: 'el' + (i + 1),
    type: ELEMENT_TYPE[it.dataType] || 'text',
    label: it.name,
    x: 0,
    y: i * 40,
    width: 700,
    height: it.dataType === 'table' || it.dataType === 'chart' ? 220 : 36,
    props: {},
    data: null
  }));

  const generatedAt = new Date().toLocaleString('zh-CN', { hour12: false });
  const period = data.period || '2026-07-01 ~ 2026-07-31';
  const format = (data.formats && data.formats[0]) || tpl.format || 'PDF';
  const report = {
    template: {
      name: tpl.templateName,
      reportType: tpl.reportType,
      description: tpl.description,
      elements
    },
    reportName: tpl.templateName,
    reportType: tpl.reportType,
    period,
    dimension: '作业岗位',
    generatedAt,
    generatedBy: '当前用户'
  };

  // 生成后登记到报告列表，保证"生成报告 → 列表可见"
  reportStore.unshift({
    id: 'RPT' + Date.now(),
    reportName: tpl.templateName,
    reportType: tpl.reportType,
    period,
    format,
    status: '已生成',
    creator: '当前用户',
    createTime: generatedAt
  });

  return Promise.resolve({ code: 200, data: report, msg: '报告生成成功' });
}

/** 删除已生成的报告：DELETE /task-monitor/report/{id} */
export function deleteReport(id: string): Promise<any> {
  const idx = reportStore.findIndex((r) => r.id === id);
  if (idx >= 0) reportStore.splice(idx, 1);
  return Promise.resolve({ code: 200, data: null, msg: '报告已删除' });
}

/**
 * 工程（项目）列表 —— 供任务监控页"选择工程"下拉使用。
 * 真实接口: GET /task-monitor/project/list（接入后替换本函数实现即可）
 */
export function getProjectList(): Promise<any> {
  return Promise.resolve({
    code: 200,
    msg: 'ok',
    data: [
      { id: 'PRJ001', name: '数据保障工程' },
      { id: 'PRJ002', name: '基础测绘工程' },
      { id: 'PRJ003', name: '应急保障工程' }
    ]
  });
}

/* ================================================================
 *  任务运行报告模板
 * ================================================================ */

/** 报告模板库 mock 数据 */
const mockReportTemplates: any[] = [
  {
    id: 'TPL001',
    templateName: '任务运行情况日报模板',
    reportType: '任务运行情况报告',
    description: '用于生成每日任务运行情况汇总报告，包含任务执行概要、明细列表、异常分析',
    dataItems: [
      { name: '任务总数', dataType: 'number', source: 'task_status' },
      { name: '完成数', dataType: 'number', source: 'task_status' },
      { name: '异常数', dataType: 'number', source: 'task_status' },
      { name: '任务明细', dataType: 'table', source: 'task_list' },
      { name: '异常分析', dataType: 'text', source: 'task_alerts' }
    ],
    layout: '纵向排版',
    format: 'PDF',
    permissions: { roles: ['超级管理员', '任务-项目负责人', '任务-项目组', '任务-任务调度'] },
    creator: '管理员',
    createTime: '2026-07-10 09:00:00',
    updateTime: '2026-07-20 14:30:00'
  },
  {
    id: 'TPL002',
    templateName: '资源使用情况周报模板',
    reportType: '资源使用情况报告',
    description: '用于生成每周资源使用情况统计报告，包含CPU/内存/存储使用率、节点负载对比',
    dataItems: [
      { name: 'CPU平均使用率', dataType: 'chart', source: 'resource_trend' },
      { name: '内存平均使用率', dataType: 'chart', source: 'resource_trend' },
      { name: '节点负载对比', dataType: 'chart', source: 'node_load' },
      { name: '资源明细', dataType: 'table', source: 'resource_list' }
    ],
    layout: '横向排版',
    format: 'Word',
    permissions: { roles: ['超级管理员', '资源管理', '运维子系统管理员'] },
    creator: '张建国',
    createTime: '2026-07-12 10:30:00',
    updateTime: '2026-07-18 16:00:00'
  },
  {
    id: 'TPL003',
    templateName: '任务异常专项报告模板',
    reportType: '专项报告',
    description: '用于生成任务异常/告警/超时专项分析报告',
    dataItems: [
      { name: '异常任务列表', dataType: 'table', source: 'task_alerts' },
      { name: '异常类型分布', dataType: 'chart', source: 'alert_stats' },
      { name: '处理建议', dataType: 'text', source: 'manual' }
    ],
    layout: '纵向排版',
    format: 'PDF',
    permissions: { roles: ['超级管理员', '任务-项目负责人', '陕西节点'] },
    creator: '李明华',
    createTime: '2026-07-15 11:00:00',
    updateTime: '2026-07-22 09:30:00'
  },
  {
    id: 'TPL004',
    templateName: '月度综合运行报告模板',
    reportType: '综合报告',
    description: '月度任务运行与资源使用综合分析报告',
    dataItems: [
      { name: '任务执行概要', dataType: 'text', source: 'task_summary' },
      { name: '任务趋势', dataType: 'chart', source: 'task_trend' },
      { name: '资源使用统计', dataType: 'chart', source: 'resource_trend' },
      { name: '绩效评估', dataType: 'table', source: 'task_evaluate' }
    ],
    layout: '混合排版',
    format: 'HTML',
    permissions: { roles: ['超级管理员', '陕西节点', '陕西节点-测绘局', '任务-项目负责人', '任务-项目组'] },
    creator: '管理员',
    createTime: '2026-07-01 08:00:00',
    updateTime: '2026-07-25 17:00:00'
  }
];

/**
 * 获取报告模板列表
 * 真实接口: GET /task-monitor/report-template/list
 */
export function getReportTemplatePage(params?: Record<string, any>): Promise<any> {
  let rows = [...mockReportTemplates];
  if (params?.templateName) {
    rows = rows.filter((r) => r.templateName.includes(params.templateName));
  }
  if (params?.reportType) {
    rows = rows.filter((r) => r.reportType === params.reportType);
  }
  return Promise.resolve({ code: 200, data: { total: rows.length, rows }, msg: 'ok' });
}

/**
 * 获取报告模板详情
 * 真实接口: GET /task-monitor/report-template/{id}
 */
export function getReportTemplateDetail(id: string): Promise<any> {
  const tpl = mockReportTemplates.find((t) => t.id === id);
  return Promise.resolve({ code: 200, data: tpl || null, msg: tpl ? 'ok' : '未找到模板' });
}

/**
 * 保存报告模板（新增/修改）
 * 真实接口: POST /task-monitor/report-template/save
 */
export function saveReportTemplate(data: any): Promise<any> {
  if (data.id) {
    const idx = mockReportTemplates.findIndex((t) => t.id === data.id);
    if (idx >= 0) {
      mockReportTemplates[idx] = { ...mockReportTemplates[idx], ...data, updateTime: new Date().toLocaleString('zh-CN', { hour12: false }) };
    }
  } else {
    const newId = 'TPL' + String(mockReportTemplates.length + 1).padStart(3, '0');
    mockReportTemplates.push({
      ...data,
      id: newId,
      creator: '当前用户',
      createTime: new Date().toLocaleString('zh-CN', { hour12: false }),
      updateTime: new Date().toLocaleString('zh-CN', { hour12: false })
    });
  }
  return Promise.resolve({ code: 200, data: null, msg: '保存成功' });
}

/**
 * 删除报告模板
 * 真实接口: DELETE /task-monitor/report-template/{id}
 */
export function deleteReportTpl(id: string): Promise<any> {
  const idx = mockReportTemplates.findIndex((t) => t.id === id);
  if (idx >= 0) mockReportTemplates.splice(idx, 1);
  return Promise.resolve({ code: 200, data: null, msg: '删除成功' });
}

/**
 * 导出任务运行报告
 * 真实接口: POST /task-monitor/report/export
 */
export function exportReport(id: string): Promise<any> {
  console.log('Exporting report:', id);
  return Promise.resolve({ code: 200, data: { downloadUrl: '#' }, msg: '导出成功' });
}

/* ================================================================
 *  ECharts Chart Data - 任务监控
 * ================================================================ */

/**
 * 获取任务状态分布饼图数据
 * 真实接口: GET /task-monitor/chart/status-pie
 */
export function getTaskStatusPieData(): Promise<any> {
  const mockData = {
    data: [
      { value: 3, name: '任务运行中' },
      { value: 1, name: '任务接收中' },
      { value: 1, name: '任务审批中' },
      { value: 1, name: '任务审批完成' },
      { value: 1, name: '任务分解中' },
      { value: 1, name: '任务分解完成' },
      { value: 1, name: '资源配置中' },
      { value: 1, name: '资源配置完成' },
      { value: 1, name: '任务提交中' },
      { value: 1, name: '任务暂停' },
      { value: 1, name: '任务取消' },
      { value: 1, name: '任务完成' }
    ]
  };

  // 真实数据优先（按生命周期状态聚合）；失败回落示例数据
  return fetchRealStatusPie().catch((err) => {
    console.warn('[任务监控] 状态分布真实接口不可用，回落到示例数据：', err);
    return { code: 200, data: mockData, msg: 'ok' };
  });
}

/**
 * 获取任务类型堆叠柱状图数据
 * 真实接口: GET /task-monitor/chart/type-bar
 */
export function getTaskTypeBarData(): Promise<any> {
  const mockData = {
    categories: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'],
    series: [
      { name: '计划任务', data: [18, 22, 25, 20, 24, 12, 8] },
      { name: '应急任务', data: [3, 5, 2, 6, 4, 8, 5] },
      { name: '自立任务', data: [7, 9, 11, 8, 10, 4, 3] },
      { name: '其他任务', data: [5, 4, 6, 5, 7, 2, 1] }
    ]
  };

  // 真实数据优先（按任务类型聚合）；失败回落示例数据
  return fetchRealTypeBar().catch((err) => {
    console.warn('[任务监控] 任务类型统计真实接口不可用，回落到示例数据：', err);
    return { code: 200, data: mockData, msg: 'ok' };
  });
}

/**
 * 获取资源使用趋势折线图数据
 * 真实接口: GET /task-monitor/chart/resource-trend
 */
export function getResourceTrendData(): Promise<any> {
  const mockData = {
    categories: ['00:00', '02:00', '04:00', '06:00', '08:00', '10:00', '12:00', '14:00', '16:00', '18:00', '20:00', '22:00'],
    series: [
      { name: 'CPU使用率(%)', data: [15, 12, 10, 18, 45, 58, 62, 55, 48, 52, 35, 22] },
      { name: '内存使用率(%)', data: [42, 40, 38, 45, 55, 68, 72, 65, 60, 58, 50, 44] },
      { name: '存储使用率(%)', data: [44, 44, 44, 44, 45, 45, 45, 45, 45, 45, 45, 44] }
    ]
  };

  return Promise.resolve({ code: 200, data: mockData, msg: 'ok' });
}

/**
 * 获取节点负载分组柱状图数据
 * 真实接口: GET /task-monitor/chart/node-load
 */
export function getNodeLoadBarData(): Promise<any> {
  const mockData = {
    categories: ['数据采集节点', '计算处理节点', '数据存储节点', '报表渲染节点', '消息队列节点'],
    series: [
      { name: 'CPU使用率(%)', data: [45.2, 78.5, 22.1, 55.8, 12.4] },
      { name: '内存使用率(%)', data: [52.8, 65.3, 35.6, 48.2, 28.9] },
      { name: '存储使用率(%)', data: [38.1, 45.7, 72.4, 25.3, 15.8] }
    ]
  };

  return Promise.resolve({ code: 200, data: mockData, msg: 'ok' });
}

/* ================================================================
 *  任务评价 (Task Evaluation)
 * ================================================================ */

/**
 * 获取评价指标体系列表
 * 真实接口: GET /task-monitor/eval/indicators
 */
export function getIndicatorList(): Promise<any> {
  const mockData: any[] = [
    {
      id: 'I01',
      code: 'I01',
      name: '进度完成率',
      category: '业务指标',
      type: 'auto',
      weight: 15,
      value: 92.5,
      description: '任务实际进度与计划进度的比值',
      readOnly: true
    },
    {
      id: 'I02',
      code: 'I02',
      name: '人均工作量',
      category: '业务指标',
      type: 'auto',
      weight: 10,
      value: 68.3,
      description: '统计周期内团队人均完成任务数',
      readOnly: true
    },
    {
      id: 'I03',
      code: 'I03',
      name: '产出量',
      category: '业务指标',
      type: 'auto',
      weight: 10,
      value: 1247,
      description: '统计周期内完成的任务产出数量',
      readOnly: true
    },
    {
      id: 'I04',
      code: 'I04',
      name: '返工工作量',
      category: '质量指标',
      type: 'auto',
      weight: 8,
      value: 3.2,
      description: '因质量问题导致返工的任务占比(%)',
      readOnly: true
    },
    {
      id: 'I05',
      code: 'I05',
      name: '质量达标率',
      category: '质量指标',
      type: 'auto',
      weight: 12,
      value: 96.8,
      description: '通过质检达标的任务占比(%)',
      readOnly: true
    },
    {
      id: 'I06',
      code: 'I06',
      name: '缺陷密度',
      category: '质量指标',
      type: 'auto',
      weight: 5,
      value: 0.12,
      description: '每千行/千件中的缺陷数',
      readOnly: true
    },
    {
      id: 'I07',
      code: 'I07',
      name: '质量评分',
      category: '质量指标',
      type: 'manual',
      weight: 15,
      value: 4.2,
      description: '由业务主管对任务完成质量评分(1-5星)',
      readOnly: false
    },
    {
      id: 'I08',
      code: 'I08',
      name: '专家评分',
      category: '综合评价',
      type: 'manual',
      weight: 10,
      value: 4.0,
      description: '由质量专家对任务成果评分(1-5星)',
      readOnly: false
    },
    {
      id: 'I09',
      code: 'I09',
      name: '时效性评分',
      category: '时效指标',
      type: 'manual',
      weight: 8,
      value: 4.5,
      description: '任务是否在承诺时间内完成(1-5星)',
      readOnly: false
    },
    {
      id: 'I10',
      code: 'I10',
      name: '协作评分',
      category: '综合评价',
      type: 'manual',
      weight: 7,
      value: 3.8,
      description: '跨部门/跨团队协作表现评分(1-5星)',
      readOnly: false
    }
  ];

  return Promise.resolve({ code: 200, data: mockData, msg: 'ok' });
}

/**
 * 保存指标体系配置
 * 真实接口: POST /task-monitor/eval/indicators/save
 */
export function saveIndicators(indicators: any): Promise<any> {
  console.log('Saving indicators:', indicators);
  return Promise.resolve({ code: 200, data: null, msg: '指标体系保存成功' });
}

/**
 * 获取业务评价列表
 * 真实接口: GET /task-monitor/eval/biz/list
 */
export function getBizEvalList(params: any): Promise<any> {
  console.log('Fetching biz eval with params:', params);
  const mockData: any = {
    total: 6,
    rows: [
      {
        id: 'EV-B001',
        taskName: '工程测绘数据自动化处理流程',
        taskType: '计划任务',
        team: '数据处理作业组',
        participantType: '作业组',
        participantName: '数据处理作业组',
        progress: 72,
        outputVolume: '125,830 个图幅',
        reworkCount: 2,
        qualityRate: 98.7,
        defectDensity: 0.08,
        qualityScore: 4,
        timelinessScore: 5,
        collaborationScore: 4,
        comment: '测绘数据处理流程运行顺畅，图幅拼接精度良好，少量控制点需复核。',
        evaluator: '张建国',
        evalTime: '2026-08-15 10:30:00',
        status: '已评价'
      },
      {
        id: 'EV-B002',
        taskName: '应急灾害响应数据采集',
        taskType: '应急任务',
        team: '现场采集作业岗位',
        participantType: '作业岗位',
        participantName: '现场采集岗位-李明华',
        progress: 45,
        outputVolume: '56,420 条采集记录',
        reworkCount: 1,
        qualityRate: 96.2,
        defectDensity: 0.15,
        qualityScore: 4,
        timelinessScore: 3,
        collaborationScore: 4,
        comment: '应急采集响应及时，数据分类标准与业务部门一致，预计按期完成。',
        evaluator: '李明华',
        evalTime: '2026-08-15 09:45:00',
        status: '已评价'
      },
      {
        id: 'EV-B003',
        taskName: '卫星影像自动化配准与组网',
        taskType: '计划任务',
        team: '影像处理作业组',
        participantType: '节点单位',
        participantName: '陕西节点-测绘局',
        progress: 91,
        outputVolume: '3,472 景影像',
        reworkCount: 5,
        qualityRate: 94.5,
        defectDensity: 0.22,
        qualityScore: 4,
        timelinessScore: 5,
        collaborationScore: 3,
        comment: '影像配准流程完整，组网拼接环节顺畅，末期注意控制点复核。',
        evaluator: '王芳',
        evalTime: '2026-08-15 11:00:00',
        status: '已评价'
      },
      {
        id: 'EV-B004',
        taskName: '矢量数据产品生成与分发',
        taskType: '计划任务',
        team: '产品输出作业组',
        participantType: '牵头单位',
        participantName: '陕西节点',
        progress: 100,
        outputVolume: '48 套矢量产品',
        reworkCount: 0,
        qualityRate: 100,
        defectDensity: 0,
        qualityScore: 5,
        timelinessScore: 5,
        collaborationScore: 5,
        comment: '矢量产品生成全部达标，零缺陷通过，分发链路表现突出。',
        evaluator: '赵志强',
        evalTime: '2026-08-14 14:00:00',
        status: '已评价'
      },
      {
        id: 'EV-B005',
        taskName: '自立质量审核与缺陷分析',
        taskType: '自立任务',
        team: '质量审核作业组',
        participantType: '作业组',
        participantName: '质量审核作业组',
        progress: 60,
        outputVolume: '18 份审核报告',
        reworkCount: 3,
        qualityRate: 92.3,
        defectDensity: 0.31,
        qualityScore: 3,
        timelinessScore: 4,
        collaborationScore: 4,
        comment: '质量审核按计划推进，缺陷分析准确，建议加强数据源校验。',
        evaluator: '陈卫国',
        evalTime: '2026-08-15 16:30:00',
        status: '已评价'
      },
      {
        id: 'EV-B006',
        taskName: '地理信息数据库更新维护',
        taskType: '计划任务',
        team: '数据库运维作业岗位',
        participantType: '作业岗位',
        participantName: '数据库运维岗位-刘雪梅',
        progress: 0,
        outputVolume: '待执行',
        reworkCount: 0,
        qualityRate: 0,
        defectDensity: 0,
        qualityScore: 0,
        timelinessScore: 0,
        collaborationScore: 0,
        comment: '',
        evaluator: '刘雪梅',
        evalTime: '',
        status: '待评价'
      }
    ]
  };

  return Promise.resolve({ code: 200, data: mockData, msg: 'ok' });
}

/**
 * 获取业务评价的自评/互评记录列表
 * 真实接口: GET /task-monitor/eval/biz/records
 */
export function getBizEvalRecords(params?: Record<string, any>): Promise<any> {
  console.log('Fetching biz eval records with params:', params);
  const mockRecords: any[] = [
    // 自评记录
    {
      id: 'BR-001',
      taskId: 'EV-B001',
      taskName: '工程测绘数据自动化处理流程',
      evalType: 'self',
      evaluatorType: '作业组',
      evaluatorName: '数据处理作业组',
      evaluator: '张建国',
      targetName: '数据处理作业组（自评）',
      anonymous: false,
      star: 4,
      comment: '本组工作完成度较好，部分图幅需返工。',
      visibility: '公开',
      evalTime: '2026-08-15 10:30:00'
    },
    {
      id: 'BR-002',
      taskId: 'EV-B002',
      taskName: '应急灾害响应数据采集',
      evalType: 'self',
      evaluatorType: '作业岗位',
      evaluatorName: '现场采集岗位-李明华',
      evaluator: '李明华',
      targetName: '现场采集岗位-李明华（自评）',
      anonymous: false,
      star: 4,
      comment: '应急响应及时，采集数据完整。',
      visibility: '节点内公开',
      evalTime: '2026-08-15 09:45:00'
    },
    {
      id: 'BR-003',
      taskId: 'EV-B004',
      taskName: '矢量数据产品生成与分发',
      evalType: 'self',
      evaluatorType: '牵头单位',
      evaluatorName: '陕西节点',
      evaluator: '赵志强',
      targetName: '陕西节点（自评）',
      anonymous: false,
      star: 5,
      comment: '产品分发零缺陷，各环节协同高效。',
      visibility: '公开',
      evalTime: '2026-08-14 14:00:00'
    },
    // 互评记录
    {
      id: 'BR-004',
      taskId: 'EV-B001',
      taskName: '工程测绘数据自动化处理流程',
      evalType: 'mutual',
      evaluatorType: '节点单位',
      evaluatorName: '陕西节点-测绘局',
      evaluator: '王芳',
      targetName: '数据处理作业组',
      anonymous: false,
      star: 4,
      comment: '数据处理及时，配准精度达标，建议加强控制点复核。',
      visibility: '公开',
      evalTime: '2026-08-15 11:00:00'
    },
    {
      id: 'BR-005',
      taskId: 'EV-B003',
      taskName: '卫星影像自动化配准与组网',
      evalType: 'mutual',
      evaluatorType: '作业组',
      evaluatorName: '影像处理作业组',
      evaluator: '张建国',
      targetName: '陕西节点-测绘局',
      anonymous: true,
      star: 3,
      comment: '组网进度略滞后，建议优化节点调度。',
      visibility: '节点内公开',
      evalTime: '2026-08-15 13:20:00'
    },
    {
      id: 'BR-006',
      taskId: 'EV-B005',
      taskName: '自立质量审核与缺陷分析',
      evalType: 'mutual',
      evaluatorType: '牵头单位',
      evaluatorName: '陕西节点',
      evaluator: '赵志强',
      targetName: '质量审核作业组',
      anonymous: false,
      star: 4,
      comment: '审核流程规范，缺陷定位准确。',
      visibility: '公开',
      evalTime: '2026-08-15 16:30:00'
    },
    {
      id: 'BR-007',
      taskId: 'EV-B002',
      taskName: '应急灾害响应数据采集',
      evalType: 'mutual',
      evaluatorType: '作业岗位',
      evaluatorName: '数据库运维岗位-刘雪梅',
      evaluator: '刘雪梅',
      targetName: '现场采集岗位-李明华',
      anonymous: true,
      star: 5,
      comment: '应急采集数据完整准确，入库无异常。',
      visibility: '不公开',
      evalTime: '2026-08-15 17:00:00'
    }
  ];
  // 过滤
  let rows = mockRecords;
  if (params?.evalType) rows = rows.filter((r) => r.evalType === params.evalType);
  if (params?.evaluatorType) rows = rows.filter((r) => r.evaluatorType === params.evaluatorType);
  if (params?.taskName) rows = rows.filter((r) => r.taskName.includes(params.taskName));
  if (params?.onlyMine) rows = rows.filter((r) => r.evaluator === '张建国'); // 模拟当前用户为张建国
  return Promise.resolve({ code: 200, data: { total: rows.length, rows: JSON.parse(JSON.stringify(rows)) }, msg: 'ok' });
}

/**
 * 获取参与方可评价对象列表（用于互评选择）
 * 真实接口: GET /task-monitor/eval/biz/targets
 */
export function getBizEvalTargets(taskId?: string): Promise<any> {
  const allTargets = [
    {
      taskId: 'EV-B001',
      taskName: '工程测绘数据自动化处理流程',
      targets: [
        { targetId: 'T01', targetName: '数据处理作业组', targetType: '作业组' },
        { targetId: 'T02', targetName: '陕西节点-测绘局', targetType: '节点单位' },
        { targetId: 'T03', targetName: '陕西节点', targetType: '牵头单位' },
        { targetId: 'T04', targetName: '现场采集岗位-李明华', targetType: '作业岗位' }
      ]
    },
    {
      taskId: 'EV-B002',
      taskName: '应急灾害响应数据采集',
      targets: [
        { targetId: 'T05', targetName: '现场采集岗位-李明华', targetType: '作业岗位' },
        { targetId: 'T06', targetName: '应急保障作业组', targetType: '作业组' },
        { targetId: 'T07', targetName: '陕西节点', targetType: '牵头单位' }
      ]
    },
    {
      taskId: 'EV-B003',
      taskName: '卫星影像自动化配准与组网',
      targets: [
        { targetId: 'T08', targetName: '影像处理作业组', targetType: '作业组' },
        { targetId: 'T09', targetName: '陕西节点-测绘局', targetType: '节点单位' },
        { targetId: 'T10', targetName: '陕西节点', targetType: '牵头单位' }
      ]
    },
    {
      taskId: 'EV-B004',
      taskName: '矢量数据产品生成与分发',
      targets: [
        { targetId: 'T11', targetName: '产品输出作业组', targetType: '作业组' },
        { targetId: 'T12', targetName: '陕西节点', targetType: '牵头单位' }
      ]
    },
    {
      taskId: 'EV-B005',
      taskName: '自立质量审核与缺陷分析',
      targets: [
        { targetId: 'T13', targetName: '质量审核作业组', targetType: '作业组' },
        { targetId: 'T14', targetName: '陕西节点', targetType: '牵头单位' }
      ]
    },
    {
      taskId: 'EV-B006',
      taskName: '地理信息数据库更新维护',
      targets: [
        { targetId: 'T15', targetName: '数据库运维岗位-刘雪梅', targetType: '作业岗位' },
        { targetId: 'T16', targetName: '陕西节点', targetType: '牵头单位' }
      ]
    }
  ];
  const matched = taskId ? allTargets.filter((t) => t.taskId === taskId) : allTargets;
  return Promise.resolve({ code: 200, data: matched, msg: 'ok' });
}

/**
 * 提交业务评价（自评/互评）
 * 真实接口: POST /task-monitor/eval/biz/submit
 * data 包含: taskId, evalType(self|mutual), evaluatorType, evaluatorName, targetName,
 *           star, comment, anonymous, visibility
 */
export function submitBizEval(data: any): Promise<any> {
  console.log('Submitting biz eval:', data);
  return Promise.resolve({
    code: 200,
    data: { id: 'BR-' + Date.now().toString(36) },
    msg: data.evalType === 'mutual' ? '互评提交成功' : '自评提交成功'
  });
}

/**
 * 获取管理评价列表
 * 真实接口: GET /task-monitor/eval/mgr/list
 * 各级任务管理者对下级作业岗位、作业组、节点单位、牵头单位进行评价
 */
export function getMgrEvalList(params?: Record<string, any>): Promise<any> {
  console.log('Fetching mgr eval with params:', params);
  const mockData: any = {
    total: 6,
    rows: [
      {
        id: 'EV-M001',
        taskName: '工程测绘数据自动化处理流程',
        taskType: '计划任务',
        managerType: '节点单位管理者',
        managerName: '陕西节点-测绘局',
        manager: '王芳',
        targetType: '作业组',
        targetName: '数据处理作业组',
        star: 4,
        comment: '数据处理流程规范，进度达标，建议加强控制点复核。',
        evaluator: '王芳',
        evalTime: '2026-08-15 14:00:00',
        status: '已评价',
        visibility: '公开',
        workloadScore: 4,
        efficiencyScore: 4,
        qualityScore: 4,
        complianceScore: 5,
        innovationScore: 3,
        perCapitaWorkload: 41.9,
        overtimeRate: '5.2%'
      },
      {
        id: 'EV-M002',
        taskName: '应急灾害响应数据采集',
        taskType: '应急任务',
        managerType: '牵头单位管理者',
        managerName: '陕西节点',
        manager: '赵志强',
        targetType: '作业岗位',
        targetName: '现场采集岗位-李明华',
        star: 5,
        comment: '应急响应迅速，采集数据完整准确。',
        evaluator: '赵志强',
        evalTime: '2026-08-15 15:00:00',
        status: '已评价',
        visibility: '节点内公开',
        workloadScore: 3,
        efficiencyScore: 3,
        qualityScore: 4,
        complianceScore: 4,
        innovationScore: 4,
        perCapitaWorkload: 28.2,
        overtimeRate: '2.8%'
      },
      {
        id: 'EV-M003',
        taskName: '卫星影像自动化配准与组网',
        taskType: '计划任务',
        managerType: '节点单位管理者',
        managerName: '陕西节点-测绘局',
        manager: '王芳',
        targetType: '节点单位',
        targetName: '影像处理作业组',
        star: 3,
        comment: '组网进度略滞后，建议优化节点调度。',
        evaluator: '王芳',
        evalTime: '2026-08-15 16:30:00',
        status: '已评价',
        visibility: '公开',
        workloadScore: 5,
        efficiencyScore: 4,
        qualityScore: 3,
        complianceScore: 4,
        innovationScore: 2,
        perCapitaWorkload: 52.6,
        overtimeRate: '8.5%'
      },
      {
        id: 'EV-M004',
        taskName: '矢量数据产品生成与分发',
        taskType: '计划任务',
        managerType: '牵头单位管理者',
        managerName: '陕西节点',
        manager: '赵志强',
        targetType: '牵头单位',
        targetName: '产品输出作业组',
        star: 5,
        comment: '产品分发零缺陷，各环节协同高效。',
        evaluator: '赵志强',
        evalTime: '2026-08-14 16:00:00',
        status: '已评价',
        visibility: '公开',
        workloadScore: 5,
        efficiencyScore: 5,
        qualityScore: 5,
        complianceScore: 5,
        innovationScore: 4,
        perCapitaWorkload: 16.0,
        overtimeRate: '0%'
      },
      {
        id: 'EV-M005',
        taskName: '自立质量审核与缺陷分析',
        taskType: '自立任务',
        managerType: '作业组管理者',
        managerName: '质量审核作业组',
        manager: '陈卫国',
        targetType: '作业组',
        targetName: '质量审核作业组',
        star: 4,
        comment: '审核流程规范，缺陷定位准确。',
        evaluator: '陈卫国',
        evalTime: '2026-08-15 17:00:00',
        status: '已评价',
        visibility: '节点内公开',
        workloadScore: 4,
        efficiencyScore: 4,
        qualityScore: 4,
        complianceScore: 4,
        innovationScore: 3,
        perCapitaWorkload: 33.5,
        overtimeRate: '3.1%'
      },
      {
        id: 'EV-M006',
        taskName: '地理信息数据库更新维护',
        taskType: '计划任务',
        managerType: '',
        managerName: '',
        manager: '',
        targetType: '',
        targetName: '',
        star: 0,
        comment: '',
        evaluator: '',
        evalTime: '',
        status: '待评价',
        visibility: '',
        workloadScore: 0,
        efficiencyScore: 0,
        qualityScore: 0,
        complianceScore: 0,
        innovationScore: 0,
        perCapitaWorkload: 0,
        overtimeRate: '--'
      }
    ]
  };

  return Promise.resolve({ code: 200, data: mockData, msg: 'ok' });
}

/**
 * 提交管理评价
 * 真实接口: POST /task-monitor/eval/mgr/submit
 * data 包含: taskId, taskName, managerType, managerName, targetName, targetType,
 *           star, comment, visibility
 */
export function submitMgrEval(data: any): Promise<any> {
  console.log('Submitting mgr eval:', data);
  return Promise.resolve({ code: 200, data: { id: 'MR-' + Date.now().toString(36) }, msg: '管理评价提交成功' });
}

/**
 * 获取管理评价记录列表
 * 真实接口: GET /task-monitor/eval/mgr/records
 */
export function getMgrEvalRecords(params?: Record<string, any>): Promise<any> {
  console.log('Fetching mgr eval records with params:', params);
  const mockRecords: any[] = [
    {
      id: 'MR-001',
      taskId: 'EV-B001',
      taskName: '工程测绘数据自动化处理流程',
      managerType: '节点单位管理者',
      managerName: '陕西节点-测绘局',
      manager: '王芳',
      targetType: '作业组',
      targetName: '数据处理作业组',
      star: 4,
      comment: '数据处理流程规范，进度达标，建议加强控制点复核。',
      visibility: '公开',
      evalTime: '2026-08-15 14:00:00'
    },
    {
      id: 'MR-002',
      taskId: 'EV-B002',
      taskName: '应急灾害响应数据采集',
      managerType: '牵头单位管理者',
      managerName: '陕西节点',
      manager: '赵志强',
      targetType: '作业岗位',
      targetName: '现场采集岗位-李明华',
      star: 5,
      comment: '应急响应迅速，采集数据完整准确。',
      visibility: '节点内公开',
      evalTime: '2026-08-15 15:00:00'
    },
    {
      id: 'MR-003',
      taskId: 'EV-B003',
      taskName: '卫星影像自动化配准与组网',
      managerType: '节点单位管理者',
      managerName: '陕西节点-测绘局',
      manager: '王芳',
      targetType: '节点单位',
      targetName: '影像处理作业组',
      star: 3,
      comment: '组网进度略滞后，建议优化节点调度。',
      visibility: '公开',
      evalTime: '2026-08-15 16:30:00'
    },
    {
      id: 'MR-004',
      taskId: 'EV-B004',
      taskName: '矢量数据产品生成与分发',
      managerType: '牵头单位管理者',
      managerName: '陕西节点',
      manager: '赵志强',
      targetType: '牵头单位',
      targetName: '产品输出作业组',
      star: 5,
      comment: '产品分发零缺陷，各环节协同高效。',
      visibility: '公开',
      evalTime: '2026-08-14 16:00:00'
    },
    {
      id: 'MR-005',
      taskId: 'EV-B005',
      taskName: '自立质量审核与缺陷分析',
      managerType: '作业组管理者',
      managerName: '质量审核作业组',
      manager: '陈卫国',
      targetType: '作业组',
      targetName: '质量审核作业组',
      star: 4,
      comment: '审核流程规范，缺陷定位准确。',
      visibility: '节点内公开',
      evalTime: '2026-08-15 17:00:00'
    }
  ];
  let rows = mockRecords;
  if (params?.managerType) rows = rows.filter((r) => r.managerType === params.managerType);
  if (params?.targetType) rows = rows.filter((r) => r.targetType === params.targetType);
  if (params?.taskName) rows = rows.filter((r) => r.taskName.includes(params.taskName));
  if (params?.onlyMine) rows = rows.filter((r) => r.manager === '张建国');
  return Promise.resolve({ code: 200, data: { total: rows.length, rows: JSON.parse(JSON.stringify(rows)) }, msg: 'ok' });
}

/**
 * 获取管理评价下级评价对象列表
 * 真实接口: GET /task-monitor/eval/mgr/targets
 */
export function getMgrEvalTargets(taskId?: string): Promise<any> {
  const allTargets = [
    {
      taskId: 'EV-B001',
      taskName: '工程测绘数据自动化处理流程',
      targets: [
        { targetId: 'MT01', targetName: '数据处理作业组', targetType: '作业组' },
        { targetId: 'MT02', targetName: '陕西节点-测绘局', targetType: '节点单位' },
        { targetId: 'MT03', targetName: '陕西节点', targetType: '牵头单位' },
        { targetId: 'MT04', targetName: '现场采集岗位-李明华', targetType: '作业岗位' }
      ]
    },
    {
      taskId: 'EV-B002',
      taskName: '应急灾害响应数据采集',
      targets: [
        { targetId: 'MT05', targetName: '现场采集岗位-李明华', targetType: '作业岗位' },
        { targetId: 'MT06', targetName: '应急保障作业组', targetType: '作业组' },
        { targetId: 'MT07', targetName: '陕西节点', targetType: '牵头单位' }
      ]
    },
    {
      taskId: 'EV-B003',
      taskName: '卫星影像自动化配准与组网',
      targets: [
        { targetId: 'MT08', targetName: '影像处理作业组', targetType: '作业组' },
        { targetId: 'MT09', targetName: '陕西节点-测绘局', targetType: '节点单位' },
        { targetId: 'MT10', targetName: '陕西节点', targetType: '牵头单位' }
      ]
    },
    {
      taskId: 'EV-B004',
      taskName: '矢量数据产品生成与分发',
      targets: [
        { targetId: 'MT11', targetName: '产品输出作业组', targetType: '作业组' },
        { targetId: 'MT12', targetName: '陕西节点', targetType: '牵头单位' }
      ]
    },
    {
      taskId: 'EV-B005',
      taskName: '自立质量审核与缺陷分析',
      targets: [
        { targetId: 'MT13', targetName: '质量审核作业组', targetType: '作业组' },
        { targetId: 'MT14', targetName: '陕西节点', targetType: '牵头单位' }
      ]
    },
    {
      taskId: 'EV-B006',
      taskName: '地理信息数据库更新维护',
      targets: [
        { targetId: 'MT15', targetName: '数据库运维岗位-刘雪梅', targetType: '作业岗位' },
        { targetId: 'MT16', targetName: '陕西节点', targetType: '牵头单位' }
      ]
    }
  ];
  const matched = taskId ? allTargets.filter((t) => t.taskId === taskId) : allTargets;
  return Promise.resolve({ code: 200, data: matched, msg: 'ok' });
}

/**
 * 获取业务环节评价列表（自动抽取生成）
 * 真实接口: GET /task-monitor/eval/process/list
 * 业务环节：智能提取、属性挖掘、人机协同、矢量组网、数据预处理
 */
export function getProcessEvalList(params?: Record<string, any>): Promise<any> {
  console.log('Fetching process eval with params:', params);
  const mockData: any = {
    total: 6,
    rows: [
      {
        id: 'EP-001',
        taskName: '工程测绘数据自动化处理流程',
        processName: '智能提取',
        processType: '核心处理',
        dataSource: '任务管理调度子系统+基础地理信息框架数据管理分系统+业务系统运行日志',
        timelinessScore: 5,
        qualityScore: 4,
        collaborationScore: 4,
        avgScore: 4.33,
        autoGenerated: true,
        visibility: '公开',
        evaluator: '系统自动生成',
        evalTime: '2026-08-15 09:00:00'
      },
      {
        id: 'EP-002',
        taskName: '工程测绘数据自动化处理流程',
        processName: '属性挖掘',
        processType: '核心处理',
        dataSource: '任务管理调度子系统+基础地理信息框架数据管理分系统+业务系统运行日志',
        timelinessScore: 4,
        qualityScore: 5,
        collaborationScore: 3,
        avgScore: 4.0,
        autoGenerated: true,
        visibility: '节点内公开',
        evaluator: '系统自动生成',
        evalTime: '2026-08-15 09:30:00'
      },
      {
        id: 'EP-003',
        taskName: '应急灾害响应数据采集',
        processName: '人机协同',
        processType: '交互处理',
        dataSource: '任务管理调度子系统+业务系统运行日志',
        timelinessScore: 3,
        qualityScore: 4,
        collaborationScore: 4,
        avgScore: 3.67,
        autoGenerated: true,
        visibility: '公开',
        evaluator: '系统自动生成',
        evalTime: '2026-08-15 10:00:00'
      },
      {
        id: 'EP-004',
        taskName: '卫星影像自动化配准与组网',
        processName: '矢量组网',
        processType: '核心处理',
        dataSource: '任务管理调度子系统+基础地理信息框架数据管理分系统+业务系统运行日志',
        timelinessScore: 4,
        qualityScore: 3,
        collaborationScore: 5,
        avgScore: 4.0,
        autoGenerated: true,
        visibility: '公开',
        evaluator: '系统自动生成',
        evalTime: '2026-08-15 10:30:00'
      },
      {
        id: 'EP-005',
        taskName: '矢量数据产品生成与分发',
        processName: '数据预处理',
        processType: '数据准备',
        dataSource: '任务管理调度子系统+基础地理信息框架数据管理分系统',
        timelinessScore: 5,
        qualityScore: 5,
        collaborationScore: 4,
        avgScore: 4.67,
        autoGenerated: true,
        visibility: '公开',
        evaluator: '系统自动生成',
        evalTime: '2026-08-15 11:00:00'
      },
      {
        id: 'EP-006',
        taskName: '自立质量审核与缺陷分析',
        processName: '智能提取',
        processType: '核心处理',
        dataSource: '任务管理调度子系统+业务系统运行日志',
        timelinessScore: 4,
        qualityScore: 4,
        collaborationScore: 4,
        avgScore: 4.0,
        autoGenerated: true,
        visibility: '节点内公开',
        evaluator: '系统自动生成',
        evalTime: '2026-08-15 11:30:00'
      }
    ]
  };

  return Promise.resolve({ code: 200, data: mockData, msg: 'ok' });
}

/**
 * 获取业务环节评价详情（自动抽取的指标明细）
 * 真实接口: GET /task-monitor/eval/process/detail/{id}
 * 返回该环节自动抽取的评价因子/指标明细
 */
export function getProcessEvalDetail(id: string): Promise<any> {
  console.log('Fetching process eval detail for id:', id);
  const detailMap: Record<string, any> = {
    'EP-001': {
      factors: [
        { name: '环节处理时长', value: '4.2h', source: '任务管理调度子系统', dimension: '时效' },
        { name: '处理及时率', value: '95%', source: '任务管理调度子系统', dimension: '时效' },
        { name: '智能识别准确率', value: '92.5%', source: '业务系统运行日志', dimension: '质量' },
        { name: '成果质检合格率', value: '94.8%', source: '基础地理信息框架数据管理分系统', dimension: '质量' },
        { name: '上下游环节衔接度', value: '88%', source: '任务管理调度子系统', dimension: '协作' },
        { name: '节点间数据交换成功率', value: '99.2%', source: '业务系统运行日志', dimension: '协作' }
      ],
      model: '时效×35% + 质量×40% + 协作×25% （自动抽取）'
    },
    'EP-002': {
      factors: [
        { name: '挖掘耗时', value: '6.8h', source: '任务管理调度子系统', dimension: '时效' },
        { name: '挖掘字段覆盖率', value: '91%', source: '业务系统运行日志', dimension: '质量' },
        { name: '属性值准确率', value: '96.4%', source: '基础地理信息框架数据管理分系统', dimension: '质量' },
        { name: '与上游数据匹配度', value: '90%', source: '任务管理调度子系统', dimension: '协作' }
      ],
      model: '时效×35% + 质量×40% + 协作×25% （自动抽取）'
    },
    'EP-003': {
      factors: [
        { name: '人机协同响应时长', value: '12min', source: '业务系统运行日志', dimension: '时效' },
        { name: '人工干预占比', value: '28%', source: '业务系统运行日志', dimension: '时效' },
        { name: '协同成果合格率', value: '93%', source: '基础地理信息框架数据管理分系统', dimension: '质量' },
        { name: '协同节点数', value: '5', source: '任务管理调度子系统', dimension: '协作' }
      ],
      model: '时效×35% + 质量×40% + 协作×25% （自动抽取）'
    },
    'EP-004': {
      factors: [
        { name: '组网耗时', value: '8.5h', source: '任务管理调度子系统', dimension: '时效' },
        { name: '拓扑正确率', value: '98.6%', source: '基础地理信息框架数据管理分系统', dimension: '质量' },
        { name: '节点连通率', value: '96.2%', source: '业务系统运行日志', dimension: '协作' },
        { name: '上下游衔接度', value: '92%', source: '任务管理调度子系统', dimension: '协作' }
      ],
      model: '时效×35% + 质量×40% + 协作×25% （自动抽取）'
    },
    'EP-005': {
      factors: [
        { name: '预处理耗时', value: '2.1h', source: '任务管理调度子系统', dimension: '时效' },
        { name: '数据清洗合格率', value: '99.1%', source: '基础地理信息框架数据管理分系统', dimension: '质量' },
        { name: '格式转换成功率', value: '100%', source: '业务系统运行日志', dimension: '质量' },
        { name: '与下游环节衔接度', value: '95%', source: '任务管理调度子系统', dimension: '协作' }
      ],
      model: '时效×35% + 质量×40% + 协作×25% （自动抽取）'
    },
    'EP-006': {
      factors: [
        { name: '提取处理时长', value: '5.5h', source: '任务管理调度子系统', dimension: '时效' },
        { name: '识别准确率', value: '90.2%', source: '业务系统运行日志', dimension: '质量' },
        { name: '质检合格率', value: '92%', source: '基础地理信息框架数据管理分系统', dimension: '质量' },
        { name: '节点衔接度', value: '85%', source: '任务管理调度子系统', dimension: '协作' }
      ],
      model: '时效×35% + 质量×40% + 协作×25% （自动抽取）'
    }
  };
  const data = detailMap[id] || { factors: [], model: '时效×35% + 质量×40% + 协作×25% （自动抽取）' };
  return Promise.resolve({ code: 200, data, msg: 'ok' });
}

/**
 * 获取任务综合评价（自动生成，任务全过程）
 * 真实接口: GET /task-monitor/eval/comprehensive/{taskId}
 * 任务全过程：任务接收审批、任务分解、资源配置、任务执行、成果提交
 */
export function getComprehensiveEval(taskId: string): Promise<any> {
  console.log('Fetching comprehensive eval for task:', taskId);
  const mockData: any = {
    taskName: '工程测绘数据自动化处理流程',
    dataSource: '任务管理调度子系统+基础地理信息框架数据管理分系统+业务系统运行日志',
    autoGenerated: true,
    visibility: '公开',
    compositeScore: 87.8,
    grade: '良好',
    phases: [
      {
        phase: '任务接收审批',
        score: 92,
        weight: 15,
        indicators: [
          { name: '接收及时率', value: 100, source: '任务管理调度子系统' },
          { name: '审批通过率', value: 95, source: '任务管理调度子系统' }
        ]
      },
      {
        phase: '任务分解',
        score: 88,
        weight: 20,
        indicators: [
          { name: '分解完整度', value: 92, source: '任务管理调度子系统' },
          { name: '子任务覆盖', value: 85, source: '任务管理调度子系统' }
        ]
      },
      {
        phase: '资源配置',
        score: 85,
        weight: 20,
        indicators: [
          { name: '资源到位率', value: 90, source: '任务管理调度子系统' },
          { name: '配置准确率', value: 80, source: '基础地理信息框架数据管理分系统' }
        ]
      },
      {
        phase: '任务执行',
        score: 86,
        weight: 30,
        indicators: [
          { name: '进度完成率', value: 88, source: '任务管理调度子系统' },
          { name: '执行合格率', value: 92.5, source: '基础地理信息框架数据管理分系统' },
          { name: '系统运行稳定率', value: 99.2, source: '业务系统运行日志' }
        ]
      },
      {
        phase: '成果提交',
        score: 90,
        weight: 15,
        indicators: [
          { name: '成果完整率', value: 95, source: '基础地理信息框架数据管理分系统' },
          { name: '成果合格率', value: 96.8, source: '基础地理信息框架数据管理分系统' }
        ]
      }
    ],
    trend: [
      { time: '2026-08-09', score: 82.1 },
      { time: '2026-08-10', score: 83.4 },
      { time: '2026-08-11', score: 85.0 },
      { time: '2026-08-12', score: 84.7 },
      { time: '2026-08-13', score: 86.2 },
      { time: '2026-08-14', score: 87.1 },
      { time: '2026-08-15', score: 87.8 }
    ]
  };

  return Promise.resolve({ code: 200, data: mockData, msg: 'ok' });
}

/**
 * 获取综合评价列表
 * 真实接口: GET /task-monitor/eval/comprehensive/list
 */
export function getComprehensiveEvalList(params?: Record<string, any>): Promise<any> {
  console.log('Fetching comprehensive eval list with params:', params);
  const mockData: any = {
    total: 5,
    rows: [
      {
        id: 'CE-001',
        taskName: '工程测绘数据自动化处理流程',
        taskType: '计划任务',
        compositeScore: 87.8,
        grade: '良好',
        visibility: '公开',
        autoGenerated: true,
        evalTime: '2026-08-15 12:00:00'
      },
      {
        id: 'CE-002',
        taskName: '应急灾害响应数据采集',
        taskType: '应急任务',
        compositeScore: 82.5,
        grade: '良好',
        visibility: '节点内公开',
        autoGenerated: true,
        evalTime: '2026-08-15 12:30:00'
      },
      {
        id: 'CE-003',
        taskName: '卫星影像自动化配准与组网',
        taskType: '计划任务',
        compositeScore: 81.2,
        grade: '良好',
        visibility: '公开',
        autoGenerated: true,
        evalTime: '2026-08-15 13:00:00'
      },
      {
        id: 'CE-004',
        taskName: '矢量数据产品生成与分发',
        taskType: '计划任务',
        compositeScore: 96.3,
        grade: '优秀',
        visibility: '公开',
        autoGenerated: true,
        evalTime: '2026-08-14 17:00:00'
      },
      {
        id: 'CE-005',
        taskName: '自立质量审核与缺陷分析',
        taskType: '自立任务',
        compositeScore: 76.5,
        grade: '良好',
        visibility: '节点内公开',
        autoGenerated: true,
        evalTime: '2026-08-15 17:30:00'
      }
    ]
  };
  return Promise.resolve({ code: 200, data: mockData, msg: 'ok' });
}

/**
 * 获取评价数据查询列表（综合查询）
 * 真实接口: GET /task-monitor/eval/query/list
 * 查询条件：任务名称、评价类型、评价者
 */
export function getEvalQueryList(params?: Record<string, any>): Promise<any> {
  console.log('Fetching eval query with params:', params);
  const allRows: any[] = [
    // 业务用户评价
    {
      id: 'EQ-B001',
      taskName: '工程测绘数据自动化处理流程',
      taskType: '计划任务',
      evalType: '业务用户评价',
      evalSubType: '自评',
      evaluator: '张建国',
      targetName: '数据处理作业组（自评）',
      anonymous: false,
      star: 4,
      score: 80,
      comment: '本组工作完成度较好。',
      visibility: '公开',
      evalTime: '2026-08-15 10:30:00'
    },
    {
      id: 'EQ-B002',
      taskName: '应急灾害响应数据采集',
      taskType: '应急任务',
      evalType: '业务用户评价',
      evalSubType: '互评',
      evaluator: '王芳',
      targetName: '现场采集作业组',
      anonymous: true,
      star: 4,
      score: 80,
      comment: '应急响应及时，数据完整。',
      visibility: '节点内公开',
      evalTime: '2026-08-15 11:00:00'
    },
    // 管理用户评价
    {
      id: 'EQ-M001',
      taskName: '工程测绘数据自动化处理流程',
      taskType: '计划任务',
      evalType: '管理用户评价',
      evalSubType: '管理评价',
      evaluator: '赵志强',
      targetName: '数据处理作业组',
      anonymous: false,
      star: 4,
      score: 80,
      comment: '处理流程规范，建议加强控制点复核。',
      visibility: '公开',
      evalTime: '2026-08-15 14:00:00'
    },
    {
      id: 'EQ-M002',
      taskName: '矢量数据产品生成与分发',
      taskType: '计划任务',
      evalType: '管理用户评价',
      evalSubType: '管理评价',
      evaluator: '赵志强',
      targetName: '矢量数据分发作业组',
      anonymous: false,
      star: 5,
      score: 100,
      comment: '产品分发零缺陷。',
      visibility: '公开',
      evalTime: '2026-08-14 16:00:00'
    },
    // 业务环节评价
    {
      id: 'EQ-P001',
      taskName: '工程测绘数据自动化处理流程',
      taskType: '计划任务',
      evalType: '业务环节评价',
      evalSubType: '智能提取',
      evaluator: '系统自动生成',
      star: 4,
      score: 86.7,
      comment: '时效5/质量4/协作4',
      visibility: '公开',
      evalTime: '2026-08-15 09:00:00'
    },
    {
      id: 'EQ-P002',
      taskName: '卫星影像自动化配准与组网',
      taskType: '计划任务',
      evalType: '业务环节评价',
      evalSubType: '矢量组网',
      evaluator: '系统自动生成',
      star: 4,
      score: 80,
      comment: '时效4/质量3/协作5',
      visibility: '公开',
      evalTime: '2026-08-15 10:30:00'
    },
    // 任务综合评价
    {
      id: 'EQ-C001',
      taskName: '工程测绘数据自动化处理流程',
      taskType: '计划任务',
      evalType: '任务综合评价',
      evalSubType: '全过程',
      evaluator: '系统自动生成',
      star: 5,
      score: 87.8,
      comment: '接收92/分解88/配置85/执行86/提交90',
      visibility: '公开',
      evalTime: '2026-08-15 12:00:00'
    },
    {
      id: 'EQ-C002',
      taskName: '矢量数据产品生成与分发',
      taskType: '计划任务',
      evalType: '任务综合评价',
      evalSubType: '全过程',
      evaluator: '系统自动生成',
      star: 5,
      score: 96.3,
      comment: '接收95/分解92/配置90/执行98/提交95',
      visibility: '公开',
      evalTime: '2026-08-14 17:00:00'
    }
  ];
  let rows = allRows;
  if (params?.taskName) rows = rows.filter((r) => r.taskName.includes(params.taskName));
  if (params?.evalType) rows = rows.filter((r) => r.evalType === params.evalType);
  if (params?.evaluator) rows = rows.filter((r) => r.evaluator.includes(params.evaluator));
  return Promise.resolve({ code: 200, data: { total: rows.length, rows: JSON.parse(JSON.stringify(rows)) }, msg: 'ok' });
}

/**
 * 导出评价数据统计报表
 * 真实接口: POST /task-monitor/eval/query/export
 * 格式：Word、WPS、PDF、HTML
 */
export function exportEvalData(data: any): Promise<any> {
  console.log('Exporting eval data:', data);
  return Promise.resolve({ code: 200, data: { url: '/download/eval-report-' + Date.now() + '.' + (data.format || 'pdf') }, msg: '导出成功' });
}

/* ================================================================
 *  ECharts Chart Data - 任务评价
 * ================================================================ */

/**
 * 获取综合评价雷达图数据
 * 真实接口: GET /task-monitor/eval/chart/radar
 */
export function getEvalRadarData(): Promise<any> {
  const mockData = {
    indicators: [
      { name: '进度完成率', max: 100 },
      { name: '质量达标率', max: 100 },
      { name: '时效性', max: 100 },
      { name: '协作能力', max: 100 },
      { name: '合规性', max: 100 },
      { name: '创新性', max: 100 }
    ],
    data: [
      { name: '当前任务', value: 87.8 },
      { name: '团队均值', value: 76.3 },
      { name: '部门目标', value: 85.0 }
    ]
  };

  return Promise.resolve({ code: 200, data: mockData, msg: 'ok' });
}

/* ================================================================
 *  任务统计 (Task Statistics)
 * ================================================================ */

/**
 * 报告模板 Mock 存储
 * - reportType: 任务工作量/任务作业率/任务质量/任务评价/任务综合分析
 * - dsl: tmagic-editor 生成的页面布局 DSL (MApp)
 */
const mockReportTemplateStore: any[] = [
  {
    id: 'rt1',
    name: '月度任务工作量统计模板',
    reportType: '任务工作量',
    description: '适用于月度任务工作量统计汇报，涵盖任务完成数、完成率、人均工作量、工时统计等关键指标。',
    indicators: ['task_total', 'task_done', 'task_rate', 'workload_rate'],
    dsl: {
      type: 'app',
      id: 1,
      page: 1,
      items: [
        {
          type: 'page',
          id: 2,
          name: '工作量报告',
          title: '任务工作量统计',
          style: { width: '820px', minHeight: '1100px', display: 'block', padding: '40px 32px', background: '#ffffff', boxSizing: 'border-box' },
          items: [
            {
              type: 'text',
              id: 11,
              text: '任务工作量月度统计',
              textAlign: 'center',
              field: 'task_total',
              order: 'first',
              sortBy: 'default',
              fontSize: 18,
              fontColor: '#303133',
              bgColor: '#ffffff',
              title: '报告标题'
            },
            {
              type: 'chart',
              id: 12,
              title: '任务完成量趋势',
              field: 'trend',
              order: 'default',
              sortBy: 'default',
              fontSize: 14,
              fontColor: '#409eff',
              bgColor: '#ffffff'
            },
            {
              type: 'table',
              id: 13,
              title: '任务明细',
              field: 'task_list',
              order: 'default',
              sortBy: 'default',
              fontSize: 14,
              fontColor: '#303133',
              bgColor: '#ffffff'
            }
          ]
        }
      ]
    },
    creator: '当前用户',
    createTime: '2026-06-01 08:00:00',
    updateTime: '2026-07-01 08:00:00'
  },
  {
    id: 'rt2',
    name: '季度任务作业率分析模板',
    reportType: '任务作业率',
    description: '季度任务作业率分析报告模板，包含计划/实际作业率对比、效率评分与瓶颈分析。',
    indicators: ['workload_rate', 'task_done', 'task_rate'],
    dsl: {
      type: 'app',
      id: 1,
      page: 1,
      items: [
        {
          type: 'page',
          id: 2,
          name: '作业率报告',
          title: '任务作业率分析',
          style: { width: '820px', minHeight: '1100px', display: 'block', padding: '40px 32px', background: '#ffffff', boxSizing: 'border-box' },
          items: [
            {
              type: 'chart',
              id: 21,
              title: '作业率趋势',
              field: 'load',
              order: 'first',
              sortBy: 'desc',
              fontSize: 14,
              fontColor: '#409eff',
              bgColor: '#ffffff'
            },
            {
              type: 'table',
              id: 22,
              title: '执行节点作业率',
              field: 'task_list',
              order: 'default',
              sortBy: 'default',
              fontSize: 14,
              fontColor: '#303133',
              bgColor: '#ffffff'
            }
          ]
        }
      ]
    },
    creator: '当前用户',
    createTime: '2026-04-01 08:00:00',
    updateTime: '2026-07-01 08:00:00'
  },
  {
    id: 'rt3',
    name: '任务质量专题分析模板',
    reportType: '任务质量',
    description: '任务质量专题分析报告模板，包含数据/代码/成果质量雷达图与缺陷分布。',
    indicators: ['quality_rate', 'task_alert'],
    dsl: {
      type: 'app',
      id: 1,
      page: 1,
      items: [
        {
          type: 'page',
          id: 2,
          name: '质量报告',
          title: '任务质量分析',
          style: { width: '820px', minHeight: '1100px', display: 'block', padding: '40px 32px', background: '#ffffff', boxSizing: 'border-box' },
          items: [
            {
              type: 'text',
              id: 31,
              text: '任务质量专题分析报告',
              textAlign: 'center',
              field: 'quality_rate',
              order: 'first',
              sortBy: 'default',
              fontSize: 18,
              fontColor: '#303133',
              bgColor: '#ffffff',
              title: ''
            },
            {
              type: 'chart',
              id: 32,
              title: '质量指标雷达图',
              field: 'radar',
              order: 'default',
              sortBy: 'default',
              fontSize: 14,
              fontColor: '#f56c6c',
              bgColor: '#ffffff'
            }
          ]
        }
      ]
    },
    creator: '当前用户',
    createTime: '2026-05-20 10:00:00',
    updateTime: '2026-07-15 09:00:00'
  },
  {
    id: 'rt4',
    name: '任务评价综合报告模板',
    reportType: '任务评价',
    description: '任务评价综合报告模板，涵盖业务/管理/专家多维度评分与综合得分。',
    indicators: ['eval_star', 'composite_score'],
    dsl: {
      type: 'app',
      id: 1,
      page: 1,
      items: [
        {
          type: 'page',
          id: 2,
          name: '评价报告',
          title: '任务评价统计',
          style: { width: '820px', minHeight: '1100px', display: 'block', padding: '40px 32px', background: '#ffffff', boxSizing: 'border-box' },
          items: [
            {
              type: 'chart',
              id: 41,
              title: '评价等级分布',
              field: 'pie',
              order: 'first',
              sortBy: 'default',
              fontSize: 14,
              fontColor: '#67c23a',
              bgColor: '#ffffff'
            },
            {
              type: 'table',
              id: 42,
              title: '任务评价明细',
              field: 'task_list',
              order: 'default',
              sortBy: 'default',
              fontSize: 14,
              fontColor: '#303133',
              bgColor: '#ffffff'
            }
          ]
        }
      ]
    },
    creator: '当前用户',
    createTime: '2026-06-10 14:00:00',
    updateTime: '2026-06-20 10:00:00'
  },
  {
    id: 'rt5',
    name: '任务综合分析报告模板',
    reportType: '任务综合分析',
    description: '任务综合分析报告模板，覆盖工作量、作业率、质量、评价多维分析矩阵与达成率。',
    indicators: ['composite_score', 'task_rate', 'quality_rate', 'eval_star'],
    dsl: {
      type: 'app',
      id: 1,
      page: 1,
      items: [
        {
          type: 'page',
          id: 2,
          name: '综合分析报告',
          title: '任务综合分析',
          style: { width: '820px', minHeight: '1100px', display: 'block', padding: '40px 32px', background: '#ffffff', boxSizing: 'border-box' },
          items: [
            {
              type: 'text',
              id: 51,
              text: '任务综合分析报告',
              textAlign: 'center',
              field: 'composite_score',
              order: 'first',
              sortBy: 'default',
              fontSize: 18,
              fontColor: '#303133',
              bgColor: '#ffffff',
              title: ''
            },
            {
              type: 'chart',
              id: 52,
              title: '多维综合分析矩阵',
              field: 'bar',
              order: 'default',
              sortBy: 'desc',
              fontSize: 14,
              fontColor: '#409eff',
              bgColor: '#ffffff'
            },
            {
              type: 'control',
              id: 53,
              title: '分析维度选择',
              field: 'select',
              order: 'default',
              sortBy: 'default',
              fontSize: 14,
              fontColor: '#303133',
              bgColor: '#ffffff'
            }
          ]
        }
      ]
    },
    creator: '当前用户',
    createTime: '2026-01-01 08:00:00',
    updateTime: '2026-06-15 14:00:00'
  }
];

/**
 * 获取报告模板列表
 * 真实接口: GET /task-monitor/stat/template/list
 * @param params.reportType 报告类型（任务工作量/任务作业率/任务质量/任务评价/任务综合分析）
 * @param params.keyword 模板名称关键字
 */
export function getReportTemplateList(params?: { reportType?: string; keyword?: string }): Promise<any> {
  let rows = [...mockReportTemplateStore];
  if (params?.reportType) {
    rows = rows.filter((r) => r.reportType === params.reportType);
  }
  if (params?.keyword) {
    const kw = String(params.keyword).trim();
    rows = rows.filter((r) => r.name?.includes(kw));
  }
  return Promise.resolve({ code: 200, data: rows, msg: 'ok' });
}

/**
 * 获取统计报告模板详情（基于 mockReportTemplateStore）
 * 真实接口: GET /task-monitor/stat/template/{id}
 * 注：与早期的 getReportTemplateDetail（基于 mockReportTemplates）用途不同
 */
export function getStatReportTemplateDetail(id: string): Promise<any> {
  const tpl = mockReportTemplateStore.find((t) => t.id === id);
  return Promise.resolve({ code: 200, data: tpl || null, msg: tpl ? 'ok' : '未找到模板' });
}

/**
 * 创建报告模板
 * 真实接口: POST /task-monitor/stat/template/create
 * @param data.name 模板名称
 * @param data.reportType 报告类型（任务工作量/任务作业率/任务质量/任务评价/任务综合分析）
 * @param data.description 模板说明
 * @param data.indicators 包含指标列表
 * @param data.dsl tmagic-editor 生成的页面布局 DSL（MApp）
 */
export function createReportTemplate(data: any): Promise<any> {
  const now = new Date().toLocaleString('zh-CN');
  const newId = 'rt' + Date.now();
  const tpl: any = {
    id: newId,
    name: data.name || '新建模板',
    reportType: data.reportType || '任务工作量',
    description: data.description || '',
    indicators: data.indicators || [],
    dsl: data.dsl || null,
    creator: '当前用户',
    createTime: now,
    updateTime: now
  };
  mockReportTemplateStore.push(tpl);
  return Promise.resolve({ code: 200, data: tpl, msg: '模板创建成功' });
}

/**
 * 更新报告模板
 * 真实接口: PUT /task-monitor/stat/template/update
 * @param data.id 模板ID
 * @param data.name 模板名称
 * @param data.reportType 报告类型
 * @param data.description 模板说明
 * @param data.indicators 包含指标列表
 * @param data.dsl 页面布局 DSL
 */
export function updateReportTemplate(data: any): Promise<any> {
  const idx = mockReportTemplateStore.findIndex((t) => t.id === data.id);
  if (idx >= 0) {
    const now = new Date().toLocaleString('zh-CN');
    mockReportTemplateStore[idx] = {
      ...mockReportTemplateStore[idx],
      ...data,
      id: mockReportTemplateStore[idx].id,
      updateTime: now
    };
    return Promise.resolve({ code: 200, data: mockReportTemplateStore[idx], msg: '模板更新成功' });
  }
  return Promise.resolve({ code: 404, data: null, msg: '未找到模板' });
}

/**
 * 删除报告模板
 * 真实接口: DELETE /task-monitor/stat/template/{id}
 */
export function deleteReportTemplate(id: string): Promise<any> {
  const idx = mockReportTemplateStore.findIndex((t) => t.id === id);
  if (idx >= 0) mockReportTemplateStore.splice(idx, 1);
  return Promise.resolve({ code: 200, data: null, msg: '模板删除成功' });
}

/**
 * 获取工作量统计数据
 * 真实接口: GET /task-monitor/stat/workload
 */
export function getWorkloadData(params?: Record<string, any>): Promise<any> {
  console.log('Fetching workload data with params:', params);
  const mockData = {
    table: [
      {
        period: '2026年第28周 (7.6-7.12)',
        totalTasks: 48,
        completedTasks: 45,
        completionRate: 93.75,
        totalWorkHours: 1680,
        avgWorkHours: 35,
        overtimeRate: 5.2,
        perCapitaWorkload: '12 件/人'
      },
      {
        period: '2026年第29周 (7.13-7.19)',
        totalTasks: 52,
        completedTasks: 49,
        completionRate: 94.23,
        totalWorkHours: 1760,
        avgWorkHours: 36.7,
        overtimeRate: 6.8,
        perCapitaWorkload: '13 件/人'
      },
      {
        period: '2026年第30周 (7.20-7.26)',
        totalTasks: 45,
        completedTasks: 42,
        completionRate: 93.33,
        totalWorkHours: 1600,
        avgWorkHours: 35.6,
        overtimeRate: 4.5,
        perCapitaWorkload: '11.3 件/人'
      },
      {
        period: '2026年第31周 (7.27-8.2)',
        totalTasks: 50,
        completedTasks: 35,
        completionRate: 70.0,
        totalWorkHours: 1700,
        avgWorkHours: 34,
        overtimeRate: 3.1,
        perCapitaWorkload: '12.5 件/人(预估)'
      }
    ],
    chart: {
      categories: ['第27周', '第28周', '第29周', '第30周', '第31周', '第32周(预估)'],
      totalTasks: [42, 48, 52, 45, 50, 46],
      completedTasks: [40, 45, 49, 42, 35, 0],
      workHours: [1520, 1680, 1760, 1600, 1700, 1650],
      distributionData: [
        { value: 35, name: '数据核验' },
        { value: 28, name: '统计分析' },
        { value: 52, name: '流程作业' },
        { value: 20, name: '报表生成' },
        { value: 15, name: '安全巡检' },
        { value: 12, name: '环境监测' },
        { value: 18, name: '文档处理' },
        { value: 8, name: '优化计算' }
      ]
    }
  };

  return Promise.resolve({ code: 200, data: mockData, msg: 'ok' });
}

/**
 * 获取作业率统计数据
 * 真实接口: GET /task-monitor/stat/oprate
 */
export function getOpRateData(params?: Record<string, any>): Promise<any> {
  console.log('Fetching operation rate data with params:', params);
  const mockData = {
    table: [
      {
        node: '数据采集节点集群',
        plannedHours: 40,
        actualHours: 38.5,
        operationRate: 96.25,
        efficiency: 1.04,
        bottleneck: '无',
        suggestion: '当前运行良好，建议保持现有资源配置。'
      },
      {
        node: '计算处理节点集群',
        plannedHours: 40,
        actualHours: 48.2,
        operationRate: 100,
        efficiency: 0.83,
        bottleneck: 'CPU资源不足',
        suggestion: '建议增加计算节点或优化任务调度算法以降低排队等待时间。'
      },
      {
        node: '数据存储节点集群',
        plannedHours: 40,
        actualHours: 37.0,
        operationRate: 92.5,
        efficiency: 1.08,
        bottleneck: '存储IO偶发延迟',
        suggestion: '建议定期执行存储碎片整理，保持IO性能稳定。'
      },
      {
        node: '报表渲染节点集群',
        plannedHours: 40,
        actualHours: 42.3,
        operationRate: 100,
        efficiency: 0.95,
        bottleneck: '复杂报表渲染耗时',
        suggestion: '建议对大报表采用异步生成+缓存策略。'
      }
    ],
    chart: {
      categories: ['第27周', '第28周', '第29周', '第30周', '第31周', '第32周(预估)'],
      plannedRate: [95, 94, 93, 96, 95, 95],
      actualRate: [92, 91, 90, 94, 93, 93],
      plannedHours: [160, 160, 160, 160, 160, 160],
      actualHours: [155, 153, 152, 158, 156, 156],
      nodes: ['数据采集节点集群', '计算处理节点集群', '数据存储节点集群', '报表渲染节点集群', '消息队列节点集群']
    }
  };

  return Promise.resolve({ code: 200, data: mockData, msg: 'ok' });
}

/**
 * 获取质量统计数据
 * 真实接口: GET /task-monitor/stat/quality
 */
export function getQualityData(params?: Record<string, any>): Promise<any> {
  console.log('Fetching quality data with params:', params);
  const mockData = {
    chart: {
      radarIndicators: [
        { name: '数据准确性', max: 100 },
        { name: '规格合规率', max: 100 },
        { name: '时效达标率', max: 100 },
        { name: '文档完整度', max: 100 },
        { name: '异常处理率', max: 100 },
        { name: '客户满意度', max: 100 }
      ],
      radarCurrentPeriod: [96.8, 98.7, 93.5, 95.2, 89.4, 92.0],
      radarLastPeriod: [94.5, 97.2, 91.0, 93.8, 86.5, 90.3],
      defectDistribution: [
        { value: 35, name: '数据格式错误' },
        { value: 25, name: '规格偏差' },
        { value: 18, name: '标签缺失' },
        { value: 12, name: '时间戳异常' },
        { value: 10, name: '其他' }
      ],
      trendCategories: ['1月', '2月', '3月', '4月', '5月', '6月', '7月'],
      trendDataQuality: [94.2, 94.5, 95.0, 95.3, 95.8, 96.2, 96.8],
      trendCodeQuality: [96.5, 96.8, 97.0, 97.3, 97.8, 98.2, 98.7],
      trendOutputQuality: [91.0, 91.5, 92.0, 92.5, 93.0, 93.3, 93.5],
      trendOverallQuality: [93.9, 94.3, 94.7, 95.0, 95.5, 95.9, 96.3]
    }
  };

  return Promise.resolve({ code: 200, data: mockData, msg: 'ok' });
}

/**
 * 获取评价统计数据
 * 真实接口: GET /task-monitor/stat/eval
 */
export function getEvalData(params?: Record<string, any>): Promise<any> {
  console.log('Fetching eval stat data with params:', params);
  const mockData = {
    table: [
      {
        taskName: '危险品库存安全巡检',
        businessScore: 98.0,
        managerScore: 96.0,
        expertScore: 95.0,
        compositeScore: 96.3,
        grade: '优秀',
        evaluators: 3,
        evalTime: '2026-07-22 17:00:00'
      },
      {
        taskName: '成品钢材入库数据核验',
        businessScore: 88.5,
        managerScore: 85.0,
        expertScore: 90.0,
        compositeScore: 87.8,
        grade: '良好',
        evaluators: 3,
        evalTime: '2026-07-23 15:00:00'
      },
      {
        taskName: '原料库物料分类统计',
        businessScore: 82.0,
        managerScore: 79.5,
        expertScore: 85.0,
        compositeScore: 82.2,
        grade: '良好',
        evaluators: 2,
        evalTime: '2026-07-23 15:30:00'
      },
      {
        taskName: '半成品工序流转记录',
        businessScore: 85.5,
        managerScore: 80.0,
        expertScore: 78.0,
        compositeScore: 81.2,
        grade: '良好',
        evaluators: 3,
        evalTime: '2026-07-23 16:00:00'
      },
      {
        taskName: '入库质检报告上传',
        businessScore: 58.0,
        managerScore: 62.0,
        expertScore: 55.0,
        compositeScore: 58.3,
        grade: '不合格',
        evaluators: 2,
        evalTime: '2026-07-23 11:30:00'
      }
    ],
    chart: {
      gradeDistribution: [
        { value: 1, name: '优秀(>=90)' },
        { value: 3, name: '良好(75-89)' },
        { value: 1, name: '合格(60-74)' },
        { value: 1, name: '不合格(<60)' }
      ],
      dimensionScores: {
        categories: ['危险品巡检', '钢材核验', '物料统计', '工序流转', '质检上传'],
        business: [98.0, 88.5, 82.0, 85.5, 58.0],
        manager: [96.0, 85.0, 79.5, 80.0, 62.0],
        expert: [95.0, 90.0, 85.0, 78.0, 55.0]
      }
    }
  };

  return Promise.resolve({ code: 200, data: mockData, msg: 'ok' });
}

/**
 * 获取综合分析数据
 * 真实接口: GET /task-monitor/stat/analysis
 */
export function getAnalysisData(params?: Record<string, any>): Promise<any> {
  console.log('Fetching analysis data with params:', params);
  const mockData = {
    cards: [
      {
        title: '综合绩效指数',
        value: '87.5',
        color: '#409EFF',
        trend: 2.3
      },
      {
        title: '任务完成率',
        value: '93.8%',
        color: '#67C23A',
        trend: 1.5
      },
      {
        title: '平均作业率',
        value: '91.2%',
        color: '#E6A23C',
        trend: -0.8
      },
      {
        title: '质量达标率',
        value: '89.0%',
        color: '#F56C6C',
        trend: 0.6
      }
    ],
    table: [
      {
        dimension: '工作量维度',
        currentValue: 92.5,
        lastValue: 90.0,
        change: 2.5,
        unit: '%',
        target: 95.0,
        achievement: 97.4,
        conclusion: '工作量完成情况良好，预计可达成月度目标。'
      },
      {
        dimension: '质量维度',
        currentValue: 89.0,
        lastValue: 87.5,
        change: 1.5,
        unit: '%',
        target: 92.0,
        achievement: 96.7,
        conclusion: '质量指标稳中有升，缺陷密度持续下降。'
      },
      {
        dimension: '效率维度',
        currentValue: 91.2,
        lastValue: 92.0,
        change: -0.8,
        unit: '%',
        target: 93.0,
        achievement: 98.1,
        conclusion: '作业率略有下降，需关注计算节点瓶颈。'
      },
      {
        dimension: '成本维度',
        currentValue: 85.3,
        lastValue: 83.0,
        change: 2.3,
        unit: '%',
        target: 88.0,
        achievement: 96.9,
        conclusion: '成本控制效果显著，资源利用率持续优化。'
      }
    ],
    chart: {
      categories: ['工作量', '质量', '效率', '成本', '安全', '协作'],
      currentValues: [92.5, 89.0, 91.2, 85.3, 96.0, 82.5],
      lastValues: [90.0, 87.5, 92.0, 83.0, 95.2, 80.0],
      targetValues: [95.0, 92.0, 93.0, 88.0, 98.0, 85.0]
    }
  };

  return Promise.resolve({ code: 200, data: mockData, msg: 'ok' });
}
