import request from '@/utils/request';
import { TASK_TEMPLATE_BASE } from '@/api/taskTemplate';

/**
 * 模板项的"模板流程图"接口（供模板画布使用）
 *
 * 契约（2026-09-22 实测确认，走网关 task-manage）：
 *  - GET    /task-templates/{templateId}/items/{itemId}/workflow
 *           → { workflowDefinition, taskDefinitionList, workflowTaskRelationList, dag }；模板项未绘制时 data 为空
 *  - POST   /task-templates/{templateId}/items/{itemId}/workflow  新建，返回新的 workflowCode
 *  - PUT    /task-templates/{templateId}/items/{itemId}/workflow  更新（模板项已有 workflowCode 时用）
 *  - DELETE /task-templates/{templateId}/items/{itemId}/workflow  清理该模板项的流程图
 *
 * ⚠️ 两个必须遵守的约定（踩过坑）：
 *  1) taskDefinitionJson / taskRelationJson / locations **必须传 JSON 字符串**，
 *     传对象或数组后端会返回 `500 创建模板工作流失败: 请求参数[{0}]无效`；
 *  2) 节点的插件参数（url / httpMethod / connectTimeout 等）必须放在 `taskParams` 内，
 *     平铺在任务定义顶层同样会报"请求参数无效"。
 */

const itemWorkflowUrl = (templateId: number | string, itemId: number | string) =>
  `${TASK_TEMPLATE_BASE}/${String(templateId)}/items/${String(itemId)}/workflow`;

/** 模板项流程图数据（画布回填用） */
export interface TemplateItemWorkflow {
  workflowDefinition?: Record<string, any>;
  taskDefinitionList?: any[];
  workflowTaskRelationList?: any[];
  dag?: Record<string, any>;
  [property: string]: any;
}

/** 保存模板项流程图的入参（JSON 字符串已在外层拼好） */
export interface TemplateItemWorkflowPayload {
  name: string;
  description?: string;
  executionType?: string;
  globalParams?: string;
  timeout?: number;
  releaseState?: string;
  taskDefinitionJson: string;
  taskRelationJson: string;
  locations: string;
}

/** 读取模板项的模板流程图 */
export function getTemplateItemWorkflow(templateId: number | string, itemId: number | string) {
  return request({
    url: itemWorkflowUrl(templateId, itemId),
    method: 'get'
  });
}

/** 新建模板项的模板流程图（返回新 workflowCode） */
export function createTemplateItemWorkflow(
  templateId: number | string,
  itemId: number | string,
  data: TemplateItemWorkflowPayload
) {
  return request({
    url: itemWorkflowUrl(templateId, itemId),
    method: 'post',
    data
  });
}

/** 更新模板项的模板流程图 */
export function updateTemplateItemWorkflow(
  templateId: number | string,
  itemId: number | string,
  data: TemplateItemWorkflowPayload
) {
  return request({
    url: itemWorkflowUrl(templateId, itemId),
    method: 'put',
    data
  });
}

/** 删除（清空）模板项的模板流程图 */
export function deleteTemplateItemWorkflow(templateId: number | string, itemId: number | string) {
  return request({
    url: itemWorkflowUrl(templateId, itemId),
    method: 'delete'
  });
}
