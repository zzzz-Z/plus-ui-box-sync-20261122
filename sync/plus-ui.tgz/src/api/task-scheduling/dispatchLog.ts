import request from '@/utils/request';
import { getToken } from '@/utils/auth';

/**
 * 下发/回执请求日志（后端 `DispatchLogController`）
 *
 * 记录「综合管理系统 ↔ 外部作业单元」之间的每一次接口调用：
 * 下发 POST（OUTBOUND）与外部回执（INBOUND），含请求/响应原文、HTTP 状态码、耗时。
 * 统一前缀复用现有 taskApproval 网关路由，网关无需改动。
 */
export const DISPATCH_LOG_BASE = '/dolphinscheduler/taskApproval/dispatch-log';

/** 调用方向 */
export const DISPATCH_DIRECTIONS = [
  { value: 'OUTBOUND', label: '我方下发' },
  { value: 'INBOUND', label: '外部回执' }
] as const;

/** 调用场景 */
export const DISPATCH_SCENES = [
  { value: 'SUBMIT', label: '编排器直发' },
  { value: 'SUBMIT_AND_WAIT', label: '代提交同步等待' },
  { value: 'CALLBACK_STATUS', label: '外部回执状态' },
  { value: 'CALLBACK_PROGRESS', label: '外部回执进度' }
] as const;

export const dispatchDirectionLabel = (v?: string) =>
  DISPATCH_DIRECTIONS.find((d) => d.value === v)?.label || v || '-';

export const dispatchSceneLabel = (v?: string) =>
  DISPATCH_SCENES.find((s) => s.value === v)?.label || v || '-';

/** 分页查询参数（全部可选，除分页外） */
export interface DispatchLogQuery {
  /** OUTBOUND=我方下发；INBOUND=外部回执 */
  direction?: string;
  /** SUBMIT / SUBMIT_AND_WAIT / CALLBACK_STATUS / CALLBACK_PROGRESS */
  scene?: string;
  /** '1' 成功 / '0' 失败（注意是字符串） */
  success?: string;
  /** 作业单元编码（精确） */
  unitCode?: string;
  /** 对外子任务编号（精确） */
  subTaskNo?: string;
  /** 执行计划 ID（精确） */
  planId?: number | string;
  /** 节点编码（精确） */
  nodeCode?: number | string;
  /** 模糊匹配 URL、错误信息、子任务号、单元编码、请求/响应报文 */
  keyword?: string;
  /** yyyy-MM-dd HH:mm:ss 或 yyyy-MM-dd */
  beginTime?: string;
  endTime?: string;
  pageNo: number;
  pageSize: number;
}

/** 分页查询（列表里的报文截断到 500 字符） */
export function queryDispatchLogPage(params: DispatchLogQuery) {
  return request({
    url: `${DISPATCH_LOG_BASE}/page`,
    method: 'get',
    params
  });
}

/**
 * 静默 GET：不经过全局请求拦截器。
 *
 * 背景：`/stat`、`/{id}` 这类"辅助信息"接口一旦后端故障（实测返回 10256），
 * 走全局拦截器会**每次打开页面都弹一条错误通知**，干扰正常使用。
 * 这里用原生 fetch 直连（与 `unit-params.vue` 里探测主任务的做法一致），
 * 失败时由调用方决定怎么提示。
 */
async function silentGet<T = any>(path: string, params?: Record<string, any>): Promise<T> {
  const base = import.meta.env.VITE_APP_BASE_API || '';
  const query = params
    ? '?' +
      Object.entries(params)
        .filter(([, v]) => v !== undefined && v !== null && v !== '')
        .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`)
        .join('&')
    : '';
  const res = await fetch(`${base}${DISPATCH_LOG_BASE}${path}${query}`, {
    headers: {
      Authorization: 'Bearer ' + getToken(),
      clientid: String(import.meta.env.VITE_APP_CLIENT_ID || '')
    }
  });
  const body: any = await res.json().catch(() => null);
  if (!body) throw new Error('接口无响应');
  // 后端两种成功码并存：0（海豚风格）/ 200（若依风格）
  const code = body.code ?? 0;
  if (code !== 0 && code !== 200) throw new Error(body.msg || '请求失败');
  return (body.data ?? body) as T;
}

/** 详情（返回完整请求/响应报文）——静默调用，失败由面板提示 */
export function getDispatchLogDetail(id: number | string) {
  return silentGet<any>(`/${String(id)}`);
}

/** 概览统计：总数/成功/失败/失败率 + 按场景分组 ——静默调用 */
export function queryDispatchLogStat() {
  return silentGet<any>('/stat');
}

/** 清理 N 天前的日志（keepDays ≥ 1） */
export function cleanDispatchLog(keepDays: number) {
  return request({
    url: `${DISPATCH_LOG_BASE}/clean`,
    method: 'delete',
    params: { keepDays }
  });
}
