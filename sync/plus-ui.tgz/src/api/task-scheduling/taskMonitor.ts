import request from '@/utils/request';

/**
 * 状态监控接口（若依 task-manage 模块）
 *
 * 分两组：
 * - /monitor/main-tasks/**  ：主任务运行监控（顶部统计、组合检索列表、详情、告警）
 * - /monitor/**             ：状态监控（子任务+作业单元执行情况、资源使用、告警）
 *
 * 说明：前端统一走 /dolphinscheduler 前缀（网关 StripPrefix=1 后与服务端对齐）。
 */
export const MONITOR_BASE = '/dolphinscheduler/monitor';
export const MAIN_TASK_MONITOR_BASE = '/dolphinscheduler/monitor/main-tasks';

/** 任务运行监控顶部统计 */
export interface MainTaskStat {
  /** 运行中主任务数 */
  runningCount?: number;
  /** 已完成主任务数 */
  finishedCount?: number;
  /** 流程运行中子任务数 */
  flowRunningCount?: number;
  /** 告警数 */
  alertCount?: number;
}

/** 顶部统计：GET /monitor/main-tasks/stat */
export function getMainTaskMonitorStat() {
  return request({
    url: `${MAIN_TASK_MONITOR_BASE}/stat`,
    method: 'get'
  });
}

/** 任务运行情况列表（组合检索，返回若依分页 { rows, total }） */
export function queryMainTaskMonitorList(params: {
  searchName?: string;
  taskType?: string;
  lifeStatus?: string;
  startDate?: string;
  endDate?: string;
  pageNo: number;
  pageSize: number;
}) {
  return request({
    url: MAIN_TASK_MONITOR_BASE,
    method: 'get',
    params
  });
}

/** 任务运行详情（含子任务统计 / 子任务列表 / 告警） */
export function getMainTaskMonitorDetail(mainProjectId: number | string) {
  return request({
    url: `${MAIN_TASK_MONITOR_BASE}/${mainProjectId}`,
    method: 'get'
  });
}

/** 主任务维度告警（异常 / 超时等） */
export function getMainTaskMonitorAlerts() {
  return request({
    url: `${MAIN_TASK_MONITOR_BASE}/alerts`,
    method: 'get'
  });
}

/** 任务执行情况监控（子任务 + 作业单元明细，分页） */
export function queryTaskExecution(params: {
  mainProjectId?: number | string;
  subTaskNo?: string;
  taskType?: string;
  taskStatus?: string;
  searchName?: string;
  pageNo: number;
  pageSize: number;
}) {
  return request({
    url: `${MONITOR_BASE}/task-execution`,
    method: 'get',
    params
  });
}

/** 资源使用情况（作业岗位 / 作业单元 / 算力 / 存储 / 带宽 / 作业资料） */
export function getResourceUsage() {
  return request({
    url: `${MONITOR_BASE}/resource-usage`,
    method: 'get'
  });
}

/** 子任务/资源维度告警（timeoutHours 可选，默认后端设定） */
export function getMonitorAlerts(timeoutHours?: number) {
  return request({
    url: `${MONITOR_BASE}/alerts`,
    method: 'get',
    params: { timeoutHours }
  });
}
