import request from '@/utils/request';

/**
 * 查询浏览接口（主任务组合条件检索 + 详情 + 报表导出）
 *
 * 真实接口：/dolphinscheduler/main/projects（主任务查询/详情/导出统一走该组接口）。
 */
export const MAIN_PROJECT_BASE = '/dolphinscheduler/main/projects';

/** 主任务查询条件（与后端 MainProjectBo 对齐） */
export interface MainProjectQuery {
  pageNum: number;
  pageSize: number;
  /** 任务编号 */
  taskNo?: string;
  /** 任务名称 */
  taskName?: string;
  /** 任务类型：0计划 1应急 2其他 3自立 */
  taskType?: string;
  /** 任务来源 */
  taskSource?: string;
  /** 任务执行单位 */
  taskExecUnit?: string;
  /** 生命周期状态（running/finished/...） */
  taskLifeStatus?: string;
  /** 执行模式：1自动化 2人机交互 */
  execMode?: string;
  /** 任务状态：0正常 1废除 */
  taskStatus?: string;
  /** 时间范围（yyyy-MM-dd HH:mm:ss） */
  beginTime?: string;
  endTime?: string;
}

/** 主任务分页查询（组合条件检索） */
export function queryMainProjectPage(params: MainProjectQuery) {
  return request({
    url: MAIN_PROJECT_BASE,
    method: 'get',
    params
  });
}

/** 主任务详情 */
export function getMainProjectInfo(id: number | string) {
  return request({
    url: `${MAIN_PROJECT_BASE}/${id}`,
    method: 'get'
  });
}

/**
 * 导出任务调度统计报表（Excel）。
 * 真实接口：GET /dolphinscheduler/main/projects/export?format=excel|wps|html
 * 旧路径 /workflow/main/project/export 在后端不存在，会返回 404。
 */
export function exportMainProjectReport(params: MainProjectQuery & { format?: 'excel' | 'wps' | 'html' }) {
  return request({
    url: `${MAIN_PROJECT_BASE}/export`,
    method: 'get',
    params: {
      ...params,
      format: params.format || 'excel'
    },
    responseType: 'blob'
  });
}
