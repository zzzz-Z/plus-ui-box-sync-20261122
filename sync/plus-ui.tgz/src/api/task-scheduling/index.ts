/* ================================================================
 *  任务审批 (Approval)
 * ================================================================ */

const mockApprovalList: TaskApprovalVO[] = [
  {
    id: 'RW-2026-001',
    taskCode: 'RW-2026-001',
    taskName: '全国矢量要素更新(第一期)',
    taskType: '计划任务',
    templateName: '标准数据处理调度模板',
    priority: 'urgent',
    taskLevel: '1',
    taskSource: '单位名称',
    taskObjective: '完成全国重点区域矢量要素的增量更新，覆盖道路、建筑、水体三大要素类别',
    execCycle: '每月',
    startTime: '2026-08-01 08:00:00',
    endTime: '2026-12-31 18:00:00',
    applicant: '张明远',
    applicationTime: '2026-07-20 14:30:00',
    deadline: '2026-07-25 18:00:00',
    status: 'processing',
    creator: '张明远',
    createTime: '2026-07-20 14:30:00',
    isDispatched: true,
    isExecuting: true,
    isCompleted: false,
    abolished: false,
    description: '对全国重点区域矢量要素进行增量更新，涉及道路、建筑、水体三大要素类别的数据采集、质检与入库。',
    execUnits: [
      { name: '数据平台部', deliverable: '道路矢量更新成果包（Shapefile + GeoJSON）', deadline: '2026-09-30 18:00:00' },
      { name: '数据分析部', deliverable: '建筑要素更新成果包及质量报告', deadline: '2026-10-31 18:00:00' },
      { name: '军事地质部', deliverable: '水体要素更新及专题图', deadline: '2026-11-30 18:00:00' }
    ],
    approvalFormPath: '',
    scannedResultPath: '',
    offlineApprover: '',
    offlineApprovalDate: '',
    handler: '',
    approvalNodes: [
      {
        id: 'node-001',
        name: '部门主管审批',
        role: '部门主管',
        assignee: '李志强',
        assigneeId: 'U-1001',
        status: 'approved',
        comment: '任务需求明确，资源配置合理，同意执行。',
        time: '2026-07-20 16:45:30',
        deadline: '2026-07-21 12:00:00'
      },
      {
        id: 'node-002',
        name: '技术负责人审批',
        role: '技术负责人',
        assignee: '王建国',
        assigneeId: 'U-1002',
        status: 'approved',
        comment: '技术方案可行，已评估对生产环境的影响。',
        time: '2026-07-21 10:20:00',
        deadline: '2026-07-22 12:00:00'
      },
      {
        id: 'node-003',
        name: '数据管理委员会审批',
        role: '数据管理委员会',
        assignee: '陈雪梅',
        assigneeId: 'U-1003',
        status: 'pending',
        comment: '',
        time: '',
        deadline: '2026-07-23 18:00:00'
      }
    ],
    approvalHistory: [
      { nodeName: '部门主管审批', operator: '李志强', action: 'approved', comment: '任务需求明确，资源配置合理，同意执行。', time: '2026-07-20 16:45:30' },
      { nodeName: '技术负责人审批', operator: '王建国', action: 'approved', comment: '技术方案可行，已评估对生产环境的影响。', time: '2026-07-21 10:20:00' }
    ]
  },
  {
    id: 'RW-2026-002',
    taskCode: 'RW-2026-002',
    taskName: '南海陆海专题图紧急制作',
    taskType: '应急任务',
    templateName: '批量文件转换调度模板',
    priority: 'urgent',
    taskLevel: '1',
    taskSource: '海军司令部',
    taskObjective: '72小时内完成南海重点海域陆海融合专题图的紧急制作与分发',
    execCycle: '单次执行',
    startTime: '2026-08-02 06:00:00',
    endTime: '2026-08-05 06:00:00',
    applicant: '刘晓峰',
    applicationTime: '2026-08-02 06:30:00',
    deadline: '2026-08-05 06:00:00',
    status: 'pending',
    creator: '刘晓峰',
    createTime: '2026-08-02 06:30:00',
    isDispatched: false,
    isExecuting: false,
    isCompleted: false,
    abolished: false,
    description: '应海军司令部紧急要求，72小时内完成南海重点海域的陆海融合专题图制作，包括海底地形渲染、岸线变化标注及航道安全分析。',
    execUnits: [
      { name: '陆海融合中心', deliverable: '南海陆海融合专题图（1:25万，GeoTIFF+PDF）', deadline: '2026-08-04 18:00:00' },
      { name: '军事地质部', deliverable: '海底地形分析报告及数据包', deadline: '2026-08-05 06:00:00' }
    ],
    approvalFormPath: '',
    scannedResultPath: '',
    offlineApprover: '',
    offlineApprovalDate: '',
    handler: '',
    approvalNodes: [
      {
        id: 'node-004',
        name: '部门主管审批',
        role: '部门主管',
        assignee: '赵文博',
        assigneeId: 'U-1004',
        status: 'pending',
        comment: '',
        time: '',
        deadline: '2026-08-02 12:00:00'
      },
      {
        id: 'node-005',
        name: '技术负责人审批',
        role: '技术负责人',
        assignee: '孙海龙',
        assigneeId: 'U-1005',
        status: 'pending',
        comment: '',
        time: '',
        deadline: '2026-08-02 18:00:00'
      }
    ],
    approvalHistory: []
  },
  {
    id: 'RW-2026-003',
    taskCode: 'RW-2026-003',
    taskName: '全球框架数据季度同步任务',
    taskType: '其他任务',
    templateName: '数据同步与校验模板',
    priority: 'normal',
    taskLevel: '2',
    taskSource: '联合国地理信息司',
    taskObjective: '按季度同步全球地理框架数据，确保与UN-GGIM标准对齐',
    execCycle: '每季度',
    startTime: '2026-07-01 00:00:00',
    endTime: '2026-09-30 23:59:59',
    applicant: '杨帆',
    applicationTime: '2026-06-25 09:00:00',
    deadline: '2026-07-01 00:00:00',
    status: 'approved',
    creator: '杨帆',
    createTime: '2026-06-25 09:00:00',
    isDispatched: true,
    isExecuting: false,
    isCompleted: true,
    abolished: false,
    description: '按季度从UN-GGIM数据门户同步全球地理框架数据，包括行政边界、交通网络、水系、地名等基础图层，同步完成后进行质量校验和格式转换。',
    execUnits: [
      { name: '矢量组网部', deliverable: '全球框架数据同步包（GeoPackage格式）', deadline: '2026-09-30 18:00:00' },
      { name: '质量监控组', deliverable: '数据质量评估报告', deadline: '2026-10-15 18:00:00' }
    ],
    approvalFormPath: '/files/approval/RW-2026-003_审批表.pdf',
    scannedResultPath: '/files/approval/RW-2026-003_扫描件.pdf',
    offlineApprover: '黄俊杰',
    offlineApprovalDate: '2026-06-30',
    handler: '马晓丽',
    approvalNodes: [
      {
        id: 'node-007',
        name: '部门主管审批',
        role: '部门主管',
        assignee: '黄俊杰',
        assigneeId: 'U-1007',
        status: 'approved',
        comment: '已线下审批通过。',
        time: '2026-06-28 15:30:00',
        deadline: '2026-06-30 12:00:00'
      },
      {
        id: 'node-008',
        name: '数据管理委员会审批',
        role: '数据管理委员会',
        assignee: '陈雪梅',
        assigneeId: 'U-1003',
        status: 'approved',
        comment: '数据标准已确认，同意执行。',
        time: '2026-06-30 09:45:00',
        deadline: '2026-07-01 12:00:00'
      }
    ],
    approvalHistory: [
      { nodeName: '部门主管审批', operator: '黄俊杰', action: 'approved', comment: '已线下审批通过。', time: '2026-06-28 15:30:00' },
      { nodeName: '数据管理委员会审批', operator: '陈雪梅', action: 'approved', comment: '数据标准已确认，同意执行。', time: '2026-06-30 09:45:00' }
    ]
  },
  {
    id: 'RW-2026-004',
    taskCode: 'RW-2026-004',
    taskName: '军事地质数据采集(西南区域)',
    taskType: '计划任务',
    templateName: '遥感影像数据预处理流程',
    priority: 'high',
    taskLevel: '1',
    taskSource: '陆军参谋部',
    taskObjective: '完成西南边境区域军事地质数据的全面采集与建库，支撑战场环境分析',
    execCycle: '单次执行',
    startTime: '2026-08-15 08:00:00',
    endTime: '2026-12-31 18:00:00',
    applicant: '李明远',
    applicationTime: '2026-08-01 08:30:00',
    deadline: '2026-08-10 18:00:00',
    status: 'pending',
    creator: '李明远',
    createTime: '2026-08-01 08:30:00',
    isDispatched: false,
    isExecuting: false,
    isCompleted: false,
    abolished: false,
    description: '对西南边境区域进行军事地质数据全面采集，包括地形地貌、水文地质、工程地质、地质灾害等专题数据，建立军事地质数据库。',
    execUnits: [
      { name: '军事地质部', deliverable: '西南区域军事地质数据库（含4大专题）', deadline: '2026-12-15 18:00:00' },
      { name: 'AI协同部', deliverable: 'AI辅助地质解译成果报告', deadline: '2026-11-30 18:00:00' },
      { name: '数据平台部', deliverable: '数据入库与可视化平台部署', deadline: '2026-12-31 18:00:00' }
    ],
    approvalFormPath: '',
    scannedResultPath: '',
    offlineApprover: '',
    offlineApprovalDate: '',
    handler: '',
    approvalNodes: [
      {
        id: 'node-009',
        name: '部门主管审批',
        role: '部门主管',
        assignee: '吴国栋',
        assigneeId: 'U-1009',
        status: 'pending',
        comment: '',
        time: '',
        deadline: '2026-08-05 12:00:00'
      },
      {
        id: 'node-010',
        name: '安全审计审批',
        role: '安全审计员',
        assignee: '周敏',
        assigneeId: 'U-1006',
        status: 'pending',
        comment: '',
        time: '',
        deadline: '2026-08-08 12:00:00'
      }
    ],
    approvalHistory: []
  },
  {
    id: 'RW-2026-005',
    taskCode: 'RW-2026-005',
    taskName: '智能化标注工具开发',
    taskType: '自立任务',
    templateName: '矢量要素并行提取流程',
    priority: 'low',
    taskLevel: '3',
    taskSource: '内部立项',
    taskObjective: '自主研发基于AI的地图要素智能标注工具，提升标注效率50%以上',
    execCycle: '单次执行',
    startTime: '2026-09-01 09:00:00',
    endTime: '2027-03-31 18:00:00',
    applicant: '陈志强',
    applicationTime: '2026-08-03 10:00:00',
    deadline: '2026-08-20 18:00:00',
    status: 'rejected',
    creator: '陈志强',
    createTime: '2026-08-03 10:00:00',
    isDispatched: false,
    isExecuting: false,
    isCompleted: false,
    abolished: false,
    description: '利用深度学习技术研发地图要素智能标注工具，支持道路、建筑、水体等要素的自动识别与标注，目标将人工标注效率提升50%以上。含数据标注平台、模型训练框架和推理引擎三个子模块。',
    execUnits: [
      { name: 'AI协同部', deliverable: '智能标注工具软件（含模型+文档）', deadline: '2027-03-15 18:00:00' },
      { name: '数据平台部', deliverable: '标注数据集（10万+样本）', deadline: '2026-12-31 18:00:00' }
    ],
    approvalFormPath: '',
    scannedResultPath: '',
    offlineApprover: '',
    offlineApprovalDate: '',
    handler: '',
    approvalNodes: [
      {
        id: 'node-011',
        name: '部门主管审批',
        role: '部门主管',
        assignee: '郑永刚',
        assigneeId: 'U-1010',
        status: 'approved',
        comment: '内部研发项目，方向可行。',
        time: '2026-08-04 14:00:00',
        deadline: '2026-08-10 12:00:00'
      },
      {
        id: 'node-012',
        name: '技术负责人审批',
        role: '技术负责人',
        assignee: '王建国',
        assigneeId: 'U-1002',
        status: 'rejected',
        comment: '当前人力资源紧张，建议推迟至明年第一季度立项。',
        time: '2026-08-05 09:30:00',
        deadline: '2026-08-15 12:00:00'
      }
    ],
    approvalHistory: [
      { nodeName: '部门主管审批', operator: '郑永刚', action: 'approved', comment: '内部研发项目，方向可行。', time: '2026-08-04 14:00:00' },
      { nodeName: '技术负责人审批', operator: '王建国', action: 'rejected', comment: '当前人力资源紧张，建议推迟至明年第一季度立项。', time: '2026-08-05 09:30:00' }
    ]
  }
];

/** 获取审批列表 - GET /task-scheduling/approval/list */
export function getApprovalList(params: any): Promise<any> {
  let filtered = [...mockApprovalList];
  if (params.taskCode) {
    filtered = filtered.filter(item => item.taskCode?.includes(params.taskCode!));
  }
  if (params.taskName) {
    filtered = filtered.filter(item => item.taskName.includes(params.taskName!));
  }
  if (params.taskType) {
    filtered = filtered.filter(item => item.taskType === params.taskType);
  }
  if (params.taskLevel) {
    filtered = filtered.filter(item => item.taskLevel === params.taskLevel);
  }
  if (params.taskSource) {
    filtered = filtered.filter(item => item.taskSource?.includes(params.taskSource!));
  }
  if (params.execUnit) {
    filtered = filtered.filter(item => (item.execUnits || []).some((u: any) => u.name?.includes(params.execUnit!)));
  }
  if (params.status) {
    // status can be comma-separated for multiple
    const statuses = params.status.split(',');
    filtered = filtered.filter(item => statuses.includes(item.status));
  }
  if (params.priority) {
    filtered = filtered.filter(item => item.priority === params.priority);
  }
  const pageNum = params.pageNum || 1;
  const pageSize = params.pageSize || 10;
  const start = (pageNum - 1) * pageSize;
  const rows = filtered.slice(start, start + pageSize);
  return Promise.resolve({
    code: 200,
    data: { rows, total: filtered.length },
    msg: 'ok'
  });
}

/** 获取审批详情 - GET /task-scheduling/approval/detail/{id} */
export function getApprovalDetail(id: string): Promise<any> {
  const detail = mockApprovalList.find(item => item.id === id) || null;
  return Promise.resolve({
    code: 200,
    data: detail as TaskApprovalVO,
    msg: 'ok'
  });
}

/** 提交审批 - POST /task-scheduling/approval/submit */
export function submitApproval(data: any): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: null,
    msg: '审批任务提交成功'
  });
}

/** 审批操作（通过/驳回） - PUT /task-scheduling/approval/action/{id} */
export function approvalAction(id: string, action: 'approved' | 'rejected', comment: string): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: null,
    msg: action === 'approved' ? '审批通过成功' : '审批驳回成功'
  });
}

// ==================== 线下审批管理 ====================

/** 生成审批表文件 - POST /task-scheduling/approval/generate-form */
export function generateApprovalForm(id: string, format: 'word' | 'wps' | 'pdf'): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: { downloadUrl: `/download/approval/${id}_审批表.${format === 'word' ? 'docx' : format === 'wps' ? 'wps' : 'pdf'}` },
    msg: `${format.toUpperCase()}审批表已生成，请下载后线下审批`
  });
}

/** 上传审批扫描件 - POST /task-scheduling/approval/upload-scan */
export function uploadApprovalScan(id: string, _formData: FormData): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: { filePath: `/files/approval/${id}_扫描件.pdf` },
    msg: '扫描件上传成功'
  });
}

/** 记录线下审批信息 - PUT /task-scheduling/approval/offline-record */
export function recordOfflineApproval(id: string, data: { approver: string; approvalDate: string; handler: string; comment: string }): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: null,
    msg: '线下审批信息已记录'
  });
}

// ==================== 任务操作 ====================

/** 标记废除任务 - PUT /task-scheduling/approval/abolish/{id} */
export function abolishTask(id: string): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: null,
    msg: '任务已标记废除'
  });
}

/** 删除任务（级联删除） - DELETE /task-scheduling/approval/delete/{id} */
export function deleteTask(id: string): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: null,
    msg: '任务及关联信息已删除'
  });
}

/** 导出任务列表 - POST /task-scheduling/approval/export */
export function exportTaskList(params: any, format: 'excel' | 'wps' | 'html'): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: { downloadUrl: `/download/export/task_list_${Date.now()}.${format === 'excel' ? 'xlsx' : format}` },
    msg: `任务列表已导出为${format.toUpperCase()}格式`
  });
}

/* ================================================================
 *  调度模板 (Scheduling Template)
 * ================================================================ */

const mockTemplateList: SchedulingTemplateVO[] = [
  {
    id: 'TPL-001',
    name: '遥感影像数据预处理流程',
    taskType: '计划任务',
    productCategory: '分类要素标准分幅产品',
    taskScale: '大规模（全国范围）',
    description: '从HDFS数据源读取原始遥感影像，经过辐射定标、大气校正后输出GeoTIFF产品，适用于卫星影像标准化预处理。',
    version: 'v3.2.1',
    status: 'published',
    abolished: false,
    creator: '张明远',
    approver: '李志强',
    createTime: '2026-06-15 10:30:00',
    updateTime: '2026-07-25 16:45:00',
    execDept: '数据平台部',
    nodeCount: 4,
    scheduleMode: 'manual',
    versionHistory: [
      { version: 'v3.2.1', modifier: '张明远', time: '2026-07-25 16:45:00', remark: '更新大气校正模型参数' },
      { version: 'v3.2.0', modifier: '张明远', time: '2026-07-10 09:30:00', remark: '新增辐射定标处理节点' },
      { version: 'v3.1.0', modifier: '杨帆', time: '2026-06-20 14:00:00', remark: '优化质检入库SQL性能' }
    ],
    usedTaskIds: ['RW-2026-001'],
    flowData: {
      nodes: [
        { id: 'node_1', type: 'custom', position: { x: 250, y: 60 }, data: { label: 'HDFS遥感影像源', nodeType: 'DATA_SOURCE', dataSourceType: 'hdfs', dataSourcePath: 'hdfs://cluster/raw/satellite/2026/', dataSourceFormat: 'geotiff', width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 30, failStrategy: 'end' } },
        { id: 'node_2', type: 'custom', position: { x: 250, y: 180 }, data: { label: '辐射定标处理', nodeType: 'SHELL', command: 'python /scripts/radiometric_calib.py --input ${input_dir} --coeff /config/calib_coeff.json', workDir: '/home/gisworker', width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 120, failStrategy: 'end' } },
        { id: 'node_3', type: 'custom', position: { x: 250, y: 300 }, data: { label: '大气校正', nodeType: 'PYTHON', scriptPath: '/scripts/atmospheric_correction.py', pythonVersion: '3.10', scriptArgs: '--model 6S --aerosol continental --water-vapor 2.5', width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 180, failStrategy: 'end' } },
        { id: 'node_4', type: 'custom', position: { x: 250, y: 420 }, data: { label: '质检结果入库', nodeType: 'SQL', dataSource: 'jdbc:postgresql://pg-cluster:5432/gis_db', sqlText: 'INSERT INTO products (name,path,quality_score,processed_at) VALUES (${name},${output_path},${score},NOW())', width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 60, failStrategy: 'end' } },
      ],
      edges: [
        { id: 'enode_1-node_2', source: 'node_1', target: 'node_2', type: 'smoothstep', animated: true },
        { id: 'enode_2-node_3', source: 'node_2', target: 'node_3', type: 'smoothstep', animated: true },
        { id: 'enode_3-node_4', source: 'node_3', target: 'node_4', type: 'smoothstep', animated: true },
      ],
      schedule: { mode: 'manual', priority: 'medium', retryCount: 3, timeout: 480 },
    },
  },
  {
    id: 'TPL-002',
    name: '矢量要素并行提取流程',
    taskType: '计划任务',
    productCategory: '分类要素矢量产品',
    taskScale: '中规模（区域级）',
    description: '从S3对象存储读取矢量数据，分三路并行执行要素提取（道路/建筑/水体），合并结果后通过HTTP推送到下游系统。',
    version: 'v2.1.0',
    status: 'published',
    abolished: false,
    creator: '刘晓峰',
    approver: '王建国',
    createTime: '2026-05-20 14:00:00',
    updateTime: '2026-07-22 09:30:00',
    execDept: '数据分析部',
    nodeCount: 6,
    scheduleMode: 'cron',
    versionHistory: [
      { version: 'v2.1.0', modifier: '刘晓峰', time: '2026-07-22 09:30:00', remark: '新增水体要素提取分支' },
      { version: 'v2.0.0', modifier: '刘晓峰', time: '2026-06-15 11:00:00', remark: '架构升级：单路改为三路并行' },
      { version: 'v1.0.0', modifier: '刘晓峰', time: '2026-05-20 14:00:00', remark: '初始版本' }
    ],
    usedTaskIds: ['RW-2026-005'],
    flowData: {
      nodes: [
        { id: 'node_1', type: 'custom', position: { x: 250, y: 60 }, data: { label: 'S3矢量数据源', nodeType: 'DATA_SOURCE', dataSourceType: 's3', dataSourcePath: 's3://geo-bucket/vector/2026Q3/', dataSourceFormat: 'shp', width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 30, failStrategy: 'end' } },
        { id: 'node_2', type: 'custom', position: { x: 60, y: 200 }, data: { label: '道路要素提取', nodeType: 'SPARK', sparkMainClass: 'com.gis.RoadExtraction', sparkJar: 'hdfs:///jars/feature-extract.jar', sparkArgs: '--feature road --min-confidence 0.85', sparkDeployMode: 'cluster', width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 300, failStrategy: 'continue' } },
        { id: 'node_3', type: 'custom', position: { x: 250, y: 200 }, data: { label: '建筑要素提取', nodeType: 'SPARK', sparkMainClass: 'com.gis.BuildingExtraction', sparkJar: 'hdfs:///jars/feature-extract.jar', sparkArgs: '--feature building --min-area 50', sparkDeployMode: 'cluster', width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 300, failStrategy: 'continue' } },
        { id: 'node_4', type: 'custom', position: { x: 440, y: 200 }, data: { label: '水体要素提取', nodeType: 'SPARK', sparkMainClass: 'com.gis.WaterExtraction', sparkJar: 'hdfs:///jars/feature-extract.jar', sparkArgs: '--feature water --min-area 100', sparkDeployMode: 'cluster', width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 300, failStrategy: 'continue' } },
        { id: 'node_5', type: 'custom', position: { x: 250, y: 340 }, data: { label: '要素合并', nodeType: 'MERGE', width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 60, failStrategy: 'end' } },
        { id: 'node_6', type: 'custom', position: { x: 250, y: 460 }, data: { label: '推送到数据中台', nodeType: 'HTTP', url: 'https://api.data-platform.com/v2/features/import', httpMethod: 'POST', httpBody: '{"format":"GeoJSON","source":"vector-extract"}', width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 120, failStrategy: 'end' } },
      ],
      edges: [
        { id: 'enode_1-node_2', source: 'node_1', target: 'node_2', type: 'smoothstep', animated: true },
        { id: 'enode_1-node_3', source: 'node_1', target: 'node_3', type: 'smoothstep', animated: true },
        { id: 'enode_1-node_4', source: 'node_1', target: 'node_4', type: 'smoothstep', animated: true },
        { id: 'enode_2-node_5', source: 'node_2', target: 'node_5', type: 'smoothstep', animated: true },
        { id: 'enode_3-node_5', source: 'node_3', target: 'node_5', type: 'smoothstep', animated: true },
        { id: 'enode_4-node_5', source: 'node_4', target: 'node_5', type: 'smoothstep', animated: true },
        { id: 'enode_5-node_6', source: 'node_5', target: 'node_6', type: 'smoothstep', animated: true },
      ],
      schedule: { mode: 'cron', cron: '0 2 * * *', priority: 'high', retryCount: 2, timeout: 720 },
    },
  },
  {
    id: 'TPL-003',
    name: '陆海专题图生成与分发',
    taskType: '应急任务',
    productCategory: 'lh专题图产品',
    taskScale: '小规模（单次任务）',
    description: '数据库查询陆海边界数据，生成专题图渲染，执行质量检查，条件判断通过后分两路（邮件+FTP）分发成品。',
    version: 'v1.5.3',
    status: 'draft',
    abolished: false,
    creator: '马晓丽',
    approver: '',
    createTime: '2026-06-01 08:00:00',
    updateTime: '2026-07-20 11:15:00',
    execDept: '军事地质部',
    nodeCount: 6,
    scheduleMode: 'event',
    versionHistory: [
      { version: 'v1.5.3', modifier: '马晓丽', time: '2026-07-20 11:15:00', remark: '新增条件判断节点' },
      { version: 'v1.5.0', modifier: '马晓丽', time: '2026-07-01 16:00:00', remark: '优化专题图渲染DPI参数' }
    ],
    usedTaskIds: ['RW-2026-002'],
    flowData: {
      nodes: [
        { id: 'node_1', type: 'custom', position: { x: 250, y: 60 }, data: { label: 'PG空间数据库', nodeType: 'DATA_SOURCE', dataSourceType: 'database', dataSourceConnection: 'jdbc:postgresql://pg-cluster:5432/gis_db', dataSourceQuery: 'SELECT * FROM land_sea_boundary WHERE region=${region} AND version=2026', dataSourcePath: '', dataSourceFormat: 'auto', width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 60, failStrategy: 'end' } },
        { id: 'node_2', type: 'custom', position: { x: 250, y: 180 }, data: { label: '专题图渲染', nodeType: 'SHELL', command: 'python /scripts/thematic_render.py --style /config/land_sea.json --dpi 300 --output ${output_dir}/', workDir: '/home/renderer', width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 600, failStrategy: 'end' } },
        { id: 'node_3', type: 'custom', position: { x: 250, y: 300 }, data: { label: '质量检查', nodeType: 'SHELL', command: 'python /scripts/quality_check.py --threshold 0.98 --check-items geometry,attribute,completeness', workDir: '/home/qc', width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 120, failStrategy: 'end' } },
        { id: 'node_4', type: 'custom', position: { x: 250, y: 420 }, data: { label: '质检通过?', nodeType: 'CONDITION', conditionExpr: '${qc_score} >= 0.98', width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 10, failStrategy: 'end' } },
        { id: 'node_5', type: 'custom', position: { x: 80, y: 540 }, data: { label: '邮件分发', nodeType: 'HTTP', url: 'https://mail-api.internal.com/send', httpMethod: 'POST', httpBody: '{"to":"gis-team@company.com","subject":"专题图成果","attachPath":"${output_dir}"}', width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 30, failStrategy: 'continue' } },
        { id: 'node_6', type: 'custom', position: { x: 420, y: 540 }, data: { label: 'FTP归档', nodeType: 'DATA_TRANSFER', sourcePath: '${output_dir}/', targetPath: 'ftp://archive.internal.com/thematic/2026/', transferMode: 'scp', width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 60, failStrategy: 'continue' } },
      ],
      edges: [
        { id: 'enode_1-node_2', source: 'node_1', target: 'node_2', type: 'smoothstep', animated: true },
        { id: 'enode_2-node_3', source: 'node_2', target: 'node_3', type: 'smoothstep', animated: true },
        { id: 'enode_3-node_4', source: 'node_3', target: 'node_4', type: 'smoothstep', animated: true },
        { id: 'enode_4-node_5', source: 'node_4', target: 'node_5', type: 'smoothstep', animated: true },
        { id: 'enode_4-node_6', source: 'node_4', target: 'node_6', type: 'smoothstep', animated: true },
      ],
      schedule: { mode: 'event', eventType: 'data_arrived', priority: 'medium', retryCount: 1, timeout: 900 },
    },
  },
  {
    id: 'TPL-004',
    name: '全球框架数据同步流程',
    taskType: '其他任务',
    productCategory: 'qq地理信息框架',
    taskScale: '大规模（全球范围）',
    description: '依赖上游数据准备完成后，从FTP拉取全球框架数据，经Flink实时流处理后写入HDFS，再启动MapReduce批量建索引。',
    version: 'v1.0.0',
    status: 'published',
    abolished: false,
    creator: '陈志强',
    approver: '黄俊杰',
    createTime: '2026-07-01 09:00:00',
    updateTime: '2026-07-26 14:20:00',
    execDept: '矢量组网部',
    nodeCount: 4,
    scheduleMode: 'cron',
    versionHistory: [
      { version: 'v1.0.0', modifier: '陈志强', time: '2026-07-01 09:00:00', remark: '初始版本' }
    ],
    usedTaskIds: ['RW-2026-003'],
    flowData: {
      nodes: [
        { id: 'node_1', type: 'custom', position: { x: 250, y: 60 }, data: { label: '等待上游数据就绪', nodeType: 'DEPENDENT', dependentTasks: 'TPL-001,TPL-002', dependentTimeout: 3600, width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 3600, failStrategy: 'end' } },
        { id: 'node_2', type: 'custom', position: { x: 250, y: 180 }, data: { label: 'FTP数据拉取', nodeType: 'DATA_TRANSFER', sourcePath: 'ftp://global-data.internal.com/framework/v3/', targetPath: '/data/global/incoming/', transferMode: 'scp', width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 180, failStrategy: 'end' } },
        { id: 'node_3', type: 'custom', position: { x: 250, y: 300 }, data: { label: 'Flink实时ETL', nodeType: 'FLINK', flinkMainClass: 'com.gis.FrameworkETL', flinkJar: 'hdfs:///jars/flink-etl.jar', flinkArgs: '--source /data/global/incoming --sink hdfs:///global/processed', flinkParallelism: 8, width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 600, failStrategy: 'end' } },
        { id: 'node_4', type: 'custom', position: { x: 250, y: 420 }, data: { label: 'MR空间索引构建', nodeType: 'MR', mrInput: 'hdfs:///global/processed', mrOutput: 'hdfs:///global/indexed', mrMapper: 'com.gis.SpatialIndexMapper', mrReducer: 'com.gis.SpatialIndexReducer', width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 900, failStrategy: 'end' } },
      ],
      edges: [
        { id: 'enode_1-node_2', source: 'node_1', target: 'node_2', type: 'smoothstep', animated: true },
        { id: 'enode_2-node_3', source: 'node_2', target: 'node_3', type: 'smoothstep', animated: true },
        { id: 'enode_3-node_4', source: 'node_3', target: 'node_4', type: 'smoothstep', animated: true },
      ],
      schedule: { mode: 'cron', cron: '0 6 * * 1,3,5', priority: 'high', retryCount: 0, timeout: 1200 },
    },
  },
  {
    id: 'TPL-005',
    name: '成果质量评估子流程',
    taskType: '自立任务',
    productCategory: '分类要素标准分幅产品',
    taskScale: '小规模（子流程）',
    description: '作为子流程模板被其他主流程调用，执行多维度质量评估（几何精度/属性完整性/拓扑一致性），输出质量报告。',
    version: 'v2.0.1',
    status: 'published',
    abolished: false,
    creator: '王海峰',
    approver: '李志强',
    createTime: '2026-04-10 13:00:00',
    updateTime: '2026-07-15 10:00:00',
    execDept: '质量监控组',
    nodeCount: 4,
    scheduleMode: 'manual',
    versionHistory: [
      { version: 'v2.0.1', modifier: '王海峰', time: '2026-07-15 10:00:00', remark: 'Python升级到3.11，调整评分权重' },
      { version: 'v2.0.0', modifier: '王海峰', time: '2026-05-20 09:00:00', remark: '重构为多维评估模型' }
    ],
    usedTaskIds: [],
    flowData: {
      nodes: [
        { id: 'node_1', type: 'custom', position: { x: 250, y: 60 }, data: { label: '接收父流程数据', nodeType: 'DATA_SOURCE', dataSourceType: 'file', dataSourcePath: '${parent_output_dir}/', dataSourceFormat: 'auto', width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 10, failStrategy: 'end' } },
        { id: 'node_2', type: 'custom', position: { x: 250, y: 180 }, data: { label: '精度/属性/拓扑评估', nodeType: 'PYTHON', scriptPath: '/scripts/multi_dim_eval.py', pythonVersion: '3.11', scriptArgs: '--dims geometry,attribute,topology --weights 0.4,0.3,0.3', width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 300, failStrategy: 'end' } },
        { id: 'node_3', type: 'custom', position: { x: 250, y: 300 }, data: { label: '评分等级判定', nodeType: 'SWITCH', switchExpr: '${quality_level}', switchBranches: 'A,B,C,D', width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 10, failStrategy: 'end' } },
        { id: 'node_4', type: 'custom', position: { x: 250, y: 420 }, data: { label: '评估结果写入数据库', nodeType: 'SQL', dataSource: 'jdbc:postgresql://pg-cluster:5432/gis_db', sqlText: 'INSERT INTO quality_reports (task_id,dims,scores,level,created_at) VALUES (${task_id},${dims},${scores},${quality_level},NOW())', width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 30, failStrategy: 'end' } },
      ],
      edges: [
        { id: 'enode_1-node_2', source: 'node_1', target: 'node_2', type: 'smoothstep', animated: true },
        { id: 'enode_2-node_3', source: 'node_2', target: 'node_3', type: 'smoothstep', animated: true },
        { id: 'enode_3-node_4', source: 'node_3', target: 'node_4', type: 'smoothstep', animated: true },
      ],
      schedule: { mode: 'manual', priority: 'medium', retryCount: 2, timeout: 420 },
    },
  },
  {
    id: 'TPL-006',
    name: '验证码接口检测流程',
    taskType: '其他任务',
    productCategory: 'qq地理信息框架',
    taskScale: '小规模（单次任务）',
    description: '访问 /dev-api/auth/code 接口获取验证码，判断是否有返回值。有返回值则输出结果，无返回值则弹出警告。',
    version: 'v1.0.0',
    status: 'published',
    abolished: false,
    creator: '系统管理员',
    approver: '',
    createTime: '2026-08-08 14:00:00',
    updateTime: '2026-08-08 14:00:00',
    execDept: '数据平台部',
    nodeCount: 4,
    scheduleMode: 'manual',
    versionHistory: [
      { version: 'v1.0.0', modifier: '系统管理员', time: '2026-08-08 14:00:00', remark: '初始版本' }
    ],
    usedTaskIds: [],
    flowData: {
      nodes: [
        { id: 'node_1', type: 'custom', position: { x: 250, y: 60 }, data: { label: '获取验证码', nodeType: 'HTTP', url: 'http://10.61.128.70:8092/dev-api/auth/code', httpMethod: 'GET', httpBody: '', width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 30, failStrategy: 'end' } },
        { id: 'node_2', type: 'custom', position: { x: 250, y: 200 }, data: { label: '判断返回值', nodeType: 'CONDITION', conditionExpr: '${response} != null && ${response} != \'\'', width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 10, failStrategy: 'end' } },
        { id: 'node_3', type: 'custom', position: { x: 80, y: 340 }, data: { label: '输出验证码结果', nodeType: 'SHELL', command: 'echo "验证码获取成功: ${response}"', workDir: '/tmp', width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 10, failStrategy: 'end' } },
        { id: 'node_4', type: 'custom', position: { x: 420, y: 340 }, data: { label: '弹出警告', nodeType: 'SHELL', command: 'echo "WARNING: 验证码接口无响应！请检查网络连接或接口地址是否正常。" && exit 1', workDir: '/tmp', width: 180, height: 80, fontSize: 13, borderRadius: 8, executionMode: 'docker', timeout: 10, failStrategy: 'end' } },
      ],
      edges: [
        { id: 'enode_1-node_2', source: 'node_1', target: 'node_2', type: 'smoothstep', animated: true },
        { id: 'enode_2-node_3', source: 'node_2', target: 'node_3', type: 'smoothstep', animated: true, style: { stroke: '#67c23a', strokeWidth: 2 } },
        { id: 'enode_2-node_4', source: 'node_2', target: 'node_4', type: 'smoothstep', animated: true, style: { stroke: '#f56c6c', strokeWidth: 2 } },
      ],
      schedule: { mode: 'manual', priority: 'medium', retryCount: 1, timeout: 120 },
    },
  },
];

/** 获取调度模板列表 - GET /task-scheduling/template/list */
export function getTemplateList(params: any): Promise<any> {
  let filtered = [...mockTemplateList];
  if (params.name) {
    filtered = filtered.filter(item => item.name.includes(params.name!));
  }
  if (params.taskType) {
    filtered = filtered.filter(item => item.taskType === params.taskType);
  }
  if (params.productCategory) {
    filtered = filtered.filter(item => item.productCategory === params.productCategory);
  }
  if (params.execDept) {
    filtered = filtered.filter(item => item.execDept?.includes(params.execDept!));
  }
  if (params.status) {
    filtered = filtered.filter(item => item.status === params.status);
  }
  const pageNum = params.pageNum || 1;
  const pageSize = params.pageSize || 10;
  const start = (pageNum - 1) * pageSize;
  const rows = filtered.slice(start, start + pageSize);
  return Promise.resolve({
    code: 200,
    data: { rows, total: filtered.length },
    msg: 'ok'
  });
}

/** 获取调度模板详情 - GET /task-scheduling/template/detail/{id} */
export function getTemplateDetail(id: string): Promise<any> {
  const detail = mockTemplateList.find(item => item.id === id) || null;
  return Promise.resolve({
    code: 200,
    data: detail as SchedulingTemplateVO,
    msg: 'ok'
  });
}

/** 创建调度模板 - POST /task-scheduling/template */
export function createTemplate(data: any): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: null,
    msg: '调度模板创建成功'
  });
}

/** 更新调度模板 - PUT /task-scheduling/template */
export function updateTemplate(data: any): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: null,
    msg: '调度模板更新成功'
  });
}

/** 删除调度模板 - DELETE /task-scheduling/template/{id} */
export function deleteTemplate(id: string): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: null,
    msg: '调度模板删除成功'
  });
}

/** 标记废除模板 - PUT /task-scheduling/template/abolish/{id} */
export function abolishTemplate(id: string): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: null,
    msg: '模板已标记废除'
  });
}

/** 导出模板列表 - POST /task-scheduling/template/export */
export function exportTemplateList(params: any, format: 'excel' | 'wps' | 'html'): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: { downloadUrl: `/download/export/template_list_${Date.now()}.${format === 'excel' ? 'xlsx' : format}` },
    msg: `模板列表已导出为${format.toUpperCase()}格式`
  });
}

/** 获取模板关联任务列表 - GET /task-scheduling/template/tasks/{id} */
export function getTemplateTasks(id: string): Promise<any> {
  const template = mockTemplateList.find(item => item.id === id);
  const taskIds = template?.usedTaskIds || [];
  const tasks = taskIds.map(tid => {
    const t = mockApprovalList.find(a => a.id === tid);
    return t ? { id: t.id, taskCode: t.taskCode, taskName: t.taskName, taskType: t.taskType, status: t.status, createTime: t.createTime } : null;
  }).filter(Boolean);
  return Promise.resolve({
    code: 200,
    data: tasks,
    msg: 'ok'
  });
}

/* ================================================================
 *  资源模板 (Resource Template)
 * ================================================================ */

const mockResourceTemplateList: any[] = [
  {
    id: 'RST-001',
    name: '全国矢量要素更新标准模板',
    taskType: '计划任务',
    productCategory: '分类要素标准分幅产品',
    taskScale: '大规模（全国范围）',
    jobPostList: [
      { name: '内业编辑', count: 20, duty: '负责矢量要素采集与编辑' },
      { name: '质检员', count: 5, duty: '负责成果质检与问题反馈' },
      { name: '审核员', count: 2, duty: '负责成果终审与签发' }
    ],
    jobUnitList: [
      { name: '全国分幅单元', partition: '图幅分幅', count: 12800 },
      { name: '重点区域单元', partition: '区域划分', count: 256 }
    ],
    compute: { cpu: 32, memory: 128, gpuModel: '', gpuCount: 0 },
    storage: { type: '共享存储', capacity: 20000, mountPath: '/data/vector' },
    bandwidth: { value: 1000, guarantee: '独享' },
    materialList: [
      { name: '基础底图', path: '/archive/base-map', purpose: '作业底图' },
      { name: '数字高程模型', path: '/archive/dem', purpose: '地形参考' }
    ],
    creator: '张明远',
    createTime: '2026-06-10 09:00:00',
    description: '适用于全国范围矢量要素更新任务的标准资源配置。'
  },
  {
    id: 'RST-002',
    name: '专题图生产GPU模板',
    taskType: '应急任务',
    productCategory: 'lh专题图产品',
    taskScale: '中规模（区域级）',
    jobPostList: [
      { name: '影像处理员', count: 10, duty: '负责影像融合与增强' },
      { name: '专题制图员', count: 6, duty: '负责专题要素提取与制图' }
    ],
    jobUnitList: [
      { name: '行政区划单元', partition: '区域划分', count: 512 },
      { name: '要素类别单元', partition: '要素类别', count: 20 }
    ],
    compute: { cpu: 64, memory: 256, gpuModel: 'NVIDIA A100', gpuCount: 4 },
    storage: { type: '本地盘', capacity: 10000, mountPath: '/data/image' },
    bandwidth: { value: 500, guarantee: '独享' },
    materialList: [
      { name: '卫星影像', path: '/archive/satellite', purpose: '遥感底图' },
      { name: '矢量参考', path: '/archive/vector-ref', purpose: '要素参考' }
    ],
    creator: '刘晓峰',
    createTime: '2026-06-12 14:20:00',
    description: '适用于专题图产品生产的 GPU 加速资源配置。'
  },
  {
    id: 'RST-003',
    name: '地理信息框架数据模板',
    taskType: '其他任务',
    productCategory: 'qq地理信息框架',
    taskScale: '大规模（全球范围）',
    jobPostList: [
      { name: '数据整合员', count: 15, duty: '负责多源数据整合' },
      { name: '质量检验员', count: 4, duty: '负责框架数据质检' }
    ],
    jobUnitList: [
      { name: '全球网格单元', partition: '任务批次', count: 4096 }
    ],
    compute: { cpu: 48, memory: 192, gpuModel: '', gpuCount: 0 },
    storage: { type: '对象存储', capacity: 50000, mountPath: '/data/framework' },
    bandwidth: { value: 2000, guarantee: '独享' },
    materialList: [
      { name: '全球底图数据', path: '/archive/global-base', purpose: '基础框架' }
    ],
    creator: '杨帆',
    createTime: '2026-07-05 08:30:00',
    description: '适用于全球范围地理信息框架数据生产与更新的资源配置。'
  },
  {
    id: 'RST-004',
    name: '分类要素矢量产品轻量模板',
    taskType: '自立任务',
    productCategory: '分类要素矢量产品',
    taskScale: '小规模（单次任务）',
    jobPostList: [
      { name: '内业编辑', count: 4, duty: '负责要素采集编辑' }
    ],
    jobUnitList: [
      { name: '单景作业单元', partition: '图幅分幅', count: 64 }
    ],
    compute: { cpu: 8, memory: 16, gpuModel: '', gpuCount: 0 },
    storage: { type: '共享存储', capacity: 2000, mountPath: '/data/vector-lite' },
    bandwidth: { value: 100, guarantee: '共享' },
    materialList: [
      { name: '影像参考', path: '/archive/image-ref', purpose: '判读底图' }
    ],
    creator: '马晓丽',
    createTime: '2026-06-20 10:45:00',
    description: '适用于小规模单次矢量要素任务的轻量资源配置。'
  }
];

/** 获取资源模板列表 - GET /task-scheduling/resource-template/list */
export function getResourceTemplateList(params: any): Promise<any> {
  let filtered = [...mockResourceTemplateList];
  if (params.name) {
    filtered = filtered.filter(item => item.name.includes(params.name!));
  }
  if (params.taskType) {
    filtered = filtered.filter(item => item.taskType === params.taskType);
  }
  if (params.productCategory) {
    filtered = filtered.filter(item => item.productCategory === params.productCategory);
  }
  const pageNum = params.pageNum || 1;
  const pageSize = params.pageSize || 10;
  const start = (pageNum - 1) * pageSize;
  const rows = filtered.slice(start, start + pageSize);
  return Promise.resolve({
    code: 200,
    data: { rows, total: filtered.length },
    msg: 'ok'
  });
}

/** 获取资源模板详情 - GET /task-scheduling/resource-template/detail/{id} */
export function getResourceTemplateDetail(id: string): Promise<any> {
  const detail = mockResourceTemplateList.find(item => item.id === id) || null;
  return Promise.resolve({
    code: 200,
    data: detail as ResourceTemplateVO,
    msg: 'ok'
  });
}

/** 创建资源模板 - POST /task-scheduling/resource-template */
export function createResourceTemplate(data: any): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: null,
    msg: '资源模板创建成功'
  });
}

/** 更新资源模板 - PUT /task-scheduling/resource-template */
export function updateResourceTemplate(data: any): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: null,
    msg: '资源模板更新成功'
  });
}

/** 删除资源模板 - DELETE /task-scheduling/resource-template/{id} */
export function deleteResourceTemplate(id: string): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: null,
    msg: '资源模板删除成功'
  });
}

/* ================================================================
 *  任务调度下发 (Task Dispatch)
 * ================================================================ */

const mockDispatchTemplateList: DispatchTemplate[] = [
  { id: 't1', name: '标准数据处理调度模板', type: '数据处理', stepCount: 4 },
  { id: 't2', name: '批量文件转换调度模板', type: '文件处理', stepCount: 6 },
  { id: 't3', name: '报表生成与分发模板', type: '报表生成', stepCount: 6 },
  { id: 't4', name: '数据同步与校验模板', type: '数据同步', stepCount: 5 }
];

const templateDecomposeMap: Record<string, { subtasks: any[]; workUnits: any[] }> = {
  t1: {
    subtasks: [
      { id: 's1-1', stepName: '数据源接入', taskType: 'auto' },
      { id: 's1-2', stepName: '数据清洗转换', taskType: 'auto' },
      { id: 's1-3', stepName: '数据质量校验', taskType: 'auto' },
      { id: 's1-4', stepName: '数据入库存储', taskType: 'auto' }
    ],
    workUnits: [
      { id: 'wu-1-1', parentSubtaskId: 's1-1', unitName: 'MySQL源数据读取', assignedUnit: '数据平台部', executor: '张明远', description: '从MySQL业务库读取当日增量数据' },
      { id: 'wu-1-2', parentSubtaskId: 's1-2', unitName: '数据标准化清洗', assignedUnit: '数据平台部', executor: '李华', description: '执行数据清洗规则，处理空值和异常值' },
      { id: 'wu-1-3', parentSubtaskId: 's1-2', unitName: '字段映射转换', assignedUnit: '数据治理组', executor: '王芳', description: '将源字段映射到目标数据仓库标准字段' },
      { id: 'wu-1-4', parentSubtaskId: 's1-3', unitName: '完整性校验', assignedUnit: '质量监控组', executor: '陈刚', description: '校验数据记录数和字段完整性' },
      { id: 'wu-1-5', parentSubtaskId: 's1-3', unitName: '业务规则校验', assignedUnit: '质量监控组', executor: '赵丽', description: '按业务规则验证数据合理性' },
      { id: 'wu-1-6', parentSubtaskId: 's1-4', unitName: 'Hive分区写入', assignedUnit: '数据平台部', executor: '张明远', description: '按日期分区写入Hive目标表' }
    ]
  },
  t2: {
    subtasks: [
      { id: 's2-1', stepName: '文件源扫描', taskType: 'auto' },
      { id: 's2-2', stepName: 'CSV格式转换', taskType: 'auto' },
      { id: 's2-3', stepName: 'JSON格式转换', taskType: 'auto' },
      { id: 's2-4', stepName: 'XML格式转换', taskType: 'auto' },
      { id: 's2-5', stepName: '结果合并汇总', taskType: 'auto' },
      { id: 's2-6', stepName: '写入目标存储', taskType: 'auto' }
    ],
    workUnits: [
      { id: 'wu-2-1', parentSubtaskId: 's2-1', unitName: 'HDFS目录扫描', assignedUnit: '数据平台部', executor: '刘晓峰', description: '扫描HDFS源目录发现待处理文件' },
      { id: 'wu-2-2', parentSubtaskId: 's2-2', unitName: 'CSV解析与清洗', assignedUnit: '文件处理组', executor: '杨帆', description: '解析CSV文件并进行格式校验' },
      { id: 'wu-2-3', parentSubtaskId: 's2-3', unitName: 'JSON序列化', assignedUnit: '文件处理组', executor: '周杰', description: '将数据转为JSON格式输出' },
      { id: 'wu-2-4', parentSubtaskId: 's2-4', unitName: 'XML结构生成', assignedUnit: '文件处理组', executor: '吴敏', description: '按预定义XML Schema生成结构化文件' },
      { id: 'wu-2-5', parentSubtaskId: 's2-5', unitName: '多源数据合并', assignedUnit: '数据平台部', executor: '刘晓峰', description: '将三种格式转换结果合并为统一数据集' },
      { id: 'wu-2-6', parentSubtaskId: 's2-6', unitName: '目标存储写入', assignedUnit: '数据平台部', executor: '刘晓峰', description: '写入HDFS目标路径并生成校验文件' }
    ]
  },
  t3: {
    subtasks: [
      { id: 's3-1', stepName: '数据查询汇总', taskType: 'auto' },
      { id: 's3-2', stepName: '指标计算聚合', taskType: 'auto' },
      { id: 's3-3', stepName: '报表渲染生成', taskType: 'auto' },
      { id: 's3-4', stepName: '邮件分发', taskType: 'auto' },
      { id: 's3-5', stepName: '企微推送', taskType: 'auto' },
      { id: 's3-6', stepName: 'FTP归档', taskType: 'auto' }
    ],
    workUnits: [
      { id: 'wu-3-1', parentSubtaskId: 's3-1', unitName: 'Presto查询执行', assignedUnit: '数据分析部', executor: '马晓丽', description: '通过Presto引擎执行月度汇总SQL模板' },
      { id: 'wu-3-2', parentSubtaskId: 's3-2', unitName: '财务指标计算', assignedUnit: '数据分析部', executor: '马晓丽', description: '计算收入/成本/利润/增长率等核心指标' },
      { id: 'wu-3-3', parentSubtaskId: 's3-3', unitName: 'PDF报表渲染', assignedUnit: '报表中心', executor: '孙阳', description: '使用报表模板渲染生成PDF格式输出' },
      { id: 'wu-3-4', parentSubtaskId: 's3-4', unitName: '邮件通知发送', assignedUnit: '运维支持组', executor: '郑涛', description: '向管理层邮箱群发月度汇总报表' },
      { id: 'wu-3-5', parentSubtaskId: 's3-5', unitName: '企微消息推送', assignedUnit: '运维支持组', executor: '郑涛', description: '向相关部门企微群推送报表摘要' },
      { id: 'wu-3-6', parentSubtaskId: 's3-6', unitName: 'FTP归档存储', assignedUnit: '运维支持组', executor: '郑涛', description: '将报表文件归档至FTP历史存档目录' }
    ]
  },
  t4: {
    subtasks: [
      { id: 's4-1', stepName: '源端数据读取', taskType: 'auto' },
      { id: 's4-2', stepName: '数据差异对比', taskType: 'auto' },
      { id: 's4-3', stepName: '数据格式规范化', taskType: 'auto' },
      { id: 's4-4', stepName: '校验规则执行', taskType: 'auto' },
      { id: 's4-5', stepName: '目标端写入确认', taskType: 'auto' }
    ],
    workUnits: [
      { id: 'wu-4-1', parentSubtaskId: 's4-1', unitName: '源库全量读取', assignedUnit: '数据平台部', executor: '杨帆', description: '从PostgreSQL源库全量读取待同步表数据' },
      { id: 'wu-4-2', parentSubtaskId: 's4-2', unitName: '差异数据识别', assignedUnit: '数据平台部', executor: '杨帆', description: '对比源端与目标端数据识别增量/变更/删除' },
      { id: 'wu-4-3', parentSubtaskId: 's4-3', unitName: '数据标准化', assignedUnit: '数据治理组', executor: '王芳', description: '统一数据类型、编码和格式规范' },
      { id: 'wu-4-4', parentSubtaskId: 's4-4', unitName: '质量规则执行', assignedUnit: '质量监控组', executor: '陈刚', description: '执行预定义的50+质量校验规则' },
      { id: 'wu-4-5', parentSubtaskId: 's4-5', unitName: '目标库事务写入', assignedUnit: '数据平台部', executor: '杨帆', description: '以事务方式写入目标库，保证数据一致性' }
    ]
  }
};

const mockProcessors: Processor[] = [
  { id: 'p1', name: 'Spark集群-主节点01', available: true },
  { id: 'p2', name: 'Spark集群-工作节点02', available: true },
  { id: 'p3', name: 'Flink集群-节点01', available: true },
  { id: 'p4', name: 'Flink集群-节点02', available: false },
  { id: 'p5', name: 'Presto查询引擎节点', available: true },
  { id: 'p6', name: 'GPU计算节点-A100-01', available: false }
];

const mockTaskNodes: TaskNode[] = [
  { id: 'n1', name: '主调度节点' },
  { id: 'n2', name: '备调度节点' },
  { id: 'n3', name: '区域节点-华东' },
  { id: 'n4', name: '区域节点-华南' }
];

const mockDispatchHistory: DispatchRecord[] = [
  { time: '2026-07-22 14:30:00', taskName: '电商平台日度数据ETL清洗任务', mode: '手动下发', status: '已完成' },
  { time: '2026-07-22 10:15:00', taskName: '智能报表系统月度财务汇总', mode: '定时调度', status: '运行中' },
  { time: '2026-07-21 16:00:00', taskName: '物流仓储库存数据同步任务', mode: '手动下发', status: '等待中' }
];

const mockExecutionLogs_001: ExecutionLog[] = [
  { time: '2026-07-22 14:30:05', level: 'info', content: '[初始化] 任务 EXEC-20260722-001 开始执行，分配资源模板 RST-001' },
  { time: '2026-07-22 14:30:10', level: 'info', content: '[数据源接入] 连接MySQL源数据库成功，表数量: 12' },
  { time: '2026-07-22 14:30:40', level: 'info', content: '[数据源接入] 数据抽取完成，记录数: 2,458,391 条' },
  { time: '2026-07-22 14:30:41', level: 'info', content: '[数据清洗转换] 开始执行数据清洗规则: standard' },
  { time: '2026-07-22 14:32:20', level: 'warn', content: '[数据清洗转换] 发现空值字段 order_detail.product_tag，已填充默认值' },
  { time: '2026-07-22 14:35:00', level: 'info', content: '[数据清洗转换] 清洗完成，有效记录: 2,455,102 条 (清洗率 99.87%)' },
  { time: '2026-07-22 14:35:01', level: 'info', content: '[数据质量校验] 启动质量校验规则，阈值: 0.95' },
  { time: '2026-07-22 14:36:30', level: 'info', content: '[数据质量校验] 校验通过，质量得分: 0.982' },
  { time: '2026-07-22 14:36:31', level: 'info', content: '[数据入库存储] 开始写入 Hive 目标表: dwd_order_daily' }
];

const mockExecutionLogs_002: ExecutionLog[] = [
  { time: '2026-07-22 10:15:00', level: 'info', content: '[初始化] 任务 EXEC-20260722-002 定时触发，开始执行' },
  { time: '2026-07-22 10:15:05', level: 'info', content: '[数据查询汇总] 连接Presto引擎成功，执行预定义SQL模板' },
  { time: '2026-07-22 10:16:30', level: 'info', content: '[指标计算聚合] 计算7月财务指标: 收入/成本/利润/增长率' },
  { time: '2026-07-22 10:17:45', level: 'info', content: '[报表渲染生成] 正在生成PDF格式财务汇总报表...' }
];

const mockExecutionLogs_003: ExecutionLog[] = [
  { time: '2026-07-22 09:00:00', level: 'info', content: '[初始化] 任务 EXEC-20260722-003 开始执行' },
  { time: '2026-07-22 09:00:05', level: 'info', content: '[文件源扫描] 扫描 /data/raw/region_logs 目录' },
  { time: '2026-07-22 09:00:15', level: 'info', content: '[文件源扫描] 发现待处理文件: 48个' },
  { time: '2026-07-22 09:01:00', level: 'error', content: '[CSV格式转换] 文件 region_log_031.csv 格式异常: 第12405行字段数不匹配，已跳过' },
  { time: '2026-07-22 09:02:30', level: 'warn', content: '[CSV格式转换] 3个文件存在编码问题，已自动切换为GBK编码重试' }
];

const mockExecutionLogs_004: ExecutionLog[] = [
  { time: '2026-07-21 16:00:00', level: 'info', content: '[初始化] 任务 EXEC-20260721-001 下发成功，等待资源分配...' },
  { time: '2026-07-21 16:00:05', level: 'warn', content: '[资源调度] 目标节点 区域节点-华南 资源使用率 87%，排队等待中' }
];

const mockExecutionLogs_005: ExecutionLog[] = [
  { time: '2026-07-21 08:00:00', level: 'info', content: '[初始化] 任务 EXEC-20260721-002 开始执行' },
  { time: '2026-07-21 08:30:00', level: 'info', content: '[模型训练] 开始金融风控模型训练，数据量: 500万条' },
  { time: '2026-07-21 12:00:00', level: 'error', content: '[模型训练] GPU显存溢出(OOM)，训练中断。当前batch_size: 256，建议调整为128' },
  { time: '2026-07-21 12:01:00', level: 'error', content: '[任务终止] 任务因GPU资源不足自动终止，请联系管理员调整资源配置后重试' }
];

const mockExecutionLogs_006: ExecutionLog[] = [
  { time: '2026-07-20 20:00:00', level: 'info', content: '[初始化] 任务 EXEC-20260720-001 定时触发' },
  { time: '2026-07-20 20:00:10', level: 'info', content: '[源端数据读取] 读取MySQL主库用户标签表，记录数: 12,800,000' },
  { time: '2026-07-20 22:00:00', level: 'info', content: '[数据差异对比] 对比完成，新增标签: 245,000，变更: 1,200,000，删除: 8,500' },
  { time: '2026-07-20 23:30:00', level: 'info', content: '[校验规则执行] 标签数据校验通过，准确率: 99.95%' },
  { time: '2026-07-21 01:00:00', level: 'info', content: '[目标端写入确认] 写入ElasticSearch索引 user_tags_v3 完成' },
  { time: '2026-07-21 01:01:00', level: 'info', content: '[完成] 任务 EXEC-20260720-001 执行成功，总耗时: 5h01min' }
];

const mockExecutionList: ExecutionRecord[] = [
  {
    taskId: 'EXEC-20260722-001',
    taskName: '电商平台日度数据ETL清洗任务',
    mode: '手动下发',
    progress: 78,
    status: 'running',
    currentStep: '数据入库存储',
    startTime: '2026-07-22 14:30:00',
    logs: mockExecutionLogs_001
  },
  {
    taskId: 'EXEC-20260722-002',
    taskName: '智能报表系统月度财务汇总',
    mode: '定时调度',
    progress: 45,
    status: 'running',
    currentStep: '报表渲染生成',
    startTime: '2026-07-22 10:15:00',
    logs: mockExecutionLogs_002
  },
  {
    taskId: 'EXEC-20260722-003',
    taskName: '批量日志文件转换任务',
    mode: '手动下发',
    progress: 100,
    status: 'completed',
    currentStep: '已完成',
    startTime: '2026-07-22 09:00:00',
    logs: mockExecutionLogs_003
  },
  {
    taskId: 'EXEC-20260721-001',
    taskName: '物流仓储库存数据同步任务',
    mode: '手动下发',
    progress: 5,
    status: 'waiting',
    currentStep: '源端数据读取',
    startTime: '2026-07-21 16:00:00',
    logs: mockExecutionLogs_004
  },
  {
    taskId: 'EXEC-20260721-002',
    taskName: '金融风控模型特征工程批处理',
    mode: '定时调度',
    progress: 32,
    status: 'failed',
    currentStep: '模型训练',
    startTime: '2026-07-21 08:00:00',
    logs: mockExecutionLogs_005
  },
  {
    taskId: 'EXEC-20260720-001',
    taskName: '营销活动用户标签全量刷新',
    mode: '定时调度',
    progress: 100,
    status: 'completed',
    currentStep: '已完成',
    startTime: '2026-07-20 20:00:00',
    logs: mockExecutionLogs_006
  }
];

const mockMonitorStats: MonitorStat[] = [
  { label: '运行中', value: 3, color: '#409EFF' },
  { label: '等待中', value: 2, color: '#E6A23C' },
  { label: '已完成', value: 8, color: '#67C23A' },
  { label: '失败', value: 1, color: '#F56C6C' }
];

const mockMonitorTasks: MonitorTask[] = [
  { taskId: 'EXEC-20260722-001', taskName: '电商平台日度数据ETL清洗任务', node: '主调度节点', progress: 78, status: 'running', cpuUsage: 72.5, memoryUsage: 58.3, elapsed: '2h15min' },
  { taskId: 'EXEC-20260722-002', taskName: '智能报表系统月度财务汇总', node: '区域节点-华东', progress: 45, status: 'running', cpuUsage: 45.8, memoryUsage: 32.1, elapsed: '1h30min' },
  { taskId: 'EXEC-20260722-004', taskName: '用户行为日志实时分析', node: '主调度节点', progress: 12, status: 'running', cpuUsage: 88.2, memoryUsage: 74.6, elapsed: '20min' }
];

const mockQueryResults: QueryResult[] = [
  {
    taskId: 'EXEC-20260722-001',
    taskName: '电商平台日度数据ETL清洗任务',
    templateName: '标准数据处理调度模板',
    execMode: '手动下发',
    startTime: '2026-07-22 14:30:00',
    endTime: '',
    duration: '进行中',
    status: 'running',
    priority: 'urgent',
    operator: '张明远',
    steps: [
      { stepName: '数据源接入', status: 'completed', startTime: '2026-07-22 14:30:05', endTime: '2026-07-22 14:30:40' },
      { stepName: '数据清洗转换', status: 'completed', startTime: '2026-07-22 14:30:41', endTime: '2026-07-22 14:35:00' },
      { stepName: '数据质量校验', status: 'completed', startTime: '2026-07-22 14:35:01', endTime: '2026-07-22 14:36:30' },
      { stepName: '数据入库存储', status: 'running', startTime: '2026-07-22 14:36:31', endTime: '' }
    ]
  },
  {
    taskId: 'EXEC-20260722-002',
    taskName: '智能报表系统月度财务汇总',
    templateName: '报表生成与分发模板',
    execMode: '定时调度',
    startTime: '2026-07-22 10:15:00',
    endTime: '',
    duration: '进行中',
    status: 'running',
    priority: 'normal',
    operator: '马晓丽',
    steps: [
      { stepName: '数据查询汇总', status: 'completed', startTime: '2026-07-22 10:15:05', endTime: '2026-07-22 10:16:30' },
      { stepName: '指标计算聚合', status: 'completed', startTime: '2026-07-22 10:16:31', endTime: '2026-07-22 10:17:30' },
      { stepName: '报表渲染生成', status: 'running', startTime: '2026-07-22 10:17:31', endTime: '' }
    ]
  },
  {
    taskId: 'EXEC-20260722-003',
    taskName: '批量日志文件转换任务',
    templateName: '批量文件转换调度模板',
    execMode: '手动下发',
    startTime: '2026-07-22 09:00:00',
    endTime: '2026-07-22 11:30:00',
    duration: '2h30min',
    status: 'completed',
    priority: 'high',
    operator: '刘晓峰',
    steps: [
      { stepName: '文件源扫描', status: 'completed', startTime: '2026-07-22 09:00:05', endTime: '2026-07-22 09:00:15' },
      { stepName: 'CSV格式转换', status: 'completed', startTime: '2026-07-22 09:00:16', endTime: '2026-07-22 10:30:00' },
      { stepName: 'JSON格式转换', status: 'completed', startTime: '2026-07-22 09:00:16', endTime: '2026-07-22 10:15:00' },
      { stepName: 'XML格式转换', status: 'completed', startTime: '2026-07-22 09:00:16', endTime: '2026-07-22 10:45:00' },
      { stepName: '结果合并汇总', status: 'completed', startTime: '2026-07-22 10:45:01', endTime: '2026-07-22 11:10:00' },
      { stepName: '写入目标存储', status: 'completed', startTime: '2026-07-22 11:10:01', endTime: '2026-07-22 11:30:00' }
    ]
  },
  {
    taskId: 'EXEC-20260721-001',
    taskName: '物流仓储库存数据同步任务',
    templateName: '数据同步与校验模板',
    execMode: '手动下发',
    startTime: '2026-07-21 16:00:00',
    endTime: '',
    duration: '等待中',
    status: 'waiting',
    priority: 'high',
    operator: '杨帆',
    steps: [
      { stepName: '源端数据读取', status: 'waiting', startTime: '', endTime: '' },
      { stepName: '数据差异对比', status: 'waiting', startTime: '', endTime: '' },
      { stepName: '数据格式规范化', status: 'waiting', startTime: '', endTime: '' },
      { stepName: '校验规则执行', status: 'waiting', startTime: '', endTime: '' },
      { stepName: '目标端写入确认', status: 'waiting', startTime: '', endTime: '' }
    ]
  },
  {
    taskId: 'EXEC-20260721-002',
    taskName: '金融风控模型特征工程批处理',
    templateName: '批量文件转换调度模板',
    execMode: '定时调度',
    startTime: '2026-07-21 08:00:00',
    endTime: '2026-07-21 12:01:00',
    duration: '4h01min',
    status: 'failed',
    priority: 'high',
    operator: '刘晓峰',
    steps: [
      { stepName: '文件源扫描', status: 'completed', startTime: '2026-07-21 08:00:05', endTime: '2026-07-21 08:10:00' },
      { stepName: 'CSV格式转换', status: 'completed', startTime: '2026-07-21 08:10:01', endTime: '2026-07-21 11:30:00' },
      { stepName: 'JSON格式转换', status: 'completed', startTime: '2026-07-21 08:10:01', endTime: '2026-07-21 11:45:00' },
      { stepName: 'XML格式转换', status: 'failed', startTime: '2026-07-21 08:10:01', endTime: '2026-07-21 12:01:00' }
    ]
  }
];

/** 获取可下发模板列表 - GET /task-scheduling/dispatch/templates */
export function getDispatchTemplateList(): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: mockDispatchTemplateList,
    msg: 'ok'
  });
}

/** 执行任务分解 - POST /task-scheduling/dispatch/decompose/{templateId} */
export function executeDecompose(templateId: string): Promise<any> {
  const decomposeData = templateDecomposeMap[templateId] || { subtasks: [], workUnits: [] };
  return Promise.resolve({
    code: 200,
    data: decomposeData,
    msg: decomposeData.subtasks.length > 0 ? '任务分解成功' : '未找到该模板的分解配置'
  });
}

const mockRecommendedTemplateList = [
  {
    id: 'rt1',
    name: '标准ETL处理推荐流程',
    description: '适用于常规数据ETL场景，包含数据接入-清洗-校验-入库标准链路',
    nodes: [
      { id: 'rt-n1', type: 'custom', position: { x: 100, y: 200 }, data: { label: '数据接入', nodeType: 'DATA_SOURCE', description: '从数据源读取数据' } },
      { id: 'rt-n2', type: 'custom', position: { x: 350, y: 200 }, data: { label: '数据清洗', nodeType: 'SHELL', description: '执行数据清洗脚本' } },
      { id: 'rt-n3', type: 'custom', position: { x: 600, y: 200 }, data: { label: '质量校验', nodeType: 'SQL', description: 'SQL校验规则' } },
      { id: 'rt-n4', type: 'custom', position: { x: 850, y: 200 }, data: { label: '数据入库', nodeType: 'SQL', description: '写入目标数据库' } }
    ],
    edges: [
      { id: 'rt-e1', source: 'rt-n1', target: 'rt-n2', sourceHandle: 'right-source', targetHandle: 'left-target' },
      { id: 'rt-e2', source: 'rt-n2', target: 'rt-n3', sourceHandle: 'right-source', targetHandle: 'left-target' },
      { id: 'rt-e3', source: 'rt-n3', target: 'rt-n4', sourceHandle: 'right-source', targetHandle: 'left-target' }
    ]
  },
  {
    id: 'rt2',
    name: '并行处理推荐流程',
    description: '适用于需要多路并行处理的场景，含条件分支和结果合并',
    nodes: [
      { id: 'rt2-n1', type: 'custom', position: { x: 100, y: 200 }, data: { label: '文件扫描', nodeType: 'DATA_SOURCE', description: '扫描源文件目录' } },
      { id: 'rt2-n2', type: 'custom', position: { x: 350, y: 100 }, data: { label: '格式转换A', nodeType: 'SPARK', description: 'Spark并行处理A组' } },
      { id: 'rt2-n3', type: 'custom', position: { x: 350, y: 300 }, data: { label: '格式转换B', nodeType: 'SPARK', description: 'Spark并行处理B组' } },
      { id: 'rt2-n4', type: 'custom', position: { x: 600, y: 200 }, data: { label: '结果合并', nodeType: 'MERGE', description: '合并并行处理结果' } },
      { id: 'rt2-n5', type: 'custom', position: { x: 850, y: 200 }, data: { label: '结果输出', nodeType: 'DATA_TRANSFER', description: '输出到目标存储' } }
    ],
    edges: [
      { id: 'rt2-e1', source: 'rt2-n1', target: 'rt2-n2', sourceHandle: 'right-source', targetHandle: 'left-target' },
      { id: 'rt2-e2', source: 'rt2-n1', target: 'rt2-n3', sourceHandle: 'right-source', targetHandle: 'left-target' },
      { id: 'rt2-e3', source: 'rt2-n2', target: 'rt2-n4', sourceHandle: 'right-source', targetHandle: 'left-target' },
      { id: 'rt2-e4', source: 'rt2-n3', target: 'rt2-n4', sourceHandle: 'right-source', targetHandle: 'left-target' },
      { id: 'rt2-e5', source: 'rt2-n4', target: 'rt2-n5', sourceHandle: 'right-source', targetHandle: 'left-target' }
    ]
  }
];

/** 获取推荐流程配置模板 - GET /task-scheduling/dispatch/recommended-templates */
export function getRecommendedTemplates(): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: mockRecommendedTemplateList,
    msg: 'ok'
  });
}

/** 获取可用处理器列表 - GET /task-scheduling/dispatch/processors */
export function getAvailableProcessors(): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: mockProcessors,
    msg: 'ok'
  });
}

/** 获取节点列表 - GET /task-scheduling/dispatch/nodes */
export function getNodeList(): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: mockTaskNodes,
    msg: 'ok'
  });
}

/** 保存调度配置 - POST /task-scheduling/dispatch/config */
export function saveDispatchConfig(data: any): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: null,
    msg: '调度配置保存成功'
  });
}

/** 提交调度下发 - POST /task-scheduling/dispatch/submit */
export function submitDispatch(data: any): Promise<any> {
  const newRecord: DispatchRecord = {
    time: new Date().toISOString().replace('T', ' ').substring(0, 19),
    taskName: '新下发任务',
    mode: data.dispatchType === 'scheduled' ? '定时调度' : '手动下发',
    status: '等待中'
  };
  return Promise.resolve({
    code: 200,
    data: newRecord,
    msg: '任务下发成功'
  });
}

/** 获取下发历史 - GET /task-scheduling/dispatch/history */
export function getDispatchHistory(): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: mockDispatchHistory,
    msg: 'ok'
  });
}

/** 获取执行列表 - GET /task-scheduling/execution/list */
export function getExecutionList(params: any): Promise<any> {
  let filtered = [...mockExecutionList];
  if (params.taskName) {
    filtered = filtered.filter(item => item.taskName.includes(params.taskName!));
  }
  if (params.status) {
    filtered = filtered.filter(item => item.status === params.status);
  }
  const pageNum = params.pageNum || 1;
  const pageSize = params.pageSize || 10;
  const start = (pageNum - 1) * pageSize;
  const rows = filtered.slice(start, start + pageSize);
  return Promise.resolve({
    code: 200,
    data: { rows, total: filtered.length },
    msg: 'ok'
  });
}

/** 暂停执行 - PUT /task-scheduling/execution/pause/{id} */
export function pauseExecution(id: string): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: null,
    msg: '任务暂停成功'
  });
}

/** 恢复执行 - PUT /task-scheduling/execution/resume/{id} */
export function resumeExecution(id: string): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: null,
    msg: '任务恢复成功'
  });
}

/** 取消执行 - PUT /task-scheduling/execution/cancel/{id} */
export function cancelExecution(id: string): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: null,
    msg: '任务取消成功'
  });
}

/** 重试执行 - PUT /task-scheduling/execution/retry/{id} */
export function retryExecution(id: string): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: null,
    msg: '任务重试已提交'
  });
}

/** 获取执行日志 - GET /task-scheduling/execution/logs/{id} */
export function getExecutionLogs(id: string): Promise<any> {
  const execution = mockExecutionList.find(item => item.taskId === id);
  return Promise.resolve({
    code: 200,
    data: execution?.logs || [],
    msg: 'ok'
  });
}

/** 获取监控统计 - GET /task-scheduling/monitor/stats */
export function getMonitorStats(): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: mockMonitorStats,
    msg: 'ok'
  });
}

/** 获取监控任务列表 - GET /task-scheduling/monitor/tasks */
export function getMonitorTasks(): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: mockMonitorTasks,
    msg: 'ok'
  });
}

/** 查询下发记录 - GET /task-scheduling/dispatch/records */
export function queryDispatchRecords(params: any): Promise<any> {
  let filtered = [...mockQueryResults];
  if (params.taskName) {
    filtered = filtered.filter(item => item.taskName.includes(params.taskName!));
  }
  if (params.status) {
    filtered = filtered.filter(item => item.status === params.status);
  }
  if (params.priority) {
    filtered = filtered.filter(item => item.priority === params.priority);
  }
  const pageNum = params.pageNum || 1;
  const pageSize = params.pageSize || 10;
  const start = (pageNum - 1) * pageSize;
  const rows = filtered.slice(start, start + pageSize);
  return Promise.resolve({
    code: 200,
    data: { rows, total: filtered.length },
    msg: 'ok'
  });
}

/* ================================================================
 *  资源配置 (Resource Config)
 * ================================================================ */

const mockConfigList: ResourceConfigVO[] = [
  {
    id: 'RC-001',
    templateName: '标准数据处理调度模板',
    assignedNode: '主调度节点',
    operator: '张明远',
    assignTime: '2026-07-20 10:00:00',
    status: '已生效'
  },
  {
    id: 'RC-002',
    templateName: '批量文件转换调度模板',
    assignedNode: '区域节点-华东',
    operator: '刘晓峰',
    assignTime: '2026-07-20 14:30:00',
    status: '已生效'
  },
  {
    id: 'RC-003',
    templateName: '报表生成与分发模板',
    assignedNode: '区域节点-华南',
    operator: '马晓丽',
    assignTime: '2026-07-21 09:15:00',
    status: '已生效'
  },
  {
    id: 'RC-004',
    templateName: '数据同步与校验模板',
    assignedNode: '备调度节点',
    operator: '杨帆',
    assignTime: '2026-07-21 11:00:00',
    status: '待生效'
  },
  {
    id: 'RC-005',
    templateName: '用户标签全量刷新任务模板',
    assignedNode: '主调度节点',
    operator: '何静',
    assignTime: '2026-07-22 08:00:00',
    status: '已失效'
  },
  {
    id: 'RC-006',
    templateName: '金融风控模型定时训练模板',
    assignedNode: '区域节点-华南',
    operator: '刘晓峰',
    assignTime: '2026-07-22 15:45:00',
    status: '待分配'
  }
];

/** 获取资源配置列表 - GET /task-scheduling/resource-config/list */
export function getConfigList(params: any): Promise<any> {
  let filtered = [...mockConfigList];
  if (params.templateName) {
    filtered = filtered.filter(item => item.templateName.includes(params.templateName!));
  }
  if (params.status) {
    filtered = filtered.filter(item => item.status === params.status);
  }
  const pageNum = params.pageNum || 1;
  const pageSize = params.pageSize || 10;
  const start = (pageNum - 1) * pageSize;
  const rows = filtered.slice(start, start + pageSize);
  return Promise.resolve({
    code: 200,
    data: { rows, total: filtered.length },
    msg: 'ok'
  });
}

/** 创建资源配置 - POST /task-scheduling/resource-config */
export function createConfig(data: any): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: null,
    msg: '资源配置创建成功'
  });
}

/** 更新资源配置 - PUT /task-scheduling/resource-config */
export function updateConfig(data: any): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: null,
    msg: '资源配置更新成功'
  });
}

/** 删除资源配置 - DELETE /task-scheduling/resource-config/{id} */
export function deleteConfig(id: string): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: null,
    msg: '资源配置删除成功'
  });
}

/* ================================================================
 *  任务导出 (Task Export)
 * ================================================================ */

const mockExportList: TaskExportVO[] = [
  {
    id: 'EXP-001',
    taskName: '电商平台日度数据ETL清洗任务',
    exportType: '执行日志',
    format: 'PDF',
    dataScope: '最近7天',
    status: 'completed',
    fileSize: '12.5 MB',
    operator: '张明远',
    createTime: '2026-07-22 16:00:00',
    completeTime: '2026-07-22 16:03:00',
    downloadUrl: '/download/export/EXP-001.pdf'
  },
  {
    id: 'EXP-002',
    taskName: '智能报表系统月度财务汇总',
    exportType: '报表数据',
    format: 'Excel',
    dataScope: '7月份全量',
    status: 'completed',
    fileSize: '8.2 MB',
    operator: '马晓丽',
    createTime: '2026-07-22 12:00:00',
    completeTime: '2026-07-22 12:05:00',
    downloadUrl: '/download/export/EXP-002.xlsx'
  },
  {
    id: 'EXP-003',
    taskName: '物流仓储库存数据同步任务',
    exportType: '执行记录',
    format: 'CSV',
    dataScope: '自定义范围',
    status: 'processing',
    fileSize: '',
    operator: '杨帆',
    createTime: '2026-07-22 15:30:00',
    completeTime: '',
    downloadUrl: ''
  },
  {
    id: 'EXP-004',
    taskName: '批量日志文件转换任务',
    exportType: '执行日志',
    format: 'JSON',
    dataScope: '单次执行',
    status: 'completed',
    fileSize: '3.8 MB',
    operator: '刘晓峰',
    createTime: '2026-07-21 17:00:00',
    completeTime: '2026-07-21 17:02:00',
    downloadUrl: '/download/export/EXP-004.json'
  },
  {
    id: 'EXP-005',
    taskName: '金融风控模型特征工程批处理',
    exportType: '错误日志',
    format: 'PDF',
    dataScope: '单次执行',
    status: 'failed',
    fileSize: '',
    operator: '刘晓峰',
    createTime: '2026-07-21 13:00:00',
    completeTime: '2026-07-21 13:01:00',
    downloadUrl: ''
  }
];

/** 获取导出列表 - GET /task-scheduling/export/list */
export function getExportList(params: any): Promise<any> {
  let filtered = [...mockExportList];
  if (params.taskName) {
    filtered = filtered.filter(item => item.taskName.includes(params.taskName!));
  }
  if (params.status) {
    filtered = filtered.filter(item => item.status === params.status);
  }
  if (params.format) {
    filtered = filtered.filter(item => item.format === params.format);
  }
  const pageNum = params.pageNum || 1;
  const pageSize = params.pageSize || 10;
  const start = (pageNum - 1) * pageSize;
  const rows = filtered.slice(start, start + pageSize);
  return Promise.resolve({
    code: 200,
    data: { rows, total: filtered.length },
    msg: 'ok'
  });
}

/** 创建导出任务 - POST /task-scheduling/export */
export function createExport(data: any): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: null,
    msg: '导出任务创建成功，请稍后在列表中查看'
  });
}

/** 下载导出文件 - GET /task-scheduling/export/download/{id} */
export function downloadExportFile(id: string): Promise<any> {
  return Promise.resolve({
    code: 200,
    data: null,
    msg: '文件下载已开始'
  });
}
