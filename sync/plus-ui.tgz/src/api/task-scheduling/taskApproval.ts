import request from '@/utils/request';
import { tansParams } from '@/utils/ruoyi';

/**
 * 任务审批 - 任务表写操作接口（后端任务表，非海豚项目）
 * 列表查询仍走 /workflow/main/project/page（见 dolphinscheduler/projects）
 */

/** 创建任务 */
export function createTask(data: any) {
  return request({ url: '/dolphinscheduler/main/projects', method: 'post', data });
}

/** 修改任务 */
export function updateTask(data: any) {
  return request({ url: '/dolphinscheduler/main/projects', method: 'put', data });
}

/** 删除任务 */
export function deleteTask(id: string | number) {
  return request({ url: `/dolphinscheduler/main/projects/${id}`, method: 'delete' });
}

/**
 * 主任务一键下发
 * POST /main/projects/{id}/dispatch
 * 按主任务维度下发：主任务下的子任务（海豚项目）流程配置齐备后一次性下发
 */
export function dispatchMainProject(id: string | number) {
  return request({ url: `/dolphinscheduler/main/projects/${id}/dispatch`, method: 'post' });
}

/**
 * 提交审批并启动流程
 *
 * @param id      主任务ID
 * @param handler 审批人用户ID（可选）：传递后由流程引擎把首节点办理人覆盖为该用户。
 *                依赖后端 /workflow/main/project/submitAndFlowStart/{id} 支持 handler 参数
 *                （见「任务审批-选择审批人-后端配合说明.md」）。
 */
export function submitApprovalFlow(id: string | number, handler?: string | number) {
  return request({
    url: `/workflow/main/project/submitAndFlowStart/${id}`,
    method: 'post',
    params: handler ? { handler } : undefined
  });
}

/** 分解任务：创建子项目（任务名称 + 任务描述，关联到当前主项目） */
export function createSubProject(data: any) {
  return request({
    url: '/dolphinscheduler/projects',
    method: 'post',
    data,
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    transformRequest: [tansParams]
  });
}

/** 查询主项目下的所有子项目 */
export function queryProjectsByMainProjectId(id: string | number) {
  return request({ url: `/dolphinscheduler/main/projects/queryAllProjectByMainProjectId/${id}`, method: 'get' });
}

/** 修改子项目 */
export function updateSubProject(code: string | number, data: any) {
  return request({
    url: `/dolphinscheduler/projects/${code}`,
    method: 'put',
    data,
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    transformRequest: [tansParams]
  });
}

/** 删除子项目 */
export function deleteSubProject(code: string | number) {
  return request({ url: `/dolphinscheduler/projects/${code}`, method: 'delete' });
}

/**
 * 按调度模板分解主任务：
 * 后端按模板项创建子任务；模板项若绘制过流程图，则把该流程图复制成子任务的流程图。
 */
export function decomposeByTemplate(mainProjectId: string | number, templateId: string | number) {
  return request({
    url: `/dolphinscheduler/main/projects/${mainProjectId}/decompose?templateId=${templateId}`,
    method: 'post'
  });
}
