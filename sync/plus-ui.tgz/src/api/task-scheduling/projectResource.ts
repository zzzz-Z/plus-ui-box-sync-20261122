import request from '@/utils/request';

/**
 * 任务级资源挂接（真实接口）
 *
 * 后端：ruoyi-task-manage / dispatch.projectwork
 *  - POST   /main/projects/{projectId}/work-posts        body: [postId, ...]
 *  - GET    /main/projects/{projectId}/work-posts
 *  - DELETE /main/projects/{projectId}/work-posts/{postId}
 *  - POST   /main/projects/{projectId}/work-units?workUnitId=xx
 *  - GET    /main/projects/{projectId}/work-units
 *  - DELETE /main/projects/{projectId}/work-units/{workUnitId}
 *
 * 说明：配置粒度是「子任务（海豚 project）」；主任务 → 子任务用 queryAllProjectByMainProjectId 取。
 */
export const PROJECT_BASE = '/dolphinscheduler/main/projects';

/** 子任务已配置岗位（ProjectWorkPost） */
export interface ProjectWorkPost {
  id?: number;
  projectId?: number;
  postId?: number;
  postCode?: string;
  postName?: string;
  postType?: string;
  /** 岗位占用状态（后端读取字段，当前无写入方） */
  occupyStatus?: string;
  occupySubTaskNo?: string;
  flag?: number;
  createBy?: string;
  createTime?: string;
}

/** 子任务已挂接单元（ProjectWorkUnitVO） */
export interface ProjectWorkUnit {
  id?: number;
  projectId?: number;
  workUnitId?: number;
  unitCode?: string;
  unitName?: string;
  unitVersion?: string;
  sortOrder?: number;
  createTime?: string;
}

/** 查询子任务已配置岗位 */
export function listProjectWorkPosts(projectId: number | string) {
  return request({ url: `${PROJECT_BASE}/${projectId}/work-posts`, method: 'get' });
}

/** 子任务挂接岗位（批量） */
export function bindProjectWorkPosts(projectId: number | string, postIds: Array<number | string>) {
  return request({ url: `${PROJECT_BASE}/${projectId}/work-posts`, method: 'post', data: postIds });
}

/** 子任务解绑岗位 */
export function unbindProjectWorkPost(projectId: number | string, postId: number | string) {
  return request({ url: `${PROJECT_BASE}/${projectId}/work-posts/${postId}`, method: 'delete' });
}

/** 查询子任务已挂接单元 */
export function listProjectWorkUnits(projectId: number | string) {
  return request({ url: `${PROJECT_BASE}/${projectId}/work-units`, method: 'get' });
}

/** 子任务挂接单元 */
export function bindProjectWorkUnit(projectId: number | string, workUnitId: number | string) {
  return request({
    url: `${PROJECT_BASE}/${projectId}/work-units`,
    method: 'post',
    params: { workUnitId }
  });
}

/** 子任务解绑单元 */
export function unbindProjectWorkUnit(projectId: number | string, workUnitId: number | string) {
  return request({ url: `${PROJECT_BASE}/${projectId}/work-units/${workUnitId}`, method: 'delete' });
}
