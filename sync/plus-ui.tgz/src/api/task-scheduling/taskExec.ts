import request from '@/utils/request';

/**
 * 执行管理接口（若依 task-manage 模块 TaskExecController）
 *
 * 说明：任务下发改造后，执行管理不再读海豚的流程实例，
 * 改为读「执行计划（t_ds_task_exec_plan）+ 节点执行记录（t_ds_task_node_exec）」。
 * 下发一次子任务生成一个执行计划，计划下一到多个节点执行记录。
 */
/**
 * 实际网关前缀是 /dolphinscheduler（与其它海豚接口一致），
 * 文档里给的是 Controller 的映射路径 `/taskApproval/exec`，直连会 404。
 */
export const EXEC_BASE = '/dolphinscheduler/taskApproval/exec';

/** 执行计划分页查询参数 */
export interface ExecPlanQuery {
  /** 主任务 id（后端必填） */
  mainProjectId: number | string;
  /** 子任务项目 id（可选） */
  projectId?: number | string;
  /** 计划状态（可选，取值以后端枚举为准） */
  status?: string;
  pageNo: number;
  pageSize: number;
}

/** 执行计划分页查询 */
export function queryExecPlanPage(params: ExecPlanQuery) {
  return request({
    url: `${EXEC_BASE}/plan/page`,
    method: 'get',
    params
  });
}

/** 计划下的节点执行记录（含 waitingSeconds 已等待时长） */
export function queryExecPlanNodes(planId: number | string) {
  return request({
    url: `${EXEC_BASE}/plan/${planId}/nodes`,
    method: 'get'
  });
}

/** 节点执行日志（异常 / 成果信息） */
export function queryExecNodeLogs(id: number | string) {
  return request({
    url: `${EXEC_BASE}/node/${id}/logs`,
    method: 'get'
  });
}

/** 节点重试（生成新的执行批次） */
export function retryExecNode(id: number | string) {
  return request({
    url: `${EXEC_BASE}/node/${id}/retry`,
    method: 'post'
  });
}

/** 节点取消 */
export function cancelExecNode(id: number | string) {
  return request({
    url: `${EXEC_BASE}/node/${id}/cancel`,
    method: 'post'
  });
}

/** 执行计划取消（未终态节点一并取消） */
export function cancelExecPlan(planId: number | string) {
  return request({
    url: `${EXEC_BASE}/plan/${planId}/cancel`,
    method: 'post'
  });
}

/* ==================== 以下为 2026-09-23 后端新增能力 ==================== */

/** 计划状态 */
export type PlanStatus = 'NOT_STARTED' | 'RUNNING' | 'PAUSED' | 'SUCCESS' | 'FAILED' | 'CANCELED';

/** 节点状态 */
export type NodeStatus =
  | 'PENDING'
  | 'SUBMITTED'
  | 'WAITING'
  | 'SUCCESS'
  | 'FAILED'
  | 'CANCELED'
  | 'TIMEOUT'
  | 'SKIPPED';

/** 回滚快照 */
export interface TaskExecSnapshot {
  id: number;
  planId: number;
  projectId: number;
  subTaskNo: string;
  nodeCode: number;
  nodeName: string;
  attempt: number;
  status: NodeStatus;
  progress: number;
  resultPath: string | null;
  resultPayload: string | null;
  errorInfo: string | null;
  /** PRE_ROLLBACK：回滚前留存 */
  snapshotType: string;
  snapshotJson: string | null;
  createBy: string | null;
  createTime: string | null;
}

/** 催办记录 */
export interface TaskUrge {
  id: number;
  planId: number;
  projectId: number;
  subTaskNo: string;
  nodeCode: number | null;
  nodeName: string | null;
  unitCode: string | null;
  unitName: string | null;
  /** NODE 催办节点 / UNIT 催办作业单元 */
  targetType: string;
  targetCode: string | null;
  targetName: string | null;
  content: string | null;
  status: 'PENDING' | 'ACKED';
  urgeBy: string | null;
  urgeTime: string | null;
  ackBy: string | null;
  ackTime: string | null;
}

/** 暂停执行计划（仅 RUNNING 可暂停；pausedInstanceCount 常为 0，属正常） */
export function pauseExecPlan(planId: number | string) {
  return request({
    url: `${EXEC_BASE}/plan/${planId}/pause`,
    method: 'post'
  });
}

/** 恢复暂停的执行计划（仅 PAUSED 可恢复；恢复时服务端会自动补跑） */
export function resumeExecPlan(planId: number | string) {
  return request({
    url: `${EXEC_BASE}/plan/${planId}/resume`,
    method: 'post'
  });
}

/**
 * 计划级重运行
 * @param scope failed=仅失败/超时/取消/跳过节点（默认）；all=全部节点重跑（会先停仍在跑的海豚实例）
 */
export function rerunExecPlan(planId: number | string, scope: 'all' | 'failed' = 'failed') {
  return request({
    url: `${EXEC_BASE}/plan/${planId}/rerun`,
    method: 'post',
    params: { scope }
  });
}

/**
 * 回滚到指定节点（该节点 + 全部下游重新执行，上游成果保留）
 * @param nodeCode 取自执行计划节点列表的 nodeCode，不是节点记录 id
 */
export function rollbackExecPlan(planId: number | string, nodeCode: number | string) {
  return request({
    url: `${EXEC_BASE}/plan/${planId}/rollback`,
    method: 'post',
    params: { nodeCode }
  });
}

/** 计划回滚快照列表（按 id 倒序） */
export function queryExecPlanSnapshots(planId: number | string) {
  return request({
    url: `${EXEC_BASE}/plan/${planId}/snapshots`,
    method: 'get'
  });
}

/**
 * 发起催办
 * @param params.nodeCode 不传=对计划下全部未完成节点催办
 * @param params.content  为空时后端默认「任务执行超时，请尽快处理」
 */
export function urgeExecPlan(
  planId: number | string,
  params?: { nodeCode?: number | string; content?: string }
) {
  return request({
    url: `${EXEC_BASE}/plan/${planId}/urge`,
    method: 'post',
    params
  });
}

/** 计划催办记录列表（按 id 倒序） */
export function queryExecPlanUrges(planId: number | string) {
  return request({
    url: `${EXEC_BASE}/plan/${planId}/urges`,
    method: 'get'
  });
}

/** 催办回执（幂等） */
export function ackExecUrge(urgeId: number | string) {
  return request({
    url: `${EXEC_BASE}/urge/${urgeId}/ack`,
    method: 'post'
  });
}
