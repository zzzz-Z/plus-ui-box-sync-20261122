import request from '@/utils/request';

/**
 * 自定义字典（元数据驱动）接口
 *
 * 后端：ruoyi-task-manage common/dict/custom；网关前缀 /dolphinscheduler/customDict/**
 * 与老的固定字段层级字典（/hierDict/**）完全并存、互不影响。
 *
 * 三条必须遵守的约定：
 *  1. 字段定义是「覆盖式保存」：PUT /{dictCode}/fields 要提交全部字段，漏掉的会被删除；
 *  2. 数据过滤：除保留参数（pageNum/pageSize/keyword/status/parentId/orderByColumn/isAsc）外，
 *     其余参数名就是「字段编码」，未定义的字段会被忽略；
 *  3. 新增/修改数据用 { fieldValues: {...} } 包一层。
 */
export const CUSTOM_DICT_BASE = '/dolphinscheduler/customDict';

export interface CustomDictField {
  id?: number;
  dictCode?: string;
  fieldCode: string;
  fieldName: string;
  /** STRING / TEXT / INTEGER / NUMBER / DATE / DATETIME / BOOLEAN / GEOMETRY */
  fieldType: string;
  /** "1"=必填 "0"=否 */
  required?: string;
  /** "1"=唯一 */
  uniqueFlag?: string;
  /** "1"=列表展示 */
  listVisible?: string;
  /** "1"=可检索 */
  searchable?: string;
  sortOrder?: number;
  maxLength?: number | null;
  defaultValue?: string | null;
  options?: any[];
  remark?: string;
}

export interface CustomDict {
  id?: number;
  dictCode?: string;
  dictName?: string;
  /** "1"=层级字典 */
  hierEnabled?: string;
  codeField?: string;
  nameField?: string;
  /** "0"=正常 "1"=停用 */
  status?: string;
  remark?: string;
  /** 新增时可带字段一并保存；修改时不要传（会覆盖式删字段） */
  fields?: CustomDictField[];
  dataCount?: number;
  createBy?: string;
  createTime?: string;
  updateTime?: string;
}

/** 字典分页 */
export function listCustomDicts(params: { keyword?: string; status?: string; pageNum: number; pageSize: number }) {
  return request({ url: `${CUSTOM_DICT_BASE}/list`, method: 'get', params });
}

/** 字典下拉（不含字段定义） */
export function customDictOptions(status = '0') {
  return request({ url: `${CUSTOM_DICT_BASE}/options`, method: 'get', params: { status } });
}

/** 字典详情（含 fields 与 dataCount） */
export function getCustomDict(dictCode: string) {
  return request({ url: `${CUSTOM_DICT_BASE}/${dictCode}`, method: 'get' });
}

/** 新增字典（body 可带 fields 一并保存） */
export function addCustomDict(data: CustomDict) {
  return request({ url: CUSTOM_DICT_BASE, method: 'post', data });
}

/** 修改字典（fields 非空时会全量覆盖字段定义；只改基本信息时不要传 fields） */
export function updateCustomDict(data: CustomDict) {
  return request({ url: CUSTOM_DICT_BASE, method: 'put', data });
}

/** 删除字典（该字典下还有数据时会被拒绝） */
export function deleteCustomDict(ids: string | number) {
  return request({ url: `${CUSTOM_DICT_BASE}/${ids}`, method: 'delete' });
}

/** 启停字典 */
export function setCustomDictStatus(id: string | number, status: string) {
  return request({ url: `${CUSTOM_DICT_BASE}/${id}/status`, method: 'put', params: { status } });
}

/** 字段定义列表 */
export function listCustomDictFields(dictCode: string) {
  return request({ url: `${CUSTOM_DICT_BASE}/${dictCode}/fields`, method: 'get' });
}

/** 全量保存字段定义（覆盖式） */
export function saveCustomDictFields(dictCode: string, fields: CustomDictField[]) {
  return request({ url: `${CUSTOM_DICT_BASE}/${dictCode}/fields`, method: 'put', data: fields });
}

/** 数据分页（params 里除保留参数外都是字段编码过滤条件） */
export function listCustomDictData(dictCode: string, params: Record<string, any>) {
  return request({ url: `${CUSTOM_DICT_BASE}/${dictCode}/data/list`, method: 'get', params });
}

/** 树状数据（非层级字典返回平铺列表） */
export function customDictDataTree(dictCode: string, status = '0') {
  return request({ url: `${CUSTOM_DICT_BASE}/${dictCode}/data/tree`, method: 'get', params: { status } });
}

/** 数据详情 */
export function getCustomDictData(dictCode: string, id: string | number) {
  return request({ url: `${CUSTOM_DICT_BASE}/${dictCode}/data/${id}`, method: 'get' });
}

/**
 * 新增数据行
 * @param extra 可选项：层级字典的上级 parentId（0/不传=顶级）、排序 sortOrder、状态 status
 */
export function addCustomDictData(
  dictCode: string,
  fieldValues: Record<string, any>,
  extra?: { parentId?: string | number | null; sortOrder?: number; status?: string }
) {
  return request({ url: `${CUSTOM_DICT_BASE}/${dictCode}/data`, method: 'post', data: { fieldValues, ...(extra || {}) } });
}

/**
 * 修改数据行（body 带 id）
 * @param extra 可选项：parentId（层级字典的上级，0=顶级）、sortOrder、status
 */
export function updateCustomDictData(
  dictCode: string,
  id: string | number,
  fieldValues: Record<string, any>,
  extra?: { parentId?: string | number | null; sortOrder?: number; status?: string }
) {
  return request({ url: `${CUSTOM_DICT_BASE}/${dictCode}/data`, method: 'put', data: { id, fieldValues, ...(extra || {}) } });
}

/** 批量删除数据行（层级字典有下级时会被拒绝） */
export function deleteCustomDictData(dictCode: string, ids: string | number) {
  return request({ url: `${CUSTOM_DICT_BASE}/${dictCode}/data/${ids}`, method: 'delete' });
}

/** 业务方下拉；full=true 时附带全部字段值 */
export function customDictDataOptions(
  dictCode: string,
  params?: { keyword?: string; full?: boolean; limit?: number }
) {
  return request({ url: `${CUSTOM_DICT_BASE}/${dictCode}/options`, method: 'get', params });
}

/** 下载导入模板（仅表头，返回 blob） */
export function downloadCustomDictTemplate(dictCode: string) {
  return request({ url: `${CUSTOM_DICT_BASE}/${dictCode}/data/template`, method: 'get', responseType: 'blob' });
}

/** 导出数据（按当前过滤条件，返回 blob） */
export function exportCustomDictData(dictCode: string, data?: Record<string, any>) {
  return request({
    url: `${CUSTOM_DICT_BASE}/${dictCode}/data/export`,
    method: 'post',
    data: data || {},
    responseType: 'blob'
  });
}

/** 导入数据（multipart；mode=OVERWRITE 会先逻辑删除再导入） */
export function importCustomDictData(dictCode: string, file: File, mode: 'APPEND' | 'OVERWRITE' = 'APPEND') {
  const form = new FormData();
  form.append('file', file);
  return request({
    url: `${CUSTOM_DICT_BASE}/${dictCode}/data/import?mode=${mode}`,
    method: 'post',
    data: form,
    headers: { 'Content-Type': 'multipart/form-data' }
  });
}