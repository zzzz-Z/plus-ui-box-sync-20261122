import type { Form, Table } from '@/components/product-manage';
import type { FormItemProps, FormItemRule, TableColumnCtx } from 'element-plus';
import type { TableColumnProps } from 'element-plus/es/components/table/src/table-column/defaults.mjs';
import type { App, VNode } from 'vue';
import type { Router } from 'vue-router';

export {};

declare global {
  export type Params = Record<string, any>;
  export type TableInstance = InstanceType<typeof Table>;
  export type FormInstance = InstanceType<typeof Form>;

  interface Window {
    __v3_app: App;
    __v3_router: Router;
  }

  interface RenderParams<T> {
    row: T;
    value: any;
    column: TableColumnCtx<T>;
    index: number;
  }

  export interface TableColumn<T = any> extends TableColumnProps<T> {
    show?: () => boolean;
    prop?: keyof T;
    dictType?: string;
    /** 列设置：为 false 时该列在「字段显示与顺序」中不可隐藏（复选框禁用） */
    hideable?: boolean;
    /** 操作列标识：避免依赖 label 文本判断（国际化后 label 会变） */
    action?: boolean;
    columns?: TableColumn<T>[];
    render?: (params: RenderParams<T>) => VNode | VNode[] | string | number;
    // render?: (params: RenderParams<T>) => VNode | VNode[] | string | number
    /**
     * 默认渲染函数 default slot
     */
    renderDefault?: any;
  }

  export interface FormItemOption extends Partial<FormItemProps> {
    span?: number;
    label?: string;
    show?: () => boolean;
    tooltip?: string;
    rule?: FormItemRule;
    validator?: FormItemRule['validator'];
    render: () => any;
    [string: string]: any;
  }
}
