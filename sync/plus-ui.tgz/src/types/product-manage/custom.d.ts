export { }

declare module 'vue' {

  export interface ComponentCustomProperties {
    API: any
  }
}
