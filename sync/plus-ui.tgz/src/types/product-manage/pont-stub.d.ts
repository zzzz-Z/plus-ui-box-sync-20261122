// Pont 生成产物的本地 stub（后端 Swagger 就绪后由 pont-engine 覆盖）
// 目的是让 vue-tsc 通过；接入真实 Pont 前不要手改此文件。
export {}

declare global {
  interface PontResponse<T = any> {
    code: number
    data?: T
    message?: string
  }

  interface PontRequester {
    request: (params?: any) => Promise<PontResponse>
  }

  interface PontNamespace {
    [key: string]: PontRequester
  }

  const API: Record<string, PontNamespace>

  namespace defs {
    interface SysUserSelectSchema {
      userName?: string
      [key: string]: any
    }
    interface SysMenuSelectSchema {
      id?: number
      parentId?: number
      menuName?: string
      menuType?: string
      visible?: string
      perms?: string
      path?: string
      component?: string
      icon?: string
      isCache?: boolean
      orderNum?: number
      [key: string]: any
    }
    interface SysDictDataSelectSchema {
      dictLabel?: string
      dictValue?: string
      listClass?: string
      [key: string]: any
    }
  }
}
