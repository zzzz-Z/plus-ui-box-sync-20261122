/** 作业单元参数 */
export interface WorkUnitParam {
  id?: string
  unitId?: string
  paramKey: string
  paramName: string
  paramValue: string
  paramType: string
  /** 是否必填，1=必填 0=非必填 */
  requiredFlag: string
  sortOrder: number
  remark?: string
  createBy?: string
  createTime?: string
  updateBy?: string
  updateTime?: string
  params?: Record<string, any>
}

/** 作业单元 */
export interface WorkUnit {
  id?: string
  unitCode: string
  unitName: string
  unitType: string
  unitVersion: string
  status: string
  executablePath: string
  docPath: string
  metadata: string
  description: string
  sourceSystem: string
  remark: string
  createBy?: string
  createTime?: string
  updateBy?: string
  updateTime?: string
  createDept?: string
  paramList: WorkUnitParam[]
}

/** 作业单元表单（新增/修改） */
export type WorkUnitForm = WorkUnit

/** 查询参数 */
export interface WorkUnitQuery {
  key?: string
  pageNum?: number
  pageSize?: number
}
