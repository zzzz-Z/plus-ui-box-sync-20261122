import { createApp } from 'vue';
// global css
import 'virtual:uno.css';
import 'element-plus/theme-chalk/dark/css-vars.css';
import '@/assets/styles/index.scss';
// 产品管理(product-manage)的 CSS 变量（地图 / 业务组件依赖）
import '@/assets/product-manage/styles/css-vars.scss';

// maplibre-gl v6 worker：用 ?worker&url 让 Vite 把 worker 输出为带哈希的独立资源，
// 避免运行时 import.meta.url 解析失效（打包后路径对不上），worker 请求落到 SPA
// fallback 返回 text/html 触发 MIME 错误。setWorkerUrl 必须在任何 Map 实例创建前调用。
import maplibreWorkerUrl from 'maplibre-gl/dist/maplibre-gl-worker.mjs?worker&url';
import { setWorkerUrl as setMaplibreWorkerUrl } from 'maplibre-gl';
setMaplibreWorkerUrl(maplibreWorkerUrl);

// Monaco Editor worker（任务调度代码编辑器使用）
import EditorWorker from 'monaco-editor/esm/vs/editor/editor.worker?worker';
import JsonWorker from 'monaco-editor/esm/vs/language/json/json.worker?worker';
import CssWorker from 'monaco-editor/esm/vs/language/css/css.worker?worker';
import HtmlWorker from 'monaco-editor/esm/vs/language/html/html.worker?worker';
import TsWorker from 'monaco-editor/esm/vs/language/typescript/ts.worker?worker';
// @ts-expect-error MonacoEnvironment 由 monaco-editor 全局注入，无 TS 声明
globalThis.MonacoEnvironment = {
  getWorker(_: any, label: string) {
    if (label === 'json') return new JsonWorker();
    if (['css', 'scss', 'less'].includes(label)) return new CssWorker();
    if (['html', 'handlebars', 'razor'].includes(label)) return new HtmlWorker();
    if (['typescript', 'javascript'].includes(label)) return new TsWorker();
    return new EditorWorker();
  }
};

// App、router、store
import App from './App.vue';
import store from './store';
import router from './router';

// 自定义指令
import directive from './directive';

// v-tooltip 提供（floating-vue）
import FloatingVue from 'floating-vue';
import 'floating-vue/dist/style.css';

// 注册插件
import plugins from './plugins/index'; // plugins

// 高亮组件
// import 'highlight.js/styles/a11y-light.css';
import 'highlight.js/styles/atom-one-dark.css';
import 'highlight.js/lib/common';
import HighLight from '@highlightjs/vue-plugin';

// svg图标
import 'virtual:svg-icons-register';
import ElementIcons from '@/plugins/svgicon';

// permission control
import './permission';

// 国际化
import i18n from '@/lang/index';

// 海豚任务流编辑器多语言(合并进 vue-i18n,使 t('project.xxx') / t('modal.xxx') 可解析)
import dsProjectZh from '@/lang/project';
import dsModalZh from '@/lang/modal';
import dsProjectEn from '@/lang/project.en';
import dsModalEn from '@/lang/modal.en';
i18n.global.mergeLocaleMessage('zh_CN', { project: dsProjectZh, modal: dsModalZh });
i18n.global.mergeLocaleMessage('en_US', { project: dsProjectEn, modal: dsModalEn });

// vxeTable
import VXETable from 'vxe-table';
import 'vxe-table/lib/style.css';
VXETable.setConfig({
  zIndex: 999999
});

// 修改 el-dialog 默认点击遮照为不关闭
import { ElDialog } from 'element-plus';
ElDialog.props.closeOnClickModal.default = false;

/* ==================================================================
 * 开发环境：让 F12 打开/切换不再卡顿
 * ------------------------------------------------------------------
 * 排查经验：DevTools 变慢通常不是业务代码慢，而是"它要处理的数据太多"：
 *   1) 控制台消息量大：请求、轮询、重渲染每次都打日志，打开面板时要把历史消息全量排版；
 *   2) Vue 告警刷屏：渲染循环里的重复告警，每条都要抓一遍调用栈；
 *   3) Vue Devtools 桥接：打开 DevTools 时会遍历整棵组件树 + 所有响应式对象，
 *      页面里表格/图表数据越大越慢（列表页动辄上千行）。
 * 这里分别做：控制台同内容 1 秒去重、Vue 告警只打一次、默认关闭 Vue Devtools 桥接
 * （需要时在控制台执行 localStorage.setItem('__VUE_DEVTOOLS__','on') 后刷新即可恢复）。
 * 全部只在开发环境生效，生产构建不受影响。
 * ================================================================== */
if (import.meta.env.DEV) {
  const seen = new Map<string, number>();
  (['log', 'info', 'warn', 'error', 'debug'] as const).forEach((name) => {
    const original = console[name].bind(console);
    (console as any)[name] = (...args: any[]) => {
      let key: string;
      try {
        key = args.map((a) => (typeof a === 'string' ? a : a instanceof Error ? a.message : JSON.stringify(a))).join('|');
      } catch {
        key = String(args[0]);
      }
      key = name + ':' + key.slice(0, 200);
      const now = Date.now();
      const last = seen.get(key) ?? 0;
      if (now - last < 1000) return; // 1 秒内相同内容只输出一次，避免刷屏拖慢面板
      seen.set(key, now);
      if (seen.size > 300) seen.clear();
      original(...args);
    };
  });
  console.info('[dev] 控制台已开启重复日志去重；如需关闭 Vue Devtools 桥接请清空 localStorage.__VUE_DEVTOOLS__');
}

const app = createApp(App);

// Vue Devtools 桥接默认关闭（开发环境可用 localStorage 打开），显著降低 F12 打开耗时
const devtoolsFlag = import.meta.env.DEV && localStorage.getItem('__VUE_DEVTOOLS__') === 'on';
(app.config as any).devtools = devtoolsFlag;

// Vue 告警去重：同一告警只打印一次（渲染循环里的告警最容易把控制台刷爆）
if (import.meta.env.DEV) {
  const warned = new Set<string>();
  app.config.warnHandler = (msg, _instance, trace) => {
    if (warned.has(msg)) return;
    warned.add(msg);
    console.warn('[Vue warn] ' + msg + (trace ? '\n' + trace : ''));
  };
}

app.use(HighLight);
app.use(ElementIcons);
app.use(router);
app.use(store);
app.use(i18n);
app.use(VXETable);
app.use(plugins);
// 自定义指令
directive(app);
app.use(FloatingVue);

// 产品管理命令式弹窗 / 区块（create-dialog / create-block）依赖的全局实例
window.__v3_app = app;
window.__v3_router = router;

app.mount('#app');
