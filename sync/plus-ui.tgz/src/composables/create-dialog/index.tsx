import type { AnyFn, Fn } from '@vueuse/core';
import type { DialogProps } from 'element-plus';
import { ElButton, ElConfigProvider, ElDialog, ElMessage } from 'element-plus';
import type { CSSProperties, VNode } from 'vue';
import { isVNode, render } from 'vue';

import { stringifyStyle } from '@vue/shared';
import zhCn from 'element-plus/es/locale/lang/zh-cn.mjs';
import { isUndefined } from 'lodash';
import './index.scss';

interface Props extends DialogProps {
  render: AnyFn;
  close?: Fn;
  footer?: (() => VNode | VNode[]) | false;
  afterSave?: (r?: Params) => any;
  save?: (p?: Params) => Promise<any>;
  bodyStyle?: CSSProperties;
  /** 追加到 .el-dialog 根节点的类名（配合自定义高度/宽度的弹窗使用） */
  class?: string;
  appContext?: any;
  okText?: string;
  cancelText?: string;
  style?: CSSProperties;
  /**
   * 缓存模式：实例常驻，关闭只隐藏、不销毁（保留子组件状态），由返回的 open / close 控制显隐。
   * 为 true 时弹窗不主动打开（等价 visible:false），适合「一次创建、反复打开」的弹窗。
   */
  cache?: boolean;
  /** 初始是否显示。默认：cache 模式为 false、普通模式为 true；显式传 false 同样进入常驻模式 */
  visible?: boolean;
}

/**
 * @description 点击提交时,调用组件内部expose的save函数 或者createDialog参数传入save
 * @example
 * defineExpose({save：async ()=> {} })
 * save返回为promise时 按钮自动添加loading
 *
 * 缓存复用（弹窗关闭后状态不丢，反复打开用同一个实例）：
 * const fileDialog = createDialog({ visible: false, render: () => <FilePicker /> });
 * fileDialog.open();   // 打开/再次打开
 * fileDialog.close();  // 隐藏，不销毁，状态保留
 * 等价于 createDialog({ cache: true, ... })。
 */
export function createDialog({
  footer,
  title,
  afterSave,
  save: customSave,
  render: customRender,
  close: customClose,
  cancelText = '取消',
  okText = '提交',
  bodyStyle = {},
  style = {},
  appContext,
  cache = false,
  visible,
  ...restProps
}: Partial<Props>) {
  const root = document.body;
  const div = document.createElement('div');
  // 常驻判定：显式 cache 或显式 visible:false —— 两者都表示「先不打开、留着复用」
  // cache/visible 在此被解构掉，不会经 restProps 透传给 ElDialog
  const persistent = cache || visible === false;
  // cache:true + visible:true 仍应「不主动打开」：用户显式打开必须走 open()
  const state = reactive({ loading: false, visible: persistent ? false : (visible ?? true) });
  const contentRef = ref();
  root?.appendChild(div);

  const baseFooter = () => [
    <ElButton onClick={close}>{cancelText}</ElButton>,
    <ElButton type="primary" onClick={submit} loading={state.loading}>
      {okText}
    </ElButton>
  ];

  const dialog = () => {
    return (
      <ElDialog
        class={`create-dialog ${restProps.fullscreen ? '__is-fullscreen' : ''}  ${footer === false ? '__no-footer' : ''}  `}
        v-model={state.visible}
        onClose={close}
        onClosed={closed}
        style={style}
        append-to={div}
        closeOnClickModal={true}
        width={500}
        {...restProps}
        onVnodeMounted={setBodyStyle}
        v-slots={{
          footer: footer === false ? null : contentRef.value?.action?.(baseFooter(), close) || footer || baseFooter,
          header: () => <span class="title-content">{title}</span>,
          default: () => {
            const node = customRender!();
            return isVNode(node) ? h(node, { ref: contentRef }) : node;
          }
        }}
      />
    );
  };

  const node = h(ElConfigProvider, { locale: zhCn }, dialog);

  node.appContext = window.__v3_app._context || appContext;

  render(node, div);

  /** 卸载并移除容器（普通模式关闭即销毁；缓存模式仅在 destroy 时调用） */
  function unmount() {
    render(null, div);
    if (div.parentNode) div.parentNode.removeChild(div);
  }

  /** 打开 / 再次打开（缓存模式下复用同一个实例，子组件状态保留） */
  function open() {
    state.visible = true;
    // 缓存模式首次打开时 dialog content 才真正挂载，补一次 body 样式
    nextTick(setBodyStyle);
  }

  /**
   * 关闭（缓存模式下只隐藏、不销毁）。
   * WHY 加幂等判断：取消按钮 / submit 成功会直接调 close，而 ElDialog 的 leave 过渡
   * 又会 emit('close') 再调一次；只在「由可见变隐藏」这一次转换里触发 customClose。
   */
  function close() {
    if (!state.visible) return;
    customClose?.();
    state.visible = false;
  }

  function closed() {
    // 缓存模式：保留 DOM 与子组件状态，等 open() 再次显示
    if (persistent) return;
    unmount();
  }

  /** 彻底销毁缓存实例：组件卸载时建议调用，避免隐藏的 div 长期挂在 body 上 */
  function destroy() {
    state.visible = false;
    unmount();
  }

  async function submit() {
    const content = unref(contentRef);
    const request = customSave || content?.save;
    const validate = content?.validate || unref(content?.form)?.validate;
    if (!request) {
      console.warn('[create-dialog]：请传入save函数');
      return;
    }

    try {
      await validate?.();
    } catch (error) {
      return error;
    }

    state.loading = true;
    const res = await request(close)?.finally?.(() => {
      state.loading = false;
    });

    if (isUndefined(res)) {
      return;
    }

    if (res.code === 0) {
      close();
      afterSave?.(res);
      ElMessage.success(res.message || '保存成功。');
    } else {
      ElMessage.error(res.message || '保存失败。');
    }
  }

  async function setBodyStyle() {
    await nextTick();
    const body = div.getElementsByClassName('el-dialog__body')[0] as HTMLElement | undefined;
    body?.setAttribute('style', stringifyStyle({ ...(bodyStyle as any) }));
  }

  return {
    open,
    close,
    destroy,
    contentRef,
    baseFooter
  };
}
