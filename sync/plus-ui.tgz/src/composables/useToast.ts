import { ElMessage, ElMessageBox } from 'element-plus';
import i18n from '@/lang/index';
const t = (key: string) => i18n.global.t(key);

export function useToast() {
  const toast = {
    success: (msg: string) => ElMessage.success(msg),
    error: (msg: string) => ElMessage.error(msg),
    warning: (msg: string) => ElMessage.warning(msg),
    info: (msg: string) => ElMessage.info(msg)
  };

  async function confirmDialog(options: { title: string; detail?: string; danger?: boolean }) {
    try {
      await ElMessageBox.confirm(options.detail || '', options.title, {
        confirmButtonText: t('common.confirm'),
        cancelButtonText: t('common.cancel'),
        type: options.danger ? 'warning' : 'info'
      });
      return true;
    } catch {
      return false;
    }
  }

  return { toast, confirmDialog };
}
