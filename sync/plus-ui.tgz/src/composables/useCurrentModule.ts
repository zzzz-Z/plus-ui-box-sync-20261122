import { computed } from 'vue';
import { useRoute } from 'vue-router';
import type { ResultModuleType } from '@/api/product-manage/types/result';

/**
 * 路由 path → 产品成果模块 映射表
 *
 * ⚠️ 必须与 src/router/routes/result-product.ts 保持同步：
 *    新增/删除路由时，同步修改此表。
 *
 * 说明：
 *  - 不映射 /result-product/metadata，因为元数据管理复用初级产品页面
 *  - 每个业务模块都有独立页面容器（src/pages/result-product/{name}/index.vue）
 */
export const PATH_TO_MODULE: Record<string, ResultModuleType> = {
  '/result-product/category-feature': '分类要素产品成果',
  '/result-product/category-attribute': '分类要素属性产品成果',
  '/result-product/geology-feature': '地质要素产品成果',
  '/result-product/lh-fusion': 'lh融合产品成果',
  '/result-product/sample-model': '样本与模型成果',
  '/result-product/vector-network': '矢量组网产品成果'
};

/**
 * 当前模块（响应式）：路由变化时自动更新
 *
 * 用法：
 *   const { moduleType } = useCurrentModule()
 *   if (moduleType.value === '分类要素产品成果') { ... }
 *
 * 若当前路径不在产品成果模块下，返回空字符串。
 */
export function useCurrentModule() {
  const route = useRoute();

  const moduleType = computed<ResultModuleType | ''>(() => {
    // 1. 精确匹配
    if (PATH_TO_MODULE[route.path]) return PATH_TO_MODULE[route.path];
    // 2. 前缀匹配（兼容子路径，如 /result-product/category-feature/detail/1）
    const hit = Object.keys(PATH_TO_MODULE).find((k) => route.path.startsWith(k));
    return hit ? PATH_TO_MODULE[hit] : '';
  });

  /** 当前是否处于产品成果模块 */
  const isResultProduct = computed(() => !!moduleType.value);

  return { moduleType, isResultProduct };
}
