import { reactive } from 'vue'
import { saveJSON } from '@/utils/product-manage/storage'

export interface TaskLike {
  id: number
  progress: number
  message: string
  status: string
}

export interface TaskProgressOptions<T extends TaskLike> {
  interval?: number
  step?: (task: T) => number
  isRunning?: (task: T) => boolean
  onTick?: (task: T) => void
}

export function createTaskStore<T extends TaskLike>(
  storageKey: string,
  fetcher: () => Promise<{ data?: T[] }>,
  progressOptions: TaskProgressOptions<T> = {},
) {
  const tasks = reactive<T[]>([]) as T[]
  let loadPromise: Promise<void> | null = null
  let timer: ReturnType<typeof setInterval> | undefined
  function persist() {
    saveJSON(storageKey, tasks)
  }
  function readStored(): T[] | null {
    const raw = localStorage.getItem(storageKey)
    if (!raw) return null
    try {
      const parsed = JSON.parse(raw)
      return Array.isArray(parsed) ? (parsed as T[]) : null
    } catch {
      return null
    }
  }
  function load(): Promise<void> {
    if (loadPromise) return loadPromise
    const stored = readStored()
    if (stored) {
      tasks.push(...stored)
      loadPromise = Promise.resolve()
    } else {
      loadPromise = fetcher().then((res) => {
        tasks.push(...(res?.data ?? []))
        persist()
      })
    }
    return loadPromise
  }
  function startProgress() {
    if (timer) return
    timer = setInterval(() => {
      let running = false
      tasks.forEach((task) => {
        if (!(progressOptions.isRunning?.(task) ?? task.status === 'running')) return
        running = true
        const step = progressOptions.step?.(task) ?? 2
        task.progress = Math.min(task.progress + step, 100)
        progressOptions.onTick?.(task)
      })
      persist()
      if (!running) stopProgress()
    }, progressOptions.interval ?? 1000)
  }
  function stopProgress() {
    if (timer) {
      clearInterval(timer)
      timer = undefined
    }
  }
  return { tasks, persist, load, startProgress, stopProgress }
}
