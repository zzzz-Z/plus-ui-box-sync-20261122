import type { Fn } from '@vueuse/core';
import type { DialogProps } from 'element-plus';
import { ElButton, ElConfigProvider, ElMessage } from 'element-plus';
import type { CSSProperties, VNode } from 'vue';
import { isVNode, render, unref } from 'vue';
import zhCn from 'element-plus/es/locale/lang/zh-cn.mjs';
import { isUndefined } from 'lodash';
import { Back, Select } from '@element-plus/icons-vue';
import './index.scss';

interface Props extends DialogProps {
  render: (...args: any[]) => any;
  close?: Fn;
  footer?: (() => VNode | VNode[]) | false;
  afterSave?: (r?: Params) => any;
  afterClose?: () => any;
  save?: (p?: Params) => Promise<any>;
  bodyStyle?: CSSProperties;
  appContext?: any;
  okText?: string;
  cancelText?: string;
  rootDom?: HTMLElement | null;
  header?: any;
  container?: string;
  title?: string;
}

/**
 * @description 点击提交时,调用组件内部expose的save函数 或者createDialog参数传入save
 * @example
 * defineExpose({save：async ()=> {} })
 * save返回为promise时 按钮自动添加loading
 */
export function createBlock({
  afterSave,
  afterClose,
  save: customSave,
  render: customRender,
  close: customClose,
  cancelText = '返回',
  okText = '保存',
  appContext,
  title,
  header,
  container
}: Partial<Props>) {
  const appMain = container ? document.getElementById(container) : document.body;
  const div = document.createElement('div');

  div.className = 'block-container';
  appMain?.appendChild(div);

  const contentRef = ref();
  const state = reactive({
    loading: false,
    visible: true
  });

  const stop = watch(window.__v3_router.currentRoute, close);

  function close() {
    customClose?.();
    state.visible = false;
    render(null, div);
    appMain?.removeChild(div);
    stop();
    afterClose?.();
  }
  /**
   * 提交表单数据的异步函数
   * 处理表单验证、发送请求以及响应处理
   *
   * @returns {Promise<any>} 返回一个Promise，解析为请求的结果或错误信息
   */
  async function submit() {
    // 获取表单内容和保存方法
    const content = unref(contentRef);
    const request = customSave || content?.save;
    const validate = content?.validate || unref(content?.form)?.validate;

    // 如果没有请求方法，直接返回
    if (!request) {
      return;
    }

    try {
      await validate?.();
    } catch (error) {
      return error;
    }

    // 显示加载状态
    state.loading = true;

    // 发送请求并处理最终操作
    const res = await request(close)?.finally?.(() => {
      state.loading = false;
    });

    // 如果结果未定义，直接返回
    if (isUndefined(res)) {
      return;
    }

    // 如果结果为false，关闭表单
    if (!res) {
      return close();
    }

    // 处理响应结果
    if (res.code === 0) {
      // 请求成功，关闭表单并触发afterSave回调
      close();
      afterSave?.(res);
      ElMessage.success(res.msg || '保存成功。');
    } else {
      // 请求失败，显示错误消息
      ElMessage.error(res.msg || '保存失败。');
    }
  }

  const baseHeader = () => [
    <ElButton type="primary" icon={Back} onClick={close}>
      {cancelText}
    </ElButton>,
    <ElButton type="primary" plain icon={Select} onClick={submit} loading={state.loading}>
      {okText}
    </ElButton>
  ];

  const block = () => {
    const node = customRender!();
    return (
      <>
        <div class="block-header" v-show={header !== false}>
          {title ? <span class="header-title">{title}</span> : contentRef.value?.header?.() || <div />}
          <div>{contentRef.value?.action?.(baseHeader(), close) || baseHeader()}</div>
        </div>
        <div class="block-content">{isVNode(node) ? h(node, { ref: contentRef }) : node}</div>
      </>
    );
  };

  const node = h(ElConfigProvider, { locale: zhCn }, block);

  node.appContext = window.__v3_app._context || appContext;

  render(node, div);

  return {
    close,
    contentRef,
    baseHeader
  };
}
