export function useListener() {
  const listener = Object.fromEntries(
    Object.entries(getCurrentInstance()!.vnode.props!).filter(([key]) => key.startsWith('on'))
  )

  return listener
}
