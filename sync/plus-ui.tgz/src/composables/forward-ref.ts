import { unref } from 'vue'
import type { Ref } from 'vue'

export function forwardRef<T extends object, P extends object>(
  ref: Ref<T | null | undefined>,
  target?: P
): T & P {
  const exposeTarget: Record<PropertyKey, unknown> = target ? { ...target } : {}

  const expose = new Proxy(exposeTarget, {
    get(targetObj, key) {
      const source = unref(ref)

      if (key in targetObj) {
        const value = targetObj[key]
        if (typeof value === 'function') {
          return (value as (...args: unknown[]) => unknown).bind(targetObj)
        }
        return unref(value)
      }

      if (!source) return undefined

      const value = Reflect.get(source, key)
      if (typeof value === 'function') {
        return value.bind(source)
      }
      return unref(value)
    },

    set(targetObj, key, value) {
      const source = unref(ref)

      if (source && key in source) {
        return Reflect.set(source, key, value)
      }

      return Reflect.set(targetObj, key, value)
    },

    has(targetObj, key) {
      const source = unref(ref)
      return key in targetObj || Boolean(source && key in source)
    },
  }) as T & P

  return expose
}
