import { ref, watch } from 'vue'
import { loadJSON, saveJSON } from '@/utils/product-manage/storage'

/**
 * 收藏 / 屏蔽集合（localStorage 持久化）
 *
 * 初级线 data-query 与成果线 data-query 各自维护同一套逻辑，
 * 抽到此处后由调用方传入 key 前缀（如 'dq' / 'rq'）。
 *
 * 返回值中：
 *   - favoriteIds / blockedIds 为响应式 Ref
 *   - isFavorite / isBlocked 单项查询
 *   - toggleFavorite / toggleBlocked 单项切换
 *   - addFavorites / addBlocked 批量添加（供"收藏所选"等操作调用）
 */
export function useFavoriteBlock(prefix: string) {
  const favKey = `${prefix}.favorites`
  const blkKey = `${prefix}.blocked`

  const favoriteIds = ref<number[]>(loadJSON<number[]>(favKey, []))
  const blockedIds = ref<number[]>(loadJSON<number[]>(blkKey, []))

  watch(favoriteIds, value => saveJSON(favKey, value), { deep: true })
  watch(blockedIds, value => saveJSON(blkKey, value), { deep: true })

  const isFavorite = (id: number) => favoriteIds.value.includes(id)
  const isBlocked = (id: number) => blockedIds.value.includes(id)

  function toggleIn(list: typeof favoriteIds, id: number) {
    list.value = list.value.includes(id)
      ? list.value.filter(item => item !== id)
      : [...list.value, id]
  }

  const toggleFavorite = (id: number) => toggleIn(favoriteIds, id)
  const toggleBlocked = (id: number) => toggleIn(blockedIds, id)

  function addFavorites(ids: number[]) {
    ids.forEach((id) => { if (!favoriteIds.value.includes(id)) favoriteIds.value.push(id) })
  }
  function addBlocked(ids: number[]) {
    ids.forEach((id) => { if (!blockedIds.value.includes(id)) blockedIds.value.push(id) })
  }

  return {
    favoriteIds,
    blockedIds,
    isFavorite,
    isBlocked,
    toggleFavorite,
    toggleBlocked,
    addFavorites,
    addBlocked,
  }
}
