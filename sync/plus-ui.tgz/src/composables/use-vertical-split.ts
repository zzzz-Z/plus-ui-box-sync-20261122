import { computed, onBeforeUnmount, onMounted, ref, type Ref } from 'vue';

export interface VerticalSplitOptions {
  /** 上半区初始占比（0~1），默认 0.5 */
  initialRatio?: number;
  /** 上半区最小高度（px），默认 140 */
  minTop?: number;
  /** 下半区最小高度（px），默认 160 */
  minBottom?: number;
  /** 拖拽条自身占的高度（px），默认 12；算上限时必须扣掉，否则下半区会比 minBottom 少这么多 */
  handleSize?: number;
}

/**
 * 上下分栏拖拽（地图 / 表格联动布局用）
 *
 * 约定：容器 flex-direction: column；上半区高度绑 topStyle，下半区用 flex:1 吃剩余高度；
 * 两者之间放一条热区元素，@pointerdown="startDrag"。
 *
 * WHY 记比例不记像素：header 折行、窗口缩放都会改变容器高度，固定 px 会把下半区挤成 0；
 * 存比例则两栏按容器等比缩放，只在越界（小于最小高度）时才纠偏。
 */
export function useVerticalSplit(container: Ref<HTMLElement | undefined>, options: VerticalSplitOptions = {}) {
  const minTop = options.minTop ?? 140;
  const minBottom = options.minBottom ?? 160;
  const handleSize = options.handleSize ?? 12;
  const ratio = ref(options.initialRatio ?? 0.5);
  const dragging = ref(false);

  /** 上半区样式：百分比高度 + 不参与 flex 伸缩（默认 height:50% 由它接管） */
  const topStyle = computed(() => ({ height: `${(ratio.value * 100).toFixed(4)}%`, flex: '0 0 auto', minHeight: '0px' }));

  let startY = 0;
  let startHeight = 0;
  let prevCursor = '';
  let prevUserSelect = '';
  let resizeObserver: ResizeObserver | undefined;

  /** 容器内可分配的总高度与上半区上下限 */
  function limits() {
    const total = container.value?.clientHeight ?? 0;
    // 上限扣掉拖拽条自身高度，保证下半区真正不小于 minBottom
    return { total, maxTop: Math.max(minTop, total - minBottom - handleSize) };
  }

  function onPointerMove(e: PointerEvent) {
    if (!dragging.value) return;
    const { total, maxTop } = limits();
    if (!total) return;
    // 上限同时保证下半区不被拖没；容器过矮时以 minTop 优先（maxTop 不会小于 minTop，避免 clamp 反转）
    const next = Math.min(Math.max(startHeight + (e.clientY - startY), minTop), maxTop);
    ratio.value = next / total;
  }

  function stopDrag() {
    if (!dragging.value) return;
    dragging.value = false;
    window.removeEventListener('pointermove', onPointerMove);
    window.removeEventListener('pointerup', stopDrag);
    window.removeEventListener('pointercancel', stopDrag);
    // 还原拖动期间临时接管的全局光标与选中行为
    document.body.style.cursor = prevCursor;
    document.body.style.userSelect = prevUserSelect;
  }

  function startDrag(e: PointerEvent) {
    const el = container.value;
    if (!el) return;
    // 只响应主键 / 触摸与触控笔；右键、中键不进入拖动
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    dragging.value = true;
    startY = e.clientY;
    startHeight = el.clientHeight * ratio.value || 0;
    // 捕获指针：鼠标拖出窗口再松开也能收到 pointerup，否则 dragging 会卡在 true
    (e.currentTarget as HTMLElement | null)?.setPointerCapture?.(e.pointerId);
    prevCursor = document.body.style.cursor;
    prevUserSelect = document.body.style.userSelect;
    document.body.style.cursor = 'row-resize';
    document.body.style.userSelect = 'none';
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', stopDrag);
    window.addEventListener('pointercancel', stopDrag);
    e.preventDefault();
  }

  onMounted(() => {
    const el = container.value;
    if (!el) return;
    // 容器变矮（窗口缩放 / header 折行）时比例可能越界，非拖动状态下自动纠偏回可分配区间
    resizeObserver = new ResizeObserver(() => {
      if (dragging.value) return;
      const { total, maxTop } = limits();
      if (!total) return;
      const current = total * ratio.value;
      const fixed = Math.min(Math.max(current, minTop), maxTop);
      if (Math.abs(fixed - current) > 1) ratio.value = fixed / total;
    });
    resizeObserver.observe(el);
  });

  onBeforeUnmount(() => {
    stopDrag();
    resizeObserver?.disconnect();
    resizeObserver = undefined;
  });

  return { ratio, dragging, topStyle, startDrag };
}
