import { ref, watch } from 'vue'
import { loadJSON, saveJSON } from '@/utils/product-manage/storage'

/**
 * 安全屏蔽规则工厂
 *
 * 两条产品线的 data-permission 各自维护同一套逻辑：
 *   hiddenIds / rules / toggleHidden / hideSelected / addRuleData / removeRuleData
 * 抽到此处，由调用方传入 localStorage 前缀（'mdm.security' / 'result.security'）。
 *
 * 状态与业务无关：不依赖任何 store，只在自身 ref 上做增删改查 + 持久化。
 */

export type SecurityRuleType = 'attribute' | 'space' | 'sheet'

export interface SecurityRule {
  id: number
  name: string
  type: SecurityRuleType
  expression: string
  effect: '隐藏' | '显示'
  enabled: boolean
  updatedAt: string
}

export interface RuleDraft {
  name: string
  type: SecurityRuleType
  expression: string
  effect: '隐藏' | '显示'
}

/** 限定方式：属性字段 / 空间范围 / 图号列表 */
export const RULE_TYPE_LABEL: Record<SecurityRuleType, string> = {
  attribute: '属性字段',
  space: '空间范围',
  sheet: '图号列表',
}

export const RULE_TAG_TYPE: Record<SecurityRuleType, 'success' | 'warning' | 'info'> = {
  space: 'success',
  sheet: 'warning',
  attribute: 'info',
}

export function createSecurityStore(prefix: string, defaultRules: SecurityRule[] = []) {
  const HIDDEN_KEY = `${prefix}.hidden`
  const RULES_KEY = `${prefix}.rules`

  const hiddenIds = ref<number[]>(loadJSON<number[]>(HIDDEN_KEY, []))
  const rules = ref<SecurityRule[]>(loadJSON<SecurityRule[]>(RULES_KEY, defaultRules))
  const selectedIds = ref<number[]>([])

  function persist() {
    saveJSON(HIDDEN_KEY, hiddenIds.value)
    saveJSON(RULES_KEY, rules.value)
  }
  watch(hiddenIds, persist, { deep: true })
  watch(rules, persist, { deep: true })

  const isHidden = (id: number) => hiddenIds.value.includes(id)

  function toggleHidden(id: number) {
    hiddenIds.value = hiddenIds.value.includes(id)
      ? hiddenIds.value.filter(item => item !== id)
      : [...hiddenIds.value, id]
  }

  function setSelected(rows: { id: number }[]) {
    selectedIds.value = rows.map(row => row.id)
  }

  /** 屏蔽所选；返回处理条数，0 表示未选择 */
  function hideSelected(): number {
    if (!selectedIds.value.length)
      return 0
    selectedIds.value.forEach((id) => {
      if (!hiddenIds.value.includes(id))
        hiddenIds.value.push(id)
    })
    return selectedIds.value.length
  }

  function clearHidden() {
    hiddenIds.value = []
  }

  /** 新增规则；返回错误信息或 null 表示成功 */
  function addRuleData(model: RuleDraft): string | null {
    if (!model.name.trim() || !model.expression.trim())
      return '请填写规则名称和限定条件'
    rules.value.unshift({
      id: Date.now(),
      name: model.name.trim(),
      type: model.type,
      expression: model.expression.trim(),
      effect: model.effect,
      enabled: true,
      updatedAt: new Date().toLocaleString('zh-CN'),
    })
    return null
  }

  function removeRuleData(rule: SecurityRule) {
    const index = rules.value.indexOf(rule)
    if (index >= 0)
      rules.value.splice(index, 1)
  }

  return {
    hiddenIds,
    rules,
    selectedIds,
    isHidden,
    toggleHidden,
    setSelected,
    hideSelected,
    clearHidden,
    addRuleData,
    removeRuleData,
  }
}
