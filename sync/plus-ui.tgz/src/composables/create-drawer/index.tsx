import type { AnyFn, Fn } from '@vueuse/core';
import type { DrawerProps } from 'element-plus';
import { ElConfigProvider, ElDrawer } from 'element-plus';
import type { ComponentInternalInstance, CSSProperties, EffectScope, VNode } from 'vue';
import { getCurrentInstance, isVNode, onScopeDispose, render } from 'vue';

import { stringifyStyle } from '@vue/shared';
import zhCn from 'element-plus/es/locale/lang/zh-cn.mjs';
import './index.scss';

interface Props extends DrawerProps {
  render: AnyFn;
  close?: Fn;
  footer?: (() => VNode | VNode[]) | false;
  bodyStyle?: CSSProperties;
  style?: CSSProperties;
  appContext?: any;
  /**
   * 拥有者组件实例：传入后抽屉的销毁挂到该组件的 effect scope 上，组件卸载时自动 destroy。
   *
   * WHY 需要：抽屉是 `render(node, div)` 渲染到 body 上的独立 VNode 树，不在这棵页面组件树里，
   * Vue 的树级卸载带不走它 —— 路由切换有 internal 的 watch 兜底，但「路由没变、页面组件没了」
   * （同一路由内 v-if 换页 / 父组件卸载 / KeepAlive 切走）会把它连同 document 监听、ResizeObserver
   * 一起遗留在 body 上。
   *
   * WHY 不能只靠内部 getCurrentInstance()：`createDrawer` 几乎都在事件回调里调（openDetail 之类），
   * 那时没有 currentInstance、也没有 active scope，注册必然落空。所以调用方要在 setup 顶层先存实例再传入：
   * `const owner = getCurrentInstance();` → `createDrawer({ owner, ... })`。
   *
   * 传 `false` 表示显式不绑定（例如实例需要活过页面，交给调用方自己 destroy）。
   */
  owner?: ComponentInternalInstance | null | false;
  /**
   * 缓存模式：实例常驻，关闭只隐藏、不销毁（保留子组件状态），由返回的 open / close 控制显隐。
   * 为 true 时抽屉不主动打开（等价 visible:false），适合「一次创建、反复打开」的抽屉。
   */
  cache?: boolean;
  /** 初始是否显示。默认：cache 模式为 false、普通模式为 true；显式传 false 同样进入常驻模式 */
  visible?: boolean;
  /**
   * 是否互斥（默认 true）—— 同一时刻只保留一个抽屉实例。
   *
   * WHY 需要：抽屉是「看当前这一条」的容器，用户点另一行 / 另一要素时应该原地换内容，
   * 而不是叠出第二个抽屉。开启后新建实例会先销毁上一个，调用方不需要自己维护单例。
   */
  exclusive?: boolean;
  /**
   * 纵向对齐的参照元素（可选）。
   *
   * WHY 需要：抽屉默认按视口定位（顶部避开导航、贴底 10px），但「属性详情」是从右侧
   * 表格里点出来的，用户预期它和表格上下齐平 —— 视口对齐会让抽屉比表格高一截，
   * 视觉上像是悬在两块内容之间。传入表格根元素后，抽屉的 top / height 跟随它的矩形。
   *
   * 取值可以是元素、选择器或返回元素的函数；传函数时在每次重新对齐时调用，
   * 适合「元素可能晚于抽屉创建才挂载」的场景。
   */
  anchor?: HTMLElement | string | (() => HTMLElement | null);
}

/**
 * 抽屉默认宽度。
 *
 * WHY 用 clamp 而不是固定 px / 百分比：属性详情是「边看边点」的辅助视图，
 * 太宽会把地图压掉一半。clamp 让窄屏保底 320px、宽屏封顶 460px，
 * 中间按视口 26% 过渡 —— 1440 屏约 374px、1920 屏 460px。
 */
const DEFAULT_SIZE = 'clamp(320px, 26vw, 460px)';

/**
 * 组件实例 + 它的 effect scope。
 *
 * WHY 需要自己补类型：`instance.scope` 在 Vue 运行时确实存在（createComponentInstance 里
 * `scope: new EffectScope(true)`），但 @vue/runtime-core 的公开 d.ts 没有导出这个字段。
 * 这里用局部交叉类型补齐，避免 any、也不去污染全局 ComponentInternalInstance 声明。
 */
type InstanceWithScope = ComponentInternalInstance & { scope?: EffectScope };

/** 当前处于打开状态的互斥抽屉（模块级单例，供 exclusive 复用） */
let activeDrawer: { destroy: () => void } | null = null;

/**
 * @description 右侧非模态抽屉：从视口右侧浮出，不压暗、不锁滚动，下方列表与地图仍可点击。
 *
 * WHY 不直接用 createDialog：Element Plus 的 el-dialog 是居中模态，遮罩会把整张地图和列表压住，
 * 而属性详情恰恰要「边看详情边点另一条记录」。el-drawer 在 `modal=false + modal-penetrable` 时
 * 包裹层是 `pointer-events:none`（`.el-modal-drawer.is-penetrable`），才能做到真正的点击穿透。
 *
 * @example
 * createDrawer({ title: '记录详情', render: () => <AttributeRowDialog row={row} columns={cols} /> });
 *
 * 缓存复用（关闭后状态不丢，反复打开用同一个实例）：
 * const panel = createDrawer({ visible: false, title: '详情', render: () => <Detail /> });
 * panel.open();   // 打开/再次打开
 * panel.close();  // 隐藏，不销毁，状态保留
 */
export function createDrawer({
  footer = false,
  title,
  render: customRender,
  close: customClose,
  bodyStyle = {},
  style = {},
  appContext,
  cache = false,
  visible,
  exclusive = true,
  anchor,
  owner,
  size = DEFAULT_SIZE,
  direction = 'rtl',
  lockScroll = false,
  modal = false,
  modalPenetrable = true,
  showClose = true,
  ...restProps
}: Partial<Props>) {
  // 互斥：先把上一个抽屉销毁，再挂新的（避免短暂两层叠加）
  if (exclusive && activeDrawer) {
    try {
      activeDrawer.destroy();
    } catch {
      // 旧实例可能已自行销毁，忽略
    }
    activeDrawer = null;
  }

  const div = document.createElement('div');
  div.className = 'create-drawer__host';
  // 页面处于浏览器全屏时 body 上的节点不可见，必须挂进全屏元素
  const host = (document.fullscreenElement as HTMLElement | null) || document.body;
  host.appendChild(div);

  // 常驻判定：显式 cache 或显式 visible:false —— 两者都表示「先不打开、留着复用」
  const persistent = cache || visible === false;
  const state = reactive({ visible: persistent ? false : (visible ?? true) });
  const contentRef = ref();

  // footer === false 时压根不渲染；这里只处理「函数」分支（类型上 false 不可调用）
  const baseFooter = () => (typeof footer === 'function' ? footer() : []);

  const drawer = () => {
    return (
      <ElDrawer
        class={`create-drawer ${footer === false ? '__no-footer' : ''}`}
        // modal-class 落到 ElOverlay 的包裹层上，供 index.scss 覆写穿透
        modalClass="create-drawer__overlay"
        v-model={state.visible}
        onClose={close}
        onClosed={closed}
        style={style}
        appendTo={div}
        direction={direction}
        size={size}
        modal={modal}
        modalPenetrable={modalPenetrable}
        lockScroll={lockScroll}
        showClose={showClose}
        {...restProps}
        onVnodeMounted={syncDom}
        v-slots={{
          header: () => (
            <span class="create-drawer__title" title={typeof title === 'string' ? title : undefined}>
              {title}
            </span>
          ),
          default: () => {
            const node = customRender!();
            return isVNode(node) ? h(node, { ref: contentRef }) : node;
          },
          ...(footer === false ? {} : { footer: baseFooter })
        }}
      />
    );
  };

  /**
   * children 必须传「函数」：Vue 对组件把函数 children 归一化成 default slot，
   * `drawer()` 在渲染期读取 `state.visible` 才能建立响应式依赖。
   * 若传对象（即便是 `{ setup }`），会被当成 slots 字典 —— 没有 `default` 键，
   * ElConfigProvider 渲染为空，抽屉整个不显示（曾踩过）。
   */
  const node = h(ElConfigProvider, { locale: zhCn }, drawer);

  node.appContext = window.__v3_app._context || appContext;

  render(node, div);

  // 路由切换时销毁：抽屉挂在 body 上，不随页面组件卸载，不清掉会残留到下一个页面
  const stopRouteWatch = window.__v3_router ? watch(() => window.__v3_router.currentRoute.value.fullPath, destroy) : () => {};

  /**
   * document 级 Esc 兜底。
   *
   * WHY 不能只靠 EP：ElDrawer 的 Esc 监听挂在 focus-trap 内部（焦点必须在抽屉里才收得到），
   * 而本组件是穿透的浮层 —— 用户看详情时往往正把鼠标停在地图或列表上（焦点不在抽屉），
   * 此时按 Esc 按 EP 的逻辑是收不到的。只在 document 上再挂一个，用 state.visible 幂等去重。
   */
  function onDocKeydown(e: KeyboardEvent) {
    if (!state.visible || e.key !== 'Escape' || e.defaultPrevented) return;
    if (restProps.closeOnPressEscape === false) return;
    // 有更高层的模态（弹窗 / 抽屉）压在详情之上时，Esc 应先关它，不能穿透关掉详情
    const target = e.target as HTMLElement | null;
    const overlay = target?.closest?.('.el-overlay, .el-modal-drawer');
    if (overlay && !div.contains(overlay)) return;
    close();
  }

  document.addEventListener('keydown', onDocKeydown);

  /**
   * leave 过渡的兜底卸载。
   *
   * WHY 不能只信 `onClosed`：ElDrawer 的关闭动画是 Vue Transition，下一步推进要等
   * requestAnimationFrame；页面在后台标签页 / 侧栏未 attach 时 rAF 被暂停，overlay 会永久
   * 卡在 `el-drawer-fade-leave-from`，`transitionend` 与 `afterLeave` 都不触发 ⇒ 抽屉
   * 视觉上「关不掉」（EP 内部 visible 已 false，但 DOM 还在）。
   * 所以可见态一变 false 就排一个定时器，按 EP 的过渡时长（0.3s）兜底硬卸载。
   *
   * CONSTRAINT 必须定义在 unmount 之前：unmount 是函数声明会提升，若 render 期间同步走到
   * unmount，这里的 const 仍处于 TDZ，会抛 ReferenceError。
   */
  const stopVisibleWatch = watch(
    () => state.visible,
    (visible) => {
      if (visible || persistent) return;
      setTimeout(() => {
        if (!state.visible) unmount();
      }, 400);
    }
  );

  /**
   * 卸载并移除容器（普通模式关闭即销毁；缓存模式仅在 destroy 时调用）。
   *
   * WHY 要幂等：销毁有三条触发路径 —— 路由 watch、onClosed / 兜底定时器、owner scope 的
   * onScopeDispose。同一次页面卸载里可能连走两三条，重复 render(null) 虽无害，但会重复
   * 触发带副作用的清理（ResizeObserver 断连、监听移除），幂等开关让它只生效一次。
   */
  let unmounted = false;
  function unmount() {
    if (unmounted) return;
    unmounted = true;
    stopRouteWatch();
    // 兜底 watch 建在模块作用域，render(null, div) 清不掉它，必须显式停：否则每次卸载都残留一个 effect
    stopVisibleWatch();
    document.removeEventListener('keydown', onDocKeydown);
    if (anchor) {
      window.removeEventListener('resize', alignToAnchor);
      anchorObserver?.disconnect();
      anchorObserver = null;
    }
    render(null, div);
    if (div.parentNode) div.parentNode.removeChild(div);
    if (exclusive && activeDrawer === api) activeDrawer = null;
  }
  /** 打开 / 再次打开（缓存模式下复用同一个实例，子组件状态保留） */
  function open() {
    state.visible = true;
    // 缓存模式首次打开时内容才真正挂载，补一次 DOM 修正
    nextTick(syncDom);
  }

  /**
   * 关闭（缓存模式下只隐藏、不销毁）。
   * WHY 加幂等判断：关闭按钮与 Esc 都会走 close()，而 ElDrawer 的 leave 过渡
   * 又会 emit('close') 再调一次；只在「由可见变隐藏」这一次转换里触发 customClose。
   */
  function close() {
    if (!state.visible) return;
    customClose?.();
    state.visible = false;
  }

  function closed() {
    // 缓存模式：保留 DOM 与子组件状态，等 open() 再次显示
    if (persistent) return;
    unmount();
  }

  /** 彻底销毁实例：避免隐藏的 div 长期挂在 body 上 */
  function destroy() {
    state.visible = false;
    unmount();
  }

  /**
   * 把抽屉纵向对齐到 anchor 元素（top / height 跟随它的矩形）。
   *
   * WHY 用内联样式而不是让 SCSS 算：锚点位置是运行时的（表格在树/地图联动布局里，
   * 高度随「地图开没开」「详情列表拖了多高」变化），CSS 拿不到这个值。
   * 内联 style 优先级高于样式表里的 `top` / `bottom`，所以只需要覆盖这两个维度。
   */
  function alignToAnchor() {
    const root = div.getElementsByClassName('el-drawer')[0] as HTMLElement | undefined;
    if (!root || !anchor) return;
    const el = typeof anchor === 'function' ? anchor() : typeof anchor === 'string' ? document.querySelector<HTMLElement>(anchor) : anchor;
    if (!el || !el.isConnected) {
      // 锚点还没挂载/已被卸载：把内联覆盖清掉，退回默认的视口对齐，避免停在旧位置
      root.style.top = '';
      root.style.height = '';
      root.classList.remove('is-anchored');
      return;
    }
    const rect = el.getBoundingClientRect();
    if (!rect.height) return;
    root.style.top = `${Math.round(rect.top)}px`;
    root.style.height = `${Math.round(rect.height)}px`;
    root.classList.add('is-anchored');
  }

  /**
   * 挂载后补齐三件事：
   * 1. 把调用方传入的 bodyStyle 落到 `.el-drawer__body`（ElDrawer 没有 bodyStyle 属性）；
   * 2. 把根节点的 `aria-modal` 改成 false —— EP 硬编码为 "true"，但本组件 modal=false，
   *    对辅助技术而言「页面其余部分仍可交互」，写死 true 会屏蔽下方列表与地图的读屏；
   * 3. 若给了 anchor，把抽屉的 top / height 对齐到它（高度差一截就显得悬空）。
   */
  async function syncDom() {
    await nextTick();
    const body = div.getElementsByClassName('el-drawer__body')[0] as HTMLElement | undefined;
    body?.setAttribute('style', stringifyStyle({ ...(bodyStyle as any) }));

    // resizable 依赖 closest('[aria-modal="true"]') 量宽，启用时不能改
    if (!restProps.resizable) {
      const root = div.getElementsByClassName('el-drawer')[0] as HTMLElement | undefined;
      root?.setAttribute('aria-modal', 'false');
    }

    alignToAnchor();
    watchAnchor();
  }

  /**
   * 锚点跟随：窗口尺寸变化、详情列表被拖高拖低时，抽屉要跟着重新对齐。
   * WHY 用 window resize + ResizeObserver 两条：前者管视口变化（抽屉宽度是 vw 相关），
   * 后者管锚点自身尺寸变化（布局里的 h-split 拖动只改元素高度，不触发窗口事件）。
   */
  let anchorObserver: ResizeObserver | null = null;

  function watchAnchor() {
    if (!anchor) return;
    window.addEventListener('resize', alignToAnchor);
    if (typeof ResizeObserver === 'undefined') return;
    const el = typeof anchor === 'function' ? anchor() : typeof anchor === 'string' ? document.querySelector<HTMLElement>(anchor) : anchor;
    if (!el) return;
    anchorObserver = new ResizeObserver(alignToAnchor);
    anchorObserver.observe(el);
  }

  const api = {
    open,
    close,
    destroy,
    contentRef,
    baseFooter
  };

  if (exclusive) activeDrawer = api;

  /**
   * 把销毁挂到调用方组件的 effect scope 上 —— 页面卸载时抽屉跟着走。
   *
   * WHY 挂在 scope 而不是 onUnmounted：`createDrawer` 常在事件回调里调用，那里没有
   * currentInstance（onUnmounted 会警告且注册不上）；而 scope 拿到手后可以在任意时机 run()。
   * 时序上安全：Scope 停止时先 stop 所有 effects、再执行 cleanups，所以路由 watch 会先被停掉，
   * 不会在 destroy 之后再被路由变化触发一次。
   *
   * owner 优先用调用方显式传入的（setup 顶层存的实例），否则退回当前组件实例（仅限 setup 内直接调用）。
   */
  const instance = (owner === false ? null : (owner ?? getCurrentInstance())) as InstanceWithScope | null;
  const scope = instance?.scope;
  if (scope) {
    // 组件已卸载（或 scope 已停）：注册没有意义，直接销毁避免留下孤儿节点
    if (!scope.active) {
      destroy();
    } else {
      scope.run(() => onScopeDispose(destroy));
    }
  }

  return api;
}
