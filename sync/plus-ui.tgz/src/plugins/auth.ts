import { useUserStore } from '@/store/modules/user';
import { matchPermission } from '@/utils/permission';

const authPermission = (permission: string): boolean => {
  const permissions: string[] = useUserStore().permissions;
  if (!permission || permission.length === 0) {
    return false;
  }
  // 页面级权限模型下后端会下发同模块通配项（task:template:*），这里必须按通配语义匹配
  return permissions.some((v) => matchPermission(v, permission));
};

const authRole = (role: string): boolean => {
  const super_admin = 'admin';
  const roles = useUserStore().roles;
  if (role && role.length > 0) {
    return roles.some((v) => {
      return super_admin === v || v === role;
    });
  } else {
    return false;
  }
};

export default {
  // 验证用户是否具备某权限
  hasPermi(permission: string): boolean {
    return authPermission(permission);
  },
  // 验证用户是否含有指定权限，只需包含其中一个
  hasPermiOr(permissions: string[]): boolean {
    return permissions.some((item) => {
      return authPermission(item);
    });
  },
  // 验证用户是否含有指定权限，必须全部拥有
  hasPermiAnd(permissions: string[]): boolean {
    return permissions.every((item) => {
      return authPermission(item);
    });
  },
  // 验证用户是否具备某角色
  hasRole(role: string): boolean {
    return authRole(role);
  },
  // 验证用户是否含有指定角色，只需包含其中一个
  hasRoleOr(roles: string[]): boolean {
    return roles.some((role) => {
      return authRole(role);
    });
  },
  // 验证用户是否含有指定角色，必须全部拥有
  hasRoleAnd(roles: string[]): boolean {
    return roles.every((role) => {
      return authRole(role);
    });
  }
};
