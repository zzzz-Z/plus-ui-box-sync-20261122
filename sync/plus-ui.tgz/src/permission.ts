import { to as tos } from 'await-to-js';
import router from './router';
import type { RouteLocationNormalized } from 'vue-router';
import NProgress from 'nprogress';
import 'nprogress/nprogress.css';
import { getToken, removeToken, setToken } from '@/utils/auth';
import { isHttp, isPathMatch } from '@/utils/validate';
import { isRelogin } from '@/utils/request';
import { useUserStore } from '@/store/modules/user';
import { useSettingsStore } from '@/store/modules/settings';
import { usePermissionStore } from '@/store/modules/permission';
import { ElMessage } from 'element-plus/es';
import { translateRouteTitle } from '@/utils/i18n';

NProgress.configure({ showSpinner: false });
// 【临时】'/__debug/dag-drag-sim' 用于本地复现拖拽问题，'/__debug/map-draw-sim' 复现地图绘制无响应，验证完删除
const whiteList = ['/login', '/register', '/social-callback', '/register*', '/register/*', '/__debug/dag-drag-sim', '/__debug/map-draw-sim'];

const isWhiteList = (path: string) => {
  return whiteList.some((pattern) => isPathMatch(pattern, path));
};

/**
 * 取出地址上携带的登录态（门户跳转过来时使用）。
 *
 * 同源部署时（门户与子系统同一 域名+端口），两边的 localStorage 天然共享
 * Admin-Token，地址上不会带参数，这里直接返回 null；
 * 跨源部署时（例如门户 80、子系统 8091 的开发环境），门户会把当前 token
 * 拼在地址上（?token=xxx），这里写入本地登录态，并清掉地址上的参数，
 * 避免凭证残留在浏览器历史里。
 */
function takeEntryToken(query: Record<string, any>): { token: string; rest: Record<string, any> } | null {
  const raw = query?.token ?? query?.ticket;
  if (!raw) return null;
  const rest = { ...query };
  delete rest.token;
  delete rest.ticket;
  const token = String(raw)
    .replace(/^Bearer\s+/i, '')
    .trim();
  return { token, rest };
}

/**
 * 未授权任务页面的兜底去向
 *
 * 任务三子系统是本地静态路由，未分配的页面不会被 addRoute，直达地址会落到 404。
 * 这里把「已知任务页面但没权限」与「真的不存在」区分开：前者送回第一个有权限的页面。
 *
 * @param to 目标路由
 * @returns 兜底跳转地址，返回 null 表示不需要兜底
 */
function resolveUnreachablePage(to: RouteLocationNormalized): string | null {
  const isNotFound = to.matched.some((record) => record.path === '/:pathMatch(.*)*');
  if (!isNotFound) {
    return null;
  }
  const permissionStore = usePermissionStore();
  if (!permissionStore.isKnownTaskPath(String(to.path))) {
    return null;
  }
  const fallback = permissionStore.getFirstAccessiblePath();
  return fallback && fallback !== to.path ? fallback : null;
}

router.beforeEach(async (to, from, next) => {
  NProgress.start();

  // 门户跳转带过来的登录态：先落到本地，再用干净地址重新进入本次导航
  const entry = takeEntryToken(to.query as Record<string, any>);
  if (entry) {
    if (entry.token) setToken(entry.token);
    next({ path: to.path, query: entry.rest, hash: to.hash, replace: true });
    NProgress.done();
    return;
  }

  if (getToken()) {
    to.meta.title && useSettingsStore().setTitle(translateRouteTitle(to.meta.title as string));
    /* has token*/
    if (to.path === '/login') {
      next({ path: '/' });
      NProgress.done();
    } else if (isWhiteList(to.path)) {
      next();
    } else {
      if (useUserStore().roles.length === 0) {
        isRelogin.show = true;
        // 判断当前用户是否已拉取完user_info信息
        const [err] = await tos(useUserStore().getInfo());
        if (err) {
          // 登录态无效或已过期：只清本应用的状态，不再调后端 /auth/logout。
          // 该 token 与门户共用，贸然注销会连带把仍然有效的门户会话一起踢掉。
          removeToken();
          useUserStore().roles = [];
          useUserStore().permissions = [];
          ElMessage.error(err);
          isRelogin.show = false;
          const redirect = encodeURIComponent(to.fullPath || '/');
          next(`/login?redirect=${redirect}`);
          NProgress.done();
        } else {
          isRelogin.show = false;
          const accessRoutes = await usePermissionStore().generateRoutes();
          // 根据roles权限生成可访问的路由表
          accessRoutes.forEach((route) => {
            if (!isHttp(route.path)) {
              router.addRoute(route); // 动态添加可访问路由表
            }
          });
          // @ts-expect-error hack方法 确保addRoutes已完成
          next({ path: to.path, replace: true, params: to.params, query: to.query, hash: to.hash, name: to.name as string }); // hack方法 确保addRoutes已完成
        }
      } else {
        // 页面级权限兜底：地址是任务三子系统里的已知页面、但当前角色没被分配（路由没注册 → 落到 404），
        // 直接送回第一个有权限的页面，避免"点菜单/刷新就 404"。
        const fallback = resolveUnreachablePage(to);
        if (fallback) {
          NProgress.done();
          next({ path: fallback, replace: true });
          return;
        }
        next();
      }
    }
  } else {
    // 没有token
    if (isWhiteList(to.path)) {
      // 在免登录白名单，直接进入
      next();
    } else {
      const redirect = encodeURIComponent(to.fullPath || '/');
      next(`/login?redirect=${redirect}`); // 否则全部重定向到登录页
      NProgress.done();
    }
  }
});

router.afterEach(() => {
  NProgress.done();
});
