import { defineStore } from 'pinia';
import router, { constantRoutes, dynamicRoutes } from '@/router';
import store from '@/store';
import { getRouters } from '@/api/menu';
import auth from '@/plugins/auth';
import { RouteRecordRaw } from 'vue-router';
import Layout from '@/layout/index.vue';
import ParentView from '@/components/ParentView/index.vue';
import InnerLink from '@/layout/components/InnerLink/index.vue';
import { ref } from 'vue';
import { createCustomNameComponent } from '@/utils/createCustomNameComponent';
import { useUserStore } from '@/store/modules/user';
import { useAppStore } from '@/store/modules/app';

// 匹配views里面所有的.vue文件
const modules = import.meta.glob('./../../views/**/*.vue');

/**
 * 任务三子系统的根路径
 *
 * 这三套页面是**前端本地静态路由**：路由表不随后端菜单变化，
 * 但「哪个界面分配给了当前角色」只有后端菜单树知道，所以是否可见要在本地再过滤一次。
 */
const TASK_ROOT_PATHS = ['/task-scheduling', '/task-resource', '/task-monitor'];

/** 归一化匹配键：忽略大小写、中划线、下划线与空白，容忍路径/菜单名写法差异 */
const normalizeKey = (value: unknown): string =>
  String(value ?? '')
    .replace(/[-_\s]/g, '')
    .toLowerCase();

/** 拼接父子路由路径（子路由可能带前导 /，也可能不带） */
const joinRoutePath = (parentPath: string, path: string): string => {
  const value = String(path ?? '');
  if (!value) return parentPath || '';
  if (value.startsWith('/')) return value;
  return `${parentPath}/${value}`.replace(/\/{2,}/g, '/');
};

/**
 * 从后端菜单树里提取「任务三子系统已授权的页面」匹配键
 *
 * 输出包含三种口径（全部归一化）：绝对路径、路径末段、菜单标题。
 * WHY 三种都收：菜单表里 path 的写法与前端路由不一定完全一致（大小写/中划线/驼峰），
 * 只按绝对路径比对容易把「已分配」的页面误判成「没分配」，导致界面凭空消失。
 *
 * @param routes 后端菜单树（getRouters 的返回值）
 * @returns 已授权页面的匹配键集合
 */
const collectGrantedPageKeys = (routes: RouteRecordRaw[]): Set<string> => {
  const keys = new Set<string>();
  const walk = (list: RouteRecordRaw[], parentPath: string) => {
    list.forEach((route) => {
      const path = joinRoutePath(parentPath, String((route as any).path ?? ''));
      const inTaskModule = TASK_ROOT_PATHS.some((root) => path === root || path.startsWith(`${root}/`));
      if (inTaskModule) {
        keys.add(normalizeKey(path));
        const lastSegment = path.split('/').filter(Boolean).pop();
        if (lastSegment) keys.add(normalizeKey(lastSegment));
        const title = (route as any).meta?.title;
        if (title) keys.add(normalizeKey(title));
      }
      const children = (route as any).children;
      if (Array.isArray(children) && children.length) walk(children, path);
    });
  };
  walk(routes, '');
  return keys;
};

/**
 * 任务三子系统是否按「页面级权限」控制可见性
 *
 * 出问题时可临时改成 false：恢复「任务页面全部可见」的旧行为（后端接口权限仍然照常校验），
 * 用于现场应急；改完需要重新构建前端。
 */
const TASK_PAGE_VISIBILITY_ENABLED = true;

/**
 * 任务三子系统的全部页面路径（本地静态路由全集，用于判断「这个地址是不是已知页面」）
 *
 * 注意：必须在首次调用时再读 {@link dynamicRoutes}，不能在模块顶层直接读。
 * WHY：permission store 处在 router 的依赖环上（router → Layout → Sidebar → 本 store），
 * 模块求值时 `dynamicRoutes` 还在 TDZ 里，顶层读取会抛
 * `Cannot access 'dynamicRoutes' before initialization`，整个应用挂不起来（表现为一直转圈）。
 */
let cachedTaskPagePaths: string[] | null = null;
const getTaskPagePaths = (): string[] => {
  if (!cachedTaskPagePaths) {
    cachedTaskPagePaths = dynamicRoutes.flatMap((root) =>
      ((root as any).children || []).map((child: RouteRecordRaw) =>
        joinRoutePath(String((root as any).path ?? ''), String((child as any).path ?? ''))
      )
    );
  }
  return cachedTaskPagePaths;
};

/**
 * 单个页面是否对当前用户可见（页面级权限判定）
 *
 * 判定顺序：
 * 1. 后端菜单树里分配了这个页面 → 可见（菜单授权的既有口径）；
 * 2. 页面登记了 meta.permPrefix 且用户拥有该前缀下任意权限点 → 可见（权限点口径）；
 * 3. 没有登记 permPrefix 的页面（后端没有对应权限点）→ 只要用户还有任何授权信息就放行，避免误伤；
 * 4. 其余情况不可见。
 *
 * @param route      任务三子系统的页面路由
 * @param parentPath 父级路由路径
 * @param keys       后端菜单树里已授权页面的匹配键
 * @param permissions 当前用户的权限点集合
 */
const isTaskPageVisible = (route: RouteRecordRaw, parentPath: string, keys: Set<string>, permissions: string[]): boolean => {
  const fullPath = joinRoutePath(parentPath, String((route as any).path ?? ''));
  const meta: any = (route as any).meta || {};
  const lastSegment = fullPath.split('/').filter(Boolean).pop();
  const grantedByMenu =
    keys.has(normalizeKey(fullPath)) ||
    (!!lastSegment && keys.has(normalizeKey(lastSegment))) ||
    (!!meta.title && keys.has(normalizeKey(meta.title)));
  if (grantedByMenu) {
    return true;
  }
  const permPrefix = String(meta.permPrefix ?? '');
  if (permPrefix) {
    const head = `${permPrefix}:`;
    return permissions.some((granted) => granted === '*:*:*' || granted.startsWith(head));
  }
  // 没有权限点的页面无法按权限分级：用户只要还有任何授权信息就维持可见
  return permissions.length > 0 || keys.size > 0;
};

/**
 * 按页面级权限过滤任务三子系统路由
 *
 * 父级下没有任何可见子页面时整体移除；保留的父级把 redirect 指向第一个可见子页面，
 * 避免「默认落地页被隐藏后一点菜单就 404」。
 *
 * @param modules     任务三子系统根路由
 * @param keys        后端菜单树里已授权页面的匹配键
 * @param permissions 当前用户的权限点集合
 * @returns 过滤后的路由
 */
const filterTaskRoutes = (modules: RouteRecordRaw[], keys: Set<string>, permissions: string[]): RouteRecordRaw[] => {
  if (!TASK_PAGE_VISIBILITY_ENABLED) {
    return modules;
  }
  const result: RouteRecordRaw[] = [];
  modules.forEach((root) => {
    const children = ((root as any).children || []).filter((child: RouteRecordRaw) =>
      isTaskPageVisible(child, String((root as any).path ?? ''), keys, permissions)
    );
    if (!children.length) {
      return;
    }
    const firstVisible = children.find((child: RouteRecordRaw) => !(child as any).hidden);
    result.push({
      ...root,
      redirect: firstVisible ? joinRoutePath(String((root as any).path ?? ''), String((firstVisible as any).path ?? '')) : (root as any).redirect,
      children
    } as RouteRecordRaw);
  });
  return result;
};

export const usePermissionStore = defineStore('permission', () => {
  /**
   * 顶层菜单若未声明 Layout，强制包一层父路由；否则页面直接挂在根 router-view 上，
   * 绕过全局 Navbar/Sidebar，表现为看不到布局菜单和 header。
   */
  const normalizeTopLevel = (list: RouteRecordRaw[]): RouteRecordRaw[] =>
    list.map((route) => {
      if (route.component === Layout) return route;
      if (!route.path) return route;
      return {
        path: route.path,
        component: Layout,
        children: [{ ...route, path: '' }],
        meta: route.meta
      } as RouteRecordRaw;
    });

  const routes = ref<RouteRecordRaw[]>([]);
  const addRoutes = ref<RouteRecordRaw[]>([]);
  const defaultRoutes = ref<RouteRecordRaw[]>([]);
  const topbarRouters = ref<RouteRecordRaw[]>([]);
  const sidebarRouters = ref<RouteRecordRaw[]>([]);
  /** 「数据管理」分区的菜单：后端菜单树（即原管理系统那套菜单） */
  const manageRouters = ref<RouteRecordRaw[]>([]);
  /** 任务三子系统里当前用户可见的路由（已按页面级权限过滤，侧边栏与路由注册共用） */
  const taskRouters = ref<RouteRecordRaw[]>([]);

  const getRoutes = (): RouteRecordRaw[] => {
    return routes.value as RouteRecordRaw[];
  };
  const getDefaultRoutes = (): RouteRecordRaw[] => {
    return defaultRoutes.value as RouteRecordRaw[];
  };
  const getSidebarRoutes = (): RouteRecordRaw[] => {
    return sidebarRouters.value as RouteRecordRaw[];
  };
  const getTopbarRoutes = (): RouteRecordRaw[] => {
    return topbarRouters.value as RouteRecordRaw[];
  };
  const getManageRoutes = (): RouteRecordRaw[] => {
    return manageRouters.value as RouteRecordRaw[];
  };
  /** 任务三子系统里当前用户可见的路由 */
  const getTaskRoutes = (): RouteRecordRaw[] => {
    return taskRouters.value as RouteRecordRaw[];
  };
  /** 第一个可见的任务页面（登录后的默认落地页 / 无权限页面的兜底去向） */
  const getFirstAccessiblePath = (): string => {
    for (const root of taskRouters.value) {
      for (const child of (root as any).children || []) {
        if (!(child as any).hidden) {
          return joinRoutePath(String((root as any).path ?? ''), String((child as any).path ?? ''));
        }
      }
    }
    return '/index';
  };
  /** 该地址是否为任务三子系统中已定义的页面（用于区分「没权限」与「真 404」） */
  const isKnownTaskPath = (path: string): boolean => {
    const allPaths = getTaskPagePaths();
    return allPaths.includes(path) || allPaths.includes(path.replace(/\/$/, ''));
  };

  const setRoutes = (newRoutes: RouteRecordRaw[]): void => {
    addRoutes.value = newRoutes;
    routes.value = constantRoutes.concat(newRoutes);
  };
  const setDefaultRoutes = (routes: RouteRecordRaw[]): void => {
    defaultRoutes.value = constantRoutes.concat(routes);
  };
  const setTopbarRoutes = (routes: RouteRecordRaw[]): void => {
    topbarRouters.value = routes;
  };
  /**
   * 重置侧边栏为「任务三子系统」菜单（已按页面级权限过滤）
   *
   * 入参仅为兼容历史调用（TopNav / 设置面板会传入各自的路由集合），
   * 该字段一直只展示任务子系统菜单，不随后端菜单变化。
   *
   * @param _routes 兼容用，未使用
   */
  const setSidebarRouters = (_routes?: RouteRecordRaw[]): void => {
    sidebarRouters.value = taskRouters.value;
  };
  const generateRoutes = async (): Promise<RouteRecordRaw[]> => {
    const res = await getRouters();
    const { data } = res;
    const sdata = JSON.parse(JSON.stringify(data));
    const rdata = JSON.parse(JSON.stringify(data));
    const defaultData = JSON.parse(JSON.stringify(data));
    const sidebarRoutes = filterAsyncRouter(sdata);
    const rewriteRoutes = normalizeTopLevel(filterAsyncRouter(rdata, undefined, true));
    const defaultRoutes = filterAsyncRouter(defaultData);
    /**
     * 页面级权限过滤：任务三子系统是本地静态路由，先按「后端菜单树是否分配了该页面 + 用户是否有该页面
     * 权限前缀下的任意权限点」过滤，再注册路由与渲染侧边栏。
     * 没被分配到的界面既不在侧边栏出现，也不能通过直接敲地址访问。
     */
    const taskPageKeys = collectGrantedPageKeys(sidebarRoutes);
    const accessibleTaskRoutes = filterTaskRoutes(dynamicRoutes, taskPageKeys, useUserStore().permissions);
    taskRouters.value = accessibleTaskRoutes;
    if (import.meta.env.DEV) {
      // 页面级权限排障用：控制台里能看到「后端菜单树命中的页面标识」与「最终可见的任务页面」
      console.info('[页面级权限] 菜单命中的页面标识：', [...taskPageKeys]);
      console.info(
        '[页面级权限] 可见的任务页面：',
        accessibleTaskRoutes.flatMap((root: any) => (root.children || []).map((child: any) => child.path))
      );
    }
    const asyncRoutes = filterDynamicRoutes(accessibleTaskRoutes);
    asyncRoutes.forEach((route) => {
      router.addRoute(route);
    });
    /**
     * 任务三子系统（/task-scheduling、/task-resource、/task-monitor）属于「任务管理」分区。
     * 它们虽然也在后端菜单表里（用于权限点与角色授权），但**不能**算进「数据管理」分区，
     * 否则点头部「数据管理」的侧边栏里会冒出这三套任务菜单。
     */
    const isTaskRoot = (r: RouteRecordRaw) => TASK_ROOT_PATHS.includes(String((r as any).path || ''));

    // 后端菜单统一标记为「数据管理」分区（侧边栏分区切换用），
    // 同时挂到路由表上的那份也要标记，页面内的 route.matched 才能识别当前分区。
    // 任务三子系统不标记，它们归「任务管理」分区。
    const tagManage = (list: RouteRecordRaw[]) => {
      list.forEach((r) => {
        if (isTaskRoot(r)) return;
        r.meta = { ...(r.meta || {}), group: 'manage' } as any;
      });
    };
    tagManage(sidebarRoutes);
    tagManage(rewriteRoutes);
    setRoutes(rewriteRoutes);
    setSidebarRouters();
    // 「数据管理」分区 = 后端菜单树里排除任务三子系统后的部分
    //（任务三子系统由「任务管理」分区的侧边栏展示，见 store 里的 sidebarRouters）
    manageRouters.value = sidebarRoutes.filter((r) => !isTaskRoot(r));
    // 一个任务页面都没分配时，侧边栏自动切到「数据管理」，避免登录后停在空菜单
    if (!accessibleTaskRoutes.length && manageRouters.value.length && useAppStore().activeGroup === 'task') {
      useAppStore().setActiveGroup('manage');
    }
    setDefaultRoutes(sidebarRoutes);
    setTopbarRoutes(defaultRoutes);
    // 路由name重复检查
    duplicateRouteChecker(asyncRoutes, sidebarRoutes);
    return new Promise<RouteRecordRaw[]>((resolve) => resolve(rewriteRoutes));
  };

  /**
   * 遍历后台传来的路由字符串，转换为组件对象
   * @param asyncRouterMap 后台传来的路由字符串
   * @param lastRouter 上一级路由
   * @param type 是否是重写路由
   */
  const filterAsyncRouter = (asyncRouterMap: RouteRecordRaw[], lastRouter?: RouteRecordRaw, type = false): RouteRecordRaw[] => {
    return asyncRouterMap.filter((route) => {
      if (type && route.children) {
        route.children = filterChildren(route.children, undefined);
      }
      // Layout ParentView 组件特殊处理
      if (route.component?.toString() === 'Layout') {
        route.component = Layout;
      } else if (route.component?.toString() === 'ParentView') {
        route.component = ParentView;
      } else if (route.component?.toString() === 'InnerLink') {
        route.component = InnerLink;
      } else {
        const resolved = loadView(route.component, route.name as string);
        // 顶层目录解析不到组件时用 Layout 兜底：否则子路由直接挂到根 router-view，绕过 Navbar/Sidebar
        route.component = resolved || (!lastRouter && Array.isArray(route.children) && route.children.length ? Layout : resolved);
      }
      if (route.children != null && route.children && route.children.length) {
        route.children = filterAsyncRouter(route.children, route, type);
      } else {
        delete route.children;
        delete route.redirect;
      }
      return true;
    });
  };
  const filterChildren = (childrenMap: RouteRecordRaw[], lastRouter?: RouteRecordRaw): RouteRecordRaw[] => {
    let children: RouteRecordRaw[] = [];
    childrenMap.forEach((el) => {
      // 以 / 开头的 path 是绝对路径，不能再前缀父路径，否则后端菜单里挂的前端路由会拼出错误 URL
      el.path = lastRouter && !el.path.startsWith('/') ? lastRouter.path + '/' + el.path : el.path;
      if (el.children && el.children.length && el.component?.toString() === 'ParentView') {
        children = children.concat(filterChildren(el.children, el));
      } else {
        children.push(el);
      }
    });
    return children;
  };
  return {
    routes,
    topbarRouters,
    sidebarRouters,
    manageRouters,
    defaultRoutes,
    taskRouters,

    getRoutes,
    getDefaultRoutes,
    getSidebarRoutes,
    getTopbarRoutes,
    getManageRoutes,
    getTaskRoutes,
    getFirstAccessiblePath,
    isKnownTaskPath,

    setRoutes,
    generateRoutes,
    setSidebarRouters
  };
});

// 动态路由遍历，验证是否具备权限
export const filterDynamicRoutes = (routes: RouteRecordRaw[]) => {
  const res: RouteRecordRaw[] = [];
  routes.forEach((route) => {
    if (route.permissions) {
      if (auth.hasPermiOr(route.permissions)) {
        res.push(route);
      }
    } else if (route.roles) {
      if (auth.hasRoleOr(route.roles)) {
        res.push(route);
      }
    } else {
      // 无权限限制的路由直接添加
      res.push(route);
    }
  });
  return res;
};

export const loadView = (view: any, name: string) => {
  // 1) 精确匹配：后端菜单 component 字段为 views/ 下相对路径（不带 .vue）
  for (const path in modules) {
    const viewsIndex = path.indexOf('/views/');
    let dir = path.substring(viewsIndex + 7);
    dir = dir.substring(0, dir.lastIndexOf('.vue'));
    if (dir === view) {
      return createCustomNameComponent(modules[path], { name });
    }
  }

  // 2) 兜底：后端菜单 component 字段为 PascalCase 组件名（如 MetadataManage）。
  // WHY 需要兜底：若不加，路由会静默解析失败并触发「Failed to resolve component」，
  // 页面挂空。此处按 PascalCase → kebab-case 规则找匹配的 **/{kebab}/index.vue。
  if (typeof view === 'string' && /^[A-Z]/.test(view)) {
    const kebab = view.replace(/([a-z0-9])([A-Z])/g, '$1-$2').toLowerCase();
    for (const path in modules) {
      const viewsIndex = path.indexOf('/views/');
      let dir = path.substring(viewsIndex + 7);
      dir = dir.substring(0, dir.lastIndexOf('.vue'));
      if (dir.endsWith('/' + kebab + '/index') || dir === kebab) {
        return createCustomNameComponent(modules[path], { name });
      }
    }
  }

  return undefined;
};

// 非setup
export const usePermissionStoreHook = () => {
  return usePermissionStore(store);
};

interface Route {
  name?: string | symbol;
  path: string;
  children?: Route[];
}

/**
 * 检查路由name是否重复
 * @param localRoutes 本地路由
 * @param routes 动态路由
 */
function duplicateRouteChecker(localRoutes: Route[], routes: Route[]) {
  // 展平
  function flatRoutes(routes: Route[]) {
    const res: Route[] = [];
    routes.forEach((route) => {
      if (route.children) {
        res.push(...flatRoutes(route.children));
      } else {
        res.push(route);
      }
    });
    return res;
  }

  const allRoutes = flatRoutes([...localRoutes, ...routes]);

  const nameList: string[] = [];
  allRoutes.forEach((route) => {
    const name = route.name.toString();
    if (name && nameList.includes(name)) {
      const message = `路由名称: [${name}] 重复, 会造成 404`;
      console.error(message);
      ElNotification({
        title: '路由名称重复',
        message,
        type: 'error'
      });
      return;
    }
    nameList.push(route.name.toString());
  });
}
