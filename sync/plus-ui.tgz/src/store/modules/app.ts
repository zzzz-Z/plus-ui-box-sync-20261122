import zhCN from 'element-plus/es/locale/lang/zh-cn';
import enUS from 'element-plus/es/locale/lang/en';
import { defineStore } from 'pinia';
import { useStorage } from '@vueuse/core';
import { ref, reactive, computed } from 'vue';
import { LanguageEnum } from '@/enums/LanguageEnum';
import { language, getLanguage } from '@/lang/index';

export const useAppStore = defineStore('app', () => {
  const sidebarStatus = useStorage('sidebarStatus', '1');
  const sidebar = reactive({
    opened: sidebarStatus.value ? !!+sidebarStatus.value : true,
    withoutAnimation: false,
    hide: false
  });
  const device = ref<string>('desktop');
  const size = useStorage<'large' | 'default' | 'small'>('size', 'default');

  // 语言：language 为唯一真源（来自 @/lang/index），Element Plus locale 由它派生
  const languageObj: Record<string, any> = {
    en_US: enUS,
    zh_CN: zhCN
  };
  const locale = computed(() => languageObj[getLanguage()] || zhCN);

  const toggleSideBar = (withoutAnimation: boolean) => {
    if (sidebar.hide) {
      // 侧边栏被整块隐藏时（驾驶舱全屏页 screen、顶部导航布局），点汉堡按钮应当"恢复侧边栏"；
      // 旧逻辑直接 return false，会让用户卡在没有菜单的页面里出不来。
      sidebar.hide = false;
      sidebar.opened = true;
      sidebarStatus.value = '1';
      return true;
    }

    sidebar.opened = !sidebar.opened;
    sidebar.withoutAnimation = withoutAnimation;
    if (sidebar.opened) {
      sidebarStatus.value = '1';
    } else {
      sidebarStatus.value = '0';
    }
  };

  const closeSideBar = ({ withoutAnimation }: any): void => {
    sidebarStatus.value = '0';
    sidebar.opened = false;
    sidebar.withoutAnimation = withoutAnimation;
  };
  const toggleDevice = (d: string): void => {
    device.value = d;
  };
  const setSize = (s: 'large' | 'default' | 'small'): void => {
    size.value = s;
  };
  const toggleSideBarHide = (status: boolean): void => {
    sidebar.hide = status;
  };

  const changeLanguage = (val: string): void => {
    language.value = val as LanguageEnum;
  };

  // 当前激活的分系统
  const activeSystem = ref<string>('system1');
  const setActiveSystem = (system: string): void => {
    activeSystem.value = system;
  };

  /**
   * 侧边栏分区：
   *  - task   = 三个分系统（任务管理调度 / 任务资源管理 / 任务监控评价）
   *  - manage = 数据管理（后端菜单树，即原管理系统那套菜单）
   */
  const activeGroup = useStorage<'task' | 'manage'>('activeGroup', 'task');
  const setActiveGroup = (group: 'task' | 'manage'): void => {
    activeGroup.value = group;
  };

  return {
    device,
    sidebar,
    language,
    locale,
    size,
    activeSystem,
    setActiveSystem,
    activeGroup,
    setActiveGroup,
    changeLanguage,
    toggleSideBar,
    closeSideBar,
    toggleDevice,
    setSize,
    toggleSideBarHide
  };
});
