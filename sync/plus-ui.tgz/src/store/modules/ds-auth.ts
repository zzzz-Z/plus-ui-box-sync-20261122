/**
 * 海豚(DolphinScheduler)登录态 store
 * 不再自动登录。sessionId 优先取 .env 中配置的静态值(VITE_APP_DS_SESSION_ID),
 * 其次回退到 localStorage 中保存的旧值。
 */
import { defineStore } from 'pinia';
import { ref } from 'vue';

const DS_SESSION_KEY = 'ds_session_id';
const staticSessionId = (import.meta.env.VITE_APP_DS_SESSION_ID as string) || '';

export const useDsAuthStore = defineStore('ds-auth', () => {
  const sessionId = ref<string>(
    staticSessionId || localStorage.getItem(DS_SESSION_KEY) || ''
  );

  const setSessionId = (id: string) => {
    sessionId.value = id || '';
    if (id) {
      localStorage.setItem(DS_SESSION_KEY, id);
    } else {
      localStorage.removeItem(DS_SESSION_KEY);
    }
  };

  const logout = () => setSessionId('');

  return { sessionId, setSessionId, logout };
});
