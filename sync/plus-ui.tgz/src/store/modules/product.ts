import { defineStore } from 'pinia';
import { ref } from 'vue';
import { useStorage } from '@vueuse/core';
import router from '@/router';
import { arrayToTree } from '@/utils/product-manage/arrayToTree';

interface StoreState {
  /** 登录成功后由后端返回的访问令牌。 */
  token: string;
  /** 当前登录用户的基本资料。 */
  user: defs.SysUserSelectSchema;
  /** 已转换为树形结构的可见菜单，供布局菜单组件使用。 */
  menus: defs.SysMenuSelectSchema[];
  /** 当前用户拥有的按钮和接口权限标识。 */
  permissions: string[];
  /** 保留接口返回的扁平菜单，用于后续生成动态路由。 */
  dynamicRoutes: defs.SysMenuSelectSchema[];
}

export const useProductAppStore = defineStore('product-manage', () => {
  // 使用 Vite 的 glob 导入提前建立“菜单组件路径 -> Vue 组件”的映射。
  // 动态路由生成时只需根据后端返回的 component 字段查找组件，不需要运行时加载任意文件。
  const modules = import.meta.glob('@/views/product-manage/**/*.vue');

  // useStorage 会同步读写 localStorage，使刷新页面后登录态、菜单和权限仍然可用。
  const storage = useStorage<StoreState | null>('__v3_temp', {
    token: '',
    user: {},
    menus: [],
    permissions: [],
    dynamicRoutes: []
  });

  const dynamicRoutesLoaded = ref(false);

  /**
   * 从后端获取当前用户的菜单，并同步更新菜单树、动态路由源数据和权限列表。
   * 按钮菜单（menuType === 'F'）以及不可见菜单只参与权限计算，不生成导航菜单或页面路由。
   */
  async function getDynamicRoutes() {
    const res = await API.menu.postMenuAll.request({});
    if (res.code === 200) {
      // 页面菜单需要保留目录和页面节点，但过滤掉按钮节点与后端标记为不可见的节点。
      const data = res.data!.filter((v: any) => v.menuType !== 'F' && v.visible !== '0');
      storage.value!.dynamicRoutes = data;
      storage.value!.menus = arrayToTree(data);
      // 权限标识来自全部菜单数据，按钮权限不能因为不显示在导航中而丢失。
      storage.value!.permissions = res.data!.map((v: any) => v.perms!).filter((v: string) => v);
    }
  }

  /**
   * 将单个后端菜单转换为 vue-router 路由配置。
   * 根目录或根页面使用 Page 作为布局容器；普通页面则直接挂载实际页面组件。
   */
  function genRouteCfg(route: defs.SysMenuSelectSchema) {
    // glob 的 key 与后端 component 拼接后必须严格匹配，例如 /user/index.vue。
    const component = modules[`/src/pages${route.component}.vue`];
    const isRoot = Number(route.parentId) === 0;

    // 保留菜单自身的业务字段，同时补充 router 使用的图标和标题元数据。
    const baseCfg = {
      id: route.id,
      parentId: route.parentId,
      path: route.path,
      meta: {
        icon: route.icon,
        title: route.menuName,
        isCache: route.isCache
      }
    };

    // M 是目录；根级 C 也需要一个空路径子路由，才能在 Page 布局下渲染页面。
    if (route.menuType === 'M' || (isRoot && route.menuType === 'C')) {
      return {
        ...baseCfg,
        component: isRoot ? () => import('@/layout/index.vue') : null,
        children: [
          {
            path: '',
            name: route.menuName,
            meta: baseCfg.meta,
            component
          }
        ]
      };
    }

    // 非根级 C 是普通页面路由，直接使用页面组件渲染。
    if (route.menuType === 'C') {
      return {
        ...baseCfg,
        name: route.menuName,
        component
      };
    }
  }

  /** 将缓存的扁平菜单转换成嵌套路由，并注册到基础路由树中。 */
  function addDynamicRoutes() {
    const routes = storage.value!.dynamicRoutes?.map?.((item) => genRouteCfg(item));
    if (!routes?.length) {
      dynamicRoutesLoaded.value = true;
      return;
    }

    arrayToTree(routes).forEach((route) => {
      router.addRoute(route);
    });

    dynamicRoutesLoaded.value = true;
  }

  return {
    storage,
    addDynamicRoutes,
    getDynamicRoutes,
    dynamicRoutesLoaded
  };
});
