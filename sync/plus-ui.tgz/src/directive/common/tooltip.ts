// DEPRECATED: v-tooltip 由 floating-vue 提供，本文件不再被引用，可安全删除。
export default {};
