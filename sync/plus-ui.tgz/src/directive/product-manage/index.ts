import { useProductAppStore } from '@/store/modules/product';
import type { App, Directive, DirectiveBinding } from 'vue';

const permission: Directive = {
  mounted(el: HTMLElement, binding: DirectiveBinding) {
    const { value, arg } = binding;
    const store = useProductAppStore();
    const permissions = store.storage?.permissions ?? [];
    if (!permissions.includes(value ?? arg ?? '')) {
      el.parentNode && el.parentNode.removeChild(el);
    }
  }
};

export default function (app: App) {
  app.directive('perm', permission);
}
