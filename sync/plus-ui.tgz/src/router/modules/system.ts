import Layout from '@/layout/index.vue';
import { RouteRecordRaw } from 'vue-router';

/**
 * 系统管理公共路由（不设置 meta.system，始终显示在侧边栏）
 */
const systemRoutes: RouteRecordRaw = {
  path: '/system',
  component: Layout,
  redirect: '/system/dict',
  meta: { title: '系统管理', icon: 'system' },
  children: [
    {
      path: 'dict',
      component: () => import('@/views/system/dict/index.vue'),
      name: 'SystemDict',
      meta: { title: '数据字典', icon: 'dict' }
    }
  ]
};

export default systemRoutes;
