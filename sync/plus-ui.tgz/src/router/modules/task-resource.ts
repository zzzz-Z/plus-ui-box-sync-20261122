import Layout from '@/layout/index.vue';
import { RouteRecordRaw } from 'vue-router';

/**
 * 任务资源管理（任务三子系统之一）
 *
 * meta.permPrefix：该页面的「页面级权限前缀」，判定口径见 task-scheduling.ts 顶部说明。
 * 未登记 permPrefix 的页面表示后端暂无对应权限点（无法按权限分级），保持原样放行。
 */
const taskResourceRoutes: RouteRecordRaw = {
  path: '/task-resource',
  component: Layout,
  redirect: '/task-resource/post-manage',
  meta: { title: '任务资源管理', icon: 'list', system: 'system2' },
  children: [
    {
      path: 'post-manage',
      component: () => import('@/views/task-resource/post-manage.vue'),
      name: 'PostManage',
      meta: { title: '作业岗位管理', icon: 'post', system: 'system2', permPrefix: 'task:workPost' }
    },
    {
      path: 'unit-manage',
      component: () => import('@/views/task-resource/unit-manage.vue'),
      name: 'UnitManage',
      meta: { title: '作业单元管理', icon: 'component', system: 'system2', permPrefix: 'task:workUnit' }
    },
    {
      path: 'infra-manage',
      component: () => import('@/views/task-resource/infra-manage.vue'),
      name: 'InfraManage',
      meta: { title: '基础设施管理', icon: 'server', system: 'system2' }
    },
    {
      path: 'data-manage',
      component: () => import('@/views/task-resource/data-manage.vue'),
      name: 'DataManage',
      meta: { title: '作业资料管理', icon: 'documentation', system: 'system2', permPrefix: 'task:jobData' }
    },
    {
      path: 'temp-space',
      component: () => import('@/views/task-resource/temp-space.vue'),
      name: 'TempSpace',
      meta: { title: '临时空间管理', icon: 'zip', system: 'system2', permPrefix: 'task:tempSpace' }
    },
    {
      path: 'resource-monitor',
      component: () => import('@/views/task-resource/resource-monitor.vue'),
      name: 'ResourceMonitor',
      meta: { title: '资源使用监控', icon: 'monitor', system: 'system2' }
    },
    {
      path: 'hier-dict',
      component: () => import('@/views/task-resource/hier-dict.vue'),
      name: 'HierDict',
      meta: { title: '字典管理', icon: 'tree', system: 'system2' }
    }
  ]
};

export default taskResourceRoutes;
