import Layout from '@/layout/index.vue';
import { RouteRecordRaw } from 'vue-router';

const taskMonitorRoutes: RouteRecordRaw = {
  path: '/task-monitor',
  component: Layout,
  redirect: '/task-monitor/task-monitor',
  meta: { title: '任务监控评价', icon: 'list', system: 'system3' },
  children: [
    {
      path: 'task-monitor',
      component: () => import('@/views/task-monitor/task-monitor.vue'),
      name: 'TaskMonitor',
      meta: { title: '任务监控', icon: 'monitor', system: 'system3' }
    },
    {
      path: 'task-evaluate',
      component: () => import('@/views/task-monitor/task-evaluate.vue'),
      name: 'TaskEvaluate',
      meta: { title: '任务评价', icon: 'star', system: 'system3' }
    },
    {
      path: 'task-statistics',
      component: () => import('@/views/task-monitor/task-statistics.vue'),
      name: 'TaskStatistics',
      meta: { title: '任务统计', icon: 'chart', system: 'system3' }
    },
  ]
};

export default taskMonitorRoutes;
