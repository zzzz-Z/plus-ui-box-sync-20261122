import Layout from '@/layout/index.vue';
import { RouteRecordRaw } from 'vue-router';

/**
 * 任务管理调度（任务三子系统之一）
 *
 * meta.permPrefix：该页面的「页面级权限前缀」。
 * 页面级权限模型下，角色只要拥有该前缀下的任意权限点（如 task:template:list /
 * task:template:*），就认为这个界面已分配，界面内操作默认全部可用；
 * 一个都没有则界面不出现、直达也会被拦回。
 * 没有登记 permPrefix 的页面表示后端暂无对应权限点（无法按权限分级），保持原样放行。
 */
const taskSchedulingRoutes: RouteRecordRaw = {
  path: '/task-scheduling',
  component: Layout,
  redirect: '/task-scheduling/task-approval',
  meta: { title: '任务管理调度', icon: 'list', system: 'system1' },
  children: [
    {
      path: 'task-approval',
      component: () => import('@/views/task-scheduling/task-approval.vue'),
      name: 'TaskApproval',
      meta: { title: '任务管理', icon: 'form', system: 'system1', permPrefix: 'workflow:mainProject' }
    },
    {
      path: 'scheduling-template',
      component: () => import('@/views/task-scheduling/scheduling-template.vue'),
      name: 'SchedulingTemplate',
      meta: { title: '任务调度模板管理', icon: 'process-definition', system: 'system1', permPrefix: 'task:template' }
    },
    {
      path: 'resource-template',
      component: () => import('@/views/task-scheduling/resource-template.vue'),
      name: 'ResourceTemplate',
      meta: { title: '资源配置模板管理', icon: 'model', system: 'system1', permPrefix: 'task:resourceTemplate' }
    },
    {
      path: 'task-dispatch',
      component: () => import('@/views/task-scheduling/task-dispatch.vue'),
      name: 'TaskDispatch',
      meta: { title: '任务调度', icon: 'guide', system: 'system1', permPrefix: 'task:dispatch' }
    },
    {
      path: 'resource-config',
      component: () => import('@/views/task-scheduling/resource-config.vue'),
      name: 'ResourceConfig',
      meta: { title: '资源配置', icon: 'tool', system: 'system1', permPrefix: 'task:resourceConfig' }
    },
    {
      path: 'task-export',
      component: () => import('@/views/task-scheduling/task-export.vue'),
      name: 'TaskExport',
      meta: { title: '任务导出', icon: 'download', system: 'system1' }
    }
  ]
};

export default taskSchedulingRoutes;
