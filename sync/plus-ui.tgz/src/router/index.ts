import { createWebHistory, createRouter, RouteRecordRaw } from 'vue-router';
/* Layout */
import Layout from '@/layout/index.vue';
/* 分系统路由 */
import taskSchedulingRoutes from './modules/task-scheduling';
import taskResourceRoutes from './modules/task-resource';
import taskMonitorRoutes from './modules/task-monitor';

/**
 * Note: 路由配置项
 *
 * hidden: true                     // 当设置 true 的时候该路由不会再侧边栏出现 如401，login等页面，或者如一些编辑页面/edit/1
 * alwaysShow: true                 // 当你一个路由下面的 children 声明的路由大于1个时，自动会变成嵌套的模式--如组件页面
 *                                  // 只有一个时，会将那个子路由当做根路由显示在侧边栏--如引导页面
 *                                  // 若你想不管路由下面的 children 声明的个数都显示你的根路由
 *                                  // 你可以设置 alwaysShow: true，这样它就会忽略之前定义的规则，一直显示根路由
 * redirect: noRedirect             // 当设置 noRedirect 的时候该路由在面包屑导航中不可被点击
 * name:'router-name'               // 设定路由的名字，一定要填写不然使用<keep-alive>时会出现各种问题
 * query: '{"id": 1, "name": "ry"}' // 访问路由的默认传递参数
 * roles: ['admin', 'common']       // 访问路由的角色权限
 * permissions: ['a:a:a', 'b:b:b']  // 访问路由的菜单权限
 * meta : {
    noCache: true                   // 如果设置为true，则不会被 <keep-alive> 缓存(默认 false)
    title: 'title'                  // 设置该路由在侧边栏和面包屑中展示的名字
    icon: 'svg-name'                // 设置该路由的图标，对应路径src/assets/icons/svg
    breadcrumb: false               // 如果设置为false，则不会在breadcrumb面包屑中显示
    activeMenu: '/system/user'      // 当路由设置了该属性，则会高亮相对应的侧边栏。
  }
 */

// 公共路由
export const constantRoutes: RouteRecordRaw[] = [
  {
    path: '/redirect',
    component: Layout,
    hidden: true,
    children: [
      {
        path: '/redirect/:path(.*)',
        component: () => import('@/views/redirect/index.vue')
      }
    ]
  },
  {
    path: '/social-callback',
    hidden: true,
    component: () => import('@/layout/components/SocialCallback/index.vue')
  },
  {
    path: '/login',
    component: () => import('@/views/login.vue'),
    hidden: true
  },
  {
    path: '/register',
    component: () => import('@/views/register.vue'),
    hidden: true
  },
  {
    path: '/:pathMatch(.*)*',
    component: () => import('@/views/error/404.vue'),
    hidden: true
  },
  {
    path: '/401',
    component: () => import('@/views/error/401.vue'),
    hidden: true
  },
  {
    path: '',
    component: Layout,
    redirect: '/task-scheduling/task-approval',
    children: [
      {
        path: '/index',
        component: () => import('@/views/index.vue'),
        name: 'Index',
        meta: { title: '首页', icon: 'dashboard', affix: true }
      }
    ]
  },
  {
    path: '/user',
    component: Layout,
    hidden: true,
    redirect: 'noredirect',
    children: [
      {
        path: 'profile',
        component: () => import('@/views/system/user/profile/index.vue'),
        name: 'Profile',
        meta: { title: '个人中心', icon: 'user' }
      }
    ]
  },
  // 任务调度模板 - 流程设计(海豚 DAG 编辑器,整屏、不在侧边栏显示)
  {
    path: '/task-scheduling/flow-design',
    component: () => import('@/views/task-scheduling/flow/flow-design'),
    hidden: true,
    meta: { title: '流程设计' }
  },
  // 运行驾驶舱：右上角驾驶舱按钮直达（/cockpit）
  // 不在侧边栏显示；页面内自行隐藏左侧菜单，所以挂在 Layout 下
  {
    path: '/cockpit',
    component: Layout,
    hidden: true,
    children: [
      {
        path: '',
        name: 'CockpitFullscreen',
        component: () => import('@/views/task-monitor/cockpit.vue'),
        meta: { title: '运行驾驶舱', noCache: true }
      }
    ]
  },
  // 系统管理里的两个「隐藏菜单页」：分配用户 / 分配角色
  //
  // 它们在菜单表里是「隐藏菜单」（component=system/role/authUser、system/user/authRole），
  // 页面跳转用 utils/menuPath 按后缀反查真实前缀。一旦菜单缺失或菜单树层级变动，
  // 反查不到前缀就会拼出裸路径然后 404。这里静态兜底注册一次，保证入口永远可用：
  //   - 菜单存在且路径一致时：静态路由先生效，渲染同一个组件（不影响权限，接口仍按权限校验）
  //   - 菜单缺失/路径不一致时：仍可打开页面，不再 404
  {
    path: '/SafeManage/role-auth/user/:roleId',
    component: Layout,
    hidden: true,
    children: [
      {
        path: '',
        name: 'AuthUser',
        component: () => import('@/views/system/role/authUser.vue'),
        meta: { title: '分配用户', noCache: true }
      }
    ]
  },
  {
    path: '/SafeManage/user-auth/role/:userId',
    component: Layout,
    hidden: true,
    children: [
      {
        path: '',
        name: 'AuthRole',
        component: () => import('@/views/system/user/authRole.vue'),
        meta: { title: '分配角色', noCache: true }
      }
    ]
  },
  // 【临时】拖拽模拟页，验证完删除
  {
    path: '/__debug/dag-drag-sim',
    component: () => import('@/views/__debug/dag-drag-sim.vue'),
    hidden: true,
    meta: { title: '拖拽模拟' }
  },
  // 【临时】地图绘制模拟页，验证完删除
  {
    path: '/__debug/map-draw-sim',
    component: () => import('@/views/__debug/map-draw-sim.vue'),
    hidden: true,
    meta: { title: '地图绘制模拟' }
  }
];

// 动态路由，基于用户权限动态去加载
export const dynamicRoutes: RouteRecordRaw[] = [taskSchedulingRoutes, taskResourceRoutes, taskMonitorRoutes];

/**
 * 创建路由
 */
const router = createRouter({
  history: createWebHistory(import.meta.env.VITE_APP_CONTEXT_PATH),
  routes: constantRoutes,
  // 刷新时，滚动条位置还原
  scrollBehavior(to, from, savedPosition) {
    if (savedPosition) {
      return savedPosition;
    }
    return { top: 0 };
  }
});

export default router;
