import { LanguageEnum } from '@/enums/LanguageEnum';

/**
 * 字典 label 的英文兜底映射（value → 英文）。
 *
 * 背景：字典 label 由后端下发且通常是中文。前端无法单方面决定后端语言，
 * 这里为「若依标准字典」提供一份前端兜底译文：英文环境下命中映射则覆盖 label，
 * 未命中的字典（业务自定义）保留后端原文，待后端提供多语字段后再接入。
 *
 * 格式：{ [dictType]: { [dictValue]: englishLabel } }
 */
export const DICT_LABEL_EN: Record<string, Record<string, string>> = {
  sys_normal_disable: { '0': 'Normal', '1': 'Disabled' },
  sys_common_status: { '0': 'Normal', '1': 'Disabled' },
  sys_yes_no: { Y: 'Yes', N: 'No' },
  sys_show_hide: { '0': 'Show', '1': 'Hide' },
  sys_oper_type: {
    '0': 'Other',
    '1': 'Insert',
    '2': 'Update',
    '3': 'Delete',
    '4': 'Grant',
    '5': 'Export',
    '6': 'Import',
    '7': 'Force Logout',
    '8': 'Generate Code',
    '9': 'Clear Data'
  }
};

/**
 * 按当前语言把字典选项的 label 覆盖为译文（命中映射时）。
 * @param dictType 字典类型
 * @param options  原始选项（label 为后端原文）
 * @param lang     当前语言
 */
export const applyDictI18n = (dictType: string, options: DictDataOption[], lang: LanguageEnum): DictDataOption[] => {
  if (lang !== LanguageEnum.en_US) return options;
  const map = DICT_LABEL_EN[dictType];
  if (!map) return options;
  return options.map((item) => ({ ...item, label: map[item.value] ?? item.label }));
};
