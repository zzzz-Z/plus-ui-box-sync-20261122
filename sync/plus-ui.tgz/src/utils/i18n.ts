// translate router.meta.title, be used in breadcrumb sidebar tagsview
import i18n from '@/lang/index';

/**
 * 路由标题中文原文 → i18n key 的映射。
 *
 * 设计取舍：router.meta.title 保持中文原文作为「稳定标识」，因为权限模块
 * (permission.ts) 会拿它与后端菜单 title 做匹配；改成英文 key 会破坏授权判定。
 * 展示层统一经 translateRouteTitle 翻译：中文环境返回原文，英文环境返回译文。
 */
const ROUTE_TITLE_KEY_MAP: Record<string, string> = {
  首页: 'dashboard',
  项目文档: 'document',
  个人中心: 'profile',
  流程设计: 'processDesign',
  运行驾驶舱: 'cockpit',
  分配用户: 'assignUser',
  分配角色: 'assignRole',
  拖拽模拟: 'dragSim',
  地图绘制模拟: 'mapDrawSim',
  系统管理: 'systemManage',
  数据字典: 'dataDict',
  任务管理调度: 'taskScheduleManage',
  任务管理: 'taskManage',
  任务调度模板管理: 'taskTemplate',
  资源配置模板管理: 'resourceTemplate',
  任务调度: 'taskDispatch',
  资源配置: 'resourceConfig',
  任务导出: 'taskExport',
  任务监控评价: 'taskMonitorEval',
  任务监控: 'taskMonitor',
  任务评价: 'taskEval',
  任务统计: 'taskStatistics',
  任务资源管理: 'taskResourceManage',
  作业岗位管理: 'workPostManage',
  作业单元管理: 'workUnitManage',
  基础设施管理: 'infraManage',
  作业资料管理: 'jobDataManage',
  临时空间管理: 'tempSpaceManage',
  资源使用监控: 'resourceMonitor',
  字典管理: 'dictManage',
  // 数据管理分区：后端菜单 title 由展示层兜底翻译，授权匹配仍用中文原文
  配置运维管理: 'configOpsManage',
  安全管理: 'safeManage',
  角色管理: 'roleManage',
  用户管理: 'userManage',
  权限验证: 'permissionVerify',
  子系统管理: 'oauthManage',
  产品配置管理: 'productConfigManage',
  产品类型管理: 'productTypeManage',
  电子地图底图: 'baseMap',
  字段库管理: 'fieldLibManage',
  数据库配置: 'dbConfig',
  输入数据: 'inputData',
  产品数据: 'productData',
  运维数据: 'opsData',
  结构化数据: 'structuredData',
  非结构化数据: 'unstructuredData',
  半结构化数据: 'semistructuredData',
  日志管理: 'logManage',
  资源监控: 'resourceMonitorMenu',
  故障定位: 'faultLocate',
  查询统计: 'queryStats',
  菜单管理: 'menuManage',
  部门管理: 'deptManage',
  岗位管理: 'postManage',
  文件配置管理: 'ossConfigManage',
  字典数据: 'dictData',
  数据存取: 'dataAccess',
  备份恢复: 'backupRestore',
  运维监控: 'opsMonitor',
  初级产品管理: 'primaryProduct',
  元数据管理: 'metadataManage',
  分类要素初级产品: 'classFeatureProduct',
  分类要素属性产品: 'classAttrProduct',
  地质要素初级产品: 'geoFeatureProduct',
  陆海融合初级产品: 'landSeaProduct',
  协同检核初级产品: 'jointCheckProduct',
  数据提取: 'dataExtract',
  产品成果管理: 'productResultManage',
  分类要素产品成果: 'classFeatureResult',
  分类要素属性产品成果: 'classAttrResult',
  地质要素产品成果: 'geoFeatureResult',
  陆海融合产品成果: 'landSeaResult',
  样本与模型成果: 'sampleModelResult',
  矢量组网产品成果: 'vectorNetResult',
  // 产品管理页内 tab 标题（shared/metadata-manage/index.vue TABS.label）
  元数据浏览: 'tabMetaBrowse',
  元数据查询: 'tabMetaQuery',
  元数据模型管理: 'tabMetaModel',
  元数据抽取: 'tabMetaExtract',
  元数据编辑: 'tabMetaEdit',
  元数据检查: 'tabMetaCheck',
  元数据分析: 'tabMetaAnalysis',
  元数据更新: 'tabMetaUpdate',
  元数据版本管理: 'tabMetaVersion',
  元数据导入导出: 'tabMetaTransfer',
  元数据备份恢复: 'tabMetaBackup',
  元数据安全管理: 'tabMetaSecurity',
  数据浏览: 'tabDataBrowse',
  数据查询: 'tabDataQuery',
  数据入库: 'tabDataInto',
  数据提取: 'tabDataExtract',
  数据更新: 'tabDataUpdate',
  版本管理: 'tabVersion',
  备份恢复: 'tabBackup',
  权限设置: 'tabPermission',
  数据资产报告: 'tabDataReport',
  树: 'paneTree',
  列表: 'paneList',
  地图: 'paneMap'
};

/**
 * 获取国际化路由标题；找不到对应 key 时原样返回。
 * @param title 路由名称（中文原文或已登记 key）
 * @returns {string}
 */
export const translateRouteTitle = (title: string): string => {
  if (!title) return title;
  const key = ROUTE_TITLE_KEY_MAP[title] || title;
  const fullKey = 'route.' + key;
  return i18n.global.te(fullKey) ? i18n.global.t(fullKey) : title;
};
