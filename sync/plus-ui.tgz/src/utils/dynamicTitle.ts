import defaultSettings from '@/settings';
import { useSettingsStore } from '@/store/modules/settings';
import i18n from '@/lang/index';

/**
 * 动态修改标题（系统名走 i18n，切换语言即时生效）
 */
export const useDynamicTitle = () => {
  const settingsStore = useSettingsStore();
  const appTitle = i18n.global.t('app.title');
  if (settingsStore.dynamicTitle) {
    document.title = settingsStore.title + ' - ' + appTitle;
  } else {
    document.title = (defaultSettings.title as string) || appTitle;
  }
};
