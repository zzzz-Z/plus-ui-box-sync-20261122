import { watch } from 'vue';
import { getDicts } from '@/api/system/dict/data';
import { useDictStore } from '@/store/modules/dict';
import { language } from '@/lang/index';
import { applyDictI18n } from '@/utils/dict-i18n';
/**
 * 获取字典数据
 */
export const useDict = (...args: string[]): { [key: string]: DictDataOption[] } => {
  const res = ref<{
    [key: string]: DictDataOption[];
  }>({});

  // 原始选项（保持后端下发的 label），语言切换时据此重算译文
  const rawOptions = new Map<string, DictDataOption[]>();

  args.forEach(async (dictType) => {
    res.value[dictType] = [];
    const dicts = useDictStore().getDict(dictType);
    if (dicts) {
      rawOptions.set(dictType, dicts);
      res.value[dictType] = applyDictI18n(dictType, dicts, language.value);
    } else {
      await getDicts(dictType).then((resp) => {
        const options = resp.data.map(
          (p): DictDataOption => ({ label: p.dictLabel, value: p.dictValue, elTagType: p.listClass, elTagClass: p.cssClass })
        );
        rawOptions.set(dictType, options);
        res.value[dictType] = applyDictI18n(dictType, options, language.value);
        useDictStore().setDict(dictType, options);
      });
    }
  });

  // 语言切换后即时重算已加载字典的 label（写回响应式对象，页面上的 toRefs 会跟随更新）
  watch(language, (lang) => {
    rawOptions.forEach((options, dictType) => {
      res.value[dictType] = applyDictI18n(dictType, options, lang);
    });
  });

  return res.value;
};
