/**
 * 查询区背景图自动挂载
 *
 * 规范：单行查询区用 one_input.png，两行及以上用 two_input.png（见《界面样式改造规范》3.7）。
 *
 * 为什么用 JS 探测行数而不是逐页写死类名：
 *   查询区一行放几个条件由"表单控件在当前宽度下是否换行"决定（响应式），
 *   静态分类在窄屏/宽屏下必然有一端错位；这里按渲染后的真实行数打类，全站自动正确。
 */

/** 同一行允许的顶部误差（px），超过即视为换行 */
const ROW_TOLERANCE = 4;
const CLASS_ONE = 'query-bg-one';
const CLASS_TWO = 'query-bg-two';

/** 统计表单实际渲染出的行数（按表单项的顶部坐标分组；隐藏项不参与） */
function rowCount(form: HTMLElement): number {
  const items = Array.from(form.querySelectorAll<HTMLElement>('.el-form-item'));
  const tops: number[] = [];
  for (const item of items) {
    const rect = item.getBoundingClientRect();
    if (!rect.height) continue;
    const top = Math.round(rect.top);
    if (!tops.some((t) => Math.abs(t - top) <= ROW_TOLERANCE)) tops.push(top);
  }
  return tops.length;
}

/**
 * 目标容器允许比表单本身高出的余量（px）：容纳内边距、查询/重置按钮行等。
 * 只要某个祖先"比表单高出不超过这个余量"，就认为它只是查询条的包裹层。
 */
const MAX_EXTRA_HEIGHT = 90;

/**
 * 背景图的目标元素。
 *
 * 历史上这里写过"找不到 el-card 就挂到 form.parentElement"，结果在查询区不是卡片、
 * 父容器又是页面根 div 的页面里，背景图被 100% 100% 拉伸铺满整页（只能逐页写
 * `.query-bg-one { background-image: none }` 救）；后来又改成"父容器必须 ≤140px"，
 * 又把不少合法查询区（两行查询、带按钮行）误杀了。
 *
 * 现在的判据是"相对表单高度"而不是绝对高度，两种情况都能覆盖：
 *   ① 卡片式查询区：卡片没比表单高太多（说明卡片里基本只有查询条件）→ 用卡片；
 *   ② 非卡片查询区：从表单向上找"刚好包住它"的那一层；
 *   ③ 找不到合适包裹层：直接挂到表单自身（背景按表单尺寸铺开，绝不会铺满整页）。
 */
function targetOf(form: HTMLElement): HTMLElement | null {
  const base = form.getBoundingClientRect().height;
  if (!base) return null;
  const limit = base + MAX_EXTRA_HEIGHT;

  const card = form.closest('.el-card') as HTMLElement | null;
  if (card) {
    // 表单在卡片里，只有两种结果：
    //  ① 卡片本身就是"一条查询条"（没装别的内容）→ 挂到卡片上（卡片有配套的透明底/去边框样式）；
    //  ② 卡片里还装着表格等其它内容（如"任务导出"的 range-card：卡片头 + 查询表单 + 表格）
    //     → 直接不挂。绝不能退到 .el-card__body 上：那会让底图落在卡片内层，
    //     与卡片白底、内边距错位（这是"任务导出"页出现背景图的根因）。
    return card.getBoundingClientRect().height <= limit ? card : null;
  }

  // 非卡片查询区：从表单向上找"刚好包住它"的那一层（不超过表单高 + 余量）
  let best: HTMLElement | null = null;
  let cur: HTMLElement | null = form.parentElement;
  while (cur && cur !== document.body) {
    const h = cur.getBoundingClientRect().height;
    if (h <= 0 || h > limit) break;
    best = cur;
    cur = cur.parentElement;
  }
  return best ?? form;
}

/**
 * 判断是否"查询区"。
 * 页面里还有别的内联表单（例如任务分解页的"配置对象"表单、只有按钮的动作条），
 * 需要把它们排除掉，但判据不能太窄，否则会漏掉真正的查询区：
 *   ① 显式标记：查询表单写 class="search-form"（项目里已有这种写法）→ 直接认定；
 *   ② 文案里带 查询 / 搜索 / 重置 按钮；
 *   ③ 兜底：≥2 个表单项、且不含表格/上传，视为筛选条件组
 *      （例如"产品数据"页的查询区由共享 Table 组件的 #search 槽渲染，里面没有查询按钮）。
 * 三种都要求表单里确实有可输入的控件；弹窗/抽屉里的表单在调用处已排除。
 */
function isQueryForm(form: HTMLElement): boolean {
  const hasInput = !!form.querySelector('input, textarea');
  if (!hasInput) return false;
  if (form.classList.contains('search-form')) return true;
  if (/查询|搜索|重置/.test(form.textContent || '')) return true;
  const items = form.querySelectorAll('.el-form-item');
  return items.length >= 2 && !form.querySelector('.el-table, .el-upload');
}

/**
 * 扫描并给页面查询区打上 one/two 背景类。
 * 幂等：目标类没变化时不碰 DOM，避免 MutationObserver 自激。
 */
export function applyQueryBackground(root: ParentNode | null = document): void {
  const scope: ParentNode = root || document;
  const forms = Array.from(scope.querySelectorAll<HTMLElement>('.el-form'));
  /** 本次判定为合法的背景承载元素，用于清理上一次运行留下的脏类 */
  const validTargets = new Set<HTMLElement>();
  for (const form of forms) {
    if (!form.querySelector('.el-form-item')) continue;
    // 只处理页面级查询区：排除弹窗 / 抽屉 / 消息框里的表单
    if (form.closest('.el-dialog, .el-drawer, .el-message-box')) continue;
    // 排除非查询类的内联表单（动作条 / 配置表单等）
    if (!isQueryForm(form)) continue;
    const rows = rowCount(form);
    if (!rows) continue;
    // 标记查询表单：用于"行高对齐"（表单项默认 10px 下间距会把行撑成 40+10=50px，控件看起来偏上）
    form.classList.toggle('is-query-form-single', rows <= 1);
    form.classList.add('is-query-form');
    const el = targetOf(form);
    if (!el) continue;
    validTargets.add(el);
    const wantOne = rows <= 1;
    const hasOne = el.classList.contains(CLASS_ONE);
    const hasTwo = el.classList.contains(CLASS_TWO);
    if ((wantOne && hasOne) || (!wantOne && hasTwo)) continue;
    el.classList.toggle(CLASS_ONE, wantOne);
    el.classList.toggle(CLASS_TWO, !wantOne);
  }
  // 清理脏类：历史版本可能把背景类挂到过大容器上，这里统一收回，
  // 页面无需再自己写 .query-bg-one { background-image: none }
  for (const el of Array.from(scope.querySelectorAll<HTMLElement>(`.${CLASS_ONE}, .${CLASS_TWO}`))) {
    if (!validTargets.has(el)) el.classList.remove(CLASS_ONE, CLASS_TWO);
  }
}
