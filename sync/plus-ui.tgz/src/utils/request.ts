import axios, { AxiosResponse, InternalAxiosRequestConfig } from 'axios';
import { useUserStore } from '@/store/modules/user';
import { getToken } from '@/utils/auth';
import { tansParams, blobValidate } from '@/utils/ruoyi';
import cache from '@/plugins/cache';
import { HttpStatus } from '@/enums/RespEnum';
import { errorCode } from '@/utils/errorCode';
import { LoadingInstance } from 'element-plus/es/components/loading/src/loading';
import FileSaver from 'file-saver';
import { getLanguage } from '@/lang';
import i18n from '@/lang/index';
import { encryptBase64, encryptWithAes, generateAesKey, decryptWithAes, decryptBase64 } from '@/utils/crypto';
import { encrypt, decrypt } from '@/utils/jsencrypt';
import router from '@/router';

const encryptHeader = 'encrypt-key';
let downloadLoadingInstance: LoadingInstance;
// 是否显示重新登录
export const isRelogin = { show: false };
/**
 * 尽力而为请求的标记头（小写：axios 会把请求头统一转成小写存储）。
 *
 * 用途：让调用方能声明「这个请求失败我自己降级，别弹全局会话过期框」。
 * 典型场景是装饰性 / 可缺失的数据（图例类别树、可选配置），
 * 它们失败不该把带全屏遮罩的 ElMessageBox 弹出来锁死整个页面。
 */
export const BEST_EFFORT_HEADER = 'x-best-effort';
export const globalHeaders = () => {
  return {
    Authorization: 'Bearer ' + getToken(),
    clientid: import.meta.env.VITE_APP_CLIENT_ID
  };
};

axios.defaults.headers['Content-Type'] = 'application/json;charset=utf-8';
axios.defaults.headers['clientid'] = import.meta.env.VITE_APP_CLIENT_ID;

/**
 * JSON 解析时保留超长整型精度。
 * 后端 Long 型 id（雪花算法）超过 Number.MAX_SAFE_INTEGER，
 * 直接 JSON.parse 会被四舍五入，例如 2097501837841846274 → 2097501837841846300。
 * 该函数把 JSON 中长度 ≥16 位的整数字面量转成字符串，其余内容原样解析。
 */
export function parseJsonKeepLongIds(raw: any) {
  if (typeof raw !== 'string' || !raw) return raw;
  const head = raw.trimStart()[0];
  // 非 JSON 报文（如参数加密返回的密文、纯文本）不做处理
  if (head !== '{' && head !== '[') return raw;

  let out = '';
  let i = 0;
  const len = raw.length;
  while (i < len) {
    const ch = raw[i];
    // 字符串字面量整体拷贝，避免改动字符串内部的内容
    if (ch === '"') {
      let j = i + 1;
      while (j < len) {
        if (raw[j] === '\\') {
          j += 2;
          continue;
        }
        if (raw[j] === '"') break;
        j++;
      }
      out += raw.slice(i, Math.min(j + 1, len));
      i = j + 1;
      continue;
    }
    // 数字字面量：≥16 位整数加引号，保留原始精度
    if ((ch >= '0' && ch <= '9') || ch === '-') {
      let j = i + 1;
      while (j < len && /[0-9eE+\-.]/.test(raw[j])) j++;
      const token = raw.slice(i, j);
      out += /^\d{16,}$/.test(token) ? '"' + token + '"' : token;
      i = j;
      continue;
    }
    out += ch;
    i++;
  }
  try {
    return JSON.parse(out);
  } catch {
    try {
      return JSON.parse(raw);
    } catch {
      return raw;
    }
  }
}

// 创建 axios 实例
const service = axios.create({
  baseURL: import.meta.env.VITE_APP_BASE_API,
  timeout: 50000,
  transitional: {
    // 超时错误更明确
    clarifyTimeoutError: true
  }
});

// 请求拦截器
service.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    // 对应国际化资源文件后缀
    config.headers['Content-Language'] = getLanguage();

    const isToken = config.headers?.isToken === false;
    // 是否需要防止数据重复提交
    const isRepeatSubmit = config.headers?.repeatSubmit === false;
    // 是否需要加密
    const isEncrypt = config.headers?.isEncrypt === 'true';

    if (getToken() && !isToken) {
      config.headers['Authorization'] = 'Bearer ' + getToken(); // 让每个请求携带自定义token 请根据实际情况自行修改
    }
    // get请求映射params参数
    if (config.method === 'get' && config.params) {
      let url = config.url + '?' + tansParams(config.params);
      url = url.slice(0, -1);
      config.params = {};
      config.url = url;
    }

    if (!isRepeatSubmit && (config.method === 'post' || config.method === 'put')) {
      const requestObj = {
        url: config.url,
        data: typeof config.data === 'object' ? JSON.stringify(config.data) : config.data,
        time: new Date().getTime()
      };
      const sessionObj = cache.session.getJSON('sessionObj');
      if (sessionObj === undefined || sessionObj === null || sessionObj === '') {
        cache.session.setJSON('sessionObj', requestObj);
      } else {
        const s_url = sessionObj.url; // 请求地址
        const s_data = sessionObj.data; // 请求数据
        const s_time = sessionObj.time; // 请求时间
        const interval = 500; // 间隔时间(ms)，小于此时间视为重复提交
        if (s_data === requestObj.data && requestObj.time - s_time < interval && s_url === requestObj.url) {
          const message = i18n.global.t('common.duplicateSubmit');
          console.warn(`[${s_url}]: ` + message);
          return Promise.reject(new Error(message));
        } else {
          cache.session.setJSON('sessionObj', requestObj);
        }
      }
    }
    if (import.meta.env.VITE_APP_ENCRYPT === 'true') {
      // 当开启参数加密
      if (isEncrypt && (config.method === 'post' || config.method === 'put')) {
        // 生成一个 AES 密钥
        const aesKey = generateAesKey();
        config.headers[encryptHeader] = encrypt(encryptBase64(aesKey));
        config.data = typeof config.data === 'object' ? encryptWithAes(JSON.stringify(config.data), aesKey) : encryptWithAes(config.data, aesKey);
      }
    }
    // FormData数据去请求头Content-Type
    if (config.data instanceof FormData) {
      delete config.headers['Content-Type'];
    }
    return config;
  },
  (error: any) => {
    return Promise.reject(error);
  }
);

// 响应拦截器
service.interceptors.response.use(
  (res: AxiosResponse) => {
    if (import.meta.env.VITE_APP_ENCRYPT === 'true') {
      // 加密后的 AES 秘钥
      const keyStr = res.headers[encryptHeader];
      // 加密
      if (keyStr != null && keyStr != '') {
        const data = res.data;
        // 请求体 AES 解密
        const base64Str = decrypt(keyStr);
        // base64 解码 得到请求头的 AES 秘钥
        const aesKey = decryptBase64(base64Str.toString());
        // aesKey 解码 data
        const decryptData = decryptWithAes(data, aesKey);
        // 将结果 (得到的是 JSON 字符串) 转为 JSON
        res.data = JSON.parse(decryptData);
      }
    }
    // 未设置状态码则默认成功状态
    const code = res.data.code || HttpStatus.SUCCESS;
    // 获取错误信息
    const msg = errorCode[code] || res.data.msg || errorCode['default'];
    // 二进制数据则直接返回
    if (res.request.responseType === 'blob' || res.request.responseType === 'arraybuffer') {
      return res.data;
    }
    if (code === 401) {
      // WHY 尽力而为的请求要能逃生：带 x-best-effort 的请求，调用方本就自行 catch 降级
      // （如图例的类别树「拉取失败时退回展示全部，不阻塞页面」）。但 ElMessageBox 带全屏
      // 遮罩，会把整个页面锁死——任何点击都被它吞掉，与调用方的降级意图正相反。
      // 真正的会话失效仍由必需请求照常弹框，这里只是不让装饰性请求有锁死页面的能力。
      const headers = res.config?.headers ?? {};
      const bestEffort = headers[BEST_EFFORT_HEADER] != null;
      // prettier-ignore
      if (!bestEffort && !isRelogin.show) {
        isRelogin.show = true;
        ElMessageBox.confirm(i18n.global.t('common.sessionExpired'), i18n.global.t('common.systemTip'), {
          confirmButtonText: i18n.global.t('common.relogin'),
          cancelButtonText: i18n.global.t('common.cancel'),
          type: 'warning'
        }).then(() => {
          isRelogin.show = false;
          useUserStore().logout().then(() => {
            router.replace({
              path: '/login',
              query: {
                redirect: encodeURIComponent(router.currentRoute.value.fullPath || '/')
              }
            })
          });
        }).catch(() => {
          isRelogin.show = false;
        });
      }
      return Promise.reject(i18n.global.t('common.invalidSession'));
    } else if (code === HttpStatus.SERVER_ERROR) {
      ElMessage({ message: msg, type: 'error' });
      return Promise.reject(new Error(msg));
    } else if (code === HttpStatus.WARN) {
      ElMessage({ message: msg, type: 'warning' });
      return Promise.reject(new Error(msg));
    } else if (code !== HttpStatus.SUCCESS) {
      ElNotification.error({ title: msg });
      return Promise.reject('error');
    } else {
      return Promise.resolve(res.data);
    }
  },
  (error: any) => {
    // 尽力而为请求失败时调用方会自行降级（如选资源加载元数据表：404=无表，显示空态），
    // 不该再弹全局错误 toast。与上面 401 分支的 x-best-effort 逃生口径保持一致：
    // 头只在请求级声明，不影响其他请求；这里仍照常 reject，由调用方 catch 决定降级策略。
    const headers = error?.config?.headers ?? {};
    const bestEffort = headers[BEST_EFFORT_HEADER] != null;
    // 4xx/5xx 时后端把业务原因放在 body.message；优先用它，避免一律显示「系统接口409异常」
    // （例如入库 start/pause 的 409 会明确说明当前状态不允许该操作）
    const bodyMessage = error?.response?.data?.message || error?.response?.data?.msg;
    let { message } = error;
    if (bodyMessage) {
      message = bodyMessage;
    } else if (message == 'Network Error') {
      message = i18n.global.t('common.networkError');
    } else if (message.includes('timeout')) {
      message = i18n.global.t('common.requestTimeout');
    } else if (message.includes('Request failed with status code')) {
      message = i18n.global.t('common.requestError', { code: message.substr(message.length - 3) });
    }
    if (!bestEffort) {
      ElMessage({ message: message, type: 'error', duration: 5 * 1000 });
    }
    return Promise.reject(error);
  }
);
// 通用下载方法
export function download(url: string, params: any, fileName: string) {
  downloadLoadingInstance = ElLoading.service({ text: i18n.global.t('common.downloadLoading'), background: 'rgba(0, 0, 0, 0.7)' });
  // prettier-ignore
  return service.post(url, params, {
      transformRequest: [
        (params: any) => {
          return tansParams(params);
        }
      ],
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      responseType: 'blob'
    }).then(async (resp: any) => {
      const isLogin = blobValidate(resp);
      if (isLogin) {
        const blob = new Blob([resp]);
        FileSaver.saveAs(blob, fileName);
      } else {
        const blob = new Blob([resp]);
        const resText = await blob.text();
        const rspObj = JSON.parse(resText);
        const errMsg = errorCode[rspObj.code] || rspObj.msg || errorCode['default'];
        ElMessage.error(errMsg);
      }
      downloadLoadingInstance.close();
    }).catch((r: any) => {
      console.error(r);
      ElMessage.error(i18n.global.t('common.downloadError'));
      downloadLoadingInstance.close();
    });
}
// 导出 axios 实例
export default service;
