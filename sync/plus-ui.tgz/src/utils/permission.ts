import { useUserStore } from '@/store/modules/user';

/** 超级管理员权限通配符（后端 Sa-Token 的同款全量通配） */
export const ALL_PERMISSION = '*:*:*';

/** 转义正则元字符，供权限通配匹配使用 */
const escapeRegExp = (value: string): string => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

/**
 * 权限点匹配（与后端 Sa-Token 的通配语义保持一致）
 *
 * WHY：页面级权限模型下，后端会给「页面」下发的同模块通配项（如 `task:template:*`），
 * 前端如果只做全等比较，页面内的审批 / 编辑按钮会被误判成「没有权限」并置灰。
 *
 * @param granted  用户拥有的权限点，可以含 `*` 通配
 * @param required 需要的权限点
 * @returns 是否命中
 */
export const matchPermission = (granted: string, required: string): boolean => {
  if (!granted || !required) return false;
  if (granted === ALL_PERMISSION || granted === '*' || granted === required) return true;
  if (!granted.includes('*')) return false;
  const pattern = granted.split('*').map(escapeRegExp).join('.*');
  return new RegExp(`^${pattern}$`).test(required);
};

/**
 * 当前用户是否拥有指定权限点（支持通配）
 *
 * @param required 需要的权限点
 * @returns 是否拥有
 */
export const hasPermission = (required: string): boolean => {
  if (!required) return false;
  return useUserStore().permissions.some((granted: string) => matchPermission(granted, required));
};

/**
 * 当前用户是否拥有某个「页面模块」下的任意权限点
 *
 * 例：prefix = `task:template`，拥有 `task:template:list` 或 `task:template:*` 都算通过。
 * 页面级权限模型里，这就是「这个界面的权限分给当前用户了吗」的判定口径。
 *
 * @param prefix 模块前缀，如 `task:template`
 * @returns 是否拥有该模块下任意权限点
 */
export const hasModulePermission = (prefix: string): boolean => {
  if (!prefix) return false;
  const head = `${prefix}:`;
  return useUserStore().permissions.some((granted: string) => granted === ALL_PERMISSION || granted.startsWith(head));
};

/**
 * 字符权限校验
 * @param {Array} value 校验值
 * @returns {Boolean}
 */
export const checkPermi = (value: any) => {
  if (value && value instanceof Array && value.length > 0) {
    return value.some((permission: string) => hasPermission(permission));
  }
  console.error(`need roles! Like checkPermi="['system:user:add','system:user:edit']"`);
  return false;
};

/**
 * 角色权限校验
 * @param {Array} value 校验值
 * @returns {Boolean}
 */
export const checkRole = (value: any): boolean => {
  if (value && value instanceof Array && value.length > 0) {
    const roles = useUserStore().roles;
    const permissionRoles = value;
    const super_admin = 'admin';

    const hasRole = roles.some((role) => {
      return super_admin === role || permissionRoles.includes(role);
    });

    if (!hasRole) {
      return false;
    }
    return true;
  } else {
    console.error(`need roles! Like checkRole="['admin','editor']"`);
    return false;
  }
};
