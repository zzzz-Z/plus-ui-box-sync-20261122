/**
 * localStorage JSON 读写工具
 *
 * 项目中多个 state.ts 手抄过同样的 try/JSON.parse/fallback 样板；
 * 统一到此处，避免各处 fallback 行为漂移。
 */

/** 读取 JSON；不存在 / 解析失败时返回 fallback */
export function loadJSON<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return (JSON.parse(raw) as T) ?? fallback;
  } catch {
    return fallback;
  }
}

/** 写入 JSON；值序列化失败时静默（localStorage 已满等） */
export function saveJSON(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* quota exceeded / 序列化失败，静默 */
  }
}
