/**
 * 将带 parentId 的扁平列表转换成树形结构。
 *
 * 节点 path 会在构建过程中继承父级路径：根节点使用自身 path，
 * 子节点使用“父级完整 path / 当前 path”。创建新节点而不是直接修改 item，
 * 可以避免同一份接口数据重复转换时发生路径累加。
 */
export function arrayToTree(list: any[], id = '0', parentPath = ''): any[] {
  // 每层都按 orderNum 排序，保证菜单和路由的显示顺序与后端配置一致。
  return list
    .sort((a, b) => a.orderNum - b.orderNum)
    .reduce((acc, item) => {
      if (item.parentId === id) {
        // 根节点不额外添加斜杠；后续递归会以当前节点的完整 path 作为父路径。
        const node = {
          ...item,
          path: `${parentPath}${parentPath ? '/' : ''}${item.path}`
        }
        // 递归查找当前节点的直接子节点，并把当前完整路径传给下一层。
        const children = arrayToTree(list, item.id, node.path)
        if (children.length) {
          node.children = children
        }
        acc.push(node)
      }
      return acc
    }, [])
}
