/**
 * 移除对象中值为 undefined 的属性
 *
 * @param obj {Params} - 输入的对象，其类型为 Params
 * @returns {Params} - 返回一个新的对象，其中不包含值为 undefined 的属性
 */
export function removeUndefinedProps(obj: Params): Params {
  // 将对象转换为键值对数组，过滤掉值为 undefined 的键值对，再将其转换回对象
  return Object.fromEntries(
    Object.entries(obj).filter(([, value]) => value !== undefined),
  )
}
