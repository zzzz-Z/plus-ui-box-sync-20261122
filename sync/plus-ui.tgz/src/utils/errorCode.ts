import i18n from '@/lang/index';

/**
 * 错误码文案：以 i18n error.* 为唯一文案源。
 * 用 Proxy 保持原来的 `errorCode[code]` / `errorCode['default']` 调用形态不变，
 * 调用方无需感知多语化，且切换语言后立即返回新译文。
 */
export const errorCode: any = new Proxy(
  {},
  {
    get: (_target, prop: string) => {
      const key = 'error.' + prop;
      return i18n.global.te(key) ? i18n.global.t(key) : undefined;
    }
  }
);
export default errorCode;
