/**
 * 下拉候选「按 total 拉全量」工具
 *
 * WHY：下拉候选过去写死 pageSize（200 / 500 / 1000），一旦库里数据超过这个数就会被静默截断，
 * 用户不输入关键字时根本看不到后面的数据。这里改成先取第 1 页拿 total，再按页补齐，
 * 200 只是「每页大小」，不再是「最多只能拿 200 条」。
 *
 * 兼容两种分页响应：
 *  - 顶层 { rows, total }（如 work-posts / work-units）
 *  - 嵌套 { data: { rows, total } }（如 workdata/list）
 * 若接口没给 total，则退化为「本页不满一页即到底」的判断。
 */

export interface OptionPage<T> {
  /** 本页数据 */
  rows: T[];
  /** 总条数（接口未返回时可不传） */
  total?: number;
}

/**
 * 拉取全量候选
 *
 * @param fetchPage 取一页的方法：(pageNo, pageSize) => 原始响应
 * @param pick      从原始响应里取 { rows, total }
 * @param pageSize  每页大小（默认 200，仅影响请求次数，不影响完整性）
 * @param maxPages  安全阀：最多拉多少页（默认 50 页 ≈ 1 万条），防止异常 total 打爆接口
 * @returns 全量数据
 */
export async function fetchAllOptions<T>(
  fetchPage: (pageNo: number, pageSize: number) => Promise<any>,
  pick: (res: any) => OptionPage<T>,
  pageSize = 200,
  maxPages = 50
): Promise<T[]> {
  const first = pick(await fetchPage(1, pageSize));
  const rows = [...first.rows];
  const total = Number(first.total) || 0;
  // 接口没给 total，且第一页就没装满 → 已经到底，不用再请求
  if (!total && first.rows.length < pageSize) {
    return rows;
  }
  const pages = total > 0 ? Math.min(Math.ceil(total / pageSize), maxPages) : maxPages;
  for (let pageNo = 2; pageNo <= pages; pageNo++) {
    let next: OptionPage<T>;
    try {
      next = pick(await fetchPage(pageNo, pageSize));
    } catch {
      // 翻页失败就保留已拿到的数据，不要因为一页失败把整个下拉清空
      break;
    }
    if (!next.rows.length) {
      break;
    }
    rows.push(...next.rows);
    if (!total && next.rows.length < pageSize) {
      break;
    }
  }
  return rows;
}
