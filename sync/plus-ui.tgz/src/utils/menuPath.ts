import router from '@/router';

/**
 * 后端菜单的地址会随菜单树层级/命名变化（例如「安全管理」从根级挪到
 * 「配置运维管理」下面后，/SafeManage/user 变成 /configOps/SafeManage/user）。
 *
 * 页面里跳转隐藏菜单（分配用户、分配角色、文件配置等）时不要写死完整路径，
 * 统一用本方法按「页面后缀」去已注册路由里反查真实前缀，菜单层级再调整也不会失效。
 *
 * @param tail   页面后缀，如 '/SafeManage/user'，可带参数占位符 '/SafeManage/role-auth/user/:roleId'
 * @param params 参数占位符对应的值，如 { roleId: 3 }
 */
export const menuPath = (tail: string, params?: Record<string, string | number>): string => {
  const suffix = tail.startsWith('/') ? tail : `/${tail}`;
  // 取最长的匹配前缀，避免同后缀不同层级时选错
  const prefix = router
    .getRoutes()
    .map((r) => r.path)
    .filter((p) => p !== suffix && p.endsWith(suffix))
    .map((p) => p.slice(0, p.length - suffix.length))
    .sort((a, b) => b.length - a.length)[0];

  let path = `${prefix || ''}${suffix}`;
  if (params) {
    Object.keys(params).forEach((key) => {
      path = path.replace(`:${key}`, String(params[key]));
    });
  }
  return path;
};
