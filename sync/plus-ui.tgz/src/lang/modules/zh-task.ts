// 任务调度域业务文案（逐批迁移中：新增 key 请同步 en 文件）
export default {
  task: {
    title: '任务',
    status: {
      running: '运行中',
      success: '成功',
      failed: '失败',
      pending: '待执行'
    }
  }
};
