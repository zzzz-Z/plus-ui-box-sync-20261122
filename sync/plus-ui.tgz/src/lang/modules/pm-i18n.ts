import { computed, unref, type MaybeRef } from 'vue';
import { language } from '@/lang/index';
import { LanguageEnum } from '@/enums/LanguageEnum';
import { PM_EXACT, PM_WORDS } from './pm-en';
import { PM_EXACT_EXTRA, PM_WORDS_EXTRA } from './pm-en-extra';

// 合并补充整句词典（覆盖数据管理全量页面）
const EXACT_ALL: Record<string, string> = { ...PM_EXACT, ...PM_EXACT_EXTRA };
const WORDS_ALL: Record<string, string> = { ...PM_WORDS, ...PM_WORDS_EXTRA };

// 归一化整句索引：字典 key 与输入都按空白归一化，命中模板里的多行/缩进文案
const normKey = (s: string) => s.replace(/\s+/g, ' ').trim();
const NORM_EXACT: Record<string, string> = {};
for (const [k, v] of Object.entries(EXACT_ALL)) {
  const nk = normKey(k);
  if (nk && !NORM_EXACT[nk]) NORM_EXACT[nk] = v;
}

// 长词优先，避免子串互吃（如「数据」先于「数据管理」被替换）
// 词级替换只保留长度 >= 2 的词条：单字映射会误伤（如「页面」吃到「页Polygon」、「不是」吃到「不Yes」、「中」吃到「Medium」）。
const WORD_ENTRIES = Object.entries(WORDS_ALL)
  .filter(([zh]) => zh.length >= 2)
  .sort((a, b) => b[0].length - a[0].length);

function translate(text: string): string {
  if (!/[\u4e00-\u9fa5]/.test(text)) return text;
  if (EXACT_ALL[text]) return EXACT_ALL[text];
  const nk = normKey(text);
  if (NORM_EXACT[nk]) return NORM_EXACT[nk];
  let out = text;
  for (const [zh, en] of WORD_ENTRIES) out = out.split(zh).join(en);
  // 仍残留中文说明字典覆盖不足，回退原文，避免半中半英
  return /[\u4e00-\u9fa5]/.test(out) ? text : out;
}

/**
 * 展示层翻译：中文态恒等返回原文（零回归）；英文态按整句/词级字典翻译。
 * 只用于展示文案，禁止用于逻辑比较值、后端 state 值、字典 key。
 */
export function pt(value: MaybeRef<string | number | null | undefined>): string {
  const raw = unref(value);
  if (raw == null) return '';
  const text = String(raw);
  return unref(language) === LanguageEnum.en_US ? translate(text) : text;
}

/** 与 pt 同语义的 computed 便捷包装。 */
export function usePt(value: MaybeRef<string | number | null | undefined>) {
  return computed(() => pt(value));
}