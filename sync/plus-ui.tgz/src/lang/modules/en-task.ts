// Task domain business messages
export default {
  task: {
    title: 'Task',
    status: {
      running: 'Running',
      success: 'Success',
      failed: 'Failed',
      pending: 'Pending'
    }
  }
};
