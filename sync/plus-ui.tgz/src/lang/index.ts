// 自定义国际化配置
import { watch } from 'vue';
import { createI18n } from 'vue-i18n';
import { useStorage } from '@vueuse/core';

import { LanguageEnum } from '@/enums/LanguageEnum';
import zh_CN from '@/lang/zh_CN';
import en_US from '@/lang/en_US';
import zhTask from '@/lang/modules/zh-task';
import enTask from '@/lang/modules/en-task';

/**
 * 当前语言的唯一真源。
 * 所有语言切换只写这个 ref；i18n.locale 与 Element Plus locale 均由它派生。
 */
export const language = useStorage<LanguageEnum>('language', LanguageEnum.zh_CN);

/**
 * 获取当前语言
 * @returns zh_CN | en_US
 */
export const getLanguage = (): LanguageEnum => language.value;

const i18n = createI18n({
  globalInjection: true,
  allowComposition: true,
  legacy: false,
  locale: language.value,
  messages: {
    zh_CN: { ...zh_CN, ...zhTask },
    en_US: { ...en_US, ...enTask }
  }
});

// i18n.locale 从唯一真源派生；语言切换需要即时反馈，故用 sync flush
watch(
  language,
  (val) => {
    i18n.global.locale.value = val;
  },
  { flush: 'sync' }
);

export default i18n;

export type LanguageType = typeof zh_CN;
