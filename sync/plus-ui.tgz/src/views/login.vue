<template>
  <div class="login-container">
    <!-- 科技感背景层 -->
    <div class="bg-layer bg-gradient"></div>
    <div class="bg-layer bg-grid"></div>
    <div class="bg-layer bg-scan"></div>

    <!-- 顶部：左侧 logo + 系统名，右侧语言切换 -->
    <header class="login-header">
      <div class="logo-wrap">
        <img :src="logoImg" alt="logo" class="logo-img" />
        <span class="system-name">{{ homeTitle }}</span>
      </div>
      <lang-select class="login-lang" />
    </header>

    <!-- 主体：左侧业务闭环插图 + 右侧登录表单 -->
    <main class="login-main">
      <!-- 左侧：业务闭环插图 -->
      <section class="left-panel">
        <img :src="loginLeftImg" alt="业务闭环" class="pipeline-img" />
      </section>

      <!-- 右侧：登录表单 -->
      <section class="right-panel">
        <div class="login-form-wrapper">
          <el-form ref="loginRef" :model="loginForm" :rules="loginRules" class="login-form">
            <div class="title-box">
              <h3 class="title">{{ t('login.title') }}</h3>
            </div>
            <el-form-item v-if="tenantEnabled" prop="tenantId">
              <el-select v-model="loginForm.tenantId" filterable :placeholder="proxy.$t('login.selectPlaceholder')" style="width: 100%">
                <el-option v-for="item in tenantList" :key="item.tenantId" :label="item.companyName" :value="item.tenantId"></el-option>
                <template #prefix><svg-icon icon-class="company" class="el-input__icon input-icon" /></template>
              </el-select>
            </el-form-item>
            <el-form-item prop="username">
              <el-input v-model="loginForm.username" type="text" size="large" auto-complete="off" :placeholder="proxy.$t('login.username')">
                <template #prefix><svg-icon icon-class="user" class="el-input__icon input-icon" /></template>
              </el-input>
            </el-form-item>
            <el-form-item prop="password">
              <el-input
                v-model="loginForm.password"
                type="password"
                size="large"
                auto-complete="off"
                :placeholder="proxy.$t('login.password')"
                @keyup.enter="handleLogin"
              >
                <template #prefix><svg-icon icon-class="password" class="el-input__icon input-icon" /></template>
              </el-input>
            </el-form-item>
            <el-form-item v-if="captchaEnabled" prop="code">
              <el-input
                v-model="loginForm.code"
                size="large"
                auto-complete="off"
                :placeholder="proxy.$t('login.code')"
                style="width: 63%"
                @keyup.enter="handleLogin"
              >
                <template #prefix><svg-icon icon-class="validCode" class="el-input__icon input-icon" /></template>
              </el-input>
              <div class="login-code">
                <img :src="codeUrl" class="login-code-img" @click="getCode" />
              </div>
            </el-form-item>
            <el-checkbox v-model="loginForm.rememberMe" style="margin: 0 0 25px 0">{{ proxy.$t('login.rememberPassword') }}</el-checkbox>
            <el-form-item style="width: 100%">
              <el-button :loading="loading" size="large" type="primary" style="width: 100%" @click.prevent="handleLogin">
                <span v-if="!loading">{{ proxy.$t('login.login') }}</span>
                <span v-else>{{ proxy.$t('login.logging') }}</span>
              </el-button>
              <div v-if="register" style="float: right">
                <router-link class="link-type" :to="'/register'">{{ proxy.$t('login.switchRegisterPage') }}</router-link>
              </div>
            </el-form-item>
          </el-form>
        </div>
      </section>
    </main>

    <!-- 底部版权 -->
    <footer class="login-footer">
      <span>Copyright © 2026 {{ unitName }} All Rights Reserved.</span>
    </footer>
  </div>
</template>

<script setup lang="ts">
import { getCodeImg, getTenantList } from '@/api/login';
import { authRouterUrl } from '@/api/system/social/auth';
import { useUserStore } from '@/store/modules/user';
import { LoginData, TenantVO } from '@/api/types';
import { to } from 'await-to-js';
import { HttpStatus } from '@/enums/RespEnum';
import { useI18n } from 'vue-i18n';
import logoImg from '@/assets/logo/logo.png';
import loginLeftImg from '@/assets/images/login_left.png';

const { proxy } = getCurrentInstance() as ComponentInternalInstance;

/** 顶部系统名（与「管理系统」登录页保持同一个变量） */
const homeTitle = computed(() => t('app.homeTitle'));
/** 页脚单位名 */
const unitName = computed(() => t('app.unitName'));

const userStore = useUserStore();
const router = useRouter();
const { t } = useI18n();

const loginForm = ref<LoginData>({
  tenantId: '000000',
  username: 'admin',
  password: 'admin123',
  rememberMe: false,
  code: '',
  uuid: ''
} as LoginData);

const loginRules: ElFormRules = {
  tenantId: [{ required: true, trigger: 'blur', message: t('login.rule.tenantId.required') }],
  username: [{ required: true, trigger: 'blur', message: t('login.rule.username.required') }],
  password: [{ required: true, trigger: 'blur', message: t('login.rule.password.required') }],
  code: [{ required: true, trigger: 'change', message: t('login.rule.code.required') }]
};

const codeUrl = ref('');
const loading = ref(false);
// 验证码开关
const captchaEnabled = ref(true);
// 租户开关
const tenantEnabled = ref(false);

// 注册开关
const register = ref(false);
const redirect = ref('/');
const loginRef = ref<ElFormInstance>();
// 租户列表
const tenantList = ref<TenantVO[]>([]);

watch(
  () => router.currentRoute.value,
  (newRoute: any) => {
    redirect.value = newRoute.query && newRoute.query.redirect && decodeURIComponent(newRoute.query.redirect);
  },
  { immediate: true }
);

const handleLogin = () => {
  loginRef.value?.validate(async (valid: boolean, fields: any) => {
    if (valid) {
      loading.value = true;
      // 勾选了需要记住密码设置在 localStorage 中设置记住用户名和密码
      if (loginForm.value.rememberMe) {
        localStorage.setItem('tenantId', String(loginForm.value.tenantId));
        localStorage.setItem('username', String(loginForm.value.username));
        localStorage.setItem('password', String(loginForm.value.password));
        localStorage.setItem('rememberMe', String(loginForm.value.rememberMe));
      } else {
        // 否则移除
        localStorage.removeItem('tenantId');
        localStorage.removeItem('username');
        localStorage.removeItem('password');
        localStorage.removeItem('rememberMe');
      }
      // 调用action的登录方法
      const [err] = await to(userStore.login(loginForm.value));
      if (!err) {
        const redirectUrl = redirect.value || '/';
        await router.push(redirectUrl);
        loading.value = false;
      } else {
        loading.value = false;
        // 重新获取验证码
        if (captchaEnabled.value) {
          await getCode();
        }
      }
    } else {
      console.log('error submit!', fields);
    }
  });
};

/**
 * 获取验证码
 */
const getCode = async () => {
  const res = await getCodeImg();
  const { data } = res;
  captchaEnabled.value = data.captchaEnabled === undefined ? true : data.captchaEnabled;
  if (captchaEnabled.value) {
    // 刷新验证码时清空输入框
    loginForm.value.code = '';
    codeUrl.value = 'data:image/gif;base64,' + data.img;
    loginForm.value.uuid = data.uuid;
  }
};

const getLoginData = () => {
  const tenantId = localStorage.getItem('tenantId');
  const username = localStorage.getItem('username');
  const password = localStorage.getItem('password');
  const rememberMe = localStorage.getItem('rememberMe');
  loginForm.value = {
    tenantId: tenantId === null ? String(loginForm.value.tenantId) : tenantId,
    username: username === null ? String(loginForm.value.username) : username,
    password: password === null ? String(loginForm.value.password) : String(password),
    rememberMe: rememberMe === null ? false : Boolean(rememberMe)
  } as LoginData;
};

/**
 * 获取租户列表
 */
const initTenantList = async () => {
  const { data } = await getTenantList(false);
  tenantEnabled.value = data.tenantEnabled === undefined ? true : data.tenantEnabled;
  if (tenantEnabled.value) {
    tenantList.value = data.voList;
    if (tenantList.value != null && tenantList.value.length !== 0) {
      loginForm.value.tenantId = tenantList.value[0].tenantId;
    }
  }
};

/**
 * 第三方登录
 * @param type
 */
const doSocialLogin = (type: string) => {
  authRouterUrl(type, loginForm.value.tenantId).then((res: any) => {
    if (res.code === HttpStatus.SUCCESS) {
      // 获取授权地址跳转
      window.location.href = res.data;
    } else {
      ElMessage.error(res.msg);
    }
  });
};

onMounted(() => {
  getCode();
  initTenantList();
  getLoginData();
});
</script>

<style lang="scss" scoped>
@use '@/assets/styles/variables.module.scss' as *;

.login-container {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  position: relative;
  overflow: hidden;
  background: #0a0e1a;
}

/* ---- 背景层 ---- */
.bg-layer {
  position: absolute;
  inset: 0;
  pointer-events: none;
}

.bg-gradient {
  background:
    radial-gradient(ellipse at 25% 35%, rgba(37, 141, 245, 0.18) 0%, transparent 50%),
    radial-gradient(ellipse at 75% 65%, rgba(34, 211, 238, 0.12) 0%, transparent 50%), linear-gradient(135deg, #0a0e1a 0%, #0d1b3a 40%, #0a1628 100%);
  z-index: 0;
}

.bg-grid {
  background-image:
    linear-gradient(rgba(90, 200, 255, 0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(90, 200, 255, 0.06) 1px, transparent 1px);
  background-size: 48px 48px;
  mask-image: radial-gradient(ellipse at 50% 50%, #000 20%, transparent 80%);
  z-index: 0;
}

.bg-scan {
  overflow: hidden;
  z-index: 0;

  &::after {
    content: '';
    position: absolute;
    inset: 0;
    width: 30%;
    background: linear-gradient(90deg, transparent, rgba(103, 232, 249, 0.06), transparent);
    transform: skewX(-14deg);
    animation: scanMove 10s linear infinite;
  }
}

@keyframes scanMove {
  0% {
    left: -30%;
  }
  100% {
    left: 110%;
  }
}

/* ---- 顶部 logo + 系统名 ---- */
.login-header {
  position: relative;
  z-index: 2;
  height: 90px;
  display: flex;
  align-items: center;
  padding: 0 50px;

  .logo-wrap {
    display: flex;
    align-items: center;

    .logo-img {
      width: 58px;
      height: 58px;
      margin-left: 10px;
    }

    .system-name {
      margin-left: 15px;
      font-family: 'PangmenZhengdao';
      font-size: 46px;
      letter-spacing: 6px;
      color: #eaf7ff;
      text-shadow:
        0 0 18px rgba(34, 211, 238, 0.65),
        0 2px 4px rgba(0, 20, 40, 0.6);
    }
  }

  /* 右上角语言切换（本系统原有的多语言入口，保留但弱化显示） */
  .login-lang {
    margin-left: auto;

    :deep(.lang-select--style) {
      line-height: 1;
      font-size: 22px;
      padding: 6px;
      cursor: pointer;
      color: rgba(234, 247, 255, 0.75);
      transition: color 0.2s ease;

      &:hover {
        color: #fff;
      }
    }
  }
}

/* ---- 主体区域 ---- */
.login-main {
  flex: 1;
  display: flex;
  align-items: center;
  position: relative;
  z-index: 1;
  padding: 0 200px 0 60px;
  gap: 60px;
}

/* 左侧业务闭环插图 */
.left-panel {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;

  .pipeline-img {
    width: 100%;
    max-width: 640px;
    height: auto;
    border-radius: 16px;
  }
}

/* 右侧登录表单 —— 贴右 */
.right-panel {
  width: 420px;
  flex-shrink: 0;
  display: flex;
  justify-content: flex-end;
  margin-left: auto;
}

.login-form-wrapper {
  width: 100%;
}

.title-box {
  text-align: left;
  margin-bottom: 30px;

  .title {
    margin: 0;
    font-size: 24px;
    font-weight: 400;
    color: #1a1a2e;
    letter-spacing: 1px;
  }
}

.login-form {
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.95);
  border: 1px solid rgba(255, 255, 255, 0.5);
  width: 100%;
  padding: 40px 36px;
  box-shadow:
    0 20px 60px rgba(0, 0, 0, 0.25),
    0 0 40px rgba(34, 211, 238, 0.08);
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);

  .el-input {
    height: 44px;
    input {
      height: 44px;
    }
  }

  .input-icon {
    height: 43px;
    width: 16px;
    margin-left: 0px;
  }
}

.login-form :deep(.el-input__wrapper) {
  background-color: rgba(255, 255, 255, 0.9);
  border-radius: 8px;
}

.login-form :deep(.el-input__wrapper.is-focus) {
  box-shadow: 0 0 0 3px rgba(64, 158, 255, 0.1);
  border-color: #409eff;
}

.login-form :deep(.el-button--primary) {
  border-radius: 8px;
  box-shadow: 0 8px 20px rgba(64, 158, 255, 0.3);
  height: 44px;
  font-size: 16px;
  font-weight: 600;
}

.login-code {
  width: calc(37% - 10px);
  height: 44px;
  float: right;
  margin-left: 10px;
  box-sizing: border-box;
  border-radius: 8px;
  overflow: hidden;
  background: rgba(255, 255, 255, 0.9);
  border: 1px solid var(--el-border-color-light);

  img {
    cursor: pointer;
    vertical-align: middle;
    display: block;
    width: 100%;
    height: 44px;
    object-fit: cover;
  }
}

.login-code-img {
  height: 44px;
  padding-left: 0;
}

/* ---- 底部 ---- */
.login-footer {
  height: 50px;
  line-height: 50px;
  text-align: center;
  color: rgba(255, 255, 255, 0.5);
  font-family: Arial, serif;
  font-size: 13px;
  letter-spacing: 1px;
  position: relative;
  z-index: 1;
}

/* ---- 响应式 ---- */
@media screen and (max-width: 992px) {
  .login-main {
    flex-direction: column;
    padding: 20px;
    gap: 20px;
  }

  .left-panel {
    order: 2;

    .pipeline-img {
      max-width: 480px;
    }
  }

  .right-panel {
    order: 1;
    width: 100%;
    max-width: 400px;
    margin-left: 0;
  }

  .login-header {
    padding: 0 20px;

    .logo-wrap {
      .logo-img {
        width: 40px;
        height: 40px;
      }

      .system-name {
        font-size: 22px;
      }
    }
  }
}

:global(html.dark) {
  .login-form {
    background: rgba(17, 24, 39, 0.95);
    border-color: rgba(148, 163, 184, 0.2);

    .title {
      color: #e2e8f0;
    }
  }

  .login-form :deep(.el-input__wrapper) {
    background-color: rgba(17, 24, 39, 0.7);
  }

  .login-footer {
    color: rgba(226, 232, 240, 0.5);
  }
}
</style>
