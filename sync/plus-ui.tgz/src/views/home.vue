<template>
  <div class="home_main">
    <!-- 背景图：assets/images/home_background.png -->
    <div class="bg_layer bg_terrain"></div>
    <div class="bg_layer bg_mask"></div>
    <div class="bg_layer bg_grid"></div>
    <div class="bg_layer bg_scan"></div>
    <!-- 上浮数据粒子 -->
    <div class="bg_layer bg_particles">
      <span v-for="n in 14" :key="n" :style="particleStyle(n)"></span>
    </div>
    <div class="bg_layer bg_glow"></div>

    <!-- 顶部 -->
    <header class="home_header">
      <div class="logo">
        <img :src="logoImg" alt="logo" />
        <span>{{ pageTitle }}</span>
      </div>
      <div class="right_user_login" v-if="userStore.nickname || userStore.name">
        <span class="user_name">{{ userStore.nickname || userStore.name }}</span>
        <span class="divider">|</span>
        <span class="logout" @click="logout">退出登录</span>
      </div>
    </header>

    <!-- 子系统卡片区 -->
    <main class="home_content" v-loading="loading">
      <div class="content_body" :class="{ 'multi-row': itemsPerRow >= 2 }">
        <div
          v-show="itemsPerRow === 1"
          class="side_arrow left"
          :style="{ cursor: canMoveLeft ? 'pointer' : 'default', opacity: canMoveLeft ? 1 : 0.35 }"
          @click="moveLeft"
        >
          <el-icon><ArrowLeft /></el-icon>
        </div>

        <div class="content_swiper" :style="swiperStyle">
          <div
            class="swiper_list"
            :class="{ 'multi-row': itemsPerRow >= 2 }"
            :style="itemsPerRow === 1 ? { transform: `translateX(-${currentIndex * (itemWidth + 20)}px)` } : {}"
          >
            <div
              v-for="(item, index) in menuList"
              :key="index"
              class="content_item"
              :style="{
                width: itemWidth + 'px',
                height: itemHeight + 'px',
                '--card-color': item.color,
                animationDelay: `${index * 90}ms`
              }"
              @click="handleClick(item)"
            >
              <!-- HUD 四角装饰 -->
              <span class="hud_corner tl"></span>
              <span class="hud_corner tr"></span>
              <span class="hud_corner bl"></span>
              <span class="hud_corner br"></span>

              <div class="icon">
                <svg viewBox="0 0 120 104" class="hex_svg">
                  <polygon class="hex_shape" points="114,52 87,98.8 33,98.8 6,52 33,5.2 87,5.2" />
                  <polygon class="hex_shape_inner" points="109,52 84.5,94.4 35.5,94.4 11,52 35.5,9.6 84.5,9.6" />
                  <g class="icon_paths" v-html="item.icon"></g>
                </svg>
              </div>

              <div class="item_line"></div>

              <div class="item_name">{{ item.name }}</div>
              <div class="item_desc" v-if="item.description">{{ item.description }}</div>
              <div class="item_badge" v-if="item.badge">{{ item.badge }}</div>
            </div>
          </div>
        </div>

        <div
          v-show="itemsPerRow === 1"
          class="side_arrow right"
          :style="{ cursor: canMoveRight ? 'pointer' : 'default', opacity: canMoveRight ? 1 : 0.35 }"
          @click="moveRight"
        >
          <el-icon><ArrowRight /></el-icon>
        </div>
      </div>

      <!-- 底部科技光带 -->
      <div class="light_line">
        <span class="dot"></span>
      </div>
    </main>

    <!-- 页脚 -->
    <footer class="home_footer">
      <!-- <span>承办单位：{{ organizer }}</span>
      <span>支撑单位：{{ supporter }}</span> -->
    </footer>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import type { CSSProperties } from 'vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import { useUserStore } from '@/store/modules/user';
import { usePermissionStore } from '@/store/modules/permission';
import { getToken } from '@/utils/auth';
import logoImg from '@/assets/logo/logo.png';
import { useI18n } from 'vue-i18n';

/** 数据上浮粒子的确定性分布（固定种子，避免每次渲染抖动） */
const particleStyle = (n: number): CSSProperties => {
  const left = (n * 67.5) % 100;
  const size = 2 + (n % 3);
  const duration = 9 + (n % 5) * 2;
  const delay = (n % 7) * 1.3;
  return {
    left: `${left}%`,
    width: `${size}px`,
    height: `${size}px`,
    animationDuration: `${duration}s`,
    animationDelay: `${delay}s`
  };
};

/** 子系统菜单项（扁平结构，无 children 层级） */
interface HomeMenuItem {
  name: string;
  description?: string;
  icon: string;
  color: string;
  path: string;
  pathKey: string;
  isFrame: number; // 0=外链 1=内部路由
  target?: '_self' | '_blank'; // 外链打开方式，默认 _self
  ssoToken?: boolean; // 跳转时是否带上当前登录态（子系统免登用），默认 false
  skipPermCheck?: boolean; // 是否跳过门户侧的菜单权限校验，默认 false
  badge?: string; // 角标文字（如"新""HOT"），空则不显示
  order?: number; // 排序权重，升序
  visible?: boolean; // 是否显示，默认 true
}
interface HomeMenuJson {
  title?: string;
  organizer?: string;
  supporter?: string;
  itemsPerRow?: number; // 每行显示几个卡片，行数自动
  menuSize?: { itemWidth?: number; itemHeight?: number };
  menu?: HomeMenuItem[];
}

const { t } = useI18n();
const router = useRouter();
const userStore = useUserStore();
const permissionStore = usePermissionStore();

/** 顶部菜单路由（用于子系统访问权限校验） */
const routers = computed(() => permissionStore.topbarRouters);

const loading = ref(false);
const pageTitle = computed(() => t('app.homeTitle'));
const organizer = import.meta.env.VITE_APP_ORGANIZER;
const supporter = import.meta.env.VITE_APP_UNIT_NAME;

const menuList = ref<HomeMenuItem[]>([]);
const itemsPerRow = ref(3); // 每行显示几个卡片，行数自动
const currentIndex = ref(0);
const itemWidth = ref(0);
const itemHeight = ref(0);
/** CSS v-bind 用的列宽字符串 */
const gridColWidth = computed(() => itemWidth.value + 'px');

/** 单行轮播时限定视口宽度；多行排列时撑满容器换行居中 */
const swiperStyle = computed(() => {
  if (itemsPerRow.value >= 2) return { width: '100%' };
  return { width: (itemWidth.value + 20) * itemsPerRow.value + 'px' };
});
const canMoveLeft = computed(() => currentIndex.value > 0);
const canMoveRight = computed(() => currentIndex.value < menuList.value.length - itemsPerRow.value);

const moveLeft = () => {
  if (canMoveLeft.value) currentIndex.value--;
};
const moveRight = () => {
  if (canMoveRight.value) currentIndex.value++;
};

/** 拉取首页门户配置 */
const getLinkData = async () => {
  loading.value = true;
  try {
    const response = await fetch(`${import.meta.env.BASE_URL}config/homeMenu.json`);
    if (!response.ok) throw new Error(t('common.homeConfigError'));
    const data: HomeMenuJson = await response.json();
    // 过滤不可见项 + 按 order 升序排列
    const raw = data.menu ?? [];
    menuList.value = raw.filter((item) => item.visible !== false).sort((a, b) => (a.order ?? 999) - (b.order ?? 999));
    itemsPerRow.value = data.itemsPerRow ?? itemsPerRow.value;
    itemWidth.value = data.menuSize?.itemWidth ?? itemWidth.value;
    itemHeight.value = data.menuSize?.itemHeight ?? itemHeight.value;
  } catch (error) {
    if (import.meta.env.DEV) console.error('首页配置加载失败', error);
    ElMessage({ message: t('common.homeConfigError'), type: 'error', plain: true });
  } finally {
    loading.value = false;
  }
};

/** 点击子系统：先校验权限，再区分外链/内部路由 */
/**
 * 解析地址里的 ${ENV_KEY} 占位符，取值来自 import.meta.env。
 * 这样同一份 homeMenu.json 在开发环境与生产环境可以指向不同地址
 * （例如 VITE_APP_RWGL_BASE 开发为 http://localhost:8091/ZHGL，生产为 /RWGL）。
 */
const resolvePath = (path: string) => String(path || '').replace(/\$\{(\w+)\}/g, (_m, key) => String((import.meta.env as any)[key] ?? ''));

/**
 * 子系统与门户共用同一套登录态（同一个后端认证中心、同一个 clientId）。
 * 同源部署时两边 localStorage 共享 Admin-Token，不带参数也能免登；
 * 跨源部署时（例如门户 80、子系统 8091）localStorage 不共享，
 * 这里把当前 token 拼到地址上，由子系统启动时写入本地登录态。
 */
const appendToken = (url: string) => {
  const token = getToken();
  if (!token) return url;
  return `${url}${url.includes('?') ? '&' : '?'}token=${encodeURIComponent(token)}`;
};

const handleClick = (item: HomeMenuItem) => {
  // 权限校验：pathKey 与【本系统(门户)】的菜单路由比对。
  // 注意：跳转到其它子系统的卡片，其 pathKey（如 /task-resource）并不在门户菜单里，
  // 这里比对必然失败、会误报“没有权限访问该系统”；这类卡片的真实权限由目标系统
  // 自己的菜单/权限控制，因此用 skipPermCheck 跳过门户侧校验。
  // 若需要门户侧严格把控，把卡片里的 skipPermCheck 去掉，并在门户菜单里配上
  // 对应 pathKey 的菜单即可恢复拦截。
  if (!item.skipPermCheck) {
    const hasPermission = routers.value.some((route) => route.path === item.pathKey);
    if (!hasPermission) {
      ElMessage({ message: t('common.noPermissionSystem'), type: 'warning', plain: true });
      return;
    }
  }
  const path = resolvePath(item.path);
  // isFrame=1 外链；isFrame=0 内部路由
  if (item.isFrame) {
    const url = item.ssoToken ? appendToken(path) : path;
    const target = item.target || '_self';
    if (target === '_blank') {
      window.open(url, '_blank');
    } else {
      window.location.href = url;
    }
  } else {
    router.push(path);
  }
};

const logout = async () => {
  try {
    await ElMessageBox.confirm(t('common.logoutConfirm'), t('common.tip'), {
      confirmButtonText: t('common.confirm'),
      cancelButtonText: t('common.cancel'),
      type: 'warning'
    });
  } catch {
    return;
  }
  await userStore.logout();
  router.push('/login');
};

onMounted(() => {
  getLinkData();
});
</script>

<style lang="scss" scoped>
.home_main {
  position: relative;
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100%;
  min-height: 100vh;
  overflow: hidden;
  background: radial-gradient(ellipse at 50% 18%, #10314f 0%, #081c36 46%, #040f22 100%);
}

/* ============ 底图层 ============ */
.bg_layer {
  position: absolute;
  inset: 0;
  pointer-events: none;
}

/* 背景图片 */
.bg_terrain {
  background-image: url('../assets/images/home_background.png');
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  animation: terrainDrift 30s ease-in-out infinite alternate;
}
@keyframes terrainDrift {
  from {
    transform: scale(1) translateY(0);
  }
  to {
    transform: scale(1.05) translateY(-10px);
  }
}

/* 轻压暗遮罩，保证前景可读且不遮挡背景图 */
.bg_mask {
  background: linear-gradient(180deg, rgba(4, 12, 32, 0.3) 0%, rgba(4, 12, 32, 0.05) 40%, rgba(3, 9, 24, 0.45) 100%);
}

/* 坐标网格 */
.bg_grid {
  background-image:
    linear-gradient(rgba(90, 200, 255, 0.07) 1px, transparent 1px), linear-gradient(90deg, rgba(90, 200, 255, 0.07) 1px, transparent 1px);
  background-size: 48px 48px;
  mask-image: radial-gradient(ellipse at 50% 45%, #000 30%, transparent 80%);
}

/* 横向扫描光带 */
.bg_scan {
  overflow: hidden;

  &::after {
    content: '';
    position: absolute;
    top: 0;
    bottom: 0;
    width: 32%;
    background: linear-gradient(90deg, transparent, rgba(103, 232, 249, 0.07), transparent);
    transform: skewX(-14deg);
    animation: scanMove 9s linear infinite;
  }
}
@keyframes scanMove {
  0% {
    left: -32%;
  }
  100% {
    left: 110%;
  }
}

/* 上浮数据粒子 */
.bg_particles span {
  position: absolute;
  bottom: -8px;
  border-radius: 50%;
  background: #a5f3fc;
  box-shadow: 0 0 8px 1px rgba(103, 232, 249, 0.8);
  opacity: 0;
  animation-name: particleUp;
  animation-timing-function: ease-in;
  animation-iteration-count: infinite;
}
@keyframes particleUp {
  0% {
    transform: translateY(0);
    opacity: 0;
  }
  12% {
    opacity: 0.85;
  }
  88% {
    opacity: 0.5;
  }
  100% {
    transform: translateY(-92vh);
    opacity: 0;
  }
}

.bg_glow {
  background:
    radial-gradient(circle at 12% 16%, rgba(34, 211, 238, 0.14), transparent 34%),
    radial-gradient(circle at 88% 12%, rgba(59, 130, 246, 0.12), transparent 32%);
}

/* ============ 顶部 ============ */
.home_header {
  position: relative;
  z-index: 2;
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 118px;
  padding: 0 48px;

  .logo {
    display: flex;
    align-items: center;

    img {
      width: 66px;
      border-radius: 50%;
      /* 圆形透明 logo：用 drop-shadow 跟随圆形轮廓发光；box-shadow 只做一圈细描边光环 */
      // filter: drop-shadow(0 0 7px rgba(103, 232, 249, 0.55));
      // box-shadow: 0 0 0 1px rgba(103, 232, 249, 0.35), 0 0 1px rgba(103, 232, 249, 0.25);
    }

    span {
      margin-left: 20px;
      font-family: 'PangmenZhengdao';
      font-size: 50px;
      letter-spacing: 6px;
      color: #eaf7ff;
      text-shadow:
        0 0 18px rgba(34, 211, 238, 0.65),
        0 2px 4px rgba(0, 20, 40, 0.6);
      white-space: 5px;
    }
  }

  .right_user_login {
    display: flex;
    align-items: center;
    padding: 9px 20px;
    color: #cfeeff;
    font-size: 15px;
    background: linear-gradient(135deg, rgba(14, 52, 86, 0.72), rgba(8, 28, 56, 0.72));
    border: 1px solid rgba(56, 189, 248, 0.55);
    border-radius: 6px;
    box-shadow:
      0 0 18px rgba(34, 211, 238, 0.25),
      inset 0 0 14px rgba(34, 211, 238, 0.12);
    backdrop-filter: blur(4px);

    .divider {
      margin: 0 12px;
      color: rgba(120, 200, 240, 0.6);
    }

    .logout {
      cursor: pointer;
      transition: color 0.2s;

      &:hover {
        color: #7dd3fc;
        text-shadow: 0 0 10px rgba(125, 211, 252, 0.8);
      }
    }
  }
}

/* ============ 卡片区 ============ */
.home_content {
  position: relative;
  z-index: 2;
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.content_body {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0 80px;
}

.content_swiper {
  overflow: hidden;
}

.swiper_list {
  display: flex;
  width: max-content;
  padding: 12px 0;
  transition: transform 0.55s cubic-bezier(0.22, 0.8, 0.36, 1);

  &.multi-row {
    display: grid;
    grid-template-columns: repeat(v-bind(itemsPerRow), v-bind(gridColWidth));
    gap: 20px;
    justify-content: center;
    width: 100%;
    transform: none !important;

    .content_item {
      margin: 0;
    }
  }
}

.content_item {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  margin: 10px;
  padding-top: 26px;
  cursor: pointer;
  border: 1px solid color-mix(in srgb, var(--card-color) 55%, transparent);
  border-radius: 8px;
  background: var(--card-color);
  background: linear-gradient(
    160deg,
    color-mix(in srgb, var(--card-color) 42%, rgba(14, 34, 66, 0.5)) 0%,
    color-mix(in srgb, var(--card-color) 20%, rgba(6, 18, 42, 0.72)) 100%
  );
  box-shadow:
    0 18px 36px rgba(0, 12, 30, 0.5),
    0 0 22px color-mix(in srgb, var(--card-color) 30%, transparent),
    inset 0 0 34px rgba(120, 200, 255, 0.06);
  backdrop-filter: blur(6px);
  opacity: 0;
  animation: cardIn 0.7s cubic-bezier(0.22, 0.8, 0.36, 1) forwards;
  transition:
    transform 0.3s ease,
    box-shadow 0.3s ease,
    border-color 0.3s ease;

  &:hover {
    transform: translateY(-7px);
    border-color: var(--card-color);
    box-shadow:
      0 26px 48px rgba(0, 12, 30, 0.6),
      0 0 38px color-mix(in srgb, var(--card-color) 55%, transparent),
      inset 0 0 40px color-mix(in srgb, var(--card-color) 14%, transparent);

    .hex_svg {
      /* 悬停：轻微放大，图标始终垂直 */
      transform: scale(1.07);
    }
    .hex_shape {
      /* 外框保持完整并点亮 */
      fill: color-mix(in srgb, var(--card-color) 22%, transparent);
      stroke: #eafaff;
    }
    .hex_shape_inner {
      /* 内框：一道亮白扫描光沿六边形循环流动（外框始终可见） */
      opacity: 1;
      stroke: #eafaff;
      stroke-dasharray: 46 248;
      filter: drop-shadow(0 0 6px #eafaff);
      animation: hexFlowInner 2.4s linear infinite;
    }
  }
}

@keyframes cardIn {
  from {
    opacity: 0;
    transform: translateY(34px) scale(0.94);
  }
  to {
    opacity: 1;
    transform: translateY(0) scale(1);
  }
}

/* 悬停时一道扫描光沿内六边形描边循环（周长 = 6×49 = 294） */
@keyframes hexFlowInner {
  to {
    stroke-dashoffset: -294;
  }
}

/* HUD 四角 */
.hud_corner {
  position: absolute;
  width: 14px;
  height: 14px;
  border-color: var(--card-color);
  border-style: solid;
  border-width: 0;
  opacity: 0.9;

  &.tl {
    top: 6px;
    left: 6px;
    border-top-width: 2px;
    border-left-width: 2px;
  }
  &.tr {
    top: 6px;
    right: 6px;
    border-top-width: 2px;
    border-right-width: 2px;
  }
  &.bl {
    bottom: 6px;
    left: 6px;
    border-bottom-width: 2px;
    border-left-width: 2px;
  }
  &.br {
    right: 6px;
    bottom: 6px;
    border-right-width: 2px;
    border-bottom-width: 2px;
  }
}

/* 六边形图标 */
.icon {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 104px;
}
.hex_svg {
  width: 108px;
  height: 96px;
  overflow: visible;
  transition: transform 0.45s cubic-bezier(0.22, 0.8, 0.36, 1);
  filter: drop-shadow(0 0 8px color-mix(in srgb, var(--card-color) 70%, transparent));
}
.hex_shape {
  fill: rgba(255, 255, 255, 0.05);
  stroke: var(--card-color);
  stroke-width: 2;
  transition:
    fill 0.3s ease,
    stroke 0.3s ease;
}
.hex_shape_inner {
  fill: none;
  stroke: var(--card-color);
  stroke-width: 1;
  opacity: 0.45;
  transition:
    opacity 0.3s ease,
    stroke 0.3s ease;
}
.icon_paths {
  fill: none;
  stroke: #eafaff;
  stroke-width: 3;
  stroke-linecap: round;
  stroke-linejoin: round;
  filter: drop-shadow(0 0 5px color-mix(in srgb, var(--card-color) 80%, transparent));
}

.item_line {
  width: 72%;
  height: 1px;
  margin: 6px auto 0;
  background: linear-gradient(90deg, transparent, var(--card-color), transparent);
  opacity: 0.85;
}

.item_name {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  margin-top: auto;
  padding: 0 14px;
  color: rgba(234, 250, 255, 0.92);
  font-size: 18px;
  font-weight: 600;
  letter-spacing: 2px;
  text-align: center;
  white-space: nowrap;
  transition:
    color 0.25s ease,
    text-shadow 0.25s ease;
}

.item_desc {
  padding: 4px 14px 20px;
  color: rgba(180, 210, 235, 0.7);
  font-size: 13px;
  letter-spacing: 1px;
  text-align: center;
  white-space: nowrap;
}

.item_badge {
  position: absolute;
  top: 10px;
  right: 10px;
  padding: 2px 8px;
  font-size: 11px;
  font-weight: 700;
  color: #fff;
  background: linear-gradient(135deg, #ef4444, #f97316);
  border-radius: 4px;
  box-shadow: 0 2px 8px rgba(239, 68, 68, 0.5);
  z-index: 3;
}

.content_item:hover .item_name {
  color: #fff;
  text-shadow: 0 0 12px var(--card-color);
}

/* 两侧箭头（单行轮播时） */
.side_arrow {
  position: absolute;
  top: 50%;
  z-index: 5;
  font-size: 44px;
  color: #7dd3fc;
  text-shadow: 0 0 16px rgba(34, 211, 238, 0.8);
  transform: translateY(-50%);
  transition: all 0.25s ease;

  &.left {
    left: 28px;
  }
  &.right {
    right: 28px;
  }
  &:hover {
    transform: translateY(-50%) scale(1.12);
  }
}

/* 底部科技光带 */
.light_line {
  position: relative;
  width: 46%;
  max-width: 720px;
  height: 2px;
  margin: 26px auto 0;
  background: linear-gradient(90deg, transparent, rgba(56, 189, 248, 0.75), transparent);
  box-shadow: 0 0 14px rgba(56, 189, 248, 0.55);

  .dot {
    position: absolute;
    top: 50%;
    left: 50%;
    width: 9px;
    height: 9px;
    background: #a5f3fc;
    border-radius: 50%;
    box-shadow: 0 0 16px 4px rgba(103, 232, 249, 0.9);
    transform: translate(-50%, -50%);
    animation: dotPulse 2.2s ease-in-out infinite;
  }
}
@keyframes dotPulse {
  0%,
  100% {
    opacity: 0.55;
    transform: translate(-50%, -50%) scale(0.8);
  }
  50% {
    opacity: 1;
    transform: translate(-50%, -50%) scale(1.25);
  }
}

/* ============ 页脚 ============ */
.home_footer {
  position: relative;
  z-index: 2;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 92px;
  color: rgba(214, 238, 255, 0.85);
  font-size: 15px;
  letter-spacing: 1px;

  span {
    margin: 0 26px;
  }
}
</style>
