<!--
  【临时】地图绘制模拟页：挂载真实 GeoMap + 真实查询面板（tabName=数据查询），
  用于复现「点了绘制按钮、地图上却画不出来」这类问题。
  访问：/ZHGL/__debug/map-draw-sim   验证完删除（含路由与白名单临时项）

  诊断入口 window.__diag()：
   - drawTool / hasMap / canvasCursor：状态与绘制引擎是否真的启动
   - drawSources / drawLayers：use-draw-tool 的预览图层是否建起来
   - mapEvents：maplibre 画布上真实收到的 mousedown / mouseup / mousemove 次数
   - hitTest(x, y)：给定视口坐标，最上层元素是什么（判定被谁盖住）
-->
<template>
  <div class="sim-wrap">
    <div class="sim-head">
      <span>地图绘制 / 勾选上图 模拟</span>
      <span class="tip">左侧真实「数据查询」列表：勾选一行 → 右侧地图应出现该资源几何</span>
      <el-button size="small" @click="result = ''">清空结果</el-button>
    </div>
    <pre class="sim-result">{{ result }}</pre>
    <div class="sim-body">
      <div class="sim-list">
        <DataQuery />
      </div>
      <div class="sim-map">
        <Map tab-name="数据查询" />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { onMounted, onUnmounted } from 'vue';
import Map from '@/views/product-manage/shared/map/index.vue';
import DataQuery from '@/views/product-manage/shared/data-query/index.vue';
import { useMap } from '@/views/product-manage/shared/map/use-map';
import { queryState, runGeometryQuery, runSampleQuery, sampleQuery } from '@/views/product-manage/shared/map/query/state';
import service from '@/utils/request';

const mapStore = useMap();
const result = ref('');
const log = (msg: string) => {
  result.value += `${msg}\n`;
};

/** 探针：记录每个响应的 url / 状态码 / body 前缀，用于定位是谁触发了 401 模态框 */
service.interceptors.request.use((c: any) => {
  if (String(c.url ?? '').includes('product-categories')) log(`[req] ${c.url} headers=${JSON.stringify(c.headers)}`);
  return c;
});
service.interceptors.response.use(
  (r: any) => {
    log(`[resp] ${r.config?.url} status=${r.status} body=${JSON.stringify(r.data).slice(0, 160)}`);
    return r;
  },
  (e: any) => {
    log(
      `[resp-err] ${e?.config?.url} status=${e?.response?.status} body=${JSON.stringify(e?.response?.data).slice(0, 160)} msg=${String(e?.message).slice(0, 120)}`
    );
    return Promise.reject(e);
  }
);

/** 地图实例就绪后挂探针：统计画布真实收到的事件 */
const detach: Array<() => void> = [];
onMounted(() => {
  const w = window as any;
  w.__mapEvents = { mousedown: 0, mouseup: 0, mousemove: 0, dblclick: 0, click: 0 };
  w.__diag = () => {
    const m = mapStore.mapInstance.value;
    const style = m?.getStyle();
    const sources = Object.keys(style?.sources ?? {});
    const layers = (style?.layers ?? []).map((l: any) => l.id);
    const drawSrc = sources.find((id) => id.startsWith('__draw_src_'));
    let drawFeatureCount = -1;
    if (m && drawSrc) {
      const data = (m.getSource(drawSrc) as any)?.serialize?.() ?? (m.getSource(drawSrc) as any)?._data;
      drawFeatureCount = data?.features?.length ?? -1;
    }
    return {
      drawTool: sampleQuery.drawTool,
      hasMap: !!m,
      canvasCursor: m?.getCanvas().style.cursor ?? null,
      drawSources: sources.filter((id) => id.startsWith('__draw_')),
      drawLayers: layers.filter((id) => id.startsWith('__draw_')),
      drawFeatureCount,
      // 50 万图幅格网（grid50）：source / 图层是否已挂上
      gridSources: sources.filter((id) => id.startsWith('grid50')),
      gridLayers: layers.filter((id) => id.startsWith('grid50')),
      gridFeatureCount: (m?.getSource('grid50-source') as any)?._data?.features?.length ?? -1,
      mapEvents: { ...w.__mapEvents },
      canvasRect: m ? m.getCanvas().getBoundingClientRect().toJSON() : null
    };
  };
  /** 给定视口坐标，返回最上层元素链（判定被谁盖住） */
  w.__hitTest = (x: number, y: number) => {
    const chain: string[] = [];
    let el = document.elementFromPoint(x, y) as HTMLElement | null;
    while (el && chain.length < 8) {
      const cs = getComputedStyle(el);
      chain.push(
        `${el.tagName.toLowerCase()}${el.id ? '#' + el.id : ''}.${(el.className || '').toString().split(' ').filter(Boolean).join('.')} [pe=${cs.pointerEvents} z=${cs.zIndex}]`
      );
      el = el.parentElement;
    }
    return chain;
  };
  /** 在画布中心点做一次命中测试 */
  w.__hitCanvas = () => {
    const r = (window as any).__diag().canvasRect;
    if (!r) return null;
    return (window as any).__hitTest(Math.round(r.x + r.width / 2), Math.round(r.y + r.height / 2));
  };

  /** 各浮层位置 + 全屏元素归属（判定全屏时查询面板是否被裁掉） */
  w.__rects = () => {
    const pick = (sel: string) => {
      const el = document.querySelector(sel);
      if (!el) return null;
      const r = el.getBoundingClientRect();
      return { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) };
    };
    const fs = document.fullscreenElement as HTMLElement | null;
    const qp = document.querySelector('.query-panel');
    return {
      geoMap: pick('.geo-map'),
      queryPanel: pick('.query-panel'),
      ctrlTopRight: pick('.maplibregl-ctrl-top-right'),
      ctrlBottomRight: pick('.maplibregl-ctrl-bottom-right'),
      legend: pick('.map-tools'),
      fullscreenElement: fs ? `${fs.tagName.toLowerCase()}.${fs.className}` : null,
      fsRect: fs
        ? (() => {
            const r = fs.getBoundingClientRect();
            return { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) };
          })()
        : null,
      queryPanelRendered: !!qp && !!(qp as HTMLElement).offsetParent,
      queryPanelInFsSubtree: fs && qp ? fs.contains(qp) : null
    };
  };

  // 暴露本页实际使用的模块实例，避免探针用 import() 拿到带 ?t= 的另一份实例（HMR 会分裂状态）
  w.__runGeometryQuery = (area: any) => runGeometryQuery(area);
  w.__runSampleQuery = () => runSampleQuery();

  /** 图层探针：__render__ 组渲染了多少要素 / 相机在哪（勾选后应从 (0,0) 变到要素所在地） */
  w.__layer = () => {
    const m = mapStore.mapInstance.value;
    if (!m) return { hasMap: false };
    const style = m.getStyle();
    const sources: Record<string, number> = {};
    for (const id of Object.keys(style?.sources ?? {})) {
      const data = (m.getSource(id) as any)?.serialize?.().data;
      if (data?.features) sources[id] = data.features.length;
    }
    const center = m.getCenter();
    let rendered = -1;
    try {
      rendered = m.queryRenderedFeatures().length;
    } catch {
      // 样式未就绪
    }
    return {
      hasMap: true,
      selectedIds: [...queryState.selectedIds],
      sources,
      rendered,
      center: [Number(center.lng.toFixed(4)), Number(center.lat.toFixed(4))],
      zoom: Number(m.getZoom().toFixed(2))
    };
  };

  /**
   * 要素落点探针：取每个有数据的 source 的首个要素坐标，投影到屏幕后做
   * queryRenderedFeatures，返回命中的图层与要素名 —— 用于确认「真的画出来了」而不只是 source 里有数据。
   */
  w.__featureAt = () => {
    const m = mapStore.mapInstance.value;
    if (!m) return null;
    const out: any[] = [];
    const style = m.getStyle();
    for (const id of Object.keys(style?.sources ?? {})) {
      const data = (m.getSource(id) as any)?.serialize?.().data;
      const f = data?.features?.[0];
      if (!f?.geometry) continue;
      const coords = f.geometry.type === 'Point' ? f.geometry.coordinates : f.geometry.coordinates?.[0]?.[0];
      if (!coords) continue;
      const pt = m.project(coords as [number, number]);
      const hits = m.queryRenderedFeatures(pt).map((h: any) => ({
        layer: h.layer?.id,
        type: h.layer?.type,
        name: h.properties?.name ?? h.properties?.product_name ?? null
      }));
      out.push({ source: id, coord: coords, screen: [Math.round(pt.x), Math.round(pt.y)], hits });
    }
    return out;
  };

  /** 点右上角全屏按钮 */
  w.__clickFullscreen = () => {
    const btn = document.querySelector('.maplibregl-ctrl-fullscreen button') as HTMLButtonElement | null;
    if (!btn) return 'no-button';
    btn.click();
    return 'clicked';
  };
  w.__exitFullscreen = () => {
    if (document.fullscreenElement) document.exitFullscreen();
  };

  /** 浏览器实际拿到的模块源码里有没有该改动（判断是否走了旧的 transform 缓存） */
  w.__moduleSrc = async () => {
    const pick = async (u: string) => {
      try {
        const t = await fetch(u).then((r) => r.text());
        return { ok: true, hasBestEffort: t.includes('BEST_EFFORT_HEADER'), len: t.length };
      } catch (e: any) {
        return { ok: false, err: String(e?.message).slice(0, 60) };
      }
    };
    return {
      store: await pick('/ZHGL/src/views/product-manage/shared/store.ts'),
      category: await pick('/ZHGL/src/api/product-manage/platform/category.ts')
    };
  };

  // 轮询等地图实例就绪后挂事件计数
  const timer = window.setInterval(() => {
    const m = mapStore.mapInstance.value;
    if (!m) return;
    window.clearInterval(timer);
    log('[probe] map ready');
    ['mousedown', 'mouseup', 'mousemove', 'dblclick', 'click'].forEach((name) => {
      const handler = () => {
        (window as any).__mapEvents[name] += 1;
      };
      m.on(name as any, handler);
      detach.push(() => m.off(name as any, handler));
    });
    log('[probe] listeners attached');
  }, 200);
  detach.push(() => window.clearInterval(timer));
});

onUnmounted(() => detach.forEach((fn) => fn()));
</script>

<style scoped lang="scss">
.sim-wrap {
  display: flex;
  flex-direction: column;
  gap: 8px;
  height: 100%;
  padding: 12px;
}
.sim-head {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 13px;
  font-weight: 600;
  .tip {
    color: #8a97a8;
    font-weight: 400;
  }
}
.sim-result {
  flex: none;
  max-height: 120px;
  margin: 0;
  padding: 8px;
  overflow: auto;
  color: #26364b;
  font-size: 12px;
  background: #f5f7fa;
  border-radius: 6px;
}
.sim-body {
  display: flex;
  flex: 1;
  gap: 8px;
  min-height: 0;
}
.sim-list {
  flex: none;
  width: 620px;
  min-height: 0;
  overflow: hidden;
  background: #fff;
  border: 1px solid rgb(31 55 84 / 12%);
  border-radius: 8px;
}
.sim-map {
  position: relative;
  flex: 1;
  min-height: 0;
  overflow: hidden;
  background: #dde6f0;
  border: 1px solid rgb(31 55 84 / 12%);
  border-radius: 8px;
}
</style>
