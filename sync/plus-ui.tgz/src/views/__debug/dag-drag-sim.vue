<!--
  【临时】拖拽模拟页：真实右侧单元面板 + 真实拖拽链路，只把 3 个后端接口换成假数据。
  目的：复现"拖 mock异步作业单元，结果建出来的是 mock同步作业单元"这类问题。
  访问：/ZHGL/__debug/dag-drag-sim   验证完删除（含路由与白名单临时项）
-->
<template>
  <div class="sim-wrap">
    <div class="sim-head">
      <span>拖拽模拟</span>
      <span class="tip">点下面按钮 = 在右侧面板对应单元上发起真实 dragstart，再落到画布上</span>
      <el-button size="small" type="primary" @click="simulateDrag('mock异步作业单元')">模拟拖入：异步</el-button>
      <el-button size="small" type="primary" @click="simulateDrag('mock同步作业单元')">模拟拖入：同步</el-button>
      <el-button size="small" type="primary" @click="simulateDrag('参数回显测试单元')">模拟拖入：参数回显</el-button>
      <el-button size="small" type="danger" @click="runAll">依次拖入 3 个单元（自动关弹窗）</el-button>
      <el-button size="small" type="warning" @click="runSaveFlow">拖入两个节点并取保存报文</el-button>
      <el-button size="small" type="success" @click="testStaleModal">检查弹窗是否沿用上一个单元</el-button>
      <el-button size="small" type="primary" @click="loadRealDef">加载真实接口返回的回填数据</el-button>
      <el-button size="small" type="warning" @click="loadLogicDef">加载含逻辑节点的流程</el-button>
      <el-button size="small" @click="checkStatusColors('RUNNING')">着色：执行中</el-button>
      <el-button size="small" @click="checkStatusColors('SUCCESS')">着色：已完成</el-button>
      <el-button size="small" @click="checkStatusColors('PENDING')">着色：未完成</el-button>
      <el-button size="small" @click="checkStatusColors('FAILED')">着色：失败</el-button>
      <el-button size="small" @click="checkStatusColors('NONE')">清除状态着色</el-button>
      <el-button size="small" @click="reset">清空画布</el-button>
    </div>
    <pre id="sim-result" class="sim-result">{{ result }}</pre>
    <div class="sim-canvas">
      <NMessageProvider>
        <Dag
          ref="dagRef"
          :definition="definition"
          :project-code="123"
          :readonly="false"
          :node-status-map="nodeStatusMap"
          :node-detail-map="nodeDetailMap"
          @save="onSavePayload"
        />
      </NMessageProvider>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { NMessageProvider } from 'naive-ui';
import Dag from '@/views/task-scheduling/flow/dag';
import service from '@/utils/request';

/** 假作业单元：名字与注册表一致（异步/同步只差一个字，正是容易拖错的地方） */
const UNITS = [
  {
    id: '19001',
    unitCode: 'TEST-PARAM-002',
    unitName: '参数回显测试单元',
    nodeType: '通用',
    baseUrl: 'http://10.61.129.28:18081/unit/echo',
    description: '参数回显：被调用时回显收到的全部参数',
    publishStatus: '1'
  },
  {
    id: '19002',
    unitCode: 'mock-async-unit',
    unitName: 'mock异步作业单元',
    nodeType: '通用',
    baseUrl: 'http://10.61.129.28:18081/unit/async',
    description: '异步：返回已受理，完成靠回调',
    publishStatus: '1'
  },
  {
    id: '19003',
    unitCode: 'mock-sync-unit',
    unitName: 'mock同步作业单元',
    nodeType: '通用',
    baseUrl: 'http://10.61.129.28:18081/unit/sync',
    description: '同步：被调用后立即返回结果',
    publishStatus: '1'
  }
];

// 真实雪花号：跨毫秒的两次生成相差 2^22，所以这里按同样步长递增，模拟"两次拖拽间隔约 1 毫秒以上"
let codeSeed = 1878700000000000000n;
const CODE_STEP = 4194304n;

// 用 axios adapter 顶掉真实接口（只影响这个模拟页：请求不发出，直接回假数据）
const request = service as any;
request.defaults.adapter = (config: any) => {
  const url = String(config.url || '');
  // 全局请求拦截器会把 GET 的 params 拼到 url 上并清空 config.params，
  // 所以这里两个来源都取一遍，保证模拟接口能拿到真实入参。
  const query: Record<string, any> = {};
  const qs = url.includes('?') ? url.slice(url.indexOf('?') + 1) : '';
  new URLSearchParams(qs).forEach((v, k) => {
    query[k] = v;
  });
  const params = { ...query, ...(config.params || {}) };
  // 注意：全局响应拦截器会读 res.request.responseType，所以这里必须带上 request
  const respond = (body: any) =>
    Promise.resolve({
      data: body,
      status: 200,
      statusText: 'OK',
      headers: {},
      config,
      request: { responseType: config.responseType || '' }
    });

  // 节点 URL：返回值里带上请求的 unitCode，便于核对"到底给哪个单元要了地址"
  if (url.includes('/work-units/node-url')) {
    const unitCode = params.unitCode;
    console.info('[模拟接口] node-url 被请求，unitCode =', unitCode);
    return respond({
      code: 200,
      msg: '成功',
      data: {
        unitCode,
        nodeUrl: `http://127.0.0.1:12345/dolphinscheduler/resource/tasks/submit-and-wait?workUnitCode=${unitCode}&subTaskNo=__SUB_TASK_NO__`
      }
    });
  }
  if (url.includes('/work-units')) {
    console.info('[模拟接口] 作业单元列表被请求');
    return respond({ code: 200, msg: '成功', total: UNITS.length, rows: UNITS });
  }
  if (url.includes('gen-task-codes')) {
    const n = Number(params.genNum || 1);
    const codes: string[] = [];
    for (let i = 0; i < n; i += 1) {
      codes.push(String(codeSeed));
      codeSeed += CODE_STEP;
    }
    console.info('[模拟接口] 生成节点 code =', codes.join(', '));
    return respond({ code: 200, msg: '操作成功', data: codes });
  }
  console.warn('[模拟接口] 未拦截的请求（直接返回空成功）:', url);
  return respond({ code: 200, msg: 'ok（模拟）', data: null });
};

const dagRef = ref<any>(null);
const result = ref('（还没有拖拽）');
const nodeStatusMap = ref<Record<string, string>>({});
const nodeDetailMap = ref<Record<string, any>>({});
const definition = ref<any>({
  workflowDefinition: { name: 'sim', code: 888888888888, releaseState: 'OFFLINE', locations: '[]' },
  taskDefinitionList: [],
  workflowTaskRelationList: []
});

/**
 * 线上实际接口返回（2026-10-10 16:14 保存的「子任务3」）：
 *  - taskDefinitionList 里 code 是【字符串】
 *  - workflowDefinition.locations 是【字符串】，但里面 taskCode 是【数字】
 * 这正是"接口有 2 个节点、画布只显示 1 个"的复现素材。
 */
const REAL_DEF = {
  workflowDefinition: {
    name: '子任务3',
    code: 186562214021216,
    releaseState: 'OFFLINE',
    projectCode: 186562214002784,
    locations:
      '[{"taskCode":1878649811432898600,"x":353,"y":157},{"taskCode":1878649815720525800,"x":810,"y":80}]'
  },
  taskDefinitionList: [
    {
      code: '1878649811432898600',
      name: '参数回显测试单元',
      version: 1,
      taskType: 'HTTP',
      flag: 'YES',
      taskParams: {
        url: 'http://127.0.0.1:12345/dolphinscheduler/resource/tasks/submit-and-wait?workUnitCode=TEST-PARAM-002&subTaskNo=__SUB_TASK_NO__',
        httpMethod: 'POST'
      }
    },
    {
      code: '1878649815720525800',
      name: 'mock同步作业单元',
      version: 1,
      taskType: 'HTTP',
      flag: 'YES',
      taskParams: {
        url: 'http://127.0.0.1:12345/dolphinscheduler/resource/tasks/submit-and-wait?workUnitCode=mock-sync-unit&subTaskNo=__SUB_TASK_NO__',
        httpMethod: 'POST'
      }
    }
  ],
  workflowTaskRelationList: [
    { preTaskCode: '0', postTaskCode: '1878649811432898600' },
    { preTaskCode: '1878649811432898600', postTaskCode: '1878649815720525800' }
  ]
};

/** 含逻辑节点（SWITCH）的流程：同步 → 逻辑 → 两个分支，用于验证逻辑规则编辑器 */
const LOGIC_DEF = {
  workflowDefinition: {
    name: '逻辑流程',
    code: 188888888881,
    releaseState: 'OFFLINE',
    projectCode: 188888888880,
    locations: JSON.stringify([
      { taskCode: '1878804700274360394', x: 180, y: 170 },
      { taskCode: '1878804700274360395', x: 500, y: 170 },
      { taskCode: '1878804700274360396', x: 860, y: 80 },
      { taskCode: '1878804700274360397', x: 860, y: 280 }
    ])
  },
  taskDefinitionList: [
    {
      code: '1878804700274360394',
      name: 'mock同步作业单元',
      taskType: 'HTTP',
      flag: 'YES',
      version: 1,
      taskParams: {
        localParams: [
          { prop: 'unitCode', value: 'mock-sync-unit', direct: 'IN', type: 'VARCHAR' },
          { prop: 'unitName', value: 'mock同步作业单元', direct: 'IN', type: 'VARCHAR' },
          { prop: 'nodeType', value: '通用', direct: 'IN', type: 'VARCHAR' }
        ],
        url: 'http://127.0.0.1:12345/dolphinscheduler/resource/tasks/submit-and-wait?workUnitCode=mock-sync-unit&subTaskNo=__SUB_TASK_NO__',
        httpMethod: 'POST'
      }
    },
    {
      code: '1878804700274360395',
      name: '逻辑-结果路径是否存在',
      taskType: 'SWITCH',
      flag: 'YES',
      version: 1,
      taskParams: {
        localParams: [
          { prop: 'unitCode', value: '', direct: 'IN', type: 'VARCHAR' },
          { prop: 'unitName', value: '逻辑-结果路径是否存在', direct: 'IN', type: 'VARCHAR' },
          { prop: 'nodeType', value: '逻辑', direct: 'IN', type: 'VARCHAR' }
        ],
        logicConfig: JSON.stringify({
          kind: 'condition',
          version: 1,
          mode: 'binary',
          branches: [
            {
              key: 'yes',
              label: '是',
              isDefault: false,
              logic: 'AND',
              rules: [
                {
                  // 故意用 sourceType='node'：模拟"接口写入/老数据"，验证编辑器能正确回显成"上游节点的结果"
                  sourceType: 'node',
                  upstreamIndex: 1,
                  field: 'resultPath',
                  type: 'string',
                  operator: 'NOT_EMPTY',
                  value: ''
                }
              ]
            },
            { key: 'no', label: '否', isDefault: true, logic: 'AND', rules: [] }
          ]
        })
      }
    },
    {
      code: '1878804700274360396',
      name: '分支-有结果',
      taskType: 'HTTP',
      flag: 'YES',
      version: 1,
      taskParams: {
        localParams: [{ prop: 'unitCode', value: 'TEST-PARAM-002', direct: 'IN', type: 'VARCHAR' }],
        url: 'http://127.0.0.1:12345/dolphinscheduler/resource/tasks/submit-and-wait?workUnitCode=TEST-PARAM-002&subTaskNo=__SUB_TASK_NO__',
        httpMethod: 'POST'
      }
    },
    {
      code: '1878804700274360397',
      name: '分支-无结果',
      taskType: 'HTTP',
      flag: 'YES',
      version: 1,
      taskParams: {
        localParams: [{ prop: 'unitCode', value: 'mock-async-unit', direct: 'IN', type: 'VARCHAR' }],
        url: 'http://127.0.0.1:12345/dolphinscheduler/resource/tasks/submit-and-wait?workUnitCode=mock-async-unit&subTaskNo=__SUB_TASK_NO__',
        httpMethod: 'POST'
      }
    }
  ],
  workflowTaskRelationList: [
    { preTaskCode: '0', postTaskCode: '1878804700274360394' },
    { preTaskCode: '1878804700274360394', postTaskCode: '1878804700274360395' },
    { preTaskCode: '1878804700274360395', postTaskCode: '1878804700274360396' },
    { preTaskCode: '1878804700274360395', postTaskCode: '1878804700274360397' }
  ]
};

/** 打印画布上每个节点的真实数据（名称 / 单元编码 / 调用地址） */
function dump() {
  const graph = dagRef.value?.graph;
  const nodes = graph?.getNodes?.() || [];
  const rows = nodes.map((node: any) => ({ id: node.id, ...(node.getData() || {}) }));
  console.info('[模拟] 画布节点:', rows);
  (window as any).__simNodes = rows;
  return rows;
}

function reset() {
  const graph = dagRef.value?.graph;
  graph?.clearCells?.();
  dump();
}

/** 关掉可能挡在前面的节点设置弹窗（真实拖拽时用户会先关掉再拖下一个） */
async function closeModals() {
  const btns = Array.from(document.querySelectorAll('.n-modal button'));
  const close = btns.find((b) => /取消|关闭|取 消/.test(b.textContent || ''));
  if (close) {
    (close as HTMLElement).click();
    await new Promise((r) => setTimeout(r, 400));
  }
}

/**
 * 在真实的面板项上派发 dragstart，再在画布上派发 drop —— 走的就是用户拖拽时那条链路。
 * 只把结果打印成文本，方便外部读取（不需要控制台）。
 */
async function doDrag(keyword: string) {
  await closeModals();
  const item = Array.from(document.querySelectorAll('[draggable="true"]')).find((el) =>
    (el.textContent || '').includes(keyword)
  ) as HTMLElement | undefined;
  const canvas = document.querySelector('.dag-container') as HTMLElement | undefined;
  if (!item || !canvas) {
    throw new Error(`找不到元素：item=${!!item} canvas=${!!canvas}`);
  }
  // 把"实际被拖的那一行"文本打到控制台，避免名字相近时误判
  // eslint-disable-next-line no-console
  console.info('[模拟] 拖拽源行文本 =', JSON.stringify(item.textContent || ''));
  const ir = item.getBoundingClientRect();
  const cr = canvas.getBoundingClientRect();
  const x = cr.x + 260;
  const y = cr.y + 180;
  const dt = new DataTransfer();
  const fire = (target: HTMLElement, type: string) =>
    target.dispatchEvent(
      new DragEvent(type, { bubbles: true, cancelable: true, clientX: x, clientY: y, dataTransfer: dt })
    );
  item.dispatchEvent(
    new DragEvent('dragstart', {
      bubbles: true,
      cancelable: true,
      clientX: ir.x + 10,
      clientY: ir.y + 10,
      dataTransfer: dt
    })
  );
  fire(canvas, 'dragover');
  fire(canvas, 'drop');
  // 真实浏览器在 drop 之后一定会在源元素上再补一个 dragend
  fire(item, 'dragend');
  await new Promise((r) => setTimeout(r, 1400));
  const rows = dump();
  await closeModals();
  return rows;
}

async function simulateDrag(keyword: string) {
  try {
    const rows = await doDrag(keyword);
    result.value =
      `模拟拖入「${keyword}」后的画布节点：\n` +
      JSON.stringify(rows, null, 2) +
      `\n\n共 ${rows.length} 个节点`;
  } catch (e: any) {
    result.value = '出错：' + (e?.message || e);
  }
}

/** 一次点完：依次拖入三个单元，每次自动关掉"当前节点设置"弹窗，最后汇总 */
async function runAll() {
  const keys = ['mock异步作业单元', 'mock同步作业单元', '参数回显测试单元'];
  dagRef.value?.graph?.clearCells?.();
  await new Promise((r) => setTimeout(r, 300));
  const parts: string[] = [];
  for (const k of keys) {
    try {
      const rows = await doDrag(k);
      parts.push(
        `拖入「${k}」→ 画布共 ${rows.length} 个节点：\n` +
          rows.map((r: any) => `   - ${r.taskName} [${r.unitCode}]`).join('\n')
      );
    } catch (e: any) {
      parts.push(`拖入「${k}」失败：` + (e?.message || e));
    }
  }
  result.value = parts.join('\n\n');
}

// 方便在浏览器控制台手动调用
(window as any).__simDump = dump;
(window as any).__simDrag = simulateDrag;
(window as any).__simRunAll = runAll;

/** 捕获 Dag 组件 emit('save') 的报文（= 前端最终要提交给海豚的内容） */
function onSavePayload(payload: any) {
  const defs = payload?.taskDefinitions || [];
  const connects = payload?.connects || [];
  const summary = defs.map((t: any) => {
    const url = t?.taskParams?.url || t?.url || '';
    const code = url.match(/workUnitCode=([^&]*)/)?.[1] || '';
    return `   - ${t.name} | workUnitCode=${code} | ${t.taskType}`;
  });
  const out =
    `保存报文里的节点（共 ${defs.length} 个）：\n` +
    summary.join('\n') +
    `\n\n任务关系 taskRelationJson（共 ${connects.length} 条）：\n` +
    connects.map((c: any) => `   - ${c.preTaskCode} → ${c.postTaskCode}`).join('\n');
  // eslint-disable-next-line no-console
  console.info('[模拟] 保存报文节点:', JSON.stringify(summary));
  result.value = out;
}

/** 拖入「参数回显」+「mock异步」两个节点，然后调用保存，取出最终报文 */
async function runSaveFlow() {
  dagRef.value?.graph?.clearCells?.();
  await new Promise((r) => setTimeout(r, 300));
  await doDrag('参数回显测试单元');
  await doDrag('mock异步作业单元');
  await new Promise((r) => setTimeout(r, 400));
  // 按用户的实际操作把两个节点连起来（第一 → 第二），再看保存报文
  const g = dagRef.value?.graph;
  const nodes = g?.getNodes?.() || [];
  if (nodes.length >= 2) {
    g.addEdge({ source: nodes[0].id, target: nodes[1].id });
    await new Promise((r) => setTimeout(r, 300));
  }
  result.value = '已拖入两个节点，正在生成保存报文…';
  dagRef.value?.save?.();
}

/** 读当前"当前节点设置"弹窗里显示的单元（节点名称输入框 + 作业单元单元格） */
function readModalUnit() {
  const modal = document.querySelector('.n-modal');
  if (!modal) return null;
  const input = modal.querySelector('input') as HTMLInputElement | null;
  const cells = Array.from(modal.querySelectorAll('td')).map((td) => (td.textContent || '').trim());
  return { nameField: input?.value ?? '', cells: cells.filter(Boolean).slice(0, 8) };
}

/** 验证：先拖「同步」关掉，再拖「异步」，看第二次弹窗是否还残留同步的信息 */
async function testStaleModal() {
  dagRef.value?.graph?.clearCells?.();
  await new Promise((r) => setTimeout(r, 300));
  const lines: string[] = [];
  for (const k of ['mock同步作业单元', 'mock异步作业单元']) {
    await closeModals();
    const item = Array.from(document.querySelectorAll('[draggable="true"]')).find((el) =>
      (el.textContent || '').includes(k)
    ) as HTMLElement | undefined;
    const canvas = document.querySelector('.dag-container') as HTMLElement | undefined;
    if (!item || !canvas) {
      lines.push(`拖「${k}」失败：找不到元素`);
      continue;
    }
    const cr = canvas.getBoundingClientRect();
    const x = cr.x + 260;
    const y = cr.y + 180;
    const dt = new DataTransfer();
    const mk = (type: string, cx: number, cy: number) =>
      new DragEvent(type, { bubbles: true, cancelable: true, clientX: cx, clientY: cy, dataTransfer: dt });
    item.dispatchEvent(mk('dragstart', x, y));
    canvas.dispatchEvent(mk('dragover', x, y));
    canvas.dispatchEvent(mk('drop', x, y));
    await new Promise((r) => setTimeout(r, 1200));
    const shown = readModalUnit();
    lines.push(
      `拖入「${k}」→ 弹窗显示：节点名称="${shown?.nameField}"，表格前几格=${JSON.stringify(shown?.cells)}`
    );
  }
  result.value = lines.join('\n');
}

/** 用线上真实返回回填画布，看看画布上到底有几个节点、坐标是多少 */
async function loadRealDef() {
  dagRef.value?.graph?.clearCells?.();
  definition.value = JSON.parse(JSON.stringify(REAL_DEF));
  await new Promise((r) => setTimeout(r, 1500));
  const g = dagRef.value?.graph;
  const nodes = g?.getNodes?.() || [];
  const rows = nodes.map((n: any) => {
    const pos = n.getPosition?.() || {};
    return { id: n.id, name: n.getData?.()?.taskName, x: pos.x, y: pos.y };
  });
  const edges = (g?.getEdges?.() || []).map(
    (e: any) => `${e.getSourceCellId()} → ${e.getTargetCellId()}`
  );
  result.value =
    `画布节点数 = ${rows.length}\n` +
    JSON.stringify(rows, null, 2) +
    `\n\n连线数 = ${edges.length}\n` +
    edges.join('\n');
}

/**
 * 把画布上所有节点标成某个执行状态，然后读真实渲染出来的
 * 边框色与文字色，验证是不是 #00b6da（执行中）/ #60b45e（已完成）。
 */
async function checkStatusColors(status: string) {
  const g = dagRef.value?.graph;
  if (!g) return;
  const initial = g.getNodes() || [];
  if (!initial.length) {
    result.value = '画布上没有节点，请先点「加载真实接口返回的回填数据」';
    return;
  }
  const map: Record<string, string> = {};
  initial.forEach((n: any) => {
    map[String(n.id)] = status;
  });
  // status === 'NONE' 表示清空状态表（回到"没有执行计划"的默认样式）
  nodeStatusMap.value = status === 'NONE' ? {} : map;
  // 造一份执行记录（字段与接口一致），用于验证"节点下方一行"和点击详情
  const detail: Record<string, any> = {};
  initial.forEach((n: any, i: number) => {
    const done = status === 'SUCCESS';
    detail[String(n.id)] = {
      nodeCode: String(n.id),
      nodeName: n.getData?.()?.taskName,
      unitCode: n.getData?.()?.unitCode,
      unitName: n.getData?.()?.unitName,
      attempt: 1,
      status,
      progress: done ? '100.00' : '0.00',
      submitTime: '2026-10-10 15:47:07',
      callbackTime: done ? '2026-10-10 15:47:07' : null,
      finishTime: done ? '2026-10-10 15:47:08' : null,
      waitingSeconds: done ? 0 : 4838,
      resultPath: done ? '//192.168.3.111/temp/results' : null,
      errorInfo: status === 'FAILED' ? '提交失败：Connection refused: connect' : null,
      workflowInstanceId: 255 + i
    };
  });
  nodeDetailMap.value = status === 'NONE' ? {} : detail;
  await new Promise((r) => setTimeout(r, 800));
  const rows = (g.getNodes() || []).map((n: any) => ({
    name: n.getData?.()?.taskName,
    runColor: n.getData?.()?.__runStatusColor,
    bodyStroke: n.attr?.('body/stroke'),
    titleFill: n.attr?.('title/fill'),
    statusText: n.attr?.('status/text')
  }));
  // 再模拟"鼠标点中第一个节点"（选中高亮），看状态色会不会被高亮色冲掉
  const first = (g.getNodes() || [])[0];
  let selectedRow: any = null;
  if (first) {
    g.resetSelection?.();
    g.select?.(first);
    await new Promise((r) => setTimeout(r, 500));
    selectedRow = {
      name: first.getData?.()?.taskName,
      runColor: first.getData?.()?.__runStatusColor,
      bodyStroke: first.attr?.('body/stroke'),
      titleFill: first.attr?.('title/fill')
    };
    g.unselect?.(first);
  }
  // 模拟点击"节点下方那一行"→ 应该弹出节点执行详情
  let clickResult = '找不到状态文字元素';
  const statusEl = document.querySelector('.dag-node-status') as SVGElement | null;
  if (statusEl) {
    statusEl.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
    await new Promise((r) => setTimeout(r, 900));
    const dlg = document.querySelector('.el-dialog__title');
    clickResult = dlg ? `已弹出弹窗「${dlg.textContent}」` : '没有弹出弹窗';
    // 关掉弹窗，否则遮罩会挡住后面要点的按钮
    const closeBtn = Array.from(document.querySelectorAll('.el-dialog__footer button')).find((b) =>
      /关闭/.test(b.textContent || '')
    );
    (closeBtn as HTMLElement | undefined)?.click();
    await new Promise((r) => setTimeout(r, 400));
  }
  result.value =
    `把全部节点标成 ${status} 后，画布节点实际颜色：\n` +
    JSON.stringify(rows, null, 2) +
    `\n\n选中第一个节点（高亮）时它的颜色：\n` +
    JSON.stringify(selectedRow, null, 2) +
    `\n\n点击节点下方状态行：${clickResult}`;
}

/** 加载一张含逻辑节点的流程，供"双击逻辑节点 → 规则编辑器"验证 */
async function loadLogicDef() {
  dagRef.value?.graph?.clearCells?.();
  definition.value = JSON.parse(JSON.stringify(LOGIC_DEF));
  await new Promise((r) => setTimeout(r, 1500));
  const rows = dump();
  result.value =
    `已加载含逻辑节点的流程，画布 ${rows.length} 个节点：\n` +
    rows.map((r: any) => `  - ${r.taskName} [${r.taskType}]`).join('\n') +
    `\n\n接着双击「逻辑-结果路径是否存在」即可打开规则编辑器`;
}
</script>

<style scoped>
.sim-wrap {
  height: 100vh;
  display: flex;
  flex-direction: column;
}

.sim-head {
  height: 44px;
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 0 12px;
  border-bottom: 1px solid #eee;
}

.sim-head .tip {
  color: #909399;
  font-size: 12px;
}

.sim-result {
  margin: 0;
  padding: 8px 12px;
  max-height: 240px;
  overflow: auto;
  background: #f6f8fa;
  border-bottom: 1px solid #eee;
  font-size: 12px;
  line-height: 18px;
}

.sim-canvas {
  flex: 1;
  min-height: 0;
}
</style>
