<script setup lang="tsx">
import FileExtraction from '../../shared/data-extraction/index.vue';
provide('product-category-root', 'result');
</script>
<template>
  <FileExtraction />
</template>

<style lang="scss" scoped></style>
