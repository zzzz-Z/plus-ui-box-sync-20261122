<script setup lang="ts">
import Layout from '@/views/product-manage/shared/index.vue';
provide('product-category-root', 'sample_model_result');
</script>

<template>
  <Layout context="result" />
</template>
