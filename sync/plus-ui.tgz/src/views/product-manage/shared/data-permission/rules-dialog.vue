<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
import { Delete, Plus } from '@element-plus/icons-vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import type { RuleType, SecurityRule } from './state';
import { addRuleData, enabledRuleCount, hiddenCount, removeRuleData, RULE_TAG_TYPE, RULE_TYPE_LABEL, rules } from './state';

const draft = reactive({ name: '', type: 'attribute' as RuleType, expression: '' });

function onAdd() {
  const error = addRuleData({ ...draft, effect: pt('隐藏') });
  if (error) {
    ElMessage.warning(error);
    return;
  }
  draft.name = '';
  draft.expression = '';
  ElMessage.success(pt('规则已新增'));
}

function onRemove(rule: SecurityRule) {
  ElMessageBox.confirm(`确认删除规则「${rule.name}」？`, pt('删除安全规则'), { type: 'warning' })
    .then(() => {
      removeRuleData(rule);
      ElMessage.success(pt('规则已删除'));
    })
    .catch(() => {});
}
</script>

<template>
  <div class="rules-dialog">
    <div class="rules-dialog__stats">
      {{ pt('已屏蔽') }} <strong>{{ hiddenCount }}</strong> {{ pt('条记录 · 启用规则') }} <strong>{{ enabledRuleCount }}</strong> {{ pt('条') }}
    </div>

    <div class="rules-dialog__add">
      <el-input v-model="draft.name" :placeholder="pt('规则名称')" class="add-name" />
      <el-select v-model="draft.type" class="add-type">
        <el-option :label="pt('属性字段')" value="attribute" />
        <el-option :label="pt('空间范围')" value="space" />
        <el-option :label="pt('图号列表')" value="sheet" />
      </el-select>
      <el-input v-model="draft.expression" :placeholder="pt('限定条件，如 dataLevel = 内部')" class="add-expr" />
      <el-button type="primary" :icon="Plus" @click="onAdd"> {{ pt('新增') }} </el-button>
    </div>

    <div class="rules-dialog__list">
      <div v-for="rule in rules" :key="rule.id" class="rule-row">
        <el-switch v-model="rule.enabled" />
        <el-tag :type="RULE_TAG_TYPE[rule.type]" size="small">
          {{ RULE_TYPE_LABEL[rule.type] }}
        </el-tag>
        <div class="rule-row__text">
          <strong>{{ rule.name }}</strong>
          <span>{{ rule.expression }}</span>
        </div>
        <el-button link type="danger" :icon="Delete" @click="onRemove(rule)" />
      </div>
      <el-empty v-if="!rules.length" :description="pt('暂无规则')" :image-size="50" />
    </div>
  </div>
</template>

<style scoped lang="scss">
.rules-dialog__stats {
  margin-bottom: 12px;
  color: #8592a6;
  font-size: 12px;

  strong {
    color: #2563a8;
    font-size: 14px;
  }
}

.rules-dialog__add {
  display: flex;
  gap: 8px;
  margin-bottom: 12px;

  .add-name {
    flex: 1;
  }

  .add-type {
    width: 120px;
    flex: none;
  }

  .add-expr {
    flex: 1.4;
  }
}

.rules-dialog__list {
  max-height: 360px;
  overflow-y: auto;
}

.rule-row {
  display: flex;
  align-items: center;
  gap: 8px;
  min-height: 40px;
  padding: 6px 0;
  border-top: 1px solid #f1f3f6;

  &__text {
    flex: 1;
    min-width: 0;

    strong,
    span {
      display: block;
    }

    strong {
      overflow: hidden;
      color: #34445a;
      font-size: 13px;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    span {
      overflow: hidden;
      color: var(--el-text-color-secondary);
      font-size: 12px;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }
}
</style>
