<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
import { Lock, Setting, Unlock } from '@element-plus/icons-vue';
import { ElMessage } from 'element-plus';
import type { MetadataRecord } from '@/api/product-manage/types';
import RulesDialog from './rules-dialog.vue';
import { categories, clearHidden, getRows, hideSelected, isHidden, loadData, queryParams, setSelected, toggleHidden } from './state.js';

function onOpenRules() {
  createDialog({
    title: pt('访问限制规则'),
    width: '640px',
    footer: false,
    render: () => <RulesDialog />
  });
}

function onHideSelected() {
  const count = hideSelected();
  if (!count) {
    ElMessage.warning(pt('请先选择需要屏蔽的元数据记录'));
    return;
  }
  ElMessage.success(`已屏蔽 ${count} 条元数据记录`);
}

function onClearHidden() {
  clearHidden();
  ElMessage.success(pt('已解除全部元数据屏蔽'));
}

const columns: TableColumn<MetadataRecord>[] = [
  { type: 'selection', width: 46 },
  { label: pt('产品名称'), prop: 'name' },
  { label: pt('产品类别'), prop: 'category' },
  { label: pt('版本'), prop: 'version', width: 80 },
  {
    label: pt('数据级别'),
    width: 90,
    render: ({ row }) => (
      <el-tag type={row.dataLevel === '内部' ? 'warning' : 'success'} size="small">
        {row.dataLevel}
      </el-tag>
    )
  },
  { label: pt('行政区划'), prop: 'region', width: 120 },
  { label: pt('所属元数据表'), prop: 'tableName', minWidth: 150 },
  {
    label: pt('访问状态'),
    width: 100,
    render: ({ row }) => (
      <el-tag type={isHidden(row.id) ? 'danger' : 'success'} size="small">
        {isHidden(row.id) ? pt('已屏蔽') : pt('可访问')}
      </el-tag>
    )
  },
  {
    action: true,
    label: pt('操作'),
    fixed: 'right',
    render: ({ row }) => (
      <el-button
        link
        type={isHidden(row.id) ? 'success' : 'danger'}
        icon={isHidden(row.id) ? Unlock : Lock}
        title={isHidden(row.id) ? pt('解除') : pt('屏蔽')}
        onClick={() => toggleHidden(row.id)}
      />
    )
  }
];

onMounted(loadData);
</script>

<template>
  <Table :columns="columns" :request="getRows" :query-params="queryParams" @selection-change="setSelected">
    <template #search>
      <el-input v-model="queryParams.keyword" :label="pt('关键字')" :placeholder="pt('名称/描述/所属表')" clearable />
      <el-select v-model="queryParams.category" :label="pt('产品类别')" :placeholder="pt('全部类别')" clearable>
        <el-option v-for="category in categories" :key="category" :label="category" :value="category" />
      </el-select>
      <el-select v-model="queryParams.dataLevel" :label="pt('数据级别')" :placeholder="pt('全部级别')" clearable>
        <el-option :label="pt('公开')" value="公开" />
        <el-option :label="pt('内部')" value="内部" />
      </el-select>
    </template>
    <template #action>
      <el-button type="primary" :icon="Setting" @click="onOpenRules"> 访问限制规则 </el-button>
      <el-button type="danger" :icon="Lock" @click="onHideSelected"> 屏蔽所选 </el-button>
      <el-button type="primary" :icon="Unlock" @click="onClearHidden"> 解除全部屏蔽 </el-button>
    </template>
  </Table>
</template>
