import { computed, reactive } from 'vue';
import { useProductRecords } from '../store';
import { createSecurityStore, RULE_TAG_TYPE, RULE_TYPE_LABEL } from '@/composables/use-security-store';
import type { RuleDraft, SecurityRule, SecurityRuleType } from '@/composables/use-security-store';

/**
 * 元数据安全管理共享状态（初级线）
 *
 * 业务相关的部分保留在本文件（records / queryParams / visibleRecords 等）；
 * 与安全屏蔽规则相关的通用逻辑（hiddenIds / rules / toggle / 增删改）已抽到
 * @/composables/use-security-store，两条产品线共用。
 */

export type RuleType = SecurityRuleType;
export type { RuleDraft, SecurityRule };
export { RULE_TAG_TYPE, RULE_TYPE_LABEL };

// 默认规则（面板首次加载时的种子）
const DEFAULT_RULES: SecurityRule[] = [
  {
    id: 1,
    name: '重要区域元数据默认屏蔽',
    type: 'space',
    expression: '北京市重点保护区',
    effect: '隐藏',
    enabled: true,
    updatedAt: '2026-09-08 10:30'
  },
  {
    id: 2,
    name: '内部元数据访问限制',
    type: 'attribute',
    expression: 'dataLevel = 内部',
    effect: '隐藏',
    enabled: true,
    updatedAt: '2026-09-07 16:20'
  }
];

// 屏蔽规则状态（key 前缀 'mdm.security'，与原有 localStorage key 保持一致）
const { hiddenIds, rules, selectedIds, isHidden, toggleHidden, setSelected, hideSelected, clearHidden, addRuleData, removeRuleData } =
  createSecurityStore('mdm.security', DEFAULT_RULES);

export { addRuleData, clearHidden, hiddenIds, hideSelected, isHidden, removeRuleData, rules, selectedIds, setSelected, toggleHidden };

// ---------- 业务侧：records / 查询条件 / 派生视图 ----------

const { records, loading, load } = useProductRecords();
export { loading, records };

export const queryParams = reactive({ keyword: '', category: '', dataLevel: '' });

export const categories = computed(() => [...new Set(records.value.map((record) => record.category))]);

/** 按查询条件过滤后的可见记录（地图与列表共用） */
export const visibleRecords = computed(() =>
  records.value.filter((record) => {
    const text = String(queryParams.keyword || '').toLowerCase();
    return (
      (!text || `${record.name}${record.description}${record.tableName}`.toLowerCase().includes(text)) &&
      (!queryParams.category || record.category === queryParams.category) &&
      (!queryParams.dataLevel || record.dataLevel === queryParams.dataLevel)
    );
  })
);

export const hiddenCount = computed(() => hiddenIds.value.length);
export const enabledRuleCount = computed(() => rules.value.filter((item) => item.enabled).length);

export function loadData() {
  return load();
}

export async function getRows() {
  await load();
  return {
    code: 0,
    data: { items: visibleRecords.value, total: visibleRecords.value.length }
  };
}
