/**
 * 数据资产报告 docx 渲染。
 *
 * 以模板 docx 为底，用 PizZip 读写 word/document.xml：模板里的〔xxx〕是「待填字段」。
 * 只替换语义全局唯一的占位符——同名占位符（如「系统生成」出现十余次）语义各不相同，
 * 用统一值全量替换会把不同字段错填成同一个值，属内容设计决策，须人工定义映射后再扩展。
 */
import PizZip from 'pizzip';

/** 报告渲染数据源：字段名与模板占位符的语义一一对应 */
export interface ReportRenderData {
  /** 报告类型：产品资产汇总 / 单类产品资产报告 */
  reportType: string;
  /** 报告对象描述 */
  reportScope: string;
  /** 统计范围（区域/图幅/时间范围/版本条件） */
  scopeCondition: string;
  /** 数据来源 */
  dataSource: string;
  /** 编制单位 */
  orgName: string;
  /** 导出格式 */
  exportFormat: string;
  /** 产品类别列表 */
  productCategory: string;
  /** 空间范围描述 */
  spatialCondition: string;
  /** 版本与时间条件 */
  versionCondition: string;
  /** 纳入规则 */
  includeRule: string;
  /** 统计截止时间 */
  statDeadline: string;
}

/**
 * 模板占位符（〔xxx〕原文） → 数据字段名。
 * 仅收录在模板里全局唯一、语义明确的占位符；同名占位符保留原样待后续扩展。
 */
const PLACEHOLDER_MAP: Record<string, keyof ReportRenderData> = {
  '产品资产汇总 / 单类产品资产报告': 'reportType',
  '产品类别、产品名称或数据集范围': 'reportScope',
  '区域/图幅/时间范围/版本条件': 'scopeCondition',
  '系统登记来源或业务系统名称': 'dataSource',
  单位名称: 'orgName',
  'Doc/Docx/WPS/PDF/HTML': 'exportFormat',
  '分类要素初级产品 / 分类要素属性初级产品 / 地质要素初级产品 / lh融合初级产品 / 协同检核初级产品': 'productCategory',
  '行政区域、图幅或空间几何条件': 'spatialCondition',
  '版本选择、数据时相或任务时间范围': 'versionCondition',
  '全部符合条件的数据集 / 用户勾选数据集': 'includeRule',
  统计截止时间: 'statDeadline'
};

/** XML 转义：占位符替换为数据值后必须转义，否则 <、& 会破坏 XML 结构 */
function escapeXml(text: string): string {
  return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');
}

/**
 * 用真实数据渲染 docx 模板。
 * @param templateUrl 模板 URL（相对页面 BASE_URL 的路径）
 * @param data 渲染数据
 * @returns 生成的 docx Blob
 */
export async function renderReportDocx(templateUrl: string, data: ReportRenderData): Promise<Blob> {
  const response = await fetch(encodeURI(templateUrl));
  if (!response.ok) throw new Error('HTTP ' + response.status);
  const buffer = await response.arrayBuffer();
  const zip = new PizZip(buffer);

  const docFile = zip.file('word/document.xml');
  if (!docFile) throw new Error('模板缺少 word/document.xml');
  let xml = docFile.asText();

  Object.entries(PLACEHOLDER_MAP).forEach(([placeholder, field]) => {
    const value = escapeXml(String(data[field] ?? ''));
    if (!value) return;
    xml = xml.split('〔' + placeholder + '〕').join(value);
  });

  zip.file('word/document.xml', xml);
  return zip.generate({ type: 'blob', mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' }) as Blob;
}
