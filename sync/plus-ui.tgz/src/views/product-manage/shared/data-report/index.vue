<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
import { Document, Download, Plus } from '@element-plus/icons-vue';
import { ElMessage } from 'element-plus';
import { getAllMetadataRecords } from '@/api/product-manage/adapter/records';
import { buildReportRows } from '@/api/product-manage/local/derived-data';
import type { ReportRow } from '@/api/product-manage/types';
import { PRODUCT_TYPE_OPTIONS, PRODUCT_TYPES } from '@/api/product-manage/types';
import { useProductRecords } from '../store';
import { renderReportDocx, type ReportRenderData } from './render';

const { records, load } = useProductRecords();

/**
 * 导出格式（G-06）：当前只有 DOCX 具备真实渲染能力（render.ts 基于 docxtemplater 生成 word/document.xml），
 * WPS / XLS / PDF / HTML 无对应生成库，勾选后也只会拿到一个 docx 文件，是「导出有问题」的根因。
 * 收敛为唯一可交付格式；后续接入其它格式时在此扩 FORMAT_EXT 并实现对应渲染器即可。
 */
const formats = ['Docx'];
/** 报告格式 → 下载扩展名；未登记的格式回退 docx，保证文件内容与扩展名一致 */
const FORMAT_EXT: Record<string, string> = { Docx: 'docx' };
function formatExt(format: string): string {
  return FORMAT_EXT[format] ?? 'docx';
}
/** 报告内容可选章节：key 对应 model 上的布尔开关 */
type ContentKey = 'includeCoverage' | 'includeMetadata' | 'includeQuality' | 'includeChanges';
const CONTENT_ITEMS: Array<{ key: ContentKey; title: string }> = [
  { key: 'includeCoverage', title: pt('覆盖图') },
  { key: 'includeMetadata', title: pt('元数据概况') },
  { key: 'includeQuality', title: pt('质量统计') },
  { key: 'includeChanges', title: pt('版本变更') }
];
const DAY_MS = 24 * 60 * 60 * 1000;
const dateShortcuts = [
  { text: pt('近 7 天'), value: () => [new Date(Date.now() - 6 * DAY_MS), new Date()] as [Date, Date] },
  { text: pt('近 30 天'), value: () => [new Date(Date.now() - 29 * DAY_MS), new Date()] as [Date, Date] },
  {
    text: pt('本月'),
    value: () => {
      const now = new Date();
      return [new Date(now.getFullYear(), now.getMonth(), 1), now] as [Date, Date];
    }
  }
];
/** 历史列表上限：种子报告 + 反复生成会让列表无界增长，超出即裁剪 */
const MAX_HISTORY = 5;
const model = reactive({
  name: '分类要素初级产品数据资产报告',
  products: [...PRODUCT_TYPES] as string[],
  dateRange: ['2026-08-01', '2026-09-08'] as string[],
  format: 'Docx',
  includeCoverage: true,
  includeMetadata: true,
  includeQuality: true,
  includeChanges: false
});
const reports = reactive<ReportRow[]>([]);
const totalRecords = computed(() => records.value.length);

/** 窄屏把 label 移到控件上方，避免 6 字 label 挤压控件可用宽度 */
const { width: viewportWidth } = useWindowSize();
const isNarrow = computed(() => viewportWidth.value < 760);
const labelPosition = computed(() => (isNarrow.value ? 'top' : 'right'));
const labelWidth = computed(() => (isNarrow.value ? 'auto' : '96px'));

const allProductsSelected = computed(() => model.products.length === PRODUCT_TYPE_OPTIONS.length);
const selectedContentCount = computed(() => CONTENT_ITEMS.filter((item) => model[item.key]).length);

function toggleAllProducts() {
  model.products = allProductsSelected.value ? [] : PRODUCT_TYPE_OPTIONS.map((option) => option.value);
}

function resetConfig() {
  model.name = '分类要素初级产品数据资产报告';
  model.products = [...PRODUCT_TYPES];
  model.dateRange = ['2026-08-01', '2026-09-08'];
  model.format = 'Docx';
  model.includeCoverage = true;
  model.includeMetadata = true;
  model.includeQuality = true;
  model.includeChanges = false;
}

const reportColumns: TableColumn<ReportRow>[] = [
  { label: pt('报告名称'), prop: 'name', minWidth: 260 },
  { label: pt('产品范围'), prop: 'products', minWidth: 180 },
  { label: pt('格式'), prop: 'format', width: 90 },
  { label: pt('生成时间'), prop: 'createdAt', width: 180 },
  {
    label: pt('状态'),
    width: 110,
    render: ({ row }) => (
      /* effect="dark"：与设计稿一致，已完成为深绿实底白字，生成中为深蓝实底白字 */
      <el-tag type={row.status === '已生成' ? 'success' : 'primary'} effect="dark" round>
        {row.status === '已生成' ? pt('已完成') : row.status}
      </el-tag>
    )
  },
  {
    action: true,
    label: pt('操作'),
    width: 110,
    render: ({ row }) => (
      <el-button link type="primary" icon={Download} disabled={row.status !== '已生成'} onClick={() => downloadReport(row)}>
        下载
      </el-button>
    )
  }
];

function generateReport() {
  if (!model.name.trim() || !model.products.length) {
    ElMessage.error(pt('请填写报告名称并至少选择一种产品'));
    return;
  }
  if (!selectedContentCount.value) {
    ElMessage.warning(pt('请至少选择一项报告内容'));
    return;
  }
  const report: ReportRow = {
    id: Date.now(),
    name: model.name,
    products: model.products.length === PRODUCT_TYPES.length ? pt('9 类产品') : model.products.join('、'),
    format: model.format,
    createdAt: new Date().toLocaleString('zh-CN'),
    status: '生成中'
  };
  reports.unshift(report);
  const created = reports[0];
  if (reports.length > MAX_HISTORY) reports.splice(MAX_HISTORY);
  setTimeout(() => {
    created.status = '已生成';
    ElMessage.success(`${model.format} 数据资产报告已生成`);
  }, 900);
}

/**
 * 报告模板映射：单类产品报告用专用模板，汇总报告用通用模板。
 * 模板为真 docx 原件（public/templates），下载时以二进制流交付。
 */
/**
 * 拼接静态资源 URL。
 * dev 环境的 VITE_APP_CONTEXT_PATH 是 '/ZHGL'（无尾斜杠），
 * 直接拼 'templates/x.docx' 会得到 '/ZHGLtemplates/x.docx' 从而 404。
 */
function resolveAssetUrl(relativePath: string): string {
  const base = import.meta.env.BASE_URL || '/';
  const normalized = base.endsWith('/') ? base : base + '/';
  return normalized + relativePath;
}

const REPORT_TEMPLATES = {
  single: pt('templates/分类要素初级产品数据资产报告.docx'),
  summary: pt('templates/综合管理系统数据资产报告模板.docx')
};

/**
 * 覆盖类别仅一类时套用「分类要素初级产品」专用模板（单类产品报告），
 * 其余场景（汇总、批次、多类）用通用模板。
 */
function pickTemplate(row: any): string {
  const categories = row.categories || [];
  if (categories.length === 1) return REPORT_TEMPLATES.single;
  return REPORT_TEMPLATES.summary;
}

/** 以当前 records 与报告行构造模板渲染数据；缺省字段用简短说明占位 */
function buildRenderData(row: any): ReportRenderData {
  const categories: string[] = row.categories || [];
  const productsInScope = categories.length ? categories.join('、') : row.products;
  const now = new Date().toLocaleString('zh-CN');
  const dateRange = model.dateRange || [];
  return {
    reportType: categories.length === 1 ? pt('单类产品资产报告') : pt('产品资产汇总'),
    reportScope: productsInScope,
    scopeCondition: dateRange.length === 2 ? dateRange.join(pt(' 至 ')) : pt('全部数据范围'),
    dataSource: pt('综合管理系统'),
    orgName: pt('503研究所'),
    exportFormat: row.format,
    productCategory: productsInScope,
    spatialCondition: pt('系统登记的空间范围'),
    versionCondition: dateRange.length === 2 ? dateRange.join(pt(' 至 ')) : pt('当前有效版本'),
    includeRule: categories.length === 1 ? pt('用户勾选的数据集') : pt('全部符合条件的数据集'),
    statDeadline: now
  };
}

/** 触发浏览器下载；延迟释放对象 URL，避免大文件尚未开始下载就被同步 revoke 取消 */
function triggerDownload(blob: Blob, filename: string) {
  if (!blob.size) throw new Error(pt('生成的文件为空（0 字节）'));
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  window.setTimeout(() => URL.revokeObjectURL(url), 4000);
}

/**
 * 下载报告：优先用模板渲染真实数据；渲染失败时降级为「原样下发模板」，
 * 避免占位符失配导致用户完全拿不到文件。
 */
async function downloadReport(row: any) {
  const templateUrl = resolveAssetUrl(pickTemplate(row));
  try {
    const blob = await renderReportDocx(templateUrl, buildRenderData(row));
    if (!blob.size) throw new Error(pt('渲染结果为空（0 字节）'));
    triggerDownload(blob, `${row.name}.${formatExt(row.format)}`);
    ElMessage.success(`已生成报告：${row.name}（${Math.round(blob.size / 1024)} KB）`);
  } catch (error: any) {
    ElMessage.warning(`模板渲染失败，改为下发原始模板：${error?.message ?? error}`);
    try {
      const response = await fetch(encodeURI(templateUrl));
      if (!response.ok) throw new Error('HTTP ' + response.status);
      triggerDownload(await response.blob(), `${row.name}.${formatExt(row.format)}`);
    } catch (fallbackError: any) {
      ElMessage.error(`下载失败：${fallbackError?.message ?? fallbackError}`);
    }
  }
}

function getReports() {
  return Promise.resolve({ code: 0, data: { items: reports, total: reports.length } });
}

/** 覆盖图：按 9 类产品各聚合一块 bbox（该类记录的 min/max 范围），保持预览清爽 */
const coverageBlocks = computed(() =>
  PRODUCT_TYPES.flatMap((category) => {
    const list = records.value.filter((record) => record.category === category);
    if (!list.length) return [];
    return [
      {
        category,
        bbox: [
          Math.min(...list.map((record) => record.bbox[0])),
          Math.min(...list.map((record) => record.bbox[1])),
          Math.max(...list.map((record) => record.bbox[2])),
          Math.max(...list.map((record) => record.bbox[3]))
        ] as [number, number, number, number]
      }
    ];
  })
);

/** 覆盖图全局范围：把各类 bbox 归一化到预览框 */
const coverageExtent = computed(() => {
  const blocks = coverageBlocks.value;
  if (!blocks.length) return { minLng: 116, minLat: 39, maxLng: 117, maxLat: 40 };
  return {
    minLng: Math.min(...blocks.map((block) => block.bbox[0])),
    minLat: Math.min(...blocks.map((block) => block.bbox[1])),
    maxLng: Math.max(...blocks.map((block) => block.bbox[2])),
    maxLat: Math.max(...blocks.map((block) => block.bbox[3]))
  };
});

function coverageStyle(block: { bbox: [number, number, number, number] }) {
  const [minLng, minLat, maxLng, maxLat] = block.bbox;
  const { minLng: gMinLng, minLat: gMinLat, maxLng: gMaxLng, maxLat: gMaxLat } = coverageExtent.value;
  const spanLng = gMaxLng - gMinLng || 1;
  const spanLat = gMaxLat - gMinLat || 1;
  return {
    left: `${((minLng - gMinLng) / spanLng) * 100}%`,
    top: `${((gMaxLat - maxLat) / spanLat) * 100}%`,
    width: `${((maxLng - minLng) / spanLng) * 100}%`,
    height: `${((maxLat - minLat) / spanLat) * 100}%`
  };
}

onMounted(async () => {
  await load();
  const res: any = await getAllMetadataRecords();
  reports.push(...buildReportRows(res?.data ?? []).slice(0, MAX_HISTORY));
});
</script>

<template>
  <div class="report-page">
    <!-- <div class="page-toolbar">
      <p class="page-toolbar__desc">{{ pt('汇总分类要素初级产品覆盖范围、元数据和质量状态') }}</p>
      <div class="page-toolbar__btns">
        <el-button @click="resetConfig">{{ pt('重置') }}</el-button>
        <el-button type="primary" :icon="Document" @click="generateReport">{{ pt('生成数据资产报告') }}</el-button>
      </div>
    </div> -->

    <div class="report-grid">
      <section class="panel config-panel">
        <h3 class="panel-title">
          <span>{{ pt('报告配置') }}</span>
          <el-button type="primary" link :icon="Document" @click="generateReport">{{ pt('生成数据资产报告') }}</el-button>
        </h3>
        <el-form class="config-form" :model="model" :label-width="labelWidth" :label-position="labelPosition" @submit.prevent>
          <el-form-item :label="pt('报告名称')" required>
            <el-input v-model="model.name" maxlength="50" :placeholder="pt('请输入报告名称')" />
          </el-form-item>

          <el-form-item :label="pt('产品范围')" required>
            <el-select
              v-model="model.products"
              multiple
              collapse-tags
              collapse-tags-tooltip
              :max-collapse-tags="2"
              :placeholder="pt('请选择产品范围')"
            >
              <template #header>
                <div class="select-header" @click.stop>
                  <span>已选 {{ model.products.length }} / {{ PRODUCT_TYPE_OPTIONS.length }} 类</span>
                  <el-button link type="primary" @click.stop="toggleAllProducts">{{ allProductsSelected ? '清空' : '全选' }}</el-button>
                </div>
              </template>
              <el-option v-for="item in PRODUCT_TYPE_OPTIONS" :key="item.value" :label="item.label" :value="item.value" />
            </el-select>
          </el-form-item>

          <el-form-item label="数据时间范围">
            <el-date-picker
              v-model="model.dateRange"
              type="daterange"
              value-format="YYYY-MM-DD"
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              :shortcuts="dateShortcuts"
              unlink-panels
            />
          </el-form-item>

          <el-form-item label="输入格式">
            <el-radio-group v-model="model.format">
              <el-radio-button v-for="format in formats" :key="format" :value="format">{{ format }}</el-radio-button>
            </el-radio-group>
          </el-form-item>

          <el-form-item label="报告内容" required>
            <el-checkbox v-for="item in CONTENT_ITEMS" :key="item.key" v-model="model[item.key]">{{ item.title }}</el-checkbox>
          </el-form-item>
        </el-form>
      </section>

      <section class="panel preview-panel">
        <h3 class="panel-title">数据覆盖图预览</h3>
        <div class="coverage-preview">
          <div class="coverage-grid" />
          <div v-for="block in coverageBlocks" :key="block.category" class="coverage-block" :style="coverageStyle(block)">
            <i />{{ block.category }}
          </div>
          <div class="coverage-legend">
            <span v-for="type in PRODUCT_TYPES.slice(0, 5)" :key="type"><i />{{ type }}</span>
          </div>
        </div>
        <div class="metric-grid">
          <div class="metric-card">
            <i class="metric-card__icon metric-card__icon--category" />
            <i class="metric-card__divider" />
            <div class="metric-card__body">
              <span class="metric-card__label">产品类别</span>
              <p class="metric-card__value"><strong>9</strong><small>种初级产品</small></p>
            </div>
          </div>
          <div class="metric-card">
            <i class="metric-card__icon metric-card__icon--metadata" />
            <i class="metric-card__divider" />
            <div class="metric-card__body">
              <span class="metric-card__label">元数据</span>
              <p class="metric-card__value">
                <strong>{{ totalRecords }}</strong
                ><small>条有效记录</small>
              </p>
            </div>
          </div>
          <div class="metric-card">
            <i class="metric-card__icon metric-card__icon--area" />
            <i class="metric-card__divider" />
            <div class="metric-card__body">
              <span class="metric-card__label">覆盖面积</span>
              <p class="metric-card__value"><strong>1,284</strong><small>平方公里</small></p>
            </div>
          </div>
          <div class="metric-card">
            <i class="metric-card__icon metric-card__icon--version" />
            <i class="metric-card__divider" />
            <div class="metric-card__body">
              <span class="metric-card__label">数据版本</span>
              <p class="metric-card__value"><strong>18</strong><small>个版本</small></p>
            </div>
          </div>
        </div>
      </section>
    </div>

    <section class="panel history-panel">
      <div class="history-head">
        <h3 class="panel-title">报告生成记录</h3>
        <el-button class="history-head__btn" link type="primary" :icon="Plus" @click="generateReport">再次生成</el-button>
      </div>
      <Table :columns="reportColumns" :request="getReports" :pagination="false" auto-height />
    </section>
  </div>
</template>

<style scoped lang="scss">
:deep(.i-table .el-card__body) {
  padding: 0 !important;
}

.report-page {
  height: 100%;
  overflow: auto;
  // padding: 10px;
  background: #f5f7fa;
}

.page-toolbar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  margin-bottom: 10px;
}
.page-toolbar__desc {
  margin: 0;
  color: #8a94a6;
  font-size: 12px;
}
.page-toolbar__btns {
  display: flex;
  gap: 8px;
}

.report-grid {
  display: grid;
  /* minmax(0, …)：允许子项收缩，避免长内容把栅格撑出横向滚动条；
     align-items 用默认 stretch，让左右两栏等高、底边对齐 */
  grid-template-columns: minmax(0, 0.86fr) minmax(0, 1.14fr);
  gap: 10px;
}

.panel {
  padding: 12px 14px;
  background: var(--el-bg-color);
  border: 1px solid #e6e9f0;
  border-radius: 4px;
}

/* 面板标题栏：贴面板顶部通栏，用设计稿「卡片顶部背景」切图（自带底部蓝色分隔线）。
   负 margin 把标题条拉到面板 padding 之外，与左右边框齐平 */
.panel-title {
  display: flex;
  align-items: center;
  height: 40px;
  margin: -12px -14px 12px;
  padding: 0 14px;
  color: #1c2d4c;
  font-size: 14px;
  font-weight: 600;
  line-height: 1.4;
  justify-content: space-between;
  background: url('@/assets/images/卡片顶部背景.png') no-repeat center / 100% 100%;
}
/* 历史面板标题行：按钮与标题共用同一条背景，标题自身不再重复挂背景 */
.history-head {
  display: flex;
  align-items: center;
  height: 40px;
  margin: -12px -14px 10px;
  padding: 0 14px;
  background: url('@/assets/images/卡片顶部背景.png') no-repeat center / 100% 100%;
}
.history-head .panel-title {
  height: auto;
  margin: 0;
  padding: 0;
  background: none;
}
.history-head__btn {
  margin-left: auto;
}

/* 预览面板与配置面板同高：等高后让覆盖图吃掉多余高度，指标卡始终贴底 */
.preview-panel,
.config-panel {
  display: flex;
  flex-direction: column;
}

/* ---------- 表格式表单：label 右对齐 + 行间分隔线 ---------- */
.config-form {
  display: flex;
  flex: 1 1 auto;
  flex-direction: column;
  width: 100%;
  border-top: 1px solid #eff1f5;
  padding-top: 2px;
}
.config-form :deep(.el-form-item) {
  align-items: center;
  margin-bottom: 0;
  padding: 9px 0;
  border-bottom: 1px solid #eff1f5;
}
.config-form :deep(.el-form-item:last-child) {
  border-bottom: 0;
}
.config-form :deep(.el-form-item__label) {
  /* nowrap：6 字 label（数据时间范围 ≈78px）在固定 label-width 下必须单行，
     否则换行的第二行会漏到下一行表单项上面 */
  padding-right: 10px;
  color: #5a6478;
  font-size: 13px;
  line-height: 32px;
  white-space: nowrap;
}
/* 关键：flex 子项默认 min-width:auto，多选标签会把控件顶宽 → 横向溢出 */
.config-form :deep(.el-form-item__content) {
  min-width: 0;
  line-height: normal;
}
.config-form :deep(.el-select),
.config-form :deep(.el-date-editor),
.config-form :deep(.el-input) {
  width: 100%;
  min-width: 0;
}
.config-form :deep(.el-select__selection) {
  min-width: 0;
}
.config-form :deep(.el-radio-group) {
  flex-wrap: wrap;
}
.config-form :deep(.el-radio-button__inner) {
  padding: 8px 14px;
  border-radius: 0;
}
.config-form :deep(.el-checkbox) {
  margin-right: 18px;
}
.config-form :deep(.el-checkbox:last-child) {
  margin-right: 0;
}

.select-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 4px 12px 6px;
  color: #8a94a6;
  font-size: 12px;
}

/* ---------- 覆盖图预览 ---------- */
.coverage-preview {
  position: relative;
  flex: 1 1 auto;
  min-height: 190px;
  overflow: hidden;
  border-radius: 3px;
  background: #dfeaf1;
}
.coverage-grid {
  position: absolute;
  inset: 0;
  opacity: 0.55;
  background:
    linear-gradient(32deg, transparent 48%, #b5ccd2 49%, #b5ccd2 50%, transparent 51%),
    linear-gradient(118deg, transparent 48%, #b5ccd2 49%, #b5ccd2 50%, transparent 51%);
  background-size:
    120px 100px,
    160px 120px;
}
.coverage-block {
  position: absolute;
  z-index: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  min-width: 45px;
  min-height: 25px;
  padding: 3px;
  border: 2px solid #3e75c5;
  color: #26384e;
  background: #ffffffaa;
  font-size: 10px;
}
.coverage-block i {
  position: absolute;
  inset: -2px;
  background: #3e75c533;
}
.coverage-block::after {
  content: '';
  position: absolute;
  inset: 0;
  border: 1px solid #fff;
}
.coverage-legend {
  position: absolute;
  right: 8px;
  bottom: 8px;
  z-index: 2;
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  padding: 5px 7px;
  border-radius: 3px;
  background: #fffffff0;
  font-size: 10px;
}
.coverage-legend span {
  display: flex;
  align-items: center;
  gap: 3px;
}
.coverage-legend i {
  width: 7px;
  height: 7px;
  background: #3e75c5;
}

/* ---------- 指标卡：设计稿切图（统计背景框 180x83 + 圆形图标 46x47 + 分割线 72x2） ---------- */
.metric-grid {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 10px;
  margin-top: 10px;
}
.metric-card {
  display: flex;
  align-items: center;
  gap: 10px;
  height: 83px;
  padding: 0 12px;
  background: url('@/assets/images/统计背景框.png') no-repeat center / 100% 100%;
}
.metric-card__icon {
  flex-shrink: 0;
  width: 46px;
  height: 47px;
}
.metric-card__icon--category {
  background: url('@/assets/images/产品类别.png') no-repeat center / 100% 100%;
}
.metric-card__icon--metadata {
  background: url('@/assets/images/元数据.png') no-repeat center / 100% 100%;
}
.metric-card__icon--area {
  background: url('@/assets/images/覆盖面积.png') no-repeat center / 100% 100%;
}
.metric-card__icon--version {
  background: url('@/assets/images/数据版本.png') no-repeat center / 100% 100%;
}
.metric-card__divider {
  flex-shrink: 0;
  width: 2px;
  height: 56px;
  background: url('@/assets/images/分割线.png') no-repeat center / 100% 100%;
}
.metric-card__body {
  min-width: 0;
}
.metric-card__label {
  display: block;
  color: #6b7688;
  font-size: 12px;
  line-height: 1.2;
}
.metric-card__value {
  margin: 4px 0 0;
  color: #2d68e8;
  line-height: 1.2;
  white-space: nowrap;
}
.metric-card__value strong {
  font-size: 22px;
  font-weight: 600;
}
.metric-card__value small {
  margin-left: 2px;
  color: #8a94a6;
  font-size: 11px;
}

/* 暗色模式：浅色底图不挂，退回纯色面板（与 PageHeader 的降级策略一致） */
html.dark .metric-card,
html.dark .panel-title,
html.dark .history-head {
  background: var(--el-bg-color-overlay);
  border-bottom: 1px solid var(--el-border-color);
}
html.dark .metric-card {
  border: 1px solid var(--el-border-color);
  border-bottom: 0;
}

/* ---------- 历史记录 ---------- */

.history-panel :deep(.el-table th.el-table__cell) {
  background: #f7f9fc;
  color: #5a6478;
  font-weight: 500;
}
.history-panel :deep(.el-table td.el-table__cell),
.history-panel :deep(.el-table th.el-table__cell) {
  padding: 6px 0;
}
.history-panel :deep(.el-table__inner-wrapper::before) {
  display: none;
}

@media (max-width: 1180px) {
  .report-grid {
    grid-template-columns: minmax(0, 1fr);
  }
}

/* 极窄屏：4 个指标卡挤不下，退化为 2 列 */
@media (max-width: 640px) {
  .metric-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  .config-form :deep(.el-checkbox) {
    margin-right: 12px;
  }
}
</style>
