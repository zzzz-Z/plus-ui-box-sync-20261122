<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
/**
 * 记录详情面板：头部（标题 + 关闭）+ 属性内容。
 *
 * WHY 全项目一份：元数据浏览 / 元数据编辑两张属性表的「记录详情」，与地图要素点击详情，
 * 三个入口共用布局右侧同一占位列（宿主契约见 record-detail-host.ts），
 * 头部、关闭按钮与属性内容（AttributeRowDialog）收口到这里，避免某条通道还停在旧悬浮抽屉。
 *
 * 使用位置：布局（shared/index.vue）在宿主有内容时统一渲染；消费方只调 showRecordDetail 写内容。
 * 布局每次重新打开都会换 key 重挂本面板 —— AttributeRowDialog 的 enrich 只在 onMounted 跑一次，
 * 重挂才能保证切换要素 / 换行后补全的是当前内容。
 */
import { Close } from '@element-plus/icons-vue';
import AttributeRowDialog from './attribute-row-dialog.vue';
import type { RecordDetailContent } from './record-detail-host';

defineOptions({ name: 'RecordDetailPanel' });

const props = defineProps<{ content: RecordDetailContent }>();

const emit = defineEmits<{ close: [] }>();
</script>

<template>
  <div class="record-detail">
    <div class="record-detail__head">
      <span class="record-detail__title">{{ pt('记录详情') }}</span>
      <el-button link :icon="Close" :title="pt('关闭详情')" @click="emit('close')" />
    </div>
    <div class="record-detail__body">
      <AttributeRowDialog :row="props.content.row" :columns="props.content.columns" :tags="props.content.tags" :enrich="props.content.enrich" />
    </div>
  </div>
</template>

<style scoped lang="scss">
.record-detail {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
}

.record-detail__head {
  display: flex;
  flex: 0 0 auto;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  padding: 10px 12px;
  border-bottom: 1px solid var(--el-border-color-lighter);
}

.record-detail__title {
  font-size: 14px;
  font-weight: 600;
  color: var(--el-text-color-primary);
}

.record-detail__body {
  flex: 1 1 0;
  min-height: 0;
  overflow: auto;
  padding: 12px;
}
</style>
