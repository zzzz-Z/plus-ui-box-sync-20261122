<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
import { computed, ref } from 'vue';
import { ElMessage } from 'element-plus';
import { Sort } from '@element-plus/icons-vue';
import {
  compareDataVersions,
  type DataVersionCompareResult,
  type DataVersionFile,
  type DataVersionLogItem
} from '@/api/product-manage/platform/data-versions';

const props = defineProps<{
  resourceUid: string;
  versions: DataVersionLogItem[];
  initialFromUid?: string;
  initialToUid?: string;
}>();

const emit = defineEmits<{
  (e: 'close'): void;
}>();

interface CompareFileRow {
  path: string;
  ext: string;
  statusType: '' | 'success' | 'warning' | 'danger' | 'info';
  group: string;
}

const fromUid = ref(props.initialFromUid ?? '');
const toUid = ref(props.initialToUid ?? '');
const loading = ref(false);
const result = ref<DataVersionCompareResult | null>(null);

function versionLabel(it: DataVersionLogItem): string {
  const name = String(it.name ?? it.displayName ?? '');
  return `v${it.versionNo ?? '—'}${name ? ` ${name}` : ''}`;
}

function statusTypeOf(status: string): CompareFileRow['statusType'] {
  const s = String(status ?? '').toLowerCase();
  if (/(add|new|create|added|新增|添加)/.test(s)) return 'success';
  if (/(del|remove|delete|removed|删除|移除)/.test(s)) return 'danger';
  if (/(mod|update|edit|change|changed|modify|修改|更新)/.test(s)) return 'warning';
  return 'info';
}

function toFileRow(f: DataVersionFile, forceStatus?: string): Omit<CompareFileRow, 'group'> {
  const path = String(f.relativePath ?? f.path ?? f.name ?? '');
  const dot = path.lastIndexOf('.');
  return {
    path,
    ext: dot > 0 ? path.slice(dot) : '',
    statusType: statusTypeOf(String(forceStatus ?? f.status ?? ''))
  };
}

const resultFileRows = computed<CompareFileRow[]>(() => {
  const fc = result.value?.fileChanges ?? {};
  return [
    ...(fc.added ?? []).map((f) => ({ ...toFileRow(f, 'added'), group: pt('新增') })),
    ...(fc.changed ?? []).map((f) => ({ ...toFileRow(f, 'changed'), group: pt('修改') })),
    ...(fc.removed ?? []).map((f) => ({ ...toFileRow(f, 'removed'), group: pt('删除') }))
  ];
});

function sideLabel(side: 'from' | 'to'): string {
  const v = result.value?.[side];
  return v?.versionNo != null ? `v${v.versionNo}` : '—';
}

async function doCompare() {
  if (!props.resourceUid || !fromUid.value || !toUid.value) {
    ElMessage.warning(pt('请选择要比较的两个版本'));
    return;
  }
  loading.value = true;
  try {
    const res = await compareDataVersions(props.resourceUid, fromUid.value, toUid.value);
    result.value = res?.data ?? null;
  } catch {
    result.value = null;
    ElMessage.error(pt('版本比较失败，请稍后重试'));
  } finally {
    loading.value = false;
  }
}

defineExpose({ doCompare });
</script>

<template>
  <div class="cp">
    <div class="cp-picker">
      <div class="cp-picker__item">
        <span class="cp-picker__label">{{ pt('起始版本') }}</span>
        <el-select v-model="fromUid" :placeholder="pt('选择起始版本')" filterable>
          <el-option v-for="it in versions" :key="it.versionUid" :label="versionLabel(it)" :value="it.versionUid ?? ''" />
        </el-select>
      </div>
      <el-icon class="cp-picker__arrow"><Sort /></el-icon>
      <div class="cp-picker__item">
        <span class="cp-picker__label">{{ pt('目标版本') }}</span>
        <el-select v-model="toUid" :placeholder="pt('选择目标版本')" filterable>
          <el-option v-for="it in versions" :key="it.versionUid" :label="versionLabel(it)" :value="it.versionUid ?? ''" />
        </el-select>
      </div>
      <el-button type="primary" :loading="loading" @click="doCompare">{{ pt('比较') }}</el-button>
    </div>
    <div v-if="result" v-loading="loading" class="cp-result">
      <div class="cp-summary">
        <el-tag size="small" type="info" effect="plain">{{ sideLabel('from') }} → {{ sideLabel('to') }}</el-tag>
        <el-tag size="small" type="warning" effect="plain">数据变更 {{ result.summary?.dataChanged ?? 0 }}</el-tag>
        <el-tag size="small" type="success" effect="plain">文件新增 {{ result.summary?.fileAdded ?? 0 }}</el-tag>
        <el-tag size="small" effect="plain">文件修改 {{ result.summary?.fileChanged ?? 0 }}</el-tag>
        <el-tag size="small" type="danger" effect="plain">文件删除 {{ result.summary?.fileRemoved ?? 0 }}</el-tag>
      </div>
      <div class="cp-files">
        <div v-for="(row, i) in resultFileRows" :key="i" class="cp-file-row">
          <el-tag
            size="small"
            :type="
              row.statusType === 'success' ? 'success' : row.statusType === 'danger' ? 'danger' : row.statusType === 'warning' ? 'warning' : 'info'
            "
            >{{ row.group }}</el-tag
          >
          <span class="cp-file-row__ext" :class="`ext-${row.statusType || 'info'}`">{{ row.ext || 'FILE' }}</span>
          <span class="cp-file-row__path" :title="row.path">{{ row.path }}</span>
        </div>
        <el-empty v-if="!resultFileRows.length" :description="pt('两个版本间无文件变更')" :image-size="50" />
      </div>
    </div>
    <div v-else class="cp-empty">{{ pt('选择版本后点击「比较」查看差异') }}</div>
    <div class="cp-footer">
      <el-button @click="emit('close')">{{ pt('关闭') }}</el-button>
    </div>
  </div>
</template>

<style scoped lang="scss">
.cp {
  min-height: 220px;
}
.cp-picker {
  display: flex;
  align-items: flex-end;
  gap: 12px;
}
.cp-picker__item {
  flex: 1;
  min-width: 0;
}
.cp-picker__label {
  display: block;
  margin-bottom: 6px;
  font-size: 12px;
  color: var(--el-text-color-secondary);
}
.cp-picker__arrow {
  padding-bottom: 8px;
  color: var(--el-text-color-secondary);
}
.cp-result {
  margin-top: 18px;
}
.cp-summary {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  padding-bottom: 12px;
  border-bottom: 1px solid var(--el-border-color-lighter);
}
.cp-files {
  margin-top: 12px;
  max-height: 320px;
  overflow: auto;
}
.cp-file-row {
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 34px;
  padding: 4px 8px;
  border-radius: 4px;
}
.cp-file-row:hover {
  background: var(--el-fill-color-light);
}
.cp-file-row__ext {
  flex: none;
  min-width: 44px;
  padding: 1px 6px;
  border-radius: 3px;
  font-size: 11px;
  text-align: center;
  background: var(--el-fill-color);
  color: var(--el-text-color-regular);
}
.cp-file-row__ext.ext-success {
  background: var(--el-color-success-light-9);
  color: var(--el-color-success);
}
.cp-file-row__ext.ext-danger {
  background: var(--el-color-danger-light-9);
  color: var(--el-color-danger);
}
.cp-file-row__ext.ext-warning {
  background: var(--el-color-warning-light-9);
  color: var(--el-color-warning);
}
.cp-file-row__path {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 12px;
}
.cp-empty {
  margin-top: 18px;
  padding: 28px 0;
  text-align: center;
  color: var(--el-text-color-secondary);
  font-size: 13px;
}
.cp-footer {
  display: flex;
  justify-content: flex-end;
  margin-top: 16px;
}
</style>
