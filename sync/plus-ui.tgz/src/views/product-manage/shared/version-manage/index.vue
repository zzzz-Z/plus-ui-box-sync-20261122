<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
/*
 * 版本管理（产品数据版本视图，doc-9701308）
 *
 * 数据源为「产品数据版本」接口族（tb_resource_data，按 resourceUid 定位），
 * 与 metadata-versions.ts 的「元数据记录版本」是两套口径——后者需要 tableKey +
 * metadataUid 三元组，取到的是单条记录 rowVersion 历史，不是本页要的产品版本日志。
 *
 * 三区布局（对齐用户提供的 SVN / 版本日志界面）：
 *   上 = 版本日志表：版本树 | 操作 | 信息 | 作者 | 日期（data-version-log，空则回退 data-versions 列表）
 *   中 = 信息：选中版本的修订说明（information 多行）+ 变更数量汇总（changeSummary）
 *   下 = 文件变更列表：路径 | 扩展名 | 状态 | 添加行数 | 删除行数
 *        （详情 files[]，为空则取相邻两版本 compare 的 fileChanges.added/changed/removed）
 *
 * 契约里 items[] 多为示例空数组、元素字段未列全，故接口层类型宽松，
 * 页面统一做字段别名兼容（normalizeLog / toFileRow），避免后端字段漂移导致整页空白。
 */
import { h } from 'vue';
import { Clock, Coin, Document, FolderOpened, Grid, Location, Memo, Picture, Refresh, RefreshLeft, Search, Sort } from '@element-plus/icons-vue';
import { ElMessage } from 'element-plus';
import { getMetadataBrowseTree, type MetadataTreeNode } from '@/api/product-manage/platform/metadata-browse';
import {
  getDataVersionLog,
  listDataVersions,
  getDataVersionDetail,
  compareDataVersions,
  getResourceStorageSummary,
  type DataVersionLogItem,
  type DataVersionDetail,
  type DataVersionFile,
  type ResourceStorageSummary
} from '@/api/product-manage/platform/data-versions';
import { useTreeHost } from '@/views/product-manage/shared/tree-host';
import { createDialog } from '@/composables/create-dialog';
import ComparePanel from './ComparePanel.vue';
import RestorePanel from './RestorePanel.vue';

defineOptions({ name: 'VersionManage' });

/**
 * 树挂载位必须在最前声明：useTreeHost 内部注册了带 immediate 语义的生命周期钩子，
 * 且下面「认领 → 回写」的 watch 会在 setup 阶段读它，后置声明会命中 TDZ。
 */
const treeHost = useTreeHost();

/* ---------------------------- 左侧资源树（与数据浏览同构） ---------------------------- */

interface TreeNodeVM {
  key: string;
  label: string;
  kind: 'cat' | 'res';
  categoryUid?: string;
  categoryName?: string;
  resourceUid?: string;
  dataType?: string;
  state?: string;
  layerCount?: number;
  version?: string;
  nameEn?: string;
  createdAt?: string;
  updatedAt?: string;
  children?: TreeNodeVM[];
  count?: number;
}

const loadingTree = ref(false);
const browseTree = ref<MetadataTreeNode[]>([]);
const keyword = ref('');
const treeRef = ref();

/** 统计子树里的资源数：类别节点 count 徽标 */
function countResources(nodes: TreeNodeVM[]): number {
  return nodes.reduce((sum, n) => sum + (n.kind === 'res' ? 1 : 0) + (n.children ? countResources(n.children) : 0), 0);
}

/** 与数据浏览 toTreeNode 同口径：资源保留全部业务字段，类别递归且剪掉空枝 */
function toTreeNode(n: MetadataTreeNode): TreeNodeVM | null {
  if (n.nodeType === 'resource') {
    return {
      key: `res:${n.uid}`,
      label: n.displayName || n.categoryName || n.uid,
      kind: 'res',
      categoryUid: n.categoryUid,
      resourceUid: n.uid,
      dataType: n.dataType,
      state: n.state,
      layerCount: n.layerCount ?? 0,
      version: n.version,
      nameEn: n.nameEn,
      createdAt: n.createdAt,
      updatedAt: n.updatedAt
    };
  }
  const children = (n.children ?? []).map(toTreeNode).filter((x): x is TreeNodeVM => !!x);
  if (!children.length) return null;
  return {
    key: `cat:${n.uid}`,
    label: n.displayName || n.categoryName || n.uid,
    kind: 'cat',
    categoryUid: n.uid,
    children,
    count: countResources(children)
  };
}

const treeData = computed<TreeNodeVM[]>(() => browseTree.value.map(toTreeNode).filter((n): n is TreeNodeVM => !!n));

/** 图标口径与数据浏览一致：类别按主色，资源按 dataType 着色 */
function nodeIconMeta(data: TreeNodeVM) {
  if (data.kind === 'cat') return { icon: FolderOpened, color: 'var(--el-color-primary)' };
  const t = (data.dataType ?? '').toLowerCase();
  if (t.includes('vector')) return { icon: Location, color: '#13a8a8' };
  if (t.includes('raster')) return { icon: Picture, color: '#3f8cff' };
  if (t.includes('table')) return { icon: Grid, color: '#2ba471' };
  if (t.includes('text')) return { icon: Memo, color: '#909399' };
  return { icon: Document, color: 'var(--el-text-color-secondary)' };
}

async function loadData() {
  loadingTree.value = true;
  try {
    const res = await getMetadataBrowseTree();
    browseTree.value = res?.data?.items ?? [];
  } catch {
    browseTree.value = [];
    ElMessage.error(pt('资源树加载失败，请稍后重试'));
  } finally {
    loadingTree.value = false;
  }
}

function filterNode(value: string, data: TreeNodeVM) {
  if (!value) return true;
  return String(data.label ?? '')
    .toLowerCase()
    .includes(value.toLowerCase());
}
watch(keyword, (v) => treeRef.value?.filter(v));

/* ---------------------------- 右侧：三区版本视图 ---------------------------- */

const selectedResource = ref<TreeNodeVM | null>(null);

/** 版本日志 */
const logItems = ref<DataVersionLogItem[]>([]);
const logTotal = ref(0);
const logPage = ref(1);
const logPageSize = ref(20);
const logLoading = ref(false);
const logError = ref('');
const selectedVersionUid = ref('');

/** 信息区 + 文件变更列表 */
const currentDetail = ref<DataVersionDetail | null>(null);
const detailLoading = ref(false);
const fileRows = ref<FileChangeRow[]>([]);
const fileLoading = ref(false);

/** 资源存储容量（信息区头部展示） */
const storageSummary = ref<ResourceStorageSummary | null>(null);

/** 版本比较弹窗实例（createDialog，关闭即销毁） */
let compareDialog: ReturnType<typeof createDialog> | null = null;

interface FileChangeRow {
  path: string;
  ext: string;
  statusType: '' | 'success' | 'warning' | 'danger' | 'info';
  statusLabel: string;
  fileName: string;
  directory: string;
  addLines: number;
  delLines: number;
}

/** 后端字段别名兼容：把松散的日志项补齐成统一视图模型 */
function normalizeLog(raw: DataVersionLogItem[]): DataVersionLogItem[] {
  return (raw ?? []).map((it) => ({
    ...it,
    information: String(it.information ?? it.message ?? it.summary ?? ''),
    operation: String(it.operation ?? it.operationText ?? it.op ?? ''),
    createdByRef: String(it.createdByRef ?? it.createdBy ?? it.author ?? it.actor ?? ''),
    createdAt: String(it.createdAt ?? it.createdTime ?? it.date ?? '')
  }));
}

function logInformation(it: DataVersionLogItem): string {
  return String((it as DataVersionLogItem).information ?? '');
}
/** 更新名称：后端 name / displayName 字段 */
function logName(it: DataVersionLogItem): string {
  return String((it as DataVersionLogItem).name ?? (it as DataVersionLogItem).displayName ?? '');
}
function logTime(it: DataVersionLogItem): string {
  return String((it as DataVersionLogItem).createdAt ?? '').replace('T', ' ');
}

/** 版本顺序：按版本号降序（新版本在前），无版本号时按时间降序 */
const sortedLogItems = computed(() =>
  [...logItems.value].sort((a, b) => {
    const na = a.versionNo == null ? -Infinity : Number(a.versionNo);
    const nb = b.versionNo == null ? -Infinity : Number(b.versionNo);
    if (na !== nb) return nb - na;
    return String(b.createdAt ?? '').localeCompare(String(a.createdAt ?? ''));
  })
);

/** 时间线展示顺序：升序（旧 → 新，当前版本在最右），与参考图「时间推进 → 当前位置」方向一致 */
const ascLogItems = computed(() => [...sortedLogItems.value].reverse());

/** 当前版本：优先后端 isCurrent/isLatest 标记，否则取版本号最大者 */
const currentVersionUid = computed(() => {
  const marked = logItems.value.find((x) => x.isCurrent === true || x.isLatest === true);
  if (marked?.versionUid) return marked.versionUid;
  return sortedLogItems.value[0]?.versionUid ?? '';
});

/** 当前选中的日志项，供信息区回退取 information 字段 */
const selectedLogItem = computed(() => logItems.value.find((x) => x.versionUid === selectedVersionUid.value) ?? null);

/** 恢复候选版本：优先当前选中项，否则取高亮版本 */
const restoreCandidate = computed(() => selectedLogItem.value ?? logItems.value.find((x) => x.versionUid === currentVersionUid.value) ?? null);

/** 恢复版本弹窗实例（createDialog，关闭即销毁） */
let restoreDialog: ReturnType<typeof createDialog> | null = null;

/** 扩展名徽章配色：按状态关键词映射颜色 */
function statusTypeOf(status: string): FileChangeRow['statusType'] {
  const s = String(status ?? '').toLowerCase();
  if (/(add|new|create|新增|添加)/.test(s)) return 'success';
  if (/(del|remove|delete|删除|移除)/.test(s)) return 'danger';
  if (/(mod|update|edit|change|modify|修改|更新)/.test(s)) return 'warning';
  return 'info';
}

function toFileRow(f: DataVersionFile, forceStatus?: string): FileChangeRow {
  const path = String(f.relativePath ?? f.path ?? f.name ?? '');
  const slash = Math.max(path.lastIndexOf('/'), path.lastIndexOf('\\'));
  const fileName = slash >= 0 ? path.slice(slash + 1) : path;
  const directory = slash > 0 ? path.slice(0, slash) : '';
  const dot = fileName.lastIndexOf('.');
  const ext = dot > 0 ? fileName.slice(dot) : '';
  const status = String(forceStatus ?? f.status ?? '');
  const addLines = Number(f.addLines ?? f.addedLines ?? f.linesAdded ?? f.insertLines ?? 0) || 0;
  const delLines = Number(f.delLines ?? f.deletedLines ?? f.linesDeleted ?? f.deleteLines ?? 0) || 0;
  return {
    path,
    ext,
    statusType: statusTypeOf(status),
    statusLabel: statusLabelOf(status),
    fileName,
    directory,
    addLines,
    delLines
  };
}

/** 状态文案：added/changed/removed 归一成新增/修改/删除，未知状态显示详情或变更 */
function statusLabelOf(status: string): string {
  const s = String(status ?? '').toLowerCase();
  if (/(add|new|create|新增|添加)/.test(s)) return pt('新增');
  if (/(del|remove|delete|删除|移除)/.test(s)) return pt('删除');
  if (/(mod|update|edit|change|modify|修改|更新)/.test(s)) return pt('修改');
  return s ? String(status) : pt('变更');
}

/** 信息区：优先详情 information，为空回退日志项 information 字段，按行拆成 bullet */
const informationLines = computed<string[]>(() => {
  const info = currentDetail.value?.information || logInformation(selectedLogItem.value ?? {}) || '';
  return String(info)
    .split(/\r?\n/)
    .map((s) => s.trim().replace(/^[-•]\s*/, ''))
    .filter(Boolean);
});

const fileStatusFilter = ref<'all' | 'added' | 'changed' | 'removed'>('all');

const fileCounts = computed(() => {
  const counts = { added: 0, changed: 0, removed: 0 };
  fileRows.value.forEach((row) => {
    if (row.statusType === 'success') counts.added++;
    else if (row.statusType === 'danger') counts.removed++;
    else if (row.statusType === 'warning') counts.changed++;
  });
  return counts;
});

const visibleFileRows = computed(() => {
  if (fileStatusFilter.value === 'all') return fileRows.value;
  const target: Record<Exclude<typeof fileStatusFilter.value, 'all'>, FileChangeRow['statusType']> = {
    added: 'success',
    changed: 'warning',
    removed: 'danger'
  };
  return fileRows.value.filter((row) => row.statusType === target[fileStatusFilter.value as Exclude<typeof fileStatusFilter.value, 'all'>]);
});

const changeSummary = computed(() => currentDetail.value?.changeSummary ?? ({} as NonNullable<DataVersionDetail['changeSummary']>));
const summaryPairs = computed(() => {
  const s: Record<string, unknown> = changeSummary.value;
  const labels: Array<[string, string]> = [
    ['数据变更', 'dataChanged'],
    ['文件新增', 'fileAdded'],
    ['文件修改', 'fileChanged'],
    ['文件删除', 'fileRemoved'],
    ['图层新增', 'layerAdded'],
    ['图层修改', 'layerChanged'],
    ['图层删除', 'layerRemoved'],
    ['元数据表新增', 'metadataTableAdded'],
    ['元数据表修改', 'metadataTableChanged'],
    ['元数据表删除', 'metadataTableRemoved']
  ];
  return labels.filter(([, key]) => s[key] !== undefined).map(([label, key]) => ({ label, value: Number(s[key] ?? 0) }));
});

/** 版本日志：优先 data-version-log，空则回退 data-versions 列表 */
async function loadVersionLog() {
  const uid = selectedResource.value?.resourceUid;
  if (!uid) return;
  logLoading.value = true;
  logError.value = '';
  try {
    const res = await getDataVersionLog(uid, { page: logPage.value, pageSize: logPageSize.value });
    let items = normalizeLog(res?.data?.items ?? []);
    let total = res?.data?.total ?? 0;
    if (!items.length) {
      const fallback = await listDataVersions(uid, { page: logPage.value, pageSize: logPageSize.value });
      items = normalizeLog(fallback?.data?.items ?? []);
      total = fallback?.data?.total ?? 0;
    }
    logItems.value = items;
    logTotal.value = total;
    if (items.length) {
      const keep = items.find((x) => x.versionUid === selectedVersionUid.value);
      const marked = items.find((x) => x.isCurrent === true || x.isLatest === true);
      const maxNo = items.reduce<DataVersionLogItem | null>((acc, x) => {
        if (!acc) return x;
        return Number(x.versionNo ?? 0) > Number(acc.versionNo ?? 0) ? x : acc;
      }, null);
      selectedVersionUid.value = keep?.versionUid ?? marked?.versionUid ?? maxNo?.versionUid ?? items[0].versionUid ?? '';
      await loadVersionDetail();
    } else {
      selectedVersionUid.value = '';
      currentDetail.value = null;
      fileRows.value = [];
    }
  } catch {
    logItems.value = [];
    logTotal.value = 0;
    currentDetail.value = null;
    fileRows.value = [];
    logError.value = '版本日志加载失败，请稍后重试';
  } finally {
    logLoading.value = false;
  }
}

/** 从详情 changeManifest.fileChanges 读取新增/修改/删除分组 */
function rowsFromManifest(detail: DataVersionDetail | null): FileChangeRow[] {
  const manifest = detail?.changeManifest as unknown as Record<string, unknown> | undefined;
  const fc = (manifest?.fileChanges ?? manifest?.files ?? {}) as DataVersionChangeGroup;
  if (!fc.added?.length && !fc.changed?.length && !fc.removed?.length) return [];
  return [
    ...(fc.added ?? []).map((f) => toFileRow(f, 'added')),
    ...(fc.changed ?? []).map((f) => toFileRow(f, 'changed')),
    ...(fc.removed ?? []).map((f) => toFileRow(f, 'removed'))
  ];
}

/** 文件变更列表：优先详情 changeManifest.fileChanges，其次相邻版本 compare，最后详情 files[] */
async function loadFileChanges(detail: DataVersionDetail | null) {
  const manifestRows = rowsFromManifest(detail);
  if (manifestRows.length) {
    fileRows.value = manifestRows;
    return;
  }
  const uid = selectedResource.value?.resourceUid;
  const curUid = selectedVersionUid.value;
  if (uid && curUid) {
    const idx = logItems.value.findIndex((x) => x.versionUid === curUid);
    const prevUid = idx >= 0 ? logItems.value[idx + 1]?.versionUid : undefined;
    if (prevUid) {
      fileLoading.value = true;
      try {
        const res = await compareDataVersions(uid, prevUid, curUid);
        const fc = res?.data?.fileChanges ?? {};
        fileRows.value = [
          ...(fc.added ?? []).map((f) => toFileRow(f, 'added')),
          ...(fc.changed ?? []).map((f) => toFileRow(f, 'changed')),
          ...(fc.removed ?? []).map((f) => toFileRow(f, 'removed'))
        ];
        if (fileRows.value.length) return;
      } catch {
        fileRows.value = [];
      } finally {
        fileLoading.value = false;
      }
    }
  }
  fileRows.value = (detail?.files ?? []).map((f) => toFileRow(f));
}

/** 选中版本 → 取详情 → 渲染信息区与文件变更列表 */
async function loadVersionDetail() {
  const uid = selectedResource.value?.resourceUid;
  const vuid = selectedVersionUid.value;
  if (!uid || !vuid) {
    currentDetail.value = null;
    fileRows.value = [];
    return;
  }
  detailLoading.value = true;
  try {
    const res = await getDataVersionDetail(uid, vuid);
    currentDetail.value = res?.data ?? null;
    await loadFileChanges(currentDetail.value);
  } catch {
    currentDetail.value = null;
    fileRows.value = [];
    ElMessage.error(pt('版本详情加载失败，请稍后重试'));
  } finally {
    detailLoading.value = false;
  }
}

async function onSelectVersion(row: DataVersionLogItem) {
  if (!row.versionUid || row.versionUid === selectedVersionUid.value) return;
  selectedVersionUid.value = row.versionUid;
  await loadVersionDetail();
}

function onLogPageChange(p: number) {
  logPage.value = p;
  void loadVersionLog();
}

/* ---------------------------- 存储容量 / 恢复 / 比较 ---------------------------- */

/** 字节数格式化：B / KB / MB / GB */
function formatBytes(n: number | undefined): string {
  if (n == null) return '—';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let v = Number(n);
  let i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i += 1;
  }
  return `${i === 0 ? v : v.toFixed(2)} ${units[i]}`;
}

/** 资源存储容量：选中资源后加载，切换资源时清空 */
async function loadStorageSummary() {
  const uid = selectedResource.value?.resourceUid;
  if (!uid) {
    storageSummary.value = null;
    return;
  }
  try {
    const res = await getResourceStorageSummary(uid);
    storageSummary.value = res?.data ?? null;
  } catch {
    storageSummary.value = null;
  }
}

/** 打开恢复弹窗（createDialog）：传入目标版本，未传则回退到当前选中/高亮版本 */
function openRestoreDialog(row?: DataVersionLogItem) {
  const target = row ?? restoreCandidate.value;
  const uid = selectedResource.value?.resourceUid;
  if (!target?.versionUid || !uid) {
    ElMessage.warning(pt('请先选择一个版本'));
    return;
  }
  const versionUid = target.versionUid;
  restoreDialog?.destroy();
  restoreDialog = createDialog({
    title: pt('恢复数据版本'),
    width: '480px',
    footer: false,
    closeOnClickModal: false,
    bodyStyle: { padding: '18px 22px' },
    render: () =>
      h(RestorePanel, {
        resourceUid: uid,
        versionUid,
        versionNo: target.versionNo,
        onClose: () => restoreDialog?.close(),
        onRestored: () => {
          void loadVersionLog();
          void loadStorageSummary();
        }
      })
  });
}

/** 打开版本比较弹窗：默认 from=当前选中版本、to=下一个较旧版本 */
function openCompareDialog() {
  const uid = selectedResource.value?.resourceUid;
  if (!uid || !logItems.value.length) return;
  const idx = logItems.value.findIndex((x) => x.versionUid === selectedVersionUid.value);
  const initialFromUid = selectedVersionUid.value;
  const initialToUid = idx >= 0 ? (logItems.value[idx + 1]?.versionUid ?? '') : '';
  compareDialog?.destroy();
  compareDialog = createDialog({
    title: pt('版本比较'),
    width: '720px',
    footer: false,
    closeOnClickModal: false,
    bodyStyle: { padding: '18px 22px' },
    render: () =>
      h(ComparePanel, {
        resourceUid: uid,
        versions: sortedLogItems.value,
        initialFromUid,
        initialToUid,
        onClose: () => compareDialog?.close()
      })
  });
}

/** 选中资源：按 resourceUid 去重避免重复请求 */
async function selectResource(res: TreeNodeVM) {
  if (selectedResource.value?.resourceUid === res.resourceUid) return;
  selectedResource.value = res;
  logPage.value = 1;
  selectedVersionUid.value = '';
  currentDetail.value = null;
  fileRows.value = [];
  storageSummary.value = null;
  await loadVersionLog();
  await loadStorageSummary();
}
async function onNodeClick(data: TreeNodeVM) {
  if (data.kind !== 'res') {
    selectedResource.value = null;
    logItems.value = [];
    currentDetail.value = null;
    fileRows.value = [];
    storageSummary.value = null;
    return;
  }
  await selectResource(data);
}

/* ---------------------------- 树宽度拖拽 ---------------------------- */

const pageRef = ref<HTMLElement>();
const hosted = computed(() => !!treeHost?.el.value);
const treeTarget = computed(() => treeHost?.el.value ?? 'body');
const treeWidth = treeHost ? treeHost.width : ref(320);
const TREE_MIN = 200;
const TREE_MAX = 520;
let resizeStartX = 0;
let resizeStartW = 0;
function startResize(e: PointerEvent) {
  resizeStartX = e.clientX;
  resizeStartW = treeWidth.value;
  window.addEventListener('pointermove', onResize);
  window.addEventListener('pointerup', stopResize);
  window.addEventListener('pointercancel', stopResize);
}
function onResize(e: PointerEvent) {
  treeWidth.value = Math.round(Math.min(TREE_MAX, Math.max(TREE_MIN, resizeStartW + (e.clientX - resizeStartX))));
}
function stopResize() {
  window.removeEventListener('pointermove', onResize);
  window.removeEventListener('pointerup', stopResize);
  window.removeEventListener('pointercancel', stopResize);
}
function fitTreeWidth() {
  const total = pageRef.value?.clientWidth ?? 0;
  if (!total) return;
  treeWidth.value = Math.min(TREE_MAX, Math.max(TREE_MIN, Math.round(total * 0.26)));
}
onMounted(() => {
  loadData();
  fitTreeWidth();
  window.addEventListener('resize', fitTreeWidth);
});
onBeforeUnmount(() => {
  stopResize();
  window.removeEventListener('resize', fitTreeWidth);
});
</script>

<template>
  <div ref="pageRef" v-loading="loadingTree" class="vm-page">
    <!-- 左：资源树。与数据浏览同构，Teleport 到宿主左列；独立挂载时就地渲染 -->
    <Teleport :to="treeTarget" :disabled="!hosted">
      <aside class="db-tree" :class="{ 'is-hosted': hosted }" :style="hosted ? undefined : { flexBasis: treeWidth + 'px' }">
        <div class="db-tree__head">
          <el-input v-model="keyword" :placeholder="pt('搜索资源 / 类别')" clearable :prefix-icon="Search" />
        </div>
        <div class="db-tree__body">
          <el-tree
            ref="treeRef"
            :data="treeData"
            node-key="key"
            :props="{ label: 'label', children: 'children' }"
            :indent="14"
            :default-expand-all="true"
            :expand-on-click-node="false"
            highlight-current
            :filter-node-method="filterNode"
            @node-click="onNodeClick"
          >
            <template #default="{ data }">
              <span class="db-node" :class="`is-${data.kind}`">
                <el-icon class="db-node__ic" :style="{ color: nodeIconMeta(data).color }">
                  <component :is="nodeIconMeta(data).icon" />
                </el-icon>
                <span class="db-node__label" :title="data.label">{{ data.label }}</span>
                <span v-if="data.count" class="db-node__count">{{ data.count }}</span>
              </span>
            </template>
          </el-tree>
          <el-empty v-if="!loadingTree && !treeData.length" description="暂无资源" :image-size="50" />
        </div>
      </aside>
    </Teleport>

    <div v-if="!hosted" class="db-split" title="拖动调整树宽度" @pointerdown.prevent="startResize" />

    <!-- 右：三区版本视图 -->
    <section v-if="selectedResource" class="vm-detail">
      <!-- 上：版本日志表 -->
      <div class="vm-pane vm-log-pane">
        <div class="vm-pane__head">
          <span class="vm-pane__title">
            <el-icon><Clock /></el-icon>
            版本时间线
            <span class="vm-pane__count">{{ logTotal }}</span>
            <span v-if="storageSummary" class="vm-storage" :title="`全部版本唯一对象 ${formatBytes(storageSummary.totalObjectBytes)}`">
              <el-icon><Coin /></el-icon>
              容量 {{ formatBytes(storageSummary.currentLogicalBytes) }} / {{ storageSummary.versionCount ?? 0 }} 版本
            </span>
          </span>
          <div class="vm-tl-actions">
            <el-button link :icon="Sort" :disabled="!logItems.length" @click="openCompareDialog">版本比较</el-button>
            <el-button
              v-if="selectedVersionUid && selectedVersionUid !== currentVersionUid"
              type="primary"
              :icon="RefreshLeft"
              @click="openRestoreDialog()"
              >恢复此版本</el-button
            >
            <el-button link :icon="Refresh" :loading="logLoading" @click="loadVersionLog">刷新</el-button>
          </div>
        </div>
        <div v-if="logError" class="vm-error">{{ logError }}</div>
        <div v-loading="logLoading" class="vm-timeline-wrap">
          <div v-if="logItems.length" class="vm-timeline">
            <!-- 时间轴：实心起点 → 箭头 → 各版本时钟节点，方向「由旧到新」，末端引出当前位置 -->
            <div class="vm-tl-track">
              <span class="vm-tl-origin" />
              <template v-for="(row, idx) in ascLogItems" :key="row.versionUid ?? idx">
                <span class="vm-tl-arrow" aria-hidden="true" />
                <div
                  class="vm-tl-node"
                  :class="{
                    'is-selected': row.versionUid === selectedVersionUid,
                    'is-current': row.versionUid === currentVersionUid
                  }"
                  :title="`${logName(row)} ${logTime(row)}`"
                  @click="onSelectVersion(row)"
                >
                  <div class="vm-tl-face">
                    <el-icon class="vm-tl-clock"><Clock /></el-icon>
                    <span class="vm-tl-flag" />
                  </div>
                  <span class="vm-tl-label">v{{ row.versionNo ?? '—' }}</span>
                  <!-- 当前版本节点向下引 L 形折线箭头，指向「当前位置」标记块 -->
                  <div v-if="row.versionUid === currentVersionUid" class="vm-tl-current">
                    <span class="vm-tl-elbow" />
                    <div class="vm-tl-now">
                      <el-icon class="vm-tl-now__pin"><Location /></el-icon>
                      <span class="vm-now-text">当前位置</span>
                      <span class="vm-tl-now-ver">v{{ row.versionNo ?? '—' }}</span>
                    </div>
                  </div>
                </div>
              </template>
            </div>
          </div>
          <el-empty v-else description="该资源暂无版本历史" :image-size="60" />
        </div>
        <div v-if="logTotal > logPageSize" class="vm-pager">
          <el-pagination
            v-model:current-page="logPage"
            :page-size="logPageSize"
            :total="logTotal"
            layout="prev, pager, next"
            background
            @current-change="onLogPageChange"
          />
        </div>
      </div>

      <!-- 中：信息 -->
      <div v-loading="detailLoading" class="vm-pane vm-info-pane">
        <div class="vm-pane__head">
          <span class="vm-pane__title">
            <el-icon><Document /></el-icon>
            信息
            <span v-if="currentDetail" class="vm-info__ver">版本 v{{ currentDetail.versionNo }}</span>
          </span>
        </div>
        <div class="vm-info__body">
          <template v-if="currentDetail">
            <ul v-if="informationLines.length" class="vm-info__lines">
              <li v-for="(line, i) in informationLines" :key="i">{{ line }}</li>
            </ul>
            <div v-else class="vm-info__muted">该版本未填写修订说明</div>
            <div v-if="summaryPairs.length" class="vm-info__summary">
              <el-tag v-for="p in summaryPairs" :key="p.label" size="small" type="info" effect="plain"> {{ p.label }} {{ p.value }} </el-tag>
            </div>
          </template>
          <el-empty v-else description="选择一个版本以查看信息" :image-size="50" />
        </div>
      </div>

      <!-- 下：文件变更列表 -->
      <div v-loading="fileLoading" class="vm-pane vm-file-pane">
        <div class="vm-pane__head">
          <span class="vm-pane__title">
            <el-icon><FolderOpened /></el-icon>
            文件变更列表
            <span class="vm-pane__count">{{ fileRows.length }}</span>
          </span>
          <div class="vm-file-filters">
            <el-button text size="small" :class="{ 'is-active': fileStatusFilter === 'all' }" @click="fileStatusFilter = 'all'"
              >全部 {{ fileRows.length }}</el-button
            >
            <el-button text size="small" :class="{ 'is-active': fileStatusFilter === 'added' }" @click="fileStatusFilter = 'added'"
              >新增 {{ fileCounts.added }}</el-button
            >
            <el-button text size="small" :class="{ 'is-active': fileStatusFilter === 'changed' }" @click="fileStatusFilter = 'changed'"
              >修改 {{ fileCounts.changed }}</el-button
            >
            <el-button text size="small" :class="{ 'is-active': fileStatusFilter === 'removed' }" @click="fileStatusFilter = 'removed'"
              >删除 {{ fileCounts.removed }}</el-button
            >
          </div>
        </div>
        <div class="vm-file-list">
          <div v-for="(row, i) in visibleFileRows" :key="`${row.path}-${i}`" class="vm-file-row" :class="`is-${row.statusType || 'info'}`">
            <span class="vm-file-row__ext" :class="`ext-${row.statusType || 'info'}`">{{ row.ext || 'FILE' }}</span>
            <div class="vm-file-row__body">
              <div class="vm-file-row__name" :title="row.path">{{ row.fileName }}</div>
            </div>
            <span class="vm-file-row__status" :class="`st-${row.statusType || 'info'}`">{{ row.statusLabel }}</span>
            <span v-if="row.addLines || row.delLines" class="vm-file-row__lines">
              <span v-if="row.addLines" class="is-add">+{{ row.addLines }}</span>
              <span v-if="row.delLines" class="is-del">-{{ row.delLines }}</span>
            </span>
          </div>
          <el-empty v-if="!visibleFileRows.length" :description="fileRows.length ? '该筛选下暂无文件' : '该版本暂无文件变更'" :image-size="50" />
        </div>
      </div>
    </section>

    <section v-else class="vm-detail vm-empty-wrap">
      <el-empty description="请从左侧资源树选择一个资源" :image-size="90" />
    </section>
  </div>
</template>

<style scoped lang="scss">
.vm-page {
  display: flex;
  width: 100%;
  height: 100%;
  min-height: 0;
  overflow: hidden;
  background: var(--el-bg-color);
}

/* 左树：完全复用数据浏览 .db-tree / .db-node / .db-split 口径，保证 UI 一致 */
.db-tree {
  display: flex;
  flex: 0 0 auto;
  flex-direction: column;
  min-height: 0;
  max-width: 55%;
  min-width: 0;
  padding: 0;
  overflow: hidden;
  background: var(--el-bg-color);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 6px;
}
.db-tree.is-hosted {
  flex: 1 1 auto;
  width: 100%;
  max-width: none;
  height: 100%;
}
.db-tree__head {
  padding: 10px 10px 8px;
  border-bottom: 1px solid var(--el-border-color-lighter);
}
.db-tree__body {
  flex: 1;
  min-height: 0;
  padding: 6px 6px 10px;
  overflow: auto;
}
.db-node {
  display: flex;
  align-items: center;
  gap: 6px;
  width: 100%;
  padding-right: 4px;
  font-size: 13px;
}
.db-node__ic {
  display: inline-flex;
  flex: none;
  align-items: center;
  width: 15px;
  font-size: 13px;
  color: var(--el-text-color-placeholder);
}
.db-node__label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.db-node__count {
  flex: none;
  min-width: 20px;
  padding: 0 5px;
  color: var(--el-text-color-secondary);
  font-size: 11px;
  line-height: 16px;
  text-align: center;
  background: var(--el-fill-color-light);
  border-radius: 8px;
}
:deep(.el-tree-node__content) {
  height: 30px;
  border-radius: 4px;
}
:deep(.el-tree-node.is-current > .el-tree-node__content) {
  background: var(--el-color-primary-light-9);
  .db-node__count {
    color: var(--el-color-primary);
    background: var(--el-color-primary-light-8);
  }
}
.db-split {
  position: relative;
  display: flex;
  flex: 0 0 9px;
  align-self: stretch;
  cursor: col-resize;
  touch-action: none;
}
.db-split::after {
  content: '';
  position: absolute;
  top: 50%;
  left: 50%;
  width: 2px;
  height: 34px;
  background: var(--el-color-primary);
  border-radius: 1px;
  opacity: 0;
  transform: translate(-50%, -50%);
  transition: opacity 0.15s;
}
.db-split:hover::after {
  opacity: 0.65;
}

/* 右：三区版本视图 */
.vm-detail {
  display: flex;
  flex: 1;
  flex-direction: column;
  gap: 12px;
  min-width: 0;
  min-height: 0;
  padding: 14px;
  overflow: hidden;
}
.vm-empty-wrap {
  align-items: center;
  justify-content: center;
}
.vm-pane {
  display: flex;
  flex-direction: column;
  min-height: 0;
  overflow: hidden;
  background: var(--el-bg-color);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 6px;
}
.vm-log-pane {
  flex: 0 0 auto;
}
.vm-info-pane {
  flex: 0 0 auto;
  max-height: 22%;
}
.vm-file-pane {
  flex: 1 1 32%;
}
.vm-file-list {
  flex: 1;
  min-height: 0;
  padding: 6px 12px 12px;
  overflow: auto;
}
.vm-file-filters {
  display: inline-flex;
  align-items: center;
  gap: 2px;
  margin-left: auto;
  .el-button {
    height: 24px;
    padding: 0 8px;
    color: var(--el-text-color-secondary);
    font-size: 12px;
  }
  .el-button.is-active {
    color: var(--el-color-primary);
    font-weight: 600;
    background: var(--el-color-primary-light-9);
  }
}
.vm-file-row {
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 34px;
  padding: 4px 10px;
  margin-bottom: 4px;
  background: var(--el-fill-color-blank);
  border: 1px solid var(--el-border-color-lighter);
  border-left: 3px solid var(--el-border-color-lighter);
  border-radius: 5px;
  transition:
    border-color 0.15s,
    box-shadow 0.15s;
}
.vm-file-row.ext-success,
.vm-file-row.is-added {
  border-left-color: var(--el-color-success);
}
.vm-file-row.ext-danger,
.vm-file-row.is-removed {
  border-left-color: var(--el-color-danger);
}
.vm-file-row.ext-warning,
.vm-file-row.is-changed {
  border-left-color: var(--el-color-warning);
}
.vm-file-row:hover {
  border-color: var(--el-color-primary-light-5);
  box-shadow: 0 2px 8px -4px rgb(0 0 0 / 18%);
}
.vm-file-row__ext {
  display: inline-flex;
  flex: none;
  align-items: center;
  justify-content: center;
  min-width: 50px;
  height: 22px;
  padding: 0 5px;
  color: var(--el-color-info);
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
  background: var(--el-fill-color-light);
  border-radius: 3px;
}
.vm-file-row__ext.ext-success {
  color: var(--el-color-success);
  background: var(--el-color-success-light-9);
}
.vm-file-row__ext.ext-danger {
  color: var(--el-color-danger);
  background: var(--el-color-danger-light-9);
}
.vm-file-row__ext.ext-warning {
  color: var(--el-color-warning);
  background: var(--el-color-warning-light-9);
}
.vm-file-row__body {
  flex: 1;
  min-width: 0;
}
.vm-file-row__name {
  overflow: hidden;
  color: var(--el-text-color-primary);
  font-size: 12px;
  font-weight: 600;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.vm-file-row__status {
  flex: none;
  min-width: 34px;
  padding: 2px 7px;
  font-size: 11px;
  line-height: 16px;
  text-align: center;
  border: 1px solid transparent;
  border-radius: 10px;
}
.vm-file-row__status.st-success {
  color: var(--el-color-success);
  background: var(--el-color-success-light-9);
  border-color: var(--el-color-success-light-7);
}
.vm-file-row__status.st-danger {
  color: var(--el-color-danger);
  background: var(--el-color-danger-light-9);
  border-color: var(--el-color-danger-light-7);
}
.vm-file-row__status.st-warning {
  color: var(--el-color-warning);
  background: var(--el-color-warning-light-9);
  border-color: var(--el-color-warning-light-7);
}
.vm-file-row__status.st-info {
  color: var(--el-text-color-secondary);
  background: var(--el-fill-color-light);
}
.vm-file-row__lines {
  display: inline-flex;
  flex: none;
  gap: 4px;
  font-size: 11px;
  font-variant-numeric: tabular-nums;
}
.vm-file-row__lines .is-add {
  color: var(--el-color-success);
}
.vm-file-row__lines .is-del {
  color: var(--el-color-danger);
}
.vm-pane__head {
  display: flex;
  flex: none;
  align-items: center;
  justify-content: space-between;
  height: 38px;
  padding: 0 12px;
  border-bottom: 1px solid var(--el-border-color-lighter);
}
.vm-pane__title {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
  font-weight: 600;
  color: var(--el-text-color-primary);
}
.vm-pane__count {
  padding: 0 6px;
  color: var(--el-text-color-secondary);
  font-size: 11px;
  font-weight: 400;
  line-height: 16px;
  background: var(--el-fill-color-light);
  border-radius: 8px;
}
.vm-pager {
  display: flex;
  flex: none;
  justify-content: flex-end;
  padding: 8px 12px;
  border-top: 1px solid var(--el-border-color-lighter);
}
.vm-error {
  flex: none;
  padding: 6px 12px;
  color: var(--el-color-danger);
  font-size: 12px;
  background: var(--el-color-danger-light-9);
}
.vm-timeline-wrap {
  min-height: 200px;
  padding: 22px 20px 26px;
  overflow-x: auto;
  overflow-y: hidden;
}
/* ============ 水平时间轴：实心起点 → 箭头 → 时钟节点 ============ */
.vm-timeline {
  display: flex;
  align-items: flex-start;
  width: max-content;
  min-width: 100%;
  /* 底部留足当前位置块高度，右侧留足 L 形引出块的横向延伸 */
  padding: 8px 150px 132px 0;
}
.vm-tl-track {
  display: flex;
  align-items: center;
}
/* 实心灰色起点圆 */
.vm-tl-origin {
  flex: none;
  width: 14px;
  height: 14px;
  margin-right: 4px;
  background: var(--el-text-color-placeholder);
  border-radius: 50%;
}
/* 粗灰色箭头（杆 + 三角） */
.vm-tl-arrow {
  position: relative;
  flex: 0 0 56px;
  height: 12px;
}
.vm-tl-arrow::before {
  position: absolute;
  top: 5px;
  right: 0;
  left: 0;
  height: 4px;
  content: '';
  background: var(--el-text-color-placeholder);
  border-radius: 2px;
}
.vm-tl-arrow::after {
  position: absolute;
  top: 1px;
  right: 0;
  content: '';
  border-top: 6px solid transparent;
  border-bottom: 6px solid transparent;
  border-left: 9px solid var(--el-text-color-placeholder);
}
/* 单个时钟节点 */
.vm-tl-node {
  position: relative;
  display: flex;
  flex: none;
  flex-direction: column;
  align-items: center;
  width: 74px;
  padding: 0 2px;
  cursor: pointer;
}
.vm-tl-face {
  position: relative;
  display: grid;
  width: 46px;
  height: 46px;
  place-items: center;
  background: var(--el-bg-color);
  border: 3px solid var(--el-text-color-placeholder);
  border-radius: 50%;
  transition:
    border-color 0.15s,
    transform 0.15s;
}
.vm-tl-node:hover .vm-tl-face {
  transform: translateY(-2px);
}
.vm-tl-clock {
  color: var(--el-text-color-placeholder);
  font-size: 22px;
}
/* 绿色旗标（沿时钟右下方向） */
.vm-tl-flag {
  position: absolute;
  top: 24px;
  left: 30px;
  width: 0;
  height: 0;
  border-top: 8px solid transparent;
  border-bottom: 8px solid transparent;
  border-left: 13px solid var(--el-color-success);
  transform: rotate(-8deg);
}
.vm-tl-label {
  max-width: 72px;
  margin-top: 10px;
  overflow: hidden;
  color: var(--el-text-color-primary);
  font-size: 12px;
  font-weight: 500;
  text-overflow: ellipsis;
  text-align: center;
  white-space: nowrap;
}
/* 选中节点：主色高亮 */
.vm-tl-node.is-selected .vm-tl-face {
  border-color: var(--el-color-primary);
  box-shadow: 0 0 0 4px var(--el-color-primary-light-9);
}
.vm-tl-node.is-selected .vm-tl-clock {
  color: var(--el-color-primary);
}
.vm-tl-node.is-selected .vm-tl-label {
  color: var(--el-color-primary);
  font-weight: 600;
}
/* 当前版本节点：绿色高亮 */
.vm-tl-node.is-current .vm-tl-face {
  border-color: var(--el-color-success);
}
.vm-tl-node.is-current .vm-tl-flag {
  border-left-color: var(--el-color-success);
}
/* ============ 当前版本向下引 L 形折线箭头 → 蓝色当前位置块 ============ */
.vm-tl-current {
  position: absolute;
  top: 100%;
  left: 50%;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}
.vm-tl-elbow {
  position: relative;
  width: 34px;
  height: 40px;
  border-bottom: 3px solid var(--el-text-color-placeholder);
  border-left: 3px solid var(--el-text-color-placeholder);
}
.vm-tl-elbow::after {
  position: absolute;
  right: -9px;
  bottom: -6px;
  content: '';
  border-top: 6px solid transparent;
  border-bottom: 6px solid transparent;
  border-left: 9px solid var(--el-text-color-placeholder);
}
.vm-tl-now {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  min-width: 104px;
  margin-top: -3px;
  margin-left: 38px;
  padding: 10px 12px;
  color: #fff;
  background: var(--el-color-primary);
  border-radius: 6px;
  box-shadow: 0 6px 16px -8px var(--el-color-primary);
}
.vm-tl-now__pin {
  font-size: 26px;
  color: #fff;
}
.vm-now-text {
  font-size: 12px;
  white-space: nowrap;
}
.vm-tl-now-ver {
  font-size: 11px;
  opacity: 0.85;
  font-variant-numeric: tabular-nums;
}
.vm-info__body {
  flex: 1;
  min-height: 0;
  padding: 10px 14px;
  overflow: auto;
}
.vm-info__lines {
  margin: 0;
  padding-left: 18px;
  color: var(--el-text-color-primary);
  font-size: 13px;
  line-height: 1.9;
}
.vm-info__muted {
  color: var(--el-text-color-placeholder);
  font-size: 13px;
}
.vm-info__summary {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-top: 10px;
}
.vm-info__ver {
  color: var(--el-text-color-secondary);
  font-size: 12px;
  font-weight: 400;
}
.vm-storage {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  margin-left: 4px;
  color: var(--el-text-color-secondary);
  font-size: 12px;
  font-weight: 400;
}
.vm-tl-actions {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  margin-left: auto;
}
</style>
