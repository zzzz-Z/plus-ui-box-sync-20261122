<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
interface CompareVersion {
  category: string;
  product: string;
  version: string;
}

interface CompareForm {
  type: string;
  sourceVersion: string;
  targetVersion: string;
}

const props = defineProps<{ versions: CompareVersion[] }>();
const emit = defineEmits<{ submit: [form: CompareForm] }>();

const form = ref();
const model = reactive<CompareForm>({ type: '', sourceVersion: '', targetVersion: '' });

// 类型选项：去重后的产品类别
const typeOptions = computed(() => [...new Set(props.versions.map((item) => item.category))].map((type) => ({ label: type, value: type })));
// 版本选项：随所选类型联动
const versionOptions = computed(() =>
  props.versions.filter((item) => item.category === model.type).map((item) => ({ label: `${item.product} ${item.version}`, value: item.version }))
);

// 切换类型时清空已选版本，避免跨类型残留
watch(
  () => model.type,
  () => {
    model.sourceVersion = '';
    model.targetVersion = '';
  }
);

function save() {
  if (model.sourceVersion === model.targetVersion) return { code: 1, message: pt('源版本与目标版本不能相同') };
  emit('submit', { ...model });
  return { code: 0, message: pt('版本比较完成') };
}

defineExpose({ save, form });
</script>

<template>
  <Form ref="form" :model="model" :span="24">
    <el-select v-model="model.type" :label="pt('类型')" :placeholder="pt('请选择类型')" :options="typeOptions" required />
    <el-select
      v-model="model.sourceVersion"
      :label="pt('源版本')"
      :placeholder="pt('请选择源版本')"
      :options="versionOptions"
      :disabled="!model.type"
      required
    />
    <el-select
      v-model="model.targetVersion"
      :label="pt('目标版本')"
      :placeholder="pt('请选择目标版本')"
      :options="versionOptions"
      :disabled="!model.type"
      required
    />
  </Form>
</template>
