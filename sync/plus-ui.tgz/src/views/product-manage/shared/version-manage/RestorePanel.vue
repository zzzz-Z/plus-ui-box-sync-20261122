<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
import { ref } from 'vue';
import { ElMessage } from 'element-plus';
import { restoreDataVersion } from '@/api/product-manage/platform/data-versions';

const props = defineProps<{
  resourceUid: string;
  versionUid: string;
  versionNo?: number;
}>();

const emit = defineEmits<{
  (e: 'close'): void;
  (e: 'restored'): void;
}>();

const reason = ref('');
const restoring = ref(false);

/** 提交恢复：requestId 保证幂等，成功后通知外层刷新版本日志与容量 */
async function submit() {
  if (!props.resourceUid || !props.versionUid) return;
  restoring.value = true;
  try {
    const body: { requestId: string; reason?: string } = {
      requestId: `restore-${Date.now()}-${props.versionUid.slice(0, 8)}`
    };
    const text = reason.value.trim();
    if (text) body.reason = text;
    const res = await restoreDataVersion(props.resourceUid, props.versionUid, body);
    ElMessage.success(`恢复成功，已生成新版本 v${res?.data?.newVersionNo ?? '—'}`);
    emit('restored');
    emit('close');
  } catch {
    // 具体失败原因（如 503 METADATA_VERSION_UNAVAILABLE）由 request 拦截器统一提示，此处不覆盖
  } finally {
    restoring.value = false;
  }
}

defineExpose({ submit });
</script>

<template>
  <div class="rp">
    <div class="rp-tip">
      {{ pt('将版本') }} <strong>v{{ versionNo ?? '—' }}</strong> {{ pt('的内容恢复为一个新版本，原版本保留不变。') }}
    </div>
    <div class="rp-field">
      <label class="rp-field__label">{{ pt('恢复原因') }}</label>
      <el-input v-model="reason" type="textarea" :rows="3" maxlength="200" show-word-limit :placeholder="pt('选填：说明恢复原因')" />
    </div>
    <div class="rp-footer">
      <el-button @click="emit('close')">{{ pt('取消') }}</el-button>
      <el-button type="primary" :loading="restoring" @click="submit">{{ pt('确认恢复') }}</el-button>
    </div>
  </div>
</template>

<style scoped lang="scss">
.rp {
  min-height: 180px;
}
.rp-tip {
  padding: 10px 12px;
  font-size: 12px;
  line-height: 1.6;
  color: var(--el-text-color-regular);
  background: var(--el-fill-color-light);
  border-radius: 4px;
}
.rp-field {
  margin-top: 16px;
}
.rp-field__label {
  display: block;
  margin-bottom: 6px;
  font-size: 12px;
  color: var(--el-text-color-secondary);
}
.rp-footer {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  margin-top: 18px;
}
</style>
