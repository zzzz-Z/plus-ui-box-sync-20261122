<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
/**
 * 新建数据更新任务面板（内联表单，随右侧「新建更新」tab 展示）。
 *
 * 创建流程：静默调 preview 接口取 previewFingerprint 并校验可更新性，再 POST 创建（指纹不匹配返回 409）。
 * UI 不展示预览按钮与比对列表，预览仅作为创建前的指纹/校验步骤。
 *
 * UI 对齐数据入库页「入库清单」：来源文件不再手填表格，改为 BrowseDialog（共享目录 / 共享路径 /
 * 本地上传三型共存）选文件 + SelectedFileTree 展示已选清单（可勾选决定入库范围、可拖拽改 targetPath、可移除）。
 * 表单字段（dataKey/updateMode/importName/priorityLevel/description/information/autoStart）与
 * 创建/预览接口契约逐项对齐，载荷只在 buildCreateUpdatePayload() 白名单里拼装。
 */
import { computed, h, ref, watch } from 'vue';
import { ElMessage } from 'element-plus';
import type { UploadUserFile } from 'element-plus';
import CryptoJS from 'crypto-js';
import { previewUpdate, createUpdate, buildCreateUpdatePayload, listUpdates } from './state';
import type { ResourceOption, UpdateFileInput, UpdateFileSource, UpdateMode, PriorityLevel, UpdateRow } from './state';
import {
  createDataUploadSession,
  putToSignedUrl,
  putDataUploadPart,
  finalizeDataUploadSession,
  isDataUploadReady
} from '@/api/product-manage/platform/ingestion';
import type { DataUploadFileDecl } from '@/api/product-manage/platform/ingestion';
import BrowseDialog from '../data-check/browse-dialog.vue';
import SelectedFileTree from '../data-check/selected-file-tree.vue';
import SourceToolbarActions from '../source-toolbar-actions.vue';
import { createDialog } from '@/composables/create-dialog';

defineOptions({ name: 'UpdateCreate' });

const props = defineProps<{ resources: ResourceOption[]; resourceUid?: string }>();

/** BrowseDialog 回传的来源选择结果（三型来源共用同一 payload 形状） */
interface PickPayload {
  locationUid?: string;
  dataRootPath?: string;
  path?: string;
  files?: string[];
  fileNames?: string[];
  targets?: string[];
}

/**
 * 来源批次：一次选择 = 一个批次，三型来源（共享目录 / 共享路径 / 本地上传）可共存于同一清单。
 * 契约 files[] 每条各带 source，同源合并、异源追加。
 */
interface SourceEntry {
  source: UpdateFileSource;
  label: string;
  files: string[];
  targets: string[];
  isUpload?: boolean;
  /** 被取消勾选的 sourcePath 集合；不在其中的文件默认勾选 */
  uncheckedPaths?: string[];
}

/** 入库清单树的一行（SelectedFileTree.TreeRow 子集） */
interface ManifestRow {
  id: string;
  sourcePath: string;
  targetPath: string;
  sourceLabel?: string;
  source: UpdateFileSource;
  /** 勾选态：由 SourceEntry.uncheckedPaths 派生，未记录视为勾选 */
  checked: boolean;
}

/** 左树选中资源后，从其更新记录 fileManifest 回填入库清单的文件条目 */
interface ManifestPickItem {
  sourcePath?: string;
  path?: string;
  fileName?: string;
  targetPath?: string;
  rootPath?: string;
  storageUid?: string;
  source?: UpdateFileSource;
}

const ROW_ID_SEP = '\u0000';

const modeOptions = [
  { label: pt('增量更新'), value: 'incremental' },
  { label: pt('全量替换'), value: 'replace' }
];
const priorityOptions = [
  { label: pt('高'), value: 'high' },
  { label: pt('中'), value: 'medium' },
  { label: pt('低'), value: 'low' }
];

const form = reactive({
  resourceUid: '',
  dataKey: '',
  updateMode: 'incremental' as UpdateMode,
  importName: '',
  priorityLevel: 'medium' as PriorityLevel,
  description: '',
  information: '',
  autoStart: true
});

const sourceEntries = ref<SourceEntry[]>([]);
const creating = ref(false);

// ---- 来源清单：稳定 key + 派生树行（对齐入库页 sourceKeyOf / buildSourceRows） ----
function sourceKeyOf(entry: SourceEntry): string {
  if (entry.isUpload || entry.source.uploadUid) return 'upload';
  if (entry.source.storageUid) return 'share:' + entry.source.storageUid + ':' + (entry.source.rootPath ?? '');
  return 'unc:' + (entry.source.rootPath ?? '');
}
function rowIdOf(entry: SourceEntry, sourcePath: string): string {
  return sourceKeyOf(entry) + ROW_ID_SEP + sourcePath;
}

/**
 * 追加（或合并）一个来源批次：三种来源可共存于同一清单。
 * 同源（sourceKeyOf 相同）合并 files/targets，同名 path 以最新 target 覆盖；不同源追加。
 * 合并时保留已取消勾选的路径（uncheckedPaths），只对新增文件默认勾选。
 */
function addSourceBatch(entry: SourceEntry) {
  const key = sourceKeyOf(entry);
  const exist = sourceEntries.value.find((item) => sourceKeyOf(item) === key);
  if (exist) {
    const merged: SourceEntry = {
      ...exist,
      source: { ...entry.source },
      label: entry.label,
      isUpload: entry.isUpload,
      uncheckedPaths: (exist.uncheckedPaths || []).slice()
    };
    merged.files = exist.files.slice();
    merged.targets = exist.targets.slice();
    for (let i = 0; i < entry.files.length; i += 1) {
      const path = entry.files[i];
      if (!path) continue;
      const at = merged.files.indexOf(path);
      if (at >= 0) {
        merged.targets[at] = entry.targets[i] || path;
      } else {
        merged.files.push(path);
        merged.targets.push(entry.targets[i] || path);
      }
    }
    sourceEntries.value = sourceEntries.value.map((item) => (item === exist ? merged : item));
  } else {
    sourceEntries.value = sourceEntries.value.concat([{ ...entry, files: entry.files.slice(), targets: entry.targets.slice(), uncheckedPaths: [] }]);
  }
}

/**
 * 用一次选择的全量结果替换「同一来源批次」，其它来源批次保持不变（三源共存）。
 * BrowseDialog 回传的是当前全部已选，用替换语义才能让「树里取消勾选」在清单里生效。
 * 保留该批次中仍存在文件的取消勾选态。
 */
function replaceSourceBatch(entry: SourceEntry) {
  const key = sourceKeyOf(entry);
  const at = sourceEntries.value.findIndex((item) => sourceKeyOf(item) === key);
  const keptUnchecked = at >= 0 ? (sourceEntries.value[at].uncheckedPaths || []).filter((p) => entry.files.includes(p)) : [];
  const next: SourceEntry = {
    ...entry,
    files: entry.files.slice(),
    targets: entry.targets.slice(),
    uncheckedPaths: keptUnchecked
  };
  if (at >= 0) {
    sourceEntries.value = sourceEntries.value.map((item, index) => (index === at ? next : item));
  } else if (next.files.length) {
    sourceEntries.value = sourceEntries.value.concat([next]);
  }
}

const manifestRows = computed<ManifestRow[]>(() => {
  const rows: ManifestRow[] = [];
  for (const entry of sourceEntries.value) {
    const unchecked = entry.uncheckedPaths || [];
    for (let i = 0; i < entry.files.length; i += 1) {
      const sp = entry.files[i];
      rows.push({
        id: rowIdOf(entry, sp),
        sourcePath: sp,
        targetPath: entry.targets[i] || sp,
        sourceLabel: entry.label,
        source: entry.source,
        checked: !unchecked.includes(sp)
      });
    }
  }
  return rows;
});

/** 仅勾选行参与预览/创建（取消勾选的文件不会入库） */
const checkedRows = computed<ManifestRow[]>(() => manifestRows.value.filter((r) => r.checked));

/**
 * 资源不再由表单内下拉选择，而是取左侧资源树当前选中节点：
 *  - 选中具体资源节点 → 该资源 uid；
 *  - 选中类别 / 全部 → 取派生资源清单的第一个（表单一次只更新一个资源）。
 */
const effectiveResourceUid = computed(() => props.resourceUid || props.resources[0]?.uid || '');
const currentResource = computed(() => props.resources.find((r) => r.uid === effectiveResourceUid.value) ?? null);
const currentResourceLabel = computed(() => currentResource.value?.label || '');

watch(
  effectiveResourceUid,
  (uid) => {
    form.resourceUid = uid;
  },
  { immediate: true }
);

/** 任务名称自动生成：资源名-更新-时间戳；手改非空即锁定，清空回落（对齐入库页 autoBatchName） */
const importNameEdited = ref(false);
const autoImportName = computed(() => {
  if (!currentResourceLabel.value) return '';
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, '0');
  const ts = `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
  return `${currentResourceLabel.value}-更新-${ts}`;
});
watch(autoImportName, (name) => {
  if (!importNameEdited.value) form.importName = name;
});
function handleImportNameInput() {
  if ((form.importName || '').trim()) importNameEdited.value = true;
  else {
    importNameEdited.value = false;
    form.importName = autoImportName.value;
  }
}

// ---- BrowseDialog 选源 ----
function labelOfShare(rootPath: string): string {
  const segs = String(rootPath || '')
    .replace(/\\/g, '/')
    .split('/')
    .filter(Boolean);
  return segs.length ? segs[segs.length - 1] : pt('共享根');
}
function onPick(payload: PickPayload, sourceType: 'registered_share' | 'direct_shared_path') {
  const storageUid = sourceType === 'registered_share' ? payload.locationUid || '' : '';
  const rootPath = payload.dataRootPath || payload.path || '';
  const files = payload.files || [];
  const targets = payload.targets || files;
  if (!files.length || !rootPath) {
    ElMessage.warning(pt('未选择到可用文件'));
    return;
  }
  // 三型来源共存：只替换/合并本来源批次，其它来源保留
  replaceSourceBatch({
    source: { ...(storageUid ? { storageUid } : {}), rootPath },
    label: labelOfShare(rootPath),
    files,
    targets
  });
}
function openBrowseDialog(sourceType: 'registered_share' | 'direct_shared_path') {
  const title = sourceType === 'registered_share' ? pt('选择共享目录来源') : pt('添加共享路径来源');
  const dialog = createDialog({
    title,
    width: '820px',
    footer: false,
    closeOnClickModal: false,
    bodyStyle: { padding: '12px 16px', display: 'flex', flexDirection: 'column', overflow: 'hidden' },
    render: () =>
      h(BrowseDialog, {
        sourceType,
        pickFilter: 'selectable',
        mode: 'auto',
        metadataOnly: false,
        live: true,
        locationUid: '',
        path: '',
        files: [],
        // live 模式：点击/勾选左侧文件树即回填入库清单，不关闭弹窗，可继续勾选
        onPick: (payload: PickPayload) => {
          onPick(payload, sourceType);
        },
        onCancel: () => dialog?.close()
      })
  });
}
function openShareDirDialog() {
  openBrowseDialog('registered_share');
}
function addUncSource() {
  openBrowseDialog('direct_shared_path');
}

// ---- 本地上传（复用入库页 data-uploads 会话流程，产出 uploadUid） ----
const uploadPickerRef = ref<HTMLInputElement>();
const uploadFileList = ref<UploadUserFile[]>([]);
const uploadProgress = ref('');
/** 点左侧资源树加载已有更新记录时的 loading（与上传进度互斥展示，清单区遮罩） */
const manifestLoading = ref(false);
function uploadPathOf(item: UploadUserFile): string {
  const raw = item.raw as (File & { webkitRelativePath?: string }) | undefined;
  return raw?.webkitRelativePath || raw?.name || item.name || '';
}
async function sha256Hex(bytes: ArrayBuffer): Promise<string> {
  if (globalThis.crypto?.subtle) {
    const digest = await crypto.subtle.digest('SHA-256', bytes);
    return Array.from(new Uint8Array(digest))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
  }
  return CryptoJS.SHA256(CryptoJS.lib.WordArray.create(bytes)).toString();
}
async function uploadPendingFiles(): Promise<string> {
  const items = uploadFileList.value.filter((item) => !!item.raw);
  if (!items.length) return '';
  uploadProgress.value = '准备上传…';
  try {
    const payloads = await Promise.all(
      items.map(async (item) => {
        const raw = item.raw as File;
        const bytes = await raw.arrayBuffer();
        return { name: uploadPathOf(item), bytes, size: raw.size, sha256: await sha256Hex(bytes) };
      })
    );
    // 文件声明只允许 path/sizeBytes/sha256，多传字段会被后端判 400
    const decls: DataUploadFileDecl[] = payloads.map((p) => ({ path: p.name, sizeBytes: p.size, sha256: p.sha256 }));
    const created = await createDataUploadSession(decls);
    const session = created?.data;
    const uploadUid = String(session?.uploadUid || '');
    if (!uploadUid) throw new Error(pt('上传会话创建失败：未返回 uploadUid'));
    const tickets = session?.files ?? [];
    for (let i = 0; i < payloads.length; i += 1) {
      const payload = payloads[i];
      const ticket = tickets[i]?.path === payload.name ? tickets[i] : tickets.find((t) => t.path === payload.name);
      if (!ticket?.fileUid) throw new Error('上传会话缺少文件指令：' + payload.name);
      uploadProgress.value = `上传中 ${i + 1}/${payloads.length}：${payload.name}`;
      if (ticket.parts?.length) {
        let offset = 0;
        for (const part of ticket.parts) {
          const size = part.sizeBytes ?? payload.size;
          await putToSignedUrl(part.uploadUrl, payload.bytes.slice(offset, offset + size));
          offset += size;
        }
      } else if (ticket.uploadUrl) {
        await putToSignedUrl(ticket.uploadUrl, payload.bytes);
      } else {
        await putDataUploadPart(uploadUid, ticket.fileUid, 1, payload.bytes);
      }
    }
    uploadProgress.value = '校验上传结果…';
    const finalized = await finalizeDataUploadSession(uploadUid);
    if (!isDataUploadReady(finalized?.data)) throw new Error(pt('上传会话未就绪（state 非 READY 或已过期），请重试'));
    return uploadUid;
  } finally {
    uploadProgress.value = '';
  }
}
function triggerUploadPicker() {
  uploadPickerRef.value?.click();
}
async function onUploadPicked(event: Event) {
  const input = event.target as HTMLInputElement;
  const files = Array.from(input.files || []);
  if (!files.length) return;
  uploadFileList.value = files.map((f) => ({ name: f.name, raw: f }) as UploadUserFile);
  try {
    const uploadUid = await uploadPendingFiles();
    const paths = uploadFileList.value.map(uploadPathOf);
    addSourceBatch({ source: { uploadUid }, label: pt('本地上传'), files: paths, targets: [...paths], isUpload: true });
    ElMessage.success(`已上传 ${paths.length} 个文件`);
  } catch {
    // 上传接口拦截器已提示；保留清单不变
  } finally {
    input.value = '';
  }
}

// ---- 清单树交互（拖拽改 targetPath / 移除 / 清空） ----
function onRowMove({ id, targetPath }: { id: string; targetPath: string }) {
  for (const entry of sourceEntries.value) {
    const idx = entry.files.findIndex((sp) => rowIdOf(entry, sp) === id);
    if (idx >= 0) {
      entry.targets[idx] = targetPath;
      break;
    }
  }
}
function onRowRemove(id: string) {
  for (let ei = 0; ei < sourceEntries.value.length; ei += 1) {
    const entry = sourceEntries.value[ei];
    const idx = entry.files.findIndex((sp) => rowIdOf(entry, sp) === id);
    if (idx >= 0) {
      entry.files.splice(idx, 1);
      entry.targets.splice(idx, 1);
      if (!entry.files.length) sourceEntries.value.splice(ei, 1);
      break;
    }
  }
}
function onRowCheck({ id, checked }: { id: string; checked: boolean }) {
  for (const entry of sourceEntries.value) {
    const idx = entry.files.findIndex((sp) => rowIdOf(entry, sp) === id);
    if (idx < 0) continue;
    const sp = entry.files[idx];
    const set = new Set(entry.uncheckedPaths || []);
    if (checked) set.delete(sp);
    else set.add(sp);
    entry.uncheckedPaths = [...set];
    break;
  }
}

/** 勾选行 → 契约 files[]（三型来源逐条下发；未勾选文件不入库） */
function toInputs(): UpdateFileInput[] {
  return checkedRows.value.map((row) => ({
    sourcePath: row.sourcePath,
    targetPath: row.targetPath || row.sourcePath,
    source: { ...row.source }
  }));
}

function validateBase(): string | null {
  if (!form.resourceUid) return pt('请选择资源');
  if (!manifestRows.value.length) return pt('请先在入库清单中添加来源文件');
  if (!checkedRows.value.length) return pt('请至少勾选一个入库文件');
  return null;
}

/** 静默预览：创建前取后端指纹并校验可更新性（UI 不再展示预览按钮与比对列表） */
async function fetchFingerprint(): Promise<string | null> {
  try {
    const payload = {
      files: toInputs(),
      ...(form.dataKey ? { dataKey: form.dataKey } : {}),
      updateMode: form.updateMode,
      ...(form.information ? { information: form.information } : {})
    };
    const res = await previewUpdate(form.resourceUid, payload);
    const data = res?.data;
    if (!data?.canUpdate) {
      ElMessage.warning(data?.blockedReason || '文件比对未通过，无法创建更新');
      return null;
    }
    if (!data.previewFingerprint) {
      ElMessage.warning(pt('未能获取预览指纹，请重试'));
      return null;
    }
    return data.previewFingerprint;
  } catch {
    // 拦截器已提示
    return null;
  }
}

/** 创建：静默取指纹后提交；requestId 幂等。返回码供父组件决定切 tab 与刷新 */
async function save(): Promise<{ code?: number; message?: string } | undefined> {
  const err = validateBase();
  if (err) {
    ElMessage.warning(err);
    return undefined;
  }
  creating.value = true;
  try {
    const fingerprint = await fetchFingerprint();
    if (!fingerprint) return undefined;
    const built = buildCreateUpdatePayload({
      files: toInputs(),
      previewFingerprint: fingerprint,
      ...(form.dataKey ? { dataKey: form.dataKey } : {}),
      updateMode: form.updateMode,
      ...(form.information ? { information: form.information } : {}),
      ...(form.importName ? { importName: form.importName } : {}),
      priorityLevel: form.priorityLevel,
      ...(form.description ? { description: form.description } : {}),
      requestId: crypto.randomUUID(),
      autoStart: form.autoStart
    });
    if (!built.ok || !built.payload) {
      ElMessage.warning(built.message || '创建参数无效');
      return undefined;
    }
    await createUpdate(form.resourceUid, built.payload);
    resetForm();
    return { code: 0, message: pt('数据更新任务已创建') };
  } catch {
    // 拦截器已提示（409 指纹/版本冲突等）
    return undefined;
  } finally {
    creating.value = false;
  }
}

function resetForm() {
  form.resourceUid = effectiveResourceUid.value;
  form.dataKey = '';
  form.updateMode = 'incremental';
  importNameEdited.value = false;
  form.importName = autoImportName.value;
  form.priorityLevel = 'medium';
  form.description = '';
  form.information = '';
  form.autoStart = true;
  sourceEntries.value = [];
  uploadFileList.value = [];
}

/**
 * 从左侧资源树点选的资源里，取其更新记录 fileManifest 的文件回填入库清单。
 * 每个资源取最近一条含 fileManifest 的更新记录；同源批次按 sourceKey 合并，异源追加（三源共存）。
 */
async function addFromExistingUpdates(resources: ResourceOption[], existingUpdates?: UpdateRow[]) {
  if (!resources.length) return;
  // 切换资源即代表更换更新清单：先清空旧批次（含手动选源），再按新资源回填
  sourceEntries.value = [];
  uploadFileList.value = [];
  manifestLoading.value = true;
  let added = 0;
  try {
    const rowPool = existingUpdates ?? [];
    for (const res of resources) {
      try {
        const items: UpdateRow[] = rowPool.length
          ? rowPool.filter((row) => row.resourceUid === res.uid)
          : ((await listUpdates(res.uid, { page: 1, pageSize: 50 }))?.data?.items ?? []);
        const hit = items.find((row) => Array.isArray((row as any).fileManifest) && (row as any).fileManifest.length);
        const manifest = ((hit as any)?.fileManifest ?? []) as ManifestPickItem[];
        const files = manifest.map((m) => String(m.sourcePath ?? m.path ?? m.fileName ?? '')).filter(Boolean);
        if (!files.length) continue;
        const targets = manifest.map((m, i) => String(m.targetPath ?? files[i]));
        const src = manifest.find((m) => m.source)?.source;
        const storageUid = String(src?.storageUid ?? '');
        const rootPath = String(src?.rootPath ?? '');
        addSourceBatch({
          source: { ...(storageUid ? { storageUid } : {}), ...(rootPath ? { rootPath } : {}) },
          label: rootPath ? labelOfShare(rootPath) : res.label,
          files,
          targets
        });
        added += files.length;
      } catch {
        // 单资源查询失败不影响其它资源
      }
    }
  } finally {
    manifestLoading.value = false;
  }
  if (added) ElMessage.success(`已从更新记录添加 ${added} 个文件到入库清单`);
}

/** 暴露业务方法给父组件（对齐入库 Edit 的 defineExpose 口径，不外泄内部 ref 数据） */
defineExpose({ save, resetForm, addFromExistingUpdates });
</script>

<template>
  <div class="create-panel">
    <div class="create-body">
      <el-form label-width="120px" class="create-form">
        <!-- 卡片 1：基本信息（高度由内容决定） -->
        <section class="edit-card edit-card--basic">
          <h3 class="edit-card__title">{{ pt('基本信息') }}</h3>
          <div class="edit-card__body">
            <el-row :gutter="16">
              <el-col :span="12">
                <el-form-item :label="pt('资源')" required>
                  <el-input :model-value="currentResourceLabel" readonly :placeholder="pt('请先在左侧资源树选择资源')" class="field-full" />
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item :label="pt('数据键')">
                  <el-input v-model="form.dataKey" :placeholder="pt('资源只有一个 dataKey 时可留空')" />
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item :label="pt('任务名称')">
                  <el-input
                    v-model="form.importName"
                    :placeholder="pt('按资源自动生成，可修改，≤160 字')"
                    maxlength="160"
                    @input="handleImportNameInput"
                  />
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item :label="pt('更新方式')">
                  <el-select v-model="form.updateMode" class="field-full">
                    <el-option v-for="o in modeOptions" :key="o.value" :label="o.label" :value="o.value" />
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item :label="pt('优先级')">
                  <el-select v-model="form.priorityLevel" class="field-full">
                    <el-option v-for="o in priorityOptions" :key="o.value" :label="o.label" :value="o.value" />
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item :label="pt('自动开始')">
                  <el-switch v-model="form.autoStart" />
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item :label="pt('任务说明')">
                  <el-input v-model="form.description" type="textarea" :rows="2" maxlength="500" :placeholder="pt('写入任务说明，≤500 字')" />
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item :label="pt('版本信息')">
                  <el-input v-model="form.information" type="textarea" :rows="2" maxlength="500" :placeholder="pt('写入版本日志，≤500 字')" />
                </el-form-item>
              </el-col>
            </el-row>
          </div>
        </section>

        <!-- 卡片 2：更新清单（对齐数据入库页：三型来源 + 已选文件树） -->
        <section class="edit-card edit-card--list">
          <div class="edit-card__header">
            <h3 class="edit-card__title">{{ pt('更新清单') }}</h3>
            <div class="edit-card__header-actions">
              <SourceToolbarActions @share-dir="openShareDirDialog" @share-path="addUncSource" @upload="triggerUploadPicker" />
            </div>
          </div>
          <div
            v-loading="!!uploadProgress || manifestLoading"
            :element-loading-text="uploadProgress ? '上传文件中…' : '正在加载更新记录文件…'"
            class="edit-card__body list-body"
          >
            <SelectedFileTree
              :rows="manifestRows"
              empty-text="尚未选择来源文件，请从「共享目录 / 共享路径 / 本地上传」或点击左侧文件树添加"
              tip="勾选决定入库范围（未勾选文件不会入库）；拖动文件到目录可改变目标路径。"
              :max-height="0"
              checkable
              :editable="false"
              :show-path="false"
              :show-count="false"
              :removable="false"
              @check="onRowCheck"
              @move="onRowMove"
              @remove="onRowRemove"
            />
          </div>
          <input ref="uploadPickerRef" type="file" multiple class="hidden-picker" @change="onUploadPicked" />
        </section>
      </el-form>
    </div>
  </div>
</template>

<style scoped lang="scss">
.create-panel {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
  overflow: hidden;
}
.create-body {
  flex: 1 1 auto;
  min-height: 0;
  padding: 4px 2px;
  box-sizing: border-box;
  overflow: hidden;
}
.create-form {
  display: flex;
  flex-direction: column;
  gap: 16px;
  height: 100%;
  min-height: 0;
}
/* 卡片本体显式白底：覆盖 .content 可能透出的淡蓝斜纹 */
.edit-card {
  display: flex;
  flex-direction: column;
  min-height: 0;
  background: var(--el-fill-color-blank);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 6px;
  overflow: hidden;

  &--basic {
    flex: none;
  }
  &--list {
    flex: 1 1 0;
    min-height: 120px;
  }
}
.edit-card__header {
  display: flex;
  flex: none;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 0 16px;
  background: var(--el-fill-color-blank);
  border-bottom: 1px solid var(--el-border-color-lighter);
}
.edit-card__header-actions {
  display: flex;
  align-items: center;
  gap: 8px;
}
.edit-card__title {
  margin: 0;
  padding: 12px 16px;
  font-size: 14px;
  font-weight: 600;
  color: var(--el-text-color-primary);
  background: var(--el-fill-color-blank);
  border-bottom: 1px solid var(--el-border-color-lighter);
}
.edit-card__header .edit-card__title {
  padding: 12px 0;
  border-bottom: 0;
}
.edit-card__body {
  min-height: 0;
  padding: 16px 16px 4px;

  .el-form-item {
    margin-bottom: 12px;
  }
}
/* 清单卡片：树占满剩余高度并内部滚动 */
.list-body {
  display: flex;
  flex: 1 1 auto;
  flex-direction: column;
  min-height: 0;
  padding: 8px 12px;
  overflow: hidden;
}
.hidden-picker {
  display: none;
}
/* 选择类控件铺满表单项宽度 */
.field-full {
  width: 100%;
}
</style>
