<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
/**
 * 数据更新任务详情 —— 由 createDialog 以独立 vnode 挂到 body 承载。
 *
 * 对齐「数据入库」detail.vue 的范式：详情承载基础信息、文件清单、日志、报告四块语义，
 * 加上一个「调整优先级」的独立写动作；不 defineExpose save，底部按钮由调用方 footer:false
 * 隐藏，保存反馈由本组件自己 ElMessage 提示。所需上下文全部走 props（createDialog 挂到 body，
 * 本组件拿不到父页面的 inject）。
 *
 * 数据来自专属接口族 /platform/updates：详情 getUpdate / 日志 getUpdateLog / 报告
 * getUpdateReport / 改优先级 patchUpdate，列表行只作为 initial 骨架先渲染避免白屏。
 */
import { Refresh } from '@element-plus/icons-vue';
import { ElMessage } from 'element-plus';
import { getUpdate, patchUpdate, getUpdateLog, getUpdateReport, statusOf, isTerminal, priorityText } from './state';
import type { UpdateRow, UpdateLogItem, UpdateReport, PriorityLevel } from './state';

defineOptions({ name: 'UpdateDetail' });

const props = defineProps<{
  updateUid: string;
  /** 列表行初值：先渲染骨架，随后被详情接口覆盖 */
  initial?: UpdateRow | null;
}>();

const emit = defineEmits<{ changed: [] }>();

const detail = ref<UpdateRow | null>(props.initial ?? null);
const loading = ref(false);
const loadError = ref('');

/** 日志（游标分页拉全量） */
const logs = ref<UpdateLogItem[]>([]);
const logsLoading = ref(false);

/** 报告 */
const report = ref<UpdateReport | null>(null);
const reportLoading = ref(false);

/** 调整优先级 */
const priorityOptions = [
  { label: pt('高'), value: 'high' },
  { label: pt('中'), value: 'medium' },
  { label: pt('低'), value: 'low' }
];
const priorityValue = ref<PriorityLevel>('medium');
const savingPriority = ref(false);

/** 状态展示口径（与列表页同源） */
const stateView = computed(() => statusOf(detail.value ?? ({} as UpdateRow)));

/** 进度百分比文案 */
const progressPercentText = computed(() => {
  const raw = detail.value?.progress?.percent;
  return typeof raw === 'number' ? `${Math.round(raw)}%` : '-';
});

/** 新版本号：接口放在 update.newVersionNo，顶层 versionNo 兜底，带 V 前缀（不显示 newVersionUid 机器码） */
const versionText = computed(() => {
  const v = (detail.value as any)?.update?.newVersionNo ?? (detail.value as any)?.versionNo;
  return v == null || v === '' ? '-' : `V${v}`;
});

/** 文件清单（updateManifest 结构可能因版本不同字段略有差异，逐字段兜底展示） */
interface ManifestRow {
  seq: number;
  sourcePath: string;
  targetPath: string;
  status: string;
  raw: string;
}
const manifestRows = computed<ManifestRow[]>(() => {
  const items = detail.value?.updateManifest ?? [];
  return items.map((item: any, i: number) => {
    const obj = item && typeof item === 'object' ? item : { value: item };
    return {
      seq: i + 1,
      sourcePath: String(obj.sourcePath ?? obj.path ?? obj.fileName ?? obj.name ?? '-'),
      targetPath: String(obj.targetPath ?? obj.newPath ?? '-'),
      status: String(obj.status ?? obj.action ?? obj.result ?? '-'),
      raw: JSON.stringify(obj)
    };
  });
});

/**
 * 报告错误明细：接口报告体没有 errors 数组，真实来源是更新日志里 type='error' 的条目
 * （errorCount 与这类日志条数一致）；报告 errorMessage 作为兜底，避免「错误数 N / 明细 0」对不上。
 */
const reportErrors = computed<string[]>(() => {
  // 成功任务不展示错误明细：即便日志/报告里残留兜底文案也不显示
  if (report.value?.state === 'SUCCEEDED' || report.value?.stateText === '成功') return [];
  const fromLogs = logs.value
    .filter((item) => String((item as any).type || '') === 'error')
    .map((item) => logMessage(item))
    .filter(Boolean);
  if (fromLogs.length) return fromLogs;
  const fallback = String((report.value as any)?.errorMessage || '').trim();
  return fallback ? [fallback] : [];
});

/** 日志类型机器值 → 中文标签（接口返回 type: version/state/file-completed 等，不能直接展示） */
const LOG_TYPE_TEXT: Record<string, string> = {
  version: pt('版本'),
  state: '状态',
  'file-completed': '文件完成',
  'file-added': '文件新增',
  'file-updated': '文件更新',
  'file-removed': '文件移除',
  error: pt('错误')
};
function logTypeText(type: unknown) {
  const key = String(type ?? '');
  return LOG_TYPE_TEXT[key] || (key ? pt('事件') : pt('日志'));
}

/** 日志正文：接口无 message 字段，按 type 拼业务文案，绝不暴露 uid 机器码 */
function logMessage(item: UpdateLogItem) {
  const x = item as any;
  if (x.message) return String(x.message);
  if (x.type === 'version') return `生成版本 V${x.versionNo ?? '-'}`;
  if (x.type === 'state') return String(x.stateText || x.state || '状态变更');
  if (String(x.type || '').startsWith('file-')) return String(x.targetPath || x.sourcePath || x.fileName || '文件处理');
  return String(x.stateText || x.hint || '');
}

/** 非终态才允许调整优先级 */
const canAdjustPriority = computed(() => !!detail.value && !isTerminal(detail.value));

async function loadDetail() {
  if (!props.updateUid) return;
  loading.value = true;
  loadError.value = '';
  try {
    const res = await getUpdate(props.updateUid);
    detail.value = (res?.data ?? detail.value) as UpdateRow;
    priorityValue.value = ((detail.value as any)?.priorityLevel as PriorityLevel) || 'medium';
  } catch {
    loadError.value = '加载详情失败';
  } finally {
    loading.value = false;
  }
}

async function loadLogs() {
  if (!props.updateUid) return;
  logsLoading.value = true;
  try {
    const acc: UpdateLogItem[] = [];
    let cursor = '';
    for (let i = 0; i < 100; i++) {
      const res = await getUpdateLog(props.updateUid, { cursor: cursor || undefined, limit: 100 });
      const items: UpdateLogItem[] = res?.data?.items ?? [];
      acc.push(...items);
      const next = res?.data?.nextCursor;
      if (!next || !items.length) break;
      cursor = next;
    }
    logs.value = acc;
  } catch {
    // 拦截器已提示
  } finally {
    logsLoading.value = false;
  }
}

async function loadReport() {
  if (!props.updateUid) return;
  reportLoading.value = true;
  try {
    const res = await getUpdateReport(props.updateUid);
    report.value = (res?.data ?? null) as UpdateReport | null;
  } catch {
    // 拦截器已提示
  } finally {
    reportLoading.value = false;
  }
}

async function reloadAll() {
  await Promise.all([loadDetail(), loadLogs(), loadReport()]);
}

/** 调整优先级（PATCH，运行中亦允许；409 由拦截器提示） */
async function savePriority() {
  if (!props.updateUid || savingPriority.value) return;
  savingPriority.value = true;
  try {
    await patchUpdate(props.updateUid, { priorityLevel: priorityValue.value });
    ElMessage.success(pt('优先级已更新'));
    await loadDetail();
    emit('changed');
  } catch {
    // 拦截器已提示（409 状态冲突等）
  } finally {
    savingPriority.value = false;
  }
}

onMounted(() => {
  reloadAll();
});
</script>

<template>
  <div v-loading="loading" class="update-detail">
    <el-alert v-if="loadError" :title="loadError" type="error" show-icon :closable="false" class="detail-alert" />

    <!-- 基础信息 -->
    <section class="section">
      <header class="section-head">
        <span class="section-accent" />
        <h3 class="section-title">{{ pt('基础信息') }}</h3>
        <el-button class="section-action" :icon="Refresh" size="small" link @click="reloadAll">{{ pt('刷新') }}</el-button>
      </header>
      <el-descriptions :column="2" border size="small">
        <el-descriptions-item :label="pt('任务名称')">{{
          String((detail as any)?.importName || (detail as any)?.dataName || '-')
        }}</el-descriptions-item>
        <el-descriptions-item :label="pt('执行状态')">
          <el-tag :type="stateView.type" size="small">{{ String((detail as any)?.stateText || stateView.text) }}</el-tag>
        </el-descriptions-item>
        <el-descriptions-item :label="pt('资源')">{{ String((detail as any)?.resourceName || '-') }}</el-descriptions-item>
        <el-descriptions-item :label="pt('数据名称')">{{
          String((detail as any)?.dataName || (detail as any)?.importName || '-')
        }}</el-descriptions-item>
        <el-descriptions-item :label="pt('优先级')">{{ priorityText((detail as any)?.priorityLevel) }}</el-descriptions-item>
        <el-descriptions-item :label="pt('进度')">
          <span :class="{ 'text-error': stateView.text === '更新失败' }">{{ progressPercentText }}</span>
          <span v-if="(detail as any)?.progress?.stageText" class="stage-text"> · {{ (detail as any).progress.stageText }}</span>
        </el-descriptions-item>
        <el-descriptions-item :label="pt('新版本')">{{ versionText }}</el-descriptions-item>
        <el-descriptions-item :label="pt('版本状态')">{{
          String((detail as any)?.versionStateName || (detail as any)?.versionState || '-')
        }}</el-descriptions-item>
        <el-descriptions-item :label="pt('回滚标记')">{{ detail?.rolledBack ? '已回滚' : '否' }}</el-descriptions-item>
        <el-descriptions-item v-if="(detail as any)?.description" :label="pt('描述')" :span="2">{{
          (detail as any).description
        }}</el-descriptions-item>
      </el-descriptions>
    </section>

    <!-- 调整优先级：非终态可见 -->
    <section v-if="canAdjustPriority" class="section">
      <header class="section-head">
        <span class="section-accent" />
        <h3 class="section-title">{{ pt('调整优先级') }}</h3>
      </header>
      <div class="priority-action">
        <el-select v-model="priorityValue" size="small" style="width: 140px">
          <el-option v-for="opt in priorityOptions" :key="opt.value" :label="opt.label" :value="opt.value" />
        </el-select>
        <el-button type="primary" size="small" plain :loading="savingPriority" @click="savePriority">{{ pt('保存') }}</el-button>
        <span>{{ pt('运行中亦可直接调整，立即生效。') }}</span>
      </div>
    </section>

    <!-- 文件清单 -->
    <section class="section">
      <header class="section-head">
        <span class="section-accent" />
        <h3 class="section-title">{{ pt('文件清单') }}</h3>
        <span class="count-badge">{{ manifestRows.length }}</span>
      </header>
      <el-empty v-if="!manifestRows.length" :description="pt('暂无文件清单')" :image-size="60" />
      <el-table v-else :data="manifestRows" size="small" border max-height="300">
        <el-table-column type="index" :label="pt('序号')" width="60" />
        <el-table-column :label="pt('来源路径')" prop="sourcePath" min-width="200" show-overflow-tooltip />
        <el-table-column :label="pt('目标路径')" prop="targetPath" min-width="200" show-overflow-tooltip />
        <el-table-column :label="pt('状态')" prop="status" width="110" />
      </el-table>
    </section>

    <!-- 更新日志 -->
    <section class="section">
      <header class="section-head">
        <span class="section-accent" />
        <h3 class="section-title">{{ pt('更新日志') }}</h3>
        <span class="count-badge">{{ logs.length }}</span>
      </header>
      <div v-loading="logsLoading" class="log-list">
        <el-timeline v-if="logs.length">
          <el-timeline-item v-for="(item, i) in logs" :key="i" :timestamp="(item as any).at || item.createdAt || ''" placement="top">
            <span class="log-type">{{ logTypeText(item.type) }}</span>
            <span>{{ logMessage(item) }}</span>
          </el-timeline-item>
        </el-timeline>
        <el-empty v-else-if="!logsLoading" :description="pt('暂无日志')" :image-size="60" />
      </div>
    </section>

    <!-- 更新报告 -->
    <section class="section">
      <header class="section-head">
        <span class="section-accent" />
        <h3 class="section-title">{{ pt('更新报告') }}</h3>
      </header>
      <div v-loading="reportLoading" class="report-body">
        <template v-if="report">
          <el-descriptions :column="2" border size="small">
            <el-descriptions-item :label="pt('数据名称')">{{
              String((detail as any)?.dataName || (detail as any)?.importName || '-')
            }}</el-descriptions-item>
            <el-descriptions-item :label="pt('新版本')">{{ report.newVersionNo != null ? `V${report.newVersionNo}` : '-' }}</el-descriptions-item>
            <el-descriptions-item :label="pt('执行状态')">{{ report.stateText || '-' }}</el-descriptions-item>
            <el-descriptions-item :label="pt('文件数')">{{ report.fileCount ?? (report as any).completedFiles ?? 0 }}</el-descriptions-item>
            <el-descriptions-item :label="pt('完成 / 总数')"
              >{{ (report as any).completedFiles ?? 0 }} / {{ report.fileCount ?? 0 }}</el-descriptions-item
            >
            <el-descriptions-item :label="pt('错误数')">{{ report.errorCount ?? 0 }}</el-descriptions-item>
          </el-descriptions>
          <template v-if="reportErrors.length">
            <div class="report-subtitle">错误明细（{{ reportErrors.length }}）</div>
            <el-table :data="reportErrors.map((e) => ({ message: e }))" size="small" border max-height="240">
              <el-table-column type="index" :label="pt('序号')" width="60" />
              <el-table-column :label="pt('错误内容')" prop="message" show-overflow-tooltip />
            </el-table>
          </template>
        </template>
        <el-empty v-else-if="!reportLoading" description="暂无报告" :image-size="60" />
      </div>
    </section>
  </div>
</template>

<style scoped lang="scss">
.update-detail {
  display: flex;
  flex-direction: column;
  gap: 20px;
  padding: 4px 0;
}

.detail-alert {
  margin-bottom: 0;
}

.text-error {
  color: var(--el-color-danger);
  font-weight: 600;
}

.stage-text {
  color: var(--el-text-color-secondary);
  font-size: 12px;
}

.section {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.section-head {
  display: flex;
  align-items: center;
  gap: 8px;
  min-height: 22px;
}

.section-accent {
  flex: 0 0 auto;
  width: 3px;
  height: 14px;
  border-radius: 2px;
  background: var(--el-color-primary);
}

.section-title {
  margin: 0;
  color: var(--el-text-color-primary);
  font-size: 14px;
  font-weight: 600;
}

.section-action {
  margin-left: auto;
}

.priority-action {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 12px;
  color: var(--el-text-color-secondary);
}

.count-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 20px;
  height: 20px;
  padding: 0 6px;
  color: var(--el-text-color-secondary);
  font-size: 12px;
  font-weight: 500;
  background: var(--el-fill-color);
  border-radius: 10px;
}

.log-list {
  min-height: 80px;
  max-height: 360px;
  overflow: auto;
}
.log-type {
  margin-right: 8px;
  color: var(--el-color-primary);
  font-size: 12px;
}

.report-body {
  min-height: 100px;
}
.report-subtitle {
  margin: 14px 0 8px;
  font-size: 13px;
  font-weight: 600;
}
</style>
