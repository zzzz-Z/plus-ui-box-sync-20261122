<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
/**
 * 数据更新任务页左侧资源树 —— 直接使用「数据浏览」那棵树。
 *
 * 数据源与 data-browse/index.vue 完全一致：GET /platform/metadata/tree
 * （getMetadataBrowseTree），后端直接返回「产品类别 → 资源」递归树，前端只做
 * 产品线根收窄与空枝剪枝。
 *
 * 交互口径对齐「数据入库」左树（product-type-tree.vue）：
 *   - 单选点选（不再复选）；再次点击已选节点 = 取消选中（回到「全部资源」）；
 *   - 对外只暴露 v-model（节点 key：`res:<uid>` / `cat:<uid>`，空串 = 全部资源）作为选中真源，
 *     选中节点对应的「资源 uid 集合 + 资源清单」由本组件派生后 change 回传父页面，
 *     父页面据此刷新任务列表（数据更新按 resourceUid 查任务）。
 *   - 新建更新面板也用回传的资源清单选资源；头部的「显示全部」图标按钮可显式清空筛选。
 *   - 不回写 tree-host 的 checkedCount / hasContent：右栏任务表格恒有内容，是否被
 *     布局收起由外层 index.vue 在 onMounted 认领 hasContent=true 统一决定。
 */
import { CircleClose, Document, FolderOpened, Grid, Location, Memo, Picture, Search } from '@element-plus/icons-vue';
import { getMetadataBrowseTree, type MetadataTreeNode } from '@/api/product-manage/platform/metadata-browse';
import { injectCategoryRoot, scopeTreeByRoot } from '../category-root';
import type { ResourceOption } from './state';

defineOptions({ name: 'UpdateBrowseTree' });

/** 与 data-browse 的树保持同一套外观口径：hosted 由布局接管列宽，treeWidth 用于独立挂载定宽 */
const props = withDefaults(defineProps<{ hosted?: boolean; treeWidth?: number }>(), { hosted: false, treeWidth: 320 });

/** 选中节点 key（`res:<uid>` / `cat:<uid>`），空串 = 全部资源 */
const selected = defineModel<string>({ default: '' });

/** 派生数据回传：change=筛选列表；node-pick=用户主动点节点，通知父组件把该节点资源的文件加进入库清单 */
const emit = defineEmits<{
  change: [resourceUids: string[], resources: ResourceOption[]];
  'node-pick': [resources: ResourceOption[]];
}>();

const categoryRoot = injectCategoryRoot();

type NodeKind = 'cat' | 'res';
interface TreeNodeVM {
  key: string;
  label: string;
  kind: NodeKind;
  categoryUid?: string;
  categoryName?: string;
  resourceUid?: string;
  dataType?: string;
  layerCount?: number;
  children?: TreeNodeVM[];
  count?: number;
}

const loading = ref(false);
const browseTree = ref<MetadataTreeNode[]>([]);
const treeRef = ref();
const keyword = ref('');

/** 后端浏览树节点 → 展示节点 VM；类别子树内没有任何资源则整枝剪掉（与 data-browse 同口径） */
function toTreeNode(n: MetadataTreeNode): TreeNodeVM | null {
  const isRes = n.nodeType === 'resource';
  if (isRes) {
    return {
      key: `res:${n.uid}`,
      label: n.displayName || n.categoryName || n.uid,
      kind: 'res',
      categoryUid: n.categoryUid,
      resourceUid: n.uid,
      dataType: n.dataType,
      layerCount: n.layerCount ?? 0
    };
  }
  const children = (n.children ?? []).map(toTreeNode).filter((c): c is TreeNodeVM => !!c);
  if (!children.length) return null;
  return {
    key: `cat:${n.uid}`,
    label: n.displayName || n.categoryName || n.uid,
    kind: 'cat',
    categoryUid: n.uid,
    categoryName: n.categoryName,
    count: countResources(children),
    children
  };
}

/** 统计一棵子树里的资源节点数（剪枝与徽标共用同一口径） */
function countResources(nodes: TreeNodeVM[]): number {
  let total = 0;
  for (const node of nodes) {
    if (node.kind === 'res') total += 1;
    else total += countResources(node.children ?? []);
  }
  return total;
}

/** 后端完整层级 → 按产品线根收窄 → 只保留「子树里有资源」的分支 */
const treeData = computed<TreeNodeVM[]>(() => {
  const scoped = scopeTreeByRoot(browseTree.value, categoryRoot);
  return scoped.map(toTreeNode).filter((n): n is TreeNodeVM => !!n);
});

function filterNode(value: string, data: TreeNodeVM) {
  if (!value) return true;
  return data.label.toLowerCase().includes(value.toLowerCase());
}
watch(keyword, (val) => treeRef.value?.filter(val));

/** 节点图标：类别文件夹 / 资源按数据类型区分语义色（与 data-browse 一致） */
function nodeIconMeta(data: TreeNodeVM): { icon: any; color: string } {
  if (data.kind === 'cat') return { icon: FolderOpened, color: 'var(--el-color-primary)' };
  switch (String(data.dataType ?? '').toLowerCase()) {
    case 'vector':
      return { icon: Location, color: '#13a8a8' };
    case 'raster':
      return { icon: Picture, color: '#3f8cff' };
    case 'table':
      return { icon: Grid, color: '#2ba471' };
    case 'text':
      return { icon: Memo, color: '#909399' };
    default:
      return { icon: Document, color: 'var(--el-text-color-secondary)' };
  }
}

function findByKey(list: TreeNodeVM[], key: string): TreeNodeVM | null {
  for (const n of list) {
    if (n.key === key) return n;
    const hit = n.children ? findByKey(n.children, key) : null;
    if (hit) return hit;
  }
  return null;
}

/** 一个节点展开成其名下所有资源（类别节点收整棵子树） */
function collectResources(node: TreeNodeVM, acc: Map<string, ResourceOption>) {
  if (node.kind === 'res' && node.resourceUid) {
    if (!acc.has(node.resourceUid)) {
      acc.set(node.resourceUid, {
        uid: node.resourceUid,
        label: node.label,
        categoryUid: node.categoryUid,
        dataType: node.dataType
      });
    }
  } else if (node.kind === 'cat') {
    node.children?.forEach((c) => collectResources(c, acc));
  }
}

/** 未选中时的默认资源清单（全部资源） */
function allResources(): ResourceOption[] {
  const acc = new Map<string, ResourceOption>();
  treeData.value.forEach((n) => collectResources(n, acc));
  return [...acc.values()];
}

/** 当前选中节点对应的资源清单（未选中 = 全部） */
function currentResources(): ResourceOption[] {
  if (!selected.value) return allResources();
  const node = findByKey(treeData.value, selected.value);
  if (!node) return allResources();
  const acc = new Map<string, ResourceOption>();
  collectResources(node, acc);
  return [...acc.values()];
}

function emitChange() {
  const resources = currentResources();
  emit(
    'change',
    resources.map((r) => r.uid),
    resources
  );
}

/** 单选点选：点击已选节点 = 取消（回到全部资源）；否则把该节点资源的文件加进入库清单 */
function onNodeClick(data: TreeNodeVM) {
  selected.value = data.key === selected.value ? '' : data.key;
  // 「点击左树即添加文件」：取消筛选（再次点同一节点）也照常把该节点名下资源的文件并入清单，
  // 由 addSourceBatch 同源合并保证幂等，不因 selected 被清空而跳过。
  const acc = new Map<string, ResourceOption>();
  collectResources(data, acc);
  emit('node-pick', [...acc.values()]);
}

/** 选中态变化：同步高亮 + 回传派生资源清单 */
watch(selected, (uid) => {
  treeRef.value?.setCurrentKey(uid || null);
  emitChange();
});

async function loadData() {
  loading.value = true;
  try {
    const res = await getMetadataBrowseTree();
    browseTree.value = res?.data?.items ?? [];
  } catch {
    browseTree.value = [];
  } finally {
    loading.value = false;
  }
  // 首屏无选中：同步高亮并主动回传全部资源，父组件/新建面板初始即有数据
  await nextTick();
  treeRef.value?.setCurrentKey(selected.value || null);
  emitChange();
}

onMounted(loadData);
</script>

<template>
  <aside v-loading="loading" class="bu-tree" :class="{ 'is-hosted': hosted }" :style="hosted ? undefined : { flexBasis: props.treeWidth + 'px' }">
    <div class="bu-tree__head">
      <el-input v-model="keyword" :placeholder="pt('搜索资源 / 类别')" clearable :prefix-icon="Search" />
      <el-button v-if="selected" :icon="CircleClose" link :title="pt('显示全部资源')" @click="selected = ''" />
    </div>
    <div class="bu-tree__body">
      <!-- 单选点选（对齐数据入库左树）：点击只高亮并选中，再次点击取消；无勾选框 -->
      <el-tree
        ref="treeRef"
        :data="treeData"
        node-key="key"
        :props="{ label: 'label', children: 'children' }"
        :indent="14"
        :default-expand-all="true"
        :expand-on-click-node="false"
        :current-node-key="selected"
        :filter-node-method="filterNode"
        highlight-current
        @node-click="onNodeClick"
      >
        <template #default="{ data }">
          <span class="bu-node" :class="`is-${data.kind}`">
            <el-icon class="bu-node__ic" :style="{ color: nodeIconMeta(data).color }"><component :is="nodeIconMeta(data).icon" /></el-icon>
            <span class="bu-node__label" :title="data.label">{{ data.label }}</span>
            <span v-if="data.count" class="bu-node__count">{{ data.count }}</span>
          </span>
        </template>
      </el-tree>
      <el-empty v-if="!loading && !treeData.length" description="暂无资源" :image-size="50" />
    </div>
  </aside>
</template>

<style scoped lang="scss">
/* 卡片外观与 data-browse 的 .db-tree 一致 */
.bu-tree {
  display: flex;
  flex: 0 0 auto;
  flex-direction: column;
  min-height: 0;
  max-width: 55%;
  padding: 0;
  overflow: hidden;
  background: var(--el-bg-color);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 6px;
}
/* 被 Teleport 到布局左列时：吃满整列（卡片外观与独立挂载时一致，与 data-browse 口径相同） */
.bu-tree.is-hosted {
  flex: 1 1 auto;
  width: 100%;
  max-width: none;
  height: 100%;
}
.bu-tree__head {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 10px 10px 8px;
  border-bottom: 1px solid var(--el-border-color-lighter);

  :deep(.el-input) {
    flex: 1;
    min-width: 0;
  }
}
.bu-tree__body {
  flex: 1;
  min-height: 0;
  padding: 6px 6px 10px;
  overflow: auto;
}

.bu-node {
  display: flex;
  align-items: center;
  gap: 6px;
  width: 100%;
  padding-right: 4px;
  font-size: 13px;
}
.bu-node__ic {
  display: inline-flex;
  flex: none;
  align-items: center;
  width: 15px;
  font-size: 13px;
  color: var(--el-text-color-placeholder);
}
.bu-node__label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.bu-node__count {
  flex: none;
  min-width: 20px;
  padding: 0 5px;
  color: var(--el-text-color-secondary);
  font-size: 11px;
  line-height: 16px;
  text-align: center;
  background: var(--el-fill-color-light);
  border-radius: 8px;
}

:deep(.el-tree-node__content) {
  height: 30px;
  border-radius: 4px;
}
:deep(.el-tree-node.is-current > .el-tree-node__content) {
  background: var(--el-color-primary-light-9);
  .bu-node__count {
    color: var(--el-color-primary);
    background: var(--el-color-primary-light-8);
  }
}
</style>
