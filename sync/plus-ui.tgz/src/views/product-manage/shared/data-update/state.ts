/**
 * 数据更新页接口门面。
 *
 * 数据更新 = 已有资源/已有 dataKey 产生新版本，走专属接口族 /platform/updates
 * （预览/创建/列表/详情/改参/控制/日志/报告，见 platform/data-update.ts），
 * 与文件提取 /platform/data-extractions 是两套语义，不再复用提取门面。
 */
export {
  previewUpdate,
  createUpdate,
  listUpdates,
  getUpdate,
  patchUpdate,
  controlUpdate,
  getUpdateLog,
  getUpdateReport,
  buildCreateUpdatePayload
} from '@/api/product-manage/platform/data-update';

export type {
  UpdateState,
  PriorityLevel,
  UpdateMode,
  FileActionType,
  UpdateFileSource,
  UpdateFileInput,
  FileAction,
  UpdateProgress,
  UpdateManifestItem,
  UpdateTask,
  ListUpdatesParams,
  PreviewUpdatePayload,
  PreviewFileResult,
  PreviewUpdateResult,
  CreateUpdatePayload,
  PatchUpdatePayload,
  UpdateAction,
  UpdateLogItem,
  UpdateLogResult,
  UpdateReport
} from '@/api/product-manage/platform/data-update';

import type { UpdateTask, UpdateState } from '@/api/product-manage/platform/data-update';

/** 列表行即更新任务实体（后端可能返回审计字段，UpdateTask 已用索引签名兜底） */
export type UpdateRow = UpdateTask;

/** 左树回传的资源选项（供新建更新任务面板选择资源） */
export interface ResourceOption {
  uid: string;
  label: string;
  categoryName?: string;
  categoryUid?: string;
  dataType?: string;
}

/** 状态下拉：值必须是后端合法英文枚举 */
export const stateOptions = [
  { label: '等待更新', value: 'QUEUED' },
  { label: '正在更新', value: 'RUNNING' },
  { label: '已暂停', value: 'PAUSED' },
  { label: '更新成功', value: 'SUCCEEDED' },
  { label: '更新失败', value: 'FAILED' },
  { label: '已取消', value: 'CANCELLED' }
] as const;

/** 标签色口径 */
export type StatusTone = 'info' | 'primary' | 'warning' | 'success' | 'danger';

/** 英文 state（及列表示例里的 ready）/ 可能返回的中文原文 → 展示文案与标签色 */
const statusMeta: Record<string, { type: StatusTone; text: string }> = {
  CREATED: { type: 'info', text: '等待更新' },
  QUEUED: { type: 'warning', text: '等待更新' },
  RUNNING: { type: 'primary', text: '正在更新' },
  PAUSED: { type: 'warning', text: '已暂停' },
  SUCCEEDED: { type: 'success', text: '更新成功' },
  ready: { type: 'success', text: '更新成功' },
  FAILED: { type: 'danger', text: '更新失败' },
  CANCELLED: { type: 'info', text: '已取消' },
  已创建: { type: 'info', text: '等待更新' },
  排队中: { type: 'warning', text: '等待更新' },
  进行中: { type: 'primary', text: '正在更新' },
  已暂停: { type: 'warning', text: '已暂停' },
  成功: { type: 'success', text: '更新成功' },
  失败: { type: 'danger', text: '更新失败' },
  已取消: { type: 'info', text: '已取消' }
};

/** 状态呈现：英文 state 优先，中文原文兜底，最后原样展示 */
export function statusOf(row: UpdateTask) {
  return statusMeta[row.state] ?? statusMeta[String(row.operationStatus ?? '')] ?? { type: 'info' as const, text: row.state || '未知' };
}

/** 是否为终态（成功 / 失败 / 取消）——终态不再提供开始/暂停/恢复动作 */
export function isTerminal(row: UpdateTask) {
  return (['SUCCEEDED', 'FAILED', 'CANCELLED'] as UpdateState[]).includes(row.state as UpdateState);
}

/** 优先级的中文展示 */
export function priorityText(level?: string) {
  return level === 'high' ? '高' : level === 'low' ? '低' : '中';
}
