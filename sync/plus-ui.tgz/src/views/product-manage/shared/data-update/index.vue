<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
import { nextTick } from 'vue';
import { CircleClose, Document, Download, VideoPause, VideoPlay } from '@element-plus/icons-vue';
import { ElMessage } from 'element-plus';
import { useTreeHost } from '@/views/product-manage/shared/tree-host';
import UpdateBrowseTree from './browse-tree.vue';
import UpdateCreate from './update-create.vue';
import UpdateDetail from './update-detail.vue';
import { listUpdates, controlUpdate, getUpdate, getUpdateLog, getUpdateReport, stateOptions, statusOf, priorityText, isTerminal } from './state';
import type { UpdateRow, ResourceOption, UpdateLogItem, UpdateReport } from './state';
import { subscribeTaskEvents, type TaskEventPayload } from '@/api/product-manage/platform/tasks';

/**
 * 数据更新任务页。
 *
 * 交互口径对齐「数据入库」（data-into-store/index.vue）：
 *  - 左侧资源树单选点选（browse-tree.vue 用 v-model），切换即 query() 回第 1 页；
 *  - 表格去掉勾选框、无批量动作，点行高亮定位（点操作按钮不触发选行）；
 *  - 详情用 createDialog 承载独立详情组件（update-detail.vue），footer:false；
 *  - 右侧用 el-tabs 分「新建更新 / 更新列表」（对齐入库页），列表内不再放新建按钮；
 *  - 状态下拉用中文口径，翻译成后端英文枚举；活跃行/运行态圆点等视觉与入库一致。
 *
 * 数据全部来自专属接口族 /platform/updates（见 platform/data-update.ts），
 * 不再复用文件提取 /platform/data-extractions。
 */

/** 左树宿主：布局接管时树 Teleport 到布局左列，独立挂载时用本页内联列 */
const treeHost = useTreeHost();
const hosted = computed(() => !!treeHost?.el.value);
const treeTarget = computed(() => treeHost?.el.value ?? 'body');

/** 右侧 tab：新建更新 / 更新列表（默认新建，与入库页一致） */
const activeTab = ref<'create' | 'list'>('create');

/** 新建更新表单实例：tab 栏右侧「重置/创建更新」按钮委托给它 */
const createRef = ref();
const creating = ref(false);

/** 左树选中节点 key（空 = 全部资源，格式 `res:<uid>` / `cat:<uid>`） */
const selectedNodeKey = ref('');

/** 选中的具体资源 uid（类别/全部节点为空，此时新建表单回退到资源清单第一个） */
const selectedResourceUid = computed(() => (selectedNodeKey.value.startsWith('res:') ? selectedNodeKey.value.slice(4) : ''));

/** 状态筛选：UI 用中文 label，queryParams.status 存后端英文枚举 */
const stateFilter = ref('');
/** 状态下拉选项：显示中文，值也用中文（onStateChange 再翻译） */
const statusFilterOptions = stateOptions.map((o) => ({ label: o.label, value: o.label }));
const queryParams = reactive<{ keyword: string; status: string }>({ keyword: '', status: '' });

function onStateChange(label: string) {
  const hit = stateOptions.find((o) => o.label === label);
  queryParams.status = hit ? hit.value : '';
  updateRows.value = [];
  updatesCache.clear();
  tableRef.value?.query?.();
}

/** 表格实例：左侧树筛选切换时调用 query() 回到第 1 页重新查询；首屏不自动请求，进入列表页再加载 */
const tableRef = ref();
const listLoaded = ref(false);
const updateRows = ref<UpdateRow[]>([]);

/** 当前点选高亮的任务行（本页无批量动作，只做点谁看谁） */
const activeRow = ref<UpdateRow | null>(null);

/** 最近一次查询到的全量更新行（未分页），供树点选回填清单复用，避免重复请求 */
const lastTaskRows = ref<UpdateRow[]>([]);
const updatesCache = new Map<string, UpdateRow[]>();

/** 左树回传的资源 uid（空 = 不过滤，此处用全部资源）与资源清单 */
const resourceUids = ref<string[]>([]);
const resources = ref<ResourceOption[]>([]);
const resourceLabelMap = computed<Record<string, string>>(() => {
  const map: Record<string, string> = {};
  for (const r of resources.value) map[r.uid] = r.label;
  return map;
});

/** 左树选中变化：更新资源集合；列表页已加载时回到第 1 页重新查询 */
function onTreeChange(uids: string[], list: ResourceOption[]) {
  resourceUids.value = uids;
  resources.value = list;
  // 选中树节点后，当前高亮行可能已不在结果集里，清掉
  activeRow.value = null;
  if (listLoaded.value) tableRef.value?.query?.();
}

/** 内部按资源拉取更新记录（一次点击一资源），同时写缓存供新建清单回填 */
async function loadUpdatesForResource(uid: string): Promise<UpdateRow[]> {
  if (updateRows.value.some((r) => r.resourceUid === uid)) return updateRows.value.filter((r) => r.resourceUid === uid);
  if (updatesCache.has(uid)) return updatesCache.get(uid)!;
  const rows: UpdateRow[] = [];
  try {
    let page = 1;
    while (true) {
      const res = await listUpdates(uid, { page, pageSize: 200, state: queryParams.status || undefined });
      const items: UpdateRow[] = res?.data?.items ?? [];
      rows.push(...items);
      const total = res?.data?.total ?? items.length;
      if (items.length < 200 || page * 200 >= total) break;
      page += 1;
    }
  } catch {
    // 单资源查询失败不影响其它资源
  }
  updatesCache.set(uid, rows);
  updateRows.value = updateRows.value.concat(rows);
  return rows;
}

/** 主动点选左树节点：只查点击节点的更新记录回填新建清单；没有可添加文件时不改动现有清单 */
async function onTreeNodePick(list: ResourceOption[]) {
  const picked = list.length ? list : resources.value;
  activeTab.value = 'create';
  if (!picked.length) return;
  const rows: UpdateRow[] = [];
  for (const res of picked) rows.push(...(await loadUpdatesForResource(res.uid)));
  lastTaskRows.value = rows;
  await nextTick();
  await createRef.value?.addFromExistingUpdates?.(picked, rows);
}

/** 进入列表页时才首次加载，避免首屏默认新建页请求全量更新 */
function onTabChange(tab: 'create' | 'list') {
  if (tab !== 'list') return;
  if (!listLoaded.value) {
    listLoaded.value = true;
    tableRef.value?.getData?.();
    return;
  }
  tableRef.value?.query?.();
}

/** 资源名：优先用接口返回的业务名 resourceName，左树映射兜底，绝不回退到 uid */
function resourceText(row: UpdateRow) {
  return String((row as any).resourceName || '') || resourceLabelMap.value[row.resourceUid] || '—';
}

/** 数据键：接口实际放在 update 子对象里，顶层 dataKey 仅作历史兜底 */
function dataKeyOf(row: UpdateRow) {
  return String((row as any).update?.dataKey || (row as any).dataKey || '');
}

/** 新版本号：接口放在 update.newVersionNo，顶层 versionNo 兜底 */
function versionNoOf(row: UpdateRow) {
  return (row as any).update?.newVersionNo ?? (row as any).versionNo;
}

/** 文件数：接口返回 fileCounts{data,metadata}，updateManifest 长度兜底 */
function fileCount(row: UpdateRow) {
  const c: any = (row as any).fileCounts;
  if (c && typeof c === 'object') return Number(c.data || 0) + Number(c.metadata || 0);
  return row.updateManifest?.length ?? 0;
}

/** 操作态判断：按接口 state 英文枚举，避免旧版用中文文案判断导致「更新失败」误显示开始按钮。
 *  后端口径：仅 CREATED/QUEUED/PAUSED 可启动；PAUSED 在 UI 上走「恢复」，故「开始」只给 CREATED/QUEUED。 */
function canStart(row: UpdateRow) {
  return row.state === 'CREATED' || row.state === 'QUEUED';
}
function canPause(row: UpdateRow) {
  return row.state === 'RUNNING';
}
function canResume(row: UpdateRow) {
  return row.state === 'PAUSED';
}
function canCancel(row: UpdateRow) {
  return !isTerminal(row);
}

/** 点行高亮：点操作按钮/进度条不触发选行 */
function onRowClick(row: UpdateRow, _column: unknown, event: Event) {
  const target = event?.target as HTMLElement | null;
  if (target?.closest?.('button, a, .el-button, .el-progress, .el-switch')) return;
  activeRow.value = row;
}

/** 活跃行 class（与数据入库一致：运行态整行淡底 + 左侧主色条） */
function rowClassName({ row }: { row: UpdateRow }) {
  return row.state === 'RUNNING' ? 'update-row--active' : '';
}

const columns: TableColumn<UpdateRow>[] = [
  {
    label: pt('更新任务'),
    minWidth: 210,
    showOverflowTooltip: true,
    render: ({ row }) => <span>{String((row as any).importName || (row as any).dataName || '—')}</span>
  },
  { label: pt('资源'), minWidth: 150, showOverflowTooltip: true, render: ({ row }) => <span>{resourceText(row)}</span> },
  {
    label: pt('状态'),
    width: 120,
    render: ({ row }) => {
      const meta = statusOf(row);
      const running = row.state === 'RUNNING';
      return (
        <span class="result-cell">
          {running && <span class="live-dot" />}
          <el-tag type={meta.type}>{String((row as any).stateText || meta.text)}</el-tag>
        </span>
      );
    }
  },
  {
    label: pt('更新进度'),
    minWidth: 190,
    render: ({ row }) => {
      const percent = Math.round(row.progress?.percent ?? 0);
      const failed = row.state === 'FAILED';
      return (
        <div class="progress-cell">
          <el-progress percentage={percent} showText={false} status={failed ? 'exception' : percent >= 100 ? 'success' : undefined} />
          <span>{percent}%</span>
        </div>
      );
    }
  },
  { label: pt('新版本'), width: 90, render: ({ row }) => <span>{versionNoOf(row) ?? '—'}</span> },
  {
    label: pt('版本状态'),
    width: 100,
    render: ({ row }) => <span>{String((row as any).versionStateName || (row as any).versionState || '—')}</span>
  },
  {
    label: pt('文件数'),
    width: 90,
    render: ({ row }) => <span>{fileCount(row)}</span>
  },
  {
    action: true,
    label: pt('操作'),
    fixed: 'right',
    minWidth: 240,
    render: ({ row }) => {
      return (
        <div class="row-actions">
          <el-button link type="primary" icon={Document} v-tooltip={'详情'} onClick={() => openDetail(row)} />
          <el-button link type="danger" icon={Document} v-tooltip={'导出错误报表'} onClick={() => exportErrors(row)} />
          <el-button link type="primary" icon={Download} v-tooltip={'导出完整报告'} onClick={() => exportFullReport(row)} />
          {canStart(row) && (
            <el-button
              link
              type="primary"
              icon={VideoPlay}
              v-tooltip={'开始'}
              onClick={() => act(() => controlUpdate(row.updateUid, 'start'), pt('开始'))}
            />
          )}
          {canPause(row) && (
            <el-button
              link
              type="warning"
              icon={VideoPause}
              v-tooltip={'暂停'}
              onClick={() => act(() => controlUpdate(row.updateUid, 'pause'), pt('暂停'))}
            />
          )}
          {canResume(row) && (
            <el-button
              link
              type="primary"
              icon={VideoPlay}
              v-tooltip={'恢复'}
              onClick={() => act(() => controlUpdate(row.updateUid, 'resume'), pt('恢复'))}
            />
          )}
          {canCancel(row) && (
            <el-button
              link
              type="info"
              icon={CircleClose}
              v-tooltip={'取消'}
              onClick={() => act(() => controlUpdate(row.updateUid, 'cancel'), pt('取消'))}
            />
          )}
        </div>
      );
    }
  }
];

/** 统一接口操作：调用成功后刷新列表，失败交给 axios 拦截器提示 */
async function act(fn: () => Promise<unknown>, label: string) {
  try {
    await fn();
    ElMessage.success(`${label}成功`);
    await tableRef.value?.getData();
  } catch {
    // axios 响应拦截器已对 4xx 弹过后端 message，这里不重复弹
  }
}

/** 详情：createDialog 承载独立详情组件（对齐数据入库 openDetail 范式） */
function openDetail(row: UpdateRow) {
  createDialog({
    title: pt('更新详情'),
    width: '900px',
    footer: false,
    bodyStyle: { padding: '0 20px 16px' },
    render: () => <UpdateDetail updateUid={row.updateUid} initial={row} onChanged={() => tableRef.value?.getData()} />
  });
}

/** 日志类型机器值 → 中文标签 */
const LOG_TYPE_TEXT: Record<string, string> = {
  version: pt('版本'),
  state: '状态',
  'file-completed': '文件完成',
  'file-added': '文件新增',
  'file-updated': '文件更新',
  'file-removed': '文件移除',
  error: pt('错误')
};
function logTypeText(type: unknown) {
  const key = String(type ?? '');
  return LOG_TYPE_TEXT[key] || (key ? pt('事件') : pt('日志'));
}
function logMessage(item: UpdateLogItem) {
  const x = item as any;
  if (x.message) return String(x.message);
  if (x.type === 'version') return `生成版本 V${x.versionNo ?? '-'}`;
  if (x.type === 'state') return String(x.stateText || x.state || '状态变更');
  if (String(x.type || '').startsWith('file-')) return String(x.targetPath || x.sourcePath || x.fileName || '文件处理');
  return String(x.stateText || x.hint || '');
}

/** 拉取选中行的详情+日志+报告，供两个导出复用（报告无 errors 数组，错误明细从日志 type='error' 提取） */
async function loadExportData(row: UpdateRow) {
  const uid = row.updateUid;
  const [detailRes, logsRes, reportRes] = await Promise.all([getUpdate(uid), getUpdateLog(uid, { limit: 200 }), getUpdateReport(uid)]);
  const detail: any = (detailRes?.data ?? row) as any;
  let logs: UpdateLogItem[] = logsRes?.data?.items ?? [];
  let cursor = logsRes?.data?.nextCursor;
  for (let i = 0; i < 100 && cursor; i++) {
    const more = await getUpdateLog(uid, { cursor, limit: 200 });
    logs = logs.concat(more?.data?.items ?? []);
    cursor = more?.data?.nextCursor;
  }
  const report = (reportRes?.data ?? null) as UpdateReport | null;
  const errors = logs
    .filter((it) => String((it as any).type || '') === 'error')
    .map((it) => logMessage(it))
    .filter(Boolean);
  if (!errors.length && report?.errorMessage) errors.push(String(report.errorMessage));
  return { detail, report, logs, errors };
}

function safeFileName(name: string) {
  return name.replace(/[\\/:*?"<>|]/g, '_');
}
function triggerDownload(content: string, mime: string, filename: string) {
  const url = URL.createObjectURL(new Blob([content], { type: mime }));
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

/** 导出错误报表（针对该行） */
async function exportErrors(row: UpdateRow) {
  try {
    const { detail, errors } = await loadExportData(row);
    if (!errors.length) {
      ElMessage.warning(pt('该任务报告中没有错误记录'));
      return;
    }
    const name = safeFileName(String(detail.importName || detail.dataName || '数据更新'));
    const rows = [['序号', '错误内容'], ...errors.map((e, i) => [String(i + 1), `"${e.replace(/"/g, '""')}"`])];
    triggerDownload('\uFEFF' + rows.map((r) => r.join(',')).join('\r\n'), 'text/csv;charset=utf-8', `数据更新错误报表_${name}.csv`);
    ElMessage.success(pt('错误报表已导出'));
  } catch {
    // 拦截器已提示
  }
}

/** 导出完整报告（针对该行，纯文本：基本信息 + 报告 + 错误明细 + 日志） */
async function exportFullReport(row: UpdateRow) {
  try {
    const { detail, report, logs, errors } = await loadExportData(row);
    const name = String(detail.importName || detail.dataName || '数据更新');
    const lines: string[] = [
      '数据更新报告',
      '========================',
      `任务名称：${name}`,
      `资源名称：${detail.resourceName || '-'}`,
      `数据名称：${detail.dataName || '-'}`,
      `执行状态：${report?.stateText || String(detail.stateText || statusOf(detail).text || '-')}`,
      `优先级：${priorityText((detail.priorityLevel as any) || 'medium')}`,
      `新版本：${report?.newVersionNo != null ? `V${report.newVersionNo}` : '-'}`,
      `文件数：${report?.fileCount ?? report?.completedFiles ?? 0}`,
      `完成 / 总数：${report?.completedFiles ?? 0} / ${report?.fileCount ?? 0}`,
      `错误数：${report?.errorCount ?? 0}`,
      '',
      '—— 错误明细 ——',
      ...(errors.length ? errors.map((e, i) => `${i + 1}. ${e}`) : ['无']),
      '',
      '—— 更新日志 ——',
      ...(logs.length ? logs.map((it) => `[${logTypeText(it.type)}] ${logMessage(it)}`) : ['无'])
    ];
    triggerDownload('\uFEFF' + lines.join('\r\n'), 'text/plain;charset=utf-8', `数据更新报告_${safeFileName(name)}.txt`);
    ElMessage.success(pt('完整报告已导出'));
  } catch {
    // 拦截器已提示
  }
}

/** 新建更新：重置（委托子组件清空表单） */
function resetCreate() {
  createRef.value?.resetForm?.();
}

/** 新建更新：创建（对齐入库页 submitCreate —— 子组件 save 返回 code=0 才切 tab 刷新） */
async function submitCreate() {
  const edit = createRef.value;
  if (!edit) return;
  creating.value = true;
  try {
    const res = await edit.save();
    if (res === undefined) return;
    if (res.code === 0) {
      ElMessage.success(res.message || '创建成功。');
      activeTab.value = 'list';
      await tableRef.value?.getData();
    } else {
      ElMessage.error(res.message || '创建失败。');
    }
  } finally {
    creating.value = false;
  }
}

/**
 * 真实列表：按左树选中的资源逐个查 /platform/resources/{resourceUid}/updates，
 * 合并后做 keyword 前端过滤与统一分页（接口本身按单资源分页）。
 */
async function getTasks(params: Params) {
  const page = params.page || 1;
  const pageSize = params.pageSize || 20;
  const state = queryParams.status || undefined;
  const keyword = String(params.keyword || queryParams.keyword || '').toLowerCase();

  if (!resourceUids.value.length) return { code: 0, data: { items: [], total: 0 } };

  const all: UpdateRow[] = [];
  for (const uid of resourceUids.value) {
    const cached = await loadUpdatesForResource(uid);
    all.push(...cached);
  }
  void state;

  const rows = keyword
    ? all.filter((r) =>
        `${dataKeyOf(r)}${r.resourceUid}${r.updateUid}${String((r as any).importName || '')}${String((r as any).resourceName || '')}`
          .toLowerCase()
          .includes(keyword)
      )
    : all;
  const start = (page - 1) * pageSize;
  const pageRows = rows.slice(start, start + pageSize);
  // 保留本次筛选下全部更新行，供树点选「加文件到清单」直接复用，避免第二次 listUpdates
  lastTaskRows.value = all;
  // SSE 进度合并到当前页行：listCache 与返回给 Table 的 items 共享对象引用，改其字段即触发重绘
  listCache.value = pageRows;
  syncSubscriptions();
  return { code: 0, data: { items: pageRows, total: rows.length } };
}

/**
 * SSE：更新列表进度实时刷新，复用 /tasks/{taskUid}/events。
 * 与 data-extraction/data-into-store 同构：仅活跃态（CREATED/QUEUED/RUNNING/PAUSED）订阅，
 * onEvent 仅就地合并 progress（不整表刷新，避免表格 loading 反复闪烁）；
 * 终态退订并整表刷新一次，拿齐 hint/finishedAt 等字段。
 * dev 下限制 2 条：Chrome 对同 origin HTTP/1.1 仅 6 连接槽，SSE 占满会卡死 HMR/刷新。
 */
const listCache = ref<UpdateRow[]>([]);
const sseControllers = new Map<string, AbortController>();
const MAX_SSE_SUBSCRIPTIONS = import.meta.env.DEV ? 2 : Infinity;
const SSE_ACTIVE_STATES = new Set(['CREATED', 'QUEUED', 'RUNNING', 'PAUSED']);

function syncSubscriptions() {
  // 当前查看行优先占住 dev 下有限的 SSE 名额
  const activeRows = listCache.value.filter((r) => r.taskUid && SSE_ACTIVE_STATES.has(r.state));
  activeRows.sort((a, b) => {
    const aActive = activeRow.value?.taskUid === a.taskUid ? 1 : 0;
    const bActive = activeRow.value?.taskUid === b.taskUid ? 1 : 0;
    return bActive - aActive;
  });
  const wanted = new Set(activeRows.slice(0, MAX_SSE_SUBSCRIPTIONS).map((r) => r.taskUid as string));

  // 回收：离开当前页 / 转终态 / 被上限挤出的订阅，防长连接泄漏
  sseControllers.forEach((controller, uid) => {
    if (!wanted.has(uid)) {
      controller.abort();
      sseControllers.delete(uid);
    }
  });

  wanted.forEach((uid) => {
    if (sseControllers.has(uid)) return;
    const controller = new AbortController();
    sseControllers.set(uid, controller);
    subscribeTaskEvents(
      uid,
      {
        onEvent: (payload: TaskEventPayload) => {
          if (payload.event !== 'task.progress' || !payload.data) return;
          const snap = (payload.data || {}) as Record<string, unknown>;
          const hit = listCache.value.find((x) => x.taskUid === uid);
          if (!hit) return;
          // 只就地合并进度：不写 state、不整表刷新，避免表格 loading 反复闪烁。
          // SSE 推的 state 文案（如「处理中」）与列表枚举（RUNNING）不同，写回会污染状态判断。
          // 状态切换/终态由 onTerminal 统一整表刷新拿权威字段。
          if (snap.progress) (hit as any).progress = snap.progress;
        },
        onTerminal: () => {
          controller.abort();
          sseControllers.delete(uid);
          tableRef.value?.getData();
        },
        onError: () => {
          // 契约不支持 Last-Event-ID，重连拿最新快照；交给下次整表刷新重算订阅面
          sseControllers.delete(uid);
        }
      },
      controller.signal
    );
  });
}

watch(
  () => activeRow.value?.taskUid,
  () => syncSubscriptions()
);

onBeforeUnmount(() => {
  sseControllers.forEach((c) => c.abort());
  sseControllers.clear();
});

onMounted(async () => {
  // useTreeHost 自己的 onMounted 会把 hasContent 重置为 false，须在其之后认领，
  // 否则零勾选时布局层会误判「详情区无内容」而收起。本页右栏恒有表格，故置 true。
  if (treeHost) {
    treeHost.checkedCount.value = 0;
    treeHost.hasContent.value = true;
  }
});
</script>

<template>
  <div class="update-page">
    <Teleport :to="treeTarget" :disabled="!hosted">
      <UpdateBrowseTree
        v-model="selectedNodeKey"
        :hosted="hosted"
        :tree-width="treeHost?.width.value ?? 320"
        @change="onTreeChange"
        @node-pick="onTreeNodePick"
      />
    </Teleport>
    <div v-if="!hosted" class="update-split" />
    <section class="update-detail">
      <!-- 操作按钮定位到 tab 栏右侧：EP el-tabs 无 #extra 插槽，绝对定位覆盖到 header 右端，与入库页一致 -->
      <div v-if="activeTab === 'create'" class="update-header-actions">
        <el-button :disabled="creating" @click="resetCreate">{{ pt('重置') }}</el-button>
        <el-button type="primary" :loading="creating" @click="submitCreate">{{ pt('创建更新') }}</el-button>
      </div>
      <el-tabs v-model="activeTab" class="update-tabs" @tab-change="onTabChange">
        <el-tab-pane :label="pt('新建更新')" name="create">
          <div class="update-create">
            <div class="update-create__body">
              <UpdateCreate ref="createRef" :resources="resources" :resource-uid="selectedResourceUid" />
            </div>
          </div>
        </el-tab-pane>
        <el-tab-pane :label="pt('更新列表')" name="list">
          <Table
            ref="tableRef"
            row-key="updateUid"
            highlight-current-row
            :row-class-name="rowClassName"
            :columns="columns"
            :request="getTasks"
            :query-params="queryParams"
            :request-cfg="{ page: 'page', size: 'pageSize', list: 'items' }"
            @row-click="onRowClick"
          >
            <template #search>
              <el-input v-model="queryParams.keyword" :label="pt('关键词')" :placeholder="pt('任务名称 / 资源 / 数据键')" />
              <el-select
                v-model="stateFilter"
                :label="pt('状态')"
                :placeholder="pt('全部状态')"
                clearable
                :options="statusFilterOptions"
                @change="onStateChange"
              />
            </template>
          </Table>
        </el-tab-pane>
      </el-tabs>
    </section>
  </div>
</template>

<style scoped lang="scss">
.update-page {
  display: flex;
  align-items: stretch;
  gap: 0;
  height: 100%;
  overflow: hidden;
}

.update-split {
  flex: 0 0 9px;
}

.update-detail {
  position: relative;
  display: flex;
  flex: 1 1 0;
  flex-direction: column;
  min-width: 0;
  min-height: 0;
  overflow: hidden;
  background: var(--el-bg-color);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 6px;
}

/* 操作按钮组：绝对定位到 tab header 右端（EP el-tabs 无 #extra 插槽，自行覆盖；与入库页一致） */
.update-header-actions {
  position: absolute;
  z-index: 2;
  top: 4px;
  right: 14px;
  display: flex;
  gap: 8px;
}

/* 新建更新：表单区撑满，操作按钮已在 tab 栏右侧，无底部操作条 */
.update-create {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
}
.update-create__body {
  flex: 1 1 auto;
  min-height: 0;
  overflow: auto;
}

/* el-tabs 必须显式撑满：否则内部 tab-pane 的 Table height:100% 参照落空 */
.update-tabs {
  display: flex;
  flex: 1 1 auto;
  flex-direction: column;
  min-height: 0;
}
:deep(.update-tabs > .el-tabs__header) {
  margin: 0;
  padding: 0 14px;
  border-bottom: 1px solid var(--el-border-color-lighter);
}
:deep(.update-tabs .el-tabs__nav-wrap::after) {
  display: none;
}
:deep(.update-tabs > .el-tabs__content) {
  flex: 1 1 auto;
  min-height: 0;
  overflow: hidden;
}
:deep(.update-tabs .el-tab-pane) {
  height: 100%;
}

/* JSX render 产出的 vnode 拿 ElTable 的 scopeId，scoped 样式必须用 :deep 才能命中 */
:deep(.progress-cell) {
  display: flex;
  align-items: center;
  gap: 8px;
}
:deep(.progress-cell .el-progress) {
  flex: 1;
}
:deep(.progress-cell > span) {
  width: 35px;
  color: #718097;
  font-size: 12px;
}
:deep(.row-actions) {
  white-space: nowrap;
}
:deep(.result-cell) {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}
/* 选中行（update-row--active）样式已归一到全局 src/assets/styles/index.scss
   的 html.group-manage 块（地图联动列表选中行唯一真源），此处不再重复。 */
:deep(.live-dot) {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: var(--el-color-primary);
  box-shadow: 0 0 0 3px color-mix(in srgb, var(--el-color-primary) 14%, transparent);
  animation: update-pulse 1.4s ease-in-out infinite;
}

@keyframes update-pulse {
  0%,
  100% {
    opacity: 1;
  }
  50% {
    opacity: 0.35;
  }
}
@media (prefers-reduced-motion: reduce) {
  :deep(.live-dot) {
    animation: none;
  }
}
</style>
