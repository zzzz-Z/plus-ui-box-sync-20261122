<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
import { Refresh } from '@element-plus/icons-vue';
import { ElMessage } from 'element-plus';
import { completeMetadataBackfill, getImportBatch, getImportFiles, IMPORT_FILES_PAGE_DEFAULT } from '@/api/product-manage/platform/ingestion';
import { describeMetacheckError, resolveMetacheckErrorAction } from '@/api/product-manage/platform/metacheck-errors';
import type { ImportArtifactFile, ImportBatchDetail } from '@/api/product-manage/platform/ingestion';
import { importStateOf, normImportState } from './state';

/**
 * 入库批次详情。
 *
 * WHY 独立成组件（而非放进 index.vue 的 render 闭包）：详情承载两个**语义不同**的文件区、
 * 一块 direct 审计、一块补录状态与一个补录动作，塞进列表页会让列表页同时承担「列表 + 详情 +
 * 地图」三件事。createDialog 以独立 vnode 挂到 body，故所需上下文走 props（本组件不需要注入）。
 *
 * 无 defineExpose save：详情页是只读展示 + 一个独立动作按钮（补录完成），
 * 不走 createDialog 的「提交/关闭」保存流程（footer:false 由调用方传入）。
 */
defineOptions({ name: 'ImportBatchDetail' });

const props = defineProps<{
  /** 批次 uid（必填；调用方从列表行取） */
  importUid: string;
  /** 列表行的初值：先渲染出来避免白屏，随后被详情接口覆盖 */
  initial?: ImportBatchDetail | null;
}>();

const emit = defineEmits<{
  /** 补录完成 / 状态变化后通知调用方刷新列表 */
  changed: [];
}>();

/** 批次详情（详情接口覆盖初值） */
const detail = ref<ImportBatchDetail | null>(props.initial ?? null);
const loading = ref(false);
const loadError = ref('');

/** 运行期原件产物（GET /imports/{uid}/files） */
const artifacts = ref<ImportArtifactFile[]>([]);
/** 游标分页状态；null/空表示没有更多 */
const nextCursor = ref<string | null>(null);
const hasMore = ref(false);
const filesLoading = ref(false);
const filesError = ref('');

/** 补录提交中（防重复点击） */
const backfilling = ref(false);

/** 状态展示口径（与列表页同源，禁止各页自写映射） */
const stateView = computed(() => importStateOf(detail.value?.state));

/** 进度百分比文案；不展示后端的大计数与英文阶段码，扫描期无百分比时兜底 '-' */
const progressPercentText = computed(() => {
  const raw = detail.value?.progress?.percent;
  return typeof raw === 'number' ? `${Math.round(raw)}%` : '-';
});

/** direct 审计信息；非 direct 批次为 null */
const directIngest = computed(() => detail.value?.directIngest ?? null);

/** 补录状态投影 */
const backfill = computed(() => detail.value?.metadataBackfill ?? null);

/**
 * 是否显示「标记补录完成」按钮。
 *
 * CONSTRAINT 只认 metadataBackfill.state === 'pending'：服务端对该状态的批次才接受补录
 * （契约 §8：direct 且已成功结束的批次），其余状态调用会返回 409「补录状态不允许」。
 */
const canCompleteBackfill = computed(() => backfill.value?.state === 'pending');

/** 补录状态中文文案 */
const backfillStateText = computed(() => {
  const s = backfill.value?.state;
  if (s === 'pending') return pt('待补录');
  if (s === 'completed') return pt('补录完成');
  if (s === 'not_required') return pt('无需补录');
  return s || '-';
});

/** 补录状态标签色 */
const backfillStateType = computed<'success' | 'warning' | 'info'>(() => {
  const s = backfill.value?.state;
  if (s === 'pending') return 'warning';
  if (s === 'completed') return 'success';
  return 'info';
});

/** 检查策略文案（契约只返 require_passed/direct，旧值兜底原文） */
const policyText = computed(() => {
  const p = detail.value?.checkPolicy;
  if (p === 'require_passed') return pt('检查通过后入库');
  if (p === 'direct') return pt('直接入库');
  return p || '';
});

/** 错误数（0 也照实展示，供概览突出） */
const errorCount = computed(() => detail.value?.errorCount ?? 0);

/** 初始优先级中文映射（与新建表单口径一致） */
const PRIORITY_LEVEL_TEXT: Record<string, string> = { high: pt('高'), medium: pt('中'), low: pt('低') };
const priorityText = computed(() => {
  const p = detail.value?.priorityLevel;
  return (p && PRIORITY_LEVEL_TEXT[p]) || '-';
});

/** 数据级别中文映射：历史数据可能存英文机器码，兜底转中文（与列表页同口径） */
const SECURITY_LEVEL_TEXT: Record<string, string> = {
  public: pt('公开'),
  internal: pt('内部'),
  secret: pt('机密'),
  confidential: pt('秘密'),
  top_secret: pt('绝密')
};
const securityLevelText = computed(() => {
  const raw = String(detail.value?.securityLevel ?? '').trim();
  return SECURITY_LEVEL_TEXT[raw.toLowerCase()] || raw || '-';
});

/**
 * 加载批次详情。
 *
 * CONSTRAINT 该接口返回 `files`（受理时冻结的选择清单）、`directIngest`、`metadataBackfill`；
 * 它与 `/files` 产物清单**不是同一份数据**，故本函数不碰 artifacts。
 */
async function loadDetail() {
  loading.value = true;
  loadError.value = '';
  try {
    const res: any = await getImportBatch(props.importUid);
    detail.value = (res?.data ?? detail.value) as ImportBatchDetail;
  } catch (error) {
    loadError.value = describeMetacheckError(error).message || '加载详情失败';
  } finally {
    loading.value = false;
  }
}

/**
 * 加载运行期原件产物（游标分页；reset=true 时从第一页重来）。
 *
 * CONSTRAINT 参数口径是 cursor/limit（1–500，默认 100），与入库列表的 page/pageSize 不同源；
 * 响应壳是 {items, pageSize, nextCursor, hasMore}，不是 {items,total}。
 */
async function loadArtifacts(reset = true) {
  filesLoading.value = true;
  filesError.value = '';
  if (reset) {
    artifacts.value = [];
    nextCursor.value = null;
    hasMore.value = false;
  }
  try {
    const res: any = await getImportFiles(props.importUid, {
      cursor: reset ? null : nextCursor.value,
      limit: IMPORT_FILES_PAGE_DEFAULT
    });
    const page = res?.data ?? {};
    const items = (page.items ?? []) as ImportArtifactFile[];
    artifacts.value = reset ? items : [...artifacts.value, ...items];
    nextCursor.value = page.nextCursor ?? null;
    hasMore.value = Boolean(page.hasMore ?? page.nextCursor);
  } catch (error) {
    filesError.value = describeMetacheckError(error).message || '加载原件产物失败';
  } finally {
    filesLoading.value = false;
  }
}

/** 刷新详情与产物（补录成功后调用：批次状态不变，但补录字段已改） */
async function reloadAll() {
  await Promise.all([loadDetail(), loadArtifacts(true)]);
}

/**
 * 标记补录完成（POST /imports/{uid}/metadata-backfill/complete）。
 *
 * 成功语义：资源 metadata_completeness 由 pending_backfill 转 complete，**批次状态不变**，
 * 因此只刷新详情（不改状态列），并通知调用方刷新列表以便其它列同步。
 * 失败 409「补录状态不允许」→ 按错误码映射给「刷新详情后重试」的动作指引。
 *
 * CONSTRAINT 不与拦截器抢着弹窗：响应拦截器已对 4xx 展示过后端原文，这里只在**识别出错误码**时
 * 补一条带动作指引的提示，并回读详情消除错误的可点状态；识别不出就不重复弹。
 */
async function doCompleteBackfill() {
  if (!props.importUid || backfilling.value) return;
  backfilling.value = true;
  try {
    await completeMetadataBackfill(props.importUid);
    ElMessage.success(pt('已标记补录完成'));
    await reloadAll();
    emit('changed');
  } catch (error) {
    const action = resolveMetacheckErrorAction(error);
    if (action === 'refresh') {
      ElMessage.warning(pt('补录状态已变化，已为你回读最新详情，请确认后再试'));
      await loadDetail();
    } else if (action) {
      ElMessage.warning(describeMetacheckError(error).message);
    }
  } finally {
    backfilling.value = false;
  }
}

/** 文件大小展示；后端给字节数，统一按 1024 进制换单位 */
function formatSize(bytes?: number): string {
  if (typeof bytes !== 'number' || bytes < 0) return '-';
  if (bytes < 1024) return `${bytes} B`;
  const units = ['KB', 'MB', 'GB', 'TB'];
  let value = bytes / 1024;
  let i = 0;
  while (value >= 1024 && i < units.length - 1) {
    value /= 1024;
    i += 1;
  }
  return `${value.toFixed(value >= 100 ? 0 : 1)} ${units[i]}`;
}

onMounted(() => {
  loadDetail();
  loadArtifacts(true);
});
</script>

<template>
  <div v-loading="loading" class="import-detail">
    <el-alert v-if="loadError" :title="loadError" type="error" show-icon :closable="false" class="detail-alert" />

    <!-- 基础信息：批次状态与诊断信息集中一处，不再单设顶部概览（与基础信息重复） -->
    <section class="section">
      <header class="section-head">
        <span class="section-accent" />
        <h3 class="section-title">{{ pt('基础信息') }}</h3>
        <el-button class="section-action" :icon="Refresh" size="small" link @click="reloadAll">{{ pt('刷新') }}</el-button>
      </header>
      <el-descriptions :column="2" border size="small" class="info-desc">
        <el-descriptions-item :label="pt('任务名称')">{{ detail?.taskName || '-' }}</el-descriptions-item>
        <el-descriptions-item :label="pt('执行状态')">
          <el-tag :type="stateView.type" size="small">{{ stateView.label }}</el-tag>
        </el-descriptions-item>
        <el-descriptions-item :label="pt('产品类别')">{{ detail?.categoryName || detail?.categoryUid || '-' }}</el-descriptions-item>
        <el-descriptions-item :label="pt('数据级别')">{{ securityLevelText }}</el-descriptions-item>
        <el-descriptions-item :label="pt('初始优先级')">{{ priorityText }}</el-descriptions-item>
        <el-descriptions-item :label="pt('进度')">
          <span :class="{ 'text-error': normImportState(detail?.state) === '失败' }">{{ progressPercentText }}</span>
        </el-descriptions-item>
        <el-descriptions-item :label="pt('检查策略')">{{ policyText || '-' }}</el-descriptions-item>
        <el-descriptions-item :label="pt('错误数')">
          <span :class="{ 'text-error': errorCount > 0 }">{{ errorCount }}</span>
        </el-descriptions-item>
        <el-descriptions-item v-if="backfill" :label="pt('元数据')">
          <el-tag :type="backfillStateType" size="small" effect="plain">{{ backfillStateText }}</el-tag>
        </el-descriptions-item>
        <el-descriptions-item :label="pt('创建人')">{{ detail?.createdBy || '-' }}</el-descriptions-item>
        <el-descriptions-item :label="pt('创建时间')">{{ detail?.createdAt || '-' }}</el-descriptions-item>
        <el-descriptions-item :label="pt('完成时间')">{{ detail?.finishedAt || '-' }}</el-descriptions-item>
        <el-descriptions-item v-if="detail?.hint" :label="normImportState(detail?.state) === '失败' ? '失败原因' : '提示'" :span="2">
          <span :class="{ 'text-error': normImportState(detail?.state) === '失败' }">{{ detail.hint }}</span>
        </el-descriptions-item>
      </el-descriptions>
    </section>

    <!-- direct 审计：仅直接入库批次有值 -->
    <section v-if="directIngest" class="section">
      <header class="section-head">
        <span class="section-accent" />
        <h3 class="section-title">{{ pt('直接入库审计') }}</h3>
      </header>
      <el-descriptions :column="1" border size="small">
        <el-descriptions-item :label="pt('入库原因')">{{ directIngest.reason || '-' }}</el-descriptions-item>
        <el-descriptions-item :label="pt('操作人')">{{ directIngest.actorRef || '-' }}</el-descriptions-item>
        <el-descriptions-item :label="pt('受理时间')">{{ directIngest.ingestedAt || '-' }}</el-descriptions-item>
      </el-descriptions>
    </section>

    <!-- 元数据补录：仅 direct 批次有意义 -->
    <section v-if="backfill" class="section">
      <header class="section-head">
        <span class="section-accent" />
        <h3 class="section-title">{{ pt('元数据补录') }}</h3>
      </header>
      <el-descriptions :column="2" border size="small">
        <el-descriptions-item :label="pt('补录状态')">
          <el-tag :type="backfillStateType" size="small">{{ backfillStateText }}</el-tag>
        </el-descriptions-item>
        <el-descriptions-item :label="pt('是否要求补录')">{{ backfill.required ? '是' : '否' }}</el-descriptions-item>
        <el-descriptions-item :label="pt('完成时间')">{{ backfill.completedAt || '-' }}</el-descriptions-item>
        <el-descriptions-item :label="pt('完成人')">{{ backfill.completedBy || '-' }}</el-descriptions-item>
      </el-descriptions>
      <div v-if="canCompleteBackfill" class="backfill-action">
        <el-button type="primary" size="small" plain :loading="backfilling" @click="doCompleteBackfill">{{ pt('标记补录完成') }}</el-button>
        <span>{{ pt('完成后资源元数据转为「完整」，批次状态不变。') }}</span>
      </div>
    </section>

    <!--
      运行期原件产物 —— 来自 GET /imports/{uid}/files。
      语义：执行后登记到 tb_task_artifact 的原件，是批次执行的「输出」产物。
    -->
    <section class="section">
      <header class="section-head">
        <span class="section-accent" />
        <h3 class="section-title">{{ pt('运行期原件产物') }}</h3>
        <span class="count-badge">{{ artifacts.length }}</span>
        <span class="section-tag section-tag--warn">{{ pt('执行后登记') }}</span>
      </header>
      <p class="section-hint">{{ pt('批次执行后登记的原件产物（相对路径、类型、大小与状态）。') }}</p>
      <el-alert v-if="filesError" :title="filesError" type="error" show-icon :closable="false" class="detail-alert" />
      <el-empty v-if="!filesLoading && !artifacts.length" :description="pt('暂无原件产物（批次尚未执行或未登记产物）')" :image-size="60" />
      <el-table v-else v-loading="filesLoading" :data="artifacts" size="small" border max-height="320">
        <el-table-column :label="pt('相对路径')" min-width="240" show-overflow-tooltip>
          <template #default="{ row }">
            <span class="mono">{{ row.relativePath || row.name || '-' }}</span>
          </template>
        </el-table-column>
        <el-table-column label="媒体类型" prop="mediaType" width="150" show-overflow-tooltip />
        <el-table-column label="大小" width="100">
          <template #default="{ row }">{{ formatSize(row.sizeBytes) }}</template>
        </el-table-column>
        <el-table-column label="状态" prop="status" width="100" />
      </el-table>
      <div v-if="hasMore" class="load-more">
        <el-button size="small" :loading="filesLoading" @click="loadArtifacts(false)">加载更多</el-button>
      </div>
    </section>
  </div>
</template>

<style scoped lang="scss">
.import-detail {
  display: flex;
  flex-direction: column;
  gap: 20px;
  padding: 4px 0;
}

.detail-alert {
  margin-bottom: 0;
}

.text-error {
  color: var(--el-color-danger);
  font-weight: 600;
}

.section {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

/* 小标题：与元数据检查详情同款竖条强调样式 */
.section-head {
  display: flex;
  align-items: center;
  gap: 8px;
  min-height: 22px;
}

.section-accent {
  flex: 0 0 auto;
  width: 3px;
  height: 14px;
  border-radius: 2px;
  background: var(--el-color-primary);
}

.section-title {
  margin: 0;
  color: var(--el-text-color-primary);
  font-size: 14px;
  font-weight: 600;
}

.section-action {
  margin-left: auto;
}

.backfill-action {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 12px;
  color: var(--el-text-color-secondary);
}

.section-tag {
  padding: 0 6px;
  border-radius: 4px;
  font-size: 11px;
  font-weight: 400;
  line-height: 18px;
  color: var(--el-color-primary);
  background: var(--el-color-primary-light-9);
}

.section-tag--warn {
  color: var(--el-color-warning);
  background: var(--el-color-warning-light-9);
}

.section-hint {
  margin: 0;
  font-size: 12px;
  line-height: 1.7;
  color: var(--el-text-color-secondary);
}

.count-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 20px;
  height: 20px;
  padding: 0 6px;
  background: var(--el-fill-color);
  border-radius: 10px;
  font-size: 12px;
  font-weight: 500;
  color: var(--el-text-color-secondary);
}

.mono {
  font-family: var(--el-font-family-mono, ui-monospace, SFMono-Regular, Menlo, Consolas, monospace);
  font-size: 12px;
}

.load-more {
  display: flex;
  justify-content: center;
}
</style>
