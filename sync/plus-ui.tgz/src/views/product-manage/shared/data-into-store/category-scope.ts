/**
 * 产品类别作用域过滤：把「页面语义根编码」映射到类别树的子树。
 *
 * WHY 独立成文件：左侧产品类型树（product-type-tree.vue）、选择框（edit.vue）与管理面板
 * （product-type-manage-dialog.vue）需要展示同一范围内的类别，逻辑复制会随任一方的修复而漂移。
 */
import { getProductTypeList } from '@/api/product-manage/adapter/category';

/**
 * 前端 provide 的语义编码与后端 categoryKey 未强约定一致；精确匹配失败时按类别名关键字兜底。
 * CONSTRAINT 别名需与「产品类型管理」实际维护的类别名对齐；命中唯一节点即可，避免多义。
 */
const ROOT_NAME_HINTS: Record<string, string[]> = {
  attribute_primary: ['分类要素属性'],
  category_primary: ['分类要素初级'],
  collaboration_primary: ['协同'],
  military_geo_primary: ['地质要素'],
  land_sea_primary: ['陆海'],
  attribute_result: ['分类要素属性'],
  category_result: ['分类要素成果'],
  geology_result: ['地质要素成果'],
  lh_result: ['陆海融合成果'],
  sample_model_result: ['样本'],
  vector_network_result: ['矢量']
};

/** 按 categoryKey 深度查找节点（含自身，命中即返回；找不到返回 null） */
export function findNodeByKey(list: any[], key: string): any {
  for (const node of list) {
    if (node.categoryKey === key) return node;
    const hit = node.children?.length ? findNodeByKey(node.children, key) : null;
    if (hit) return hit;
  }
  return null;
}

/** 按类别名关键字深度查找节点（兜底路径，仅在 categoryKey 精确匹配失败时启用） */
export function findNodeByName(list: any[], hints: string[]): any {
  for (const node of list) {
    const name = String(node.categoryName || '');
    if (hints.some((hint) => name.indexOf(hint) !== -1)) return node;
    const hit = node.children?.length ? findNodeByName(node.children, hints) : null;
    if (hit) return hit;
  }
  return null;
}

/**
 * 按页面语义根编码裁剪类别树。
 * 命中返回单节点数组（以该节点为树根，保留完整子树）；未命中返回空数组，由调用方决定回退策略。
 */
export function pickTypesByRoot(roots: any[], categoryRoot: string): any[] {
  if (!categoryRoot) return [];
  const hints = ROOT_NAME_HINTS[categoryRoot] || [];
  const hit = findNodeByKey(roots, categoryRoot) || (hints.length ? findNodeByName(roots, hints) : null);
  return hit ? [hit] : [];
}

/**
 * 深度优先收集叶子节点（无子级）的类别名集合。
 * 图例与配色表以叶子为最小着色单元，非叶节点不参与配色。
 */
export function collectLeafNames(nodes: any[], acc: Set<string> = new Set()): Set<string> {
  for (const node of nodes) {
    if (node.children?.length) collectLeafNames(node.children, acc);
    else if (node.categoryName) acc.add(node.categoryName);
  }
  return acc;
}

/** 深度优先展平类别树，供 uid 与节点双向映射 */
export function flattenNodes(list: any[]): any[] {
  const out: any[] = [];
  const walk = (nodes: any[]) => {
    for (const node of nodes) {
      out.push(node);
      if (node.children?.length) walk(node.children);
    }
  };
  walk(list);
  return out;
}

/**
 * 按页面语义根编码取「本页可见的产品类型树」，是入库页所有类别来源的**唯一取数口径**。
 *
 * WHY 必须收口到一个函数：左侧树（列表收窄 + 新建默认值）与新建弹窗（类别下拉）若各取各的，
 * 就会出现「树里点了某类别，弹窗默认值却是另一个范围」这种无法解释的错位。
 *
 * 回退策略（与改造前 edit.vue 的口径逐字一致，勿改）：
 *   ① 语义根命中 → 命中节点的完整子树；
 *   ② 未命中（含未注入 categoryRoot）→ 顶层根节点（parentCategoryUid 为空）。
 *      静默返回空数组会让整棵树看起来「没有产品类型」，用户无从判断是没配数据还是范围错了，
 *      所以宁可放宽到全量顶层，也不返回空。
 */
export async function fetchScopedTypeRoots(categoryRoot: string): Promise<{ roots: any[]; scoped: boolean }> {
  const res: any = await getProductTypeList({});
  const roots = (res?.data?.items ?? []) as any[];
  const scoped = pickTypesByRoot(roots, categoryRoot);
  if (scoped.length) return { roots: scoped, scoped: true };
  return { roots: roots.filter((n) => !n.parentCategoryUid), scoped: false };
}

/**
 * 取子树内全部类别名（含自身），用于把「树上选中的类别」展开成列表过滤集合。
 *
 * WHY 含自身而不是只取叶子：入库批次可能直接挂在中间类别上（direct 入库允许选任意层级），
 * 只取叶子会把挂在中间类别的批次整批漏掉。
 *
 * WHY 用「名」做前端兜底过滤：入库列表行（ImportBatch）只回 categoryName，没有 categoryUid，
 * 按 uid 匹配一条也命中不了。
 */
export function collectCategoryNames(node: any, acc: Set<string> = new Set()): Set<string> {
  if (!node) return acc;
  if (node.categoryName) acc.add(String(node.categoryName));
  for (const child of node.children ?? []) collectCategoryNames(child, acc);
  return acc;
}
