/**
 * 数据入库 · 状态口径（列表页 index.vue 与详情页 detail.vue 共享）
 *
 * WHY 独立成文件：入库列表与入库详情都要把后端任意 state 写法归一为**同一套中文规范键**、
 * 配色与查询枚举。两处各写一份，必然随任一侧的修复而漂移（曾出现列表认「部分成功」、
 * 详情认「PARTIAL_SUCCESS」两套口径）。
 *
 * 清理说明：本文件原先维护一套 mock 任务进度（createTaskStore + getStoreTaskList +
 * 定时推进 progress），其依赖的 `getStoreTaskList` / `StoreTask` / `StoreForm` 三个导出早已
 * 不存在，全仓也无任何引用（`grep -rn "storeTasks|persistStoreTasks|loadStoreTasks|startStoreProgress"`
 * 在 src 下零命中）。纯死代码导致 vue-tsc 稳定报 4 条 TS2305，故整体移除；保留并集中状态口径。
 *
 * CONSTRAINT 后端列表返回的 state 是**中文**（「已创建」「入库中」「已取消」…），前端内部统一以
 * 中文为规范键；唯一例外是查询参数 `?state=`，契约只认英文枚举（实测中文值被忽略），
 * 该转换只在 IMPORT_STATE_QUERY 里做，不污染内部状态键。
 */

/** 状态展示口径：文案 + el-tag 类型 + 图例配色 */
export interface ImportStateView {
  label: string;
  type: 'info' | 'primary' | 'success' | 'warning' | 'danger';
  color: string;
}

/** 中文规范键 → 展示口径；键集合同时是状态筛选下拉的取值域 */
export const IMPORT_STATE_MAP: Record<string, ImportStateView> = {
  已创建: { label: '已创建', type: 'info', color: '#909399' },
  入库中: { label: '入库中', type: 'primary', color: '#409eff' },
  已完成: { label: '已完成', type: 'success', color: '#67c23a' },
  部分成功: { label: '部分成功', type: 'warning', color: '#e6a23c' },
  失败: { label: '失败', type: 'danger', color: '#f56c6c' },
  已暂停: { label: '已暂停', type: 'warning', color: '#e6a23c' },
  已取消: { label: '已取消', type: 'info', color: '#909399' }
};

/**
 * state 别名 → 中文规范键。
 *
 * 两个来源：① 后端某些接口（如任务接口）仍返英文枚举 → 归一到中文；
 * ② 中文写法的变体（「排队中」「执行中」等）→ 归一到展示用的规范键。
 * 未列举值返回空串，由调用方归 info 兜底。
 */
const STATE_ALIAS: Record<string, string> = {
  // 英文枚举 → 中文规范键
  QUEUED: '已创建',
  ACCEPTED: '已创建',
  CREATED: '已创建',
  RUNNING: '入库中',
  CHECKING: '入库中',
  PROCESSING: '入库中',
  SUCCEEDED: '已完成',
  SUCCESS: '已完成',
  DONE: '已完成',
  COMPLETED: '已完成',
  PARTIAL_SUCCESS: '部分成功',
  FAILED: '失败',
  ERROR: '失败',
  PAUSED: '已暂停',
  PAUSING: '已暂停',
  CANCELLED: '已取消',
  CANCELED: '已取消',
  // 中文变体 → 中文规范键
  排队中: '已创建',
  等待中: '已创建',
  执行中: '入库中',
  处理中: '入库中',
  已成功: '已完成',
  成功: '已完成',
  已失败: '失败',
  暂停: '已暂停',
  取消: '已取消'
};

/** 兜底关键词（按长→短顺序）：精确匹配未命中时按包含关系识别，映射到中文规范键 */
const STATE_FALLBACK: Array<[string, string]> = [
  ['部分成功', '部分成功'],
  ['已暂停', '已暂停'],
  ['已取消', '已取消'],
  ['已完成', '已完成'],
  ['已成功', '已完成'],
  ['已创建', '已创建'],
  ['已失败', '失败'],
  ['入库中', '入库中'],
  ['执行中', '入库中'],
  ['处理中', '入库中'],
  ['排队中', '已创建'],
  ['等待中', '已创建'],
  ['成功', '已完成'],
  ['失败', '失败'],
  ['取消', '已取消'],
  ['暂停', '已暂停']
];

/**
 * 把后端返回的任意 state 写法归一为**中文规范键**（与 IMPORT_STATE_MAP 的键对齐）；未列举归空串。
 *
 * 三级匹配：① 已是中文规范键（IMPORT_STATE_MAP[raw]）直接返回；② 命中 STATE_ALIAS（英文枚举/中文变体）；
 * ③ 命中 STATE_FALLBACK 包含关系兜底（「入库成功」「任务失败」等带前后缀写法）。
 * WHY 引入第 ③ 级：后端同一状态写法会漂移，只做精确匹配会在新写法出现时静默降级为灰色 info 标签。
 */
export function normImportState(state?: string | null): string {
  const raw = String(state ?? '').trim();
  if (!raw) return '';
  if (IMPORT_STATE_MAP[raw]) return raw;
  if (STATE_ALIAS[raw]) return STATE_ALIAS[raw];
  for (const [kw, key] of STATE_FALLBACK) {
    if (raw.includes(kw)) return key;
  }
  return '';
}

/**
 * 状态 → 展示口径；未识别值回落原文 + info 色。
 *
 * CONSTRAINT 未识别时**保留后端原文**而不是显示「未知」：原文比「未知」更有诊断价值，
 * 且不会让用户误以为前端把状态吞掉了。
 */
export function importStateOf(state?: string | null): ImportStateView {
  const key = normImportState(state);
  return IMPORT_STATE_MAP[key] || { label: String(state || '未知'), type: 'info', color: '#909399' };
}

/**
 * 中文规范键 → 后端列表接口 `?state=` 接受的英文枚举。
 *
 * CONSTRAINT 契约只认英文枚举：实测 `?state=已创建` 返回 total=undefined（参数被忽略），
 * `?state=QUEUED` 才生效。UI 内部键是中文，提交查询参数时按此表翻译。
 * WHY 一个中文规范键可能对应多个后端枚举（CREATED 与 QUEUED 均显示「已创建」），
 * 值改为数组，由调用方逐枚举查询后合并，确保「按显示状态筛选」能取回全部同态批次。
 */
export const IMPORT_STATE_QUERY: Record<string, string[]> = {
  已创建: ['CREATED', 'QUEUED'],
  入库中: ['RUNNING'],
  已完成: ['SUCCEEDED'],
  部分成功: ['PARTIAL_SUCCESS'],
  失败: ['FAILED'],
  已暂停: ['PAUSED'],
  已取消: ['CANCELLED']
};

/**
 * 需要建立 SSE 订阅的状态集合（中文规范键）。
 *
 * CONSTRAINT 契约无批次级 events 路由，进度须走统一任务 `/platform/tasks/{taskUid}/events`；
 * 终态不再产生事件，订阅它们只会白占连接。
 */
export const IMPORT_ACTIVE_STATES: ReadonlySet<string> = new Set(['已创建', '入库中']);
