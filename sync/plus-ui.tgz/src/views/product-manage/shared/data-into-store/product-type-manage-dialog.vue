<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
import { Delete, Edit, Plus } from '@element-plus/icons-vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import EditForm from '@/views/product-manage/system/product-type-manage/edit.vue';
import { deleteProductType, getProductTypeList } from '@/api/product-manage/adapter/category';
import { pickTypesByRoot } from './category-scope';

const props = defineProps<{ onChanged?: () => void; categoryRoot?: string }>();

const rows = ref<any[]>([]);
const loading = ref(false);
const filterText = ref('');
const treeRef = ref();

watch(filterText, (kw) => treeRef.value?.filter(kw));

/** 树节点过滤：仅按名称包含匹配；el-tree 自动保留命中节点的祖先链 */
function filterNode(value: string, data: any) {
  if (!value) return true;
  return String(data.categoryName || '').includes(value);
}

async function load() {
  loading.value = true;
  try {
    const res: any = await getProductTypeList({});
    const roots = (res?.data?.items ?? []) as any[];
    // 与选择框同源：按页面语义根编码裁剪到同一子树；未命中回退全量根，避免空列表
    const scoped = pickTypesByRoot(roots, props.categoryRoot || '');
    rows.value = scoped.length ? scoped : roots.filter((n: any) => !n.parentCategoryUid);
  } finally {
    loading.value = false;
  }
}

function refresh() {
  load();
  props.onChanged?.();
}

function openEdit(row?: any, parent?: any) {
  const initial = row ?? (parent ? { parentCategoryUid: parent.categoryUid } : undefined);
  const title = row ? pt('编辑产品类型') : parent ? '新增「' + parent.categoryName + '」的子级' : pt('新增产品类型');
  createDialog({
    title,
    width: '600px',
    afterSave: refresh,
    render: () => <EditForm row={initial} categoryRoot={props.categoryRoot} />
  });
}

async function onDelete(row: any) {
  try {
    await ElMessageBox.confirm('确定删除「' + row.categoryName + '」？其子级会一并删除。', pt('提示'), { type: 'warning' });
  } catch {
    return;
  }
  const res: any = await deleteProductType(row.categoryUid);
  if (res.code === 0) {
    ElMessage.success(res.message || '删除成功');
    refresh();
  } else {
    ElMessage.error(res.message || '删除失败');
  }
}

onMounted(load);
</script>

<template>
  <div class="pt-manage-dialog">
    <div class="pt-manage-dialog__bar">
      <el-input v-model="filterText" :placeholder="pt('搜索类别名称')" clearable size="small" class="pt-manage-dialog__search" />
      <el-button type="primary" :icon="Plus" size="small" @click="openEdit()">{{ pt('新增产品类型') }}</el-button>
    </div>
    <div v-loading="loading" class="pt-manage-dialog__tree">
      <el-tree
        ref="treeRef"
        :data="rows"
        :props="{ label: 'categoryName', children: 'children' }"
        node-key="categoryUid"
        :expand-on-click-node="false"
        :filter-node-method="filterNode"
        default-expand-all
        empty-text="暂无产品类型"
      >
        <template #default="{ data }">
          <div class="pt-node">
            <span class="pt-node__name">{{ data.categoryName }}</span>
            <span class="pt-node__key">{{ data.categoryKey }}</span>
            <span class="pt-node__actions">
              <el-button link type="primary" :icon="Plus" @click.stop="openEdit(undefined, data)">{{ pt('子级') }}</el-button>
              <el-button link type="primary" :icon="Edit" @click.stop="openEdit(data)">{{ pt('编辑') }}</el-button>
              <el-button link type="danger" :icon="Delete" @click.stop="onDelete(data)">{{ pt('删除') }}</el-button>
            </span>
          </div>
        </template>
      </el-tree>
    </div>
  </div>
</template>

<style scoped lang="scss">
.pt-manage-dialog__bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}

.pt-manage-dialog__search {
  max-width: 220px;
}

.pt-manage-dialog__tree {
  margin-top: 12px;
  min-height: 320px;
  max-height: 420px;
  overflow: auto;
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 6px;
  padding: 8px;
}

.pt-node {
  display: flex;
  align-items: center;
  gap: 10px;
  flex: 1;
  min-width: 0;
  padding-right: 8px;
}

.pt-node__name {
  color: var(--el-text-color-primary);
}

.pt-node__key {
  color: var(--el-text-color-secondary);
  font-size: 12px;
  background: var(--el-fill-color-light);
  padding: 1px 6px;
  border-radius: 4px;
}

.pt-node__actions {
  margin-left: auto;
  opacity: 0;
  transition: opacity 0.15s;
}

:deep(.el-tree-node__content:hover) .pt-node__actions {
  opacity: 1;
}
</style>
