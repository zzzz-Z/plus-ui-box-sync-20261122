<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
import { h } from 'vue';
import SourceToolbarActions from '../source-toolbar-actions.vue';
import { ElMessage } from 'element-plus';
import type { UploadUserFile } from 'element-plus';
import CryptoJS from 'crypto-js';
import { getProductTypeList } from '@/api/product-manage/adapter/category';
import {
  buildImportPayload,
  createDataUploadSession,
  createImportBatch,
  DEPRECATED_CHECK_POLICY_NOTICE,
  finalizeDataUploadSession,
  isDataUploadReady,
  listFromCheckCandidates,
  putDataUploadPart,
  putToSignedUrl
} from '@/api/product-manage/platform/ingestion';
import {
  buildMetadataCheckPayload,
  getMetadataFileCheck,
  isMetadataCheckAccepted,
  isMetadataCheckFinished,
  isMetadataCheckNotAccepted,
  listMetadataFileChecks,
  metadataCheckNotAcceptedMessage,
  METADATA_CHECK_PAGE_MAX,
  precheckMetadataFiles,
  submitMetadataFileCheck,
  uploadMetadataFile
} from '@/api/product-manage/platform/metadata-check';
import { getMetadataModelList } from '@/api/product-manage/platform/metadata';
import { isMetacheckError, resolveMetacheckErrorAction } from '@/api/product-manage/platform/metacheck-errors';
import type {
  FromCheckCandidatesResult,
  ImportCheckPolicy,
  ImportFileSelection,
  ImportFileSource,
  ImportPriorityLevel
} from '@/api/product-manage/platform/ingestion';
import type { DataUploadFileDecl } from '@/api/product-manage/platform/ingestion';
import type { MetadataCheckTaskSummary } from '@/api/product-manage/platform/metadata-check';
import BrowseDialog from '../data-check/browse-dialog.vue';
import { createDialog } from '@/composables/create-dialog';
import SelectedFileTree from '../data-check/selected-file-tree.vue';
import { flattenNodes, pickTypesByRoot } from './category-scope.js';
import { clearSelection, hasAcceptedCheck, selection } from '../metacheck-selection';

/**
 * 表单模型；字段与 CreateImportPayload 契约同名同形。
 *
 * CONSTRAINT 策略差异（2026-11-12 多来源契约）：
 *   - require_passed：必填 checkUid；metadataFiles 不带 source（由检查单决定），
 *     dataFiles 各自带 source；
 *   - direct：认 dataFiles + categoryUid，**严禁** checkUid，每个 data 项都必须带 source。
 * 任务级 source 与旧 files 清单**停用**（传了即 400），来源下沉到 dataFiles[] 每一条。
 *
 * 入库清单三种手动来源（登记共享目录 / 共享路径 UNC / 本地上传）**可共存**：
 * 每批自带 ImportFileSource，逐文件进 dataFiles[]，后端按条目各自解析。
 * 字段级互斥（storageUid / rootPath / uploadUid 不得同时出现在同一 source 对象内）
 * 由 ingestion.ts 的 normalizeFileSource 校验；本组件保证不同批次各自带合法 source，
 * 不混叠到同一条。from-check 数据来自检查单，独立成批，不参与手动来源。
 * 拼装仍由 buildImportPayload 统一裁剪，本组件不自行拼请求体。
 */
interface ImportBatchForm {
  batchName: string;
  checkPolicy: ImportCheckPolicy;
  /** 绑定的检查单号（require_passed 必填，是唯一真源）；direct 下由自动检查回填 */
  checkUid: string;
  /**
   * 元数据模型（direct 必填）：提交前自动建检查时 checks/files 必填 modelUid；
   * require_passed 不用（模型信息由所选检查单带出）。
   */
  modelUid: string;
  categoryUid: string;
  priorityLevel: ImportPriorityLevel;
  /** 创建后是否立即排队执行；契约默认 false，保持与列表「开始」按钮的两次调用兼容 */
  autoStart: boolean;
  securityLevel: string;
}

/**
 * 上层注入的产品类别根编码。
 *
 * CONSTRAINT 不用 inject：本组件由 createDialog 以独立 render 挂到 body，vnode 没有 parent，
 * 祖先 provide 传不进来（inject 恒拿默认值）。故由 index.vue（在正常组件树上）作为 prop 传入。
 *
 * defaultCategoryUid / typeRoots：「新建入库默认和左侧同步」的落地口。
 *   - defaultCategoryUid：左侧树当前选中的类别 uid，作为表单默认值；
 *   - typeRoots：左侧树正在用的那棵类型树（**本页可见范围**，不是整库）。
 *     传入后本组件直接复用，不再自己拉一遍类别接口 —— 两遍请求会因时序不同
 *     让「默认值」与「树上显示的类型」错开。
 *     WHY 传整棵树而不是只传选中节点：只传节点会让类别下拉退化成单节点，
 *     用户想在同一页面范围内改选别的类型就没得可选。
 */
const props = defineProps<{
  categoryRoot?: string;
  defaultCategoryUid?: string;
  typeRoots?: any[];
}>();

const form = ref();

/**
 * 表单默认值：**checkPolicy 必须是 require_passed**。
 *
 * WHY 显式纠正：新契约里 run_if_needed 已从受理移除，旧实现默认值是 'run_if_needed'，
 * 会让每张新单都走已不存在的链路（新请求直接 400「导入检查策略无效」）。
 */
const model = reactive<ImportBatchForm>({
  batchName: '',
  checkPolicy: 'require_passed',
  checkUid: '',
  modelUid: '',
  categoryUid: '',
  priorityLevel: 'medium',
  autoStart: false,
  securityLevel: 'public'
});

/** 元数据模型下拉（direct 策略提交前自动检查必填） */
const modelOptions = ref<{ label: string; value: string }[]>([]);
const modelLoading = ref(false);

/**
 * 拉取模型下拉；失败降级空数组（允许手动填 modelUid，但不静默当有效值提交）。
 * 复用「数据检查」页 getMetadataModelList，口径一致。
 */
async function loadModels() {
  modelLoading.value = true;
  try {
    const res: any = await getMetadataModelList();
    modelOptions.value = ((res?.data?.items ?? []) as any[]).map((m) => ({
      label: m.modelName || m.modelKey || m.modelUid,
      value: m.modelUid
    }));
  } catch {
    modelOptions.value = [];
  } finally {
    modelLoading.value = false;
  }
}

/** 本地上传的待传文件（auto-upload=false，提交时才真正上传） */
const uploadFileList = ref<UploadUserFile[]>([]);
/** 上传进度文案；空串=未在上传 */
const uploadProgress = ref('');
/**
 * 已选来源项（来源选择器回填，模型的唯一来源）。
 *
 * WHY 独立存而不是直接写 model：来源现在不再是单一全局态，而是「一批批加进清单」，
 * 每批自带自己的 ImportFileSource。本列表只记录**尚未被清单删除**的来源项，
 * 供 buildSourceRows 派生行。
 */
interface SourceEntry {
  /** 该批次的来源根（upload 批次此处为空对象，提交前才补 uploadUid） */
  source: ImportFileSource;
  /** 来源展示名（登记位置数据根 / UNC 根 / 本地上传） */
  label: string;
  /** 该批次选中文件（相对该批次的 source 根） */
  files: string[];
  /** 与 files 同序的入库目标路径 */
  targets: string[];
  /** 本地上传批次：source 需在提交前用 uploadUid 补齐，故单标出来 */
  isUpload?: boolean;
  /** candidates.dataFiles 派生的「检查单数据」批次：切换检查单时整批替换，不与手动来源合并 */
  fromCheck?: boolean;
}

const sourceEntries = ref<SourceEntry[]>([]);

/** 产品类型选项（树）；保留类别完整属性供展示，提交只取 categoryUid */
const options = ref<any[]>([]);

/** 检查记录原始列表（未过滤）；下拉只展示 accepted=true 的子集 */
const checks = ref<MetadataCheckTaskSummary[]>([]);
const checkLoading = ref(false);

/** 选中检查单的**完整详情**（含 files/dataFiles/结论/来源），是提交前复核的唯一依据 */
const checkDetail = ref<MetadataCheckTaskSummary | null>(null);
/** 最近一次 candidates 结果：保存时与详情合并派生任务级 source（candidates 自身不带 storageUid） */
const candidatesData = ref<FromCheckCandidatesResult | null>(null);
const detailLoading = ref(false);
/** 详情复核失败原因；为空表示复核正常 */
const detailError = ref('');

/**
 * 可绑定的检查记录：**只列 isMetadataCheckAccepted(row) === true**。
 *
 * CONSTRAINT 禁止用 state/progress.stage 当通过判据（contract §三）：实测 9 条记录 state 全是
 * 中文「成功」，其中 4 条 decision=拒绝。用 state 过滤会把不合格记录放行入库。
 */
const acceptedChecks = computed(() => checks.value.filter((row) => isMetadataCheckAccepted(row)));

/** 当前选中的检查记录（列表项，用于详情未到位时的兜底展示） */
const selectedCheck = computed(() => checks.value.find((row) => row.checkUid === model.checkUid) || null);

/**
 * 左侧类型子树内的全部类别 uid（含自身）。
 *
 * WHY 需要它：require_passed 下类别由检查单带出，左侧类型不能直接写进 categoryUid，
 * 只能用来**收窄检查单候选**。收窄必须是「整棵子树」——用户点根类型时，
 * 挂在其子类别上的检查单同样属于该类型，只匹配根类别会一条都选不到。
 */
const scopedTypeUids = computed<string[]>(() => {
  const uid = props.defaultCategoryUid;
  if (!uid) return [];
  const walk = (list: any[], acc: string[] = []): string[] => {
    for (const node of list ?? []) {
      if (String(node.categoryUid) === uid) {
        // 命中即以该节点为根收集整棵子树
        const collect = (n: any, out: string[] = []): string[] => {
          if (n?.categoryUid) out.push(String(n.categoryUid));
          for (const c of n?.children ?? []) collect(c, out);
          return out;
        };
        return collect(node, acc);
      }
      const hit = node.children?.length ? walk(node.children, acc) : null;
      if (hit?.length) return hit;
    }
    return acc;
  };
  return walk(props.typeRoots ?? []);
});

/**
 * 检查记录下拉项：**只显示任务名称**。
 *
 * WHY 去掉文件数与类别路径：下拉里附加信息把任务名挤出可视区，用户核对「选的是哪次检查」
 * 反而更困难；文件数 / 类别 / 指纹等完整信息在选中后的「检查复核」区块统一展示。
 * 任务名缺失时回落 checkUid，避免出现空白选项。
 *
 * 「新建入库默认和左侧同步」（require_passed 下）：检查单是类别真源，左侧类型无法直接填进
 * categoryUid（契约：与检查单不一致即 409 CHECK_BINDING_MISMATCH），因此同步落在**候选范围**上 ——
 * 选中左侧类型时，下拉只列该类型（含子类型）的检查单，用户第一眼看到的就是同一类型的单据。
 *
 * CONSTRAINT 左侧类型下一条检查单都没有时**回落到全部**：直接给空下拉会让人以为「没有可入库的
 * 检查单」，而实际上是「这个类型下暂时没有」，两者的下一步动作完全不同（前者要去做检查，
 * 后者换类型或直接入库）。回落时下拉里会混入别的类型，由 summaryHint 说明原因。
 */
const checkOptions = computed(() => {
  const all = acceptedChecks.value.map((row) => ({
    value: row.checkUid,
    label: row.taskName || row.checkUid
  }));
  const uid = props.defaultCategoryUid;
  if (!uid) return all;
  const allowed = new Set(scopedTypeUids.value);
  if (!allowed.size) return all;
  const hit = acceptedChecks.value
    .filter((row) => allowed.has(String(row.categoryUid || row.productCategoryUid || '')))
    .map((row) => ({ value: row.checkUid, label: row.taskName || row.checkUid }));
  if (!hit.length) return all;
  /**
   * 已选检查单若落在收窄范围外，必须**补回选项**。
   *
   * WHY：el-select 的已选值不在 options 里时，显示的是原始 value（一串 UUID），
   * 用户会看到下拉框里突然出现乱码般的标识；而选中事实是有效的（检查单已通过、类别合法），
   * 强行清空会丢掉用户从「数据检查」页带过来的选择。补进选项即可两全。
   */
  if (model.checkUid && !hit.some((o) => o.value === model.checkUid)) {
    const keep = all.find((o) => o.value === model.checkUid);
    if (keep) hit.unshift(keep);
  }
  return hit;
});

/**
 * 检查单下拉当前是否**确实**被左侧类型收窄（用于提示文案）。
 *
 * 判据是「收窄后条数 < 全部条数」：没有收窄（未传类型 / 类型下无检查单而回落 / 全部都属于该类型）
 * 时都不该提示，否则会出现「已收窄 5/5 条」这种自相矛盾的说明。
 */
const checkOptionsScoped = computed(() => checkOptions.value.length < acceptedChecks.value.length);

/**
 * 检查单下拉的占位文案：把「只列接受结论」与「已按类型收窄 N / M 条」都放进 placeholder。
 *
 * WHY 不再单独渲染说明行：行内说明会被 el-form-item__content 的 flex-wrap 挤到下拉框下方，
 * 既占高度又压住输入框（截图问题）；placeholder 天然是空值态的位置，信息不丢且零额外高度。
 */
const checkPlaceholder = computed(() =>
  checkOptionsScoped.value
    ? `已按产品类型收窄（${checkOptions.value.length} / ${acceptedChecks.value.length} 条），仅列「接受」结论的检查记录`
    : pt('只列出「接受」结论的检查记录')
);

/** 策略选项；run_if_needed 已从新受理移除，不再作为可选项出现 */
/**
 * 入库策略选项。
 *
 * - require_passed「检查通过后入库」：选一条已「接受」的检查单，带 checkUid 创建入库任务。
 * - direct「直接入库」：前端自动编排——提交前先用所选文件+模型建一次元数据检查，
 *   等检查结论为「接受」后再以 require_passed 创建入库任务（创建侧只认 require_passed，
 *   故 direct 不会原样透传给后端，仅是本页的一种交互模式）。
 * run_if_needed 仍不在选项中（新受理已移除）。
 */
const checkPolicyOptions = [
  { label: pt('检查通过后入库'), value: 'require_passed' as ImportCheckPolicy },
  { label: pt('直接入库（提交前自动检查）'), value: 'direct' as ImportCheckPolicy }
];

const priorityOptions = [
  { label: pt('高'), value: 'high' },
  { label: pt('中'), value: 'medium' },
  { label: pt('低'), value: 'low' }
];

const securityLevelOptions = [
  { label: pt('公开'), value: 'public' },
  { label: pt('内部'), value: 'internal' },
  { label: pt('机密'), value: 'secret' }
];

/** 当前策略是否为「检查通过后入库」 */
const isRequirePassed = computed(() => model.checkPolicy === 'require_passed');

/** 当前策略是否为「直接入库」（提交前自动建检查，通过后再入库） */
const isDirect = computed(() => model.checkPolicy === 'direct');

/** 检查单必填（prop="checkUid" 指向 form model，提交前 createDialog 会走这项校验） */
const checkRules = [{ required: true, message: pt('请选择一条「接受」结论的检查记录'), trigger: ['blur', 'change'] }];

/** 入库任务名称必填（原 el-input required 改手写 el-form-item 后由本规则承接校验） */
const batchNameRules = [{ required: true, message: pt('请输入入库任务名称'), trigger: ['blur', 'change'] }];

/** 元数据模型必填（仅 direct 策略的 form-item 渲染，require_passed 下不生效） */
const modelRules = [{ required: true, message: pt('请选择元数据模型（提交前自动检查需要）'), trigger: ['blur', 'change'] }];

/**
 * 检查记录是否带有服务端可复核的「指纹快照」。
 *
 * WHY 必须自己判：契约只要求 require_passed 的结论是 accepted，但**创建入库时服务端还要复核
 * sizeBytes/sha256**（"服务端按 checkUid 读取完整文件清单、dataFiles 与 sizeBytes/sha256 快照并复核"）。
 * 实测（2026-11-11，本环境 15 条检查记录）：结论 accepted=true 的 6 条里只有 3 条的
 * `fileResults[]` 带 sha256/sizeBytes，其余 3 条 `fileResults` 是空数组（历史记录未回填扫描结果）
 * ——这 3 条提交必然被 409 `CHECK_BINDING_MISMATCH`「检查记录缺少选中文件清单与指纹」打回。
 * 因此把「有指纹」当成能否入库的**第二道**判据提前拦下，而不是让用户点了提交才吃 409。
 *
 * CONSTRAINT 详情接口没有顶层 sha256/sizeBytes（实测 keys=[]），指纹只在 fileResults 元素里；
 * 且 fileResults 为空可能表示「未扫描完成」而非「文件没有指纹」，所以空数组一律按不可入库处理。
 */
const checkFingerprinted = computed(() => {
  const list = checkDetail.value?.fileResults;
  if (!Array.isArray(list) || !list.length) return false;
  return list.every((item) => !!item?.sha256 && typeof item?.sizeBytes === 'number');
});

/** 按 uid 反查类别名（direct 下 el-tree-select 的选中态文本不外露，只能从同源 options 自查） */
const selectedTypeName = computed(() => {
  if (isRequirePassed.value) {
    // require_passed 的类别由检查记录带出，取路径末段比反查类别树更准（检查记录的类别可能不在当前根下）
    const path = String(checkDetail.value?.productCategoryPath || selectedCheck.value?.productCategoryPath || '');
    const leaf = path.split('/').filter(Boolean).pop();
    if (leaf) return leaf;
  }
  const hit = flattenNodes(options.value).find((n: any) => n.categoryUid === model.categoryUid) as any;
  return hit?.categoryName ?? '';
});

/**
 * 入库批次名称自动生成：产品-入库-时间戳。
 *
 * 产品取当前选中的产品类型（require_passed 由检查记录类别带出、direct 由左树带出，
 * 见 selectedTypeName）；时间戳取名称生成那一刻的本地时间 yyyyMMddHHmmss。
 * 计算属性只在依赖变化时重算，因此来源不变时名称稳定，不会每次渲染都跳秒。
 */
const autoBatchName = computed(() => {
  const product = selectedTypeName.value;
  if (!product) return '';
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, '0');
  const ts = `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
  return `${product}-入库-${ts}`;
});

/** 用户手改过名称后不再自动覆盖，避免正在编辑的内容被 watch 抹掉 */
const batchNameEdited = ref(false);

watch(autoBatchName, (name) => {
  if (!batchNameEdited.value) model.batchName = name;
});

/** 用户改动名称框：非空即锁定手工值；清空则立刻回落自动生成名 */
function handleBatchNameInput() {
  if ((model.batchName || '').trim()) {
    batchNameEdited.value = true;
  } else {
    batchNameEdited.value = false;
    model.batchName = autoBatchName.value;
  }
}

/**
 * BrowseDialog 回填：把所选文件作为一批来源全量覆盖进清单。
 *
 * CONSTRAINT 字段语义（2026-11-12 多来源契约）：
 *   - registered_share：locationUid → source.storageUid；dataRootPath → source.rootPath；
 *   - direct_shared_path：无 locationUid，rootPath 是 BrowseDialog 返回的完整 UNC 根，
 *     作为 source.rootPath、storageUid 留空；
 *   - files：相对该数据根的文件/目录路径，元素**原样进入 sourcePath**，不做前缀运算；
 *   - targets：与 files 同序的入库目标路径（弹窗里拖过目录后才有差异）。
 *
 * WHY 用 replaceSourceBatch 全量覆盖：BrowseDialog 每次回填发的都是「当前全部已选」，
 * 取消勾选时列表变短，只有全量覆盖才能把被取消的文件从清单移除（与检查页同口径）。
 * 这与手填路径 / 本地上传的「追加」语义不同，务必保持分流。
 */
function onPick(
  payload: { locationUid: string; dataRootPath: string; files: string[]; fileNames: string[]; path: string; targets?: string[] },
  sourceType: 'registered_share' | 'direct_shared_path'
) {
  const storageUid = sourceType === 'registered_share' ? String(payload?.locationUid || '').trim() : '';
  const rootPath = payload?.dataRootPath ?? payload?.path ?? '';
  const files = Array.isArray(payload?.files) ? payload.files.filter(Boolean).slice() : [];
  const targets = Array.isArray(payload?.targets) && payload.targets.length === files.length ? payload.targets.slice() : files.slice();
  if (!files.length) {
    ElMessage.info(pt('未选择文件，入库清单未变更'));
    return;
  }
  if (!rootPath) {
    ElMessage.warning(pt('未获取到数据根路径，入库清单未变更'));
    return;
  }
  // 三种来源可共存：共享目录 / UNC 各自按 sourceKey 覆盖自己的批次，不清空其它类型
  replaceSourceBatch({ source: { storageUid, rootPath }, label: labelOfShare(rootPath), files, targets });
}

/**
 * 打开共享位置/UNC 浏览弹窗（BrowseDialog + createDialog），交互与「元数据检查」页一致。
 * registered_share：登记共享目录 / 数据根 / 文件；direct_shared_path：输入 UNC 根后浏览勾选。
 * CONSTRAINT footer:false —— BrowseDialog 自带确认/取消，外层 createDialog 的按钮会二次提交。
 */
function openBrowseDialog(sourceType: 'registered_share' | 'direct_shared_path', uncPath = '') {
  const isRegistered = sourceType === 'registered_share';
  let dialog: ReturnType<typeof createDialog> | null = null;
  dialog = createDialog({
    title: isRegistered ? pt('选择元数据位置') : pt('添加共享路径来源'),
    width: '820px',
    footer: false,
    closeOnClickModal: false,
    bodyStyle: { padding: '12px 16px', display: 'flex', flexDirection: 'column', overflow: 'hidden' },
    render: () =>
      h(BrowseDialog, {
        sourceType,
        uncPath,
        pickFilter: 'selectable',
        mode: 'auto',
        metadataOnly: false,
        locationUid: '',
        path: '',
        files: [],
        onPick: (payload: any) => {
          onPick(payload, sourceType);
          dialog?.close();
        },
        onCancel: () => dialog?.close()
      })
  });
}

/** 清单工具栏「选择共享目录」：替代原表单里的「元数据位置」单独控件 */
function openShareDirDialog() {
  openBrowseDialog('registered_share');
}

/** 清单工具栏「添加共享路径来源」：UNC 路径输入已并入 BrowseDialog */
function addUncSource() {
  openBrowseDialog('direct_shared_path');
}

/**
 * 用下拉树的**全量**结果覆盖某个登记位置批次。
 *
 * WHY 是替换而不是 addSourceBatch 的合并：树上的勾选状态在 BrowseDialog 内部累积，
 * 每次回填发出的都是「当前全部已选」。若走合并语义，用户在树上**取消勾选**某个文件时，
 * 服务端发来的更短列表只会「更新已存在、追加新文件」，被取消的那个永远删不掉 ——
 * 表现为「树里取消勾选，清单里还在」。手填路径与本地选文件才是追加语义，
 * 所以两者必须分开。
 */
function replaceSourceBatch(entry: SourceEntry) {
  const key = sourceKeyOf(entry);
  const at = sourceEntries.value.findIndex((item) => sourceKeyOf(item) === key);
  const next: SourceEntry = { ...entry, files: entry.files.slice(), targets: entry.targets.slice() };
  if (at >= 0) {
    sourceEntries.value = sourceEntries.value.map((item, index) => (index === at ? next : item));
  } else if (next.files.length) {
    // 空结果且此前没有该批次（用户只是展开树看了看）：不留空壳
    sourceEntries.value = sourceEntries.value.concat([next]);
  }
  rebuildSourceRows();
}

/** 来源批次展示名：登记位置的数据根末段（空=登记根） */
function labelOfShare(rootPath: string): string {
  const raw = String(rootPath || '')
    .replace(/[\\/]+$/, '')
    .replace(/\\/g, '/');
  return raw.split('/').filter(Boolean).pop() || '共享根';
}

/**
 * 追加（或合并）一个来源批次，随后重建清单。
 *
 * WHY 要合并同源批次：下拉树是「勾选即回填」的，用户在同一数据根下先勾 A 再加勾 B
 * 会连续触发两次 pick；若不合并，清单里会出现两个「共享根」批次，用户没法理解
 * 也不利于后续按来源整批撤除。判据用 sourceKeyOf（storageUid+rootPath / upload / UNC 根）。
 */
function addSourceBatch(entry: SourceEntry) {
  const key = sourceKeyOf(entry);
  const exist = sourceEntries.value.find((item) => sourceKeyOf(item) === key);
  if (exist) {
    const merged: SourceEntry = { ...exist, source: { ...entry.source }, label: entry.label, isUpload: entry.isUpload };
    merged.files = exist.files.slice();
    merged.targets = exist.targets.slice();
    for (let i = 0; i < entry.files.length; i += 1) {
      const path = entry.files[i];
      if (!path) continue;
      const at = merged.files.indexOf(path);
      if (at >= 0) {
        // 同一文件重复勾选：以最新的 targetPath 为准（选择器内部可能刚拖过目录）
        merged.targets[at] = entry.targets[i] || path;
        continue;
      }
      merged.files.push(path);
      merged.targets.push(entry.targets[i] || path);
    }
    sourceEntries.value = sourceEntries.value.map((item) => (item === exist ? merged : item));
  } else {
    sourceEntries.value = sourceEntries.value.concat([{ ...entry, files: entry.files.slice(), targets: entry.targets.slice() }]);
  }
  rebuildSourceRows();
}

/**
 * 撤掉匹配的来源批次。
 *
 * @param matcher 来源字段匹配（三型任一）；`{storageUid:'',rootPath}` 专门表示「清空了共享目录选择」
 * @param all true=删该来源下所有批次（清空选择时用），false=只删首个匹配批次
 */
function removeSourceBatch(matcher: ImportFileSource, all = false) {
  const strip = (value?: string) => String(value ?? '').trim();
  const matches = (entry: SourceEntry) => {
    if (matcher.storageUid !== undefined && strip(entry.source.storageUid) !== strip(matcher.storageUid)) return false;
    if (matcher.rootPath !== undefined && strip(entry.source.rootPath) !== strip(matcher.rootPath)) return false;
    if (matcher.uploadUid !== undefined && strip(entry.source.uploadUid) !== strip(matcher.uploadUid)) return false;
    return true;
  };
  let removed = false;
  sourceEntries.value = sourceEntries.value.filter((entry) => {
    if (!matches(entry)) return true;
    if (removed && !all) return true;
    removed = true;
    return false;
  });
  // 上传文件对象挂在本组件的 uploadFileList 上，批次被撤时必须一起摘掉，
  // 否则 save() 仍会把它们上传成一个没人引用的孤儿会话
  if (matcher.uploadUid !== undefined) {
    const keep = new Set<string>();
    for (const entry of sourceEntries.value) if (entry.isUpload) for (const path of entry.files) keep.add(path);
    uploadFileList.value = uploadFileList.value.filter((item) => keep.has(uploadPathOf(item)));
  }
  rebuildSourceRows();
}

/**
 * 由本地上传建批次：选好文件先挂在内存里，提交时才真正建上传会话。
 *
 * WHY 不在这里就上传：上传会话有有效期（finalize 后过期即作废），用户可能选了文件
 * 又去改别的字段，提前上传会把 uid 拖到过期；save() 里统一上传更稳妥。
 */
const uploadPickerRef = ref<HTMLInputElement | null>(null);

/** 触发隐藏的文件选择框（清单工具栏的「本地上传」按钮） */
function triggerUploadPicker() {
  uploadPickerRef.value?.click();
}

/** 隐藏 input 选中文件后：登记为 upload 批次并加入清单 */
function onUploadPicked(event: Event) {
  const input = event.target as HTMLInputElement;
  const list = Array.from(input.files ?? []);
  // 清空 value 允许「同一个文件再选一次」也能触发 change
  input.value = '';
  if (!list.length) return;
  // 三种来源可共存：本地上传作为独立批次追加，不清空已选的共享目录/共享路径批次
  const paths = list.map((file) => (file as File & { webkitRelativePath?: string }).webkitRelativePath || file.name);
  const exist = sourceEntries.value.find((entry) => entry.isUpload);
  const files = exist ? exist.files.slice() : [];
  const targets = exist ? exist.targets.slice() : [];
  for (const path of paths) {
    if (!path || files.includes(path)) continue;
    files.push(path);
    targets.push(path);
  }
  /**
   * 文件对象单独存进 uploadFileList（sourceEntries 只留路径字符串）：
   * 真正上传需要 File/Blob，路径字符串拿不到字节流。
   */
  const incoming = list
    .map(
      (file) =>
        ({ name: (file as File & { webkitRelativePath?: string }).webkitRelativePath || file.name, size: file.size, raw: file }) as UploadUserFile
    )
    .filter((item) => !uploadFileList.value.some((old) => uploadPathOf(old) === item.name));
  uploadFileList.value = uploadFileList.value.concat(incoming);
  addSourceBatch({ source: {}, label: pt('本地上传'), files, targets, isUpload: true });
  ElMessage.success('已加入 ' + list.length + ' 个本地文件，提交时统一上传');
}

/* ---------------- from-check 候选清单（2026-11-12 契约） ---------------- */

/**
 * 候选里的一行：role=metadata 是检查单锁定的元数据，role=data 是用户从某个来源选的文件。
 *
 * WHY data 行要自带 source（2026-11-12 契约）：任务级 source 已停用，来源下沉到 dataFiles[]
 * 每条。三种手动来源可共存，各行带上自己的来源根，与 from-check 数据行在同一份清单里各自正确解析。
 */
interface CandidateRow {
  /** 稳定身份键：含来源标识，避免不同来源下同名文件互相覆盖 */
  id: string;
  sourcePath: string;
  targetPath: string;
  /** metadata 行：sourcePath 只读、不可删；targetPath 仍可拖动覆盖（契约允许） */
  locked: boolean;
  role: 'metadata' | 'data';
  sizeBytes?: number;
  /** data 行归属的来源（metadata 行必须为空 —— 契约：元数据来源由检查单决定） */
  source?: ImportFileSource;
  /** 来源展示名（清单里标在行尾，让用户能分辨混排的多批次） */
  sourceLabel?: string;
  /** 数据行勾选状态：false=不进入 dataFiles 提交载荷（默认勾选）；metadata 行忽略此字段 */
  checked?: boolean;
}

const candidateRows = ref<CandidateRow[]>([]);
const candidatesLoading = ref(false);
const candidatesError = ref('');

/**
 * 拉取 from-check 候选并映射成可编辑清单。
 *
 * WHY 必须用 candidates 而不是检查详情的 files：候选里带 role=metadata 标记，
 * 只有它能告诉我们「哪些行是检查单锁定、哪些行可删」；自己按扩展名猜角色，
 * 一旦与后端冻结口径不一致，提交时元数据 sourcePath 对不上就是 409。
 *
 * CONSTRAINT 锁定元数据行的真源是响应的 metadataFiles（权威全量清单），
 * 不是 items 里 role=metadata 的分页切片：items 受 cursor/limit 限制，实测 74 个
 * 元数据在第一页 items 只出现 10 个，靠 items 过滤会静默漏掉大部分元数据行。
 *
 * CONSTRAINT targetPath 的默认值：
 *   - metadata 行**原样沿用检查单里的 sourcePath**（契约要求 sourcePath 冻结，
 *     targetPath 默认保持一致最不容易误伤；用户要挪位置再手动改）；
 *   - data 行默认 targetPath = sourcePath（与旧 dataFiles 语义等价）。
 *   换数据目录时不重算 targetPath —— 新目录的层级结构与检查目录未必同构，
 *   自动重算会把文件塞到用户没预期的位置。
 */
/**
 * 由 candidates 的来源口径派生 dataFiles 逐条要带的 ImportFileSource。
 *
 * CONSTRAINT 与后端 normalizeFileSource 对齐：
 *  - registered_share → storageUid（rootPath 为登记根内相对路径）；
 *  - upload → uploadUid；
 *  - direct_shared_path → 仅完整 UNC rootPath，不带 storageUid/uploadUid。
 * 识别不出合法来源时返回 undefined：这些行会进「缺来源」提示，提交前明确拦下，
 * 好过硬塞一个会被后端 400「数据文件来源无效」拒收的组合。
 */
function deriveCandidatesSource(data?: FromCheckCandidatesResult): ImportFileSource | undefined {
  const sourceType = String(data?.sourceType ?? '');
  const rootPath = String(data?.rootPath ?? '');
  if (sourceType === 'registered_share') {
    const uid = String(data?.sourceStorageUid ?? '').trim();
    return uid ? { storageUid: uid, rootPath } : undefined;
  }
  if (sourceType === 'upload') {
    const uid = String(data?.sourceUploadUid ?? '').trim();
    return uid ? { uploadUid: uid } : undefined;
  }
  // direct_shared_path：只有完整 UNC 根才是合法来源
  if (/^\\\\[^\\]+\\[^\\]+/.test(rootPath)) return { rootPath };
  return undefined;
}

/**
 * 由「检查详情 + candidates」派生 from-check 提交的任务级 source。
 *
 * CONTEXT 文档 §3（2026-11-18）声明前端不传 source，但部署后端实测：
 *   registered_share 缺任务级/逐条 source → 400「数据文件来源缺失」，
 *   只给 storageUid 不给 rootPath → 400「数据文件不存在」，
 *   只给 rootPath（无 uid） → 400「数据来源根不可用」，
 *   任务级 source{storageUid,rootPath} → 200。
 * candidates 只回 sourceType/rootPath，storageUid 只有检查详情有；因此保存阶段补拉详情，
 * 合并出合法来源。切换检查单仍只有 candidates 一个请求（约束仅限切换动作）。
 */
function deriveCheckTaskSource(detail: MetadataCheckTaskSummary | null, cand?: FromCheckCandidatesResult | null): ImportFileSource | undefined {
  const storageUid = String(detail?.sourceStorageUid ?? '').trim();
  const uploadUid = String(detail?.uploadUid ?? cand?.sourceUploadUid ?? '').trim();
  const rootPath = String(cand?.rootPath || detail?.dataRootPath || '');
  if (storageUid) return { storageUid, rootPath };
  if (uploadUid) return { uploadUid };
  // direct_shared_path：复用既有 UNC 判据，非完整 UNC 返回 undefined 让提交拦下
  return deriveCandidatesSource({ sourceType: 'direct_shared_path', rootPath } as FromCheckCandidatesResult);
}

async function loadCandidates(checkUid: string) {
  if (!checkUid) {
    candidateRows.value = [];
    return;
  }
  candidatesLoading.value = true;
  candidatesError.value = '';
  try {
    /**
     * 权威清单来自 metadataFiles / dataFiles（不受分页影响），items 只是当前页的浏览切片。
     * 元数据 = metadataFiles；数据 = dataFiles（需求 2026-11-18 明确口径）。
     */
    const res = await listFromCheckCandidates(checkUid, {});
    const data = res?.data;
    candidatesData.value = (data ?? null) as FromCheckCandidatesResult | null;
    const metaSource: Array<{ relativePath?: string; sizeBytes?: number }> =
      data?.metadataFiles && data.metadataFiles.length ? data.metadataFiles : (data?.items ?? []).filter((it) => it.role === 'metadata');
    const metaSeen = new Set<string>();
    const metaRows: CandidateRow[] = metaSource
      .filter((it) => !!it?.relativePath)
      .filter((it) => !metaSeen.has(it.relativePath!) && !!metaSeen.add(it.relativePath!))
      .map((it) => {
        return {
          // id 用 sourcePath：候选清单里同一文件只出现一次，天然唯一；后续增删都不会撞
          id: it.relativePath!,
          sourcePath: it.relativePath!,
          targetPath: it.relativePath!,
          locked: true,
          role: 'metadata',
          sizeBytes: it.sizeBytes
        } as CandidateRow;
      });
    /**
     * 数据行 = 接口的 dataFiles（权威全量），逐条带来源：
     *  - 元数据行来自 metadataFiles（不带 source，来源由检查单决定）；
     *  - 数据行严格取 dataFiles（需求明确口径：元数据=metadataFiles，数据=dataFiles），
     *    来源是本次候选的 sourceType/rootPath 派生，与后端 normalizeFileSource 同口径，
     *    提交时逐条带 source 才不会 400。
     */
    const dataSrc = deriveCandidatesSource(data);
    const dataSourceLabel =
      data?.sourceType === 'registered_share' ? pt('共享根') : data?.sourceType === 'upload' ? pt('本地上传') : pt('检查数据来源');
    const dataSeen = new Set<string>();
    const dataPaths = (data?.dataFiles ?? [])
      .map((it) => ({ ...it, relativePath: String(it?.relativePath ?? '') }))
      .filter((it) => !!it.relativePath)
      .filter((it) => !dataSeen.has(it.relativePath) && !!dataSeen.add(it.relativePath))
      .map((it) => it.relativePath);
    /**
     * 同步来源批次：用 candidates 的 dataFiles 覆盖「检查单数据」批次，
     * 手动来源批次（共享目录 / UNC / 上传）保留。数据行统一由 buildSourceRows 从批次派生
     * （带本批次 source 与 label），避免 UI 行与 dataSelections 两套来源打架。
     */
    sourceEntries.value = [
      ...sourceEntries.value.filter((entry) => !entry.fromCheck),
      ...(dataPaths.length
        ? [
            {
              source: dataSrc ?? {},
              label: dataSourceLabel + '（检查单）',
              files: dataPaths,
              targets: dataPaths.slice(),
              fromCheck: true
            } as SourceEntry
          ]
        : [])
    ];
    candidateRows.value = metaRows.concat(buildSourceRows());
  } catch (e) {
    candidatesError.value = (e as Error)?.message || '候选清单加载失败';
    candidateRows.value = buildSourceRows();
  } finally {
    candidatesLoading.value = false;
  }
}

/* ---------------- 入库清单：共享树组件（selected-file-tree）+ 来源联动 ---------------- */

/** targetPath 的文件名部分 */
function nameOfTarget(targetPath: string): string {
  const segs = String(targetPath || '')
    .replace(/^\/+/, '')
    .split('/')
    .filter(Boolean);
  return segs.length ? segs[segs.length - 1] : String(targetPath || '');
}

/** 来源行 id 前缀：与检查单 metadata 行（id=relativePath）区分，重建时不会互相误伤 */
const SOURCE_ROW_PREFIX = 'src:';

/**
 * 清单层保存的「批次键|sourcePath → targetPath」覆盖表。
 *
 * WHY 单独存一张表而不是只写批次里的 targets：
 *   1) 本地上传的文件还在内存里（没有落盘路径），若只靠批次 targets，
 *      用户在上传清单里拖出来的目录一重建就丢；
 *   2) 重建清单（buildSourceRows）按 sourcePath 重新派生行，
 *      用「批次键+sourcePath」作键才能让「同一文件」的路径覆盖稳定存活
 *      （行 id 里带批次键但不带位置，顺序一变也要能命中）。
 */
const targetOverrides = ref<Record<string, string>>({});

/** 上传项的相对路径（与检查页同口径：优先 webkitRelativePath，其次文件名） */
function uploadPathOf(item: UploadUserFile): string {
  const raw = item.raw as (File & { webkitRelativePath?: string }) | undefined;
  return raw?.webkitRelativePath || raw?.name || item.name || '';
}

/**
 * 来源批次的稳定标识（用作覆盖表的键前缀，也是合并同源批次的判据）。
 *
 * WHY 不用批次下标：批次会随用户删除而前移，下标一变覆盖表就错位；
 * 用「来源三字段 + 是否上传」拼出的字符串才是稳定身份。
 */
function sourceKeyOf(entry: SourceEntry): string {
  // from-check 数据批次单独成键：即使与手动来源指向同一根，也不能被 addSourceBatch 合并，
  // 否则用户清空手动选择时会把检查单的数据文件一起删掉。
  if (entry.fromCheck) return 'from-check';
  if (entry.isUpload || entry.source.uploadUid) return 'upload';
  if (entry.source.storageUid) return 'share:' + entry.source.storageUid + ':' + (entry.source.rootPath ?? '');
  return 'unc:' + (entry.source.rootPath ?? '');
}

/** 手动来源的类型；from-check（检查单带出的数据批次）单独成类 */
type ManualSourceType = 'registered_share' | 'direct_shared_path' | 'upload';

/** 判定一个来源批次属于哪种手动来源；from-check 不属于手动来源 */
function manualSourceTypeOf(entry: SourceEntry): ManualSourceType | 'fromCheck' {
  if (entry.fromCheck) return 'fromCheck';
  if (entry.isUpload || entry.source.uploadUid) return 'upload';
  if (entry.source.storageUid) return 'registered_share';
  return 'direct_shared_path';
}

/** 行 id 里的批次键与路径分隔符（\u0000 不会出现在真实路径里） */
const ROW_ID_SEP = '\u0000';

/** 从来源行 id 里取出所属批次键（metadata 行没有批次键，返回空串） */
function batchKeyOfRow(row: CandidateRow): string {
  if (row.role !== 'data') return '';
  const body = String(row.id || '').slice(SOURCE_ROW_PREFIX.length);
  const at = body.indexOf(ROW_ID_SEP);
  return at < 0 ? '' : body.slice(0, at);
}

/**
 * 由来源批次派生「来源行」。
 *
 * WHY 以批次为单位：来源下沉到逐文件 dataFiles，每批自带自己的根；三种手动来源可共存，
 * 且与 from-check 数据批共存，每条提交时都要带上自己那份 source。
 */
function buildSourceRows(): CandidateRow[] {
  const rows: CandidateRow[] = [];
  // 按行 id 记住既有勾选状态：重选来源/重建清单时不要把用户已勾掉的文件又勾回来
  const checkedById = new Map(candidateRows.value.map((r) => [r.id, r.checked]));
  for (const entry of sourceEntries.value) {
    const key = sourceKeyOf(entry);
    for (let index = 0; index < entry.files.length; index += 1) {
      const path = entry.files[index];
      if (!path) continue;
      const overrideKey = key + '|' + path;
      const id = SOURCE_ROW_PREFIX + key + ROW_ID_SEP + path;
      const prior = checkedById.get(id);
      rows.push({
        id,
        sourcePath: path,
        targetPath: targetOverrides.value[overrideKey] || entry.targets[index] || path,
        locked: false,
        role: 'data',
        source: { ...entry.source },
        sourceLabel: entry.label,
        checked: prior === undefined ? true : prior
      });
    }
  }
  return rows;
}

/**
 * 用当前来源批次重建统一清单。
 *
 * CONSTRAINT metadata 行（检查单锁定）永远保留且排在最前：它们由检查单冻结，
 * 与用户新选的来源文件是两类东西 —— 前者不可删，后者随选择变化。
 */
function rebuildSourceRows() {
  const lockedRows = candidateRows.value.filter((row) => row.role === 'metadata');
  candidateRows.value = lockedRows.concat(buildSourceRows());
}

/**
 * 把统一清单里的来源行回写来源批次（拖动改目标路径、删除改文件集合）。
 *
 * WHY 必须回写：清单上的拖动与删除若不回流到 sourceEntries，
 * 下一次 rebuild（切检查单、重选位置）会把用户的改动全部冲掉，
 * 提交时 buildImportPayload 拿到的也还是旧值 —— 界面与载荷各说一套。
 */
function syncSourceFromRows() {
  const rows = candidateRows.value.filter((row) => row.role === 'data');
  const next: Record<string, string> = {};
  const alive: SourceEntry[] = [];
  for (const entry of sourceEntries.value) {
    const key = sourceKeyOf(entry);
    const mine = rows.filter((row) => batchKeyOfRow(row) === key);
    if (!mine.length) continue;
    entry.files = mine.map((row) => row.sourcePath);
    entry.targets = mine.map((row) => row.targetPath || row.sourcePath);
    for (const row of mine) next[key + '|' + row.sourcePath] = row.targetPath || row.sourcePath;
    alive.push(entry);
  }
  // 用户拖出来的目录即使对应行被删也要记住，否则重建后目录节点消失
  for (const [key, value] of Object.entries(targetOverrides.value)) {
    if (!(key in next)) next[key] = value;
  }
  targetOverrides.value = next;
  sourceEntries.value = alive;
}

/** 清单里现有的目录路径（由各行 targetPath 的中间段派生） */
function existingDirs(): string[] {
  const set = new Set<string>();
  for (const row of candidateRows.value) {
    const segs = String(row.targetPath || '')
      .replace(/^\/+/, '')
      .split('/')
      .filter(Boolean);
    for (let i = 1; i < segs.length; i += 1) set.add(segs.slice(0, i).join('/'));
  }
  return Array.from(set);
}

/**
 * 第一个可调整入库路径的文件行（含 locked 的 metadata 行）。
 *
 * WHY 不再排除 locked：require_passed（默认策略）下清单主体是检查单锁定的 metadata 行，
 * 按 from-check 契约它们「sourcePath 不可换、不可删，但 targetPath 允许覆盖」。旧实现只找
 * !locked 行，导致拖动与「移入目录」在只有 metadata 行时全部失效 —— 这正是
 * 「入库清单拖动没起作用」的根因。locked 只约束删除与换源，不约束改 targetPath。
 */
function firstMovableRow(): CandidateRow | undefined {
  return candidateRows.value.find((r) => !!r.id);
}

/**
 * 落地一次入库路径改动。
 *
 * CONSTRAINT 只有 data 行需要回流 sourceEntries / targetOverrides（否则下次 rebuild 会被冲掉）；
 * metadata 行不挂在任何来源批次下，只改它自己的 targetPath 即可 —— metadataSelections 直接
 * 读 candidateRows，rebuildSourceRows 也会保留锁定行引用。若对 metadata 行也调 syncSourceFromRows，
 * 反而会把没有对应 data 行的空来源批次误删。
 */
function applyTargetPath(row: CandidateRow, targetPath: string) {
  row.targetPath = targetPath;
  if (row.role === 'data') syncSourceFromRows();
}

/** 共享树的拖动结果：只改 targetPath，不动 sourcePath（locked 行同样允许覆盖 targetPath） */
function onTreeMove(payload: { id: string; targetPath: string }) {
  const row = candidateRows.value.find((r) => r.id === payload.id);
  if (!row) return;
  applyTargetPath(row, payload.targetPath);
}

/**
 * 共享树的删除结果：来源行可从清单移除（同步回来源批次）；metadata 行不可删。
 *
 * CONSTRAINT 上传批次必须同时从 uploadFileList 摘掉对应 File：
 * 清单行是批次派生的，只删行不删文件，下一次 rebuild 又会长回来；
 * 文件与批次里都没了之后，syncSourceFromRows 会自动把空批次摘掉。
 */
function onTreeRemove(id: string) {
  const at = candidateRows.value.findIndex((r) => r.id === id);
  if (at < 0) return;
  const row = candidateRows.value[at];
  if (row.locked) return;
  if (row.source && row.sourceLabel === '本地上传') {
    const rel = row.sourcePath;
    const index = uploadFileList.value.findIndex((item) => uploadPathOf(item) === rel);
    if (index >= 0) uploadFileList.value.splice(index, 1);
  }
  candidateRows.value.splice(at, 1);
  syncSourceFromRows();
}

/**
 * 数据视图勾选：勾选决定该行是否进入 dataFiles 载荷（metadata 行不可勾选、恒定入库）。
 * 只改行上的 checked，不动 sourceEntries —— 勾选是「是否提交」的视图态，
 * 重建清单时由 buildSourceRows 按 id 还原，既不影响拖动/删除回流，也不会被冲掉。
 */
function onTreeCheck(payload: { id: string; checked: boolean }) {
  const row = candidateRows.value.find((r) => r.id === payload.id);
  if (!row || row.locked || row.role !== 'data') return;
  row.checked = payload.checked;
}

/**
 * 共享树的「移入目录」：把第一个可移动行（含 locked 的 metadata 行）移进 dirPath。
 *
 * WHY 取第一个文件行：树上的箭头按钮不携带「当前选中行」概念（el-tree 未开 highlight），
 * 让用户先点选再点箭头会多一步且容易点错；拖动才是精确操作，按钮是拖动不可用时的兜底。
 */
function onTreeMoveInto(dirPath: string) {
  const row = firstMovableRow();
  if (!row) {
    ElMessage.info(pt('没有可移动的文件'));
    return;
  }
  const name = nameOfTarget(row.targetPath || row.sourcePath);
  const next = dirPath ? dirPath + '/' + name : name;
  if (next === row.targetPath) {
    ElMessage.info(pt('该文件已在此目录下'));
    return;
  }
  applyTargetPath(row, next);
  ElMessage.success('已移入「' + (dirPath || '根目录') + '」');
}

/**
 * 按 2026-11-18 契约拆出的两份清单：
 * - metadataFiles：metadata 行，不带 source（来源由检查单决定）；
 * - dataFiles：data 行，各自带 source（多来源混排时相对各自的根解析 sourcePath）。
 *
 * WHY 必须拆分：新契约停用旧 files 清单，改用 metadataFiles（必填非空）+ dataFiles（可空），
 * 混传会 400；metadata 行的 sourcePath 必须逐字保留。
 */
function toSelection(r: CandidateRow): ImportFileSelection {
  const item: ImportFileSelection = { sourcePath: r.sourcePath, targetPath: r.targetPath || r.sourcePath };
  if (r.role === 'data' && r.source) item.source = { ...r.source };
  return item;
}
const metadataSelections = computed<ImportFileSelection[]>(() =>
  candidateRows.value.filter((r) => r.role === 'metadata' && !!r.sourcePath).map(toSelection)
);
/**
 * dataFiles 清单：只收非元数据的数据行。
 * 手动选的 .sms/.geojson 文件虽是 role='data'（展示时才按扩展名归到元数据 tab），但后端视其为元数据：
 * 同时出现在 metadataFiles（检查单冻结清单）与 dataFiles 会 400「元数据文件位置非法」；
 * 塞进 metadataFiles 又会 409「检查清单与元数据文件不一致」。故提交侧统一排除元数据扩展名。
 */
const dataSelections = computed<ImportFileSelection[]>(() =>
  candidateRows.value.filter((r) => r.role === 'data' && !!r.sourcePath && r.checked !== false && !isMetadataExt(r.sourcePath)).map(toSelection)
);
/** 合并视图（metadata + data），仅供仍按单清单展示/判空的逻辑使用 */
const candidateSelections = computed<ImportFileSelection[]>(() => [...metadataSelections.value, ...dataSelections.value]);

/** 清单里没有带 source 的 data 行（提交前提示用，空数组=全部就绪） */
const rowsMissingSource = computed(() => candidateRows.value.filter((r) => r.role === 'data' && !r.source));

/** metadata / data 计数（提交 role 口径，供 save() 前置校验 C-10 使用，不能被展示分类影响） */
const candidateCounts = computed(() => {
  const meta = candidateRows.value.filter((r) => r.role === 'metadata').length;
  return { meta, data: candidateRows.value.length - meta };
});

/**
 * 展示分类 vs 提交分类分离：
 * - 提交载荷（metadataSelections / dataSelections）严格按 role，必须与后端检查单冻结清单一致，否则 409；
 * - 展示按扩展名：手动选的 .sms/.geojson 元数据文件与检查单锁定的 metadata 行一并归入「元数据」tab
 *   （需求 2026-11-19：共享目录选的元数据显示到了数据 tab 下）。
 */
const METADATA_FILE_EXTS = ['sms', 'geojson'];
function isMetadataExt(path: string): boolean {
  const ext =
    String(path || '')
      .split('.')
      .pop()
      ?.toLowerCase() || '';
  return METADATA_FILE_EXTS.includes(ext);
}
/** 展示为元数据行：检查单锁定行，或按扩展名识别的手动元数据文件 */
function isMetadataDisplayRow(r: CandidateRow): boolean {
  return r.role === 'metadata' || isMetadataExt(r.sourcePath);
}

/**
 * 入库清单分区：元数据与数据分开显示（需求 2026-11-18）。
 * - 元数据一级平铺（flat）：元数据是一条条独立文件，按原顺序一行一个；
 * - 数据保持树结构：数据文件按 targetPath 的目录层级展示，支持拖动整理入库路径。
 */
const metadataRows = computed(() => candidateRows.value.filter(isMetadataDisplayRow));
const dataRows = computed(() => candidateRows.value.filter((r) => !isMetadataDisplayRow(r)));
/** 数据 tab 已勾选数量（展示口径），用于页签计数提示 */
const dataCheckedCount = computed(() => dataRows.value.filter((r) => r.checked !== false).length);

/**
 * 入库清单类型切换：一次只显示一种（元数据 / 数据）。
 * 仅控制展示，不影响 candidateRows 本身与提交载荷。
 */
const candidateView = ref<'metadata' | 'data'>('metadata');

/** 计算 sha256（十六进制小写）；契约要求 64 位，服务端 finalize 时复核 */
async function sha256Hex(bytes: ArrayBuffer): Promise<string> {
  // HTTP 非安全上下文下 globalThis.crypto?.subtle === undefined，直接调 digest 会抛
  // "Cannot read properties of undefined (reading 'digest')"；此时回落到 crypto-js，
  // 保证任何环境都返回真实的 64 位 hex，不污染 uploadPendingFiles 的分片载荷。
  if (globalThis.crypto?.subtle) {
    const digest = await crypto.subtle.digest('SHA-256', bytes);
    return Array.from(new Uint8Array(digest))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
  }
  return CryptoJS.SHA256(CryptoJS.lib.WordArray.create(bytes)).toString();
}

/**
 * 本地上传来源：create → 逐文件 PUT → finalize，返回 READY 的 uploadUid。
 *
 * WHY 必须走 data-uploads 而不是检查页的 uploadMetadataFile：后者是元数据检查通道
 * （绑定 modelUid/modelVersionUid），入库不能复用；入库的 source.type='upload'
 * 只认 data-uploads 会话 uid，最终以会话 READY 为前提。
 *
 * CONSTRAINT 单文件也按 partNo=1 走 parts 接口，与 API 注释一致；
 * 有预签名地址时优先直传（不经产品网关），否则回落中转接口。
 */
async function uploadPendingFiles(): Promise<string> {
  const items = uploadFileList.value.filter((item) => !!item.raw);
  if (!items.length) return '';
  uploadProgress.value = '准备上传…';
  try {
    const payloads = await Promise.all(
      items.map(async (item) => {
        const raw = item.raw as File;
        const bytes = await raw.arrayBuffer();
        return { name: uploadPathOf(item), bytes, size: raw.size, sha256: await sha256Hex(bytes) };
      })
    );
    /**
     * 契约 api-535725070：文件声明对象**只允许** path/sizeBytes/sha256 三个成员，
     * 多传 contentType 等会被后端判 400「数据上传请求无效」（实测复现，issues 为空数组）。
     * 上传内容的类型由 finalize 后按实际对象复核，不需在声明阶段传 contentType。
     */
    const decls: DataUploadFileDecl[] = payloads.map((p) => ({
      path: p.name,
      sizeBytes: p.size,
      sha256: p.sha256
    }));
    const created = await createDataUploadSession(decls);
    const session = created?.data;
    const uploadUid = String(session?.uploadUid || '');
    if (!uploadUid) throw new Error(pt('上传会话创建失败：未返回 uploadUid'));

    const tickets = session?.files ?? [];
    for (let i = 0; i < payloads.length; i += 1) {
      const payload = payloads[i];
      // 会话返回的 files 顺序与声明顺序一致；对不上时按 path 兜底查找
      const ticket = tickets[i]?.path === payload.name ? tickets[i] : tickets.find((t) => t.path === payload.name);
      if (!ticket?.fileUid) throw new Error('上传会话缺少文件指令：' + payload.name);
      uploadProgress.value = `上传中 ${i + 1}/${payloads.length}：${payload.name}`;
      if (ticket.parts?.length) {
        // 分片：按 part.sizeBytes 依次切片上传（缺省 sizeBytes 视为整文件为单片）
        let offset = 0;
        for (const part of ticket.parts) {
          const size = part.sizeBytes ?? payload.size;
          await putToSignedUrl(part.uploadUrl, payload.bytes.slice(offset, offset + size));
          offset += size;
        }
      } else if (ticket.uploadUrl) {
        await putToSignedUrl(ticket.uploadUrl, payload.bytes);
      } else {
        await putDataUploadPart(uploadUid, ticket.fileUid, 1, payload.bytes);
      }
    }

    uploadProgress.value = '校验上传结果…';
    const finalized = await finalizeDataUploadSession(uploadUid);
    if (!isDataUploadReady(finalized?.data)) {
      throw new Error(pt('上传会话未就绪（state 非 READY 或已过期），请重试'));
    }
    return uploadUid;
  } finally {
    uploadProgress.value = '';
  }
}

/**
 * 上传文件列表变化（增删/重选）时作废已缓存的 uploadUid。
 *
 * WHY 必须作废：uploadUid 绑定的是「上传那一刻的文件指纹」，用户增删文件后
 * 旧会话的 manifest 已与当前文件集不符，继续用会在 finalize 阶段校验失败。
 * 真正的上传在 save() 里按当时文件集重跑，故这里只清批次上的 uid。
 */
watch(
  () => uploadFileList.value.map((item) => uploadPathOf(item)).join('|'),
  () => {
    sourceEntries.value = sourceEntries.value.map((entry) => (entry.isUpload && entry.source.uploadUid ? { ...entry, source: {} } : entry));
  }
);

/**
 * 加载产品类型树（与「元数据检查」同源 /platform/product-categories）。
 * CONSTRAINT 按页面注入的语义根收窄；未命中回落顶层根，避免静默空树。
 *
 * WHY 复用 index.vue 传进来的 typeRoots：本组件与左侧树必须给出**同一棵树**。
 * 各拉一遍不但多打一次接口，更麻烦的是两次请求之间类别可能被别处改动（如管理面板刚写完），
 * 于是「树里选的是 A、弹窗里默认是 B」——用户无法从这个现象推断原因。
 */
async function loadTypes() {
  try {
    // 已由 index.vue 传入本页可见类型树：直接复用，跳过重复取数
    if (props.typeRoots?.length) {
      options.value = props.typeRoots;
      return;
    }
    const res: any = await getProductTypeList({});
    const roots = (res?.data?.items ?? []) as any[];
    const scoped = pickTypesByRoot(roots, props.categoryRoot || '');
    options.value = scoped.length ? scoped : roots.filter((n) => !n.parentCategoryUid);
    // 选项变化后若已选 uid 不在新树内，清空以防提交无效类别
    if (model.categoryUid) {
      const uids = new Set(flattenNodes(options.value).map((n: any) => n.categoryUid));
      if (!uids.has(model.categoryUid)) model.categoryUid = '';
    }
  } catch {
    // 拉取失败保留空树，不阻断其余字段填写
  }
}

/**
 * 加载检查记录（页码分页，一次拉满 pageSize 上限）。
 *
 * CONSTRAINT 2026-11-17 契约变更：检查列表改为 page/pageSize（cursor 已废弃，传了 400）。
 * 一次拉 pageSize=200（契约上限）覆盖近期记录；入库编辑只关心近期检查，故不做续页。
 * 后端默认隐藏「已被入库/补录消费」的检查单——入库本来就只能选未消费的单子，是期望口径；
 * 已绑定的单被别的入库消费后从列表消失的场景，由下方「详情接口复核（404 才撤销）」兜底。
 */
async function loadChecks() {
  checkLoading.value = true;
  try {
    const res: any = await listMetadataFileChecks({ pageSize: METADATA_CHECK_PAGE_MAX });
    checks.value = (res?.data?.items ?? []) as MetadataCheckTaskSummary[];
    /**
     * CONSTRAINT 只在「确实查到该记录且结论不是接受」时撤销绑定。
     *
     * WHY 不沿用旧的「不在列表里就清空」：共享上下文带过来的 checkUid 可能只是不在最近 200 条内，
     * 错误清空会让用户刚在检查页选好的单子莫名消失。查不到记录时交给详情接口复核
     * （404 才撤销），这才是服务端真源。
     */
    const hit = checks.value.find((row) => row.checkUid === model.checkUid);
    if (hit && !isMetadataCheckAccepted(hit)) {
      model.checkUid = '';
      checkDetail.value = null;
      ElMessage.warning(pt('所选检查记录的最终结论不是「接受」，已取消绑定，请重新选择'));
    }
  } catch {
    // 拉取失败保留空列表：不放行「无检查单」的 require_passed 提交，由 save 统一拦截并提示
    checks.value = [];
  } finally {
    checkLoading.value = false;
  }
}

/**
 * 拉取选中检查单的完整详情，作为提交前复核依据。
 *
 * WHY 必须拉详情：列表项只有 fileCount 摘要，而入库时服务端要按**完整清单 + dataFiles +
 * sizeBytes/sha256 快照**复核（契约原文）。只凭列表摘要提交，用户看不到服务端到底认哪些文件，
 * 一旦来源变化只能吃 409。这里把服务端将复核的内容提前摊开。
 *
 * CONSTRAINT 竞态防护：await 期间用户可能已换单，回来必须按当前 checkUid 比对，否则会把
 * 上一张单的清单显示在这一张单下面。
 */
async function loadCheckDetail(uid: string) {
  const key = String(uid || '').trim();
  checkDetail.value = null;
  detailError.value = '';
  if (!key) return;
  detailLoading.value = true;
  try {
    const res: any = await getMetadataFileCheck(key);
    if (model.checkUid !== key) return;
    checkDetail.value = (res?.data ?? null) as MetadataCheckTaskSummary | null;
    if (!checkDetail.value) {
      detailError.value = '检查记录详情为空，无法复核清单';
      return;
    }
    if (!isMetadataCheckAccepted(checkDetail.value)) {
      detailError.value = '该检查记录的最终结论不是「接受」，不能用于入库，请回「数据检查」重新检查';
    }
  } catch (error) {
    if (model.checkUid !== key) return;
    // 全局拦截器已对 4xx 弹过原始错误，这里只补「对表单意味着什么」，不重复报同一条
    if (isMetacheckError(error, 'CHECK_NOT_FOUND')) {
      detailError.value = '检查记录不存在或已被删除，已取消绑定，请重新选择';
      model.checkUid = '';
      checkDetail.value = null;
    } else {
      detailError.value = '检查记录详情加载失败：提交前无法复核清单，建议点「刷新」重试';
    }
  } finally {
    if (model.checkUid === key) detailLoading.value = false;
  }
}

/**
 * 切换检查单：清掉上一张单的清单与复核态，只按新 uid 拉候选清单。
 *
 * CONSTRAINT 切换动作只发 candidates 一个请求，不再额外拉检查详情（getMetadataFileCheck）：
 * 入库清单的全部内容（锁定元数据 + 可选数据 + 判定依据）都由 candidates 的权威字段给出，
 * 详情接口在切换路径上是冗余往返。下拉本身只列 accepted 检查单，提交时由服务端按 checkUid
 * 复核清单与指纹，缺指纹会在提交时收到 409，前端不必预先拉详情判断。
 */
function onCheckChange(uid: string) {
  checkDetail.value = null;
  candidatesData.value = null;
  detailError.value = '';
  candidateRows.value = [];
  candidatesError.value = '';
  loadCandidates(uid);
}

/** 生成客户端幂等键；同键重放服务端返回 409，不回读详情即可确认已受理 */
function genRequestId() {
  return 'import-' + Date.now() + '-' + Math.random().toString(36).slice(2, 10);
}

/**
 * 策略切换时清理上一策略的残留状态。
 *
 * - 切到 require_passed：清掉 categoryUid。契约要求带 checkUid 时 categoryUid 若提供必须与检查记录一致，
 *   留残值会 409；类别由检查记录带出。
 * - 切到 direct：清掉绑定的检查单与其清单/详情（direct 要现场新建一次检查，残留 checkUid 会误导用户）。
 *   类别改为取左侧树的选中项——「新建入库默认和左侧同步」，左树是 direct 下产品类型的唯一来源，
 *   也是入库任务名称里「产品名称」的来源（见 autoBatchName）。
 */
watch(
  () => model.checkPolicy,
  (policy) => {
    if (policy === 'require_passed') {
      model.categoryUid = '';
    } else if (policy === 'direct') {
      model.checkUid = '';
      model.categoryUid = props.defaultCategoryUid || '';
      checkDetail.value = null;
      candidatesData.value = null;
    }
    rebuildSourceRows();
  }
);

/**
 * 直接入库下「左侧树 ↔ 入库任务名称」联动。
 *
 * index.vue 把左侧产品类型树的选中项作为 defaultCategoryUid 传入。direct 策略下产品类型由左树唯一决定
 * （表单内不重复放类别字段），因此把它的变化同步进 model.categoryUid：
 *  - 提交载荷带上正确类别（runDirectPrecheck 的类别校验也靠它）；
 *  - selectedTypeName → autoBatchName 重算 → 名称随左树联动为「产品名称-入库-时间戳」。
 *
 * require_passed 下不同步：类别由检查单带出，左树只用于收窄检查单候选，写进 categoryUid 会 409。
 */
watch(
  () => props.defaultCategoryUid,
  (uid) => {
    if (isDirect.value) model.categoryUid = uid || '';
  }
);

/**
 * 提交失败后的动作提示。
 *
 * WHY 单独处理：`request.ts` 的拦截器只弹后端原文（「来源文件大小或内容摘要与检查快照不一致…」），
 * 用户知道出错了但不知道下一步该干什么。契约给了三个稳定英文码，据此给「该回哪一页做什么」。
 */
function handleSubmitError(error: unknown) {
  const action = resolveMetacheckErrorAction(error);
  if (!action) return;
  const tips: Record<string, string> = {
    recheck: pt('请回「数据检查」对该数据重新检查，再用新的检查单提交'),
    pickFiles: pt('请重新选择文件'),
    pickCategory: pt('请重新选择产品类别'),
    checkSource: pt('请检查共享位置与路径是否可用'),
    pickModel: pt('请先配置或选择元数据模型，或改走正常检查'),
    refresh: pt('请刷新列表后重试')
  };
  const tip = tips[action];
  if (!tip) return;
  ElMessage.warning(tip);
  // 服务端不认可该绑定：刷新列表与详情，让用户看到最新结论后再决定是否重检
  if (isRequirePassed.value) {
    loadChecks();
    if (model.checkUid) loadCheckDetail(model.checkUid);
  }
}

/**
 * 直接入库的提交前预检：用当前手动来源的文件现场建一次元数据检查，轮询到终态并通过后返回 checkUid。
 *
 * WHY 后端创建侧只接受 require_passed（direct 原样透传会 400），故"直接入库"实现为前端编排：
 * 现场建检查 → 等通过 → 拿 checkUid 走标准 from-check 入库路径，用户体感即"一键直接入库"。
 *
 * CONSTRAINT 检查接口仍是单来源三选一：入库清单虽可多来源共存，但现场检查只接受单一来源，
 * 因此 direct 策略下若选了多种手动来源会明确拦下，提示用户只保留一种；
 * files 用相对来源根的路径（不取 targetPath）。
 */
async function runDirectPrecheck(): Promise<string | undefined> {
  const manualEntries = sourceEntries.value.filter((entry) => !entry.fromCheck);
  if (!manualEntries.length) {
    ElMessage.warning(pt('请先选择要入库的数据文件/目录'));
    return undefined;
  }
  const sourceType = manualSourceTypeOf(manualEntries[0]);
  if (sourceType === 'fromCheck') {
    ElMessage.warning(pt('检查单来源不能用于直接入库，请重新选择数据文件'));
    return undefined;
  }
  /**
   * 检查接口单来源三选一：多来源批次的文件相对各自来源根，不能混进同一次检查的 files
   * （否则路径与来源根错配，后端 400）。入库清单本身支持多来源共存，但 direct 的
   * 现场预检必须只针对一种来源；要求用户收敛到一种来源后再提交。
   */
  const mixedTypes = new Set(manualEntries.map((entry) => manualSourceTypeOf(entry)));
  if (mixedTypes.size > 1) {
    ElMessage.warning(pt('直接入库的现场检查仅支持单一来源，请清空清单后只保留一种来源（共享目录 / 共享路径 / 本地上传）再提交'));
    return undefined;
  }
  if (!model.modelUid) {
    ElMessage.warning(pt('请选择元数据模型（提交前自动检查需要）'));
    return undefined;
  }
  if (!model.categoryUid) {
    ElMessage.warning(pt('请选择产品类型（直接入库需显式指定类别）'));
    return undefined;
  }

  const files: string[] = [];
  for (const entry of manualEntries) {
    for (const path of entry.files) {
      if (path && !files.includes(path)) files.push(path);
    }
  }
  if (!files.length) {
    ElMessage.warning(pt('所选来源下没有可检查的文件'));
    return undefined;
  }

  const first = manualEntries[0].source;
  let uploadUid: string | undefined;
  let sourceStorageUid: string | undefined;
  let dataRootPath: string | undefined;
  // 检查范围 files：upload 来源只针对元数据文件（必须是元数据上传批次清单的子集），其余来源保持原文件集
  let checkFiles = files;
  if (sourceType === 'upload') {
    /**
     * 【关键】checks/files 的 upload 来源只认 uploadMetadataFile 建立的「元数据上传批次」，
     * 不能复用入库数据会话（createDataUploadSession）的 uploadUid——两者是独立系统，
     * 把数据会话 uid 提交到检查接口会 400「元数据上传不存在或未就绪」。
     * 故本地上传来源下，元数据文件（.sms/.geojson）须单独走检查通道上传拿元数据专用 uid；
     * 检查 files 也只针对这批元数据文件，数据文件仍由数据会话负责、不进检查清单。
     */
    const metaItems = uploadFileList.value.filter((item) => !!item.raw && isMetadataExt(uploadPathOf(item)));
    if (!metaItems.length) {
      ElMessage.warning(pt('本地上传来源下没有元数据文件（.sms/.geojson），无法提交检查'));
      return undefined;
    }
    const metaFiles = metaItems.map((item) => item.raw as File);
    const preErr = precheckMetadataFiles(metaFiles);
    if (preErr) {
      ElMessage.warning(preErr);
      return undefined;
    }
    const metaPaths = metaItems.map(uploadPathOf);
    try {
      const uploaded = await uploadMetadataFile(model.modelUid, metaFiles, { relativePaths: metaPaths });
      uploadUid = String(uploaded?.data?.uploadUid ?? '').trim() || undefined;
    } catch (error) {
      ElMessage.error((error as Error)?.message || '元数据文件上传失败，请重试');
      return undefined;
    }
    if (!uploadUid) {
      ElMessage.warning(pt('元数据文件上传失败：未返回 uploadUid'));
      return undefined;
    }
    checkFiles = metaPaths;
  } else if (sourceType === 'registered_share') {
    sourceStorageUid = String(first.storageUid ?? '').trim() || undefined;
    dataRootPath = String(first.rootPath ?? '');
  } else {
    dataRootPath = String(first.rootPath ?? '');
  }

  const built = buildMetadataCheckPayload({
    modelUid: model.modelUid,
    categoryUid: model.categoryUid || undefined,
    taskName: model.batchName,
    files: checkFiles,
    sourceType,
    uploadUid,
    sourceStorageUid,
    dataRootPath,
    requestId: genRequestId()
  });
  if (!built.ok || !built.payload) {
    ElMessage.warning(built.message || '元数据检查载荷不完整，无法提交');
    return undefined;
  }

  const loadingMsg = ElMessage({ message: pt('正在提交元数据检查并等待结果，请稍候…'), type: 'info', duration: 0 });
  try {
    const submitted: any = await submitMetadataFileCheck(built.payload);
    if (isMetadataCheckNotAccepted(submitted)) {
      ElMessage.warning(metadataCheckNotAcceptedMessage(submitted));
      return undefined;
    }
    const checkUid = String(submitted?.data?.checkUid ?? '').trim();
    if (!checkUid) {
      ElMessage.warning(pt('元数据检查未返回任务号，无法继续入库'));
      return undefined;
    }

    // 轮询到终态：2s 间隔、最多 60 次（约 2 分钟）；跑完≠通过，还要看 accepted 与指纹快照
    const MAX_POLL = 60;
    let summary: MetadataCheckTaskSummary | null = null;
    for (let i = 0; i < MAX_POLL; i++) {
      await new Promise((resolve) => setTimeout(resolve, 2000));
      try {
        const detail: any = await getMetadataFileCheck(checkUid);
        summary = (detail?.data ?? null) as MetadataCheckTaskSummary | null;
      } catch {
        // 详情短暂不可用（刚受理时可能还没落库）不算失败，下一轮继续
        continue;
      }
      if (summary && isMetadataCheckFinished(summary)) break;
    }
    if (!summary || !isMetadataCheckFinished(summary)) {
      ElMessage.warning(pt('元数据检查超时未完成，请稍后重试或改走「检查通过后入库」'));
      return undefined;
    }
    if (!isMetadataCheckAccepted(summary)) {
      ElMessage.warning(pt('元数据检查结论不是「接受」，无法入库：请检查文件与元数据模型是否匹配'));
      return undefined;
    }
    const results = (summary as MetadataCheckTaskSummary & { fileResults?: Array<{ sha256?: string; sizeBytes?: number }> }).fileResults;
    if (!Array.isArray(results) || !results.length || !results.every((item) => !!item?.sha256 && typeof item?.sizeBytes === 'number')) {
      ElMessage.warning(pt('检查通过但缺少逐文件指纹快照，入库时服务端无法复核：请重新检查后再试'));
      return undefined;
    }
    ElMessage.success(pt('元数据检查通过，正在创建入库任务…'));
    return checkUid;
  } catch (error) {
    ElMessage.error((error as Error)?.message || '提交前元数据检查失败，请重试');
    return undefined;
  } finally {
    loadingMsg.close();
  }
}

/**
 * 保存：按策略分流校验 + 统一走 buildImportPayload 拼载荷。
 *
 * require_passed（默认）：必须选一条 accepted 且带指纹快照的检查记录；清单里的 data 条目
 *   各自携带自己那份 source；candidates 派生不出的部分（registered_share 的 storageUid）
 *   在保存阶段补拉检查详情、以任务级 source 兜底（实测后端仍要它，文档 §3 与部署不一致）；
 *   metadata 条目的 sourcePath 必须逐字保留、且**不得**带 source（由检查单决定）。
 * direct：必须选产品类别 + 至少 1 个文件/目录，且**每个 data 条目都必须带 source**；
 *   不得带 checkUid。
 * run_if_needed：已从新受理移除，直接拒绝并提示迁移（兜底，界面上已无此选项）。
 *
 * CONSTRAINT 所有「前端已用 ElMessage 提示过」的失败分支一律 `return undefined`，
 * 不返回 `{ code: 1, message }`：createDialog 会拿返回值的 code 判定，code!==0 时它自己再
 * `ElMessage.error(res.message)` 弹一次，用户就会看到两条几乎一样的提示（一条我们写的、
 * 一条它弹的）。返回 undefined 命中它的 `if (isUndefined(res)) return` —— 既不关弹窗
 * （保留已填内容），也不重复提示，提示权完全留在本函数。
 */
async function save() {
  if (model.checkPolicy === 'run_if_needed') {
    ElMessage.warning(DEPRECATED_CHECK_POLICY_NOTICE);
    return undefined;
  }

  // C-10：仅有元数据、无「已勾选」数据文件时阻断提交。检查单锁定的 metadata 行不算数据文件，
  // 用户必须勾选至少一个数据行；勾选决定入库范围，全部取消勾选等同无数据文件。
  if (candidateCounts.value.meta > 0 && candidateCounts.value.data === 0) {
    ElMessage.warning(pt('请上传数据文件'));
    return undefined;
  }
  if (candidateCounts.value.meta > 0 && dataSelections.value.length === 0) {
    ElMessage.warning(pt('请勾选至少一个数据文件'));
    return undefined;
  }

  /**
   * 只有元数据文件、没有任何数据文件时拦截（需求 2026-11-19）。
   *
   * WHY 上面 C-10 用 role 口径计数，而手动选的 .sms/.geojson 文件 role='data'、
   * 展示上归元数据 tab、提交时又被 r352 排除：若来源里只有这类文件，
   * meta(role)=0、data(role)>0 使 C-10 两道都不触发，最终 dataFiles=[]，无数据可入库。
   * 这里按展示口径兜底：元数据 tab 有文件、数据 tab 一个都没有时直接拦下，
   * 也让 direct 在白发一次提交前检查之前就停下。
   */
  if (metadataRows.value.length > 0 && dataRows.value.length === 0) {
    ElMessage.warning(pt('所选来源里只有元数据文件，没有可入库的数据文件，请重新选择数据文件'));
    return undefined;
  }

  // 名称兜底：自动生成靠 watch 触发，用户若从未改动来源/类别（例如进来就选了检查单但
  // 名称框为空时被清空过），这里再补一次，避免提交时才报「缺少 batchName」
  if (!String(model.batchName || '').trim()) {
    model.batchName = autoBatchName.value;
  }

  /**
   * 本地上传批次：提交前统一上传，把 uploadUid 回填到该批次的 source 上。
   *
   * WHY 不在选择文件时就传：上传会话 finalize 后有有效期，用户可能选完文件继续改
   * 其他字段，提前上传会把 uid 拖到过期。这里集中处理，一次会话覆盖整批文件。
   */
  const uploadBatches = sourceEntries.value.filter((entry) => entry.isUpload);
  if (uploadBatches.length) {
    if (!uploadFileList.value.some((item) => !!item.raw)) {
      ElMessage.warning(pt('本地上传来源下还没有文件，请先选择文件'));
      return undefined;
    }
    try {
      let uploadUid = '';
      for (const entry of uploadBatches) {
        if (entry.source.uploadUid) {
          uploadUid = entry.source.uploadUid;
          break;
        }
      }
      if (!uploadUid) uploadUid = await uploadPendingFiles();
      if (!uploadUid) {
        ElMessage.warning(pt('上传未完成，无法提交'));
        return undefined;
      }
      // 回填到所有上传批次的 source（同一会话内所有文件共用一个 uploadUid）
      sourceEntries.value = sourceEntries.value.map((entry) =>
        entry.isUpload ? { ...entry, source: { uploadUid }, files: entry.files.slice(), targets: entry.targets.slice() } : entry
      );
      rebuildSourceRows();
    } catch (error) {
      ElMessage.error((error as Error)?.message || '文件上传失败，请重试');
      return undefined;
    }
  }

  // 每条 data 行必须携带自己的来源：direct 下后端逐条校验，缺了就是 400「数据文件来源缺失」
  if (rowsMissingSource.value.length) {
    const first = rowsMissingSource.value[0];
    ElMessage.warning('「' + first.sourcePath + '」没有来源，请重新选择它所在的来源');
    return undefined;
  }

  /**
   * 直接入库：提交前先用本次手动来源的文件现场建一次元数据检查，等通过拿到 checkUid，
   * 再把它当作"选中的检查单"加载权威清单，复用下面 require_passed 的标准入库路径。
   * 后端创建侧只认 require_passed，direct 不原样透传（见 runDirectPrecheck）。
   */
  if (isDirect.value) {
    const precheckUid = await runDirectPrecheck();
    if (!precheckUid) return undefined;
    // 竞态防护要求先绑定 uid 再拉详情/清单（loadCheckDetail/loadCandidates 内部按 model.checkUid 比对）
    model.checkUid = precheckUid;
    await loadCheckDetail(precheckUid);
    await loadCandidates(precheckUid);
  }

  let build: ReturnType<typeof buildImportPayload>;

  if (isRequirePassed.value || isDirect.value) {
    if (!model.checkUid) {
      ElMessage.warning(pt('请选择一条「接受」结论的检查记录（只列出已通过检查的单据）'));
      return undefined;
    }
    /**
     * 提交时补拉检查详情：candidates 不返回 sourceStorageUid，而部署后端实测
     * registered_share 必须任务级 source{storageUid,rootPath} 才放行（缺则 400）。
     * 切换检查单仍只发 candidates 一个请求，这里只在真正保存时补这一趟。
     */
    if (!checkDetail.value) await loadCheckDetail(model.checkUid);
    // 详情已明确判定不可入库时不再提交：省掉一次必然 400 的往返
    if (checkDetail.value && !isMetadataCheckAccepted(checkDetail.value)) {
      ElMessage.warning(pt('该检查记录的最终结论不是「接受」，不能用于入库'));
      return undefined;
    }
    // 第二道判据：缺逐文件指纹快照的记录，服务端一定 409 CHECK_BINDING_MISMATCH，提前拦下
    if (checkDetail.value && !checkFingerprinted.value) {
      ElMessage.warning(pt('该检查记录没有逐文件 sizeBytes/sha256 快照，入库时服务端无法复核：请回「数据检查」重新检查后再入库'));
      return undefined;
    }
    /**
     * from-check 提交（新契约 2026-11-18）：
     *   metadataFiles = 检查单锁定的元数据行（必填非空，不带 source，来源由检查单决定）；
     *   dataFiles = 用户按来源添加的数据行（每条带 source）。
     * 旧 files 清单已停用，混传 400；界面清单与提交载荷严格一致，targetPath 可改。
     * CONSTRAINT metadata 行必须逐字保留 sourcePath 且**不得带 source**，
     * 替换或加来源即 409「检查清单与元数据文件不一致」/ 400「元数据文件来源由检查单决定」。
     */
    build = buildImportPayload({
      importName: model.batchName,
      checkPolicy: 'require_passed',
      checkUid: model.checkUid,
      metadataFiles: metadataSelections.value,
      dataFiles: dataSelections.value.length ? dataSelections.value : undefined,
      /** 任务级来源：实测注册共享位置必须带 source{storageUid,rootPath}，逐条空 source 回落到这里 */
      source: deriveCheckTaskSource(checkDetail.value, candidatesData.value),
      priorityLevel: model.priorityLevel,
      securityLevel: model.securityLevel,
      autoStart: model.autoStart,
      requestId: genRequestId()
    });
  } else {
    // 兜底：run_if_needed 已在入口拦下，此处仅防御未知策略值
    ElMessage.warning(pt('未知的入库策略，请刷新页面后重试'));
    return undefined;
  }

  if (!build.ok || !build.payload) {
    ElMessage.warning(build.message || '请完整填写');
    return undefined;
  }
  // 直接返回接口调用；createDialog 依响应 code 决定关闭/保留表单。
  //
  // CONSTRAINT 失败时返回 undefined 而不是 { code: 1 }：
  //   - `request.ts` 的响应拦截器已对 4xx 弹过后端原文；
  //   - handleSubmitError 再补一条「下一步该做什么」的动作提示（性质不同，不算重复）；
  //   - 若返回 { code: 1 }，createDialog 会 `ElMessage.error(res.message)` 把同一段后端原文
  //     **再弹一次**，用户看到两条一模一样的红字；返回 undefined 则命中它的
  //     `if (isUndefined(res)) return` —— 不关弹窗（保留已填内容）、不重复提示。
  try {
    // "新建入库"页走「创建入库任务」端点（POST /platform/imports），
    // checkUid 已在 build.payload 请求体内；from-check 专用端点仅供检查详情页一键入库使用。
    return await createImportBatch(build.payload);
  } catch (error) {
    handleSubmitError(error);
    return undefined;
  }
}

onMounted(loadTypes);
onMounted(loadModels);

onMounted(loadChecks);

/**
 * 从「元数据检查」页带过来的选择结果预填表单。
 *
 * WHY：文档 §1 硬约束「检查页与入库页必须共用同一份文件选择结果，禁止在入库页重拼清单」。
 * 因此有 accepted 检查单时直接进 require_passed 模式并锁定 checkUid，用户不需要（也不应该）
 * 在这里重新选文件；要改文件必须回检查页重检 —— 否则入库会以 409 CHECK_BINDING_MISMATCH 拒绝。
 *
 * CONSTRAINT 只在**有 accepted 检查单**时预填：仅带 files/dataRootPath（无检查单）的场景
 * 属于半成品上下文，强行预填会诱导用户提交一个必然失败的批次，故忽略并让用户自己选。
 */
function applySharedSelection() {
  if (!hasAcceptedCheck.value) return;
  model.checkPolicy = 'require_passed';
  model.checkUid = selection.checkUid;
  loadCheckDetail(selection.checkUid);
  /**
   * 与 onCheckChange 保持一致：绑定检查单后必须把「检查单锁定的 metadata 行」也拉进清单。
   * WHY：预填路径只调了 loadCheckDetail，漏了 loadCandidates，导致从「数据检查」页点「去入库」
   * 跳过来时入库清单一直显示「元数据 0 数据 0」，提交会因缺少 metadata 行被后端拒绝。
   */
  loadCandidates(selection.checkUid);
}

onMounted(applySharedSelection);

/**
 * 清空入库清单：只撤掉用户可增删的来源批次、本地待传文件与清单行，让清单回到空白。
 *
 * CONSTRAINT 绝不动表单字段——检查单绑定（checkUid/checkDetail/candidatesData）、
 * 检查策略、任务名称、优先级等都属于表单，由顶部「重置」按钮（resetForm）负责。
 * 早先本函数连 checkUid 一起清，导致「清空清单」连锁把检查单与自动生成名一起抹掉，
 * 用户误以为整个表单被重置：清空 checkUid 后 selectedTypeName 取不到产品名，
 * autoBatchName 变空又经 watch 把 batchName 一并清空。
 * 清空后清单为空，C-10 与 buildImportPayload 会拦住空提交，不会拿空清单 + 旧 checkUid 撞 409。
 */
function clearList() {
  sourceEntries.value = [];
  uploadFileList.value = [];
  candidateRows.value = [];
  targetOverrides.value = {};
  uploadProgress.value = '';
}

/**
 * 重置整个新建入库表单：在清空清单基础上，再清检查单绑定并把基本信息恢复默认值。
 *
 * checkPolicy 回到默认 require_passed、categoryUid 留空（该策略下类别由检查单带出；
 * 用户再切 direct 时 watch(checkPolicy) 会按 r350 联动回左侧树选中项）。
 * 名称解锁并清空，等待选策略/来源后由 autoBatchName 重新生成。
 */
function resetForm() {
  clearList();
  // 检查单绑定与共享选择属于表单，仅「重置」清理；「清空清单」不得触碰
  checkDetail.value = null;
  candidatesData.value = null;
  detailError.value = '';
  candidatesError.value = '';
  model.checkUid = '';
  clearSelection();
  model.checkPolicy = 'require_passed';
  model.modelUid = '';
  model.categoryUid = '';
  model.batchName = '';
  model.priorityLevel = 'medium';
  model.autoStart = false;
  model.securityLevel = 'public';
  batchNameEdited.value = false;
  candidateView.value = 'metadata';
  form.value?.clearValidate?.();
}

defineExpose({ save, form, resetForm, clearList });
</script>

<template>
  <!--
  新建入库表单：基本信息（上）/ 入库清单（下）两张卡片。
  用原生 el-form 而非通用 <Form>：Form 只解析直接子节点，无法把字段包进卡片容器；
  原生 el-form 允许任意嵌套，form.validate() 契约对调用方（index.vue submitCreate）保持兼容。
  label-width 固定 120px：最长「入库任务名称」加冒号需要，避免折行导致 label 锯齿。
-->
  <el-form ref="form" :model="model" label-width="120px" class="import-edit-form">
    <!-- 卡片 1：基本信息（高度由内容决定，不参与剩余空间分配） -->
    <section class="edit-card edit-card--basic">
      <h3 class="edit-card__title">{{ pt('基本信息') }}</h3>
      <div class="edit-card__body">
        <el-form-item :label="pt('入库策略')">
          <el-radio-group v-model="model.checkPolicy">
            <el-radio v-for="option in checkPolicyOptions" :key="option.value" :value="option.value">{{ option.label }}</el-radio>
          </el-radio-group>
        </el-form-item>

        <el-form-item v-if="isRequirePassed" :label="pt('检查单')" prop="checkUid" :rules="checkRules">
          <el-select
            v-model="model.checkUid"
            filterable
            :loading="checkLoading"
            :placeholder="checkPlaceholder"
            class="edit-field-full"
            @change="onCheckChange"
          >
            <el-option v-for="item in checkOptions" :key="item.value" :label="item.label" :value="item.value" />
            <template #empty>
              <div class="check-empty">{{ pt('暂无「接受」结论的检查记录：请先在「数据检查」完成一次检查并等待结论为接受') }}</div>
            </template>
          </el-select>
        </el-form-item>

        <el-form-item v-if="isDirect" label="元数据模型" prop="modelUid" :rules="modelRules">
          <el-select v-model="model.modelUid" filterable :loading="modelLoading" placeholder="请选择元数据模型" class="edit-field-full">
            <el-option v-for="item in modelOptions" :key="item.value" :label="item.label" :value="item.value" />
            <template #empty><div class="check-empty">暂无可用元数据模型：请先在「元数据模型」中创建一个模型</div></template>
          </el-select>
        </el-form-item>

        <el-form-item label="入库任务名称" prop="batchName" :rules="batchNameRules">
          <el-input v-model="model.batchName" placeholder="选择入库策略与来源后自动生成，可直接修改" :maxlength="160" @input="handleBatchNameInput" />
        </el-form-item>

        <el-form-item label="初始优先级">
          <el-radio-group v-model="model.priorityLevel">
            <el-radio v-for="option in priorityOptions" :key="option.value" :value="option.value">{{ option.label }}</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="数据级别">
          <el-radio-group v-model="model.securityLevel">
            <el-radio v-for="option in securityLevelOptions" :key="option.value" :value="option.value">{{ option.label }}</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="创建后动作">
          <el-radio-group v-model="model.autoStart">
            <el-radio :value="true">立即开始执行</el-radio>
            <el-radio :value="false">稍后在列表手动开始</el-radio>
          </el-radio-group>
        </el-form-item>
      </div>
    </section>

    <!-- 卡片 2：入库清单（flex 占满剩余高度，树在卡片内滚动，页面不出滚动条） -->
    <section class="edit-card edit-card--list">
      <div class="edit-card__header">
        <h3 class="edit-card__title">入库清单</h3>
        <div class="edit-card__header-actions">
          <el-radio-group v-model="candidateView" size="small" class="cand__view-switch">
            <el-radio-button value="metadata">元数据 {{ metadataRows.length }}</el-radio-button>
            <el-radio-button value="data">数据 {{ dataCheckedCount }}/{{ dataRows.length }}</el-radio-button>
          </el-radio-group>
          <SourceToolbarActions
            show-clear
            :clear-disabled="!candidateRows.length"
            @share-dir="openShareDirDialog"
            @share-path="addUncSource"
            @upload="triggerUploadPicker"
            @clear="clearList"
          />
        </div>
      </div>
      <div class="edit-card__body">
        <div v-loading="candidatesLoading" class="cand">
          <el-alert v-if="detailError" :title="detailError" type="warning" show-icon :closable="false" class="cand__alert" />

          <div v-if="uploadProgress" class="cand__progress">{{ uploadProgress }}</div>

          <el-alert v-if="candidatesError" :title="candidatesError" type="warning" show-icon :closable="false" />
          <div v-else-if="!candidateRows.length" class="cand__empty">
            {{
              isRequirePassed
                ? '选择检查单，或点工具栏「选择共享目录」勾选文件、添加共享路径 / 本地上传，这里会列出本次入库的完整清单。'
                : '点工具栏「选择共享目录」勾选文件，或添加共享路径 / 本地上传，这里会列出本次入库的完整清单。'
            }}
          </div>

          <template v-else>
            <div v-if="candidateView === 'metadata'" class="cand__section">
              <!-- 高度由 .cand__section 的 flex 约束给出，树在卡片内滚动，不写死像素上限 -->
              <SelectedFileTree
                :rows="metadataRows"
                empty-text="本次检查没有元数据文件"
                :tip="''"
                :max-height="0"
                :show-path="true"
                flat
                @move="onTreeMove"
                @remove="onTreeRemove"
                @move-into="onTreeMoveInto"
              />
            </div>
            <div v-else class="cand__section">
              <SelectedFileTree
                :rows="dataRows"
                :show-path="false"
                checkable
                :removable="false"
                empty-text="点右上方工具栏添加数据文件（共享目录 / UNC / 本地上传）"
                tip="勾选决定入库范围，取消勾选的文件不会入库"
                :max-height="0"
                @move="onTreeMove"
                @remove="onTreeRemove"
                @move-into="onTreeMoveInto"
                @check="onTreeCheck"
              />
            </div>
          </template>
        </div>
      </div>
    </section>

    <input ref="uploadPickerRef" type="file" multiple class="hidden-picker" @change="onUploadPicked" />
  </el-form>
</template>

<style lang="scss" scoped>
/* 检查单字段：下拉行 + 说明行必须竖向排列。
   el-form-item__content 默认 flex-wrap 行布局，两段并列时说明文字会掉到下拉框下面与下一字段重叠 */
/* 选择行：下拉占满，右侧跟一个刷新按钮（检查记录随检查页实时变化，必须能就地重拉） */
.pick-row {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;

  .pick-row__grow {
    flex: 1;
    min-width: 0;
  }
}

/* 检查单被左侧类型收窄时，收窄信息已并入下拉 placeholder，无需额外说明行 */

/* 入库清单：占满卡片剩余高度，树在内部滚动（不设固定 min-height，避免撑破页面） */
.cand {
  display: flex;
  flex: 1 1 auto;
  flex-direction: column;
  width: 100%;
  min-height: 0;
  padding: 8px 0;
  background: var(--el-fill-color-blank);

  /* 目录行的子项数量角标对入库无意义，隐藏（避免改动共享树组件） */
  :deep(.trow__cnt) {
    display: none;
  }
}

/* 元数据 / 数据切换区：同样弹性占满，让内部树拿到可滚动高度 */
.cand__section {
  display: flex;
  flex: 1 1 auto;
  flex-direction: column;
  min-height: 0;
}

/* 树组件根与树体：弹性撑满 .cand__section，靠 .sft__tree 自带的 overflow:auto 在内部滚动 */
:deep(.sft) {
  display: flex;
  flex: 1 1 auto;
  flex-direction: column;
  min-height: 0;
}
:deep(.sft__tree) {
  flex: 1 1 auto;
  min-height: 0;
}

.cand__alert {
  margin: 0 0 8px;
}

/* 类型切换按钮：元数据 / 数据一次只显示一种，选中态由 el-radio-button 自带高亮 */
.cand__view-switch {
  flex: none;

  /* 与右侧图标按钮（size=small，高 32px）统一高度，消除大小不一 */
  :deep(.el-radio-button__inner) {
    height: 32px;
    padding: 0 12px;
    font-size: 12px;
    line-height: 30px;
  }
}

.cand__empty {
  padding: 10px 2px;
  font-size: 12px;
  color: var(--el-text-color-placeholder);
}

/* 提交前的上传进度：只在 save() 真正传输时短暂出现 */
.cand__progress {
  margin: 0 0 6px;
  font-size: 12px;
  color: var(--el-text-color-secondary);
}

/* 本地上传由工具栏按钮触发，文件选择框本体不占布局 */
.hidden-picker {
  display: none;
}

.mono {
  font-family: var(--el-font-family-mono, ui-monospace, SFMono-Regular, Menlo, Consolas, monospace);
}

.check-empty {
  padding: 12px;
  font-size: 13px;
  line-height: 1.6;
  color: var(--el-text-color-secondary);
}

/* ===== 新建入库：基本信息 / 入库清单 两卡片（去蓝底、清单置底） ===== */
.import-edit-form {
  display: flex;
  flex-direction: column;
  gap: 16px;
  width: 100%;
  /* 撑满外层 .import-create__body 的可用高度；box-sizing 让 padding 计入高度，避免溢出产生页面滚动条 */
  height: 100%;
  min-height: 0;
  box-sizing: border-box;
  padding: 4px 2px;
  background: transparent;
}

/* 卡片本体显式白底：覆盖外层容器可能透出的淡蓝斜纹背景；
   用 --el-fill-color-blank 跟随主题，浅/深色模式都得到干净平面 */
.edit-card {
  display: flex;
  flex-direction: column;
  min-height: 0;
  background: var(--el-fill-color-blank);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 6px;
  overflow: hidden;

  /* 基本信息：高度由内容决定，剩余空间全让给入库清单 */
  &--basic {
    flex: none;
  }

  /* 入库清单：占满剩余高度，内部再分 header（固定）+ body（弹性滚动） */
  &--list {
    flex: 1 1 auto;
  }
}

.edit-card__header {
  display: flex;
  flex: none;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 0 16px;
  background: var(--el-fill-color-blank);
  border-bottom: 1px solid var(--el-border-color-lighter);
}

.edit-card__header-actions {
  display: flex;
  align-items: center;
  gap: 12px;
}

.edit-card__title {
  margin: 0;
  padding: 12px 16px;
  font-size: 14px;
  font-weight: 600;
  color: var(--el-text-color-primary);
  background: var(--el-fill-color-blank);
  border-bottom: 1px solid var(--el-border-color-lighter);
}

/* 入库清单标题在 header 内：左右 padding 与底边框由 header 承担，避免双线 */
.edit-card__header .edit-card__title {
  padding: 12px 0;
  border-bottom: 0;
}

.edit-card__body {
  min-height: 0;
  padding: 16px 16px 8px;

  /* 卡片内表单项紧凑：每一项之间只留 8px，去掉通用 Form 的默认大间距 */
  .el-form-item {
    margin-bottom: 12px;
  }
}

/* 入库清单卡片体：弹性列撑满卡片剩余高度，让内部 .cand 拿到可滚动高度 */
.edit-card--list .edit-card__body {
  display: flex;
  flex: 1 1 auto;
  flex-direction: column;
}

/* 选择类控件铺满表单项宽度（原生 el-select 默认只占内容宽） */
.edit-field-full {
  width: 100%;
}
</style>
