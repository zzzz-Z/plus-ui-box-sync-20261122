<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
import { CircleClose, FolderOpened, Search, Setting } from '@element-plus/icons-vue';

/**
 * 数据入库 · 左侧产品类型树
 *
 * 数据源由调用方（index.vue）传入：入库页的类别范围必须与「新建入库」弹窗同源，
 * 取数收口在 category-scope.ts 的 fetchScopedTypeRoots（语义根命中取子树，未命中回落顶层根）。
 * 若本组件自己拉一遍，就会出现「树里点的类别，弹窗帘里选不到」这种无法自解释的错位。
 *
 * 视觉口径对齐「数据浏览」左树（data-browse/index.vue）：卡片外观、head 只放搜索框、
 * 节点 30px 行高 + 类别图标 + 计数徽标、current 高亮。这样同一套布局里两棵树的观感一致。
 *
 * 交互口径：
 *  - 初始不选中任何节点（v-model 为空串 = 全部类型），只有用户主动点击才产生类别筛选；
 *  - 单选；**再次点击已选中节点 = 取消选中**（回到「全部类型」），
 *    避免用户被迫停留在某个类别上无法看全量；
 *  - 对外只暴露 v-model（categoryUid，空串=全部）：父页面需要节点时按 uid 从同一棵树里派生，
 *    本组件不再额外发一份节点事件 —— 两份数据源必然不同步；
 *  - 「管理产品类型」入口外移到本树 head（用户口径）：本组件只发 manage 信号，
 *    弹窗调度与类别刷新由 index.vue 负责 —— 树被 Teleport 到布局左列，不该持有弹窗与刷新职责。
 */
interface TypeNodeVM {
  key: string;
  label: string;
  count?: number;
  children?: TypeNodeVM[];
}

const props = withDefaults(defineProps<{ roots: any[]; loading?: boolean }>(), { loading: false });

/**
 * 选中类别的 uid；空串 = 未选（全部类型）。
 * 初始值保持空串：本树不做「数据到位兜底选中第一项」，初始与清空后都是「全部类型」。
 */
const selected = defineModel<string>({ default: '' });

const emit = defineEmits<{ manage: [] }>();

const keyword = ref('');
const treeRef = ref();

function toVM(node: any): TypeNodeVM {
  const children = (node.children ?? []).map(toVM);
  return {
    key: node.categoryUid || node.categoryKey || node.categoryName,
    label: node.categoryName || node.categoryKey || '(未命名类别)',
    count: typeof node.modelCount === 'number' ? node.modelCount : undefined,
    ...(children.length ? { children } : {})
  };
}

const nodes = computed<TypeNodeVM[]>(() => (props.roots ?? []).map(toVM));

/**
 * el-tree 内置过滤（与 data-browse 同口径）：按名称包含匹配，命中节点的祖先链由 el-tree 自动保留。
 * 不再用 computed 前端裁剪整棵树 —— 那样会丢掉 el-tree 自己的展开/高亮状态。
 */
function filterNode(value: string, data: TypeNodeVM) {
  if (!value) return true;
  return data.label.toLowerCase().includes(value.toLowerCase());
}

watch(keyword, (val) => treeRef.value?.filter(val));

/** 按 uid 在原始树中找节点（展开状态与过滤无关，故用 raw 树） */
function findRaw(list: any[], uid: string): any | null {
  for (const node of list ?? []) {
    if (node.categoryUid === uid) return node;
    const hit = node.children?.length ? findRaw(node.children, uid) : null;
    if (hit) return hit;
  }
  return null;
}

function commit(uid: string) {
  selected.value = uid;
}

function onNodeClick(data: TypeNodeVM) {
  if (data.key === selected.value) {
    commit('');
    return;
  }
  commit(data.key);
}

/** 清空按钮：显式回到「全部类型」 */
function clearSelection() {
  commit('');
}

/** 选中项已不在当前树内（类别被删 / 树范围变了）：退回「全部」，避免悬空 uid 传出无效筛选 */
watch(
  () => props.roots,
  (list) => {
    if (!selected.value) return;
    if (!findRaw(list, selected.value)) selected.value = '';
  }
);

watch(selected, (uid) => {
  treeRef.value?.setCurrentKey(uid || null);
});
</script>

<template>
  <aside v-loading="loading" class="pt-tree">
    <div class="pt-tree__head">
      <el-input v-model="keyword" :placeholder="pt('搜索产品类型')" clearable :prefix-icon="Search" />
      <!-- 「显示全部」只在有筛选时出现；二次点击已选节点也能取消，但图标按钮更直观 -->
      <el-button v-if="selected" :icon="CircleClose" link :title="pt('显示全部类型')" @click="clearSelection" />
      <!-- 管理入口外移到树上：点击后由 index.vue 打开管理弹窗并在改动后刷新整页类型树 -->
      <el-button :icon="Setting" type="primary" :title="pt('管理产品类型')" @click="emit('manage')" />
    </div>
    <div class="pt-tree__body">
      <el-tree
        ref="treeRef"
        :data="nodes"
        :props="{ label: 'label', children: 'children' }"
        node-key="key"
        :indent="14"
        :default-expand-all="true"
        :expand-on-click-node="false"
        :current-node-key="selected"
        :filter-node-method="filterNode"
        highlight-current
        @node-click="onNodeClick"
      >
        <template #default="{ data }">
          <span class="pt-node">
            <el-icon class="pt-node__ic"><FolderOpened /></el-icon>
            <span class="pt-node__label" :title="data.label">{{ data.label }}</span>
            <span v-if="data.count" class="pt-node__count">{{ data.count }}</span>
          </span>
        </template>
      </el-tree>
      <el-empty v-if="!loading && !nodes.length" description="暂无产品类型" :image-size="50" />
    </div>
  </aside>
</template>

<style scoped lang="scss">
/* 卡片化外观与 data-browse 的 .db-tree(.is-hosted) 一致：布局左列只给位置和宽度，外观由树自己给 */
.pt-tree {
  display: flex;
  flex: 1 1 auto;
  flex-direction: column;
  width: 100%;
  height: 100%;
  min-height: 0;
  padding: 0;
  overflow: hidden;
  background: var(--el-bg-color);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 6px;
}

/* head 与 data-browse 同 padding / 下边框；flex 让搜索框撑满、右侧图标按钮收在末尾 */
.pt-tree__head {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 10px 10px 8px;
  border-bottom: 1px solid var(--el-border-color-lighter);

  :deep(.el-input) {
    flex: 1;
    min-width: 0;
  }
}

.pt-tree__body {
  flex: 1;
  min-height: 0;
  padding: 6px 6px 10px;
  overflow: auto;
}

/* 节点：对齐 data-browse 的 .db-node —— 13px、15px 图标、计数徽标、primary 类别色 */
.pt-node {
  display: flex;
  align-items: center;
  gap: 6px;
  width: 100%;
  padding-right: 4px;
  font-size: 13px;
}

.pt-node__ic {
  display: inline-flex;
  flex: none;
  align-items: center;
  width: 15px;
  font-size: 13px;
  color: var(--el-color-primary);
}

.pt-node__label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.pt-node__count {
  flex: none;
  min-width: 20px;
  padding: 0 5px;
  color: var(--el-text-color-secondary);
  font-size: 11px;
  line-height: 16px;
  text-align: center;
  background: var(--el-fill-color-light);
  border-radius: 8px;
}

:deep(.el-tree-node__content) {
  height: 30px;
  border-radius: 4px;
}

:deep(.el-tree-node.is-current > .el-tree-node__content) {
  background: var(--el-color-primary-light-9);

  .pt-node__count {
    color: var(--el-color-primary);
    background: var(--el-color-primary-light-8);
  }
}
</style>
