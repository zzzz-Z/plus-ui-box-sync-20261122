<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
import { Delete, Document, Location, Refresh, VideoPause, VideoPlay } from '@element-plus/icons-vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import Edit from './edit.vue';
import Detail from './detail.vue';
import { IMPORT_ACTIVE_STATES, IMPORT_STATE_MAP, IMPORT_STATE_QUERY, importStateOf, normImportState } from './state';
import { deleteImportBatch, listImportBatches, pauseImportBatch, resumeImportBatch, startImportBatch } from '@/api/product-manage/platform/ingestion';
import type { ImportBatch, ImportBatchDetail, ImportState } from '@/api/product-manage/types/platform';
import { getImportMetadata } from '@/api/product-manage/platform/ingestion';
import { describeMetacheckError, resolveMetacheckErrorAction } from '@/api/product-manage/platform/metacheck-errors';
import { subscribeTaskEvents } from '@/api/product-manage/platform/tasks';
import { subscribeImportMetadataEvents } from '@/api/product-manage/platform/ingestion';
import { useMap } from '@/views/product-manage/shared/map/use-map';
import { useProductPalette } from '@/views/product-manage/shared/store.js';
import { useTreeHost } from '@/views/product-manage/shared/tree-host';
import { useMapVisibility } from '@/views/product-manage/shared/map-visibility';
import ProductTypeTree from './product-type-tree.vue';
import ProductTypeManageDialog from './product-type-manage-dialog.vue';
import { collectCategoryNames, fetchScopedTypeRoots } from './category-scope';
import { clearSelection } from '../metacheck-selection';

const queryParams = reactive({ keyword: '', state: '' });

/**
 * 状态筛选的 UI 值（中文规范键）。
 *
 * CONSTRAINT 与 queryParams.state 分离：UI 内部键是中文（下拉 options value 中文），
 * 而提交给后端的 ?state= 只认英文枚举。用独立 ref 承载 UI 值，onStateChange 里翻译后写回 queryParams。
 */
const stateFilter = ref('');

/** 上层 provide 的产品类别根编码；透传给弹窗（createDialog 挂到 body，inject 无法穿透） */
const categoryRoot = inject<string>('product-category-root', '');

/* ------------------------- 左侧产品类型树 ------------------------- */

/**
 * 树的挂载位（布局注入；独立挂载时为 null，回落为内联渲染）。
 *
 * WHY 提到 setup 前段：下面「树 / 详情区」相关 watch 带 immediate，会在 setup 阶段立即读它，
 * 声明排在文件后半段会命中 TDZ 直接运行时报错（data-browse 踩过同一个坑）。
 */
const treeHost = useTreeHost();

/** 地图显隐控制器（布局注入；独立挂载时为 null，此时只拉图层不强开地图） */
const mapVisibility = useMapVisibility();

/** 表格实例；声明在第一段，因为下面多处 watch / 事件回调都要用它 */
const tableRef = ref();

/** 页面 tab：默认展示「新建入库」，入库列表通过 tab 切换过去 */
const activeTab = ref<'create' | 'list'>('create');
/** 页面内「新建入库」表单实例（替代原弹窗的 contentRef） */
const editRef = ref();
/** 提交中（复用原弹窗 submit 的 loading 口径） */
const creating = ref(false);

/** 本页可见的产品类型树根（语义根命中取子树，未命中回落顶层根） */
const typeRoots = ref<any[]>([]);
const typeLoading = ref(false);
/** 当前选中的产品类型 uid；空串 = 全部类型。**这是唯一真源**，节点与名集合都从它派生 */
const selectedTypeUid = ref('');
/** 语义根是否命中；未命中说明「按根收窄」退化成全量顶层，页面上要能看出这个事实 */
const typeScoped = ref(false);
/** 取数失败原因；仅用于树上的空态文案，不阻断列表 */
const typeError = ref('');

/**
 * 选中类别的原始节点：由 uid 从 typeRoots 派生，**不单独存一份**。
 *
 * WHY 不存两份状态：tree 组件（v-model uid）与父页面（需要节点展开子树）若各持一份，
 * 迟早出现「uid 是 A、节点还是上一轮的 B」——列表按 B 的子树过滤，标签却显示 A，
 * 用户完全无法从这个现象推出原因。派生出来就不存在不同步的可能。
 */
const selectedTypeNode = computed<any | null>(() => {
  const uid = selectedTypeUid.value;
  if (!uid) return null;
  const walk = (list: any[]): any | null => {
    for (const node of list ?? []) {
      if (node.categoryUid === uid) return node;
      const hit = node.children?.length ? walk(node.children) : null;
      if (hit) return hit;
    }
    return null;
  };
  return walk(typeRoots.value);
});

/**
 * 选中类别子树内的全部类别名。
 *
 * WHY 用「名」而不是「uid」做前端兜底过滤：列表行（ImportBatch）只有 categoryName，
 * 没有 categoryUid，按 uid 匹配一条也命中不了。
 *
 * 为什么还要「双保险」：列表接口声明支持 ?categoryUid=（ingestion.ts 的 ImportListParams），
 * 但**后端实测未验证**该参数是否生效（本机无法连通产品网关），且契约文档的参数表里只有
 * keyword/state/page/pageSize。因此能传就传 categoryUid（服务端生效时已收窄），
 * 返回后再按子树名集合前端过滤（服务端忽略参数时也不会把别的类型混进来）。
 */
const scopedNames = computed<Set<string>>(() => (selectedTypeNode.value ? collectCategoryNames(selectedTypeNode.value) : new Set()));

/** 加载左侧产品类型树；与新建弹窗共用 fetchScopedTypeRoots，保证两处范围一致 */
async function loadTypes() {
  typeLoading.value = true;
  typeError.value = '';
  try {
    const { roots, scoped } = await fetchScopedTypeRoots(categoryRoot);
    typeRoots.value = roots;
    typeScoped.value = scoped;
  } catch {
    // 失败原因由响应拦截器统一弹出；这里只让树显示「加载失败」而不是「暂无产品类型」
    typeError.value = '产品类型加载失败';
    typeRoots.value = [];
  } finally {
    typeLoading.value = false;
  }
}

/**
 * 树上选中变化：刷新列表。
 *
 * WHY 走 tableRef.query() 而不是 getData()：换的是筛选维度，页码必须回到第 1 页，
 * 否则在第 3 页点到只有 1 页数据的类别会看到空表（getData 会保留当前页码）。
 *
 * CONSTRAINT 不在此写 selectedTypeUid：它由树组件通过 v-model 双向更新，
 * 这里只响应「已经变了」这个事实，避免一次点击写两遍导致重复请求。
 *
 * WHY 监听 uid 而不是接收节点：uid 是唯一真源，节点已由它派生；
 * 树里「清空全部」的情形也归一到 uid='' 一条路径。
 */
watch(selectedTypeUid, () => {
  tableRef.value?.query?.();
});

/**
 * 清除类型筛选（标签上的 ×）：置空 uid 即可。
 *
 * WHY 不能只清 selectedTypeNode（现在是派生的，改它没有意义）：树上还高亮着某个类别、
 * 列表却显示全部，两个地方对「当前筛了什么」给出相反的答案。uid 是 v-model 的绑定目标，
 * 置空后树的高亮（内部 watch selected → setCurrentKey）与列表筛选会一起复位。
 */
function clearTypeFilter() {
  selectedTypeUid.value = '';
}

/**
 * 列表行类型：按 GET /platform/imports 的 items[] 真实契约投影。
 *
 * WHY 不直接用 ImportBatch：接口层类型残留两处与契约不符的漂移字段——
 * batchName（契约已更名为 importName）、errorCount（列表摘要不返回），
 * 直接拿它渲染会在列表里读到 undefined 或凭空造出一列「错误数」。
 * 这里用 Omit 剔除漂移字段、补回契约真实字段，让渲染层只能读到接口确有之物。
 */
interface ImportBatchRow extends Omit<ImportBatch, 'batchName' | 'errorCount'> {
  /** 入库任务名称（契约字段 importName，必返） */
  importName: string;
}

const batches = ref<ImportBatchRow[]>([]);

/**
 * 当前正在地图上查看的批次。
 *
 * WHY 换成「点一行看一行」：与数据浏览 / 元数据编辑保持一致的操作口径，
 * 且勾选框会让人误以为可以多选批量操作（本页并没有批量动作）。
 * 这里记住它有两个用处：① 重复点同一行时直接返回，不重拉几何（会闪烁且浪费请求）；
 * ② 列表刷新后判断该批次是否已不在结果里，在则顺手清掉图层，避免残留。
 */
const activeRow = ref<ImportBatchRow | null>(null);

/**
 * 状态口径统一走 state.ts（列表与详情同源）。
 *
 * WHY 在此只做别名而不复制实现：入库详情页必须显示与列表**完全一致**的状态文案/配色；
 * 两处各写一份映射，任何一侧补新写法都会让另一侧静默降级为灰色「未知」。
 */
const stateMap = IMPORT_STATE_MAP;
const normState = normImportState;
const stateOf = importStateOf;

/**
 * 地图单例由 layout 预初始化；本模块通过它把选中批次的元数据几何画到主地图上。
 * CONSTRAINT 几何一律来自 getImportMetadata 的 values.spatial_range（WKT），不再消费记录 mock。
 */
const map = useMap();

/**
 * 图层配色与图例同源：统一走 useProductPalette 的类别色，
 * 使图例色块与地图要素填充严格一致（此前按 state 着色，与图例两套色板）。
 */
const { palette: categoryPalette } = useProductPalette();

/**
 * 元数据图层（按批次查看）：独立图层组 id，与表格状态图层（__render__）互不干扰。
 * 展示的是 getImportMetadata 返回的 values.spatial_range（WKT），与批次状态矩形不重叠渲染。
 */
const META_GROUP_ID = 'data-into-store/meta';

/** 元数据图层要素（GeoJSON FeatureCollection.features）；空数组表示无图层 */
const metaFeatures = ref<any[]>([]);

/**
 * 把 values.spatial_range 归一为 GeoJSON Geometry。
 *
 * 支持三类输入：① GeoJSON Geometry / Feature 对象；② 上述对象的 JSON 序列化字符串
 *（契约里 spatial_range 声明为 string，序列化后仍常见）；③ WKT 字符串
 *（POLYGON / MULTIPOLYGON / POINT）。无法识别返回 null，不抛错、不阻断其他批次。
 *
 * WHY 手写解析而不引 wkt-parser：本页只需 POLYGON / MULTIPOLYGON / POINT 三种；
 * 引库会多一个依赖，且解析失败时的降级行为难控（解析抛错会打断整个加载流程）。
 */
function parseSpatialRange(input: unknown): any | null {
  if (input == null) return null;
  if (typeof input === 'object') {
    const obj = input as any;
    if (obj.type === 'Feature' && obj.geometry) return obj.geometry;
    if (typeof obj.type === 'string' && Array.isArray(obj.coordinates)) return obj;
    return null;
  }
  const raw = String(input).trim();
  if (!raw) return null;
  if (raw.startsWith('{') || raw.startsWith('[')) {
    try {
      return parseSpatialRange(JSON.parse(raw));
    } catch {
      return null;
    }
  }
  const m = raw.match(/^([A-Z]+)\s*\((.+)\)$/is);
  if (!m) return null;
  const type = m[1].toUpperCase();
  const body = m[2];
  const rings = (text: string): number[][][] =>
    text
      .split(/\),\s*\(/)
      .map((chunk) =>
        chunk
          .replace(/^\(|\)$/g, '')
          .split(',')
          .map((pair) => pair.trim().split(/\s+/).map(Number) as [number, number])
          .filter((p) => p.length === 2 && p.every((n) => Number.isFinite(n)))
      )
      .filter((ring) => ring.length >= 3);
  if (type === 'POLYGON') {
    const polygons = rings(body);
    return polygons.length ? { type: 'Polygon', coordinates: polygons } : null;
  }
  if (type === 'MULTIPOLYGON') {
    const parts = body.split(/\)\s*,\s*\(/);
    const coordinates = parts.map((part) => rings(part)).filter((p) => p.length);
    return coordinates.length ? { type: 'MultiPolygon', coordinates } : null;
  }
  if (type === 'POINT') {
    const pair = body.replace(/\(|\)/g, '').trim().split(/\s+/).map(Number);
    return pair.length === 2 && pair.every((n) => Number.isFinite(n)) ? { type: 'Point', coordinates: pair } : null;
  }
  return null;
}

/**
 * 拉取选中批次的来源元数据几何并渲染到地图。
 *
 * CONSTRAINT 契约返回的 values.spatial_range 声明为 string（WKT 或 GeoJSON 序列化后），
 * 也可能被后端直返为 GeoJSON 对象；parseSpatialRange 负责归一为 GeoJSON Geometry，
 * 无有效几何的批次静默跳过，不阻断其他批次。
 */
/**
 * importUid → 稳定数值 feature id。
 * MapLayerOptions.selectedIds 是 number[]，maplibre 的 ['in',['id'],literal] 也按数值比对，
 * 用递增序号比直接塞字符串 uid 更贴合类型契约；同一批次多次构造要素复用同一 id。
 */
const META_ID_BY_UID = new Map<string, number>();
let metaIdSeq = 0;
function getMetaFeatureId(importUid: string): number {
  let id = META_ID_BY_UID.get(importUid);
  if (id == null) {
    id = ++metaIdSeq;
    META_ID_BY_UID.set(importUid, id);
  }
  return id;
}

/**
 * 地图标签文案：把「冗长任务名 + 17 位精度百分比」压成两行紧凑展示。
 * WHY 用户 2026-11-21「优化文字UI显示 让内容更炫酷」：symbol 图层塞整条 importName + 高精度百分比，
 * 在地图上是一坨白底黑字，既遮图形又读不出重点；这里按「短标题 / 状态·进度徽标」拆字段，
 * 图层侧用 maplibre format 表达式渲染成两行，长名称用 … 截断，hover 卡片仍通过 label 看全文。
 * CONSTRAINT 只改本页 buildMetaFeature 产出的 properties，其他页面无这两个字段时图层侧自动回落原 label。
 */
const META_LABEL_TITLE_MAX = 12;
function shortMetaTitle(name: string): string {
  const text = String(name ?? '').trim();
  return text.length > META_LABEL_TITLE_MAX ? text.slice(0, META_LABEL_TITLE_MAX) + '…' : text || '未命名批次';
}
function metaLabelBadge(row: ImportBatchRow, extra: { labelSuffix?: string }, percent: number): string {
  const state = normImportState(row.state) || normState(row.state) || '';
  const suffix = String(extra.labelSuffix ?? '').trim();
  // 有外部 suffix（如 SSE 精度百分比）时优先展示它，状态作为前缀保留语义
  const detail = suffix || (row.progress?.percent != null ? `${Number(percent.toFixed(1))}%` : '');
  return [state, detail].filter(Boolean).join(' · ');
}

/** 元数据 Feature 构造：来源两条通道——① getImportMetadata 同步结果 ② SSE metadata 事件 */
function buildMetaFeature(row: ImportBatchRow, geometry: any, extra: { sourceFile?: string; modelName?: string; labelSuffix?: string } = {}): any {
  const percent = row.progress?.percent ?? 0;
  return {
    type: 'Feature',
    // 稳定唯一数值 id：selectedIds 高亮靠 ['in', ['id'], literal] 比对 feature.id，
    // 恒为 1 时多条要素会一起点亮（用户 2026-11-21「点击图层 图层要高亮」）。
    id: getMetaFeatureId(row.importUid),
    geometry,
    properties: {
      importUid: row.importUid,
      categoryName: row.categoryName,
      // 完整标题保留给 hover / 点击气泡；symbol 图层改用下面两段短字段渲染。
      label: row.importName + ' ' + (extra.labelSuffix ?? percent + '%'),
      labelTitle: shortMetaTitle(row.importName),
      labelBadge: metaLabelBadge(row, extra, percent),
      state: normState(row.state) || row.state,
      sourceFile: extra.sourceFile ?? '',
      modelName: extra.modelName ?? '',
      securityLevel: row.securityLevel ?? '',
      progress: row.progress?.percent != null ? row.progress.percent : undefined
    }
  };
}

/**
 * 加载批次的元数据图层。
 *
 * 双通道：① 同步 getImportMetadata 兜底（SSE 断线或旧数据）；
 *         ② 订阅该批次的来源元数据 SSE（/imports/{uid}/metadata/events），
 *            收到 metadata 事件直接取 geojson 覆盖该批次要素（比手写 WKT 解析更可靠）。
 * SSE 断线时不在本函数内重连，保留同步通道的兜底结果。
 *
 * CONSTRAINT 入参仍是数组：双击/连续点行时可能并发进来，按数组处理可自然支持最后一行为准的语义；
 * 当前交互「点一行看一行」只会传单元素。
 */
async function loadMetaLayers(rows: ImportBatchRow[]) {
  dropAllMetaStreams();
  const features: any[] = [];
  for (const row of rows) {
    try {
      const res: any = await getImportMetadata(row.importUid);
      const meta: any = res?.data ?? {};
      const geometry = parseSpatialRange(meta?.values?.spatial_range);
      if (geometry) {
        features.push(buildMetaFeature(row, geometry, { sourceFile: meta?.source?.file, modelName: meta?.model?.modelName }));
      }
    } catch {
      // 失败原因由响应拦截器统一弹出
    }
    subscribeMetaStream(row);
  }
  metaFeatures.value = features;
  if (!features.length) ElMessage.warning(pt('该批次暂无可用空间范围'));
}

/** 已建立的元数据 SSE 订阅（按 importUid 去重），与批次进度 SSE 分离 */
const metaStreams = new Map<string, AbortController>();

function subscribeMetaStream(row: ImportBatchRow) {
  const uid = row.importUid;
  if (!uid || metaStreams.has(uid)) return;
  const ctrl = new AbortController();
  metaStreams.set(uid, ctrl);
  subscribeImportMetadataEvents(
    uid,
    {
      onEvent: (payload) => {
        if (payload.event !== 'metadata') return;
        const data: any = payload.data;
        const geojson = data?.geojson;
        if (!geojson || !Array.isArray(geojson.features) || !geojson.features.length) return;
        // 用 geojson 覆盖该批次要素（重建所有选中要素，保持 id 稳定）
        const otherFeatures = metaFeatures.value.filter((ft) => ft.properties?.importUid !== uid);
        const rowHit = batches.value.find((b) => b.importUid === uid);
        if (!rowHit) return;
        const next = geojson.features.map((ft: any) =>
          buildMetaFeature(rowHit, ft.geometry, {
            sourceFile: data?.source?.file,
            modelName: data?.model?.modelName
          })
        );
        metaFeatures.value = [...otherFeatures, ...next];
      }
    },
    ctrl.signal
  );
}

function dropAllMetaStreams() {
  metaStreams.forEach((c) => c.abort());
  metaStreams.clear();
}

/**
 * 地图要素点击：点亮该要素图层 + 反选回表格行。
 * WHY 不再弹右侧详情：用户 2026-11-21 口径「入库页点图层只要高亮和列表联动，不需要右侧详情」。
 * 高亮走 metaSelectedIds（MapLayerOptions.selectedIds 的 watch → applyState 重算 fill-opacity / line-color / halo）；
 * 列表联动仍由 activeRow + element-plus current-row 承担，与「点行加载图层」闭环。
 * CONSTRAINT setupState 对 ref 自动解包，E2E 经组件实例读 metaSelectedIds 直接取数组，不要再 `.value`。
 */
async function onMapFeatureClick(feature: any) {
  const importUid = feature?.properties?.importUid;
  if (!importUid) return;
  // 点谁亮谁：feature.id 由 buildMetaFeature 分配且与 importUid 一一对应；
  // selectedIds 是 number[]，这里统一转 number；找不到映射时不改高亮，避免整图乱闪。
  const id = getMetaFeatureId(importUid);
  if (id != null) metaSelectedIds.value = [id];
  const batch = batches.value.find((b) => b.importUid === importUid);
  if (!batch) return;
  activeRow.value = batch;
  if (activeTab.value !== 'list') activeTab.value = 'list';
  await nextTick();
  const table = tableRef.value as any;
  if (!table) return;
  // 表格数据由 getBatches 异步填充：若尚未返回 batch，等待其 getData 完成后再定位。
  const source = table.dataSource as ImportBatchRow[] | undefined;
  if (Array.isArray(source) && source.length && !source.some((row) => row.importUid === importUid)) {
    try {
      await table.getData();
    } catch {
      // getData 内部已统一处理错误，这里不阻断高亮尝试
    }
  }
  table.setCurrentRow?.(batch);
  void nextTick(() => {
    const root = table.$el as HTMLElement | undefined;
    const tr = root?.querySelector?.('.current-row') as HTMLElement | null;
    tr?.scrollIntoView?.({ block: 'center', behavior: 'smooth' });
  });
}

/** 清除元数据图层（若当前无图层，静默返回） */
function clearMetaLayer() {
  metaFeatures.value = [];
  map.removeLayerGroup(META_GROUP_ID);
}

/**
 * 点击表格行：加载该批次的元数据几何并渲染到地图。
 *
 * WHY 从「勾选加载」换成「点行加载」：本页没有任何批量动作，勾选框只会让人误以为能多选；
 * 数据浏览 / 元数据编辑都是「点谁看谁」，这里对齐同一套口径，交互层级也更短。
 * 重复点同一行直接返回：几何已在图上，重拉会闪一下并多打一次接口。
 *
 * CONSTRAINT 操作列按钮也落在行内：点「暂停 / 删除」时 el-table 同样派发 row-click，
 * 若不拦掉会顺带把这一行的几何拉一遍（白打接口 + 图层闪一下）。按事件源判断，
 * 落在按钮 / 进度条上的点击不当作「选行」。
 */
async function onRowClick(row: ImportBatchRow, _column?: unknown, event?: MouseEvent) {
  const target = event?.target as HTMLElement | null | undefined;
  if (target?.closest?.('button, a, .el-button, .el-progress, .el-switch')) return;
  if (!row?.importUid) return;
  // 行点选即视为选中该批次：同步图层高亮 id。此前只设 activeRow，metaSelectedIds 恒为空，
  // 地图要素的 fill-opacity / line-color 表达式 literal 一直是 []，表现为「点行地图不高亮」。
  // 放在去重 return 之前，保证重复点同一行（或初次进入 activeRow 已有值）也能点亮。
  metaSelectedIds.value = [getMetaFeatureId(row.importUid)];
  // 行点选即视为要看空间分布：地图没开时先打开（放在去重 return 之前，保证地图没开时点同一行也能开图）
  mapVisibility?.ensureMapVisible();
  // 去重要连「已经有几何」一起判：上一行没拉到几何时，重点同一行应当允许重试，
  // 否则用户只能刷新页面；而几何已在图上时重拉只会闪一下并多打一次接口。
  if (activeRow.value?.importUid === row.importUid && metaFeatures.value.length) return;
  activeRow.value = row;
  await loadMetaLayers([row]);
}

/**
 * 定位到该任务节点：复用 onRowClick 的选中态逻辑，并让表格高亮、滚动到该行。
 *
 * WHY 用 setCurrentRow + 滚动 DOM 而非另造接口：本页地图点要素回表格（:414）已用同一套
 * forwardRef 转发的 el-table 方法；highlight-current-row + row-key 已在模板配置，
 * setCurrentRow 会落 .current-row 高亮，再 scrollIntoView 把行带进视口。
 * 操作列按钮点击会被 onRowClick 的「按钮点击不派发选行」拦掉，故这里显式同步选中态。
 */
function locateRow(row: ImportBatchRow, event?: MouseEvent) {
  event?.stopPropagation?.();
  if (!row?.importUid) return;
  // 定位按钮语义就是「在地图上找到它」：地图没开时先打开，再加载图层（图attach 时自动 fitBounds）
  mapVisibility?.ensureMapVisible();
  // 与 onRowClick 同一口径：定位也要点亮对应要素，否则图load出来仍是全灰。
  metaSelectedIds.value = [getMetaFeatureId(row.importUid)];
  activeRow.value = row;
  void loadMetaLayers([row]);
  const t = tableRef.value as any;
  t?.setCurrentRow?.(row);
  void nextTick(() => {
    const root = t?.$el as HTMLElement | undefined;
    const tr = root?.querySelector?.('.current-row') as HTMLElement | null;
    tr?.scrollIntoView?.({ block: 'center', behavior: 'smooth' });
  });
  ElMessage.success('已定位到「' + (row.importName || row.taskName || row.importUid) + '」');
}

/**
 * 中文规范键 → 后端英文枚举数组（口径收口在 state.ts）。
 *
 * 一个中文显示态可对应多个后端枚举（已创建=CREATED/QUEUED），所以值改为数组，
 * 选中后拼成 CSV 存入 queryParams.state，由 getBatches 拆分逐态查询合并。
 */
const STATE_QUERY_VALUE = IMPORT_STATE_QUERY;

function onStateChange(label: string) {
  const states = label ? STATE_QUERY_VALUE[label] || [label] : [];
  queryParams.state = states.join(',');
  tableRef.value?.getData();
}

const stateOptions = Object.keys(stateMap);

/**
 * 只给真正「入库中」的行加高亮类。
 * WHY 「已创建」（含未绑定、0% 的残留占位批次）并未真正在跑，套上蓝条 / 浅底色会和
 * 「正在入库」混淆；这类行应与已完成 / 失败行一样保持普通样式，视觉上与其他行一致。
 * CONSTRAINT 走 ITableProps 透传给 ElTable（Table 内部 `{...tableProps}` 展开），
 * 不是本页自己写 el-table；类只标视觉态，不改数据结构。
 */
function rowClassName({ row }: { row: unknown }): string {
  // 形参放宽为 unknown：Table 的 rowClassName 契约是 ColumnCls<any> & ColumnCls<DefaultRow>，
  // 收窄成 ImportBatchRow 会因函数参数逆变而与该交叉类型不兼容（DefaultRow 缺业务字段）。
  return normState((row as ImportBatchRow).state) === '入库中' ? 'import-row--active' : '';
}

/**
 * 数据级别中文映射：契约要求响应为中文（公开/内部/秘密/机密/绝密），
 * 但历史数据仍可能存英文机器码（public/internal/secret…），兜底转中文，杜绝英文出现在列表。
 */
const SECURITY_LEVEL_TEXT: Record<string, string> = {
  public: pt('公开'),
  internal: pt('内部'),
  secret: pt('机密'),
  confidential: pt('秘密'),
  top_secret: pt('绝密')
};

/** 数据级别展示：已是中文原样返回，英文机器码按映射转中文，未知值原样兜底便于排障 */
function securityLevelText(value?: string | null): string {
  const raw = String(value ?? '').trim();
  if (!raw) return '-';
  return SECURITY_LEVEL_TEXT[raw.toLowerCase()] ?? raw;
}

/**
 * 列表展示列：严格对齐 GET /platform/imports 的 items[] 契约字段。
 * 契约 required 字段：importUid / importName / taskName / categoryUid / categoryName /
 * securityLevel / state / hint / taskUid / createdAt / progress（另有 stateText）。
 * 已移除契约不返回的「检查单」（checkUid/checkPolicy）与「错误数」（errorCount）两列：
 * 前者恒显示「未绑定」且带英文 UID，后者恒为空，均属无关内容。
 * 「资源名称」（taskName）与「提示」（hint）也不展示：前者常与任务名称重复，
 * 后者含后端英文错误码，均会干扰阅读；需要时可在详情弹窗查看。
 */
const columns: TableColumn<ImportBatchRow>[] = [
  { label: pt('入库任务名称'), prop: 'importName', minWidth: 180, showOverflowTooltip: true },
  { label: pt('产品类型'), prop: 'categoryName', width: 130, showOverflowTooltip: true },
  {
    label: pt('数据级别'),
    width: 100,
    render: ({ row }) => securityLevelText(row.securityLevel)
  },
  {
    label: pt('入库进度'),
    minWidth: 190,
    render: ({ row }) => {
      const raw = row.progress?.percent;
      const pct = typeof raw === 'number' ? Math.round(raw) : 0;
      const st = normState(row.state) === '失败' ? 'exception' : normState(row.state) === '已完成' ? 'success' : undefined;
      return (
        <div class="progress-cell">
          <el-progress percentage={pct} status={st} />
        </div>
      );
    }
  },
  {
    label: pt('状态'),
    width: 110,
    render: ({ row }) => {
      const view = stateOf(row.state);
      return (
        <span class="result-cell">
          {normState(row.state) === '入库中' ? <span class="live-dot" title="正在入库" /> : null}
          <el-tag type={view.type as any}>{view.label}</el-tag>
        </span>
      );
    }
  },
  { label: pt('创建时间'), prop: 'createdAt', width: 170, showOverflowTooltip: true },
  {
    action: true,
    label: pt('操作'),
    fixed: 'right',
    showOverflowTooltip: false,
    render: ({ row }) => (
      <>
        <el-button v-tooltip={'详情'} link type="primary" icon={Document} onClick={() => openDetail(row)} />
        <el-button
          v-tooltip={'开始'}
          link
          type="primary"
          icon={VideoPlay}
          disabled={!['已创建', '已暂停'].includes(normState(row.state))}
          onClick={() => doAction(row, 'start')}
        />
        <el-button
          v-tooltip={normState(row.state) === '已暂停' ? pt('恢复') : pt('暂停')}
          link
          type={normState(row.state) === '已暂停' ? 'primary' : 'warning'}
          icon={normState(row.state) === '已暂停' ? Refresh : VideoPause}
          disabled={!['已创建', '已暂停'].includes(normState(row.state))}
          onClick={() => doAction(row, normState(row.state) === '已暂停' ? 'resume' : 'pause')}
        />
        <el-button v-tooltip={'定位'} link type="primary" icon={Location} onClick={(e: MouseEvent) => locateRow(row, e)} />
        <el-button
          v-tooltip={'删除'}
          link
          type="danger"
          icon={Delete}
          disabled={['已创建', '入库中'].includes(normState(row.state))}
          onClick={() => doDelete(row)}
        />
      </>
    )
  }
];

/** 已建立的 SSE 订阅，按 taskUid 去重；卸载时统一 abort */
const sseControllers = new Map<string, AbortController>();

/**
 * SSE 订阅并发上限。
 *
 * WHY dev 下必须限制：入库页每个活跃批次一条 `fetch(text/event-stream)` 长连接，
 * 而 Chrome 对同一 origin 的 HTTP/1.1 连接上限只有 6 条。活跃批次一多（或旧连接泄漏），
 * 6 个槽位被 SSE 占满，HMR 模块请求与刷新文档请求都排不上队——表现为「改代码不热更新、
 * 刷新一直转圈」，且只有带 SSE 的入库页出现。生产走 HTTP/2 多路复用无此限制，故不设上限。
 * activeRow（当前查看批次）优先订阅，其余批次靠整表刷新更新进度。
 */
const MAX_SSE_SUBSCRIPTIONS = import.meta.env.DEV ? 2 : Infinity;

/** 对当前列表中活跃态批次建立订阅；已订阅的跳过，超上限的只保留当前查看批次 */
function syncSubscriptions() {
  // 1) 目标集合：仅活跃批次，按「当前查看批次优先」排序后截取上限
  const activeBatches = batches.value.filter((b) => b.taskUid && IMPORT_ACTIVE_STATES.has(normState(b.state)));
  activeBatches.sort((a, b) => {
    const aActive = activeRow.value?.taskUid === a.taskUid ? 1 : 0;
    const bActive = activeRow.value?.taskUid === b.taskUid ? 1 : 0;
    return bActive - aActive;
  });
  const wanted = new Set(activeBatches.slice(0, MAX_SSE_SUBSCRIPTIONS).map((b) => b.taskUid as string));

  // 2) 回收不再需要的订阅（批次离开列表 / 转终态 / 被上限挤出），防止长连接泄漏占满连接槽
  sseControllers.forEach((controller, taskUid) => {
    if (!wanted.has(taskUid)) {
      controller.abort();
      sseControllers.delete(taskUid);
    }
  });

  // 3) 为尚未订阅的目标批次建立连接
  wanted.forEach((taskUid) => {
    if (sseControllers.has(taskUid)) return;
    const controller = new AbortController();
    sseControllers.set(taskUid, controller);
    subscribeTaskEvents(
      taskUid,
      {
        // 只合并 state/progress 两字段；其余列等终态整表刷新覆盖，避免字段漂移
        onEvent: (payload) => {
          const snap = (payload.data || {}) as Record<string, unknown>;
          const hit = batches.value.find((x) => x.taskUid === taskUid);
          if (!hit) return;
          if (typeof snap.state === 'string') hit.state = snap.state as ImportBatch['state'];
          if (snap.progress) hit.progress = snap.progress as ImportBatch['progress'];
        },
        // 终态：断开订阅并整表重拉一次，拿到 latest state/hint/finishedAt 等终态字段
        onTerminal: () => {
          controller.abort();
          sseControllers.delete(taskUid);
          tableRef.value?.getData();
        },
        onError: () => {
          // 契约不支持 Last-Event-ID，重连拿最新快照；本轮不自动重连，交给下次整表刷新重算订阅面
          sseControllers.delete(taskUid);
        }
      },
      controller.signal
    );
  });
}

/** 切换查看批次时立即重排订阅，让当前查看批次始终占住 dev 下有限的 SSE 名额（syncSubscriptions 内部去重，重复触发幂等） */
watch(
  () => activeRow.value?.taskUid,
  () => syncSubscriptions()
);

/**
 * 元数据图层渲染：元数据 Feature（含 WKT 解析后的几何）走独立图层组 id，
 * 与表格状态图层（renderLayers 的 __render__）互不覆盖。
 * WHY 用 createLayerGroup 而非 renderLayers：renderLayers 内部用固定 id，
 * 多次调用会互相顶掉；元数据图层需与状态图层并存。
 */
/**
 * 元数据图层用到的响应式引用：放外部避免每次重算创建新 ref 造成 watcher 泄漏。
 *
 * metaSelectedIds 点图层要素时写入对应数值 id，驱动 MapLayerOptions 的 applyState 点亮该要素；
 * 不传会丢掉 applyState 的整条链路。
 */
const metaPalette = computed<Record<string, string>>(() => categoryPalette);
const metaSelectedIds = ref<number[]>([]);
const metaHiddenIds = ref<number[]>([]);
const metaProgressFeatures = ref<any[]>([]);
const metaColorKey = ref('categoryName');
const metaLabelKey = ref('label');
const metaCluster = ref(false);
const metaClusterAnchor = ref<'corner' | 'center'>('center');
const metaHover = ref(true);
const metaFit = computed(() => metaFeatures.value.length > 0);

watch([() => map.mapInstance.value, metaFeatures], ([m, list]) => {
  if (!m) return;
  // 先清旧组：createLayerGroup 只 detach 不清地图资源，同 id 重复创建会让旧 source/layer 残留叠加
  map.removeLayerGroup(META_GROUP_ID);
  if (!list.length) return;
  const api = map.createLayerGroup(META_GROUP_ID, {
    features: metaFeatures,
    colorKey: metaColorKey,
    palette: metaPalette,
    selectedIds: metaSelectedIds,
    hiddenIds: metaHiddenIds,
    progressFeatures: metaProgressFeatures,
    labelKey: metaLabelKey,
    richLabel: ref(true),
    cluster: metaCluster,
    clusterAnchor: metaClusterAnchor,
    fit: metaFit,
    hover: metaHover,
    /**
     * 悬浮卡片内容：按《地图组件 UI 优化演示》返回结构化 VNode（标题栏 + 信息行 + 状态 Tag），
     * 不再用「· 连接纯文本」交给通用层拆行 —— 那样拿不到 Tag/标签列这类语义结构。
     * use-map.ts 的 hover 构造已支持 VNode 分支（render(content, el)）。
     */
    hoverContent: (p: any) => {
      const title = p?.label || p?.name || '';
      const infoRows = [
        ['类别', p?.categoryName],
        ['密级', p?.securityLevel],
        ['进度', p?.progress != null ? `${p.progress}%` : ''],
        ['模型', p?.modelName],
        ['来源', p?.sourceFile]
      ].filter((row) => row[1] != null && row[1] !== '') as Array<[string, string]>;
      const isSuccess = p?.state === '已完成' || p?.state === 'SUCCEEDED';
      return (
        <div class="geo-map__hover-card">
          <div class="geo-map__hover-header">{title}</div>
          <div class="geo-map__hover-content">
            {p?.state ? (
              <div class="geo-map__hover-row">
                <span class="geo-map__hover-label">状态：</span>
                <span class={['geo-map__hover-tag', isSuccess ? 'is-success' : 'is-plain']}>{p.state}</span>
              </div>
            ) : null}
            {infoRows.map(([label, value]) => (
              <div class="geo-map__hover-row">
                <span class="geo-map__hover-label">{label}：</span>
                <span class="geo-map__hover-value">{value}</span>
              </div>
            ))}
          </div>
        </div>
      );
    },
    onFeatureClick: onMapFeatureClick
  });
  api.attach();
});

/** 卸载前断开所有 SSE 连接 + 移除元数据图层，避免长连接与图层残留 */
onBeforeUnmount(() => {
  sseControllers.forEach((c) => c.abort());
  sseControllers.clear();
  dropAllMetaStreams();
  map.removeLayerGroup(META_GROUP_ID);
});

/* --------------------- 与布局（树 / 详情区）的协作 --------------------- */

/**
 * 本页接管左侧树后，必须显式告诉布局「详情区有内容」。
 *
 * WHY 不做不行：布局的收起条件是 `showMap && treeAvailable && checkedCount===0 && !hasContent`
 * （shared/index.vue 的 treeNoChecked）。入库页不勾选任何资源，checkedCount 恒为 0，
 * 若 hasContent 也恒为 false，**整个入库表格会被自动收起**，页面只剩地图 —— 正是「数据入库」
 * 这个 tab 最典型的表现异常。入库页右栏永远有内容（批次列表），故恒为 true。
 *
 * 同一行的 checkedCount 保持 0：本页没有「勾选资源上图」的语义，零勾选是事实，不该伪装。
 *
 * CONSTRAINT 必须在 onMounted 里写，不能写在 setup 顶层：useTreeHost 自己的 onMounted
 * 会把 hasContent 重置为 false（见 tree-host.ts「认领时清掉上一个面板留下的有内容」），
 * 顶层赋值会被它覆盖。本钩子注册在 useTreeHost() 之后，执行顺序上正好晚一步，能生效。
 * 卸载时不手动回退：useTreeHost 的 onBeforeUnmount 已按 owner 令牌处理，再清一次会抢值。
 */
onMounted(() => {
  if (!treeHost) return;
  treeHost.checkedCount.value = 0;
  treeHost.hasContent.value = true;
});

/**
 * 左侧树是否被布局接管（决定 Teleport 是否启用）。
 * 布局始终渲染宿主元素（v-show 控制显隐），首帧后即非空；独立挂载时为 null → 内联渲染。
 */
const hosted = computed(() => !!treeHost?.el.value);
const treeTarget = computed(() => treeHost?.el.value ?? 'body');

/** 挂载即拉产品类型树：左侧树初始不选中任何节点，数据到位后由用户点选产生类别筛选 */
onMounted(loadTypes);

/** 按类型筛选时单页拉取条数：契约 pageSize 上限 200，取满以减少往返次数 */
const SCOPED_SCAN_PAGE_SIZE = 200;
/** 按类型筛选时的最大扫描页数：超出即截断，避免某类型下批次极多时把网关打爆（4000 条已远超本系统体量） */
const SCOPED_SCAN_MAX_PAGES = 20;
/**
 * 本轮筛选是否因扫描上限被截断。
 * WHY 用常驻标签而不是 ElMessage：提示条会消失，用户翻到后面几页发现数据不全时已经无从得知，
 * 而「列表不完整」是必须一直可见的事实。
 */
const scopedTruncated = ref(false);

/**
 * 拉取「状态枚举集合」的全量批次：逐态分页扫描到末页，按 importUid 去重。
 *
 * 列表接口 state 是单值枚举，而一个中文状态可对应多个枚举（已创建=CREATED/QUEUED），
 * 所以每个枚举各自翻页取全，再合并去重；返回统一的行集合，由调用方本地分页。
 * states 为空时只查一次全量（state=undefined）。
 */
async function fetchStateUnion(keyword: string, states: ImportState[], categoryUid: string | undefined, names?: Set<string>) {
  const rows: ImportBatchRow[] = [];
  const seen = new Set<string>();
  let truncated = false;
  const queryStates: Array<ImportState | undefined> = states.length ? states : [undefined];
  for (const state of queryStates) {
    for (let page = 1; page <= SCOPED_SCAN_MAX_PAGES; page++) {
      const res: any = await listImportBatches({ keyword, state, categoryUid, page, pageSize: SCOPED_SCAN_PAGE_SIZE });
      const batch: ImportBatchRow[] = res?.data?.items ?? [];
      const total = Number(res?.data?.total ?? batch.length);
      for (const row of batch) {
        if (seen.has(row.importUid)) continue;
        seen.add(row.importUid);
        if (!names || names.has(String(row.categoryName ?? ''))) rows.push(row);
      }
      if (!batch.length || page * SCOPED_SCAN_PAGE_SIZE >= total) break;
      if (page === SCOPED_SCAN_MAX_PAGES) truncated = true;
    }
  }
  return { rows, truncated };
}

/**
 * 请求序号：每次 getBatches 自增，回来时只有「最新一次」才允许写状态。
 *
 * WHY 需要：本页有两类并发来源 —— ① Table 首屏 getData 与用户点选类型触发的 query()
 * 可能紧接着发出；② 树上快速连点几个类型。筛选态下 fetchStateUnion 是多次串行请求，
 * 耗时更长，先发的旧请求完全可能后回，把新结果覆盖成旧数据（表现为「点了 B 却显示 A 的批次」）。
 *
 * CONSTRAINT 过期请求**不能返回空清单**：Table 的 getData 拿到 code===0 就会把 dataSource
 * 整体替换成返回的 items，返回空数组等于把表格清空（用户看到「闪一下变空再恢复」）。
 * 因此过期请求返回「当前已展示的快照」，让 Table 重渲染同一份内容，不影响最新请求的结果。
 */
let requestSeq = 0;
/** 最近一次有效结果的 total（过期请求回放快照时要用，不能从 Table 内部取） */
let lastTotal = 0;

/** Table request 回调：必须在此加载数据，不能只靠 onMounted（Table 首次 getData 早于挂载） */
async function getBatches(params: Params) {
  const seq = ++requestSeq;
  /** 过期分支统一走这里：回放当前快照，不写任何状态 */
  const staleSnapshot = () => ({ code: 0, data: { items: [...batches.value], total: lastTotal } });

  const keyword = params.keyword;
  /**
   * 状态：queryParams.state 是「中文规范键翻译出的英文枚举 CSV」。
   * 中文显示态可能对应多个后端枚举（如「已创建」= CREATED / QUEUED），列表接口 state 只收单值，
   * 这里按 CSV 拆开逐个请求后合并去重（无需改后端契约，也不改变列表的中文显示口径）。
   */
  const states = String(params.state || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean) as ImportState[];
  const page = Number(params.page) || 1;
  const pageSize = Number(params.pageSize) || 10;
  const categoryUid = selectedTypeUid.value;
  const names = scopedNames.value;

  let items: ImportBatchRow[] = [];
  let total = 0;
  let truncated = false;

  const scanned = await fetchStateUnion(keyword, states, categoryUid, names.size ? names : undefined);
  if (seq !== requestSeq) return staleSnapshot();
  total = scanned.rows.length;
  items = scanned.rows.slice((page - 1) * pageSize, (page - 1) * pageSize + pageSize);
  truncated = scanned.truncated;

  scopedTruncated.value = truncated;
  lastTotal = total;
  batches.value = items;
  // 当前查看的批次已不在结果里（被删除 / 被筛选条件排除）：图层留着会指向一条不存在的批次，清掉
  if (activeRow.value && !items.some((b) => b.importUid === activeRow.value?.importUid)) {
    activeRow.value = null;
    clearMetaLayer();
  } else if (activeRow.value) {
    // 同一批次仍在列表中：用最新行数据替换引用，后续进度 / 状态变化能跟上
    const fresh = items.find((b) => b.importUid === activeRow.value?.importUid);
    if (fresh) activeRow.value = fresh;
  }
  syncSubscriptions();
  return { code: 0, data: { items, total } };
}

/**
 * 按错误码分派「下一步动作」提示。
 *
 * WHY 必须按 errorCode 分派（contract §九）：后端对入库失败给的稳定码决定用户接下来该做什么
 * （来源已变→回检查；检查单失效→重新检查；补录状态不允许→刷新详情），
 * 一律弹「操作失败」会让用户在同一条死路上反复重试。
 *
 * CONSTRAINT 不与拦截器抢着弹窗：`request.ts` 的响应拦截器已对 4xx 弹过后端原文，
 * 这里**只在识别出稳定错误码时**补一条带动作指引的提示（那正是拦截器给不出的信息：
 * 「接下来该做什么」）；识别不出错误码就静默返回，避免同一失败弹两次。
 */
function notifyImportError(error: unknown) {
  const action = resolveMetacheckErrorAction(error);
  if (!action) return;
  const hints: Record<string, string> = {
    recheck: pt('来源或检查单已变化，请回「数据检查」重新检查后再入库'),
    pickFiles: pt('请回到新建入库重新选择文件'),
    clearCheckUid: pt('「检查通过后入库」必须绑定检查单、「直接入库」不能绑定检查单，请按策略调整后重试'),
    pickCategory: pt('请重新选择产品类别'),
    checkSource: pt('请检查共享位置与路径是否可用'),
    pickModel: pt('请先配置或选择元数据模型，或改走正常检查'),
    refresh: pt('请刷新详情/列表后重试')
  };
  const hint = hints[action];
  if (!hint) return;
  ElMessage.warning(describeMetacheckError(error).message + '：' + hint);
}

async function doAction(row: ImportBatchRow, action: 'start' | 'pause' | 'resume') {
  const actions = { start: startImportBatch, pause: pauseImportBatch, resume: resumeImportBatch };
  try {
    await actions[action](row.importUid);
    ElMessage.success(pt('操作成功'));
  } catch (error) {
    // 失败原因由响应拦截器统一弹出（含 409 当前状态不允许该操作的后端原文），此处补动作提示
    notifyImportError(error);
  } finally {
    tableRef.value?.getData();
  }
}

/**
 * 删除入库批次（物理删除）。
 * CONSTRAINT 后端状态门禁：RUNNING / QUEUED / PAUSING 时返回 409；按钮已按归一后的英文键禁用，
 * 其余 404（不存在）等业务错由响应拦截器统一弹出。
 */
async function doDelete(row: ImportBatchRow) {
  try {
    await ElMessageBox.confirm('删除后将物理清除批次与任务记录，且不可恢复。确定删除「' + row.importName + '」？', pt('警告'), { type: 'warning' });
  } catch {
    return;
  }
  try {
    const res: any = await deleteImportBatch(row.importUid);
    const deleted = res?.data?.resourceDeleted;
    ElMessage.success(deleted ? pt('已删除批次及资源') : pt('已删除批次（资源保留）'));
  } catch (error) {
    // 失败原因由响应拦截器统一弹出（含 409 运行中 / 404 不存在）
    notifyImportError(error);
  } finally {
    tableRef.value?.getData();
  }
}

/**
 * 打开入库详情。
 *
 * WHY 不在此处预拉详情：detail.vue 的 onMounted 自己会拉一次，这里再拉一遍就是**两个请求**
 * （本环境 `/platform/imports/{uid}` 要阻塞到 120s，重复请求会把等待翻倍）。
 * 因此只把列表行当 initial 骨架传进去，让详情组件自己加载并覆盖。
 *
 * CONSTRAINT 行数据不含 checkUid/files/directIngest/metadataBackfill（T6a 这些只在详情接口投影），
 * detail.vue 对缺失字段一律显示占位，不会把「未加载」误渲染成「确认无值」。
 */
function openDetail(row: ImportBatchRow) {
  const initial = row as unknown as ImportBatchDetail;
  createDialog({
    title: pt('入库详情'),
    width: '900px',
    footer: false,
    bodyStyle: { padding: '0 20px 16px' },
    render: () => <Detail importUid={row.importUid} initial={initial} onChanged={() => tableRef.value?.getData()} />
  });
}

/**
 * 打开「产品类型管理」弹窗（入口在左侧树头部）。
 *
 * WHY 调度放在页面而不是树组件里：树被 Teleport 到布局左列，本身不该持有弹窗与刷新职责；
 * 更关键的是，管理里增删改类别后要刷新的是**整页的 typeRoots**（列表筛选、新建默认类别都用它），
 * 而不只是弹窗里那个类别下拉。onChanged 回调里统一 loadTypes() 即可让两处一起更新。
 */
function openManage() {
  createDialog({
    title: pt('产品类型管理'),
    width: '630px',
    footer: false,
    render: () => <ProductTypeManageDialog onChanged={loadTypes} categoryRoot={categoryRoot} />
  });
}

/**
 * 「新建入库」已由弹窗改为页面内 tab（默认展示）。
 *
 * 左侧树选中的产品类型作为新建任务的默认类别（用户口径：「新建入库任务默认和左侧同步」）：
 *  - defaultCategoryUid → Edit 的类别来源（direct 策略下表单不再有产品字段，左树即唯一来源）；
 *  - typeRoots → Edit 直接沿用本页已拉到的类别树，避免再拉一遍接口
 *    （两遍请求还可能因为 tree 刷新时序不同，让默认值与树上显示的类型不一致）。
 *
 * CONSTRAINT 用户在看某个类型时新建任务，入库类别即落在该类型上（direct 策略下左树是唯一来源）。
 */

/**
 * 页面内提交「新建入库」。
 *
 * 复刻 createDialog.submit 的契约：先 form.validate，再 Edit.save；失败时 Edit 自己
 * 提示并保留表单（save 返回 undefined），成功时（code=0）切到列表 tab 并刷新树与列表。
 */
async function submitCreate() {
  const edit = editRef.value;
  if (!edit) return;
  try {
    await edit.form?.validate?.();
  } catch {
    return;
  }
  creating.value = true;
  try {
    const res = await edit.save();
    if (res === undefined) return;
    if (res?.code === 0) {
      ElMessage.success(res.message || '保存成功。');
      // 保存成功后消费掉检查页带过来的共享上下文，避免再切回新建 tab 时重复回显已入库的检查单
      clearSelection();
      // 新建后批次归属可能变化（用户改过类别），树与列表都按最新事实刷新
      loadTypes();
      activeTab.value = 'list';
      tableRef.value?.getData();
    } else {
      ElMessage.error(res.message || '保存失败。');
    }
  } finally {
    creating.value = false;
  }
}

/** 重置「新建入库」表单：委托 edit.vue 清空清单并恢复基本信息默认值 */
function resetCreate() {
  editRef.value?.resetForm?.();
}
</script>

<template>
  <!-- 根容器必须显式 height:100% + overflow:hidden：父级 .pane-detail 是 flex 容器，
       本层不给高度时 Table 的 i-table height:100% 参照落空，表格就不出内部滚动条 -->
  <div class="import-page">
    <!-- 左：产品类型树。布局注入了树挂载位时 Teleport 到左侧独立列（高度撑满整个内容区）；
         未注入（独立挂载）时 Teleport 退化为就地渲染，仍是「左树右表」的内联布局。 -->
    <Teleport :to="treeTarget" :disabled="!hosted">
      <div class="import-tree" :class="{ 'is-hosted': hosted }">
        <ProductTypeTree v-model="selectedTypeUid" :roots="typeRoots" :loading="typeLoading" @manage="openManage" />
      </div>
    </Teleport>

    <div v-if="!hosted" class="import-split" />

    <section class="import-detail">
      <!-- 保存/重置按钮定位到 tab 栏右侧（仅新建入库 tab 显示）：EP 的 el-tabs 无 #extra 插槽，改用绝对定位覆盖到 header 右端 -->
      <div v-if="activeTab === 'create'" class="import-header-actions">
        <el-button :disabled="creating" @click="resetCreate">{{ pt('重置') }}</el-button>
        <el-button type="primary" :loading="creating" @click="submitCreate">{{ pt('保存') }}</el-button>
      </div>
      <el-tabs v-model="activeTab" class="import-tabs">
        <el-tab-pane :label="pt('新建入库')" name="create">
          <div class="import-create">
            <div class="import-create__body">
              <Edit ref="editRef" :category-root="categoryRoot" :default-category-uid="selectedTypeUid" :type-roots="typeRoots" />
            </div>
          </div>
        </el-tab-pane>

        <el-tab-pane :label="pt('入库列表')" name="list">
          <Table
            ref="tableRef"
            :columns="columns"
            :request="getBatches"
            :query-params="queryParams"
            :row-class-name="rowClassName"
            row-key="importUid"
            highlight-current-row
            @row-click="onRowClick"
          >
            <template #search>
              <el-input v-model="queryParams.keyword" :label="pt('名称')" :placeholder="pt('任务名称或产品类型')" />
              <el-select
                v-model="stateFilter"
                :label="pt('状态')"
                :placeholder="pt('全部状态')"
                :options="stateOptions.map((s) => ({ label: stateMap[s].label, value: s }))"
                @change="onStateChange"
              />
            </template>
          </Table>
        </el-tab-pane>
      </el-tabs>
    </section>
  </div>
</template>

<style scoped lang="scss">
/* 主区：左树 + 右表。
   被布局接管时树已 Teleport 到布局左列，本容器只剩右表的 section（树节点不出现在这里），
   所以这里用 flex 双栏只为「独立挂载」的内联形态服务，两种形态共用同一套规则不会互相干扰。 */
.import-page {
  display: flex;
  align-items: stretch;
  gap: 0;
  height: 100%;
  overflow: hidden;
}

/* 树列宽度：与 data-browse 独立挂载时的 flexBasis 口径一致，避免同页两种树宽。
   卡片化外壳与右栏呼应；独立挂载时才显示边框，托管时由布局列提供外观。 */
.import-tree {
  display: flex;
  flex: 0 0 auto;
  flex-direction: column;
  width: 300px;
  min-height: 0;
  padding-right: 8px;
  box-sizing: border-box;
  background: var(--el-bg-color);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 6px;
}

/* 被 Teleport 到布局左列时吃满整列：宽度由布局的树列给定，高度撑满内容区 */
.import-tree.is-hosted {
  flex: 1 1 auto;
  width: 100%;
  padding-right: 0;
  border: none;
  background: transparent;
}

.import-tree__err {
  padding: 6px 2px;
  color: var(--el-color-warning);
  font-size: 12px;
}

/* 独立挂载时树与表之间的分隔缝（布局接管时不渲染） */
.import-split {
  flex: 0 0 8px;
}

/* 右栏：tabs + 批次表格。flex:1 + min-width:0 让 Table 的 100% 宽度参照落回本容器而不是内容宽。
   卡片化外壳与左树呼应；overflow:hidden 让圆角裁掉内部方角。 */
.import-detail {
  position: relative;
  display: flex;
  flex: 1 1 0;
  flex-direction: column;
  min-width: 0;
  min-height: 0;
  overflow: hidden;
  background: var(--el-bg-color);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 6px;
}

/* 保存/重置按钮组：绝对定位到 tab header 右端（EP el-tabs 无 #extra 插槽，只能自行覆盖） */
.import-header-actions {
  position: absolute;
  z-index: 2;
  top: 4px;
  right: 14px;
  display: flex;
  gap: 8px;
}

/* el-tabs 必须显式撑满：否则内部 tab-pane 的 Table height:100% 参照落空 */
.import-tabs {
  display: flex;
  flex: 1 1 auto;
  flex-direction: column;
  min-height: 0;
}

/* tabs 头：与卡片左右内边距对齐，标签切换加轻微过渡；底部分隔线让「头/体」层次更清晰 */
:deep(.import-tabs > .el-tabs__header) {
  margin: 0;
  padding: 0 14px;
  border-bottom: 1px solid var(--el-border-color-lighter);
}
:deep(.import-tabs .el-tabs__nav-wrap::after) {
  display: none;
}
:deep(.import-tabs .el-tabs__item) {
  transition: color 0.15s ease;
}
:deep(.import-tabs > .el-tabs__content) {
  flex: 1 1 auto;
  min-height: 0;
  overflow: hidden;
}

:deep(.import-tabs .el-tab-pane) {
  height: 100%;
}

/* 新建入库：表单区可滚动（保存按钮在 tab 栏右侧，不再有底部操作条） */
.import-create {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
}

/* 表单体不滚动：Edit 内部已改为「基本信息固定 + 入库清单占满剩余高度、树在卡片内滚动」，
   外层不再需要滚动条（用户口径：页面不要有滚动条） */
.import-create__body {
  flex: 1 1 auto;
  min-height: 0;
  overflow: hidden;
}

/* 操作区的筛选标签：提示当前类型作用范围 / 在途状态 */
.import-scope {
  margin-left: 8px;
}

/* ⚠ 以下类只出现在 columns 的 JSX render 里，不在 <template> 中。
   formatter 由 ElTable 在自己的渲染上下文执行，产出的 vnode 拿的是 ElTable 的 scopeId
   而不是本组件的，所以 `scoped` 编出来的 `.progress-cell[data-v-xxx]` 永远匹配不到——
   样式静默失效（表现为进度条不是 flex）。
   改用 :deep()：编译成 `[data-v-xxx] .progress-cell`，由根节点 .import-page 携带的
   本组件 scope 锚定，后代选择器不再要求目标元素自带 scopeId。 */

:deep(.progress-cell) {
  display: flex;
  align-items: center;
  gap: 8px;
}

:deep(.progress-cell .el-progress) {
  flex: 1;
}

:deep(.progress-cell span) {
  width: 38px;
  color: #718097;
  font-size: 12px;
  font-variant-numeric: tabular-nums;
  text-align: right;
}

/* row-actions 目前本页未在 JSX 使用，保留以免后续加到 render 里再次踩坑 */
:deep(.row-actions) {
  white-space: nowrap;
}

/* 选中行（import-row--active / current-row）样式已归一到全局
   src/assets/styles/index.scss 的 html.group-manage 块（地图联动列表选中行唯一真源），此处不再重复。 */

/* 结果列：活跃态在状态标签前放一个呼吸点，静态截图也能看出「在跑」 */
:deep(.result-cell) {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}

:deep(.live-dot) {
  display: inline-block;
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: var(--el-color-primary);
  box-shadow: 0 0 0 3px color-mix(in srgb, var(--el-color-primary) 14%, transparent);
  animation: import-pulse 1.4s ease-in-out infinite;
}

@keyframes import-pulse {
  0%,
  100% {
    opacity: 1;
    transform: scale(1);
  }
  50% {
    opacity: 0.35;
    transform: scale(0.7);
  }
}

/* 尊重系统「减少动态效果」偏好：静态光晕仍在，「在跑」态不靠动画也能表达 */
@media (prefers-reduced-motion: reduce) {
  :deep(.live-dot) {
    animation: none;
  }
  :deep(.import-tabs .el-tabs__item) {
    transition: none;
  }
}
</style>

<style lang="scss">
/* 数据入库地图悬浮卡片：按《地图组件 UI 优化演示》最终 UI 落地为白色现代卡片。
   popup teleport 到 body，不受本组件 scope 约束，故用独立非 scoped 块；
   :root 前缀把优先级抬到 0,3,0 —— geo-map/index.vue 的 .geo-map .maplibregl-popup-content
   同为 0,2,0 且加载在后，不抬优先级会被它覆盖。 */
:root .geo-map__hover-popup .maplibregl-popup-content {
  padding: 0;
  overflow: hidden;
  width: 300px;
  color: #595959;
  background: #fff;
  border: 1px solid #f0f0f0;
  border-radius: 8px;
  box-shadow: 0 6px 16px rgb(0 0 0 / 8%);
  filter: drop-shadow(0 2px 4px rgb(0 0 0 / 10%));
}

:root .geo-map__hover-popup .geo-map__hover {
  max-width: none;
  font-size: 13px;
  line-height: 1.8;
}

:root .geo-map__hover-popup .geo-map__hover-header {
  padding: 12px 16px;
  color: #333;
  background: #fafafa;
  border-bottom: 1px solid #f0f0f0;
  font-size: 14px;
  font-weight: 600;
}

:root .geo-map__hover-popup .geo-map__hover-content {
  padding: 12px 16px;
}

:root .geo-map__hover-popup .geo-map__hover-row {
  display: flex;
  align-items: center;
  margin-bottom: 6px;

  &:last-child {
    margin-bottom: 0;
  }
}

:root .geo-map__hover-popup .geo-map__hover-label {
  width: 50px;
  color: #8c8c8c;
}

:root .geo-map__hover-popup .geo-map__hover-value {
  color: #595959;
}

:root .geo-map__hover-popup .geo-map__hover-tag {
  display: inline-block;
  padding: 2px 8px;
  border: 1px solid #d9d9d9;
  border-radius: 4px;
  color: #595959;
  background: #f5f5f5;
  font-size: 12px;
  font-weight: 500;
  line-height: 1.2;

  &.is-success {
    color: #389e0d;
    background: #f6ffed;
    border-color: #b7eb8f;
  }
}

:root .geo-map__hover-popup .maplibregl-popup-tip {
  border-top-color: #fafafa;
}

/* 地图白底标签（DOM Marker，见 use-map.ts syncLabelMarkers）：
   MapLibre v6 不支持 text-background-*，改用普通 DOM 还原最终 UI 的白底/灰边标签。 */
:root .geo-map__label {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 4px 8px;
  color: #333;
  background: rgb(255 255 255 / 90%);
  border: 1px solid #d9d9d9;
  border-radius: 4px;
  box-shadow: 0 2px 6px rgb(0 0 0 / 8%);
  font-size: 12px;
  font-weight: 500;
  line-height: 1.4;
  white-space: nowrap;
  cursor: default;
  pointer-events: none;
  transition: all 0.3s;

  .geo-map__label-dot {
    flex: 0 0 auto;
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: #52c41a;
  }

  .geo-map__label-badge {
    color: #8c8c8c;
    font-size: 11px;
  }

  &.is-selected {
    color: #fff;
    background: #1890ff;
    border-color: #1890ff;
    box-shadow: 0 4px 12px rgb(24 144 255 / 35%);

    .geo-map__label-dot {
      background: #fff;
    }

    .geo-map__label-badge {
      color: rgb(255 255 255 / 85%);
    }
  }
}
</style>
