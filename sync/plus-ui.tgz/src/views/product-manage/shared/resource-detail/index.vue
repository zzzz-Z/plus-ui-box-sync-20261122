<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
/**
 * 资源详情（全项目唯一实现，三处统一）
 *
 * 版式参照 source.coop 产品页（https://source.coop/vizzuality/lg-land-carbon-data）：
 * 主栏 = 「Contents（文件列表）→ README 位（仓库概览：描述 + 批次 kv + 元数据记录小节）」，
 * 侧栏 = 「详情 / 统计」。元数据记录**并入仓库概览卡**（用户 2026-11-11 口径）：
 * source.coop 的 README 里指标表格就是概览正文的一部分，不再单独一张「元数据记录」卡。
 *
 * 滚动口径（用户 2026-11-11）：**整个内容块一条滚动轴** —— 外层 .detail-page 统一滚，
 * 卡内一律不自建滚动条（旧版文件列表 / 概览各滚各的，滚轮落在哪条轴全看指针位置）。
 *
 * 资源标题 / 描述 / 状态标签已上移到外层详情头部的「已选资源 tab」（用户 2026-11-10 口径），
 * 本组件只负责资源本身的内容。数据全部来自 getResource + getRepository + listRepositoryContents，
 * 不新增虚构指标。
 *
 * WHY 单文件共享：此组件此前在 data-browse / data-query / records-edit 有三份逐行近似的副本，
 * 契约变更要改三处、漏一处就是「点了没反应」级事故（latestImport.createdAt 说谎行曾同时躺在
 * 三份里）。data-query 那份实测已无人 import（死副本），一并删除；今后新增详情消费点引本文件。
 */
import { ref, watch, onMounted, type Component } from 'vue';
import { ElTag, ElMessage } from 'element-plus';
import {
  Document,
  Download,
  CopyDocument,
  Refresh,
  Search,
  Folder,
  Picture,
  VideoCamera,
  Headset,
  Grid,
  DataBoard,
  Box,
  MapLocation,
  Memo,
  Cpu
} from '@element-plus/icons-vue';
import { getResource } from '@/api/product-manage/platform/resources';
import {
  downloadArtifact,
  getRepository,
  listRepositoryContents,
  type RepositoryEntry,
  type RepositoryMetadata,
  type RepositoryMetadataRecord
} from '@/api/product-manage/platform/repository';
import { saveAs } from 'file-saver';

const props = defineProps<{ resourceUid: string }>();

const resource = ref<any>(null);
const repository = ref<any>(null);
const loading = ref(false);
const contents = ref<RepositoryEntry[]>([]);
const currentPath = ref('');
const contentsLoading = ref(false);
/** 元数据字段筛选关键字（42 字段 × N 条记录，靠肉眼扫不现实） */
const metaKeyword = ref('');
/** 折叠态：默认只展开第一条记录（旧版是全展开，126 个格子一起铺） */
const activeMetaNames = ref<string[]>([]);

const dataTypeLabels: Record<string, string> = { vector: pt('矢量'), raster: pt('栅格'), table: pt('表格'), text: pt('文本') };
// 状态标签色：后端 state 出参可能是中文（就绪/待处理），入参枚举是英文；两套都收
const stateTypes: Record<string, string> = {
  就绪: 'success',
  异常: 'danger',
  待配置: 'warning',
  待处理: 'info',
  READY: 'success',
  SUCCEEDED: 'success',
  FAILED: 'danger',
  QUEUED: 'info',
  RUNNING: 'warning'
};

/* ================= 文件图标 =================
 * 列表里同一套「Document」让文件夹/图片/表格长一个样，看不出类型。
 * 做法：按扩展名归到语义组（几何/影像/影像栅格/文档/表格/演示/压缩/音视频/代码…），
 * 每组固定一个 Element Plus 图标 + 一个主题色；扩展名认不出时退回 mediaType，再退回通用文档图标。
 */
interface FileIconMeta {
  icon: Component;
  color: string;
}

const ICON_FOLDER: FileIconMeta = { icon: Folder, color: '#e6a23c' };
const ICON_FILE: FileIconMeta = { icon: Document, color: '#909399' };
const ICON_GEO: FileIconMeta = { icon: MapLocation, color: '#13a8a8' };
const ICON_RASTER: FileIconMeta = { icon: Picture, color: '#3f8cff' };
const ICON_IMAGE: FileIconMeta = { icon: Picture, color: '#52b788' };
const ICON_VIDEO: FileIconMeta = { icon: VideoCamera, color: '#8b5cf6' };
const ICON_AUDIO: FileIconMeta = { icon: Headset, color: '#06b6d4' };
const ICON_DOC: FileIconMeta = { icon: Document, color: '#3f8cff' };
const ICON_PDF: FileIconMeta = { icon: Document, color: '#f56c6c' };
const ICON_SHEET: FileIconMeta = { icon: Grid, color: '#2ba471' };
const ICON_SLIDE: FileIconMeta = { icon: DataBoard, color: '#f08c34' };
const ICON_ARCHIVE: FileIconMeta = { icon: Box, color: '#b4813f' };
const ICON_TEXT: FileIconMeta = { icon: Memo, color: '#909399' };
const ICON_CODE: FileIconMeta = { icon: Cpu, color: '#6b7ea8' };

/** [图标, 扩展名列表]：一个扩展名只登记一次，后者不会覆盖前者之外的分组 */
const extGroups: Array<[FileIconMeta, string[]]> = [
  // 矢量 / 地理数据（本系统主力）
  [
    ICON_GEO,
    [
      'shp',
      'shx',
      'dbf',
      'prj',
      'cpg',
      'sbn',
      'sbx',
      'qix',
      'fix',
      'gdb',
      'mdb',
      'geojson',
      'topojson',
      'kml',
      'kmz',
      'gpx',
      'gml',
      'wkt',
      'osm',
      'pbf',
      'dxf',
      'dwg',
      'tab',
      'mif',
      'mid'
    ]
  ],
  // 栅格 / 影像数据（遥感、DEM）
  [ICON_RASTER, ['tif', 'tiff', 'img', 'jp2', 'ecw', 'sid', 'hdf', 'hdf5', 'nc', 'grib', 'dem', 'asc', 'pix', 'bil', 'bsq', 'vrt']],
  // 位图 / 图片
  [ICON_IMAGE, ['png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp', 'svg', 'ico', 'heic', 'psd', 'ai', 'eps']],
  [ICON_PDF, ['pdf']],
  [ICON_DOC, ['doc', 'docx', 'rtf', 'odt', 'wps', 'pages', 'dot']],
  [ICON_SHEET, ['xls', 'xlsx', 'csv', 'tsv', 'ods', 'et', 'numbers']],
  [ICON_SLIDE, ['ppt', 'pptx', 'pps', 'odp', 'key', 'dps']],
  [ICON_TEXT, ['txt', 'md', 'markdown', 'log', 'readme', 'license', 'rst', 'nfo']],
  [ICON_ARCHIVE, ['zip', 'rar', '7z', 'tar', 'gz', 'tgz', 'bz2', 'xz', 'zst', 'jar', 'war']],
  [ICON_VIDEO, ['mp4', 'avi', 'mkv', 'mov', 'wmv', 'flv', 'webm', 'm4v', 'mpg', 'mpeg']],
  [ICON_AUDIO, ['mp3', 'wav', 'flac', 'aac', 'ogg', 'm4a', 'wma']],
  [
    ICON_CODE,
    [
      'js',
      'mjs',
      'cjs',
      'ts',
      'tsx',
      'jsx',
      'vue',
      'json',
      'xml',
      'html',
      'htm',
      'css',
      'scss',
      'less',
      'py',
      'java',
      'sql',
      'yml',
      'yaml',
      'sh',
      'bat',
      'ini',
      'conf',
      'toml',
      'ipynb'
    ]
  ]
];

/** 双扩展名要整体匹配（.tar.gz 不该按 .gz 之外的规则走，.shp.xml 仍是几何文件） */
const compositeExts = ['shp.xml', 'tar.gz', 'tar.bz2', 'tar.xz'];

const iconByExt: Record<string, FileIconMeta> = (() => {
  const map: Record<string, FileIconMeta> = {};
  for (const [meta, exts] of extGroups) for (const ext of exts) if (!map[ext]) map[ext] = meta;
  return map;
})();

/** mediaType 兜底：扩展名缺失 / 不常见时仍能给出类型感 */
const mediaIconFallbacks: Array<[string, FileIconMeta]> = [
  ['image/', ICON_IMAGE],
  ['video/', ICON_VIDEO],
  ['audio/', ICON_AUDIO],
  ['text/csv', ICON_SHEET],
  ['text/', ICON_TEXT],
  ['application/pdf', ICON_PDF],
  ['application/zip', ICON_ARCHIVE],
  ['application/x-tar', ICON_ARCHIVE]
];

function resolveFileIcon(entry: RepositoryEntry): FileIconMeta {
  if (entry.isDir) return ICON_FOLDER;
  const name = (entry.name || '').toLowerCase();
  const composite = compositeExts.find((ext) => name.endsWith('.' + ext));
  if (composite) return iconByExt[composite];
  const dot = name.lastIndexOf('.');
  const ext = dot > 0 ? name.slice(dot + 1) : '';
  const byExt = ext ? iconByExt[ext] : undefined;
  if (byExt) return byExt;
  const mt = (entry.mediaType || '').toLowerCase();
  const byMedia = mediaIconFallbacks.find(([prefix]) => mt.startsWith(prefix));
  return byMedia ? byMedia[1] : ICON_FILE;
}

/** 顶部摘要：优先取仓库口径的文件总数，缺失时回退资源 dataCount */
const fileTotal = computed<number | null>(() => {
  const n = repository.value?.fileCount ?? resource.value?.dataCount;
  return typeof n === 'number' ? n : null;
});

const categoryName = computed<string>(() => repository.value?.category?.name || resource.value?.categoryName || '');
const typeLabel = computed<string>(() => dataTypeLabels[resource.value?.dataType] || resource.value?.dataType || '-');

/**
 * 存储容量拆成「数值 + 单位」两段。
 *
 * WHY 不整串丢进统计块：`302.62 KB` 在侧栏 88px 宽的 stat-box 里会折成两行
 * （实测 h=45.6px，正好两个 22.8px 行高），数字块被撑破、和邻格不对齐。
 * 单位单独降字号后单行放得下，也不必为了排版把 302.62 舍成 302。
 */
const sizeParts = computed<{ num: string; unit: string } | null>(() => {
  const n = repository.value?.totalBytes;
  if (typeof n !== 'number' || !Number.isFinite(n) || n < 0) return null;
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let v = n;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  // 整数单位（B）不铺小数；其余保留两位，再剥掉无意义的尾零（1.00 → 1，10.50 → 10.5）
  let num = i === 0 ? String(Math.round(v)) : v.toFixed(2).replace(/\.?0+$/, '');
  if (num === '') num = '0';
  return { num, unit: units[i] };
});
/** 完整容量文本：统计块给 title 用，避免拆段后看不出原始值 */
const totalSizeText = computed<string>(() => (sizeParts.value ? `${sizeParts.value.num} ${sizeParts.value.unit}` : '-'));

/** 可见范围：契约枚举 private/dept/internal/public，直接把英文摆出来等于没说 */
const visibilityLabels: Record<string, string> = { private: pt('私有'), dept: pt('部门'), internal: pt('内部'), public: pt('公开') };
const visibilityLabel = computed<string>(() => {
  const v = repository.value?.visibility;
  if (!v) return '';
  return visibilityLabels[v] || v;
});

/** 模型绑定状态：契约枚举 bound / unconfigured */
const bindingLabels: Record<string, string> = { bound: pt('已绑定'), unconfigured: pt('未配置') };
const bindingLabel = computed<string>(() => {
  const v = resource.value?.modelBindingState;
  if (!v) return '';
  return bindingLabels[v] || v;
});

/* ================= 元数据记录（GET /repository 的 data.metadata） =================
 * 契约口径：items 是「最新已入库」的元数据记录列表，一条记录一组字段；
 * values 只含业务字段（无几何 / 身份列 / 物理路径 / 凭据），列名靠 fieldLabels 映射中文。
 *
 * 实测痛点（3 条记录 × 42 字段 = 126 个格子同时铺开，滚动高 2637px）：
 * 1. 记录之间没有折叠，页首就被元数据淹没 → 改为 el-collapse，默认只开第一条；
 * 2. 记录头去掉 tableKey / pgTable / sourceFile 等英文标识与长 ID，只留序号与字段数；
 * 3. 42 字段等权平铺，产品名 / 几何形态 / 要素数被 meta_id 之流淹没 → 核心字段前置；
 * 4. 四角经纬度 8 个键各占一格 → 合并成一行「空间范围」。
 */
const meta = computed<RepositoryMetadata | null>(() => repository.value?.metadata ?? null);
const metaRecords = computed<RepositoryMetadataRecord[]>(() => meta.value?.items ?? []);
/** available=false 时的可读说明（后端给稳定 errorCode + 安全 errorMessage，前端不自己编） */
const metaUnavailableText = computed<string>(() => {
  const m = meta.value;
  if (!m) return '';
  return m.errorMessage || m.errorCode || '暂无可读的元数据表';
});
/** 统计块口径：后端 recordCount 优先，缺失时回退已返回的 items 条数；不可读时给 null 走 '-' */
const metaRecordTotal = computed<number | null>(() => {
  const m = meta.value;
  if (!m || !m.available) return null;
  if (typeof m.recordCount === 'number') return m.recordCount;
  return metaRecords.value.length;
});

/**
 * 核心字段优先级（按此顺序前置，未列出的进「其余字段」）。
 *
 * 选取标准是「一句话说清这是什么数据」：产品名 / 编码 / 版本 / 几何 / 要素数 / 格式 /
 * 坐标系 / 密级 / 质量 / 生产方。这些键来自契约 fieldLabels 的英文键，
 * 后端某个模型没有该字段时自然跳过，不会渲染空行。
 */
const CORE_FIELD_KEYS = [
  'product_name',
  'product_code',
  'version_no',
  'data_format',
  'geometry_type',
  'feature_count',
  'coordinate_sys',
  'secret_level',
  'data_status',
  'quality_score',
  'produce_unit',
  'produce_time'
];

/** 四角经纬度：8 个键汇总成一行 bbox，比 8 个「右上角经度 114.21」好读得多 */
const BBOX_KEYS = ['sw_lon', 'sw_lat', 'ne_lon', 'ne_lat', 'nw_lon', 'nw_lat', 'se_lon', 'se_lat'];
const BBOX_KEY_SET = new Set(BBOX_KEYS);

interface MetaRowView {
  key: string;
  label: string;
  text: string;
  empty: boolean;
  /** 长值（坐标系、存储路径、空间范围）跨整行，避免被两列挤成竖条 */
  wide: boolean;
}

interface MetaRecordView {
  /** 折叠项稳定 key：同一资源下 pgTable 可能重复，故拼上序号 */
  key: string;
  index: number;
  tableKey: string;
  pgTable: string;
  sourceFile?: string;
  fieldCount: number;
  bbox: string;
  /** 空间范围行是否显示：无筛选时常显；筛选时只在命中「空间范围 / 坐标 / 值」时显示 */
  showBbox: boolean;
  core: MetaRowView[];
  rest: MetaRowView[];
}

function toNum(v: unknown): number | null {
  if (v === null || v === undefined) return null;
  const s = String(v).trim();
  if (s === '') return null;
  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}

/** 四角坐标 → 单行 bbox；凑不齐经纬度就返回空串（宁可不显示也不猜） */
function recordBbox(values: Record<string, unknown>): string {
  const lons = ['sw_lon', 'nw_lon', 'se_lon', 'ne_lon'].map((k) => toNum(values[k])).filter((n): n is number => n !== null);
  const lats = ['sw_lat', 'nw_lat', 'se_lat', 'ne_lat'].map((k) => toNum(values[k])).filter((n): n is number => n !== null);
  if (!lons.length || !lats.length) return '';
  return `${Math.min(...lons)}, ${Math.min(...lats)} → ${Math.max(...lons)}, ${Math.max(...lats)}`;
}

/**
 * 单条记录 → 视图模型。
 *
 * WHY 以 values 自身的键序为准（而不是 fieldLabels 的键序）：实测两者逐项一致，
 * 但某条记录缺字段时按 labels 遍历会多出一堆空行；按 values 遍历则「有什么展示什么」，
 * 缺的标签回落英文键名（后端补标签前也不至于显示空白）。
 */
const recordViews = computed<MetaRecordView[]>(() => {
  const labels = meta.value?.fieldLabels || {};
  return metaRecords.value.map((rec, i) => {
    const values = rec.values || {};
    const allRows: MetaRowView[] = Object.entries(values)
      .filter(([key]) => !BBOX_KEY_SET.has(key))
      .map(([key, value]) => {
        const text = fmtValue(value);
        return { key, label: labels[key] || key, text, empty: text === '-', wide: text.length > 28 };
      });

    const byKey = new Map(allRows.map((r) => [r.key, r]));
    const core: MetaRowView[] = [];
    for (const k of CORE_FIELD_KEYS) {
      const row = byKey.get(k);
      if (row) {
        core.push(row);
        byKey.delete(k);
      }
    }
    const rest = allRows.filter((r) => byKey.has(r.key));

    return {
      key: `${rec.pgTable || rec.tableKey || 'record'}#${i}`,
      index: i,
      tableKey: rec.tableKey || '-',
      pgTable: rec.pgTable || '',
      sourceFile: rec.sourceFile,
      fieldCount: Object.keys(values).length,
      bbox: recordBbox(values),
      showBbox: true,
      core,
      rest
    };
  });
});

/** 字段筛选后的记录视图；无条件返回 recordViews 的深拷贝语义由 map 保证 */
const filteredRecordViews = computed<MetaRecordView[]>(() => {
  const kw = metaKeyword.value.trim().toLowerCase();
  if (!kw) return recordViews.value;
  const hit = (r: MetaRowView) => r.label.toLowerCase().includes(kw) || r.key.toLowerCase().includes(kw) || r.text.toLowerCase().includes(kw);
  return recordViews.value
    .map((rec) => {
      // 空间范围行的键是合成的（sw_lon/sw_lat/ne_*），按标签「空间范围」与 bbox 值本身参与匹配
      const bboxHit = pt('空间范围').includes(kw) || 'bbox'.includes(kw) || rec.bbox.toLowerCase().includes(kw);
      return { ...rec, core: rec.core.filter(hit), rest: rec.rest.filter(hit), showBbox: bboxHit };
    })
    .filter(
      (rec) =>
        rec.core.length > 0 ||
        rec.rest.length > 0 ||
        rec.showBbox ||
        rec.tableKey.toLowerCase().includes(kw) ||
        rec.pgTable.toLowerCase().includes(kw) ||
        (rec.sourceFile || '').toLowerCase().includes(kw)
    );
});

watch(recordViews, (list) => {
  activeMetaNames.value = list.length ? [list[0].key] : [];
});

// 筛选期间把命中的记录全部展开，清空筛选后回到「只开第一条」
watch(metaKeyword, (kw) => {
  if (kw.trim()) activeMetaNames.value = filteredRecordViews.value.map((r) => r.key);
  else activeMetaNames.value = recordViews.value.length ? [recordViews.value[0].key] : [];
});

/** 值格式化：后端 values 是混合类型（string / number / null），空值统一弱化为 '-' */
function fmtValue(v: unknown): string {
  if (v === null || v === undefined) return '-';
  if (typeof v === 'boolean') return v ? pt('是') : pt('否');
  const s = String(v).trim();
  return s === '' ? '-' : s;
}

/** 面包屑分段：空路径表示仓库根 */
const breadcrumbs = computed(() => {
  const segs = currentPath.value ? currentPath.value.split('/') : [];
  return [{ name: 'root', path: '' }, ...segs.map((s, i) => ({ name: s, path: segs.slice(0, i + 1).join('/') }))];
});

function tagType(v?: string) {
  return (stateTypes[v || ''] || 'info') as any;
}

function fmtTime(v?: string) {
  if (!v) return '-';
  const d = new Date(v.split(' ').join('T').split('+00').join('+00:00'));
  if (isNaN(d.getTime())) return v;
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

function fmtBytes(n?: number) {
  if (n == null) return '-';
  const u = ['B', 'KB', 'MB', 'GB'];
  let v = n;
  let i = 0;
  while (v >= 1024 && i < u.length - 1) {
    v /= 1024;
    i++;
  }
  return v.toFixed(2) + ' ' + u[i];
}

async function loadContents(path = '') {
  contentsLoading.value = true;
  try {
    const res: any = await listRepositoryContents(props.resourceUid, { path });
    const data = res?.data ?? {};
    contents.value = data.entries ?? [];
    currentPath.value = data.path ?? path;
  } catch {
    contents.value = [];
  } finally {
    contentsLoading.value = false;
  }
}

function enterDir(entry: RepositoryEntry) {
  if (!entry.isDir) return;
  const next = currentPath.value ? currentPath.value + '/' + entry.name : entry.name;
  loadContents(next);
}

function jumpTo(path: string) {
  loadContents(path);
}

async function onDownload(entry: RepositoryEntry) {
  // 优先按 artifactUid 打后端下载接口（鉴权头随 request 实例带出）
  const blob = await downloadArtifact(entry.artifactUid);
  saveAs(blob, entry.name);
}

async function onCopyPath(entry: RepositoryEntry) {
  const full = currentPath.value ? currentPath.value + '/' + entry.name : entry.name;
  // 优先 Clipboard API；无权限 / 非安全上下文时降级 execCommand（老 API 在这些环境可用）
  try {
    await navigator.clipboard.writeText(full);
    ElMessage.success('已复制路径：' + full);
    return;
  } catch {
    /* fallthrough */
  }
  try {
    const ta = document.createElement('textarea');
    ta.value = full;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand('copy');
    document.body.removeChild(ta);
    if (ok) {
      ElMessage.success('已复制路径：' + full);
      return;
    }
  } catch {
    /* fallthrough */
  }
  ElMessage.warning(pt('复制失败，请手动选择'));
}

async function loadAll() {
  loading.value = true;
  try {
    const [r, repo] = await Promise.all([getResource(props.resourceUid).catch(() => null), getRepository(props.resourceUid).catch(() => null)]);
    resource.value = r?.data ?? null;
    repository.value = repo?.data ?? null;
  } finally {
    loading.value = false;
  }
  await loadContents('');
}

onMounted(loadAll);

// 组件在同页复用时（切换左侧资源）不会重新挂载，必须跟随 resourceUid 变化重新加载
watch(
  () => props.resourceUid,
  (uid, old) => {
    if (uid && uid !== old) loadAll();
  }
);

// 弹窗底部只保留「取消」：详情页无提交动作
defineExpose({
  action: ([s]) => s
});
</script>

<template>
  <div class="detail-page" v-loading="loading">
    <div class="layout">
      <!-- ========== 主栏 ========== -->
      <div class="main-col">
        <!-- 文件列表（Contents） -->
        <section class="card card--files">
          <div class="card-head">
            <span class="card-title">{{ pt('文件列表') }}</span>
            <div class="card-head-right">
              <span v-if="contents.length" class="card-hint">{{ contents.length }} 项</span>
              <button class="icon-btn icon-btn--ghost" :title="pt('刷新')" @click="loadContents(currentPath)">
                <el-icon><Refresh /></el-icon>
              </button>
            </div>
          </div>

          <div class="path-bar">
            <template v-for="(b, i) in breadcrumbs" :key="b.path + i">
              <a class="crumb" :class="{ 'is-current': i === breadcrumbs.length - 1 }" @click="jumpTo(b.path)">{{ b.name }}</a>
              <span v-if="i < breadcrumbs.length - 1" class="crumb-sep">/</span>
            </template>
          </div>

          <div class="file-list" v-loading="contentsLoading">
            <div v-for="entry in contents" :key="entry.name" class="file-row" :class="{ 'is-dir': entry.isDir }">
              <button class="file-name" :class="{ 'is-clickable': entry.isDir }" :title="entry.name" @click="enterDir(entry)">
                <el-icon class="file-icon" :style="{ color: resolveFileIcon(entry).color }">
                  <component :is="resolveFileIcon(entry).icon" />
                </el-icon>
                <span class="name-text">{{ entry.name }}</span>
                <span v-if="entry.isDir && typeof entry.fileCount === 'number'" class="count">{{ entry.fileCount }} 项</span>
              </button>
              <div class="file-right">
                <span v-if="!entry.isDir" class="size">{{ fmtBytes(entry.sizeBytes) }}</span>
                <div class="file-actions">
                  <button v-if="!entry.isDir" class="icon-btn" title="下载" @click="onDownload(entry)">
                    <el-icon><Download /></el-icon>
                  </button>
                  <button class="icon-btn" title="复制路径" @click="onCopyPath(entry)">
                    <el-icon><CopyDocument /></el-icon>
                  </button>
                </div>
              </div>
            </div>
            <el-empty v-if="!contentsLoading && !contents.length" description="当前目录为空" :image-size="56" />
          </div>
        </section>

        <!-- 仓库概览（README 位）：描述 + 仓库事实 + 元数据记录小节，同一篇内容（source.coop 口径） -->
        <section class="card card--about" v-if="repository">
          <div class="card-head">
            <span class="card-title">仓库概览</span>
            <!-- 可见范围是契约真实字段，放头部比塞进正文更像个「属性」 -->
            <span v-if="visibilityLabel" class="card-hint">{{ visibilityLabel }}</span>
          </div>
          <div class="readme">
            <!-- 描述为空时不再整行「暂无仓库描述」占位：零信息的一行只会把下面的真内容往下推 -->
            <p v-if="repository.description" class="readme-text">{{ repository.description }}</p>

            <dl class="readme-kv">
              <div class="readme-row">
                <dt>类别</dt>
                <dd :class="{ 'is-empty': !categoryName }">
                  {{ categoryName || '-' }}
                </dd>
              </div>
              <div class="readme-row">
                <dt>最近入库批次</dt>
                <dd class="readme-batch" :class="{ 'is-empty': !repository.latestImport?.batchName }">
                  <span>{{ repository.latestImport?.batchName || '-' }}</span>
                  <ElTag v-if="repository.latestImport?.state" :type="tagType(repository.latestImport.state)" size="small" effect="light" round>{{
                    repository.latestImport.state
                  }}</ElTag>
                </dd>
              </div>
            </dl>

            <!-- 元数据记录（最新已入库）：概览正文的一节 -->
            <template v-if="meta">
              <div class="readme-section">
                <div class="readme-section-head">
                  <h3 class="readme-h3">
                    元数据记录
                    <small v-if="metaRecordTotal !== null" class="readme-sub">{{ metaRecordTotal }} 条</small>
                  </h3>
                  <!-- 42 字段 × N 条，没有筛选只能靠肉眼扫 -->
                  <el-input
                    v-if="meta.available && metaRecords.length > 1"
                    v-model="metaKeyword"
                    class="meta-search"
                    size="small"
                    clearable
                    placeholder="筛选字段"
                    :prefix-icon="Search"
                  />
                </div>

                <!-- available=false：后端给的是稳定 errorCode + 安全 errorMessage，直接展示，不猜原因 -->
                <p v-if="!meta.available" class="readme-text is-empty">{{ metaUnavailableText || '暂无可读的元数据表' }}</p>

                <template v-else-if="recordViews.length">
                  <!-- 默认只展开第一条：旧版 3 条 × 42 字段全铺开，滚动高 2637px、首屏全是元数据 -->
                  <el-collapse v-model="activeMetaNames" class="meta-collapse">
                    <el-collapse-item v-for="rec in filteredRecordViews" :key="rec.key" :name="rec.key">
                      <template #title>
                        <div class="meta-head">
                          <span class="meta-head-idx">#{{ rec.index + 1 }}</span>
                          <span class="meta-head-count">{{ rec.fieldCount }} 字段</span>
                        </div>
                      </template>

                      <!-- 核心字段：一句话说清「这是什么数据」的那些键，always 可见 -->
                      <div class="meta-grid">
                        <div v-for="row in rec.core" :key="row.key" class="meta-cell" :class="{ 'is-wide': row.wide }">
                          <span class="meta-k" :title="row.key">{{ row.label }}</span>
                          <span class="meta-v mono" :class="{ 'is-empty': row.empty }" :title="row.empty ? '' : row.text">{{ row.text }}</span>
                        </div>
                        <!-- 四角经纬度合成一行，省掉 8 个「右上角经度」格子 -->
                        <div v-if="rec.bbox && rec.showBbox" class="meta-cell">
                          <span class="meta-k" title="sw_lon, sw_lat, ne_lon, ne_lat">空间范围</span>
                          <span class="meta-v mono" :title="rec.bbox">{{ rec.bbox }}</span>
                        </div>
                      </div>

                      <!-- 其余字段：全部字段直接展示，不再折叠（用户 2026-11-18 口径） -->
                      <div v-if="rec.rest.length" class="meta-grid">
                        <div v-for="row in rec.rest" :key="row.key" class="meta-cell" :class="{ 'is-wide': row.wide }">
                          <span class="meta-k" :title="row.key">{{ row.label }}</span>
                          <span class="meta-v mono" :class="{ 'is-empty': row.empty }" :title="row.empty ? '' : row.text">{{ row.text }}</span>
                        </div>
                      </div>
                    </el-collapse-item>
                  </el-collapse>

                  <!-- 筛选无命中：说清楚是筛掉了，不是没数据 -->
                  <p v-if="!filteredRecordViews.length" class="readme-text is-empty">没有匹配「{{ metaKeyword }}」的字段</p>
                </template>

                <p v-else class="readme-text is-empty">该资源暂无已入库的元数据记录</p>
              </div>
            </template>
          </div>
        </section>
      </div>

      <!-- ========== 侧栏 ========== -->
      <aside class="side-col">
        <section class="card">
          <div class="card-head">
            <span class="card-title">详情</span>
          </div>
          <div class="kv-list">
            <div class="kv-group-title">基础</div>
            <div class="kv">
              <span class="kv-k">类别</span>
              <span class="kv-v" :class="{ 'is-empty': !categoryName }">{{ categoryName || '-' }}</span>
            </div>
            <div class="kv">
              <span class="kv-k">资源类型</span>
              <span class="kv-v">{{ typeLabel }}</span>
            </div>
            <div class="kv">
              <span class="kv-k">资源版本</span>
              <span class="kv-v">{{ resource?.version ?? '-' }}</span>
            </div>
            <div class="kv">
              <span class="kv-k">所有者</span>
              <span class="kv-v kv-v--strong" :class="{ 'is-empty': !(resource?.createdByRef || repository?.owner) }">
                {{ resource?.createdByRef || repository?.owner || '-' }}
              </span>
            </div>
            <div class="kv">
              <span class="kv-k">可见范围</span>
              <span class="kv-v" :class="{ 'is-empty': !visibilityLabel }">{{ visibilityLabel || '-' }}</span>
            </div>

            <div class="kv-group-title">状态</div>
            <div class="kv">
              <span class="kv-k">资源状态</span>
              <span class="kv-v">
                <ElTag v-if="resource?.state" :type="tagType(resource.state)" size="small" effect="light" round>{{ resource.state }}</ElTag>
                <template v-else>-</template>
              </span>
            </div>
            <div class="kv">
              <span class="kv-k">schema 状态</span>
              <span class="kv-v" :class="{ 'is-empty': !resource?.metadataSchemaState }">{{
                resource?.metadataSchemaState || resource?.schemaState || '-'
              }}</span>
            </div>
            <div class="kv">
              <span class="kv-k">模型绑定</span>
              <span class="kv-v" :class="{ 'is-empty': !bindingLabel }">{{ bindingLabel || '-' }}</span>
            </div>

            <div class="kv-group-title">时间</div>
            <div class="kv">
              <span class="kv-k">创建时间</span>
              <span class="kv-v" :class="{ 'is-empty': !resource?.createdAt }">{{ fmtTime(resource?.createdAt) }}</span>
            </div>
            <div class="kv">
              <span class="kv-k">更新时间</span>
              <span class="kv-v" :class="{ 'is-empty': !resource?.updatedAt }">{{ fmtTime(resource?.updatedAt) }}</span>
            </div>
          </div>
        </section>

        <section class="card">
          <div class="card-head">
            <span class="card-title">统计</span>
            <span class="card-hint">整个仓库</span>
          </div>
          <div class="stat-body">
            <div class="stat-grid">
              <div class="stat-box" title="整个仓库的文件总数；当前目录条数见上方文件列表">
                <span class="stat-k">文件数</span>
                <span class="stat-v">{{ fileTotal ?? '-' }}</span>
              </div>
              <div class="stat-box" :title="totalSizeText">
                <span class="stat-k">存储容量</span>
                <!-- 数值与单位分开排：整串「302.62 KB」在 88px 宽的格子里会折成两行 -->
                <span v-if="sizeParts" class="stat-v stat-v--size">
                  {{ sizeParts.num }}<span class="stat-unit">{{ sizeParts.unit }}</span>
                </span>
                <span v-else class="stat-v">-</span>
              </div>
              <div class="stat-box">
                <span class="stat-k">数据数</span>
                <span class="stat-v">{{ resource?.dataCount ?? '-' }}</span>
              </div>
              <div class="stat-box">
                <span class="stat-k">版本数</span>
                <span class="stat-v">{{ resource?.versionCount ?? '-' }}</span>
              </div>
            </div>
            <div class="kv-list kv-list--flat">
              <div class="kv">
                <span class="kv-k">元数据记录</span>
                <span class="kv-v" :class="{ 'is-empty': metaRecordTotal === null }">
                  {{ metaRecordTotal === null ? '-' : `${metaRecordTotal} 条` }}
                </span>
              </div>
              <div class="kv">
                <span class="kv-k">问题数</span>
                <span class="kv-v" :class="{ 'is-warn': (resource?.problemCount ?? 0) > 0 }">
                  {{ resource?.problemCount ?? '-' }}
                </span>
              </div>
            </div>
          </div>
        </section>
      </aside>
    </div>
  </div>
</template>

<style scoped lang="scss">
/* 滚动口径（用户 2026-11-11）：**整个内容块一条滚动轴**。
   主栏（文件列表 + 仓库概览含元数据记录）与侧栏一起往下滚，
   卡内一律不自建滚动条 —— 旧版是文件列表 / 概览各滚各的，滚轮落在哪条轴全看指针位置。 */
.detail-page {
  height: 100%;
  padding: 16px 20px;
  overflow-y: auto;
  overflow-x: hidden;
  box-sizing: border-box;
  font-size: 14px;
  color: var(--el-text-color-primary);
}

.layout {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 310px;
  gap: 24px;
  /* 外层已负责滚动，这里按内容自然高度铺开（不再 flex:1 压缩），整块一起滚 */
  align-items: start;
}

@media (max-width: 900px) {
  .layout {
    grid-template-columns: minmax(0, 1fr);
    grid-auto-rows: min-content;
  }
}

.main-col,
.side-col {
  display: flex;
  flex-direction: column;
  gap: 16px;
  min-width: 0;
  /* 不自建滚动条：随外层 .detail-page 一起滚 */
  overflow: visible;
  > .card {
    flex: 0 0 auto;
  }
}

/* 文件列表卡：自然高度 */
.card--files {
  display: flex;
  flex-direction: column;
}

/* 仓库概览卡（含元数据记录小节）：自然高度，不限高裁内容 */
.card--about {
  display: flex;
  flex-direction: column;
}

.mono {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
}

/* 标签跟随整体字号放大（ElTag small 默认 12px 显得过小） */
.kv :deep(.el-tag) {
  font-size: 12.5px;
  height: 22px;
}

/* ---- 卡片 ---- */
.card {
  background: var(--el-bg-color);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 6px;
  overflow: hidden;
}
.card-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 11px 16px;
  border-bottom: 1px solid var(--el-border-color-lighter);
}
.card-title {
  font-size: 14px;
  font-weight: 600;
  color: var(--el-text-color-primary);
}
.card-head-right {
  display: flex;
  align-items: center;
  gap: 8px;
}
.card-hint {
  font-size: 12.5px;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--el-text-color-placeholder);
}

/* 方形图标按钮：与图 1 一致（下载 / 复制 / 刷新） */
.icon-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 23px;
  height: 23px;
  padding: 0;
  font-size: 14px;
  color: var(--el-text-color-secondary);
  cursor: pointer;
  background: var(--el-fill-color-light);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 3px;
  transition:
    color 0.15s,
    border-color 0.15s,
    background-color 0.15s;
  &:hover {
    color: var(--el-color-primary);
    background: var(--el-fill-color);
    border-color: var(--el-color-primary-light-5);
  }
}
/* 卡片头部用无边框图标（图 1 的刷新按钮形态） */
.icon-btn--ghost {
  width: 21px;
  height: 21px;
  color: var(--el-text-color-secondary);
  background: none;
  border-color: transparent;
  &:hover {
    background: var(--el-fill-color);
    border-color: transparent;
  }
}

/* ---- 文件列表 ---- */
.path-bar {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 4px;
  padding: 9px 16px;
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 14px;
  color: var(--el-text-color-secondary);
  background: var(--el-fill-color-lighter);
  border-bottom: 1px solid var(--el-border-color-lighter);
}
.crumb {
  color: var(--el-color-primary);
  cursor: pointer;
  &:hover {
    text-decoration: underline;
  }
  &.is-current {
    color: var(--el-text-color-regular);
    cursor: default;
    text-decoration: none;
  }
}
.crumb-sep {
  color: var(--el-text-color-placeholder);
}

.file-list {
  /* 卡内不自建滚动条：内容多时随外层 .detail-page 统一滚 */
  min-height: 0;
}
.file-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  padding: 8px 12px 8px 16px;
  border-bottom: 1px solid var(--el-border-color-lighter);
  &:last-child {
    border-bottom: none;
  }
  &:hover {
    background: var(--el-fill-color-lighter);
  }
}

.file-name {
  display: flex;
  align-items: center;
  gap: 7px;
  flex: 1;
  min-width: 0;
  padding: 0;
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 14px;
  color: var(--el-text-color-primary);
  text-align: left;
  cursor: default;
  background: none;
  border: 0;
  &.is-clickable {
    color: var(--el-color-primary);
    cursor: pointer;
    &:hover .name-text {
      text-decoration: underline;
    }
  }
}
/* 类型图标：颜色由 resolveFileIcon 内联给出，这里只管尺寸与对齐 */
.file-icon {
  flex-shrink: 0;
  font-size: 16px;
  line-height: 1;
}
.name-text {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  text-decoration: none;
}
.count {
  flex-shrink: 0;
  font-family: inherit;
  font-size: 12.5px;
  color: var(--el-text-color-placeholder);
}

.file-right {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-shrink: 0;
}
.size {
  min-width: 70px;
  font-size: 13.5px;
  color: var(--el-text-color-secondary);
  text-align: right;
  font-variant-numeric: tabular-nums;
}
.file-actions {
  display: flex;
  gap: 4px;
}

/* ---- 仓库概览 ---- */
.readme {
  /* 内容长时随外层 .detail-page 统一滚，卡内不自建滚动条 */
  padding: 14px 16px 16px;
}
.readme-text {
  margin: 0 0 14px;
  font-size: 14px;
  line-height: 1.75;
  color: var(--el-text-color-regular);
  word-break: break-word;
}
.readme-kv {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0;
}
.readme-row {
  display: flex;
  gap: 12px;
  font-size: 14px;
  dt {
    flex: 0 0 100px;
    color: var(--el-text-color-secondary);
  }
  dd {
    flex: 1;
    min-width: 0;
    margin: 0;
    color: var(--el-text-color-primary);
    word-break: break-all;
  }
}
/* 批次名 + 状态同排：拆两行时「批次状态」只剩一个词，读不出属于谁 */
.readme-batch {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}

/* ---- 元数据记录（仓库概览卡内的一节，source.coop README 表格位） ---- */
.readme-section {
  margin-top: 18px;
  padding-top: 14px;
  border-top: 1px solid var(--el-border-color-lighter);
}
/* 标题与筛选框同排：筛选必须贴着它筛的那批字段 */
.readme-section-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 10px;
}
.readme-h3 {
  display: flex;
  align-items: baseline;
  flex-wrap: wrap;
  gap: 8px;
  margin: 0;
  font-size: 15px;
  font-weight: 600;
  color: var(--el-text-color-primary);
}
.readme-sub {
  color: var(--el-text-color-placeholder);
  font-size: 12px;
  font-weight: 400;
}
.meta-search {
  flex: 0 0 180px;
}

/* 折叠面板：去掉 EP 默认的粗边框与整块底色，融进概览正文 */
.meta-collapse {
  border-top: none;
  border-bottom: none;
  :deep(.el-collapse-item__header) {
    height: auto;
    min-height: 34px;
    padding: 4px 0;
    line-height: 1.4;
    border-bottom: 1px solid var(--el-border-color-lighter);
  }
  :deep(.el-collapse-item__wrap) {
    border-bottom: none;
  }
  :deep(.el-collapse-item__content) {
    padding: 8px 0 14px;
  }
}

/* 记录头：表键 / 物理表 / 来源文件 / 字段数，一条记录一行说清 */
.meta-head {
  display: flex;
  align-items: baseline;
  gap: 8px;
  width: 100%;
  min-width: 0;
  font-size: 13px;
}
.meta-head-idx {
  flex: none;
  color: var(--el-text-color-placeholder);
  font-variant-numeric: tabular-nums;
}
.meta-head-count {
  flex: none;
  margin-left: auto;
  padding-right: 8px;
  color: var(--el-text-color-placeholder);
  font-size: 12px;
}

/* 字段两列铺：窄屏单列；长值（坐标系、空间范围）跨整行，避免被挤成竖条 */
.meta-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 6px 18px;
}
@media (max-width: 1100px) {
  .meta-grid {
    grid-template-columns: minmax(0, 1fr);
  }
}
.meta-cell {
  display: flex;
  align-items: baseline;
  gap: 10px;
  padding: 3px 0;
  font-size: 13px;
  &.is-wide {
    grid-column: 1 / -1;
  }
}
.meta-k {
  flex: 0 0 148px;
  overflow: hidden;
  color: var(--el-text-color-secondary);
  text-overflow: ellipsis;
  white-space: nowrap;
}
.meta-v {
  flex: 1;
  min-width: 0;
  overflow-wrap: anywhere;
  word-break: break-all;
}

/* ---- 侧栏键值 ---- */
.kv-list {
  display: flex;
  flex-direction: column;
  padding: 6px 16px 10px;
}
.kv-list--flat {
  padding: 8px 0 0;
  border-top: 1px solid var(--el-border-color-lighter);
}
/* 分组小标题：把 10 行 kv 切成「基础 / 状态 / 时间」三段，否则关键状态混在时间里 */
.kv-group-title {
  padding: 10px 0 2px;
  font-size: 11.5px;
  letter-spacing: 0.06em;
  color: var(--el-text-color-placeholder);
  &:first-child {
    padding-top: 2px;
  }
}
.kv {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: 14px;
  padding: 7px 0;
  font-size: 14px;
  line-height: 1.5;
}
.kv-k {
  flex-shrink: 0;
  color: var(--el-text-color-secondary);
}
.kv-v {
  min-width: 0;
  color: var(--el-text-color-primary);
  text-align: right;
  word-break: break-word;
  &.kv-v--strong {
    font-weight: 500;
  }
  /* 问题数 > 0 才强调；0 和缺值都保持中性 */
  &.is-warn {
    font-weight: 600;
    color: var(--el-color-danger);
  }
}

.stat-body {
  padding: 12px 16px 14px;
}
.stat-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 8px;
}
.stat-box {
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
  padding: 9px 10px;
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 4px;
}
.stat-k {
  font-size: 12.5px;
  /* 中文标签套 uppercase + 字距毫无作用，只留字距做弱化 */
  letter-spacing: 0.04em;
  color: var(--el-text-color-secondary);
}
.stat-v {
  font-size: 19px;
  font-weight: 600;
  line-height: 1.2;
  color: var(--el-text-color-primary);
  font-variant-numeric: tabular-nums;
}
/* 容量值：数值与单位同基线，单位降一档字号，避免「302.62 KB」在 88px 格内折行 */
.stat-v--size {
  display: flex;
  align-items: baseline;
  gap: 3px;
  white-space: nowrap;
}
.stat-unit {
  font-size: 12.5px;
  font-weight: 500;
  color: var(--el-text-color-secondary);
}

/* 空值统一弱化 */
.is-empty {
  color: var(--el-text-color-placeholder);
}
</style>
