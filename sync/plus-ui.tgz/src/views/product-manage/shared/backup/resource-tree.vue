<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
/**
 * 备份页左侧资源目录树
 *
 * 数据源复用「元数据浏览树」接口（GET /platform/metadata/tree，docId 529576518），
 * 与数据浏览页同一份树，不另造接口。节点语义：产品类别 → 任务（资源）。
 *
 * ⚠️ 契约口径：元数据库备份是**整库级**操作（backup/runs、backup/backups 均无 resourceUid 入参），
 * 本树只用于展示「纳入备份范围的资源目录」，点节点不做备份过滤。
 * 父组件拿到选中节点后，在详情 tab 里提示该资源是否出现在备份表清单中。
 */
import { computed, onMounted, ref } from 'vue';
import { Document, FolderOpened } from '@element-plus/icons-vue';
import { getMetadataBrowseTree, type MetadataTreeNode } from '@/api/product-manage/platform/metadata-browse';

const emit = defineEmits<{
  (e: 'select', node: MetadataTreeNode | null): void;
}>();

const loading = ref(false);
const keyword = ref('');
const treeData = ref<MetadataTreeNode[]>([]);
const treeRef = ref();

/** 关键字过滤：保留命中节点及其祖先链（保留层级，避免把资源拍平成孤儿） */
const filteredData = computed<MetadataTreeNode[]>(() => {
  const kw = keyword.value.trim().toLowerCase();
  if (!kw) return treeData.value;
  const walk = (nodes: MetadataTreeNode[]): MetadataTreeNode[] =>
    nodes.reduce<MetadataTreeNode[]>((acc, node) => {
      const children = walk(node.children ?? []);
      const hit = (node.displayName ?? '').toLowerCase().includes(kw) || (node.categoryName ?? '').toLowerCase().includes(kw);
      if (hit || children.length) acc.push({ ...node, children });
      return acc;
    }, []);
  return walk(treeData.value);
});

async function load() {
  loading.value = true;
  try {
    const res = await getMetadataBrowseTree();
    treeData.value = (res?.data?.items ?? []) as MetadataTreeNode[];
  } catch {
    // 拦截器已 toast；树为空即可，不向 onMounted 抛未捕获 rejection
    treeData.value = [];
  } finally {
    loading.value = false;
  }
}

function onNodeClick(data: MetadataTreeNode) {
  emit('select', data);
}

function clearSelection() {
  treeRef.value?.setCurrentKey?.(null);
  emit('select', null);
}

function nodeLabel(node: MetadataTreeNode): string {
  return node.displayName || node.categoryName || node.uid;
}

onMounted(load);
defineExpose({ load, clearSelection });
</script>

<template>
  <div class="res-tree">
    <div class="res-tree__head">
      <span class="res-tree__title">{{ pt('资源目录') }}</span>
      <el-button link type="primary" size="small" @click="clearSelection">{{ pt('清除选择') }}</el-button>
    </div>
    <el-input v-model="keyword" size="small" :placeholder="pt('筛选类别 / 资源')" clearable class="res-tree__filter" />
    <el-alert
      type="info"
      :closable="false"
      show-icon
      class="res-tree__tip"
      :title="pt('备份为元数据库整库级操作，不按资源过滤；此处展示纳入备份范围的资源目录。')"
    />
    <el-tree
      ref="treeRef"
      v-loading="loading"
      class="res-tree__tree"
      :data="filteredData"
      node-key="uid"
      :props="{ label: nodeLabel, children: 'children' }"
      :expand-on-click-node="false"
      highlight-current
      default-expand-all
      empty-text="暂无资源目录"
      @node-click="onNodeClick"
    >
      <template #default="{ data }">
        <span class="res-tree__node">
          <el-icon>
            <FolderOpened v-if="data.nodeType === 'category'" />
            <Document v-else />
          </el-icon>
          <span class="res-tree__label" :title="nodeLabel(data)">{{ nodeLabel(data) }}</span>
          <span v-if="data.nodeType === 'category' && data.resourceCount" class="res-tree__count">{{ data.resourceCount }}</span>
          <el-tag v-else-if="data.nodeType === 'resource' && data.dataType" size="small" type="info">{{ data.dataType }}</el-tag>
        </span>
      </template>
    </el-tree>
  </div>
</template>

<style scoped lang="scss">
.res-tree {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
  padding: 12px;
  background: var(--el-bg-color);
  border: 1px solid #eef1f6;
}

.res-tree__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 8px;
}

.res-tree__title {
  color: #243752;
  font-weight: 600;
}

.res-tree__filter {
  margin-bottom: 8px;
}

.res-tree__tip {
  margin-bottom: 8px;
  padding: 6px 8px;

  :deep(.el-alert__title) {
    font-size: 11px;
    line-height: 1.5;
  }
}

.res-tree__tree {
  flex: 1;
  min-height: 0;
  overflow: auto;
}

.res-tree__node {
  display: flex;
  align-items: center;
  gap: 5px;
  width: 100%;
  min-width: 0;

  .el-icon {
    flex-shrink: 0;
    color: #8695a8;
  }
}

.res-tree__label {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.res-tree__count {
  flex-shrink: 0;
  color: #8695a8;
  font-size: 12px;
}
</style>
