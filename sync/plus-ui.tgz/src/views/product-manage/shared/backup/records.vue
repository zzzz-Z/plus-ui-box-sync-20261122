<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
import { Delete, Download, Edit, Refresh } from '@element-plus/icons-vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import RestoreWizard from './restore-wizard.vue';
import type { BackupRecord } from './state.js';
import {
  applyAutoDelete,
  backups,
  createBackup,
  getBackups,
  MODE_TAG,
  policy,
  prepareRestore,
  queryParams,
  refreshToken,
  removeBackupData,
  renameBackupData,
  STATUS_MAP
} from './state.js';

const tableRef = ref();

// state 中的 mutation 通过 refreshToken 通知表格重取数据
watch(refreshToken, () => tableRef.value?.getData?.());

async function onBackupNow() {
  const item = await createBackup();
  ElMessage.success(`备份完成：${item.name}`);
}

function onOpenRestore(record?: BackupRecord) {
  const { error } = prepareRestore(record);
  if (error) {
    ElMessage.warning(error);
    return;
  }
  createDialog({
    title: pt('备份恢复向导'),
    width: '680px',
    closeOnClickModal: false,
    render: () => <RestoreWizard />
  });
}

function onClearExpired() {
  if (!policy.autoDelete) {
    ElMessage.warning(pt('当前策略未启用自动删除，请先在策略面板中开启'));
    return;
  }
  const removed = applyAutoDelete();
  if (removed.length > 0) ElMessage.success(`已清理 ${removed.length} 份超期备份`);
  else ElMessage.info(`当前备份数量（${backups.value.length}）未超过保留份数（${policy.keep}），无需清理`);
}

function onRename(record: BackupRecord) {
  ElMessageBox.prompt(pt('请输入新的备份名称'), pt('重命名备份'), {
    inputValue: record.name,
    inputPattern: /\S+/,
    inputErrorMessage: pt('名称不能为空')
  })
    .then(({ value }) => {
      renameBackupData(record, value.trim());
      ElMessage.success(pt('备份已重命名'));
    })
    .catch(() => {});
}

function onDelete(record: BackupRecord) {
  ElMessageBox.confirm(`确认删除备份「${record.name}」？该操作不可恢复。`, pt('删除备份'), { type: 'warning' })
    .then(() => {
      removeBackupData(record);
      ElMessage.success(pt('备份已删除'));
    })
    .catch(() => {});
}

const columns: TableColumn<BackupRecord>[] = [
  { label: pt('备份名称'), prop: 'name', minWidth: 220, showOverflowTooltip: true },
  {
    label: pt('方式'),
    width: 90,
    render: ({ row }) => (
      <el-tag type={MODE_TAG[row.mode]} size="small">
        {row.mode}
      </el-tag>
    )
  },
  { label: pt('类型'), prop: 'kind', width: 80 },
  { label: pt('大小'), prop: 'size', width: 100 },
  { label: pt('备份时间'), prop: 'createdAt', width: 170 },
  { label: pt('耗时'), prop: 'duration', width: 90 },
  {
    label: pt('状态'),
    width: 100,
    render: ({ row }) => (
      <el-tag type={STATUS_MAP[row.status].type} size="small">
        {STATUS_MAP[row.status].label}
      </el-tag>
    )
  },
  {
    action: true,
    label: pt('操作'),
    fixed: 'right',
    render: ({ row }) => (
      <div class="row-actions">
        <el-button link type="primary" icon={Refresh} v-tooltip={'恢复'} disabled={row.status !== 'completed'} onClick={() => onOpenRestore(row)} />
        <el-button link type="primary" icon={Edit} v-tooltip={'重命名'} onClick={() => onRename(row)} />
        <el-button link type="danger" icon={Delete} v-tooltip={'删除'} onClick={() => onDelete(row)} />
      </div>
    )
  }
];
</script>

<template>
  <Table ref="tableRef" :columns="columns" :request="getBackups" :query-params="queryParams">
    <template #search>
      <el-input v-model="queryParams.keyword" :label="pt('备份名称')" :placeholder="pt('请输入备份名称')" clearable />
      <el-select
        v-model="queryParams.mode"
        :label="pt('存储方式')"
        :placeholder="pt('全部方式')"
        clearable
        :options="(['本地', '异地', '离线'] as const).map(mode => ({ label: mode, value: mode }))"
      />
      <el-select
        v-model="queryParams.status"
        :label="pt('状态')"
        :placeholder="pt('全部状态')"
        clearable
        :options="[
          { label: '已完成', value: 'completed' },
          { label: '备份中', value: 'running' },
          { label: '失败', value: 'failed' }
        ]"
      />
      <el-date-picker
        v-model="queryParams.dateRange"
        type="date"
        :label="pt('备份时间')"
        start-placeholder="开始日期"
        end-placeholder="结束日期"
        value-format="YYYY-MM-DD"
        unlink-panels
      />
    </template>
    <template #action>
      <el-button type="primary" :icon="Refresh" @click="onBackupNow"> 立即备份 </el-button>
      <el-button :icon="Download" @click="onOpenRestore()"> 恢复向导 </el-button>
      <el-button :icon="Delete" @click="onClearExpired"> 清理超期备份 </el-button>
    </template>
  </Table>
</template>

<style scoped lang="scss">
/* .row-actions 只用在 columns 的 JSX render 里（不在 <template> 中）。
   formatter 由 ElTable 在其自身渲染上下文执行，vnode 带的是 ElTable 的 scopeId，
   不是本组件的，所以 `scoped` 编出的 `.row-actions[data-v-xxx]` 匹配不到，样式静默失效。
   改用 :deep() 后编译成 `[data-v-xxx] .row-actions`，由根节点上的本组件 scope 锚定。 */
:deep(.row-actions) {
  white-space: nowrap;
}
</style>
