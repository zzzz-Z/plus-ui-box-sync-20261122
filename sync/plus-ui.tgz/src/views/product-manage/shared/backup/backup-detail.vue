<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
/**
 * 备份详情 tab（契约：docId 532352879 详情 / 532352934 演练）
 *
 * 选中列表某行后展示：基本信息、包含表清单（契约 tables[] item properties 为空，
 * 故用表格通用渲染）、完整性校验结果（verification），以及只读的演练核验。
 *
 * ⚠️ 契约未给出 resourceUid 维度，故“该备份包含哪些资源”无法从接口得知；
 * 左树选中的资源仅在提示条里做说明，不伪造关联数据。
 */
import { computed, onMounted, ref, watch } from 'vue';
import { ElMessage } from 'element-plus';
import { drillBackup, getBackupDetail } from '@/api/product-manage/platform/backup';
import type { BackupDetail, BackupDrillResult } from '@/api/product-manage/types/platform';
import type { MetadataTreeNode } from '@/api/product-manage/platform/metadata-browse';

const props = defineProps<{
  backupUid: string | null;
  selectedResource?: MetadataTreeNode | null;
}>();

const loading = ref(false);
const detail = ref<BackupDetail | null>(null);
const drillResult = ref<BackupDrillResult | null>(null);
const drilling = ref(false);

const modeLabel = computed(() => (detail.value?.mode === 'full' ? pt('完整备份') : detail.value?.mode === 'incremental' ? pt('增量备份') : '—'));

const selectedResourceLabel = computed(() => {
  const n = props.selectedResource;
  if (!n) return '';
  return n.displayName || n.categoryName || n.uid;
});

async function load() {
  if (!props.backupUid) {
    detail.value = null;
    drillResult.value = null;
    return;
  }
  loading.value = true;
  try {
    const res = await getBackupDetail(props.backupUid);
    detail.value = res?.data ?? null;
    drillResult.value = null;
  } catch {
    // 拦截器已 toast（如 404 / 413）；保留空态，不向 onMounted 抛未捕获 rejection
    detail.value = null;
  } finally {
    loading.value = false;
  }
}

async function onDrill() {
  if (!props.backupUid) return;
  drilling.value = true;
  try {
    const res = await drillBackup(props.backupUid);
    drillResult.value = res?.data ?? null;
    ElMessage.success(pt('演练核验完成'));
  } catch {
    /* 拦截器已 toast */
  } finally {
    drilling.value = false;
  }
}

function formatRows(rows?: number): string {
  return rows === undefined ? '—' : rows.toLocaleString('zh-CN');
}

function formatBytes(bytes?: number): string {
  if (!bytes && bytes !== 0) return '—';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

/** tables[] 契约 item properties 为空：动态把每行对象渲染成 key:value 表 */
const tableRows = computed(() => {
  const tables = detail.value?.tables ?? [];
  if (!tables.length) return [];
  const keys = Array.from(new Set(tables.flatMap((t) => Object.keys(t))));
  return { keys, rows: tables };
});

watch(() => props.backupUid, load);
onMounted(load);
</script>

<template>
  <div v-loading="loading" class="backup-detail">
    <el-empty v-if="!backupUid" :description="pt('请在「备份列表」中选择一份备份查看详情')" />

    <template v-else-if="detail">
      <div class="backup-detail__hero">
        <div>
          <div class="backup-detail__title">{{ detail.name }}</div>
          <div class="backup-detail__sub">
            <el-tag size="small" :type="detail.mode === 'full' ? 'primary' : 'success'">{{ modeLabel }}</el-tag>
            <span>备份 UID：{{ detail.backupUid }}</span>
          </div>
        </div>
        <el-button :loading="drilling" @click="onDrill"> {{ pt('演练核验') }} </el-button>
      </div>

      <el-alert
        v-if="selectedResourceLabel"
        type="info"
        :closable="false"
        show-icon
        class="backup-detail__scope"
        :title="`当前资源目录选中：${selectedResourceLabel}。备份为元数据库整库级操作，详情中的表清单不受该选择过滤。`"
      />

      <el-descriptions :column="2" border size="small" class="backup-detail__desc">
        <el-descriptions-item :label="pt('备份名称')">{{ detail.name }}</el-descriptions-item>
        <el-descriptions-item :label="pt('备份模式')">{{ modeLabel }}</el-descriptions-item>
        <el-descriptions-item :label="pt('创建时间')">{{ detail.createdAt }}</el-descriptions-item>
        <el-descriptions-item :label="pt('包含表数')">{{ detail.tables?.length ?? 0 }}</el-descriptions-item>
        <el-descriptions-item :label="pt('完整性校验')">
          <el-tag size="small" :type="detail.verification?.verified ? 'success' : 'warning'">
            {{ detail.verification?.verified ? '已通过' : '未通过 / 未校验' }}
          </el-tag>
          <span v-if="detail.verification?.errorCode" class="backup-detail__error"> 错误码：{{ detail.verification.errorCode }}</span>
        </el-descriptions-item>
      </el-descriptions>

      <div class="backup-detail__section-title">{{ pt('包含表清单') }}</div>
      <el-table v-if="tableRows.keys.length" :data="tableRows.rows" size="small" border max-height="240">
        <el-table-column v-for="key in tableRows.keys" :key="key" :label="key" :prop="key" show-overflow-tooltip />
      </el-table>
      <el-empty v-else :description="pt('该备份未返回表清单')" :image-size="60" />

      <template v-if="drillResult">
        <div class="backup-detail__section-title">{{ pt('演练核验结果') }}</div>
        <el-descriptions :column="3" border size="small">
          <el-descriptions-item :label="pt('核验结论')">
            <el-tag size="small" :type="drillResult.verified ? 'success' : 'danger'">{{ drillResult.verified ? '通过' : '未通过' }}</el-tag>
          </el-descriptions-item>
          <el-descriptions-item :label="pt('总行数')">{{ formatRows(drillResult.totalRows) }}</el-descriptions-item>
          <el-descriptions-item :label="pt('表数')">{{ formatRows(drillResult.tableCount) }}</el-descriptions-item>
          <el-descriptions-item :label="pt('文件大小')">{{ formatBytes(drillResult.fileBytes) }}</el-descriptions-item>
          <el-descriptions-item :label="pt('错误码')">{{ drillResult.errorCode || '—' }}</el-descriptions-item>
          <el-descriptions-item :label="pt('说明')" :span="2">{{ drillResult.note || '—' }}</el-descriptions-item>
        </el-descriptions>
        <el-table :data="drillResult.checks ?? []" size="small" border class="backup-detail__checks">
          <el-table-column :label="pt('检查项')" prop="name" />
          <el-table-column :label="pt('结果')" width="100">
            <template #default="{ row }">
              <el-tag size="small" :type="row.passed ? 'success' : 'danger'">{{ row.passed ? '通过' : '失败' }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column label="详情" prop="detail" show-overflow-tooltip />
        </el-table>
      </template>
    </template>
  </div>
</template>

<style scoped lang="scss">
.backup-detail {
  height: 100%;
  min-height: 0;
  overflow: auto;
  padding: 14px 16px;
}

.backup-detail__hero {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
}

.backup-detail__title {
  color: #243752;
  font-size: 16px;
  font-weight: 600;
}

.backup-detail__sub {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 4px;
  color: #8695a8;
  font-size: 12px;
}

.backup-detail__scope {
  margin-bottom: 12px;
}

.backup-detail__desc {
  margin-bottom: 16px;
}

.backup-detail__error {
  margin-left: 6px;
  color: #f56c6c;
}

.backup-detail__section-title {
  margin: 14px 0 8px;
  color: #243752;
  font-weight: 600;
}

.backup-detail__checks {
  margin-top: 10px;
}
</style>
