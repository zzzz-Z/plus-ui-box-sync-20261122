<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
/**
 * 恢复向导（契约：docId 532352935 预览 / 936 确认 / 937 执行）
 *
 * 严格按令牌链：preview(backupUid) → planToken → confirm(planToken) → confirmationToken
 *   → apply({ confirmationToken, confirm: true, dryRun? })。
 *
 * ⚠️ 两个令牌有效期均约 120 秒，且 **dryRun 也消耗 confirmationToken**：
 *   一次确认令牌只能 apply 一次。故“演练”与“真实恢复”二选一，选完直接执行，
 *   若要切换必须从头 preview。此约束在 UI 上明确提示。
 * ⚠️ 策略 allowRestore=false 时 apply 会被后端以 503 RESTORE_DISABLED_BY_POLICY 拒绝。
 */
import type { VNode } from 'vue';
import { ElButton, ElMessage } from 'element-plus';
import { applyRestore, confirmRestore, previewRestore } from '@/api/product-manage/platform/backup';
import type { BackupRestoreApplyResult, BackupRestorePreview } from '@/api/product-manage/types/platform';

const props = defineProps<{
  backupUid: string;
  backupName?: string;
}>();

const step = ref(0);
const running = ref(false);
const previewData = ref<BackupRestorePreview | null>(null);
const confirmationToken = ref('');
/** 演练 or 真实恢复，二选一 */
const dryRun = ref(false);
const result = ref<BackupRestoreApplyResult | null>(null);

async function doPreview() {
  running.value = true;
  try {
    const res = await previewRestore(props.backupUid);
    previewData.value = res?.data ?? null;
    step.value = 1;
  } catch {
    /* 拦截器已 toast（如 503 RESTORE_DISABLED_BY_POLICY）；停留在当前步骤 */
  } finally {
    running.value = false;
  }
}

async function doConfirm() {
  if (!previewData.value?.planToken) return;
  running.value = true;
  try {
    const res = await confirmRestore(previewData.value.planToken);
    confirmationToken.value = res?.data?.confirmationToken ?? '';
    step.value = 2;
  } catch {
    /* 拦截器已 toast；保留计划，允许重试确认 */
  } finally {
    running.value = false;
  }
}

async function doApply() {
  if (!confirmationToken.value) return;
  running.value = true;
  try {
    const res = await applyRestore({ confirmationToken: confirmationToken.value, confirm: true, dryRun: dryRun.value });
    result.value = res?.data ?? null;
    step.value = 3;
    ElMessage.success(dryRun.value ? pt('演练执行完成（未写入数据）') : pt('恢复执行完成'));
  } catch {
    /* 拦截器已 toast（如 503 RESTORE_DISABLED_BY_POLICY）；停留在确认步骤 */
  } finally {
    running.value = false;
  }
}

function fmtRows(n?: number) {
  return n === undefined ? '—' : n.toLocaleString('zh-CN');
}

/**
 * 供 createDialog 调用的自定义 footer：按当前步骤切换按钮。
 * step 0 选择备份 / 1 预览计划 / 2 确认执行 / 3 完成
 */
function action(_baseFooter: VNode[], close: () => void) {
  return () => {
    const buttons: VNode[] = [];
    if (step.value === 0) {
      buttons.push(
        <ElButton type="primary" loading={running.value} onClick={doPreview}>
          下一步：预览计划
        </ElButton>
      );
      buttons.push(
        <ElButton disabled={running.value} onClick={close}>
          取消
        </ElButton>
      );
    } else if (step.value === 1) {
      buttons.push(
        <ElButton type="primary" loading={running.value} onClick={doConfirm}>
          下一步：确认计划
        </ElButton>
      );
      buttons.push(
        <ElButton disabled={running.value} onClick={close}>
          取消
        </ElButton>
      );
    } else if (step.value === 2) {
      buttons.push(
        <ElButton type={dryRun.value ? 'default' : 'danger'} loading={running.value} onClick={doApply}>
          {dryRun.value ? pt('执行演练') : pt('执行真实恢复')}
        </ElButton>
      );
      buttons.push(
        <ElButton disabled={running.value} onClick={close}>
          取消
        </ElButton>
      );
    } else {
      buttons.push(
        <ElButton type="primary" onClick={close}>
          完成
        </ElButton>
      );
    }
    return buttons;
  };
}

defineExpose({ action });
</script>

<template>
  <div class="restore-wizard">
    <el-steps :active="step" finish-status="success" align-center class="restore-steps">
      <el-step :title="pt('选择备份')" :description="pt('确认恢复源')" />
      <el-step :title="pt('预览计划')" :description="pt('核对影响面')" />
      <el-step :title="pt('确认执行')" :description="pt('令牌确认')" />
      <el-step :title="pt('完成')" :description="pt('执行结果')" />
    </el-steps>

    <div class="restore-body">
      <template v-if="step === 0">
        <el-descriptions :column="1" border size="small">
          <el-descriptions-item :label="pt('备份名称')">{{ backupName || backupUid }}</el-descriptions-item>
          <el-descriptions-item :label="pt('备份 UID')">{{ backupUid }}</el-descriptions-item>
        </el-descriptions>
        <el-alert
          type="info"
          :closable="false"
          show-icon
          class="restore-tip"
          :title="pt('恢复将按备份计划受控执行；下一步按契约预览计划，可核对警告与操作建议后再确认。')"
        />
      </template>

      <template v-else-if="step === 1">
        <template v-if="previewData">
          <el-descriptions :column="2" border size="small">
            <el-descriptions-item label="备份名称">{{ previewData.plan?.name }}</el-descriptions-item>
            <el-descriptions-item label="模式">{{ previewData.plan?.mode }}</el-descriptions-item>
            <el-descriptions-item label="数据库">{{ previewData.plan?.database }}</el-descriptions-item>
            <el-descriptions-item label="表数">{{ fmtRows(previewData.plan?.tableCount) }}</el-descriptions-item>
            <el-descriptions-item label="行数">{{ fmtRows(previewData.plan?.totalRows) }}</el-descriptions-item>
            <el-descriptions-item label="基础备份">{{ previewData.plan?.baseBackupUid || '—' }}</el-descriptions-item>
            <el-descriptions-item label="创建时间">{{ previewData.plan?.createdAt }}</el-descriptions-item>
            <el-descriptions-item label="计划摘要">{{ previewData.planDigest }}</el-descriptions-item>
          </el-descriptions>
          <el-alert
            v-if="previewData.plan?.warnings?.length"
            type="warning"
            :closable="false"
            show-icon
            class="restore-tip"
            :title="`警告：${previewData.plan.warnings.join('；')}`"
          />
          <el-alert
            v-if="previewData.plan?.guidance?.length"
            type="info"
            :closable="false"
            show-icon
            class="restore-tip"
            :title="`建议：${previewData.plan.guidance.join('；')}`"
          />
          <div class="restore-hint">计划令牌有效期约 {{ previewData.expiresInSeconds || 120 }} 秒，请在有效期内确认。</div>
        </template>
        <el-empty v-else description="预览计划为空" :image-size="60" />
      </template>

      <template v-else-if="step === 2">
        <el-alert
          type="warning"
          :closable="false"
          show-icon
          class="restore-tip"
          title="确认令牌已获取。演练与真实恢复二选一，且都会消耗令牌；如需切换必须重新预览。请谨慎选择。"
        />
        <el-radio-group v-model="dryRun" class="restore-mode">
          <el-radio :value="false" border>真实恢复（写入元数据库）</el-radio>
          <el-radio :value="true" border>仅演练（dry-run，不写入）</el-radio>
        </el-radio-group>
        <div class="restore-hint">若策略未开启 allowRestore，真实恢复会被后端以 503 拒绝。</div>
      </template>

      <template v-else>
        <el-result
          :icon="result?.state === 'rolled-back' ? 'warning' : 'success'"
          :title="result?.state === 'dry-run' ? '演练完成' : result?.state === 'committed' ? '恢复完成' : '执行结果'"
          :sub-title="result?.note || ''"
        >
          <template #extra>
            <div v-if="result" class="restore-result-grid">
              <span>状态：{{ result.state }}</span>
              <span>总行数：{{ fmtRows(result.totalRows) }}</span>
              <span>表数：{{ fmtRows(result.tableCount) }}</span>
              <span>备份：{{ result.name || result.backupUid }}</span>
              <span>计划摘要：{{ result.planDigest }}</span>
            </div>
          </template>
        </el-result>
        <el-table v-if="result?.tables?.length" :data="result.tables" size="small" border max-height="220" class="restore-result-table">
          <el-table-column label="Schema" prop="schema" />
          <el-table-column label="表" prop="table" />
          <el-table-column label="删除行" prop="rowsDeleted" />
          <el-table-column label="插入行" prop="rowsInserted" />
          <el-table-column label="预期行" prop="expectedRows" />
        </el-table>
      </template>
    </div>
  </div>
</template>

<style scoped lang="scss">
.restore-steps {
  margin-bottom: 16px;
}

.restore-body {
  min-height: 220px;
}

.restore-tip {
  margin-top: 12px;
}

.restore-mode {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin: 14px 0;
}

.restore-hint {
  margin-top: 10px;
  color: #8695a8;
  font-size: 12px;
  line-height: 1.6;
}

.restore-result-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 8px 18px;
  color: #4b5b70;
  font-size: 13px;
}

.restore-result-table {
  margin-top: 12px;
}
</style>
