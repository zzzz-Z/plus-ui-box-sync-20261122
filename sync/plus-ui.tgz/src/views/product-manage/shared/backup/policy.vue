<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
import { Setting } from '@element-plus/icons-vue';
import { ElMessage } from 'element-plus';
import { policy, savePolicy } from './state';

function onSave() {
  const error = savePolicy();
  if (error) {
    ElMessage.warning(error);
    return;
  }
  ElMessage.success(`备份策略已保存：下次将于 ${policy.schedule} ${policy.time} 自动执行${policy.mode}${policy.kind}备份`);
}
</script>

<template>
  <div class="backup-policy">
    <div class="backup-policy__title">
      <el-icon><Setting /></el-icon>
      {{ pt('元数据库备份策略') }}
      <span class="backup-policy__tip">{{ pt('支持本地 / 异地 / 离线，完整 / 增量模式的定期自动备份') }}</span>
    </div>
    <div class="backup-policy__form">
      <el-input v-model="policy.prefix" :placeholder="pt('备份名称前缀')" class="policy-item is-prefix">
        <template #prepend> 前缀 </template>
      </el-input>
      <el-radio-group v-model="policy.mode">
        <el-radio-button value="本地"> 本地 </el-radio-button>
        <el-radio-button value="异地"> 异地 </el-radio-button>
        <el-radio-button value="离线"> 离线 </el-radio-button>
      </el-radio-group>
      <el-radio-group v-model="policy.kind">
        <el-radio-button value="完整"> 完整 </el-radio-button>
        <el-radio-button value="增量"> 增量 </el-radio-button>
      </el-radio-group>
      <el-select v-model="policy.schedule" class="policy-item">
        <el-option label="每日" value="每日" />
        <el-option label="每周" value="每周" />
        <el-option label="每月" value="每月" />
      </el-select>
      <el-time-select v-model="policy.time" start="00:00" step="00:30" end="23:30" placeholder="执行时间" class="policy-item is-time" />
      <el-input-number v-model="policy.keep" :min="1" :max="60" />
      <el-switch v-model="policy.autoDelete" active-text="到期自动删除" inactive-text="保留全部" />
      <el-button type="primary" :icon="Setting" @click="onSave"> 保存策略 </el-button>
    </div>
  </div>
</template>

<style scoped lang="scss">
.backup-policy {
  padding: 14px 16px;
  background: var(--el-bg-color);
  border: 1px solid #eef1f6;
}

.backup-policy__title {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-bottom: 10px;
  color: #243752;
  font-weight: 600;
}

.backup-policy__tip {
  margin-left: 4px;
  color: #8695a8;
  font-size: 12px;
  font-weight: 400;
}

.backup-policy__form {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 10px 14px;
}

.policy-item {
  width: 150px;
}

.policy-item.is-prefix {
  width: 240px;
}

.policy-item.is-time {
  width: 130px;
}
</style>
