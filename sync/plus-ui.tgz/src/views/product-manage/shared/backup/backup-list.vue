<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
/**
 * 备份列表 tab（契约：docId 532352878 / 877 / 928 / 929 / 931 / 933）
 *
 * 分页字段直接用契约的 page/pageSize（Table 组件默认即读这两个字段），无需 requestCfg 映射。
 * 行操作与 action 全部走真实接口，不再依赖 localStorage mock。
 */
import { Delete, Edit, Refresh, Search, View } from '@element-plus/icons-vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import { deleteBackup, executeCleanup, listBackups, previewCleanup, renameBackup, runBackupNow } from '@/api/product-manage/platform/backup';
import type { BackupSummary } from '@/api/product-manage/types/platform';
import RestoreWizard from './restore-wizard.vue';

const emit = defineEmits<{
  (e: 'detail', backupUid: string): void;
  (e: 'backup-created', backupUid: string): void;
}>();

const tableRef = ref();

/** 立即备份弹窗选择的模式 */
const runMode = ref<'full' | 'incremental'>('full');

function requestList(params: Params) {
  return listBackups({ page: Number(params.page) || 1, pageSize: Number(params.pageSize) || 20 });
}

function refresh() {
  tableRef.value?.getData?.();
}

async function onBackupNow() {
  try {
    const res = await runBackupNow({ mode: runMode.value });
    const uid = res?.data?.backupUid;
    ElMessage.success(`备份完成：${res?.data?.name ?? uid ?? ''}`);
    refresh();
    if (uid) emit('backup-created', uid);
  } catch {
    /* 拦截器已提示 */
  }
}

function onOpenDetail(row: BackupSummary) {
  emit('detail', row.backupUid);
}

function onOpenRestore(row: BackupSummary) {
  createDialog({
    title: `恢复备份 · ${row.name}`,
    width: '700px',
    closeOnClickModal: false,
    render: () => <RestoreWizard backupUid={row.backupUid} backupName={row.name} />
  });
}

function onRename(row: BackupSummary) {
  ElMessageBox.prompt(pt('新名称允许字母、数字、点、横线、下划线（1–64 位）'), pt('重命名备份'), {
    inputValue: row.name,
    inputPattern: /^[A-Za-z0-9._-]{1,64}$/,
    inputErrorMessage: pt('名称格式不正确')
  })
    .then(async ({ value }) => {
      await renameBackup(row.backupUid, value.trim());
      ElMessage.success(pt('备份已重命名'));
      refresh();
    })
    .catch(() => {});
}

function onDelete(row: BackupSummary) {
  ElMessageBox.confirm(`确认删除备份「${row.name}」？仅删除备份文件，不影响元数据。`, pt('删除备份'), { type: 'warning' })
    .then(async () => {
      await deleteBackup(row.backupUid);
      ElMessage.success(pt('备份已删除'));
      refresh();
    })
    .catch(() => {});
}

/** 清理预览 → 确认后执行（契约：预览无 body；执行 body {confirm:true}） */
async function onCleanup() {
  try {
    const res = await previewCleanup();
    const candidates = res?.data?.candidates ?? [];
    if (!candidates.length) {
      ElMessage.info(pt('当前没有符合清理条件的备份'));
      return;
    }
    const lines = candidates.map((c) => `${c.name}  ${formatBytes(c.fileBytes)}  ${c.createdAt}`).join('\n');
    await ElMessageBox.confirm(`以下 ${candidates.length} 份备份将被清理：\n\n${lines}\n\n确认执行？该操作不可恢复。`, pt('清理超期备份'), {
      type: 'warning',
      customStyle: { whiteSpace: 'pre-line' }
    });
    const result = await executeCleanup();
    ElMessage.success(`已清理 ${result?.data?.deletedCount ?? candidates.length} 份备份`);
    refresh();
  } catch {
    /* 用户取消或拦截器已提示 */
  }
}

function formatBytes(bytes?: number): string {
  if (!bytes && bytes !== 0) return '—';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
  return `${(bytes / 1024 / 1024 / 1024).toFixed(2)} GB`;
}

function formatRows(rows?: number): string {
  return rows === undefined ? '—' : rows.toLocaleString('zh-CN');
}

const modeLabel: Record<string, string> = { full: pt('完整'), incremental: pt('增量') };

const columns: TableColumn<BackupSummary>[] = [
  { label: pt('备份名称'), prop: 'name', minWidth: 220, showOverflowTooltip: true },
  {
    label: pt('模式'),
    width: 96,
    render: ({ row }) => (
      <el-tag type={row.mode === 'full' ? 'primary' : 'success'} size="small">
        {modeLabel[row.mode] ?? row.mode}
      </el-tag>
    )
  },
  { label: pt('表数'), prop: 'tableCount', width: 84, render: ({ row }) => formatRows(row.tableCount) },
  { label: pt('总行数'), prop: 'totalRows', width: 110, render: ({ row }) => formatRows(row.totalRows) },
  { label: pt('文件大小'), width: 110, render: ({ row }) => formatBytes(row.fileBytes) },
  { label: pt('创建时间'), prop: 'createdAt', width: 180, showOverflowTooltip: true },
  { label: pt('创建人'), prop: 'createdBy', width: 120, showOverflowTooltip: true },
  {
    action: true,
    label: pt('操作'),
    fixed: 'right',
    width: 190,
    render: ({ row }) => (
      <div class="row-actions">
        <el-button link type="primary" icon={View} v-tooltip="详情" onClick={() => onOpenDetail(row)} />
        <el-button link type="primary" v-tooltip="恢复" onClick={() => onOpenRestore(row)} />
        <el-button link type="primary" icon={Edit} v-tooltip="重命名" onClick={() => onRename(row)} />
        <el-button link type="danger" icon={Delete} v-tooltip="删除" onClick={() => onDelete(row)} />
      </div>
    )
  }
];
</script>

<template>
  <div class="backup-list-tab">
    <Table ref="tableRef" :columns="columns" :request="requestList">
      <template #action>
        <el-radio-group v-model="runMode" size="small" class="backup-list-tab__mode">
          <el-radio-button value="full">{{ pt('完整') }}</el-radio-button>
          <el-radio-button value="incremental">{{ pt('增量') }}</el-radio-button>
        </el-radio-group>
        <el-button type="primary" :icon="Refresh" @click="onBackupNow"> {{ pt('立即备份') }} </el-button>
        <el-button :icon="Delete" @click="onCleanup"> {{ pt('清理超期备份') }} </el-button>
        <el-button :icon="Search" @click="refresh"> {{ pt('刷新') }} </el-button>
      </template>
    </Table>
  </div>
</template>

<style scoped lang="scss">
.backup-list-tab {
  height: 100%;
  min-height: 0;
}

.backup-list-tab__mode {
  margin-right: 8px;
}

:deep(.row-actions) {
  white-space: nowrap;
}
</style>
