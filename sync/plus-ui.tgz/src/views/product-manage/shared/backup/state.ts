import { reactive, ref } from 'vue';
import { loadJSON } from '@/utils/product-manage/storage';

/**
 * 元数据备份恢复共享状态
 *
 * 承载备份策略、备份记录、备份日志、恢复向导状态与查询条件，供
 * backup/index.vue 容器与 policy / records / logs / restore-wizard
 * 子组件共同使用，避免兄弟组件互相引用。
 *
 * UI 反馈（ElMessage/ElMessageBox）由组件层负责，本模块只做数据与业务操作。
 */

export type BackupMode = '本地' | '异地' | '离线';
export type BackupKind = '完整' | '增量';
export type BackupStatus = 'completed' | 'running' | 'failed';
export type LogLevel = 'info' | 'success' | 'warning' | 'danger';

export interface BackupRecord {
  id: number;
  name: string;
  mode: BackupMode;
  kind: BackupKind;
  size: string;
  createdAt: string;
  duration: string;
  status: BackupStatus;
}

export interface Policy {
  prefix: string;
  mode: BackupMode;
  kind: BackupKind;
  schedule: '每日' | '每周' | '每月';
  time: string;
  keep: number;
  autoDelete: boolean;
}

export interface LogEntry {
  id: number;
  time: string;
  level: LogLevel;
  action: string;
  message: string;
}

export interface RestoreResult {
  total: number;
  duration: number;
}

const POLICY_KEY = 'mdm.backup.policy';
const BACKUP_KEY = 'mdm.backup.list';
const LOG_KEY = 'mdm.backup.log';

export const DEFAULT_POLICY: Policy = {
  prefix: 'mdm-backup',
  mode: '本地',
  kind: '完整',
  schedule: '每日',
  time: '02:00',
  keep: 10,
  autoDelete: true
};

export const MODE_TAG: Record<BackupMode, 'success' | 'warning' | 'info'> = {
  本地: 'success',
  异地: 'warning',
  离线: 'info'
};

export const STATUS_MAP: Record<BackupStatus, { label: string; type: 'primary' | 'success' | 'danger' }> = {
  running: { label: '备份中', type: 'primary' },
  completed: { label: '已完成', type: 'success' },
  failed: { label: '失败', type: 'danger' }
};

export const LOG_TAG: Record<LogLevel, 'info' | 'success' | 'warning' | 'danger'> = {
  info: 'info',
  success: 'success',
  warning: 'warning',
  danger: 'danger'
};

const DEFAULT_BACKUPS: BackupRecord[] = [
  {
    id: 1,
    name: 'mdm-backup-20260908-001',
    mode: '本地',
    kind: '完整',
    size: '18.4 MB',
    createdAt: '2026-09-08 02:00:00',
    duration: '42s',
    status: 'completed'
  },
  {
    id: 2,
    name: 'mdm-backup-20260907-002',
    mode: '异地',
    kind: '增量',
    size: '2.1 MB',
    createdAt: '2026-09-07 02:00:00',
    duration: '11s',
    status: 'completed'
  },
  {
    id: 3,
    name: 'mdm-backup-20260906-003',
    mode: '本地',
    kind: '增量',
    size: '1.8 MB',
    createdAt: '2026-09-06 02:00:00',
    duration: '9s',
    status: 'failed'
  }
];

const DEFAULT_LOGS: LogEntry[] = [
  {
    id: 1,
    time: '2026-09-08 02:00:42',
    level: 'success',
    action: '备份',
    message: '完成 mdm-backup-20260908-001（本地 · 完整 · 18.4 MB · 耗时 42s）'
  },
  {
    id: 2,
    time: '2026-09-07 02:00:11',
    level: 'success',
    action: '备份',
    message: '完成 mdm-backup-20260907-002（异地 · 增量 · 2.1 MB · 耗时 11s）'
  },
  { id: 3, time: '2026-09-06 02:00:09', level: 'danger', action: '备份', message: 'mdm-backup-20260906-003 备份失败：本地磁盘空间不足' }
];

// ---------------------------------------------------------------------------
// 响应式状态
// ---------------------------------------------------------------------------

export const policy = reactive<Policy>({ ...DEFAULT_POLICY, ...loadJSON<Partial<Policy>>(POLICY_KEY, {}) });
export const backups = ref<BackupRecord[]>(loadJSON(BACKUP_KEY, DEFAULT_BACKUPS));
export const logs = ref<LogEntry[]>(loadJSON(LOG_KEY, DEFAULT_LOGS));
export const viewMode = ref<'table' | 'log'>('table');

export const queryParams = reactive<{
  keyword: string;
  mode: BackupMode | '';
  status: BackupStatus | '';
  dateRange: [string, string] | null;
}>({
  keyword: '',
  mode: '',
  status: '',
  dateRange: null
});

// 恢复向导弹窗状态（可见性由 createDialog 管理，此处只保留向导内部状态）
export const restoreStep = ref(0);
export const restoreRunning = ref(false);
export const restoreProgress = ref(0);
export const restoreResult = ref<RestoreResult | null>(null);
export const restoreTarget = ref<BackupRecord | null>(null);
export const restoreForm = reactive({ mode: '完整恢复', target: '覆盖', lock: true });

/** 表格刷新令牌：mutation 后 bump，records 组件 watch 后调用 Table.getData() */
export const refreshToken = ref(0);

export function bumpRefresh() {
  refreshToken.value++;
}

// ---------------------------------------------------------------------------
// 工具与持久化
// ---------------------------------------------------------------------------

export function nowText() {
  return new Date().toLocaleString('zh-CN', { hour12: false });
}

export function persistBackups() {
  localStorage.setItem(BACKUP_KEY, JSON.stringify(backups.value));
}

export function persistLogs() {
  localStorage.setItem(LOG_KEY, JSON.stringify(logs.value.slice(0, 200)));
}

export function persistPolicy() {
  localStorage.setItem(POLICY_KEY, JSON.stringify(policy));
}

export function initBackupStorage() {
  if (!localStorage.getItem(BACKUP_KEY)) persistBackups();
  if (!localStorage.getItem(LOG_KEY)) persistLogs();
  if (!localStorage.getItem(POLICY_KEY)) persistPolicy();
}

export function pushLog(level: LogLevel, action: string, message: string) {
  logs.value.unshift({ id: Date.now() + Math.random(), time: nowText(), level, action, message });
  persistLogs();
}

// ---------------------------------------------------------------------------
// 策略
// ---------------------------------------------------------------------------

/** 校验并保存策略；返回错误信息或 null 表示成功 */
export function savePolicy(): string | null {
  if (!policy.prefix.trim()) return '请输入备份名称前缀';
  persistPolicy();
  pushLog(
    'info',
    '策略',
    `保存备份策略：${policy.mode} · ${policy.kind} · ${policy.schedule} ${policy.time} · 保留 ${policy.keep} 份${policy.autoDelete ? '（到期自动删除）' : ''}`
  );
  return null;
}

// ---------------------------------------------------------------------------
// 备份
// ---------------------------------------------------------------------------

function nextSeq() {
  return String(backups.value.length + 1).padStart(3, '0');
}

export function buildBackupName(date = new Date()) {
  const stamp = `${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, '0')}${String(date.getDate()).padStart(2, '0')}`;
  return `${policy.prefix.trim() || 'mdm-backup'}-${stamp}-${nextSeq()}`;
}

/** 立即备份：写入运行中记录 → 模拟耗时 → 标记完成 → 触发自动清理 */
export async function createBackup(): Promise<BackupRecord> {
  const item: BackupRecord = {
    id: Date.now(),
    name: buildBackupName(),
    mode: policy.mode,
    kind: policy.kind,
    size: '计算中',
    createdAt: nowText(),
    duration: '-',
    status: 'running'
  };
  backups.value.unshift(item);
  persistBackups();
  bumpRefresh();
  pushLog('info', '备份', `启动 ${item.mode} · ${item.kind} 备份：${item.name}`);

  await new Promise((resolve) => setTimeout(resolve, 900));
  item.size = `${(Math.random() * 15 + 1).toFixed(1)} MB`;
  item.duration = `${Math.round(Math.random() * 40 + 8)}s`;
  item.status = 'completed';
  persistBackups();
  bumpRefresh();
  pushLog('success', '备份', `完成 ${item.name}（${item.mode} · ${item.kind} · ${item.size} · 耗时 ${item.duration}）`);
  applyAutoDelete();
  return item;
}

/** 按策略保留份数清理最旧的备份，返回被清理的记录 */
export function applyAutoDelete(): BackupRecord[] {
  if (!policy.autoDelete || backups.value.length <= policy.keep) return [];
  const removed = backups.value.splice(policy.keep);
  persistBackups();
  bumpRefresh();
  removed.forEach((item) => pushLog('warning', '清理', `按自动删除策略清理备份 ${item.name}（超出保留 ${policy.keep} 份）`));
  return removed;
}

export function renameBackupData(record: BackupRecord, newName: string) {
  const old = record.name;
  record.name = newName;
  persistBackups();
  bumpRefresh();
  pushLog('info', '重命名', `备份 ${old} 已重命名为 ${newName}`);
}

export function removeBackupData(record: BackupRecord) {
  const index = backups.value.indexOf(record);
  if (index < 0) return;
  backups.value.splice(index, 1);
  persistBackups();
  bumpRefresh();
  pushLog('warning', '删除', `手动删除备份 ${record.name}（${record.mode} · ${record.kind}）`);
}

// ---------------------------------------------------------------------------
// 恢复向导
// ---------------------------------------------------------------------------

/** 打开向导前重置状态；返回目标记录或错误提示（用于组件层决定是否 createDialog） */
export function prepareRestore(record?: BackupRecord): { target: BackupRecord | null; error?: string } {
  const target = record ?? backups.value.find((item) => item.status === 'completed');
  if (!target) return { target: null, error: '暂无可用于恢复的备份，请先执行一次备份' };
  if (target.status !== 'completed') return { target: null, error: '只能对已完成的备份执行恢复' };

  restoreTarget.value = target;
  restoreStep.value = 0;
  restoreProgress.value = 0;
  restoreResult.value = null;
  restoreRunning.value = false;
  restoreForm.mode = target.kind === '完整' ? '完整恢复' : '增量恢复';
  restoreForm.target = '覆盖';
  restoreForm.lock = true;
  return { target };
}

export async function runRestore(): Promise<RestoreResult | null> {
  const target = restoreTarget.value;
  if (!target) return null;
  restoreRunning.value = true;
  restoreProgress.value = 0;
  const started = Date.now();
  const timer = setInterval(() => {
    restoreProgress.value = Math.min(restoreProgress.value + Math.round(Math.random() * 12 + 4), 99);
  }, 180);
  await new Promise((resolve) => setTimeout(resolve, 1600));
  clearInterval(timer);
  restoreProgress.value = 100;
  restoreRunning.value = false;
  const duration = Math.max(1, Math.round((Date.now() - started) / 1000));
  const total = Math.round(Math.random() * 74 + 60);
  const result: RestoreResult = { total, duration };
  restoreResult.value = result;
  pushLog(
    'success',
    '恢复',
    `使用 ${target.name}（${target.mode}）执行${restoreForm.mode}·${restoreForm.target}写入，恢复 ${total} 条元数据记录，耗时 ${duration}s`
  );
  return result;
}

export function advanceRestoreStep() {
  if (restoreStep.value < 2) {
    restoreStep.value++;
    return;
  }
  if (restoreStep.value === 2 && !restoreRunning.value) {
    restoreStep.value = 3;
    runRestore();
  }
}

export function retreatRestoreStep() {
  if (restoreStep.value > 0 && !restoreRunning.value) restoreStep.value--;
}

// ---------------------------------------------------------------------------
// Table request
// ---------------------------------------------------------------------------

export function getBackups(params: Params) {
  const keyword = String(params.keyword || '')
    .trim()
    .toLowerCase();
  const range = params.dateRange as [string, string] | null | undefined;
  const [start, end] = range ?? [];
  const items = backups.value.filter((row) => {
    if (keyword && !row.name.toLowerCase().includes(keyword)) return false;
    if (params.mode && row.mode !== params.mode) return false;
    if (params.status && row.status !== params.status) return false;
    if (start && end) {
      const t = new Date(row.createdAt.replace(' ', 'T')).getTime();
      const s = new Date(`${start}T00:00:00`).getTime();
      const e = new Date(`${end}T23:59:59`).getTime();
      if (Number.isNaN(t) || t < s || t > e) return false;
    }
    return true;
  });
  return Promise.resolve({ code: 0, data: { items, total: items.length } });
}
