<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
/**
 * 备份策略 tab（契约：docId 532352875 读策略 / 532352876 改策略）
 *
 * GET /backup/policy → data{ mode,intervalSeconds,namePrefix,location,retention{maxCount,maxAgeDays,keepLatest},
 *   allowRestore,maxTables,maxRows,maxBytes,queryTimeoutMs,scheduledExecution }
 * PUT /backup/policy body { policy: {...} }，未提交字段沿用当前值。
 */
import { onMounted, reactive, ref } from 'vue';
import { ElMessage } from 'element-plus';
import { getBackupPolicy, updateBackupPolicy } from '@/api/product-manage/platform/backup';
import type { BackupPolicy } from '@/api/product-manage/types/platform';

const loading = ref(false);
const saving = ref(false);
const allowRestoreTip = ref('');

const form = reactive<BackupPolicy>({
  mode: 'incremental',
  intervalSeconds: 0,
  namePrefix: 'metadata',
  location: 'local',
  retention: { maxCount: 3, maxAgeDays: 30, keepLatest: true },
  allowRestore: false,
  maxTables: undefined,
  maxRows: undefined,
  maxBytes: undefined,
  queryTimeoutMs: undefined,
  scheduledExecution: ''
});

async function load() {
  loading.value = true;
  try {
    const res = await getBackupPolicy();
    Object.assign(form, res?.data ?? {});
    allowRestoreTip.value =
      res?.data?.allowRestore === false ? pt('当前策略未开启恢复执行（allowRestore=false），恢复向导在“执行”步骤会被后端以 503 拒绝。') : '';
  } catch {
    // 拦截器已 toast（如策略端点未部署的 404）；保留空表单，避免 onMounted 浮动 Promise 抛出未捕获 rejection
  } finally {
    loading.value = false;
  }
}

async function onSave() {
  saving.value = true;
  try {
    await updateBackupPolicy({
      mode: form.mode,
      intervalSeconds: form.intervalSeconds,
      namePrefix: form.namePrefix,
      location: form.location,
      retention: form.retention,
      allowRestore: form.allowRestore,
      maxTables: form.maxTables,
      maxRows: form.maxRows,
      maxBytes: form.maxBytes,
      queryTimeoutMs: form.queryTimeoutMs,
      scheduledExecution: form.scheduledExecution
    });
    ElMessage.success(pt('备份策略已保存'));
    await load();
  } catch {
    /* 拦截器已 toast */
  } finally {
    saving.value = false;
  }
}

onMounted(load);
</script>

<template>
  <div v-loading="loading" class="policy-tab">
    <el-alert v-if="allowRestoreTip" type="warning" :closable="false" show-icon :title="allowRestoreTip" class="policy-tab__tip" />

    <el-form label-width="150px" size="small" class="policy-tab__form">
      <el-divider content-position="left">{{ pt('备份计划') }}</el-divider>
      <el-form-item :label="pt('默认备份模式')">
        <el-radio-group v-model="form.mode">
          <el-radio-button value="incremental">{{ pt('增量备份') }}</el-radio-button>
          <el-radio-button value="full">{{ pt('完整备份') }}</el-radio-button>
        </el-radio-group>
      </el-form-item>
      <el-form-item :label="pt('定期间隔（秒）')">
        <el-input-number v-model="form.intervalSeconds" :min="0" :step="3600" controls-position="right" />
        <span class="policy-tab__hint">{{ pt('0 表示仅手动备份') }}</span>
      </el-form-item>
      <el-form-item :label="pt('自动命名前缀')">
        <el-input v-model="form.namePrefix" :placeholder="pt('1–32 位字母、数字、点、横线')" maxlength="32" />
      </el-form-item>
      <el-form-item :label="pt('运维位置标签')">
        <el-select v-model="form.location" style="width: 200px">
          <el-option :label="pt('本地')" value="local" />
          <el-option :label="pt('异地')" value="remote" />
          <el-option :label="pt('离线')" value="offline" />
        </el-select>
      </el-form-item>
      <el-form-item :label="pt('调度现状')">
        <el-input v-model="form.scheduledExecution" :placeholder="pt('后端返回的调度说明（只读展示，可原样保存）')" />
      </el-form-item>

      <el-divider content-position="left">{{ pt('保留策略') }}</el-divider>
      <el-form-item :label="pt('最多保留份数')">
        <el-input-number v-model="form.retention!.maxCount" :min="0" controls-position="right" />
      </el-form-item>
      <el-form-item :label="pt('最多保留天数')">
        <el-input-number v-model="form.retention!.maxAgeDays" :min="0" controls-position="right" />
      </el-form-item>
      <el-form-item :label="pt('始终保留最新一份')">
        <el-switch v-model="form.retention!.keepLatest" />
      </el-form-item>

      <el-divider content-position="left">{{ pt('预算与开关') }}</el-divider>
      <el-form-item :label="pt('允许恢复执行')">
        <el-switch v-model="form.allowRestore" />
        <span class="policy-tab__hint">{{ pt('本版本即使开启也不自动执行恢复，仍走确认令牌流程') }}</span>
      </el-form-item>
      <el-form-item :label="pt('单次表数上限')">
        <el-input-number v-model="form.maxTables" :min="0" controls-position="right" :placeholder="pt('不限')" />
      </el-form-item>
      <el-form-item :label="pt('单次行数上限')">
        <el-input-number v-model="form.maxRows" :min="0" :step="10000" controls-position="right" :placeholder="pt('不限')" />
      </el-form-item>
      <el-form-item :label="pt('文件字节上限')">
        <el-input-number v-model="form.maxBytes" :min="0" :step="1048576" controls-position="right" :placeholder="pt('不限')" />
      </el-form-item>
      <el-form-item :label="pt('单表读取超时（ms）')">
        <el-input-number v-model="form.queryTimeoutMs" :min="0" :step="1000" controls-position="right" :placeholder="pt('默认')" />
      </el-form-item>
    </el-form>

    <div class="policy-tab__footer">
      <el-button type="primary" :loading="saving" @click="onSave">{{ pt('保存策略') }}</el-button>
      <el-button @click="load">{{ pt('重新加载') }}</el-button>
    </div>
  </div>
</template>

<style scoped lang="scss">
.policy-tab {
  height: 100%;
  min-height: 0;
  overflow: auto;
  padding: 12px 16px;
}

.policy-tab__tip {
  margin-bottom: 12px;
}

.policy-tab__form {
  max-width: 720px;
}

.policy-tab__hint {
  margin-left: 10px;
  color: #8695a8;
  font-size: 12px;
}

.policy-tab__footer {
  display: flex;
  gap: 8px;
  padding: 12px 0 20px 150px;
}
</style>
