<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
/**
 * 元数据备份恢复（契约驱动改造）
 *
 * 布局：左侧资源目录树（复用元数据浏览树 metadata/tree）+ 右侧 tab（备份列表 / 备份详情 / 备份策略）。
 * 资源树节点点击后，详情 tab 会提示当前选中资源；备份本身是元数据库整库级操作，不按资源过滤。
 *
 * 全部数据走真实接口（见 api/product-manage/platform/backup.ts），不再使用 localStorage mock。
 */
import { ref } from 'vue';
import type { MetadataTreeNode } from '@/api/product-manage/platform/metadata-browse';
import BackupDetail from './backup-detail.vue';
import BackupList from './backup-list.vue';
import BackupPolicy from './backup-policy.vue';
import ResourceTree from './resource-tree.vue';

const activeTab = ref('list');
const selectedBackupUid = ref<string | null>(null);
const selectedResource = ref<MetadataTreeNode | null>(null);

function onSelectResource(node: MetadataTreeNode | null) {
  selectedResource.value = node;
}

function onShowDetail(backupUid: string) {
  selectedBackupUid.value = backupUid;
  activeTab.value = 'detail';
}

function onBackupCreated(backupUid: string) {
  selectedBackupUid.value = backupUid;
}
</script>

<template>
  <div class="backup-page">
    <aside class="backup-page__aside">
      <ResourceTree @select="onSelectResource" />
    </aside>

    <section class="backup-page__main">
      <el-tabs v-model="activeTab" type="border-card" class="backup-page__tabs">
        <el-tab-pane :label="pt('备份列表')" name="list">
          <BackupList @detail="onShowDetail" @backup-created="onBackupCreated" />
        </el-tab-pane>
        <el-tab-pane :label="pt('备份详情')" name="detail">
          <BackupDetail :backup-uid="selectedBackupUid" :selected-resource="selectedResource" />
        </el-tab-pane>
        <el-tab-pane :label="pt('备份策略')" name="policy">
          <BackupPolicy />
        </el-tab-pane>
      </el-tabs>
    </section>
  </div>
</template>

<style scoped lang="scss">
.backup-page {
  display: flex;
  align-items: stretch;
  gap: 0;
  height: 100%;
  min-height: 0;
  overflow: hidden;
  padding: 10px;
}

.backup-page__aside {
  flex: 0 0 260px;
  min-width: 0;
  margin-right: 8px;
}

.backup-page__main {
  position: relative;
  display: flex;
  flex: 1 1 0;
  flex-direction: column;
  min-width: 0;
  min-height: 0;
  overflow: hidden;
  background: var(--el-bg-color);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 6px;
}

.backup-page__tabs {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;

  :deep(.el-tabs__content) {
    flex: 1;
    min-height: 0;
    padding: 0;
    overflow: hidden;
  }

  :deep(.el-tab-pane) {
    height: 100%;
  }
}
</style>
