<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
import { ArrowDown, RefreshLeft, Search } from '@element-plus/icons-vue';
import { ElMessage } from 'element-plus';
import { adminDivisionCacheData, loadAdminDivisionNodes, loadSheetOptions, sampleQuery, sheetOptions, sheetOptionsLoading } from './state';

/**
 * 空间查询公共骨架（当前由初级产品查询使用；产品成果线接入时复用同一套）
 *
 * 由调用方差异决定的四处走 slot / prop：
 *  - 分类条件字段：按各自维度渲染，走默认 slot（只给字段行，卡片外壳与标题由本组件提供）；
 *  - 缓冲区目标：半径档位不同，走 bufferTargets prop；
 *  - 分类条件卡片标题：文案不同，走 categoryTitle prop；
 *  - 底部提示：数据规模不同，走 tip prop。
 * 其余（绘制框选 / 图号 / 坐标 / 底部按钮）逐字共用。
 *
 * 所有控件的动作都由调用方接到真实接口（见 ./state.ts）：本组件只负责收集输入并 emit，
 * 不接受也不会伪造「命中结果」。
 *
 * UI 契约（2026-10-24 重构，同日二轮紧凑化）：
 *  - 「分类条件」「空间查询（地图）」各自是一张浅底圆角卡片，标题带蓝色竖条 + 右侧折叠箭头，可展开 / 收起；
 *  - 卡片内一律「定宽标签 + 填充控件」横排（.q-row / .q-label / .q-control），
 *    替换早先「标签在上、控件在下」的堆叠写法——同样字段数下更紧凑、扫读更快；
 *  - 同类按钮等宽分组（.q-btns--fill），选中态唯一用主色；
 *  - 滚动只发生在字段区（.q-scroll），底部操作条永远贴在面板底部、不随内容滚走；
 *  - 插槽内容（分类条件字段）沿用同类名，样式由本组件 :deep 统一提供，调用方零样式。
 */
const props = defineProps<{
  /** 当前绘制工具（由调用方 state 持有，'none' 表示未绘制） */
  drawTool: string;
  /** 缓冲区半径档位；不传或空数组则不渲染该区块 */
  bufferTargets?: string[];
  /** 底部提示文案 */
  tip?: string;
  /** 分类条件卡片标题（调用方字段维度不同，标题也可能不同） */
  categoryTitle?: string;
}>();

const emit = defineEmits<{
  'update:drawTool': [tool: string];
  reset: [];
  query: [];
  /** 缓冲区半径（公里）：预设档位传文案，手工输入传数字，调用方统一解析 */
  buffer: [target: string | number];
  coord: [value: string];
  /** 行政区划节点的 uid（不再是自由文本名称，见 Apifox「综合管理-行政区划」树接口） */
  region: [uid: string];
  file: [file: File];
}>();

const drawTools: { label: string; value: string }[] = [
  { label: pt('折线'), value: 'polyline' },
  { label: pt('矩形'), value: 'rectangle' },
  { label: pt('圆'), value: 'circle' },
  { label: pt('多边形'), value: 'polygon' }
];

/** 坐标范围输入（范围查询 radio 选中「坐标」时渲染） */
const coordInput = ref('');
/** 选中的行政区划 uid（el-tree-select 的 v-model，node-key="uid"） */
const regionUid = ref('');
/** 缓冲区自定义半径（公里）；预设档位按钮之外也允许手工输入 */
const bufferRadius = ref<number>(5);
const fileInputRef = ref<HTMLInputElement | null>(null);

/**
 * 范围查询方式：坐标 / 行政区划 / 文件导入三者互斥，一次只用一种。
 * 原先三行输入同时摆着，看不出「这次到底按哪个范围查」，而后端只认最后一次定位的几何；
 * 改成 radio 单选后只渲染选中那一项的输入，面板也随之矮两行。
 */
type RangeMode = 'coord' | 'region' | 'file';
const RANGE_MODES: { label: string; value: RangeMode }[] = [
  { label: pt('坐标'), value: 'coord' },
  { label: pt('区划'), value: 'region' },
  { label: pt('文件'), value: 'file' }
];
const DEFAULT_RANGE_MODE: RangeMode = 'coord';
const rangeMode = ref<RangeMode>(DEFAULT_RANGE_MODE);

/** 三张卡片的展开状态；默认全展开，收起来后面板随之变矮，操作条仍贴底可见 */
const expanded = reactive({ keyword: true, space: true, category: true });
function toggleSection(key: keyof typeof expanded) {
  expanded[key] = !expanded[key];
}

function onDraw(tool: string) {
  emit('update:drawTool', tool);
  const label = drawTools.find((item) => item.value === tool)?.label ?? tool;
  const hint = tool === 'rectangle' || tool === 'circle' ? pt('按住鼠标拖动绘制') : pt('单击加点，双击结束');
  ElMessage.info(`已进入${label}绘制模式：${hint}，Esc 取消`);
}

/** 图号下拉展开时懒加载矢量组网字典（首次展开打接口，之后走缓存） */
function onSheetVisibleChange(visible: boolean) {
  if (visible) void loadSheetOptions();
}

function onCoordQuery() {
  emit('coord', coordInput.value);
}

/** 自定义缓冲半径：校验后把公里数交给调用方（预设档位按钮走 emit('buffer', target) 文案） */
function onBufferQuery() {
  const radius = Number(bufferRadius.value);
  if (!Number.isFinite(radius) || radius <= 0) {
    ElMessage.warning(pt('请输入大于 0 的缓冲半径（公里）'));
    return;
  }
  emit('buffer', radius);
}

/** 行政区划树：选中节点即查询（change 直接触发），清空选中不发起查询；不设独立查询按钮 */
function onRegionChange(uid: string) {
  if (!uid) return;
  emit('region', uid);
}

function onFilePick() {
  fileInputRef.value?.click();
}

function onFileChange(e: Event) {
  const target = e.target as HTMLInputElement;
  const file = target?.files?.[0];
  if (!file) return;
  emit('file', file);
  target.value = '';
}

/**
 * 清空骨架自持的输入（图号 / 坐标 / 行政区划 / 文件）。
 * WHY 暴露给调用方：这些 ref 住在骨架内部，而「重置」动作在 wrapper 里；
 * 不暴露的话 reset 只清 state、输入框仍留着上一次的值，表现为「重置没重置干净」。
 */
function clearInputs() {
  sampleQuery.keyword = '';
  coordInput.value = '';
  regionUid.value = '';
  bufferRadius.value = 5;
  rangeMode.value = DEFAULT_RANGE_MODE;
  if (fileInputRef.value) fileInputRef.value.value = '';
}

defineExpose({ clearInputs });
</script>

<template>
  <div class="sample-query">
    <!-- 字段滚动区：只有这里滚，底部操作条因此永远固定可见 -->
    <div class="q-scroll">
      <!-- ① 关键词检索（图号）：面板最上方，图号来自任务系统数据字典「矢量组网」 -->
      <section class="q-section">
        <header
          class="q-section-title"
          role="button"
          tabindex="0"
          :aria-expanded="expanded.keyword"
          @click="toggleSection('keyword')"
          @keydown.enter.prevent="toggleSection('keyword')"
          @keydown.space.prevent="toggleSection('keyword')"
        >
          <span>{{ pt('关键词检索') }}</span>
          <el-icon class="q-section-arrow" :class="{ 'q-section-arrow--open': expanded.keyword }"><ArrowDown /></el-icon>
        </header>
        <div v-show="expanded.keyword" class="q-section-body">
          <div class="q-row">
            <span class="q-label">{{ pt('图号') }}</span>
            <div class="q-control">
              <el-select
                v-model="sampleQuery.keyword"
                size="small"
                clearable
                filterable
                allow-create
                default-first-option
                :placeholder="pt('选择或输入图号（矢量组网）')"
                :loading="sheetOptionsLoading"
                @visible-change="onSheetVisibleChange"
              >
                <el-option v-for="opt in sheetOptions" :key="opt.value" :label="opt.label" :value="opt.value" />
              </el-select>
            </div>
          </div>
        </div>
      </section>

      <!-- ② 空间几何检索：绘制框选 / 范围查询 / 缓冲区 -->
      <section class="q-section">
        <header
          class="q-section-title"
          role="button"
          tabindex="0"
          :aria-expanded="expanded.space"
          @click="toggleSection('space')"
          @keydown.enter.prevent="toggleSection('space')"
          @keydown.space.prevent="toggleSection('space')"
        >
          <span>{{ pt('空间几何检索') }}</span>
          <el-icon class="q-section-arrow" :class="{ 'q-section-arrow--open': expanded.space }"><ArrowDown /></el-icon>
        </header>

        <div v-show="expanded.space" class="q-section-body">
          <div class="q-row">
            <span class="q-label">{{ pt('绘制框选') }}</span>
            <div class="q-btns q-btns--fill">
              <el-button
                v-for="tool in drawTools"
                :key="tool.value"
                size="small"
                :type="props.drawTool === tool.value ? 'primary' : 'default'"
                @click="onDraw(tool.value)"
              >
                {{ tool.label }}
              </el-button>
            </div>
          </div>

          <!-- 范围查询：坐标 / 区划 / 文件三选一，radio 决定用哪种，右侧只渲染选中那一项的输入 -->
          <div class="q-row">
            <span class="q-label">{{ pt('范围查询') }}</span>
            <el-radio-group v-model="rangeMode" size="small" class="q-radios">
              <el-radio-button v-for="m in RANGE_MODES" :key="m.value" :value="m.value">{{ m.label }}</el-radio-button>
            </el-radio-group>
          </div>

          <!-- 坐标：回车 + 行内查询按钮让该字段真正可提交（父组件接到坐标的真实查询）。 -->
          <div v-if="rangeMode === 'coord'" class="q-row">
            <span class="q-label">{{ pt('坐标范围') }}</span>
            <div class="q-control">
              <el-input
                v-model="coordInput"
                size="small"
                :placeholder="pt('如 116.4,39.9 或 minLng,minLat,maxLng,maxLat')"
                clearable
                @keyup.enter="onCoordQuery"
              />
              <el-button size="small" :icon="Search" :aria-label="pt('按坐标范围查询')" @click="onCoordQuery" />
            </div>
          </div>

          <div v-if="rangeMode === 'region'" class="q-row">
            <span class="q-label">{{ pt('行政区划') }}</span>
            <div class="q-control">
              <!-- 行政区划树：Apifox「综合管理-行政区划」GET /platform/administrative-divisions/tree。
                   lazy + :load 按省/市/县三级按需加载；check-strictly 让省/市父节点也可直接选中。
                   cache-data 回填已加载节点中文名，避免 lazy 选中后选择框显示 uid。 -->
              <el-tree-select
                v-model="regionUid"
                size="small"
                popper-class="q-select-popper"
                :placeholder="pt('省 / 市 / 县')"
                clearable
                filterable
                check-strictly
                lazy
                :load="loadAdminDivisionNodes"
                :cache-data="adminDivisionCacheData"
                :props="{ label: 'name', isLeaf: 'isLeaf' }"
                node-key="uid"
                @change="onRegionChange"
              />
            </div>
          </div>

          <!-- 文件导入：选中文件即由 onFileChange 立即 emit('file') 发起查询，无需额外查询按钮 -->
          <div v-if="rangeMode === 'file'" class="q-row">
            <span class="q-label">{{ pt('文件导入') }}</span>
            <div class="q-control">
              <input
                ref="fileInputRef"
                type="file"
                style="display: none"
                accept=".txt,.csv,.tsv,.xlsx,.xls,.shp,.dbf,.gdb,.zip"
                @change="onFileChange"
              />
              <el-button size="small" @click="onFilePick">{{ pt('选择文件（TXT/CSV 可解析）') }}</el-button>
            </div>
          </div>

          <!-- 缓冲区：以上一次查询几何（绘制 / 坐标 / 行政区划）为基准外扩；
               state.ts 的 runBufferQuery 要求已有 lastArea（即先定位过范围），否则提示且不发查询。
               WHY 置于范围查询之下：先定位范围再缓冲，操作顺序与阅读顺序一致（2026-11-13 调整）。 -->
          <p v-if="props.bufferTargets && props.bufferTargets.length" class="q-tip q-tip--buffer">
            {{ pt('先绘制 / 坐标 / 行政区划查询出范围，再选半径做缓冲区（半径也可手工输入公里数；未定位范围时无法缓冲）') }}
          </p>
          <div v-if="props.bufferTargets && props.bufferTargets.length" class="q-row">
            <span class="q-label">{{ pt('缓冲区') }}</span>
            <div class="q-btns q-btns--fill">
              <el-button v-for="target in props.bufferTargets" :key="target" size="small" @click="emit('buffer', target)">
                {{ target }}
              </el-button>
            </div>
          </div>
          <div v-if="props.bufferTargets && props.bufferTargets.length" class="q-row">
            <span class="q-label">{{ pt('自定义半径') }}</span>
            <div class="q-control">
              <el-input-number v-model="bufferRadius" size="small" :min="0.1" :max="1000" :step="1" :precision="1" controls-position="right" />
              <span class="q-unit">{{ pt('公里') }}</span>
              <el-button size="small" type="primary" @click="onBufferQuery">{{ pt('缓冲查询') }}</el-button>
            </div>
          </div>

          <!-- <p class="q-tip">
            <el-icon><InfoFilled /></el-icon>
            {{ props.tip ?? '地图单击选中，按住 Shift 可多选' }}
          </p> -->
        </div>
      </section>

      <!-- 分类条件卡片（E-05）：产品类别等分类条件统一置于面板最下方 -->
      <section class="q-section">
        <header
          class="q-section-title"
          role="button"
          tabindex="0"
          :aria-expanded="expanded.category"
          @click="toggleSection('category')"
          @keydown.enter.prevent="toggleSection('category')"
          @keydown.space.prevent="toggleSection('category')"
        >
          <span>{{ categoryTitle ?? '分类条件' }}</span>
          <el-icon class="q-section-arrow" :class="{ 'q-section-arrow--open': expanded.category }"><ArrowDown /></el-icon>
        </header>
        <div v-show="expanded.category" class="q-section-body">
          <slot />
        </div>
      </section>
    </div>

    <footer class="q-actions">
      <el-button size="small" :icon="RefreshLeft" @click="emit('reset')">{{ pt('重置') }}</el-button>
      <el-button size="small" type="primary" :icon="Search" @click="emit('query')">{{ pt('条件查询') }}</el-button>
    </footer>
  </div>
</template>

<style scoped lang="scss">
.sample-query {
  display: flex;
  flex: 1;
  flex-direction: column;
  gap: 8px;
  min-height: 0;
}

/* WHY 独立滚动区：把滚动从面板外壳（panel.vue 的 .qp-body）下沉到这里，
   底部操作条放在滚动区之外，才能做到「内容再长，按钮也固定在面板底部」。
   早先操作条靠 margin-top:auto 贴底，内容一超高就会被一起滚走。 */
.q-scroll {
  display: flex;
  flex: 1;
  flex-direction: column;
  gap: 8px;
  min-height: 0;
  overflow: auto;
}

/* ---------------------------------------------------------------------------
 * 卡片外壳（骨架自身模板，普通 scoped 选择器即可命中）
 * --------------------------------------------------------------------------- */
.q-section {
  display: flex;
  flex: none;
  flex-direction: column;
  padding: 8px 10px;
  background: rgb(31 55 84 / 3%);
  border: 1px solid rgb(31 55 84 / 7%);
  border-radius: 8px;
}

.q-section-title {
  display: flex;
  align-items: center;
  gap: 6px;
  color: #172b4d;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  user-select: none;

  &::before {
    flex: none;
    width: 3px;
    height: 12px;
    background: #2563eb;
    border-radius: 2px;
    content: '';
  }

  &:focus-visible {
    border-radius: 2px;
    outline: 2px solid #2563eb;
    outline-offset: 2px;
  }
}

.q-section-arrow {
  margin-left: auto;
  color: #8a97a8;
  font-size: 12px;
  transition: transform 0.18s ease;

  /* 展开时箭头朝下，收起时朝右（-90°） */
  &:not(.q-section-arrow--open) {
    transform: rotate(-90deg);
  }
}

.q-section-body {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding-top: 6px;
}

/* ---------------------------------------------------------------------------
 * 表单行样式。
 * WHY 这几组走 :deep：本组件自身模板与调用方插槽（分类条件字段 / 区划定位）用的是同一套类名，
 * 而插槽元素只带调用方的 scope attr，普通 scoped 选择器匹配不到；
 * :deep 编译为 `.sample-query[data-v-x] .q-*`，自身模板与插槽一并命中，单一事实来源。
 * --------------------------------------------------------------------------- */
:deep(.q-row) {
  display: flex;
  align-items: center;
  gap: 6px;
}

/* WHY 定宽标签：横排表单的基线。76px 容得下 6 个汉字（如「行政区划定位」），
   更长的文案应由调用方精简，而不是把控件挤成两行。 */
:deep(.q-label) {
  flex: none;
  width: 76px;
  color: var(--el-text-color-secondary);
  font-size: 12px;
  line-height: 1.4;
}

:deep(.q-control) {
  display: flex;
  flex: 1;
  gap: 6px;
  min-width: 0;

  > .el-input,
  > .el-select {
    flex: 1;
    min-width: 0;
  }

  > .el-button {
    flex: none;
  }
}

:deep(.q-btns) {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;

  .el-button {
    margin: 0;
  }
}

/* 同类按钮等宽分组：绘制工具 / 缓冲区 / 导入文件，视觉上是一个整体 */
:deep(.q-btns--fill) {
  flex: 1;
  min-width: 0;

  .el-button {
    flex: 1;
    min-width: 0;
  }
}

/* 范围查询 radio（坐标/区划/文件）：与 .q-btns--fill 同口径三等分填满剩余宽度；
   EP 的 radio-button 默认左对齐排列，不撑开会在标签右侧挤成一小条 */
:deep(.q-radios) {
  display: flex;
  flex: 1;
  min-width: 0;

  .el-radio-button {
    flex: 1;
    min-width: 0;
  }

  .el-radio-button__inner {
    width: 100%;
    padding: 5px 4px;
    font-size: 12px;
  }
}

/* 自定义缓冲半径单位：与 el-input-number 同行、不参与 flex 填充 */
.q-unit {
  flex: none;
  color: var(--el-text-color-secondary);
  font-size: 12px;
}

.q-tip {
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 2px 0 0;
  padding: 4px 8px;
  color: #4b6a9b;
  font-size: 11px;
  line-height: 1.5;
  background: rgb(37 99 235 / 6%);
  border-radius: 4px;

  .el-icon {
    flex: none;
    color: #2563eb;
  }
}

/* WHY 放在滚动区之外 + flex:none：按钮固定到底部，不随字段滚动、也不受折叠状态影响。 */
.q-actions {
  display: flex;
  flex: none;
  gap: 8px;
  padding-top: 8px;
  border-top: 1px solid var(--el-border-color-lighter);

  .el-button {
    flex: 1;
    margin: 0;
  }
}
</style>

<style lang="scss">
/* WHY 非 scoped：el-select 的下拉面板 teleport 到 <body>，不在本组件 DOM 子树内，
   scoped / :deep 的选择器都命中不到，只能靠 el-select 的 popper-class 精准命名后走全局块。

   WHY 覆盖 item 高度：EP 把 .el-select-dropdown__item 的 height / line-height 写死成 34px，
   不随 size="small" 收缩，与本面板 24px 的选择框高度不一致——这里统一压到 24px，
   并同步字号与左右留白（右侧仍给勾选图标留位）。 */
.q-select-popper {
  .el-select-dropdown__item {
    height: 24px;
    padding: 0 24px 0 12px;
    font-size: 12px;
    line-height: 24px;
  }

  .el-select-dropdown__empty {
    padding: 6px 0;
    font-size: 12px;
  }

  .el-select-dropdown__list {
    margin: 0;
    padding: 4px 0;
  }

  &.el-popper {
    border-radius: 6px;
  }
}
</style>
