import { computed, reactive, ref } from 'vue';
import { getProductCategoryTree } from '@/api/product-manage/platform/category';
import { collectLayerFeatures, listMetadataLayers } from '@/api/product-manage/platform/resources';
import { queryMetadataRecords } from '@/api/product-manage/platform/metadata-query';
import { getWorkUnitDictTypes } from '@/api/workUnitDs';
import { customDictDataOptions } from '@/api/customDict';
import {
  getAdministrativeDivision,
  listAdministrativeDivisionTree,
  locateMapSheets,
  type AdministrativeDivisionNode
} from '@/api/product-manage/platform/enums';
import { BEST_EFFORT_HEADER } from '@/utils/request';
import { hashId, toQueryRow } from '@/views/product-manage/shared/resource-row';
import { bboxPolygon, booleanIntersects, buffer } from '@turf/turf';

/**
 * 数据查询共享状态（地图左侧查询面板）
 *
 * 数据全部来自真实接口，**不含任何 mock**（2026-11-20 按最新统一查询契约改造）：
 *   - 检索分两大类：**关键词检索**（图号）+ **空间几何检索**（绘制 / 坐标 / 区划 / 文件 / 缓冲）；
 *   - 关键词（图号）选项 ← 任务系统数据字典「矢量组网」（getWorkUnitDictTypes + customDictDataOptions，
 *     拉不到时降级为手工输入，见 loadSheetOptions）；
 *   - 条件查询 ← POST /platform/metadata-records/query（keyword + categoryUids + 分页），
 *     首次查询返回的 queryToken 为跨页游标；图号与产品类别全空时不发请求。
 *   - 空间查询 ← GET /platform/resources/metadata-layers（真实 geojson）+ turf 求交。
 *
 * 数据版本下拉已按评审移除，不再作为查询维度（后端统一查询契约亦无该过滤参数）。
 *
 * 选中集合 selectedIds 与空间查询形状 shape 为跨模块共享状态：
 * 列表勾选、地图点选、空间查询、条件查询都写同一份 selectedIds，
 * 图层渲染由 data-query 侧消费（见 shared/data-query/index.vue）。
 */

export type QueryShape = 'none' | 'rectangle' | 'circle' | 'polygon' | 'polyline' | 'buffer' | 'region';

export const queryState = reactive({
  selectedIds: [] as number[],
  shape: 'none' as QueryShape,
  /**
   * 已勾选「在地图上显示」的产品类别。
   * null = 未初始化，等价于「全部勾选」（地图默认渲染全部类别）；
   * 数组 = 用户显式选择，空数组表示全部取消。
   */
  activeCategories: null as string[] | null,
  /**
   * 最近一次空间查询命中的**真实要素**（metadata-layers 的 geojson，已补 id / name / category）。
   * WHY 单独存一份：命中资源不一定在当前列表页，列表行解析不出 uid，
   * 地图需要能直接拿到几何来渲染（见 data-query 的 syncLayersFromSelection）。
   */
  hitFeatures: [] as any[],
  /** 最近一次用于查询的几何（绘制 / 图号 / 坐标），供「缓冲区」二次查询复用 */
  lastArea: null as any
});

/**
 * 左侧元数据浏览树中**实际挂载（勾选）的资源所属的产品类别名集合**。
 *
 * WHY 单独立一份共享状态（而非让图例走另一条 `getProductCategoryTree` 收敛）：
 * 图例语义是「跟随地图上实际显示的类型」，而地图只渲染用户在左侧树**勾选**的资源
 * （见 data-browse 的 checkedKeys → syncTileLayers 上图链路），未勾选的类别
 * 不应出现在图例里。直接把「勾选资源所属的类别」喂给图例，才能保证图例 =
 * 地图上实际有数据的类别。
 *
 * 由 DataBrowse 在 `checkedKeys` / `treeData` 变化时算出后写入
 * （组件常驻挂载，见 tree-host.ts 的 v-show 约定）；详情页（无树）不写。
 * 尚未来得及写入时为 null（图例回落不渲染）；没有任何资源勾选时为空 Set（图例同样不渲染）。
 */
export const mountedCategoryNames = ref<Set<string> | null>(null);

/**
 * 占位令牌：只有持有者才能清除 `mountedCategoryNames`。
 * WHY 同 tree-host 的 owner 机制：切 tab 时新面板先挂载、旧面板后卸载，
 * 若旧面板把共享值清成 null，会顶掉新面板刚写入的类别集，图例闪一下退回全部。
 * 故用令牌约定「持有者才能清」，切 tab 的竞态下只让当前持有者（新面板）生效。
 */
let mountedCategoryOwner: symbol | null = null;

/** 认领共享的已挂载类别集（DataBrowse 挂载时调用，setup 阶段同步认领避免竞态） */
export function claimMountedCategoryNames(owner: symbol) {
  mountedCategoryOwner = owner;
}

/** 释放：仅当仍是持有者时清零，避免切 tab 卸载旧面板时误清新面板的值 */
export function releaseMountedCategoryNames(owner: symbol) {
  if (mountedCategoryOwner !== owner) return;
  mountedCategoryOwner = null;
  mountedCategoryNames.value = null;
}

/** 当前生效的类别集合：null 视为全选（由调用方提供全集） */
export function resolveActiveCategories(all: string[]) {
  const active = queryState.activeCategories;
  return new Set(active === null ? all : active);
}

export function toggleCategoryOnMap(category: string, all: string[] = []) {
  const set = resolveActiveCategories(all);
  if (set.has(category)) set.delete(category);
  else set.add(category);
  queryState.activeCategories = [...set];
  return set.has(category);
}

/** 图例勾选全部 / 全不选 */
export function setCategoriesOnMap(categories: string[], on: boolean, all: string[] = []) {
  const set = resolveActiveCategories(all);
  for (const c of categories) {
    if (on) set.add(c);
    else set.delete(c);
  }
  queryState.activeCategories = [...set];
}

export const SHAPE_LABELS: Record<Exclude<QueryShape, 'none'>, string> = {
  rectangle: '矩形',
  circle: '圆形',
  polygon: '多边形',
  polyline: '折线',
  buffer: '缓冲区',
  region: '行政区划'
};

// ---------------------------------------------------------------------------
// 查询下拉选项（真实接口）
// ---------------------------------------------------------------------------

export interface CategoryOption {
  /** 类别 uid，后端 categoryUid 过滤用 */
  uid: string;
  /** 类别中文名，展示用 */
  name: string;
  /** 子类别（仅树形下拉使用；平铺列表不带该字段） */
  children?: CategoryOption[];
}

/** 平铺类别：仅用于「是否已有选项」一类线性判断 */
export const categoryOptions = ref<CategoryOption[]>([]);
/**
 * 树形类别：产品类别下拉按接口真实层级展示。
 * WHY 单独存一份（而非从平铺 items 再组一次树）：getProductCategoryTree 已经返回 tree，
 * 再拼一次等于把层级规则复制到页面层；这里直接消费接口的树，页面零组装逻辑。
 */
export const categoryTree = ref<CategoryOption[]>([]);

/** 接口树节点 → 下拉树节点：字段名换成 uid/name；空 children 不落节点（避免出现假展开箭头） */
function toCategoryOption(node: any): CategoryOption {
  const item: CategoryOption = { uid: node.categoryUid, name: node.categoryName };
  const kids: any[] = Array.isArray(node.children) ? node.children : [];
  const children = kids.filter((kid) => kid?.categoryUid && kid?.categoryName).map(toCategoryOption);
  if (children.length) item.children = children;
  return item;
}
export const queryOptionsLoading = ref(false);
let optionsLoaded = false;

/**
 * 加载查询下拉选项。幂等：面板反复挂载只打一次接口。
 * WHY 用 x-best-effort：选项拉不到只是下拉空，不该弹「登录状态已过期」把整页锁死。
 * 数据来源改为统一查询契约的 options 接口（categories 树），不再从 /platform/resources 前端拼版本。
 */
export async function loadQueryOptions(force = false): Promise<void> {
  if (optionsLoaded && !force) return;
  queryOptionsLoading.value = true;
  const headers = { [BEST_EFFORT_HEADER]: '1' };
  try {
    const catRes: any = await getProductCategoryTree({ headers }).catch(() => null);
    const items: any[] = catRes?.data?.items ?? [];
    categoryOptions.value = items
      .filter((it: any) => it?.categoryUid && it?.categoryName)
      .map((it: any) => ({ uid: it.categoryUid, name: it.categoryName }));
    // 树形下拉：直接消费接口的 tree（层级由 category.ts 的 buildCategoryTree 统一组装）
    const tree: any[] = catRes?.data?.tree ?? [];
    categoryTree.value = tree.filter((it) => it?.categoryUid && it?.categoryName).map(toCategoryOption);
    // 兜底：接口只回平铺 items 时（无 tree），树退化为单层列表，下拉仍有选项可选
    if (!categoryTree.value.length) categoryTree.value = categoryOptions.value;
    optionsLoaded = true;
  } finally {
    queryOptionsLoading.value = false;
  }
}

// ---------------------------------------------------------------------------
// 图号选项（任务系统数据字典「矢量组网」）
// ---------------------------------------------------------------------------

export interface SheetOption {
  label: string;
  value: string;
}

/** 图号下拉选项；拉取失败时为空数组，骨架 Fallback 为可手工输入 */
export const sheetOptions = ref<SheetOption[]>([]);
export const sheetOptionsLoading = ref(false);
let sheetOptionsLoaded = false;

/**
 * 从任务系统数据字典「矢量组网」加载图号选项。
 * 路径：getWorkUnitDictTypes 按名字找到字典 code → customDictDataOptions(code) 取项。
 * 全程 best-effort：任一步失败只让下拉为空（手工输入仍可用），不弹登录过期遮罩。
 */
export async function loadSheetOptions(force = false): Promise<void> {
  if (sheetOptionsLoaded && !force) return;
  sheetOptionsLoading.value = true;
  try {
    const typeRes: any = await getWorkUnitDictTypes('矢量组网').catch(() => null);
    const types: any[] = typeRes?.data ?? typeRes?.rows ?? [];
    const match = types.find((t: any) => String(t?.name ?? '').includes('矢量组网')) ?? types[0];
    const dictCode = match?.code;
    if (dictCode) {
      const dataRes: any = await customDictDataOptions(String(dictCode), { full: true }).catch(() => null);
      const opts: any[] = dataRes?.data ?? dataRes?.rows ?? [];
      sheetOptions.value = opts
        .map((d: any) => ({
          label: String(d?.label ?? d?.name ?? d?.dictLabel ?? d?.value ?? d?.code ?? ''),
          value: String(d?.value ?? d?.code ?? d?.dictValue ?? d?.label ?? '')
        }))
        .filter((o: SheetOption) => o.value);
    }
    sheetOptionsLoaded = true;
  } finally {
    sheetOptionsLoading.value = false;
  }
}

// ---------------------------------------------------------------------------
// 行政区划树（Apifox「综合管理-行政区划」2026-11-10 released，省/市/县懒加载）
// ---------------------------------------------------------------------------

/**
 * 行政区划树节点（el-tree-select lazy 消费）。
 * - value = uid（node-key="uid"）、label = name、isLeaf 决定是否还能展开
 * - 接口 Node 字段更全（code / path / geometryAvailable / hasChildren…），这里只保留下拉需要的
 */
export interface AdminDivisionTreeNode {
  uid: string;
  name: string;
  levelNo: 1 | 2 | 3;
  path: string;
  /** 无下级（hasChildren=false）或已到县级（levelNo 3）→ 叶子，不再触发 :load */
  isLeaf: boolean;
}

/** 接口 Node → el-tree-select 节点 */
function toAdminDivisionTreeNode(node: AdministrativeDivisionNode): AdminDivisionTreeNode {
  return {
    uid: node.uid,
    name: node.name,
    levelNo: node.levelNo,
    path: node.path,
    isLeaf: !node.hasChildren || node.levelNo >= 3
  };
}

/**
 * 已加载过的行政区划节点缓存，供 el-tree-select 的 cache-data 回显选中标签。
 * WHY 必须：lazy 模式下节点由 :load 动态 resolve 进 tree store，不在 :data 里，
 * ElSelect 的 cachedOptions 取不到 label，选中后输入框会显示 uid 而不是中文名。
 */
export const adminDivisionCacheData = ref<AdminDivisionTreeNode[]>([]);

/**
 * 行政区划树懒加载：node.level===0 拉省级根，其余按父级 uid 拉直接下级。
 * 直接给 el-tree-select 的 :load 用（resolve 的节点需带 isLeaf）。
 * 用 x-best-effort：区划树拉不到只是下拉空，不该弹「登录状态已过期」把整页锁死。
 */
export async function loadAdminDivisionNodes(node: any, resolve: (nodes: AdminDivisionTreeNode[]) => void) {
  const headers = { [BEST_EFFORT_HEADER]: '1' };
  try {
    const parentUid = node.level === 0 ? undefined : String(node.data?.uid ?? '');
    const res: any = await listAdministrativeDivisionTree(parentUid ? { parentUid } : {}, { headers });
    const items: AdministrativeDivisionNode[] = res?.data?.items ?? [];
    const nodes = items.map(toAdminDivisionTreeNode);
    // 累计进 cache-data：按 uid 去重，保证任意已加载节点都能回显中文名
    const merged = new Map(adminDivisionCacheData.value.map((n) => [n.uid, n]));
    for (const n of nodes) merged.set(n.uid, n);
    adminDivisionCacheData.value = [...merged.values()];
    resolve(nodes);
  } catch {
    resolve([]);
  }
}

// ---------------------------------------------------------------------------
// 选中集合
// ---------------------------------------------------------------------------

export function toggleQuerySelection(id: number, multiple = true) {
  if (!multiple) queryState.selectedIds = [id];
  else if (queryState.selectedIds.includes(id)) queryState.selectedIds = queryState.selectedIds.filter((item) => item !== id);
  else queryState.selectedIds.push(id);
}

export function clearQuerySelection() {
  queryState.selectedIds = [];
  queryState.shape = 'none';
  queryState.hitFeatures = [];
  queryState.lastArea = null;
}

// ---------------------------------------------------------------------------
// 条件查询（真实接口）
// ---------------------------------------------------------------------------

export type SampleMode = 'map' | 'list';
export type DrawTool = 'none' | 'polyline' | 'rectangle' | 'circle' | 'polygon';

export const sampleQuery = reactive({
  mode: 'map' as SampleMode,
  /** 产品类别 uid（后端 categoryUid，置于面板最下方的「产品类别」条件） */
  categoryUid: '',
  /** 关键词（图号）：来自数据字典「矢量组网」，可下拉选或手工输入，走统一查询 keyword */
  keyword: '',
  drawTool: 'none' as DrawTool,
  /** 条件查询命中的资源行（QueryRow） */
  results: [] as any[],
  /** 本轮查询的跨页游标（queryMetadataRecords 返回，翻页/建选择集复用） */
  queryToken: '',
  /** 本轮查询命中总数 */
  total: 0,
  searched: false,
  loading: false
});

/**
 * 本轮查询是否有命中结果（单一数据源，供布局层决定「详情列表」是否占半屏）。
 *
 * WHY 同时看两处：条件查询写 sampleQuery.results、空间查询写 queryState.hitFeatures，
 * 两者互相清空（见 runSampleQuery / applySpatialQuery），任一处非空即代表「查到数据」。
 * 0 命中 / 未查询 / 重置后均为 false —— 用户 2026-11-10 口径「默认不显示列表，
 * 查询到数据的时候才显示列表」。布局层用 computed 派生显隐，不另存一份布尔状态。
 */
export const hasQueryResult = computed(() => sampleQuery.results.length > 0 || queryState.hitFeatures.length > 0);

/**
 * 地图查询 loading：所有条件 / 空间查询全程为 true（含图幅、区划、文件解析等前置接口与 turf 求交），
 * 由地图容器（map/index.vue）以 v-loading 消费，盖住整块地图防止查询期间重复操作。
 * WHY 计数：并发发起两个查询时（如区划刚出结果又点缓冲），最后一个结束才复位，避免先返回的那个提前撤掉遮罩。
 */
export const mapQueryLoading = ref(false);
let queryInFlight = 0;
/**
 * 把查询函数装饰一层 loading：调用期间 mapQueryLoading 为 true，并发时最后一个结束才复位。
 * WHY 装饰函数而不是在调用点包：7 个查询入口（条件 / 绘制 / 图号 / 区划 / 坐标 / 文件 / 缓冲）都要覆盖，
 * 且图幅、区划详情、文件解析等前置接口也算「查询过程」，统一在入口收口最省事、也不会漏掉某一条链路。
 */
function withQueryLoading<A extends any[], R>(run: (...args: A) => Promise<R>): (...args: A) => Promise<R> {
  return (...args: A) => {
    queryInFlight += 1;
    mapQueryLoading.value = true;
    return run(...args).finally(() => {
      queryInFlight -= 1;
      if (queryInFlight === 0) mapQueryLoading.value = false;
    });
  };
}

/** 条件查询单页上限（统一查询契约 pageSize 1-200，面板一次取够） */
const QUERY_PAGE_SIZE = 200;

/**
 * 关键词检索（核心）：POST /platform/metadata-records/query 统一查询。
 *
 * 检索条件（可任意组合，但至少给一个，避免全表扫描）：
 *  - keyword：图号（数据字典「矢量组网」选中 / 手工输入）；
 *  - categoryUids：面板底部选择的产品类别。
 *
 * 命中项带 geometry（includeGeometry=true），既有 resourceUid 供属性表消费，
 * 又能直接把几何喂给地图（写 queryState.hitFeatures），避免再拉 metadata-layers 得到的空 geojson。
 * 首次查询返回 queryToken，写入 sampleQuery.queryToken 供后续翻页 / 建选择集复用。
 *
 * @returns 命中条数（本页）
 */
export const runSampleQuery = withQueryLoading(async (): Promise<number> => {
  const keyword = String(sampleQuery.keyword ?? '').trim();
  const categoryUids = sampleQuery.categoryUid ? [sampleQuery.categoryUid] : [];
  // 至少给一个过滤维度，避免无条件全表扫描（UI 侧 onQuery 同样先提示）
  if (!keyword && !categoryUids.length) return 0;
  sampleQuery.loading = true;
  try {
    const res: any = await queryMetadataRecords({
      page: 1,
      pageSize: QUERY_PAGE_SIZE,
      keyword: keyword || undefined,
      categoryUids: categoryUids.length ? categoryUids : undefined,
      includeGeometry: true
    });
    const data: any = res?.data ?? {};
    const items: any[] = data.items ?? [];
    // 统一查询的 item 有 resourceUid / resourceName / categoryName / attributes / geometry，
    // toQueryRow 只认这些字段，recordUid 落 resourceUid，供 data-query 的 hitResourceUids 消费。
    const list = items.map((it: any, idx: number) =>
      toQueryRow(
        {
          resourceUid: it.resourceUid,
          resourceName: it.resourceName || it.attributes?.name || '',
          categoryName: it.categoryName,
          categoryUid: it.categoryUid,
          dataType: it.tableKey || it.modelUid || '',
          state: it.state,
          createdAt: it.createdAt,
          updatedAt: it.updatedAt
        },
        idx
      )
    );
    sampleQuery.results = list;
    sampleQuery.queryToken = String(data.queryToken ?? '');
    sampleQuery.total = Number(data.total ?? list.length);
    sampleQuery.searched = true;
    // 条件查询是「换一批」语义：清掉上一次空间查询的命中要素/范围
    queryState.lastArea = null;
    queryState.shape = 'none';
    // 项带 geometry 时直接作为命中要素上图（补 id/resourceUid/category），
    // 否则退化为「只列表」：data-query 会按 results 的 recordUid 异步拉 metadata-layers 几何。
    const hits: any[] = [];
    for (const it of items) {
      if (!it?.geometry) continue;
      hits.push({
        type: 'Feature',
        geometry: it.geometry,
        properties: {
          resourceUid: it.resourceUid,
          name: it.resourceName || it.attributes?.name || '',
          category: it.categoryName || '',
          sheetNo: keyword || ''
        },
        id: hashId(String(it.resourceUid ?? ''))
      });
    }
    queryState.hitFeatures = hits;
    queryState.selectedIds = list.map((row) => row.id);
    return list.length;
  } finally {
    sampleQuery.loading = false;
  }
});

export function resetSampleQuery() {
  Object.assign(sampleQuery, {
    categoryUid: '',
    keyword: '',
    drawTool: 'none',
    results: [],
    queryToken: '',
    total: 0,
    searched: false,
    loading: false
  });
}

/**
 * 切换绘制工具：只更新状态，由地图侧（GeoMap props.drawTool）驱动实际绘制。
 * 命中计算统一交给地图 onDrawComplete 回调（见 map/index.vue），避免切换即落一次假命中。
 */
export function setDrawTool(tool: DrawTool) {
  sampleQuery.drawTool = tool;
  return tool !== 'none';
}

// ---------------------------------------------------------------------------
// 空间查询（真实 geojson + turf 求交）
// ---------------------------------------------------------------------------

/** 图层接口单页条数（契约 limit 1-200，建议 50） */
const LAYER_PAGE_SIZE = 50;
/** 翻页上限：防止异常数据把浏览器拖死（200 页 = 1 万条图层记录） */
const LAYER_MAX_PAGES = 200;

/** 把图层条目里的几何整理成地图可直接消费的要素（补 id / name / category） */
function normalizeLayerFeature(item: any, f: any) {
  return {
    ...f,
    id: hashId(item.resourceUid),
    properties: {
      ...f.properties,
      resourceUid: item.resourceUid,
      name: item.resourceName || f.properties?.product_name || item.resourceUid,
      category: item.categoryName || '',
      createTime: f.properties?.update_time || f.properties?.created_at || ''
    }
  };
}

/**
 * extent2d 兜底要素：用图层自带的空间范围造一个矩形面参与求交。
 *
 * WHY 必须有这条兜底（2026-11-04 实测）：`/platform/resources/metadata-layers` 返回的
 * `geojson.features` 全是 0 条 —— 几何只写进了 MVT 瓦片，而瓦片服务对任意 z/x/y 都回同一份
 * 数据、解码后几何退化成 (0,0)，靠瓦片求交永远 0 命中（现象：坐标/图号/区划查询恒提示
 * 「范围内命中 0 个图层要素」）。这批数据里唯一可信的空间范围就是 `extent2d`。
 *
 * 语义代价：extent 是**外接矩形**，比真实几何大，属于「近似命中」。因此把它标到
 * `properties.extentApprox = true`，由地图/提示语区分，避免被误当成精确几何。
 * @returns 要素；extent 缺失或非法时返回 null
 */
function extentFallbackFeature(item: any) {
  const extent = item?.extent2d;
  if (!Array.isArray(extent) || extent.length !== 4) return null;
  const nums = extent.map((v: any) => Number(v));
  if (nums.some((v: number) => !Number.isFinite(v))) return null;
  const [minLng, minLat, maxLng, maxLat] = nums;
  if (minLng === maxLng || minLat === maxLat) return null;
  const polygon = bboxPolygon([minLng, minLat, maxLng, maxLat]);
  return {
    type: 'Feature' as const,
    geometry: polygon.geometry,
    properties: { extentApprox: true }
  };
}

/**
 * 单个图层条目 → 可求交的要素（真实 geojson 优先，无几何走 extent2d 兜底）。
 */
function collectQueryFeatures(item: any, into: any[]) {
  if (!item?.resourceUid) return;
  // 多表模型：item.geojson 只是首张表，collectLayerFeatures 会一并取出 metadataTables 的几何
  const real = collectLayerFeatures(item);
  if (real.length) {
    for (const f of real) into.push(normalizeLayerFeature(item, f));
    return;
  }
  // 无真实几何 → extent2d 近似兜底，保证「查得到」而不是恒空
  const approx = extentFallbackFeature(item);
  if (approx) into.push(normalizeLayerFeature(item, approx));
}

/**
 * 拉取参与空间求交的真实图层要素。
 *
 * 范围口径：按面板底部选中的产品类别（categoryUid）翻页拉图层；未选类别返回空数组，
 * 几何检索需先选产品类别，避免无范围的全表求交。
 */
async function loadLayerFeaturesForQuery(): Promise<any[]> {
  const feats: any[] = [];
  if (!sampleQuery.categoryUid) return feats;
  let cursor: string | undefined;
  let pages = 0;
  do {
    const res = await listMetadataLayers({ categoryUid: sampleQuery.categoryUid, limit: LAYER_PAGE_SIZE, cursor });
    for (const item of res?.data?.items ?? []) collectQueryFeatures(item, feats);
    cursor = res?.data?.hasMore ? res?.data?.nextCursor : undefined;
    pages += 1;
  } while (cursor && pages < LAYER_MAX_PAGES);
  return feats;
}

/**
 * 用任意查询几何做真实求交。
 * @param area GeoJSON 几何（Polygon / LineString / Point）
 * @param shape 记录到 queryState.shape 的形状标签
 */
async function applySpatialQuery(area: any, shape: QueryShape): Promise<number> {
  const feats = await loadLayerFeaturesForQuery();
  const hits = feats.filter((f) => {
    try {
      return booleanIntersects(f, area);
    } catch {
      return false;
    }
  });
  const ids = [...new Set(hits.map((f) => Number(f.id)))].filter((id) => !Number.isNaN(id));
  queryState.shape = shape;
  queryState.lastArea = area;
  queryState.hitFeatures = hits;
  queryState.selectedIds = ids;
  // 空间命中是「要素」而不是「资源行」，清掉上一轮条件查询的行集，避免列表误用
  sampleQuery.results = [];
  sampleQuery.searched = true;
  return hits.length;
}

/**
 * 绘制完成后的范围查询（矩形 / 圆 / 多边形 / 折线）。
 * @param feature use-draw-tool 输出的 { type:"Feature", geometry, properties }
 * @returns 命中图层要素条数
 */
export const runGeometryQuery = withQueryLoading(async (feature: any) => {
  const geometry = feature?.geometry ?? feature;
  const shape: QueryShape = geometry?.type === 'Polygon' ? 'polygon' : 'polyline';
  const count = await applySpatialQuery(geometry, shape);
  return { count };
});

/**
 * 图号查询：GET /platform/metadata/map-sheets 取图幅范围，再用该范围求交。
 * 无真实范围时返回 error，不做假命中。
 */
export const runSheetQuery = withQueryLoading(async (code: string) => {
  const sheetCode = String(code ?? '').trim();
  if (!sheetCode) return { count: 0, error: '请输入图号' };
  let res: any;
  try {
    res = await locateMapSheets([sheetCode]);
  } catch {
    // WHY 单独包一层：图幅接口在当前后端网关未部署（实测 /platform/metadata/map-sheets 返回 404），
    // 抛出的通用网络错误会被页面兜底文案盖成「图号查询失败，请稍后重试」，看不出是接口缺失，
    // 排查时会误以为是图号写错或求交逻辑有 bug。
    return { count: 0, error: '图号查询服务暂未开通（后端未提供 /platform/metadata/map-sheets），请改用坐标范围或绘制框选' };
  }
  const sheet = (res?.data?.items ?? [])[0];
  const extent = sheet?.extent;
  if (!Array.isArray(extent) || extent.length !== 4) {
    return { count: 0, error: `未找到图号「${sheetCode}」的图幅范围` };
  }
  const count = await applySpatialQuery(bboxPolygon(extent as any), 'polygon');
  return { count, sheetCode, sheetName: sheet?.sheetName };
});

/**
 * 行政区划树定位 + 范围查询（Apifox「综合管理-行政区划」2026-11-10 released）。
 *
 * WHY 换掉旧的「名称 → 离线省级 GeoJSON 模糊匹配」：
 *  - 离线 CHINA_PROVINCES_GEOJSON 只有省级、且陈旧，无法定位市 / 县；
 *  - 名称模糊匹配（includes）易误命中（「广西」↔「广西壮族自治区」）；
 *  - 新树接口 GET /platform/administrative-divisions/tree 省 / 市 / 县三级，
 *    详情 GET /platform/administrative-divisions/{uid}?includeGeometry=true 返回 EPSG:4326 真实边界。
 *
 * 选中节点后按 uid 取真实边界，再复用 applySpatialQuery 与图层要素求交上图；
 * 该面写入 lastArea，缓冲区查询可直接复用。
 * @param divisionUid 行政区划节点 uid（树选择器 v-model 的值）
 */
export const runAdminDivisionQuery = withQueryLoading(async (divisionUid: string) => {
  const uid = String(divisionUid ?? '').trim();
  if (!uid) return { count: 0, error: '请先选择行政区划' };
  let node: AdministrativeDivisionNode | undefined;
  try {
    const res: any = await getAdministrativeDivision(uid, true);
    node = res?.data;
  } catch {
    return { count: 0, error: '行政区划边界加载失败，请稍后重试' };
  }
  const geometry = node?.geometry;
  if (!geometry) return { count: 0, error: `行政区划「${node?.name || uid}」暂无可用边界几何` };
  // 详情返回的是 EPSG:4326 GeoJSON geometry（MultiPolygon），包成 Feature 交给 turf 求交
  const area = { type: 'Feature' as const, geometry, properties: {} };
  const count = await applySpatialQuery(area, 'region');
  return { count, regionName: node?.name || node?.path || uid };
});

/** 解析坐标输入：支持 `minLng,minLat,maxLng,maxLat` 与 `lng,lat`（点，取约 1km 见方） */
export function parseCoordInput(text: string): [number, number, number, number] | null {
  const nums = String(text ?? '')
    .split(/[\s,，]+/)
    .map((v) => Number(v))
    .filter((v) => !Number.isNaN(v));
  if (nums.length === 4) {
    const [minLng, minLat, maxLng, maxLat] = nums;
    return [Math.min(minLng, maxLng), Math.min(minLat, maxLat), Math.max(minLng, maxLng), Math.max(minLat, maxLat)];
  }
  if (nums.length === 2) {
    const [lng, lat] = nums;
    const d = 0.01; // 点查询取约 1km 见方，避免零面积范围求交恒空
    return [lng - d, lat - d, lng + d, lat + d];
  }
  return null;
}

/** 坐标范围查询：解析文本 → bbox → 求交 */
export const runCoordQuery = withQueryLoading(async (text: string) => {
  const bbox = parseCoordInput(text);
  if (!bbox) return { count: 0, error: '坐标格式应为 `minLng,minLat,maxLng,maxLat` 或 `lng,lat`' };
  const count = await applySpatialQuery(bboxPolygon(bbox), 'polygon');
  return { count, bbox };
});

/**
 * 缓冲区查询：对上一次查询范围做缓冲再求交。
 * WHY 必须有 lastArea：没有基准几何就无从缓冲，直接报错而不是给假命中。
 */
/**
 * 文件导入查询：从 TXT / CSV 文本中按「经度,纬度」逐行抽点，取包围盒与图层要素求交。
 * WHY 只支持文本格式：.xlsx（zip）/ .shp（shp 头 + dbf）/ .gdb 都是二进制，前端无解析库时强行读只会得到乱码，
 * 与其假装命中，不如明确提示「导出为 TXT/CSV」。
 */
export const runFileQuery = withQueryLoading(async (file: File) => {
  const name = String(file?.name ?? '').trim();
  if (!file) return { count: 0, error: '请先选择文件' };
  const lower = name.toLowerCase();
  const textExts = ['.txt', '.csv', '.tsv'];
  if (!textExts.some((e) => lower.endsWith(e))) {
    const binExts = ['.xlsx', '.xls', '.shp', '.dbf', '.gdb', '.zip'];
    const hit = binExts.find((e) => lower.endsWith(e));
    return {
      count: 0,
      error: hit ? `${name} 为二进制格式（${hit}），当前前端未接入解析库；请先导出为 TXT/CSV 后重试` : `不支持的文件类型：${name}`
    };
  }
  let text = '';
  try {
    text = await file.text();
  } catch {
    return { count: 0, error: '文件读取失败' };
  }
  const points = parseCoordList(text);
  if (!points.length) return { count: 0, error: '文件中未解析出坐标（每行形如 `经度,纬度`）' };
  const lngs = points.map((c) => c[0]);
  const lats = points.map((c) => c[1]);
  const bbox: [number, number, number, number] = [Math.min(...lngs), Math.min(...lats), Math.max(...lngs), Math.max(...lats)];
  const count = await applySpatialQuery(bboxPolygon(bbox), 'polygon');
  return { count, fileName: name, pointCount: points.length, bbox };
});

/** 逐行解析 `lng,lat`（也容错制表符 / 空格分隔）；越界值丢弃，避免坏行把 bbox 撑到整个地球 */
function parseCoordList(text: string): Array<[number, number]> {
  const out: Array<[number, number]> = [];
  for (const line of String(text ?? '').split(/\r?\n/)) {
    const parts = line
      .split(/[,\t; ]+/)
      .map((s) => s.trim())
      .filter(Boolean);
    if (parts.length < 2) continue;
    const lng = Number(parts[0]);
    const lat = Number(parts[1]);
    if (!Number.isFinite(lng) || !Number.isFinite(lat)) continue;
    if (Math.abs(lng) > 180 || Math.abs(lat) > 90) continue;
    out.push([lng, lat]);
  }
  return out;
}

export const runBufferQuery = withQueryLoading(async (radiusKm = 5) => {
  const area = queryState.lastArea;
  if (!area) return { count: 0, error: '请先绘制范围或按图号 / 坐标定位，再做缓冲区查询' };
  const buffered = buffer(area, radiusKm, { units: 'kilometers' });
  const count = await applySpatialQuery(buffered as any, 'buffer');
  return { count, radiusKm };
});

// ---------------------------------------------------------------------------
// 选区清理 / 查询样本路径（供地图工具栏「清除选区」与后续复用）
// ---------------------------------------------------------------------------

/**
 * 绘制图形清除信号（自增计数）。
 * WHY 用信号而非直接持有 draw 实例：GeoMap 是通用组件、不感知业务 state，
 * 「重置 / 清除」动作却由查询面板 wrapper 发起，二者跨组件层级；沿用 drawTool
 * 由 prop 驱动 GeoMap 的既有模式，由 map/index.vue 转发、GeoMap watch 后调 draw.clear()。
 */
export const drawClearSignal = ref(0);
export function clearDrawGraphics() {
  drawClearSignal.value += 1;
}

interface SelectableRow {
  id: number;
  path: string;
}

/**
 * 本轮查询结果池：条件查询命中行 + 空间查询命中要素，统一成 { id, path } 并去重。
 * WHY 必须并入 hitFeatures：条件查询写 results、空间查询写 hitFeatures 且互相清空，
 * 只认 results 会让基于结果池的操作在所有空间查询（绘制 / 图号 / 坐标 / 区划 / 缓冲区）
 * 之后作用于空集。两处 id 都来自 hashId(resourceUid)，数字口径一致。
 */
function activeSamples(): SelectableRow[] {
  if (!sampleQuery.searched) return [];
  const rows = (sampleQuery.results ?? []).map((r: any) => ({ id: Number(r.id), path: String(r.path ?? '') }));
  const hits = (queryState.hitFeatures ?? []).map((f: any) => ({
    id: Number(f?.id),
    path: String(f?.properties?.resourceUid ?? f?.resourceUid ?? '')
  }));
  const seen = new Set<number>();
  const pool: SelectableRow[] = [];
  for (const item of [...rows, ...hits]) {
    if (Number.isNaN(item.id) || seen.has(item.id)) continue;
    seen.add(item.id);
    pool.push(item);
  }
  return pool;
}

/**
 * 清除选区勾选：只清空 selectedIds，保留查询结果（hitFeatures / results 不动）。
 * 由地图工具栏「清除选区与绘制图形」调用（见 map/index.vue），评审 I-04 删除了
 * 「查询结果选择」区块后，这里仍须保留给地图选区联动使用；与 clearQuerySelection 的
 * 「清场」语义区分：后者连 hitFeatures / lastArea / shape 一起清。
 */
export function clearSampleSelection() {
  queryState.selectedIds = [];
  return 0;
}

/** 当前选中样本的存储路径（在本轮查询结果池里筛，空间要素用 resourceUid 兜底） */
export function selectedSamplePaths() {
  const selected = new Set(queryState.selectedIds);
  return activeSamples()
    .filter((item) => selected.has(item.id))
    .map((item) => item.path)
    .filter(Boolean);
}

/** 查询选项是否已加载（面板可据此显示加载态） */
export const queryOptionsReady = computed(() => categoryOptions.value.length > 0);
