<script setup lang="ts">
import SharedQueryPanel from '@/views/product-manage/shared/map/query/panel.vue';
import SampleQuery from './sample-query-primary.vue';

/** 数据查询面板（薄 wrapper）：位置与查询表单由本产品线提供，外壳走 SharedQueryPanel */
const open = defineModel<boolean>('open', { default: true });
</script>

<template>
  <SharedQueryPanel v-model:open="open" placement="top-left">
    <SampleQuery />
  </SharedQueryPanel>
</template>
