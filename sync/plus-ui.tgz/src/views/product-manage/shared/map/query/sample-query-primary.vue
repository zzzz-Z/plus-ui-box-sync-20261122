<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
import { ElMessage } from 'element-plus';
import SharedSampleQuery from '@/views/product-manage/shared/map/query/sample-query.vue';
import type { DrawTool } from './state';
import {
  categoryTree,
  clearQuerySelection,
  clearDrawGraphics,
  loadQueryOptions,
  resetSampleQuery,
  runBufferQuery,
  runCoordQuery,
  runSampleQuery,
  sampleQuery,
  setDrawTool,
  runAdminDivisionQuery,
  runFileQuery
} from './state';

/**
 * 初级产品 · 数据查询面板（薄 wrapper）
 *
 * 公共骨架（关键词检索 / 空间几何检索 / 底部按钮）走 SharedSampleQuery；
 * 本 wrapper 只提供分类条件字段（产品类别，置于面板最下方）与各查询动作的真实调用。
 * 图号检索走数据字典「矢量组网」，数据版本已去除。
 *
 * 数据来源全部为真实接口（详见 ./state.ts 顶部注释）：
 *   - 产品类别 ← GET /platform/product-categories
 *   - 条件查询 / 空间查询 / 坐标 / 缓冲区 → POST /platform/metadata-records/query 统一查询 + 真实 geojson
 *
 * 表单类名（q-row / q-label / q-control）的样式由 SharedSampleQuery 以 :deep 统一提供，本文件零表单样式。
 */
const bufferTargets = ['5 公里', '10 公里', '25 公里'];

const drawTool = computed<string>({
  get: () => sampleQuery.drawTool,
  set: (tool) => setDrawTool(tool as DrawTool)
});

/** 下拉选项：真实接口；面板首次挂载拉一次，之后复用 */
onMounted(() => {
  void loadQueryOptions();
});

const categoryValue = computed({
  get: () => sampleQuery.categoryUid,
  set: (v: string) => {
    sampleQuery.categoryUid = v || '';
  }
});

async function onQuery() {
  // 图号关键词与产品类别全空时不发起全表查询（runSampleQuery 内另有同样的守卫兜底）
  if (!String(sampleQuery.keyword ?? '').trim() && !sampleQuery.categoryUid) {
    ElMessage.warning(pt('请设置图号关键词或选择产品类别后再查询'));
    return;
  }
  try {
    const count = await runSampleQuery();
    ElMessage.success(count ? `条件查询完成，命中 ${count} 条资源` : pt('条件查询完成，没有命中的资源'));
  } catch {
    ElMessage.error(pt('条件查询失败，请稍后重试'));
  }
}

/** 骨架实例：重置时清空其内部自持的图号 / 坐标 / 行政区划输入 */
const sharedQueryRef = ref<{ clearInputs: () => void } | null>(null);

function onReset() {
  resetSampleQuery();
  clearQuerySelection();
  clearDrawGraphics();
  sharedQueryRef.value?.clearInputs();
  ElMessage.info(pt('已重置查询条件、选择与绘制图形'));
}

/** 缓冲区：对「上一次查询范围」做缓冲，半径取自预设档位文案或手工输入的公里数 */
async function onBuffer(target: string | number) {
  const radius = Number(String(target).replace(/[^\d.]/g, '')) || 5;
  const res = await runBufferQuery(radius);
  if (res.error) {
    ElMessage.warning(res.error);
    return;
  }
  ElMessage.success(`已在原范围外扩 ${radius} 公里，命中 ${res.count} 个图层要素`);
}

async function onCoord(value: string) {
  try {
    const res = await runCoordQuery(value);
    if (res.error) {
      ElMessage.warning(res.error);
      return;
    }
    ElMessage.success(`坐标范围内命中 ${res.count} 个图层要素`);
  } catch {
    ElMessage.error(pt('坐标查询失败，请稍后重试'));
  }
}

async function onRegion(uid: string) {
  try {
    const res = await runAdminDivisionQuery(uid);
    if (res.error) {
      ElMessage.warning(res.error);
      return;
    }
    ElMessage.success(`行政区划「${res.regionName}」范围内命中 ${res.count} 个图层要素`);
  } catch {
    ElMessage.error(pt('行政区划查询失败，请稍后重试'));
  }
}

async function onFile(file: File) {
  try {
    const res = await runFileQuery(file);
    if (res.error) {
      ElMessage.warning(res.error);
      return;
    }
    ElMessage.success(`文件「${res.fileName}」解析 ${res.pointCount} 个坐标点，范围内命中 ${res.count} 个图层要素`);
  } catch {
    ElMessage.error(pt('文件导入查询失败，请稍后重试'));
  }
}
</script>

<template>
  <SharedSampleQuery
    ref="sharedQueryRef"
    v-model:draw-tool="drawTool"
    :buffer-targets="bufferTargets"
    @reset="onReset"
    @query="onQuery"
    @buffer="onBuffer"
    @coord="onCoord"
    @region="onRegion"
    @file="onFile"
  >
    <!-- 分类条件：只提供字段行——卡片外壳、标题与展开/收起由 SharedSampleQuery 负责；
         类名契约（q-row / q-label / q-control）由骨架 :deep 统一样式，本文件零表单样式。
         下拉面板高度统一走 popper-class="q-select-popper"（EP 的选项行写死 34px，需压到 24px 与选择框齐高）。 -->
    <div class="q-row">
      <span class="q-label">{{ pt('产品类别') }}</span>
      <div class="q-control">
        <!-- WHY 树形：接口 /platform/product-categories 返回 categoryUid + parentCategoryUid 的真实层级，
             平铺下拉会把子类别和父类别排成一列、看不出归属；这里按接口 tree 展示。
             check-strictly：父节点本身也是可选类别（后端 categoryUid 过滤支持父级），勾选不与子级联动。
             render-after-expand=false：折叠状态下也渲染全部节点，否则 el-tree-select 查不到深层节点的显示名。 -->
        <el-tree-select
          v-model="categoryValue"
          size="small"
          popper-class="q-select-popper"
          :placeholder="pt('全部')"
          clearable
          filterable
          check-strictly
          default-expand-all
          :render-after-expand="false"
          :data="categoryTree"
          :props="{ label: 'name', children: 'children' }"
          node-key="uid"
          :loading="!categoryTree.length"
        />
      </div>
    </div>
  </SharedSampleQuery>
</template>
