<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
import { Close } from '@element-plus/icons-vue';

/**
 * 地图查询面板外壳（初级产品 / 产品成果共用）
 *
 * 只承担面板容器与标题栏；查询表单由调用方通过默认插槽注入各自的 SampleQuery，
 * 因两侧查询条件与数据源不同（初级产品按类别/版本/区划；产品成果按结果类型/归档状态）。
 * 位置差异走 placement：默认贴地图左上角（top-left），产品成果可改右下角（bottom-right）。
 *
 * WHY 默认改到左上角：用户明确要求「搜索框放到左侧靠边」。左上角是 GeoMap 里唯一未被
 * 占用的角落 —— 右上角是 maplibre 原生控件竖条 + 图例（LayerControl 也在 right:46px），
 * 右下角是自定义工具栏，左下角是比例尺；面板放左上不会压住任何可点控件。
 */
const open = defineModel<boolean>('open', { default: true });
defineProps<{ placement?: 'top-left' | 'top-right' | 'bottom-right' }>();
</script>

<template>
  <div v-if="open" class="query-panel" :class="`query-panel--${placement ?? 'top-left'}`">
    <div class="qp-header">
      <span class="qp-title">{{ pt('数据查询') }}</span>
      <el-tooltip :content="pt('收起面板')" placement="left" :show-after="150">
        <el-button class="qp-close" link :icon="Close" :aria-label="pt('收起查询面板')" @click="open = false" />
      </el-tooltip>
    </div>
    <div class="qp-body">
      <slot />
    </div>
  </div>
</template>

<style scoped lang="scss">
.query-panel {
  position: absolute;
  z-index: 5;
  display: flex;
  flex-direction: column;
  width: 380px;
  /* WHY max-width：面板停在地图右缘内缩「控件竖条 + 图例」之后，窄屏（地图宽 < 约 620px）时
     固定 380px 会顶出地图左沿。这里只在真的放不下时才收窄，宽屏下仍是 380px 原宽。
     兜底值与 .query-panel--top-right 的偏移量同源，改图例宽度只需改 GeoMap 的 token。 */
  max-width: calc(100% - var(--map-ctrl-rail, 52px) - var(--map-legend-w, 176px) - 16px);
  max-height: calc(100% - 44px);
  overflow: hidden;
  /* 与图例 / 地图气泡统一的玻璃表面 */
  background: rgb(255 255 255 / 96%);
  border: 1px solid rgb(31 55 84 / 10%);
  border-radius: 8px;
  box-shadow: 0 6px 18px rgb(25 45 70 / 14%);
  backdrop-filter: blur(8px);
  box-sizing: border-box;
}

/* 位置差异：两产品线占位不同，走 modifier 而非业务分支。
   WHY 两级偏移都读 GeoMap 声明的 token：
   - --map-ctrl-rail：右上角 maplibre 原生控件竖条（缩放 / 指北 / 全屏，约 42px），面板贴边会把它压住
     —— 实测 elementFromPoint 命中的是面板里的 .q-section 而不是全屏按钮，连「退出全屏」都点不到；
   - --map-legend-w：图例（legend.vue）改为右侧停靠后，面板再停在它左侧，两者并排不互相遮挡。
     顺序自地图右缘向左：原生控件竖条 → 图例 → 查询面板。
   兜底值走同值：面板被单独引用（不经 GeoMap）时仍落在原来的 right:52px 位置。 */
.query-panel--top-left {
  /* 贴地图左沿：左上角在 GeoMap 里是唯一空闲的角落（右上=原生控件+图例，右下=工具栏，左下=比例尺） */
  top: 8px;
  left: 8px;
  /* 左贴时右侧没有控件竖条/图例要避让，只留边距即可，否则窄屏下会被基础规则的 calc 过度收窄 */
  max-width: calc(100% - 16px);
}
.query-panel--top-right {
  top: 4px;
  right: calc(var(--map-ctrl-rail, 52px) + var(--map-legend-w, 176px) + 8px);
}
.query-panel--bottom-right {
  bottom: 26px;
  right: 58px;
}

.qp-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 7px 8px 7px 12px;
  background: rgb(246 249 253 / 96%);
  border-bottom: 1px solid rgb(31 55 84 / 8%);
}
.qp-title {
  display: flex;
  align-items: center;
  gap: 6px;
  color: #172b4d;
  font-size: 13px;
  font-weight: 600;
}
.qp-title::before {
  width: 3px;
  height: 12px;
  background: #2563eb;
  border-radius: 2px;
  content: '';
}
.qp-close {
  color: #8a97a8;
}
.qp-close:hover {
  color: #2563eb;
  background: rgb(37 99 235 / 8%);
}
.qp-body {
  /* WHY flex 列 + flex:1 + overflow:hidden：滚动已下沉到查询表单内部的 .q-scroll，
     底部操作条因此永远固定在面板底部（不随字段滚走、也不被折叠状态影响位置）。
     早先此处自己是滚动容器，并靠 padding-bottom:40px 给绝对定位的操作条留位，两处都已移除。 */
  display: flex;
  flex: 1;
  flex-direction: column;
  min-height: 0;
  padding: 10px;
  overflow: hidden;
}
</style>
