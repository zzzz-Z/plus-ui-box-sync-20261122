/**
 * 点击地图要素 → 详情弹窗（公共能力的监听部分）。
 *
 * WHY 抽到这里而不是各业务模块自己绑：地图上有两条完全不同的图层通道，业务模块只知道自己那条，
 * 「点要素看详情」却是所有模块的共同诉求 —— 写在各模块里必然四份实现、四种样式。
 *
 * 通道一：MVT 瓦片（vector-tile-layer.ts 的 mountVectorTileLayer，data-browse / data-query / records-edit 在用）
 *   `map.on('click')` 拿到的只有渲染层 id（`mvt-fill-xxx`），必须靠 findMountedVectorTileByLayerId
 *   反查回挂载时的 key（`${resourceUid}:${tableKey}`），身份才能还原。本文件的公共监听自动覆盖这条通道，
 *   三个模块无需任何改动。
 *
 * 通道二：GeoJSON 图层组（useMap().createLayerGroup / renderLayers，data-query / data-into-store 在用）
 *   source/layer id 由 useMapResource.genId() 随机生成，与业务身份无关、无法反查；
 *   而地图上同时还有离线底图、网格底衬等「不该弹详情」的 geojson 图层，
 *   全量 queryRenderedFeatures 会把它们一起命中。
 *   ⇒ 这条通道由调用方在自己的 onFeatureClick 里调 openFeatureDetail(payload) 显式触发。
 *
 * 两条通道最终都落到 attribute-row-dialog.vue（全项目唯一的一份「看一条记录的全部字段」视图）。
 */
import type { Map as MapLibreMap, MapGeoJSONFeature, MapMouseEvent } from 'maplibre-gl';
import { getCurrentInstance, onScopeDispose, watch } from 'vue';
import { openFeatureDetail, type FeatureDetailPayload } from './feature-detail-dialog';
import { useMap } from './use-map';
import { findMountedVectorTileByLayerId, listMountedVectorTileLayerIds } from './vector-tile-layer';
import { sampleQuery } from './query/state';
import { collectMvtFeatureGeometry } from './mvt-feature-geometry';

/** 从 MVT 命中结果里还原出一次详情请求（命中多图层时只取第一个，避免同一位置叠开多个弹窗） */
function payloadFromFeature(feature: MapGeoJSONFeature): FeatureDetailPayload | null {
  const info = findMountedVectorTileByLayerId(String((feature as any).layer?.id ?? ''));
  if (!info) return null;
  // key 形如 `${resourceUid}:${tableKey}`；tableKey 自身不含冒号，故从最后一个冒号切
  const i = info.key.lastIndexOf(':');
  const resourceUid = i > 0 ? info.key.slice(0, i) : info.key;
  const tableKey = i >= 0 ? info.key.slice(i + 1) : '';
  return {
    values: (feature.properties ?? {}) as Record<string, unknown>,
    tags: [info.label],
    resourceUid,
    tableKey,
    geometryType: String((feature as any).geometry?.type ?? ''),
    // 命中图斑的原始几何：地图 → 列表联动画高亮边框时用（比外接矩形更贴合）
    geometry: (feature as any).geometry
  };
}

/**
 * 在地图容器上挂一次性监听，覆盖所有 MVT 瓦片图层。
 * 在 shared/map/index.vue 里调用一次即可，所有走 MVT 通道的业务模块自动具备点击详情。
 */
export function useFeatureDetail() {
  const map = useMap();
  let boundMap: MapLibreMap | null = null;
  // 本 composable 在 setup 内调用，此处实例即宿主组件：透传给抽屉当 owner，
  // 让「点要素弹出的详情」也跟着页面卸载一起销毁（onMapClick 是地图回调，那时没有 currentInstance）
  const owner = getCurrentInstance();
  // KeepAlive 下缓存页的 Map 不会解绑 click，map 单例上的一次物理点击会唤醒所有副本；
  // 只让「自身 DOM 真正可见」的这份响应，避免被 openFeatureDetail 的 600ms 去重抢先。
  // DOM 判据比 KeepAlive 生命周期钩子可靠：缓存页被移进 storageContainer 后 isConnected=false / 无矩形。
  function isHostVisible() {
    const el = (owner?.proxy?.$el ?? owner?.vnode?.el) as HTMLElement | null | undefined;
    if (!el?.isConnected) return false;
    return typeof el.getClientRects === 'function' && el.getClientRects().length > 0;
  }

  function onMapClick(e: MapMouseEvent) {
    if (!isHostVisible()) return;
    // 绘制工具进行中不抢点击：此时点击是「落点」，不是「选要素」
    if (sampleQuery.drawTool !== 'none') return;
    // Shift 在地图上承担多选语义（data-query 的加选），弹窗会打断这个操作
    if ((e.originalEvent as MouseEvent | undefined)?.shiftKey) return;
    const m = map.mapInstance.value;
    if (!m) return;

    const layerIds = listMountedVectorTileLayerIds();
    // CONSTRAINT 空数组必须直接 return：maplibre 把空 layers 当作「不传」，
    // 会退化成查全图所有图层（连底图道路都会命中）
    if (!layerIds.length) return;

    let features: MapGeoJSONFeature[] = [];
    try {
      features = m.queryRenderedFeatures(e.point, { layers: layerIds });
    } catch {
      // 图层刚被卸载 / style 正在切换：本次点击直接放弃
      return;
    }
    if (!features.length) return;

    const payload = payloadFromFeature(features[0]);
    if (!payload) return;
    // 瓦片裁切会把同一条记录拆成多个片段：按 metadata_uid / feature.id 聚合已加载瓦片里的全部片段，
    // 合并成完整几何再进交互层。基础 MVT 图层不动；聚合失败时保留原命中片段，功能降级不中断。
    let geometry: unknown = payload.geometry;
    try {
      geometry = collectMvtFeatureGeometry(m, features[0]) ?? geometry;
    } catch {
      /* 合并失败：维持原片段几何 */
    }
    openFeatureDetail({ ...payload, geometry, event: e.originalEvent, owner });
  }

  /**
   * 绑定切图监听。
   * WHY 用 watch 而非 onMounted：地图实例由 GeoMap 创建后经 @ready 写进 useMap 单例，
   * 本组件与它是兄弟节点，挂载时序不保证 —— onMounted 里绑一次会在地图后到时静默失效。
   */
  function syncBinding() {
    const next = map.mapInstance.value ?? null;
    if (boundMap === next) return;
    if (boundMap) boundMap.off('click', onMapClick);
    boundMap = next;
    if (boundMap) boundMap.on('click', onMapClick);
  }

  watch(() => map.mapInstance.value, syncBinding, { immediate: true });

  onScopeDispose(() => {
    if (boundMap) boundMap.off('click', onMapClick);
    boundMap = null;
  });
}
