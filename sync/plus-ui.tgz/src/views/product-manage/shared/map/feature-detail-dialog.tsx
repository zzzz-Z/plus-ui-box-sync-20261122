/**
 * 地图要素详情弹窗入口（两条图层通道共用）。
 *
 * WHY 与 use-feature-detail.ts 分开：本文件只负责「把一份要素数据渲染成详情弹窗」，
 * 被 use-map.ts 的图层点击、各业务模块的 onFeatureClick、以及 MVT 全局监听共用；
 * 而 use-feature-detail.ts 需要 import useMap（地图单例），若本文件也 import 它就会形成循环依赖。
 *
 * 展示落到 attribute-row-dialog.vue —— 全项目唯一的一份「看一条记录的全部字段」视图，
 * 与属性表的「记录详情」完全同一套展示（复制 / 长值折叠 / 中文列名 / 重要字段优先的顺序）。
 *
 * WHY 与列表详情保持三处一致：标题、字段顺序（收口在 attribute-row-dialog.vue 统一排）、
 * 纵向形态（与属性表「记录详情」共用布局右侧 .pane-record 真实占位列，打开时把地图与列表
 * 挤向中心，而不是悬浮遮挡）—— 用户「点图层」和「点列表行」应当是同一个详情视图，
 * 只是触发来源不同。没有布局注册宿主的独立挂载场景（如 __debug 单挂地图）取不到占位列，
 * 自动回落为旧的右侧非模态抽屉（锚点解析见 detail-drawer-anchor.ts）。
 */
import type { ComponentInternalInstance } from 'vue';
import type { MetadataAttributeColumn, MetadataAttributeRecord } from '@/api/product-manage/platform/metadata-attributes';
import { listResourceAttributes, localizeFieldLabel, resolveAttributeColumns } from '@/api/product-manage/platform/metadata-attributes';
import { getMetadataRecordDetail } from '@/api/product-manage/platform/metadata-records';
import AttributeRowDialog from '@/views/product-manage/shared/attribute-row-dialog.vue';
import { findPaneRightAnchor } from '@/views/product-manage/shared/detail-drawer-anchor';
import { showRecordDetail } from '@/views/product-manage/shared/record-detail-host';
import { selectFeature } from './feature-selection';

/** 打开详情所需的最少信息：能力范围内能给多少给多少，缺的部分降级渲染 */
export interface FeatureDetailPayload {
  /** 要素属性（键值对，直接展示） */
  values: Record<string, unknown>;
  /** 头部信息片：资源名 / 表名 / 业务状态等 */
  tags?: string[];
  /**
   * 首屏列清单覆盖（可选）：调用方已持有字段中文名时直接给全，免去 localizeFieldLabel 只认系统字段的局限。
   * 典型场景：GeoJSON 业务要素（入库批次等）的 properties 是自造业务键，没有任何后端列清单可查，
   * 只能由构造要素的一方把中文表头一并交出来，否则详情会整列空白。enrich 回来后仍以权威列为准。
   */
  columns?: MetadataAttributeColumn[];
  /** 资源唯一标识：有它才能去后端补权威列清单与完整记录 */
  resourceUid?: string;
  /** 账本表键（同一资源下可能有多张表） */
  tableKey?: string;
  /** 几何类型（Point / Polygon / ...） */
  geometryType?: string;
  /** 点击命中的 GeoJSON Geometry：地图 → 列表联动时用它画精确贴合图斑的高亮边框 */
  geometry?: unknown;
  /**
   * 触发本次弹窗的原始 DOM 事件。
   * MVT 与 GeoJSON 两套图层的 click 是各自独立的监听器，同一位置同时有两者时会各触发一次；
   * 同一个物理点击带同一个事件对象，据此去重，避免叠开两个一样的弹窗。
   */
  event?: unknown;
  /**
   * 调用方组件实例（可选）：透传给 createDrawer 的 owner，让抽屉随该组件卸载一起销毁。
   *
   * WHY 要从调用方传：本文件是纯函数，没有组件上下文，`getCurrentInstance()` 永远是 null。
   * 调用方在 setup 顶层存一份 `const owner = getCurrentInstance()` 再交进来即可。
   * 不传时行为退化为「仅随路由切换销毁」。
   */
  owner?: ComponentInternalInstance | null;
}

/** enrich 的返回形状，与 attribute-row-dialog.vue 的 AttributeRowEnrich 一致（无需跨文件引类型） */
interface FeatureDetailEnrich {
  row?: Partial<MetadataAttributeRecord>;
  columns?: MetadataAttributeColumn[];
  tags?: string[];
}

/**
 * 补一次权威数据：瓦片属性只有后端塞进瓦片的那部分字段，且没有中文列名。
 *
 * 两件事分别尽力而为，任一失败都不影响另一件：
 *   1. 列清单（fieldLabels → 中文列名 + 完整字段顺序）—— 走 metadata-attributes；
 *   2. 完整记录（含瓦片里被裁掉的字段）—— 需要 metadata_uid，走 metadata-records。
 * 没有 resourceUid 就直接放弃（GeoJSON 要素常常只有业务键，认不出是哪张表）。
 */
async function enrichFeatureDetail(payload: FeatureDetailPayload, values: Record<string, unknown>): Promise<FeatureDetailEnrich | null> {
  const resourceUid = String(payload.resourceUid ?? '').trim();
  if (!resourceUid) return null;
  const tableKey = String(payload.tableKey ?? '').trim();
  const metadataUid = String(values?.metadata_uid ?? '').trim();

  const [columnResult, detailResult] = await Promise.allSettled([
    // pageSize 取 1：只要列清单（fieldLabels），不关心数据行
    listResourceAttributes(resourceUid, { tableKey: tableKey || undefined, page: 1, pageSize: 1 }),
    tableKey && metadataUid ? getMetadataRecordDetail(resourceUid, tableKey, metadataUid) : Promise.reject(new Error('缺少 tableKey / metadata_uid'))
  ]);

  const out: FeatureDetailEnrich = {};

  if (columnResult.status === 'fulfilled') {
    const data = columnResult.value?.data;
    const columns = resolveAttributeColumns(data);
    if (columns.length) out.columns = columns;
    // 表名比瓦片里的图层 label 更权威（label 是挂载时由业务侧拼的）
    const tableName = String(data?.displayName || data?.layerName || '').trim();
    if (tableName) out.tags = [tableName];
  }

  if (detailResult.status === 'fulfilled') {
    const detail = detailResult.value?.data;
    const full = detail?.values ?? detail?.normalizedValues;
    if (full && typeof full === 'object') out.row = { tableKey, pgTable: '', values: full as Record<string, unknown> };
  }

  return out.columns || out.row || out.tags ? out : null;
}

/** 同一次物理点击的去重窗口（两条通道的 click 回调几乎同时到达） */
let lastEvent: unknown = null;
let lastEventAt = 0;

/**
 * 打开要素详情：统一写进布局右侧的记录详情占位列；没有宿主时回落为抽屉。
 *
 * WHY 用 createDrawer 而不是 createDialog：要素属性常有几十列，居中弹窗的遮罩会把整张地图压住，
 * 用户点完还想看旁边那块地；右侧非模态抽屉不压暗、不锁滚动，地图与列表仍可点击。
 *
 * WHY 不用地图 Popup 气泡：气泡（max-width 240px）放不下几十列，而且会挡住点击位置附近的要素。
 */
export function openFeatureDetail(payload: FeatureDetailPayload) {
  const now = Date.now();
  if (payload.event != null && payload.event === lastEvent && now - lastEventAt < 600) return;
  if (payload.event != null) {
    lastEvent = payload.event;
    lastEventAt = now;
  }

  // 地图 → 列表联动：所有点击通道都汇合到这里，广播一次选中态；
  // 属性表 watch 后写 locatedRows，同时驱动地图高亮边框与列表行选中态。
  selectFeature({
    values: payload.values ?? {},
    resourceUid: payload.resourceUid,
    tableKey: payload.tableKey,
    geometry: payload.geometry,
    geometryType: payload.geometryType
  });

  const values = payload.values ?? {};
  const row: MetadataAttributeRecord = { tableKey: String(payload.tableKey ?? ''), pgTable: '', values };
  // 首屏列：拿不到后端列清单，先用系统字段中文名顶上（业务字段名等 enrich 回来再替换）
  const columns: MetadataAttributeColumn[] = payload.columns?.length
    ? payload.columns
    : Object.keys(values).map((key) => ({ key, label: localizeFieldLabel(key) }));
  const tags = [...(payload.tags ?? []), payload.geometryType].map((t) => String(t ?? '').trim()).filter(Boolean);

  // 与属性表详情走同一个宿主：内容写进布局的 .pane-record 占位列，
  // tags / enrich 一并带上，面板重挂时补齐中文列名与瓦片里裁掉的字段。
  if (showRecordDetail({ row, columns, tags, enrich: () => enrichFeatureDetail(payload, values) })) return;

  // 独立挂载（没有布局注册的宿主）：回落为原来的非模态抽屉
  createDrawer({
    // 标题与列表详情一致：同一个「看一条记录全部字段」的视图，不因触发入口改名
    title: '记录详情',
    // 与列表详情同高：从地图上沿贯穿到页面底部（右侧整列），解析见 detail-drawer-anchor.ts；
    // 页面没有属性表（如入库页）时取不到，自动退回视口全高
    anchor: findPaneRightAnchor,
    // 随调用方页面卸载销毁（页面没传 owner 时退化为仅随路由切换销毁）
    owner: payload.owner,
    render: () => <AttributeRowDialog row={row} columns={columns} tags={tags} enrich={() => enrichFeatureDetail(payload, values)} />
  });
}
