import type { LngLatLike } from 'maplibre-gl';
import * as maplibregl from 'maplibre-gl';
import type { Ref, VNode } from 'vue';
import { computed, effectScope, isRef, ref, render, shallowRef, watch } from 'vue';
import { createSharedComposable } from '@vueuse/core';
import type { useMapResource } from '@/components/product-manage/geo-map/use-map-resource';
import { MAP_SELECTION, MAP_UNSELECTED_LINE } from '@/components/product-manage/geo-map/selection-style';

// =============================================================================
// 一、图层组函数（每份实例独立，由单例内部创建）
// =============================================================================

/**
 * 单个业务图层组的选项。
 * 所有字段均为响应式 Ref，图层组内部 watch 后自行同步到 maplibre。
 */
export interface MapLayerOptions {
  features: Ref<any[]>;
  colorKey: Ref<string>;
  palette: Ref<Record<string, string>>;
  selectedIds: Ref<number[]>;
  hiddenIds: Ref<number[]>;
  progressFeatures: Ref<any[]>;
  labelKey: Ref<string>;
  /**
   * 炫酷双行标签：打开后 text-field 自动尝试 properties.labelTitle / labelBadge，
   * 用 maplibre format 表达式渲染「粗体标题 + 小号徽标」；缺少字段时回落原 label 单行。
   */
  richLabel?: Ref<boolean>;
  cluster: Ref<boolean>;
  clusterAnchor: Ref<'corner' | 'center'>;
  fit: Ref<boolean>;
  hover: Ref<boolean>;
  /**
   * 悬浮弹窗内容：
   * - 返回字符串：作为纯文本展示；
   * - 返回 VNode：走 vue render 渲染；
   * - 返回 null / undefined：本次不弹。
   * 未提供时走默认 name + createTime 兜底。
   */
  hoverContent?: (properties: Record<string, any>) => VNode | string | null | undefined;
  popup?: Ref<((properties: Record<string, any>) => VNode | null) | undefined>;
  onFeatureClick?: (feature: any, originalEvent: any) => void;
  /** 复用 useMapResource 的 popup 工厂（由单例的 utils 提供） */
  createPopup?: (node: VNode, lngLat: LngLatLike) => void;
}

export interface MapLayerApi {
  /** 地图 load 或 style.load 后调用，创建所有业务图层 */
  attach: () => void;
  /**
   * 切换底图前调用：清空图层 id 缓存。
   * CONSTRAINT 不删地图上的 source/layer —— 因为 setStyle 会自己清掉；
   * 需要真正从地图上移除请用 destroy()。
   */
  detach: () => void;
  /** 真正从地图移除本组的所有 source/layer 并清缓存（tab 切换 / 组件卸载用） */
  destroy: () => void;
  applyState: () => void;
  applyPalette: () => void;
  applyProgress: () => void;
  applyLabel: () => void;
}

/**
 * 创建一个业务图层组。
 * CONSTRAINT 每次调用返回独立实例，内部 id 由 useMapResource.genId 唯一化，
 * 多个图层组挂到同一张地图上不会互相覆盖（各自 watch 只影响自己的 source / layer）。
 */
export function useMapLayers(getUtils: () => ReturnType<typeof useMapResource> | undefined, options: MapLayerOptions): MapLayerApi {
  let polygonSourceId = '';
  let clusterSourceId = '';
  let fillLayerId = '';
  let lineLayerId = '';
  /**
   * 选中 halo 层（白色粗描边垫在彩色选中线下面）。
   * WHY 多加一层而不是把 line-width 拉大：类别配色表有 4 套方案，冷色方案里本身就有好几个蓝，
   * 「选中蓝」单独出现时仍可能与某个类别填充撞色；白色垫边在任何底色上都能把选中项抠出来。
   */
  let haloLayerId = '';
  let progressSourceId = '';
  let progressLayerId = '';
  let labelSourceId = '';
  let labelLayerId = '';
  /**
   * source 引用（用于 destroy 真正移除地图资源）：
   * useMapResource.createSource 返回对象自带 clear()，会一并 removeLayer + removeSource + 清内部 sources 表。
   * detach 只清 id 缓存不清地图，故 destroy 必须持有这些引用。
   */
  let polygonSource: any = null;
  let progressSource: any = null;
  let labelSource: any = null;
  let clusterSource: any = null;
  /**
   * 本组创建的所有 source / layer id。
   * WHY destroy 需要精确 removeLayer/removeSource，不依赖 useMapResource.clear() 的行为，
   * 也不依赖 source 引用是否还在；直接按 id 从 map 上摘除，最稳。
   * CONSTRAINT attach 开始时清空——旧 id 已被 setStyle 清掉，不应重复尝试。
   */
  const ownedSourceIds: string[] = [];
  const ownedLayerIds: string[] = [];
  let hoverPopup: maplibregl.Popup | null = null;
  let lastSignature = '';
  /**
   * richLabel 白底标签用 MapLibre 原生 Marker 渲染（element 是普通 DOM，位置随地图缩放平移自动跟随）。
   * WHY 不用 canvas symbol：MapLibre GL JS v6 不支持 text-background-* / text-border-*（Mapbox 专有），
   * 写进 paint 会让 addLayer 直接抛错、整张地图样式加载失败（E2E 实测 console.error）。
   */
  const labelMarkers: maplibregl.Marker[] = [];
  let lastLabelSignature = '';

  /**
   * 聚合展开阈值：zoom >= CLUSTER_MAX_ZOOM 时聚合完全展开（每个矩形单独可见）。
   * 与下方 cluster source 的 clusterMaxZoom 保持一致，集中在一处避免两处不同步。
   */
  const CLUSTER_MAX_ZOOM = 9;

  /**
   * 图层显示门槛：cluster 开启时返回 minzoom（zoom >= 门槛才显示图层），
   * cluster 关闭时返回空对象（图层始终显示）。
   * WHY 用 layer.minzoom 而非 paint 表达式：maplibre 的 layer 原生支持 minzoom，
   * 无需把 paint 表达式嵌 case（后者在部分版本下解析会失败导致整层不可见）。
   * minzoom = CLUSTER_MAX_ZOOM - 1：故意比 clusterMaxZoom 低 1 档。
   * WHY：maplibre 图层 minzoom 是「zoom >= 该值」才可见，而 cluster 展开判定发生在
   * zoom > clusterMaxZoom；若两者同档，聚合散开与矩形重绘之间仍存在一帧空窗。
   * 提前一档让矩形在聚合尚未散开时就已就位，聚合散开的瞬间矩形已在画布上，
   * 用户感知不到「聚合消失 → 矩形出现」的断层。
   * CONSTRAINT 低 zoom 时聚合圆会与矩形叠加，属可接受代价（圆在矩形中心，
   * 语义上即「此处有多条记录」）。
   */
  function layerZoomGate() {
    return options.cluster.value ? { minzoom: CLUSTER_MAX_ZOOM - 1 } : {};
  }

  /**
   * symbol 图层 text-field 表达式。
   * richLabel 打开时用 format 表达式把两行拼在一起：标题按 text-size 原号、徽标按 0.82 缩放，
   * 选中行靠 text-halo 发光（applyLabelRichState 按 selectedIds 切换 halo 颜色/宽度）。
   * 其它图层组（数据浏览 / 元数据检查 / 更新）没开 richLabel，继续走原 ['get', labelKey]，零回归。
   */
  function labelFieldExpression(): any {
    if (!options.richLabel?.value || !options.labelKey.value) return options.labelKey.value ? ['get', options.labelKey.value] : '';
    const fallback = ['get', options.labelKey.value] as any;
    const title = ['get', 'labelTitle'] as any;
    const badge = ['get', 'labelBadge'] as any;
    // [why] 最终 UI 标签左侧带状态圆点：未选中绿点(#52c41a)、选中白点(#fff)。
    // 圆点颜色走 format section 的 text-color（按 feature id 是否在 selectedIds 判断），随选中态切换。
    const selected = ['in', ['id'], ['literal', options.selectedIds.value]] as any;
    const dotSection: any[] = ['● ', { 'text-color': ['case', selected, '#ffffff', '#52c41a'] }];
    return [
      'case',
      ['all', ['has', 'labelTitle'], ['has', 'labelBadge']],
      ['format', ...dotSection, title, { 'font-scale': 1 }, '\n', ' ', {}, badge, { 'font-scale': 0.82 }],
      ['format', ...dotSection, fallback, {}]
    ];
  }

  function featureCollection(features: any[]) {
    return { type: 'FeatureCollection', features };
  }

  function clusterPoint(feature: any) {
    const coords = feature?.geometry?.coordinates?.[0];
    if (!Array.isArray(coords) || !coords.length) return [116.4, 39.9];
    if (options.clusterAnchor.value === 'corner') return coords[0];
    const lngs = coords.map((p: number[]) => p[0]);
    const lats = coords.map((p: number[]) => p[1]);
    return [(Math.min(...lngs) + Math.max(...lngs)) / 2, (Math.min(...lats) + Math.max(...lats)) / 2];
  }

  function colorExpression() {
    const entries = Object.entries(options.palette.value ?? {});
    // [why] maplibre 的 match 表达式至少需要 4 个参数（input + 1 组 label/output + fallback）；
    // palette 为空时 entries.flat() 长度为 0，表达式退化为 3 参数，运行时报错。
    // 此场景下改用常量色，交给 fill-outline-color / line-color 做视觉区分即可。
    if (!entries.length) return '#cccccc';
    return ['match', ['get', options.colorKey.value], ...entries.flat(), '#cccccc'];
  }

  function opacityExpression() {
    // [why] 最终 UI 用「选中淡蓝发光 + 未选中更淡」区分状态：图斑填充只做淡染，
    // 不能像旧版 0.85 那样糊住底图/相邻图斑；真正的选中强调交给蓝色描边 + 白色 halo + 光晕。
    // 选中态用 MAP_SELECTION.fillOpacity(0.14)，未选中降到 0.06，隐藏仍近乎全透明。
    return [
      'case',
      ['in', ['id'], ['literal', options.hiddenIds.value]],
      0.06,
      ['in', ['id'], ['literal', options.selectedIds.value]],
      MAP_SELECTION.fillOpacity,
      0.06
    ];
  }

  function applyFillOpacity() {
    const map = getUtils()?.mapInstance.value;
    if (!fillLayerId || !map?.getLayer(fillLayerId)) return;
    map.setPaintProperty(fillLayerId, 'fill-opacity', opacityExpression() as any);
  }

  function applyLineStyle() {
    const map = getUtils()?.mapInstance.value;
    if (!lineLayerId || !map?.getLayer(lineLayerId)) return;
    const selected = ['in', ['id'], ['literal', options.selectedIds.value]] as any;
    // [why] 选中线用要素自身类别色（与 fill-color 同源 colorExpression），不再写死系统蓝；
    // 加粗 + 白色 halo 仍作为「已选中」的额外信号，避免纯靠颜色在同类图斑里认不出来。
    map.setPaintProperty(lineLayerId, 'line-color', ['case', selected, colorExpression(), MAP_UNSELECTED_LINE.color] as any);
    map.setPaintProperty(lineLayerId, 'line-width', ['case', selected, MAP_SELECTION.lineWidth, MAP_UNSELECTED_LINE.width] as any);
    if (haloLayerId && map.getLayer(haloLayerId)) {
      map.setPaintProperty(haloLayerId, 'line-width', ['case', selected, MAP_SELECTION.haloWidth, 0] as any);
    }
  }

  function applyPalette() {
    const map = getUtils()?.mapInstance.value;
    if (!map) return;
    if (fillLayerId && map.getLayer(fillLayerId)) map.setPaintProperty(fillLayerId, 'fill-color', colorExpression() as any);
    if (progressLayerId && map.getLayer(progressLayerId)) map.setPaintProperty(progressLayerId, 'fill-color', colorExpression() as any);
  }

  function applyState() {
    applyFillOpacity();
    applyLineStyle();
    applyLabelRichState();
  }

  function setSourceData(id: string, data: any) {
    const source = getUtils()?.mapInstance.value?.getSource(id) as any;
    if (source?.setData) source.setData(data);
  }

  function syncData(fitBounds: boolean) {
    const utils = getUtils();
    if (!utils?.mapInstance.value) return;
    if (polygonSourceId) setSourceData(polygonSourceId, featureCollection(options.features.value));
    if (labelSourceId) setSourceData(labelSourceId, featureCollection(options.features.value));
    if (progressSourceId) setSourceData(progressSourceId, featureCollection(options.progressFeatures.value));
    if (clusterSourceId) {
      setSourceData(
        clusterSourceId,
        featureCollection(
          options.features.value.map((feature: any) => ({
            type: 'Feature',
            geometry: { type: 'Point', coordinates: clusterPoint(feature) },
            properties: feature.properties,
            id: feature.id
          }))
        )
      );
    }
    if (fitBounds && options.features.value.length) utils.fitBounds(featureCollection(options.features.value) as any);
    if (options.richLabel?.value) syncLabelMarkers();
  }

  function featuresSignature() {
    return options.features.value.map((f: any) => `${f?.id ?? ''}:${f?.properties?.category ?? ''}`).join('|');
  }

  function applyProgress() {
    if (progressSourceId) setSourceData(progressSourceId, featureCollection(options.progressFeatures.value));
  }

  /**
   * 面要素标注锚点：Polygon/MultiPolygon 取外接矩形中心，Point 取自身坐标。
   * 与 clusterPoint 分开，避免受 clusterAnchor 影响 —— 标签始终落在矩形几何中心。
   */
  function labelAnchor(feature: any): [number, number] {
    const g = feature?.geometry;
    const c = g?.coordinates;
    if (g?.type === 'Point' && Array.isArray(c) && typeof c[0] === 'number') return [c[0], c[1]];
    const ring = g?.type === 'Polygon' ? c?.[0] : g?.type === 'MultiPolygon' ? c?.[0]?.[0] : null;
    if (Array.isArray(ring) && ring.length) {
      const lngs = ring.map((p: number[]) => p[0]);
      const lats = ring.map((p: number[]) => p[1]);
      return [(Math.min(...lngs) + Math.max(...lngs)) / 2, (Math.min(...lats) + Math.max(...lats)) / 2];
    }
    return [116.4, 39.9];
  }

  /**
   * 构造单个白底标签 DOM（绿点 + 标题 + 徽标），选中态由 applyLabelRichState 切 class。
   * 样式定义在 data-into-store/index.vue 的非 scoped style 块。
   */
  function buildLabelElement(feature: any): HTMLElement {
    const p = feature?.properties ?? {};
    const el = document.createElement('div');
    el.className = 'geo-map__label';
    const dot = document.createElement('span');
    dot.className = 'geo-map__label-dot';
    const text = document.createElement('span');
    text.className = 'geo-map__label-text';
    text.textContent = String(p.labelTitle ?? p[options.labelKey.value] ?? '');
    el.append(dot, text);
    if (p.labelBadge) {
      const badge = document.createElement('span');
      badge.className = 'geo-map__label-badge';
      badge.textContent = String(p.labelBadge);
      el.append(badge);
    }
    return el;
  }

  /** features 变化时重建 DOM Marker；位置交给 MapLibre 随地图缩放平移自动跟随。 */
  function syncLabelMarkers() {
    const map = getUtils()?.mapInstance.value;
    labelMarkers.forEach((m) => m.remove());
    labelMarkers.length = 0;
    if (!options.richLabel?.value || !map) return;
    const selected = new Set(options.selectedIds.value.map(Number));
    for (const feature of options.features.value) {
      const el = buildLabelElement(feature);
      if (selected.has(Number(feature.id))) el.classList.add('is-selected');
      const marker = new maplibregl.Marker({ element: el, anchor: 'center' }).setLngLat(labelAnchor(feature)).addTo(map);
      labelMarkers.push(marker);
    }
    lastLabelSignature = featuresSignature();
  }

  /** 选中态变化只切 DOM class，不重建 Marker（避免闪烁）。 */
  function applyLabelRichState() {
    if (!options.richLabel?.value) return;
    const selected = new Set(options.selectedIds.value.map(Number));
    labelMarkers.forEach((m, i) => {
      const feature = options.features.value[i];
      m.getElement().classList.toggle('is-selected', feature != null && selected.has(Number(feature.id)));
    });
  }

  function applyLabel() {
    const map = getUtils()?.mapInstance.value;
    if (labelLayerId && map?.getLayer(labelLayerId)) {
      map.setLayoutProperty(labelLayerId, 'text-field', labelFieldExpression() as any);
      applyLabelRichState();
    }
  }

  function attach() {
    const utils = getUtils();
    const map = utils?.mapInstance.value;
    if (!utils || !map) return;

    // 新一轮 attach：清空记录（旧 id 已被 setStyle 清掉，不应重复 remove）
    ownedSourceIds.length = 0;
    ownedLayerIds.length = 0;

    const fillSource = utils.createSource({ type: 'geojson', data: featureCollection(options.features.value) } as any);
    polygonSource = fillSource;
    polygonSourceId = fillSource.id;
    ownedSourceIds.push(fillSource.id);
    const fillLayer = fillSource.addLayer({
      type: 'fill',
      ...layerZoomGate(),
      paint: {
        'fill-color': colorExpression() as any,
        'fill-opacity': opacityExpression() as any,
        'fill-outline-color': '#ffffff'
      }
    });
    fillLayerId = fillLayer.id;
    ownedLayerIds.push(fillLayer.id);
    fillLayer.on('click', (event: any) => {
      const feature = event.features?.[0];
      if (!feature) return;
      hoverPopup?.remove();
      hoverPopup = null;
      const node = options.popup?.value?.(feature.properties ?? {});
      if (node && options.createPopup) options.createPopup(node, [event.lngLat.lng, event.lngLat.lat]);
      options.onFeatureClick?.(feature, event.originalEvent);
    });

    if (options.hover.value) {
      fillLayer.on('mouseenter', (event: any) => {
        const feature = event.features?.[0];
        if (!feature) return;
        const canvas = map.getCanvas();
        if (canvas) canvas.style.cursor = 'pointer';
        const fields = feature.properties ?? {};
        const el = document.createElement('div');
        el.className = 'geo-map__hover';
        // [why] 优先用调用方 hoverContent —— 不同业务字段差异极大，通用组件只能兜底；
        // 未提供时才退回 name + createTime 的默认文案。
        if (options.hoverContent) {
          const content = options.hoverContent(fields);
          if (typeof content === 'string') {
            // [why] 业务侧约定用 ' · ' 连接多段信息（首段=标题，其余=次级信息）。
            // 拆成多行渲染：标题加粗、次级信息灰色小字，把悬停气泡从「单行纯文本」
            // 升级为结构化卡片，与点击气泡 / 图例 / 查询面板统一为玻璃风格。
            const segs = content
              .split(/\s*[·•・‧]\s*/)
              .map((s) => s.trim())
              .filter(Boolean);
            if (segs.length > 1) {
              const nameEl = document.createElement('div');
              nameEl.className = 'geo-map__hover-name';
              nameEl.textContent = segs[0];
              el.append(nameEl);
              for (const seg of segs.slice(1)) {
                const line = document.createElement('div');
                line.className = 'geo-map__hover-time';
                line.textContent = seg;
                el.append(line);
              }
            } else {
              el.textContent = content;
            }
          } else if (content) {
            render(content, el);
          } else {
            return;
          }
        } else {
          const nameEl = document.createElement('div');
          nameEl.className = 'geo-map__hover-name';
          nameEl.textContent = String(fields.name ?? '');
          const timeEl = document.createElement('div');
          timeEl.className = 'geo-map__hover-time';
          timeEl.textContent = `更新时间：${fields.createTime ?? ''}`;
          el.append(nameEl, timeEl);
        }
        hoverPopup?.remove();
        hoverPopup = new maplibregl.Popup({ closeButton: false, closeOnClick: false, className: 'geo-map__hover-popup' })
          .setLngLat(event.lngLat)
          .setDOMContent(el)
          .addTo(map);
      });
      fillLayer.on('mousemove', (event: any) => {
        hoverPopup?.setLngLat(event.lngLat);
      });
      fillLayer.on('mouseleave', () => {
        map.getCanvas().style.cursor = '';
        hoverPopup?.remove();
        hoverPopup = null;
      });
    }

    // halo 必须先于彩色线加入，才能在栈里垫在它下面（同 source 同层序即先后）
    const haloLayer = fillSource.addLayer({
      type: 'line',
      ...layerZoomGate(),
      paint: {
        'line-color': MAP_SELECTION.haloColor,
        'line-width': ['case', ['in', ['id'], ['literal', options.selectedIds.value]], MAP_SELECTION.haloWidth, 0] as any,
        'line-opacity': MAP_SELECTION.haloOpacity
      }
    });
    haloLayerId = haloLayer.id;
    ownedLayerIds.push(haloLayer.id);

    const lineLayer = fillSource.addLayer({
      type: 'line',
      ...layerZoomGate(),
      paint: { 'line-color': MAP_UNSELECTED_LINE.color, 'line-width': MAP_UNSELECTED_LINE.width, 'line-opacity': MAP_UNSELECTED_LINE.opacity }
    });
    lineLayerId = lineLayer.id;
    ownedLayerIds.push(lineLayer.id);

    const progressSrc = utils.createSource({ type: 'geojson', data: featureCollection(options.progressFeatures.value) } as any);
    progressSource = progressSrc;
    progressSourceId = progressSrc.id;
    ownedSourceIds.push(progressSrc.id);
    progressLayerId = progressSrc.addLayer({
      type: 'fill',
      ...layerZoomGate(),
      paint: { 'fill-color': colorExpression() as any, 'fill-opacity': 0.95, 'fill-outline-color': '#ffffff' }
    }).id;

    // [why] richLabel 打开时标签由 DOM Marker 渲染（见 syncLabelMarkers），不建 symbol 图层：
    // 1) MapLibre GL JS v6 不支持 text-background-* / text-border-*，写进 paint 会让 addLayer 抛错、
    //    整张地图样式加载失败（E2E 实测 console.error）；
    // 2) 即使只画纯文字也会和 DOM Marker 叠成双份标签。
    // 未开 richLabel 的其它图层组（数据浏览 / 元数据检查 / 更新）继续走原 symbol 渲染，零回归。
    if (!options.richLabel?.value) {
      const labelSrc = utils.createSource({ type: 'geojson', data: featureCollection(options.features.value) } as any);
      labelSource = labelSrc;
      labelSourceId = labelSrc.id;
      ownedSourceIds.push(labelSrc.id);
      labelLayerId = labelSrc.addLayer({
        type: 'symbol',
        ...layerZoomGate(),
        layout: {
          'text-field': labelFieldExpression(),
          'text-size': 12,
          'text-anchor': 'center',
          'text-line-height': 1.25
        },
        paint: { 'text-color': '#172b4d', 'text-halo-color': '#ffffff', 'text-halo-width': 1.5 }
      }).id;
      ownedLayerIds.push(labelLayerId);
    }

    if (options.cluster.value) {
      const pointFeatures = options.features.value.map((feature: any) => ({
        type: 'Feature',
        geometry: { type: 'Point', coordinates: clusterPoint(feature) },
        properties: feature.properties,
        id: feature.id
      }));
      const clusterSrc = utils.createSource({
        type: 'geojson',
        data: featureCollection(pointFeatures),
        cluster: true,
        clusterMaxZoom: CLUSTER_MAX_ZOOM,
        clusterRadius: 45
      } as any);
      clusterSource = clusterSrc;
      clusterSourceId = clusterSrc.id;
      ownedSourceIds.push(clusterSrc.id);
      clusterSrc.addLayer({
        type: 'circle',
        filter: ['has', 'point_count'],
        paint: {
          'circle-color': '#2563eb',
          'circle-radius': ['step', ['get', 'point_count'], 16, 5, 22, 10, 28],
          'circle-opacity': 0.85
        }
      });
      clusterSrc.addLayer({
        type: 'symbol',
        filter: ['has', 'point_count'],
        layout: { 'text-field': '{point_count_abbreviated}', 'text-size': 12 },
        paint: { 'text-color': '#ffffff' }
      });
    }

    applyState();
    syncLabelMarkers();

    // [why] 首次 attach / 底图切换后重 attach 时，若图层组有数据但视口未包含它们，
    // 地图会停在旧中心；此处主动 fitBounds，保证「图层加载完即自动聚焦到图层」。
    // CONSTRAINT 仅在 fit 开启且有数据时调用 —— 空数据时 bbox 非法会触发 fitBounds 报错。
    if (options.fit.value && options.features.value.length) utils.fitBounds(featureCollection(options.features.value) as any);
  }

  /**
   * 真正从地图移除本组的所有 source/layer。
   * WHY 与 detach 的区别：detach 只清 id 缓存，依赖 setStyle 自己清资源；
   * 组件卸载 / tab 切换时 setStyle 不会发生，必须显式 removeLayer + removeSource，
   * 否则地图上会残留上一场景的矩形。
   * CONSTRAINT 用 useMapResource.createSource 返回的 clear()（内部会 removeLayer + removeSource + 清 sources 表）；
   * 直接调用 map.removeLayer/removeSource 会漏清 sources 表，可能造成内存泄漏。
   */
  function destroy() {
    labelMarkers.forEach((m) => m.remove());
    labelMarkers.length = 0;
    // [why] 用 useMapResource.createSource 返回的 clear() 处理每个 source：
    // 它内部会先 removeLayer（该 source 关联的所有 layer）再 removeSource，顺带清 sources 表。
    // 之前手动按 id 迭代 layer/source 会漏 track（例如 progress layer、cluster 的两个 layer），
    // 导致 removeSource 时残留 layer 报 "cannot be removed while layer is using it"。
    const sources = [polygonSource, progressSource, labelSource, clusterSource];
    sources.forEach((s) => {
      try {
        if (s && typeof s.clear === 'function') s.clear();
      } catch {
        /* 单个 source 清理失败不阻断其他 */
      }
    });
    polygonSource = null;
    progressSource = null;
    labelSource = null;
    clusterSource = null;
    ownedLayerIds.length = 0;
    ownedSourceIds.length = 0;
    detach();
  }

  function detach() {
    labelMarkers.forEach((m) => m.remove());
    labelMarkers.length = 0;
    lastLabelSignature = '';
    polygonSourceId = '';
    clusterSourceId = '';
    fillLayerId = '';
    lineLayerId = '';
    haloLayerId = '';
    progressSourceId = '';
    progressLayerId = '';
    labelSourceId = '';
    labelLayerId = '';
    hoverPopup?.remove();
    hoverPopup = null;
    lastSignature = '';
  }

  watch(options.selectedIds, () => applyState(), { deep: true });
  watch(options.hiddenIds, () => applyState(), { deep: true });
  watch(options.palette, () => applyPalette(), { deep: true });
  watch(
    options.features,
    () => {
      const utils = getUtils();
      if (!utils?.mapInstance.value || !polygonSourceId) return;
      const sig = featuresSignature();
      syncData(sig !== lastSignature && options.fit.value);
      lastSignature = sig;
    },
    { deep: true }
  );
  watch(options.progressFeatures, () => applyProgress(), { deep: true });
  watch(options.labelKey, () => applyLabel());

  return {
    attach,
    detach,
    destroy,
    applyState,
    applyPalette,
    applyProgress,
    applyLabel
  };
}

/**
 * renderLayers 的选项：全部可选，不传则走智能默认。
 *
 * 归一化优先级（针对单条 record）：
 *   1. record.type === 'Feature' → 直接用；
 *   2. record.geometry 存在 → 用 geometry 构造 Feature；
 *   3. record.bbox 存在 → 由 bbox 构造 Polygon（[minLng, minLat, maxLng, maxLat]）。
 */
export interface RenderLayersOptions {
  /** record 里用作 Feature 属性的字段名；默认展开整条 record */
  properties?: (record: any) => Record<string, any>;
  /** bbox 字段名，默认 'bbox' */
  bboxKey?: string;
  /** geometry 字段名，默认 'geometry' */
  geometryKey?: string;
  /** id 字段名，默认 'id' */
  idKey?: string;
  /** 单一颜色：所有要素填充同一色 */
  color?: string;
  /** 分类配色：key→color；配合 colorKey 使用 */
  palette?: Record<string, string>;
  /** 分类配色键字段名；默认自动检测（category / type / status / qualityEvaluate） */
  colorKey?: string;
  /** label 字段名；默认自动检测（name / graphName / title / zoneNumber / id） */
  labelKey?: string;
  /** 是否在数据变化时重新 fitBounds，默认 true */
  fit?: boolean;
  /** 是否启用悬浮展示，默认 true */
  hover?: boolean;
  /** 悬浮弹窗内容（语义同 MapLayerOptions.hoverContent） */
  hoverContent?: (properties: Record<string, any>) => VNode | string | null | undefined;
  /** 点击要素回调 */
  onFeatureClick?: (feature: any, originalEvent: any) => void;
  /** popup 渲染函数 */
  popup?: (properties: Record<string, any>) => VNode | null;
  /**
   * 每条 record 进入归一化之前的转换钩子：
   * 用于给要素追加业务字段（如 storeStatus / label），再由 colorKey / labelKey 消费。
   * WHY 用钩子而非预加工数据：业务数据的字段名差异大（category / productType），
   * 由业务侧在钩子里完成匹配，通用组件只做归一化。
   */
  recordTransform?: (record: any) => any;
  /** 是否启用点聚合（默认 false）；仅在要素为 Polygon 时自动用其中心点作为聚点 */
  cluster?: boolean;
  /**
   * 当前选中的要素 id 列表；选中项以加粗红描边高亮。
   * 传 Ref 随选中变化自动刷新；不传则全部按未选中样式渲染。
   * WHY 与业务侧双向联动：表格勾选行 → 传 ids 到此 → 地图同步高亮。
   */
  selectedIds?: Ref<number[]> | number[];
  /**
   * 当前置灰的要素 id 列表；置灰项填充透明度降低（用于「筛选未命中」反馈）。
   * 传 Ref 随筛选变化自动刷新；不传则无置灰。
   */
  hiddenIds?: Ref<number[]> | number[];
  /**
   * 进度条要素（用于在矩形内部绘制进度横条）。
   * 传 Ref 时随数据变化自动刷新；传普通数组时视为一次性快照。
   */
  progressFeatures?: Ref<any[]> | any[];
}

/** 用于「统一色」策略：往 feature.properties 里注入的伪字段名 */
const RENDER_COLOR_FIELD = '__renderColor';

/** 自动检测：从 record 里挑第一个命中的候选字段作为 label 键 */
const LABEL_CANDIDATES = ['name', 'graphName', 'title', 'zoneNumber', 'id'];
/** 自动检测：从 record 里挑第一个命中的候选字段作为分类配色键 */
const COLOR_CANDIDATES = ['category', 'type', 'status', 'qualityEvaluate'];

function pickField(record: any, candidates: string[]): string {
  for (const key of candidates) {
    if (record && record[key] !== undefined) return key;
  }
  return candidates[0];
}

/**
 * 把单条 record 归一化为 GeoJSON Feature。
 * CONSTRAINT 归一化顺序固定为 Feature → geometry → bbox；
 * 三者都不命中返回 null（调用方需要 filter）。
 */
function toFeature(record: any, options: RenderLayersOptions): any | null {
  if (!record || typeof record !== 'object') return null;

  const idKey = options.idKey ?? 'id';
  const props = options.properties ? options.properties(record) : { ...record };
  const feature = { type: 'Feature', id: record[idKey], properties: props };

  if (record.type === 'Feature' && record.geometry) {
    return { ...feature, geometry: record.geometry };
  }

  const geomKey = options.geometryKey ?? 'geometry';
  if (record[geomKey]) {
    return { ...feature, geometry: record[geomKey] };
  }

  const bboxKey = options.bboxKey ?? 'bbox';
  const bbox = record[bboxKey];
  if (Array.isArray(bbox) && bbox.length === 4) {
    const [minLng, minLat, maxLng, maxLat] = bbox;
    return {
      ...feature,
      geometry: {
        type: 'Polygon',
        coordinates: [
          [
            [minLng, minLat],
            [maxLng, minLat],
            [maxLng, maxLat],
            [minLng, maxLat],
            [minLng, minLat]
          ]
        ]
      }
    };
  }

  return null;
}
// =============================================================================
// 二、useMap 单例 —— 全局唯一的地图实例 + 图层组注册表
// =============================================================================

/**
 * 全局唯一的 useMap 单例（两产品线共享）。
 *
 * 职责：
 * - 持有当前地图实例与 useMapResource utils（由 GeoMap 通过 @ready 事件推送）；
 * - 提供 createLayerGroup / removeLayerGroup，让每个业务模块注册自己的图层组；
 * - styleVersion 计数器：底图切换后自增，业务侧 watch 后 detach + attach，各自刷新自己的图层。
 *
 * 使用约定（每个业务地图组件）：
 *   const { createLayerGroup, removeLayerGroup, styleVersion, utils } = useMap()
 *   const GROUP = 'primary-product/map'
 *   const layers = createLayerGroup(GROUP, { features, palette, ... })
 *   watch(styleVersion, () => { layers.detach(); layers.attach() }, { immediate: true })
 *   onUnmounted(() => removeLayerGroup(GROUP))
 *
 * CONSTRAINT 单例内的图层组用 effectScope 隔离：removeLayerGroup 时 stop 会连带清掉组内 watch，
 * 避免业务组件卸载后图层组仍在监听 store 变化。
 */
export const useMap = createSharedComposable(() => {
  const mapInstance = shallowRef<maplibregl.Map>();
  /**
   * utils 存普通 let、不用 shallowRef：useMapResource 返回对象内含嵌套 Ref，
   * 外层再包 shallowRef 时 vue-tsc 访问 .value 会误判为「Property value 不存在」；
   * 用 styleVersion 通知业务侧刷新即可。
   */
  let utilsInstance: ReturnType<typeof useMapResource> | undefined;
  const groups = new Map<string, MapLayerApi>();
  const scopes = new Map<string, ReturnType<typeof effectScope>>();
  /** 每次 setMap / 底图切换后自增；业务侧 watch 此值重挂图层 */
  const styleVersion = ref(0);
  /** renderLayers 专用 scope：重新调用时 stop 旧组，避免重复监听 styleVersion */
  let renderScope: ReturnType<typeof effectScope> | undefined;

  function setMap(payload: { map: maplibregl.Map | undefined; utils: ReturnType<typeof useMapResource> }) {
    mapInstance.value = payload.map;
    utilsInstance = payload.utils;
    styleVersion.value += 1;
  }

  function bumpStyleVersion() {
    styleVersion.value += 1;
  }

  function createLayerGroup(id: string, options: MapLayerOptions): MapLayerApi {
    const existing = groups.get(id);
    // [fix] 用 destroy 而不是 detach：detach 只清 id 缓存，旧 source（geojson-xxxxx 随机 id）
    // 会留在 style 里，反复 renderLayers 时表现为「新结果和旧结果叠在一起」。
    // 2026-10-24 实测：条件查询 → 空间查询后 style.sources 从 4 个涨到 8 个。
    if (existing) existing.destroy();
    const oldScope = scopes.get(id);
    if (oldScope) oldScope.stop();
    const scope = effectScope(true);
    const group = scope.run(() => useMapLayers(() => utilsInstance, options))!;
    scopes.set(id, scope);
    groups.set(id, group);
    return group;
  }

  function removeLayerGroup(id: string) {
    const group = groups.get(id);
    // [fix] 组件卸载 / tab 切换时不会触发 setStyle，必须真正从地图移除资源
    // （历史 bug：调 detach 只清 id 缓存，导致地图上残留上一场景的图层）
    if (group) group.destroy();
    groups.delete(id);
    const scope = scopes.get(id);
    if (scope) scope.stop();
    scopes.delete(id);
  }

  /** 方法读取而非返回字段：避免 createSharedComposable 的类型推断把对象误认为 Ref */
  function getUtils() {
    return utilsInstance;
  }

  /**
   * 一键渲染图层：业务侧只传入原始记录数组（或 Ref），归一化 / 配色 / label / 图层组
   * / effectScope / 底图切换后重挂 全部由本函数内部处理。
   *
   * 典型用法（data-browse 等业务模块完全解耦）：
   *   const map = useMap()
   *   watch(map.mapInstance, () => map.renderLayers(records))
   *   // 或直接传 Ref，records 变化会自动刷新
   *   map.renderLayers(records)
   *
   * CONSTRAINT 内部使用固定图层组 id '__render__'：多次调用会先停掉上一次的 scope
   * 再建新组，避免同一业务地图多次 renderLayers 时旧图层残留。
   */
  function renderLayers(dataInput: any[] | Ref<any[]>, options: RenderLayersOptions = {}) {
    // 归一化输入：Ref 直接用，普通数组转成 ref
    const dataRef = isRef(dataInput) ? (dataInput as Ref<any[]>) : ref(dataInput);

    // [why] 先过 recordTransform：业务侧可在钩子里给 record 追加 storeStatus / label 等字段；
    // transform 返回新对象，不改动原数组元素，避免污染共享数据源。
    const transformedRecords = computed<any[]>(() => {
      const list = dataRef.value ?? [];
      if (!options.recordTransform) return list;
      return list.map((r: any) => options.recordTransform!(r));
    });

    // 归一化数据为 Feature 数组：每项过 toFeature，null 丢弃
    const features = computed<any[]>(() => transformedRecords.value.map((r: any) => toFeature(r, options)).filter(Boolean));

    // 从第一条记录自动探测 labelKey / colorKey，若 options 里已指定则用 options 的
    const sample = computed(() => features.value[0]?.properties ?? {});
    const resolvedLabelKey = computed(() => options.labelKey ?? pickField(sample.value, LABEL_CANDIDATES));
    const resolvedColorKey = computed(() => options.colorKey ?? pickField(sample.value, COLOR_CANDIDATES));

    // 配色：单色 → 注入伪字段 + palette 映射；分类色 → 直接用
    const isSingleColor = typeof options.color === 'string';
    const paletteRef = computed<Record<string, string>>(() => {
      if (isSingleColor) return { [options.color as string]: options.color as string };
      return options.palette ?? {};
    });

    // 单色场景：给每条 feature 的 properties 注入伪字段 RENDER_COLOR_FIELD
    const preparedFeatures = computed<any[]>(() => {
      if (!isSingleColor) return features.value;
      return features.value.map((f: any) => ({
        ...f,
        properties: { ...f.properties, [RENDER_COLOR_FIELD]: options.color as string }
      }));
    });

    const effectiveColorKey = computed(() => (isSingleColor ? RENDER_COLOR_FIELD : resolvedColorKey.value));

    const popupRef = options.popup ? computed(() => options.popup as any) : undefined;

    const group = createLayerGroup('__render__', {
      features: preparedFeatures,
      colorKey: effectiveColorKey,
      palette: paletteRef,
      selectedIds: isRef(options.selectedIds) ? options.selectedIds : ref(options.selectedIds ?? []),
      hiddenIds: isRef(options.hiddenIds) ? options.hiddenIds : ref(options.hiddenIds ?? []),
      progressFeatures: isRef(options.progressFeatures) ? (options.progressFeatures as Ref<any[]>) : ref(options.progressFeatures ?? []),
      labelKey: resolvedLabelKey,
      cluster: ref(options.cluster ?? false),
      clusterAnchor: ref('center'),
      fit: computed(() => options.fit ?? true),
      hover: ref(options.hover ?? true),
      hoverContent: options.hoverContent,
      popup: popupRef,
      onFeatureClick: options.onFeatureClick,
      createPopup: (node, lngLat) => {
        utilsInstance?.createPopup(node, lngLat);
      }
    });

    if (utilsInstance?.mapInstance.value) {
      group.detach();
      group.attach();
    }

    watch(styleVersion, () => {
      if (!utilsInstance?.mapInstance.value) return;
      group.detach();
      group.attach();
    });

    return group;
  }

  /**
   * 清空 renderLayers 创建的图层与内部 scope。
   * WHY 业务面板（data-browse / task 模块）在 tab 切换后会卸载，但其 renderLayers 注册在
   * 本单例的 renderScope 上（与组件生命周期解耦），不主动清会残留到下一 tab。
   * CONSTRAINT 只清 renderLayers 的固定 id，不动其他 createLayerGroup 注册的业务图层组。
   */
  function clearRenderLayers() {
    if (renderScope) {
      renderScope.stop();
      renderScope = undefined;
    }
    // 关闭点击矩形弹出的 popup —— 该实例由 useMapResource.popup 持有，不受图层组 destroy 影响；
    // 不关的话切 tab 后会悬挂在新地图上（上一次点击的弹窗停留在旧视口位置）。
    utilsInstance?.popup.value?.remove();
    removeLayerGroup('__render__');
  }

  // ---------------------------------------------------------------------------
  // 查询范围轮廓：把「本轮空间查询所用的范围」半透明高亮出来
  //
  // WHY 独立图层通道：renderLayers 固定用 '__render__' 组画命中要素，
  // clearRenderLayers() 只清它。范围轮廓若复用同组，0 命中时会被一并清掉
  // （正是「海淀区 0 命中后地图全空」的根因），且与命中要素配色 / 选中态冲突。
  // 这里用固定 source / layer id 自建一对 fill + line 层，与 '__render__' 互不干扰。
  // ---------------------------------------------------------------------------
  const QUERY_AREA_SOURCE_ID = '__query_area_src__';
  const QUERY_AREA_FILL_ID = '__query_area_fill__';
  const QUERY_AREA_LINE_ID = '__query_area_line__';
  /** 最近一次范围 FeatureCollection；底图切换（styleVersion 自增）后据此重挂 */
  let queryAreaData: any = null;

  function removeQueryAreaLayers() {
    const map = mapInstance.value;
    if (!map) return;
    try {
      if (map.getLayer(QUERY_AREA_FILL_ID)) map.removeLayer(QUERY_AREA_FILL_ID);
      if (map.getLayer(QUERY_AREA_LINE_ID)) map.removeLayer(QUERY_AREA_LINE_ID);
      if (map.getSource(QUERY_AREA_SOURCE_ID)) map.removeSource(QUERY_AREA_SOURCE_ID);
    } catch {
      // setStyle 已清空 source / layer 时忽略
    }
  }

  function attachQueryArea() {
    const map = mapInstance.value;
    const data = queryAreaData;
    if (!map || !data) return;
    // [why] 不检查 map.isStyleLoaded()：底图切换链路是 setStyle → style.load →
    // onStyleLoad → emit('styleChange') → bumpStyleVersion → 本函数被 watch 重挂，
    // 此时 style.load 已过、addSource / addLayer 合法；但在线底图下 isStyleLoaded()
    // （要求全部瓦片 source 加载完）仍为 false，若据此守卫并 once('style.load') 重试，
    // style.load 已过点不会再触发，轮廓会永久丢失（表现为切底图后黄框消失）。
    // 与 renderLayers 的 attach() 口径一致：直接 addSource；style 尚未挂的极早期调用
    // 由 try/catch 吞掉，queryAreaData 仍在，下一次 setMap / styleVersion 会重挂。
    try {
      const src = map.getSource(QUERY_AREA_SOURCE_ID) as any;
      if (src?.setData) src.setData(data);
      else map.addSource(QUERY_AREA_SOURCE_ID, { type: 'geojson', data });
      if (!map.getLayer(QUERY_AREA_FILL_ID)) {
        map.addLayer({
          id: QUERY_AREA_FILL_ID,
          type: 'fill',
          source: QUERY_AREA_SOURCE_ID,
          paint: { 'fill-color': '#FFC53D', 'fill-opacity': 0.22 }
        });
      }
      if (!map.getLayer(QUERY_AREA_LINE_ID)) {
        map.addLayer({
          id: QUERY_AREA_LINE_ID,
          type: 'line',
          source: QUERY_AREA_SOURCE_ID,
          paint: {
            'line-color': '#E9A23B',
            'line-width': 2,
            'line-opacity': 0.95,
            'line-dasharray': [2, 1.5]
          }
        });
      }
    } catch {
      // 非致命：下一次 setQueryArea / styleVersion 会重试
    }
  }

  /**
   * 设置（或清除）查询范围轮廓。
   * @param area 范围几何：裸 GeoJSON geometry 或完整 Feature；null / undefined 表示清除
   * @param options.fit 是否把相机缩放到该范围。有命中要素时由业务侧 fit 到要素（视觉聚焦数据），
   *                    这里传 false 避免两次 fitBounds 动画打架；0 命中时传 true 才能看见查的是哪块区域。
   */
  function setQueryArea(area: any, options: { fit?: boolean } = {}) {
    if (!area) {
      clearQueryArea();
      return;
    }
    // lastArea 形态不统一：runGeometryQuery / runSheetQuery / runCoordQuery 等传裸 geometry，
    // runAdminDivisionQuery 传完整 Feature —— 统一包成 FeatureCollection 供 geojson source 使用。
    const feature = area.type === 'Feature' ? area : { type: 'Feature', geometry: area, properties: {} };
    queryAreaData = { type: 'FeatureCollection', features: [feature] };
    attachQueryArea();
    if (options.fit !== false) {
      try {
        getUtils()?.fitBounds(queryAreaData);
      } catch {
        // 退化包围盒跳过
      }
    }
  }

  function clearQueryArea() {
    queryAreaData = null;
    removeQueryAreaLayers();
  }

  // 底图切换：setStyle 会清掉自建的 source / layer，styleVersion 自增后按 queryAreaData 重挂
  watch(styleVersion, () => {
    if (!queryAreaData) return;
    removeQueryAreaLayers();
    attachQueryArea();
  });

  return {
    mapInstance,
    getUtils,
    styleVersion,
    setMap,
    bumpStyleVersion,
    createLayerGroup,
    removeLayerGroup,
    renderLayers,
    clearRenderLayers,
    setQueryArea,
    clearQueryArea
  };
});
