/**
 * 地图要素选中态（地图 ↔ 列表联动的唯一真源）。
 *
 * WHY 独立成模块：地图点击的两条通道（MVT 全局监听 / GeoJSON 业务 onFeatureClick）
 * 都汇合到 feature-detail-dialog.tsx 的 openFeatureDetail，而属性表（data-browse /
 * records-edit 两份 attribute-table.vue）与地图是兄弟组件、没有 provide/inject 通道。
 * 用一份模块级 shallowRef 把「点了哪个要素」广播出去，属性表 watch 后写自己的 locatedRows，
 * 即可同时驱动地图高亮边框与列表行选中态（两者本就同源）。
 *
 * WHY 不 import useMap：feature-detail-dialog.tsx 头注释已说明该文件不能碰地图单例，
 * 否则形成循环依赖；本模块只依赖 vue，保持零业务耦合。
 *
 * WHY 带 seq：连点同一个要素时 payload 内容完全相同，显式自增序号让 watch 回调能区分
 * 「第几次点击」，也便于给未匹配到行的高亮生成唯一 key。
 */
import { shallowRef } from 'vue';

export interface FeatureSelection {
  seq: number;
  /** 瓦片 / 要素携带的属性（含 metadata_uid 时用它做精确行匹配） */
  values: Record<string, unknown>;
  resourceUid?: string;
  tableKey?: string;
  /** 点击命中的 GeoJSON Geometry：优先拿它画精确贴合图斑的高亮边框 */
  geometry?: unknown;
  geometryType?: string;
}

export const featureSelection = shallowRef<FeatureSelection | null>(null);

let seq = 0;

/** 广播一次地图选中（在 openFeatureDetail 的同事件去重之后调用） */
export function selectFeature(payload: Omit<FeatureSelection, 'seq'>) {
  featureSelection.value = { ...payload, seq: ++seq };
}

/**
 * 从一批记录里找出与地图要素最匹配的一行。
 *
 * 优先 metadata_uid 精确相等（跨翻页稳定的行身份，见 records-edit 的 recordUid）；
 * 瓦片 properties 是完整记录的子集，退而求其次按共享标量键做子集打分，取最高分且 ≥ 0.8。
 * 只比对标量（短字符串 / 数字 / 布尔），跳过对象与超长字符串（WKT / JSON），
 * 避免 spatial_range 这类噪音字段把不相干的行凑成「命中」。
 */
export function matchRecord<T extends { values?: any }>(records: T[], values: Record<string, unknown>): T | null {
  const uid = String(values?.metadata_uid ?? '').trim();
  if (uid) {
    const hit = records.find((r) => String(r.values?.metadata_uid ?? '').trim() === uid);
    if (hit) return hit;
  }

  const entries = Object.entries(values ?? {}).filter(([, v]) => isComparable(v));
  if (!entries.length) return null;

  let best: T | null = null;
  let bestScore = 0;
  for (const r of records) {
    const rv = r.values ?? {};
    let same = 0;
    let total = 0;
    for (const [k, v] of entries) {
      if (!(k in rv)) continue;
      total += 1;
      if (!isComparable(rv[k])) continue;
      if (String(rv[k]).trim() === String(v).trim()) same += 1;
    }
    if (!total) continue;
    const score = same / total;
    if (score > bestScore) {
      bestScore = score;
      best = r;
    }
  }
  return bestScore >= 0.8 ? best : null;
}

function isComparable(v: unknown): boolean {
  if (v == null) return false;
  const t = typeof v;
  if (t === 'string') return (v as string).length <= 200;
  return t === 'number' || t === 'boolean';
}
