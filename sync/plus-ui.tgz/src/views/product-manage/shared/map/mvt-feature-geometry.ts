/**
 * MVT 要素几何聚合（瓦片片段 → 完整要素）。
 *
 * WHY：服务端按瓦片裁切几何，同一条记录跨瓦片时会拆成多个 feature；直接拿 queryRenderedFeatures
 * 命中的那一片做高亮/详情，只显示局部。这里按要素身份（优先 metadata_uid，其次 feature.id）分组，
 * 再用 querySourceFeatures 取当前已加载瓦片里的全部片段，按几何类型合并成一个完整 Geometry。
 * 只影响交互层（高亮/选中/详情），基础 MVT 图层仍按瓦片原样绘制；未加载瓦片的部分无法在此补回。
 */
import type { Map as MapLibreMap } from 'maplibre-gl';
import type { Geometry, MultiLineString, MultiPoint, MultiPolygon, Polygon, Position } from 'geojson';
import { flattenEach, union } from '@turf/turf';
import { MVT_SOURCE_LAYER } from '@/api/product-manage/platform/metadata-tiles';
import { findMountedVectorTileByLayerId, listMountedVectorTileKeys } from './vector-tile-layer';

type MvtFeatureLike = {
  id?: string | number | null;
  geometry?: Geometry | null;
  properties?: Record<string, unknown> | null;
  layer?: { id?: string } | null;
  source?: string;
};

/** 取瓦片片段的要素身份：业务 uid 优先，其次 feature.id 转字符串 */
export function mvtFeatureIdentity(feature: MvtFeatureLike): string {
  const uid = String((feature.properties as any)?.metadata_uid ?? '').trim();
  if (uid) return `uid:${uid}`;
  if (feature.id != null) return `id:${String(feature.id)}`;
  return '';
}

/** 该片段在地图上实际使用的 MVT source id（反查 mounted，避免手拼 id 口径漂移） */
function sourceIdForFeature(feature: MvtFeatureLike): string {
  if (feature.source) return feature.source;
  const info = findMountedVectorTileByLayerId(String((feature as any).layer?.id ?? ''));
  // 与 vector-tile-layer.ts 的 uid('mvt-src', key) 保持同一替换规则
  return info ? `mvt-src-${info.key.replace(/[^a-zA-Z0-9_-]/g, '_')}` : '';
}

/** 把 Turf 结果（裸 Geometry / Feature / FeatureCollection）规范成 GeoJSON Geometry */
function toGeometry(value: unknown): Geometry | null {
  if (!value || typeof value !== 'object') return null;
  const candidate = value as any;
  if (candidate.type === 'FeatureCollection') return (candidate.features?.[0]?.geometry as Geometry) ?? null;
  if (candidate.type === 'Feature') return (candidate.geometry as Geometry) ?? null;
  return typeof candidate.type === 'string' ? (candidate as Geometry) : null;
}

/**
 * 用 Turf flattenEach 把 Geometry 展平成裸 Geometry 列表。
 * WHY：flattenEach 是 callback 风格（返回 void），不能用 for...of 迭代；
 * 这里统一收集 callback 里的 geometry，避免每个 merge 分支各写一遍回调样板。
 */
function flattenGeometries(geometry: Geometry): Geometry[] {
  const parts: Geometry[] = [];
  flattenEach(geometry as any, (feature: any) => {
    if (feature?.geometry?.type) parts.push(feature.geometry as Geometry);
  });
  return parts.length ? parts : [geometry];
}

/** 去掉 position 数组里重复且相邻的点 */
function dedupePoints(points: Position[]): Position[] {
  const out: Position[] = [];
  for (const point of points) {
    const prev = out[out.length - 1];
    if (prev && prev[0] === point[0] && prev[1] === point[1]) continue;
    out.push(point);
  }
  return out;
}

function uniqueGeometries(features: MvtFeatureLike[]): Geometry[] {
  const seen = new Set<string>();
  const out: Geometry[] = [];
  for (const feature of features) {
    const geometry = feature.geometry;
    if (!geometry?.type) continue;
    const signature = `${geometry.type}:${JSON.stringify((geometry as any).coordinates)}`;
    if (seen.has(signature)) continue;
    seen.add(signature);
    out.push(geometry);
  }
  return out;
}

/** 点 / 多点：按坐标去重后输出 MultiPoint */
function mergePoints(features: MvtFeatureLike[]): Geometry | null {
  const seen = new Set<string>();
  const points: Position[] = [];
  for (const geometry of uniqueGeometries(features)) {
    for (const part of flattenGeometries(geometry)) {
      const type = String((part as any).type ?? '');
      const coordinates = (part as any).coordinates;
      const candidates: Position[] = [];
      // Point 的 coordinates 是一个 Position；MultiPoint 的才是 Position[]，两种层级不能混遍历
      if (type === 'Point' && Array.isArray(coordinates)) candidates.push(coordinates as Position);
      else if (type === 'MultiPoint' && Array.isArray(coordinates)) candidates.push(...(coordinates as Position[]));
      for (const point of candidates) {
        const key = `${point[0]},${point[1]}`;
        if (seen.has(key)) continue;
        seen.add(key);
        points.push(point);
      }
    }
  }
  if (!points.length) return null;
  if (points.length === 1 && features.length === 1 && (features[0].geometry as any)?.type === 'Point') return features[0].geometry ?? null;
  return { type: 'MultiPoint', coordinates: points } as MultiPoint;
}

/** 两点是否同坐标（lineMerge 连接判据） */
function samePoint(a: Position, b: Position): boolean {
  return a[0] === b[0] && a[1] === b[1];
}

/**
 * 经典 lineMerge 语义：把首尾相接的线段拼成一条长线，不相连的各自保留。
 * WHY 自己实现：@turf/turf v7 已移除顶层 lineMerge 导出，但其「相连段合并」是刚需；
 * 这里按 head/tail 四种相接方向迭代归并，结果等价。
 */
function mergeLineStrings(lines: Position[][]): Position[][] {
  const remaining = lines.map((line) => [...line]);
  const result: Position[][] = [];
  while (remaining.length) {
    let current = remaining.shift()!;
    let joined = true;
    while (joined) {
      joined = false;
      for (let i = 0; i < remaining.length; i += 1) {
        const seg = remaining[i];
        const head = current[0];
        const tail = current[current.length - 1];
        const segHead = seg[0];
        const segTail = seg[seg.length - 1];
        if (samePoint(tail, segHead)) current = current.concat(seg.slice(1));
        else if (samePoint(tail, segTail)) current = current.concat([...seg.slice(0, -1)].reverse());
        else if (samePoint(head, segTail)) current = seg.concat(current.slice(1));
        else if (samePoint(head, segHead)) current = [...seg.slice(0, -1)].reverse().concat(current);
        else continue;
        remaining.splice(i, 1);
        joined = true;
        break;
      }
    }
    result.push(current);
  }
  return result;
}

/** 线：按坐标串去重后合并相连片段（lineMerge 语义） */
function mergeLines(features: MvtFeatureLike[]): Geometry | null {
  const lines: MultiLineString['coordinates'] = [];
  for (const geometry of uniqueGeometries(features)) {
    for (const part of flattenGeometries(geometry)) {
      const type = String((part as any).type ?? '');
      const coordinates = (part as any).coordinates;
      if (type === 'LineString' && Array.isArray(coordinates) && (coordinates as Position[]).length >= 2) {
        lines.push(dedupePoints(coordinates as Position[]));
      } else if (type === 'MultiLineString' && Array.isArray(coordinates)) {
        for (const line of coordinates as Position[][]) {
          if (line.length >= 2) lines.push(dedupePoints(line));
        }
      }
    }
  }
  if (!lines.length) return null;
  const parts = mergeLineStrings(lines);
  if (parts.length === 1) return { type: 'LineString', coordinates: parts[0] } as Geometry;
  return { type: 'MultiLineString', coordinates: parts } as MultiLineString;
}

/** 面：单个面直接用，多片用 Turf union 合并为完整面 */
function mergePolygons(features: MvtFeatureLike[]): Geometry | null {
  const parts: MultiPolygon['coordinates'] = [];
  for (const geometry of uniqueGeometries(features)) {
    for (const part of flattenGeometries(geometry)) {
      const type = String((part as any).type ?? '');
      const coordinates = (part as any).coordinates;
      if (!coordinates?.length) continue;
      if (type === 'Polygon') parts.push((coordinates as Position[][]).map(dedupePoints));
      else if (type === 'MultiPolygon') {
        for (const polygon of coordinates as Position[][][]) parts.push(polygon.map(dedupePoints));
      }
    }
  }
  if (!parts.length) return null;
  if (parts.length === 1) return { type: 'Polygon', coordinates: parts[0] } as Polygon;
  const merged = toGeometry(
    union({
      type: 'FeatureCollection',
      features: parts.map((coordinates) => ({ type: 'Feature', properties: {}, geometry: { type: 'Polygon', coordinates } }))
    })
  );
  return merged ?? ({ type: 'MultiPolygon', coordinates: parts } as MultiPolygon);
}

/** 按几何类型合并一组瓦片片段为一个完整 Geometry */
function mergeFeatureParts(features: MvtFeatureLike[]): Geometry | null {
  const unique = uniqueGeometries(features);
  if (!unique.length) return null;
  const firstType = String((unique[0] as any).type ?? '');
  // mergeXxx 内部会再调 uniqueGeometries，必须传原始 feature 列表；传裸 Geometry 会取不到 .geometry 而全被跳过
  if (firstType === 'Point' || firstType === 'MultiPoint') return mergePoints(features);
  if (firstType === 'LineString' || firstType === 'MultiLineString') return mergeLines(features);
  if (firstType === 'Polygon' || firstType === 'MultiPolygon') return mergePolygons(features);
  return unique.length === 1 ? unique[0] : null;
}

/**
 * 取当前地图已加载瓦片里同一要素的所有片段，合并为一个完整 Geometry。
 * 没有 uid / id、source 未挂载或无可合并几何时返回 null，调用方降级用原命中片段。
 */
export function collectMvtFeatureGeometry(map: Pick<MapLibreMap, 'querySourceFeatures' | 'getSource'>, hit: MvtFeatureLike): Geometry | null {
  const identity = mvtFeatureIdentity(hit);
  if (!identity) return null;
  const sourceId = sourceIdForFeature(hit);
  if (!sourceId || !map.getSource(sourceId)) return null;
  const sourceIds = new Set<string>([sourceId]);
  // 同名要素可能挂在多张表：当前视口全部已挂载 MVT source 都查一遍，避免只拿本表片段
  for (const key of listMountedVectorTileKeys()) {
    const id = `mvt-src-${key.replace(/[^a-zA-Z0-9_-]/g, '_')}`;
    if (map.getSource(id)) sourceIds.add(id);
  }
  const parts: MvtFeatureLike[] = [];
  for (const id of sourceIds) {
    try {
      const features = map.querySourceFeatures(id, { sourceLayer: MVT_SOURCE_LAYER }) as MvtFeatureLike[];
      for (const feature of features) {
        if (mvtFeatureIdentity(feature) === identity) parts.push(feature);
      }
    } catch {
      /* 某个 source 尚未就绪：跳过，不影响其他 source */
    }
  }
  return mergeFeatureParts(parts.length ? parts : [hit]);
}
