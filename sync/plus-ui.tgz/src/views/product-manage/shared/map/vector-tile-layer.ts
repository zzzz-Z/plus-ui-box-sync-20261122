/**
 * 元数据矢量瓦片图层（地图侧）
 *
 * 与 renderLayers（GeoJSON 要素渲染）并列的第二条渲染通道：
 *   - renderLayers：拿 metadata-layers 的 geojson，前端建 geojson source；
 *   - 本文件：拿 metadata-tables/{tableKey}/tiles 的 MVT，直接由 maplibre 按 zoom 拉瓦片。
 *
 * WHY 独立成文件：MVT 图层要处理「多表叠加 / 源与图层成对增删 / 底图切换后重挂」三件事，
 * 塞进 use-map.ts 会让那个单例同时承担要素渲染与瓦片渲染两种关注点。
 *
 * 关键约束：
 *   1. MVT 图层名恒为 `metadata`（后端固定），不是 tableKey；
 *   2. 每种矢量图层要三层：fill / line / circle——同一个 source 的要素可能是面/线/点，
 *      只建一层会有一半几何看不见；其中 circle 必须用 geometry-type 过滤只画 Point/MultiPoint，
 *      否则 circle 会连面、线要素的每个顶点也画成圆点；
 *   3. 底图 setStyle 会清空所有 source/layer，必须由调用方 watch styleVersion 重挂。
 */
import type { Map as MapLibreMap } from 'maplibre-gl';
import { MVT_SOURCE_LAYER } from '@/api/product-manage/platform/metadata-tiles';

/** 一张元数据表对应的图层配置 */
export interface VectorTileLayerSpec {
  /** 唯一 key（用 `${resourceUid}:${tableKey}`），用于增删时定位 */
  key: string;
  /** maplibre source 的 tiles URL（已含 {z}/{x}/{y} 与网关前缀） */
  url: string;
  /** 图例 / 弹窗展示用的表名 */
  label: string;
  /** 线 / 面的主色；同一个资源的多张表按调用方给的调色板取色 */
  color: string;
  /** 最大可用 zoom：实测超出该级别服务端返回 404，maplibre 会停止拉取，避免刷一堆 404 */
  maxzoom?: number;
}

/** 已挂到地图上的图层记录（source id 与三个 layer id） */
interface MountedLayer {
  sourceId: string;
  layerIds: string[];
  /**
   * 挂载时传入的表名。
   *
   * WHY 存下来：点击地图上的 MVT 要素时只能拿到 `feature.layer.id`（`mvt-fill-xxx`），
   * 要显示「这是哪张表」必须反查 spec —— 调用方的 key→表名映射不在这里，
   * 每次点击再去问调用方会把「图层自己是什么」这件事外泄给业务层。
   */
  label: string;
  /** 挂载时的原始 key（`${resourceUid}:${tableKey}`），与 id 的反解值不同，必须原样保存 */
  key: string;
}

const mounted = new Map<string, MountedLayer>();

/** 生成不冲突的 id：maplibre 的 source/layer id 全局唯一 */
function uid(prefix: string, key: string): string {
  return `${prefix}-${key.replace(/[^a-zA-Z0-9_-]/g, '_')}`;
}

/**
 * 挂载一张元数据表的矢量瓦片图层。
 * 重复调用同一 key 会先移除旧图层再重挂（避免叠层）。
 */
export function mountVectorTileLayer(map: MapLibreMap, spec: VectorTileLayerSpec) {
  unmountVectorTileLayer(map, spec.key);

  const sourceId = uid('mvt-src', spec.key);
  if (map.getSource(sourceId)) map.removeSource(sourceId);

  map.addSource(sourceId, {
    type: 'vector',
    tiles: [spec.url],
    // 服务端 MVT 的坐标系是 Web Mercator 瓦片标准，无需 minzoom/maxzoom 声明底限；
    // maxzoom 只影响 maplibre 何时停止放大取瓦片（超过后由 overzoom 逻辑拉伸显示）
    maxzoom: spec.maxzoom ?? 13
  });

  const layerIds: string[] = [];

  // 面：填充 + 描边（fill 只画内部，边界靠 line 层）
  const fillId = uid('mvt-fill', spec.key);
  map.addLayer({
    id: fillId,
    type: 'fill',
    source: sourceId,
    'source-layer': MVT_SOURCE_LAYER,
    paint: { 'fill-color': spec.color, 'fill-opacity': 0.35 }
  } as any);
  layerIds.push(fillId);

  const lineId = uid('mvt-line', spec.key);
  map.addLayer({
    id: lineId,
    type: 'line',
    source: sourceId,
    'source-layer': MVT_SOURCE_LAYER,
    paint: { 'line-color': spec.color, 'line-width': 1.4, 'line-opacity': 0.9 }
  } as any);
  layerIds.push(lineId);

  // 点：circle 兜底，保证点要素也能看见。
  // 必须限定只画点：maplibre 的 circle 图层会对几何的「每个顶点」都生成一个圆
  // （CircleBucket.addFeature 遍历 geometry 的每个 point），若不加过滤，面/线要素的
  // 每个顶点都会被画成小圆点（截图里绿色矩形四角的绿圆即由此而来），而瓦片数据本身没有点要素。
  const circleId = uid('mvt-circle', spec.key);
  map.addLayer({
    id: circleId,
    type: 'circle',
    source: sourceId,
    'source-layer': MVT_SOURCE_LAYER,
    filter: ['match', ['geometry-type'], ['Point', 'MultiPoint'], true, false],
    paint: { 'circle-color': spec.color, 'circle-radius': 4, 'circle-stroke-color': '#fff', 'circle-stroke-width': 1 }
  } as any);
  layerIds.push(circleId);

  mounted.set(spec.key, { sourceId, layerIds, label: spec.label, key: spec.key });
}

/**
 * 重涂已挂载瓦片图层的颜色。
 *
 * WHY 需要：颜色在 mount 时写死进 maplibre 的 paint 属性，而图例直接读响应式 palette 实时变色；
 * 配色方案切换后不重涂，就会出现「图例已变色、地图还是旧色」的不一致。
 * layer id 前缀（mvt-fill / mvt-line / mvt-circle）即几何类型，据此选对应的 paint 属性。
 */
export function restyleVectorTileLayer(map: MapLibreMap, key: string, color: string) {
  const rec = mounted.get(key);
  if (!rec) return;
  for (const id of rec.layerIds) {
    if (!map.getLayer(id)) continue;
    if (id.startsWith('mvt-fill')) map.setPaintProperty(id, 'fill-color', color);
    else if (id.startsWith('mvt-line')) map.setPaintProperty(id, 'line-color', color);
    else if (id.startsWith('mvt-circle')) map.setPaintProperty(id, 'circle-color', color);
  }
}

/** 移除一张表的瓦片图层；key 不存在时静默返回（幂等，调用方不必先判存在） */
export function unmountVectorTileLayer(map: MapLibreMap, key: string) {
  const rec = mounted.get(key);
  if (!rec) return;
  for (const id of rec.layerIds) {
    if (map.getLayer(id)) map.removeLayer(id);
  }
  if (map.getSource(rec.sourceId)) map.removeSource(rec.sourceId);
  mounted.delete(key);
}

/** 清空本模块挂载的所有瓦片图层（切 tab / 组件卸载 / 底图切换前调用） */
export function unmountAllVectorTileLayers(map: MapLibreMap) {
  for (const key of [...mounted.keys()]) unmountVectorTileLayer(map, key);
}

/** 当前已挂载的 key 列表（调试 / 图例用） */
export function listMountedVectorTileKeys(): string[] {
  return [...mounted.keys()];
}

/**
 * 当前所有已挂载图层的 maplibre 渲染层 id（fill / line / circle 全量）。
 *
 * WHY 需要：`map.queryRenderedFeatures(point, { layers })` 必须显式给出候选层，
 * 不给就会把底图道路、其他模块的 geojson 图层一起算进来 —— 点底图也会弹本页的详情。
 * 层 id 是 `uid()` 的产物，只有本模块知道，故由本模块统一导出，调用方不自己拼。
 */
export function listMountedVectorTileLayerIds(): string[] {
  return [...mounted.values()].flatMap((rec) => rec.layerIds);
}

/** 已挂载瓦片图层的信息（点击要素后反查「这是哪张表」用） */
export interface MountedVectorTileInfo {
  /** 原始 key（`${resourceUid}:${tableKey}`） */
  key: string;
  /** 挂载时传入的表名 */
  label: string;
}

/**
 * 由 maplibre 的 layer id 反查所属瓦片图层。
 *
 * WHY 需要：`map.on('click')` 拿到的只有渲染层 id（`mvt-fill-xxx` / `mvt-line-xxx` / `mvt-circle-xxx`），
 * 而业务要知道的是「哪张表」和「它的原始 key」。本模块的 id 是 key 经字符替换后的产物
 * （非 `[a-zA-Z0-9_-]` 一律变 `_`），**不能由 id 反推 key**，只能在 mounted 里反向查找。
 * 单次点击命中多个图层是常态（面同时命中 fill 与 line），调用方按需去重。
 */
export function findMountedVectorTileByLayerId(layerId: string): MountedVectorTileInfo | null {
  for (const [key, rec] of mounted) {
    if (rec.layerIds.includes(layerId)) return { key, label: rec.label };
  }
  return null;
}
