<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
import GeoMap from '@/components/product-manage/geo-map/index.vue';
import { useProductPalette } from '@/views/product-manage/shared/store.js';
import Legend from '@/views/product-manage/shared/map/legend.vue';
import QueryPanel from './query/index.vue';
import { ElMessage } from 'element-plus';
import { clearDrawGraphics, clearSampleSelection, drawClearSignal, mapQueryLoading, runGeometryQuery, sampleQuery, setDrawTool } from './query/state';
import { Search, RefreshLeft, Delete, List } from '@element-plus/icons-vue';
import type { ToolbarItem } from '@/components/product-manage/geo-map/toolbar-types';
import { useMap } from '@/views/product-manage/shared/map/use-map';
import type { BasemapOption } from '@/components/product-manage/geo-map/use-basemaps';
import { basemapToOption, OFFLINE_BASEMAPS } from '@/components/product-manage/geo-map/use-basemaps';
import { listBasemaps } from '@/api/product-manage/platform/basemap';
import { useFeatureDetail } from './use-feature-detail';

/**
 * 地图容器 —— 只负责：
 *   1. 挂载 GeoMap，把首帧 @ready / 底图切换 @style-change 的 { map, utils } 写入 useMap 单例；
 *   2. 提供查询面板、图例、绘制工具等地图周边 UI；
 *   3. 绘制完成后按几何筛选样本，写回 queryState.selectedIds。
 *
 * 图层渲染全部下放到各业务模块（data-browse / data-into-store / data-extraction / data-update 等），
 * 由各模块通过 useMap().renderLayers() 自持图层 —— 与 data-browse 的做法一致。
 * 这样 map 不必再根据 tabName 分支判断渲染样式，避免出现「两套图层叠加」/「判断条件漏匹配」的问题。
 */

const props = defineProps<{ tabName?: string; fullscreenContainer?: HTMLElement; pauseResize?: boolean }>();

// 地图右下角操作栏：查询面板开合、3D 白膜开关
const queryOpen = ref(true);
const extrusion = ref(true);
/** 图例显隐：由右下工具栏的「图例」按钮切换，默认显示 */
const legendOpen = ref(true);

/**
 * 50 万标准图幅格网（grid50）开关。
 * WHY 持久化到 localStorage：这是「底衬参考线」，属于用户偏好而非页面状态，
 * 刷新后应保持上次选择；沿用项目里地图相机持久化的同一套前缀习惯。
 * 默认关闭 —— 8104 个面在全球视角下会明显压低帧率，需要时手动打开。
 */
const GRID_STORAGE_KEY = 'geo-map-grid50:v1';
const gridLayer = ref(localStorage.getItem(GRID_STORAGE_KEY) === '1');
watch(gridLayer, (v) => {
  try {
    localStorage.setItem(GRID_STORAGE_KEY, v ? '1' : '0');
  } catch {
    /* 隐私模式 / 配额满：开关仍生效，只是不记忆 */
  }
});

const mapStore = useMap();
const { palette } = useProductPalette();

// 数据查询模式：显示查询面板与操作栏的查询按钮

const showQueryPanel = computed(() => props.tabName?.includes('数据查询'));

/**
 * 底图源：优先「系统管理 · 电子地图底图」的在线接口数据；
 * **仅当接口无数据（返回空列表 / 请求异常）时**才回退内置离线底图作为兜底。
 *
 * WHY 不再把内置底图混入列表：两者 id 口径不同（内置 `offline-china` vs 后端 `bm-offline-china`），
 * 混排会让下拉出现两个同名「离线·中国」；且业务口径是「在线接口为唯一真源，本地只作断网兜底」。
 */
const basemapOptions = ref<BasemapOption[] | undefined>(undefined);
async function loadBasemaps() {
  try {
    // 不传 pageNum/pageSize：契约规定缺省即全量，地图下拉需要完整列表
    const res = await listBasemaps();
    const items = res?.data?.items ?? [];
    if (items.length) {
      basemapOptions.value = items.map(basemapToOption);
      return;
    }
  } catch {
    // 接口异常：落到下面统一走离线兜底
  }
  // 接口确实没有数据（或不可用）：回退内置离线底图，保证无网络时仍有底图可渲染
  basemapOptions.value = OFFLINE_BASEMAPS;
}
onMounted(loadBasemaps);

// ------ 绘制工具 → GeoMap ------
// [why] sample-query 通过 setDrawTool 写状态，此处只做转发与回调：
//   - drawToolForMap 把 'none' 归一为 '' 与 GeoMap prop 语义对齐
//   - onDrawComplete 按几何命中样本，写回 selectedIds（地图/列表同步高亮），并复位绘制工具
const drawToolForMap = computed(() => (sampleQuery.drawTool === 'none' ? '' : sampleQuery.drawTool));

/** 业务侧工具栏项：数据查询面板开关（仅查询 tab 显示） */
const toolbarItems = computed<ToolbarItem[]>(() => {
  const items: ToolbarItem[] = [];
  if (showQueryPanel.value) {
    items.push({
      type: 'button',
      key: 'query',
      icon: Search,
      tooltip: pt('数据查询'),
      active: queryOpen.value,
      onClick: () => {
        queryOpen.value = !queryOpen.value;
      }
    });
  }
  // 图例开关：把图例显隐收敛到地图下方工具栏，与查询/清除/重置同一入口
  items.push({
    type: 'button',
    key: 'legend',
    icon: List,
    tooltip: legendOpen.value ? pt('隐藏图例') : pt('显示图例'),
    active: legendOpen.value,
    onClick: () => {
      legendOpen.value = !legendOpen.value;
    }
  });
  // 业务自定义按钮：框选查询 / 清除选区 / 重置视图
  items.push(
    // {
    //   type: 'button',
    //   key: 'draw-rect',
    //   icon: Crop,
    //   tooltip: '框选查询',
    //   active: sampleQuery.drawTool === 'rectangle',
    //   onClick: () => setDrawTool(sampleQuery.drawTool === 'rectangle' ? 'none' : 'rectangle')
    // },
    {
      type: 'button',
      key: 'clear-selection',
      icon: Delete,
      tooltip: pt('清除选区与绘制图形'),
      onClick: () => {
        // 与选择卡片的「清除」保持同一语义：只取消勾选、保留查询结果；
        // 额外擦掉业务侧绘制引擎留在地图上的图形（draw 引擎不随 selectedIds 清空而消失）。
        clearSampleSelection();
        clearDrawGraphics();
        ElMessage.success(pt('已清除选区与绘制图形'));
      }
    },
    {
      type: 'button',
      key: 'reset-view',
      icon: RefreshLeft,
      tooltip: pt('重置视图'),
      onClick: () => {
        mapStore.mapInstance.value?.flyTo({ center: [116.3974, 39.9093], zoom: 10 });
      }
    }
  );
  return items;
});

/**
 * 绘制完成回调：把几何交给 runGeometryQuery，用真实图层要素（metadata-layers 的 geojson）求交，
 * 命中集写入 queryState.selectedIds / hitFeatures。
 * WHY 不在此 reset 绘制工具以外的状态：selectedIds 更新会自动驱动图层渲染与列表勾选（双向联动）。
 */
async function onDrawComplete(feature: any) {
  const labelMap: Record<string, string> = { Polygon: pt('面'), LineString: pt('折线') };
  const label = labelMap[feature?.geometry?.type] ?? '范围';
  setDrawTool('none');
  const res = await runGeometryQuery(feature);
  ElMessage.success(res.count ? `已按${label}框选，命中 ${res.count} 个图层要素` : `已按${label}框选，当前范围内没有要素`);
}

/** GeoMap 首帧就绪：拿 map + utils 写入单例 */
function onReady(payload: { map: any; utils: any }) {
  mapStore.setMap(payload);
}

/** 底图切换后 setStyle 会清空所有 source/layer：自增版本号触发各业务模块的图层组重挂 */
function onStyleChange(payload: { map: any; utils: any }) {
  mapStore.setMap(payload);
  mapStore.bumpStyleVersion();
}

/**
 * 点击地图要素弹详情（MVT 瓦片通道）。
 * 在这里挂一次即可覆盖 data-browse / data-query / records-edit 等所有走瓦片通道的模块；
 * GeoJSON 图层组通道由各业务模块在自己的 onFeatureClick 里调 openFeatureDetail。
 */
useFeatureDetail();
</script>

<template>
  <GeoMap
    v-loading="mapQueryLoading"
    element-loading-text="查询中…"
    v-model:extrusion="extrusion"
    v-model:grid-layer="gridLayer"
    :toolbar-items="toolbarItems"
    class="map-panel"
    :pause-resize="pauseResize"
    :basemap-switcher="(basemapOptions?.length ?? 0) > 1"
    :basemaps="basemapOptions"
    :draw-tool="drawToolForMap"
    :clear-draw-signal="drawClearSignal"
    :fullscreen-container="fullscreenContainer"
    @draw-complete="onDrawComplete"
    @ready="onReady"
    @style-change="onStyleChange"
  >
    <Legend v-if="legendOpen" :palette="palette" />
    <QueryPanel v-if="showQueryPanel" v-model:open="queryOpen" />
  </GeoMap>
</template>

<style lang="scss">
.metadata-popup {
  color: #26364b;
  font-family: inherit;
}
.metadata-popup__title {
  margin-bottom: 9px;
  color: #172b4d;
  font-size: 15px;
  font-weight: 700;
}
.metadata-popup__meta {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-bottom: 10px;
  color: #728096;
  font-size: 12px;
}
.metadata-popup__tag {
  padding: 2px 7px;
  color: #2563a8;
  background: #e8f2ff;
  border-radius: 10px;
}
.metadata-popup__description {
  padding-top: 9px;
  border-top: 1px solid #edf1f5;
  color: #56667c;
  font-size: 12px;
  line-height: 1.6;
}
.metadata-popup__status {
  padding-top: 9px;
  border-top: 1px solid #edf1f5;
}
.store-popup__label {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-bottom: 6px;
  font-size: 12px;
  font-weight: 600;
}
.store-popup__dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
}
.store-popup__percent {
  margin-left: auto;
  color: #728096;
  font-weight: 500;
}
.store-popup__track {
  height: 6px;
  overflow: hidden;
  background: #edf1f5;
  border-radius: 3px;
}
.store-popup__bar {
  height: 100%;
  border-radius: 3px;
  transition: width 0.3s ease;
}
.store-popup__message {
  margin-top: 6px;
  color: #56667c;
  font-size: 12px;
  line-height: 1.6;
}
</style>
