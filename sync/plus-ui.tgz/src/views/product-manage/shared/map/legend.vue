<script setup lang="ts">
import { queryState, toggleCategoryOnMap, mountedCategoryNames } from './query/state';

/**
 * 地图图例面板（初级产品 / 产品成果共用）
 *
 * 纯展示：类别与颜色均由调用方注入（palette 键与产品类型树叶子类别名对齐）。
 * 颜色只读展示 —— 修改配色统一在产品类型管理 / 配色方案处进行，图例不提供选择器。
 *
 * 内容**严格跟随左侧树上实际挂载（勾选）的资源所属类别**：只列 `mountedCategoryNames`
 * 里出现的类别（即用户在树上勾选、真正上图画层的资源所属的类别），没有资源勾选的
 * 类别一律不显示。WHY 不列「树上出现过但未勾选」的类别：地图只渲染勾选的资源，
 * 图例若把未勾选的空类别列出来，会与「图例应反映地图上实际显示的类型」直接矛盾 ——
 * 宁可少列（甚至暂时为空），也不凭空多列。
 * 左树尚未就绪（mountedCategoryNames 为 null）或该页面没有左侧树时，图例不渲染。
 *
 * 停靠位置：地图右侧边缘、紧贴 maplibre 原生控件竖条左侧（右侧只与右上控件、右下工具栏共存，
 * 是地图上最空闲的竖直带）。左上角留给要素 / 气泡 / 比例尺等读数区。
 * 同页另一个右停靠浮层（查询面板）由调用方通过 --map-legend-w 让位，见 query/panel.vue。
 */
const props = defineProps<{
  /** 类别 → 填充色；键与产品类型树叶子类别名对齐 */
  palette: Record<string, string>;
  title?: string;
  /** 各类别记录数，传入时在行尾显示计数（不传则不显示） */
  counts?: Record<string, number>;
}>();

/** 已勾选（在地图上显示）的类别数，显示在标题栏 */
const activeCount = computed(() => paletteEntries.value.filter(([name]) => isActive(name)).length);

/**
 * 图例条目：palette 按左侧树实际挂载（勾选）资源所属类别严格过滤。
 * 树未就绪（null）→ 空；没有任何已挂载类别与 palette 对得上 → 也是空（不再退回全量）。
 */
const paletteEntries = computed<[string, string][]>(() => {
  const scope = mountedCategoryNames.value;
  if (!scope || !scope.size) return [];
  return Object.entries(props.palette).filter(([name]) => scope.has(name));
});

/** 该类别是否在地图上显示；activeCategories 为 null 表示未初始化 = 默认全选 */
function isActive(category: string) {
  const active = queryState.activeCategories;
  return active === null ? true : active.includes(category);
}

/** 点击图例行：切换该类别的地图显示（首次点击会把「默认全选」展开为显式集合） */
function onToggle(category: string) {
  toggleCategoryOnMap(
    category,
    paletteEntries.value.map(([name]) => name)
  );
}
</script>

<template>
  <div v-if="paletteEntries.length" class="map-tools">
    <div class="overlay-title">
      <span>{{ title ?? '图例' }}</span>
      <span class="overlay-count">{{ activeCount }}/{{ paletteEntries.length }}</span>
    </div>
    <div class="legend-body">
      <div
        v-for="[category, color] in paletteEntries"
        :key="category"
        class="legend-row"
        :class="{ 'is-off': !isActive(category) }"
        @click="onToggle(category)"
      >
        <span class="legend-swatch" :style="{ background: color }" />
        <span class="legend-name" :title="category">{{ category }}</span>
        <em v-if="counts">
          {{ counts[category] ?? 0 }}
        </em>
      </div>
      <slot />
    </div>
  </div>
</template>

<style scoped lang="scss">
.map-tools {
  position: absolute;
  /* WHY 右侧停靠（right: 原生控件竖条左侧）而非左上：
     - 左上角是地图的读数区（比例尺在左下、气泡会跟随要素弹出，图例常驻会与之打架）；
     - 右侧只有「右上原生控件 / 右下自定义工具栏」两条窄竖条，减掉它们之后整条竖直带是空的，
       图例停在这里既不压控件，也离右边框最近，符合「辅助说明贴边」的阅读习惯。
     偏移量走 GeoMap 在 .geo-map 上声明的 --map-ctrl-rail（右上控件竖条占位宽），
     组件被单独复用时用同值兜底，避免依赖调用顺序。 */
  top: 6px;
  right: var(--map-ctrl-rail, 52px);
  z-index: 6;
  /* WHY 显式 flex 列 + max-height：地图高度可能只有 300px 出头（列表/地图上下分栏时），
     早先固定 max-height:300 的 body 会把整张卡片顶出地图下沿。改为卡片自身按地图高度封顶，
     标题条恒在，类别列表在剩余高度里滚动。 */
  display: flex;
  flex-direction: column;
  width: var(--map-legend-w, 176px);
  /* WHY min(360px, 100%-12px)：地图高时图例不必把整条竖直带吃满（360px 已能容 12 类不滚动，
     再多就滚），地图矮时（列表/地图上下分栏）按可用高度收缩，绝不出下沿。 */
  max-height: min(360px, calc(100% - 12px));
  padding: 10px 12px;
  /* 显隐由工具栏「图例」开关统一控制（见 map/index.vue 的 legendOpen），组件内不再自带折叠。 */
  /* 与查询面板 / 地图气泡统一的玻璃表面（半透明底 + 模糊 + 统一描边/阴影/圆角） */
  background: rgb(255 255 255 / 96%);
  border: 1px solid rgb(31 55 84 / 10%);
  border-radius: 8px;
  box-shadow: 0 6px 18px rgb(25 45 70 / 14%);
  backdrop-filter: blur(8px);
}
.overlay-title {
  display: flex;
  /* WHY flex:none：标题条恒在、不参与压缩；压缩只发生在 .legend-body（类别列表）上，
     否则矮地图下一压，标题行本身会被挤成两行。 */
  flex: none;
  align-items: center;
  gap: 6px;
  user-select: none;
  margin-bottom: 8px;
  padding-bottom: 8px;
  color: #172b4d;
  font-size: 13px;
  font-weight: 600;
  border-bottom: 1px solid rgb(31 55 84 / 8%);
}
.overlay-title::before {
  width: 3px;
  height: 12px;
  background: #2563eb;
  border-radius: 2px;
  content: '';
}
.overlay-title > span:first-child {
  flex: 1;
}
.overlay-count {
  color: var(--el-text-color-secondary);
  font-size: 11px;
  font-weight: 500;
  font-variant-numeric: tabular-nums;
}
.legend-body {
  display: flex;
  flex-direction: column;
  gap: 1px;
  /* WHY flex:1 + min-height:0 而非固定 max-height：类别较多时（如十几类）滚动条落在列表上，
     卡片总高由 .map-tools 的 max-height 按地图高度封顶 —— 地图矮时列表自然变短，卡片不会溢出地图。
     早先是 max-height:300 的硬编码，与地图实际高度无关，矮地图下会顶出下沿。 */
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  overflow-x: hidden;
}
.legend-row {
  display: flex;
  align-items: center;
  gap: 7px;
  min-height: 24px;
  padding: 0 4px;
  color: var(--el-text-color-regular);
  font-size: 12px;
  border-radius: 4px;
  cursor: pointer;
  user-select: none;
  transition: background 0.12s;
  &:hover {
    background: var(--el-fill-color-light);
  }
  &.is-off {
    color: var(--el-text-color-placeholder);
  }
  /* 未勾选：保留真实配色，仅降饱和/透明度，表明「未上图」 */
  &.is-off .legend-swatch {
    opacity: 0.35;
    filter: saturate(0.4);
  }
}
.legend-swatch {
  flex: none;
  width: 13px;
  height: 13px;
  border: 1px solid rgb(31 55 84 / 20%);
  border-radius: 3px;
  transition:
    background 0.12s,
    border-color 0.12s;
}
.legend-name {
  flex: 1;
  /* 长类别名（含后端可能返回的异常长串）截断并悬浮提示，避免撑破图例行 */
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.legend-row em {
  color: var(--el-text-color-secondary);
  font-style: normal;
}
</style>
