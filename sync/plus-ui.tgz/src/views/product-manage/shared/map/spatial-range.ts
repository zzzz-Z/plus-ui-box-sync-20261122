/**
 * 元数据「空间范围」归一化工具
 *
 * 后端把一条记录的空间范围放在 `values.spatial_range` 里，形态并不统一：
 *   ① GeoJSON Geometry / Feature 对象；
 *   ② 上述对象的 JSON 序列化字符串（契约把该字段声明为 string，序列化后最常见）；
 *   ③ WKT 字符串（`POLYGON ((…))` / `MULTIPOLYGON (((…)))` / `POINT (…)`，PostGIS 还会带 `SRID=4326;` 前缀）。
 *
 * 地图侧只关心 GeoJSON Geometry，本文件是「三种形态 → GeoJSON」的唯一出口。
 *
 * WHY 手写解析而不引 wkt / wellknown 之类的库：
 *   1. 只需要「拿到坐标」这一件事，库带来的异常形态（解析失败抛错）反而要再包一层兜底；
 *   2. 解析失败必须静默返回 null —— 一条记录的范围坏了不该打断整页/整批加载；
 *   3. 项目已有 @turf 但没有 WKT 解析，为一个小函数多装依赖不值当。
 */

/** 经纬度范围 [minLng, minLat, maxLng, maxLat] */
export type Bounds4 = [number, number, number, number];

/**
 * 支持的简单类型 → { GeoJSON 规范名, `coordinates` 嵌套深度 }
 *（Point=0，LineString/MultiPoint=1，Polygon/MultiLineString=2，MultiPolygon=3）
 *
 * WHY 规范名和 WKT 写法分开登记：WKT 是全大写，GeoJSON 的 type 必须逐字是
 * `Point` / `MultiPolygon` 这种驼峰 —— 靠 lowerFirst 拼会得到 `Multipolygon`，
 * maplibre 直接把整层数据判成无效几何（要素画不出来， yet 包围盒仍然「正常」，最难查）。
 */
const GEOM_SPECS: Record<string, { name: string; depth: number }> = {
  POINT: { name: 'Point', depth: 0 },
  MULTIPOINT: { name: 'MultiPoint', depth: 1 },
  LINESTRING: { name: 'LineString', depth: 1 },
  LINEARRING: { name: 'LineString', depth: 1 },
  MULTILINESTRING: { name: 'MultiLineString', depth: 2 },
  POLYGON: { name: 'Polygon', depth: 2 },
  MULTIPOLYGON: { name: 'MultiPolygon', depth: 3 }
};

/** GeoJSON Geometry 类型名（小写）→ 规范名 */
const GEOJSON_TYPES = new Set(['point', 'multipoint', 'linestring', 'multilinestring', 'polygon', 'multipolygon', 'geometrycollection']);

/**
 * 按**顶层**逗号切分（括号内的逗号不算分隔符）。
 * WHY 需要深度感知：`POLYGON ((1 2, 3 4),(5 6, 7 8))` 里环内也有逗号，
 * 直接 split(',') 会把一个环拆碎。
 */
function splitTop(text: string): string[] {
  const out: string[] = [];
  let depth = 0;
  let start = 0;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (ch === '(') depth += 1;
    else if (ch === ')') depth -= 1;
    else if (ch === ',' && depth === 0) {
      out.push(text.slice(start, i));
      start = i + 1;
    }
  }
  out.push(text.slice(start));
  return out.map((s) => s.trim()).filter((s) => s.length > 0);
}

/** 去掉一对最外层括号（`(1 2)` → `1 2`）；不是括号包裹就原样返回 */
function stripParen(text: string): string {
  const t = text.trim();
  if (t.startsWith('(') && t.endsWith(')')) return t.slice(1, -1).trim();
  return t;
}

/**
 * 把「一个 x y（可带 Z/M 后缀）」的片段转成 [lng, lat]。
 * WHY 只取前两位：PostGIS 的 3D/4D 坐标（`1 2 300` / `1 2 300 5`）很常见，
 * 第三四位是高程与测量值，对经纬度包围盒没有意义，带着会让 bbox 计算出界。
 */
function toPair(text: string): number[] | null {
  const parts = text
    .trim()
    .split(/\s+/)
    .map(Number)
    .filter((n) => Number.isFinite(n));
  if (parts.length < 2) return null;
  return [parts[0], parts[1]];
}

/**
 * 递归取到目标深度的坐标结构。
 * `depth === 0` 时当前段应是一个坐标对；否则剥一层括号、按顶层逗号往下拆。
 * 拆不出来的分支直接丢弃（返回 null 由上层 filter），坏一环不影响整形。
 */
function toCoordinates(seg: string, depth: number): any {
  if (depth <= 0) return toPair(stripParen(seg));
  const kids = splitTop(stripParen(seg))
    .map((s) => toCoordinates(s, depth - 1))
    .filter((v) => v != null);
  return kids.length ? kids : null;
}

/** 收集一段文本里所有合法坐标对（GEOMETRYCOLLECTION 等混合结构用它兜底） */
function collectPairs(text: string): number[][] {
  const out: number[][] = [];
  const re = /(-?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?)\s+(-?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text))) {
    const lng = Number(m[1]);
    const lat = Number(m[2]);
    if (Number.isFinite(lng) && Number.isFinite(lat)) out.push([lng, lat]);
  }
  return out;
}

/**
 * WKT → GeoJSON Geometry；无法识别返回 null。
 *
 * 拆解口径：`body` 是最外层括号内的内容，按 `COORD_DEPTH` 逐层往下拆——
 * `POLYGON` 的 body 是「环的列表」（depth 2），`MULTIPOLYGON` 是「多边形的列表」（depth 3），
 * `POINT` 就是一个坐标对（depth 0）。所以顶层先 splitTop，再对每段递归 depth-1。
 */
export function wktToGeometry(wkt: string): any | null {
  // SRID 前缀（`SRID=4326;POLYGON(...)`，PostGIS 常见）先剥掉
  const raw = String(wkt ?? '')
    .trim()
    .replace(/^SRID=\d+;\s*/i, '');
  if (!raw) return null;
  const m = raw.match(/^([A-Za-z_]+)\s*\((.+)\)$/s);
  if (!m) return null;
  const type = m[1].toUpperCase();
  const body = m[2].trim();
  if (!body || /^EMPTY$/i.test(body)) return null;

  if (type === 'GEOMETRYCOLLECTION') {
    // 混合结构：按顶层逗号拆成子几何逐个解析，全失败则退化为点集（只为保住包围盒）
    const parts = splitTop(body)
      .map((s) => wktToGeometry(s))
      .filter(Boolean);
    if (parts.length) return { type: 'GeometryCollection', geometries: parts };
    const pairs = collectPairs(body);
    return pairs.length ? { type: 'MultiPoint', coordinates: pairs } : null;
  }

  const spec = GEOM_SPECS[type];
  if (!spec) return null;

  if (spec.depth === 0) {
    const pair = toPair(body);
    return pair ? { type: spec.name, coordinates: pair } : null;
  }
  const coordinates = splitTop(body)
    .map((s) => toCoordinates(s, spec.depth - 1))
    .filter((v) => v != null);
  if (!coordinates.length) return null;
  return { type: spec.name, coordinates };
}

/**
 * 把 `spatial_range` 归一为 GeoJSON Geometry。
 * 对象 / JSON 字符串 / WKT 三种形态都吃，识别不了返回 null，不抛错。
 */
export function spatialRangeToGeometry(input: unknown): any | null {
  if (input == null) return null;

  if (typeof input === 'object') {
    const obj = input as any;
    if (obj.type === 'Feature' && obj.geometry) return obj.geometry;
    if (typeof obj.type === 'string' && Array.isArray(obj.coordinates) && GEOJSON_TYPES.has(obj.type.toLowerCase())) return obj;
    if (obj.type === 'GeometryCollection' && Array.isArray(obj.geometries)) return obj;
    return null;
  }

  const raw = String(input).trim();
  if (!raw) return null;
  if (raw.startsWith('{') || raw.startsWith('[')) {
    try {
      return spatialRangeToGeometry(JSON.parse(raw));
    } catch {
      return null;
    }
  }
  return wktToGeometry(raw);
}

/**
 * GeoJSON Geometry → 包围盒 `[minLng, minLat, maxLng, maxLat]`。
 * 递归走坐标（各类型嵌套深度不同，不必按类型分支），没有有效坐标返回 null。
 */
export function geometryBounds(geometry: any): Bounds4 | null {
  let minLng = Infinity;
  let minLat = Infinity;
  let maxLng = -Infinity;
  let maxLat = -Infinity;
  let found = false;

  const walk = (node: any) => {
    if (!Array.isArray(node)) return;
    if (typeof node[0] === 'number') {
      const [lng, lat] = node;
      if (!Number.isFinite(lng) || !Number.isFinite(lat)) return;
      found = true;
      if (lng < minLng) minLng = lng;
      if (lng > maxLng) maxLng = lng;
      if (lat < minLat) minLat = lat;
      if (lat > maxLat) maxLat = lat;
      return;
    }
    for (const kid of node) walk(kid);
  };

  if (geometry?.type === 'GeometryCollection') {
    for (const g of geometry.geometries ?? []) walk(g?.coordinates);
  } else {
    walk(geometry?.coordinates);
  }
  return found ? [minLng, minLat, maxLng, maxLat] : null;
}

/** 多个包围盒的并集；空数组返回 null */
export function mergeBounds(list: Bounds4[]): Bounds4 | null {
  if (!list.length) return null;
  let [minLng, minLat, maxLng, maxLat] = list[0];
  for (const b of list) {
    if (b[0] < minLng) minLng = b[0];
    if (b[1] < minLat) minLat = b[1];
    if (b[2] > maxLng) maxLng = b[2];
    if (b[3] > maxLat) maxLat = b[3];
  }
  return [minLng, minLat, maxLng, maxLat];
}
