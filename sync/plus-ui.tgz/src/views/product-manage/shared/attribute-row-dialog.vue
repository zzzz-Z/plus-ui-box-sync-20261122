<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
/**
 * 属性 / 要素详情（createDrawer 内容）—— 全项目唯一的一份「看一条记录的全部字段」视图。
 *
 * 两类入口共用本组件：
 *   1. 属性表行末「详情」按钮（data-browse / records-edit 两张属性表）；
 *   2. 地图上点击矢量要素（shared/map 的公共点击能力，见 map/use-feature-detail.ts）。
 * 两处字段规模一致（元数据记录常有 40+ 个字段），展示诉求完全重合，拆两份只会让样式走样，
 * 所以收口到这里 —— 之前 data-browse 与 records-edit 各存一份内容相同的副本。
 *
 * 展示取舍：
 *   - 两列描述列表铺开，比单列滚动更少、比表格更易读；
 *   - 长值（POLYGON 串、文件路径）默认折两行，需要时展开；
 *   - 每个值可一键复制：路径 / UUID 这类值用户下一站就是贴到别处。
 *   - 不展示数据表 / 账本表键（pgTable / tableKey）：那是排障用的内部标识；
 *   - 不展示技术标识字段（元数据唯一标识 / 资源唯一标识 / 记录主键ID / 流程实例ID / 任务ID 等）：
 *     详情主要显示图层（业务）信息，内部主键 / 外键 / 流程 ID 不给用户看，
 *     与「模型 UID 不显示在页面上」同一口径；业务编码（产品统一编码、图号等）照常展示。
 */
import { computed, onMounted, ref } from 'vue';
import { useElementSize } from '@vueuse/core';
import { CopyDocument, Loading } from '@element-plus/icons-vue';
import {
  localizeFieldLabel,
  orderAttributeColumns,
  type MetadataAttributeColumn,
  type MetadataAttributeRecord
} from '@/api/product-manage/platform/metadata-attributes';

defineOptions({ name: 'AttributeRowDialog' });

/** 异步补全结果：属性表详情直接给全量，地图要素则靠它补齐列中文名与完整字段 */
export interface AttributeRowEnrich {
  row?: Partial<MetadataAttributeRecord>;
  columns?: MetadataAttributeColumn[];
  tags?: string[];
}

const props = withDefaults(
  defineProps<{
    /** 一行记录（地图要素会被包装成同样的形状） */
    row: MetadataAttributeRecord;
    /** 列清单（列名 + 中文标签）；行内可能还有额外键，一并列出 */
    columns: MetadataAttributeColumn[];
    /** 头部信息片：资源名 / 表名 / 几何类型等，空则整块不渲染 */
    tags?: string[];
    /**
     * 打开后再补一次更权威的数据。
     *
     * WHY 需要：地图要素（MVT）里只有后端瓦片带过来的属性，既没有完整列清单（拿不到中文列名），
     * 也可能缺掉不在瓦片里的字段。等接口回来再整表替换，用户不用先盯着空表格。
     * 失败一律忽略：属性本身已经能看，补全只是锦上添花。
     */
    enrich?: () => Promise<AttributeRowEnrich | null | undefined>;
  }>(),
  { tags: () => [] }
);

const extra = ref<AttributeRowEnrich | null>(null);
const loading = ref(false);

onMounted(async () => {
  if (!props.enrich) return;
  loading.value = true;
  try {
    extra.value = (await props.enrich()) ?? null;
  } catch {
    // 补全失败保持首屏数据即可
  } finally {
    loading.value = false;
  }
});

/** 合并后的行：补全值覆盖首屏值（同一字段以后端全量为准） */
const row = computed<MetadataAttributeRecord>(() => {
  const base = props.row;
  const more = extra.value?.row;
  if (!more) return base;
  return { ...base, ...more, values: { ...(base?.values ?? {}), ...(more?.values ?? {}) } };
});

/**
 * 合并后的列：补全拿到的列清单带中文名，优先级高于从属性键猜出来的空标签列。
 * WHY 统一在这里排序：属性表与地图要素详情共用本组件，两侧传来的列顺序口径不同
 * （列表用重要字段优先、地图 enrich 用后端原序），在此收口才能让「点图层」和「点列表」
 * 看到完全相同的字段顺序。
 */
const columns = computed<MetadataAttributeColumn[]>(() => orderAttributeColumns(extra.value?.columns?.length ? extra.value.columns : props.columns));

/** 头部信息片：补全值追加在后面并去重 */
const tagList = computed<string[]>(() => {
  const merged = [...props.tags, ...(extra.value?.tags ?? [])].map((s) => String(s ?? '').trim()).filter(Boolean);
  return [...new Set(merged)];
});

/** 标准 UUID 形态：元数据唯一标识 / 资源唯一标识这类技术 ID，详情里一律不展示 */
const UUID_VALUE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * 技术标识字段判定（详情主要显示图层业务信息，用户口径 2026-11-17「这种ID也都不要」）：
 *   1. 值是标准 UUID（metadata_uid / resource_uid 等，后端列清单带中文名挡不住，按值挡）；
 *   2. 键是内部标识形态：snake 的 _id / _uid / _key 结尾，或驼峰的 Id / Uid / Key 结尾
 *      （记录主键ID、流程实例ID、任务ID 这类外键 / 主键都命中；区分大小写，避免 valid 这类词误伤）；
 *   3. 中文标签去掉括号后缀后以 ID 结尾，或含「主键」（后端 fieldLabels 只给中文时的兜底）。
 * 业务编码（产品统一编码 FLYS-2025…、图号、数字编号字段）不命中任何一条，照常展示。
 */
function isTechnicalField(key: string, label: string, value: string): boolean {
  if (UUID_VALUE.test(value)) return true;
  if (/(?:_id|_uid|_key|Id|Uid|Key)$/.test(key)) return true;
  const bare = label.replace(/[（(].*$/, '').trim();
  return bare.endsWith('ID') || /主键/.test(label);
}

/** 超过这个长度的值先折起来（POLYGON 串可达上千字符） */
const LONG_VALUE = 90;
/** 折叠态短化：保留开头一段 + 省略号 + 结尾一段，让 WKT 首尾坐标都可见 */
const LONG_HEAD = 60;
const LONG_TAIL = 30;

const expanded = ref<Set<string>>(new Set());
const copiedKey = ref('');

/**
 * 列数按自身宽度自适应。
 *
 * WHY：抽屉（createDrawer）最窄只有 420px（clamp 下限），此时两列布局会让两个标签列
 * 各占 132px、值列只剩几十像素，长值被逐字竖排成一条窄条 —— 反而比单列更难读。
 * 用 useElementSize 量根节点宽度而不是读视口：抽屉宽度取决于 clamp，与视口不成正比。
 */
const rootRef = ref<HTMLElement>();
const { width: rootWidth } = useElementSize(rootRef);
const descColumns = computed(() => (rootWidth.value >= 720 ? 2 : 1));

/**
 * 字段清单。三条来源按优先级拼接：
 *   1. `columns` 里有中文标签的项（后端字段清单 + 顺序）；
 *   2. `values` 里多出来的键 —— 用 localizeFieldLabel 再查一遍中文名，查不到的不列
 *      （表头 / 字段名不许有英文，见 metadata-attributes.ts 的约定）；
 *   3. 上面过滤后一个都不剩时退回原始列：详情空着比看到英文字段名更糟。
 */
const items = computed(() => {
  const values = row.value?.values ?? {};
  const cols = columns.value ?? [];
  const out = cols.filter((c) => c.label).map((c) => ({ key: c.key, label: c.label, value: fmt(values[c.key]) }));
  const known = new Set(cols.map((c) => c.key));
  for (const k of Object.keys(values)) {
    if (known.has(k)) continue;
    const label = localizeFieldLabel(k);
    if (!label) continue;
    out.push({ key: k, label, value: fmt(values[k]) });
  }
  const list = out.length ? out : cols.map((c) => ({ key: c.key, label: c.label || c.key, value: fmt(values[c.key]) }));
  // 技术标识字段统一隐藏（含兜底分支）：值形态（UUID）+ 键形态（_id/_uid/_key、Id/Uid/Key）
  // + 标签形态（…ID / 主键）三重判定，覆盖所有表，见 isTechnicalField
  return list.filter((it) => !isTechnicalField(it.key, it.label, it.value));
});

/** 任意值 → 展示文本：null / 空串统一 '-'，对象转 JSON（否则显示 [object Object]） */
function fmt(v: unknown): string {
  if (v == null || v === '') return '-';
  if (typeof v === 'object') {
    try {
      return JSON.stringify(v, null, 0);
    } catch {
      return String(v);
    }
  }
  return String(v);
}

function isLong(value: string) {
  return value.length > LONG_VALUE;
}

function toggleLong(key: string) {
  const next = new Set(expanded.value);
  if (next.has(key)) next.delete(key);
  else next.add(key);
  expanded.value = next;
}

/**
 * 长值折叠态的短化展示：开头一段 + 省略号 + 结尾一段。
 * WHY：WKT 的图斑首尾坐标是判断形状是否闭合 / 落在哪一带的关键信息，
 * 只截前两行会把结尾整段吃掉；展开后仍显示全文，展开/收起逻辑不变。
 */
function displayValue(it: { key: string; value: string }) {
  if (!isLong(it.value) || expanded.value.has(it.key)) return it.value;
  return `${it.value.slice(0, LONG_HEAD)}…${it.value.slice(-LONG_TAIL)}`;
}

/** 复制单值：用 navigator.clipboard，不可用时（非安全上下文）退回 textarea 方案 */
async function copyValue(it: { key: string; value: string }) {
  const text = it.value === '-' ? '' : it.value;
  if (!text) return;
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const el = document.createElement('textarea');
    el.value = text;
    el.style.position = 'absolute';
    el.style.left = '-9999px';
    document.body.append(el);
    el.select();
    document.execCommand('copy');
    el.remove();
  }
  copiedKey.value = it.key;
  ElMessage.success(pt('已复制'));
  window.setTimeout(() => {
    if (copiedKey.value === it.key) copiedKey.value = '';
  }, 1200);
}

/** 弹窗无提交动作：底部按钮只保留关闭，直接放行 */
defineExpose({ action: ([close]: any[]) => close });
</script>

<template>
  <div ref="rootRef" class="row-detail">
    <div v-if="tagList.length" class="row-detail__tags">
      <el-tag v-for="t in tagList" :key="t" size="small" type="info" effect="plain">{{ t }}</el-tag>
    </div>

    <!-- 字段数量文字按需求去掉；只保留补全中的加载提示，enrich 回来即消失 -->
    <div v-if="loading" class="row-detail__bar">
      <span class="row-detail__count">
        <el-icon class="is-loading"><Loading /></el-icon>
        正在加载完整字段…
      </span>
    </div>

    <el-descriptions v-if="items.length" :column="descColumns" border size="small" class="row-fields" :class="{ 'is-narrow': descColumns === 1 }">
      <el-descriptions-item v-for="it in items" :key="it.key" :label="it.label">
        <div class="value" :class="{ 'is-expanded': expanded.has(it.key) }">
          <span class="mono">{{ displayValue(it) }}</span>
          <span class="value__ops">
            <el-link v-if="isLong(it.value)" type="primary" :underline="false" @click="toggleLong(it.key)">
              {{ expanded.has(it.key) ? '收起' : '展开' }}
            </el-link>
            <el-tooltip :content="pt('复制')" placement="top" :show-after="300">
              <el-button link size="small" :icon="CopyDocument" :type="copiedKey === it.key ? 'success' : 'primary'" @click="copyValue(it)" />
            </el-tooltip>
          </span>
        </div>
      </el-descriptions-item>
    </el-descriptions>

    <el-empty v-else :description="pt('该行没有字段值')" :image-size="60" />
  </div>
</template>

<style scoped lang="scss">
/* 滚动交给弹窗 body（.create-dialog .el-dialog__body 已有 max-height + overflow:auto），
   这里不再套一层 max-height，否则会出现「双滚动条」 */
.row-detail {
  min-height: 0;
}

.row-detail__tags {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-bottom: 10px;
}

.row-detail__bar {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  margin-bottom: 10px;
}

.row-detail__count {
  font-size: 12px;
  color: var(--el-text-color-secondary);
}

/* 两列布局：column=2 会把每行渲染成「标签|值|标签|值」四格。
   WHY 要 table-layout: fixed：EP 的描述表格默认是 auto 布局，长中文标签
   （如「影像分辨率 / 地面采样距离（米）」）会把自己的列撑宽、把内容列挤到换行。
   固定布局后标签列锁定宽度，内容列平分剩余宽度，行与行之间对齐。
   窄容器（抽屉最窄 420px）由 descColumns 退成单列，见脚本里的 descColumns */
.row-fields :deep(.el-descriptions__table) {
  table-layout: fixed;
}

.row-fields :deep(.el-descriptions__label) {
  width: 132px;
  font-size: 12.5px;
  line-height: 1.45;
  word-break: break-all;
}

/* 单列模式（详情占位列 / 最窄抽屉都走这里）：长中文标签（如「生产流程实例ID（Flowable）」）
   104px 要折两三行，标签列加宽到 132px 与两列模式对齐；列宽整体已收窄，值列仍够看 */
.row-fields.is-narrow :deep(.el-descriptions__label) {
  width: 132px;
}

.row-fields :deep(.el-descriptions__content) {
  font-size: 12.5px;
  line-height: 1.45;
  /* WHY 不用 break-all：值里常混着「FLYS-2025-10-01」这类带分隔符的编号，
     break-all 会在任意字符处劈开；anywhere 优先在空白/符号处断行，
     只有整段没有断点（POLYGON 坐标串）时才硬断 */
  overflow-wrap: anywhere;
  word-break: normal;
}

.value {
  display: flex;
  align-items: flex-start;
  gap: 8px;
}

.value .mono {
  flex: 1;
  min-width: 0;
}

.value__ops {
  display: flex;
  flex-shrink: 0;
  align-items: center;
  gap: 4px;
  opacity: 0;
  transition: opacity 0.15s;
}

.value:hover .value__ops,
.value.is-expanded .value__ops {
  opacity: 1;
}

.mono {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
}
</style>
