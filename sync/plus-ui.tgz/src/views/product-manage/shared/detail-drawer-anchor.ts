/**
 * 「记录详情」抽屉的纵向锚点解析。
 *
 * 抽屉（composables/create-drawer）的 top / height 完全由 anchor 元素的
 * getBoundingClientRect() 决定，所以「抽屉多高」= 「锚点元素多高」。
 *
 * WHY 锚右侧整列（`.pane-right`）而不是属性表：
 *   用户 2026-11-10 确认，详情抽屉要从地图上沿一直贯穿到页面底部。右侧列
 *   `.pane-right` 里装的正是「上地图 / 分隔条 / 下详情列表」，它的矩形恰好就是
 *   地图上沿 → 列表下沿；锚表格只能盖住下半区，上半截地图旁边仍是空的。
 *
 * WHY 从表格往上 closest、而不是全局按类名直接取整列：
 *   同一时刻 DOM 里可能不止一个布局实例（KeepAlive 缓存、弹层里的对照页），
 *   全局选 `.pane-right` 可能抓到别人的那一列，抽屉就会贴到看不见的区域上。
 *   由「自己这张表」往上找，拿到的必然是自己所在的列。
 *
 * WHY 传函数而不是缓存元素：布局里的 h-split / v-split 会实时改高度，
 * 元素不换、尺寸会变；createDrawer 每次重新对齐都会重新调用取锚点的函数。
 */

/** 布局右列的选择器：上半地图、下半详情列表，纵向覆盖整块内容区 */
const PANE_RIGHT = '.pane-right';

/** 属性表根节点的选择器（地图点击通道没有组件实例引用，只能按类名反查） */
const ATTR_TABLE = '.attr-table';

/** 由某个后代元素反查它所在的布局右列；不在布局里时退回该元素自身 */
export function paneRightAnchor(el: Element | null | undefined): HTMLElement | null {
  const node = (el as HTMLElement | null) ?? null;
  return (node?.closest?.(PANE_RIGHT) as HTMLElement | null) ?? node;
}

/**
 * 地图点击通道的锚点：按 `.attr-table` 反查当前这列。
 *
 * 多个候选取「有高度」的那一个：缓存页 / 收起态的表格 rect.height 为 0，
 * 选错会让抽屉对齐到一块不可见区域；一张表都没有时返回 null，
 * createDrawer 会自动退回视口全高（入库等无表格页面的既有行为）。
 */
export function findPaneRightAnchor(): HTMLElement | null {
  const tables = Array.from(document.querySelectorAll<HTMLElement>(ATTR_TABLE));
  const visible = tables.find((t) => (paneRightAnchor(t)?.getBoundingClientRect().height ?? 0) > 0);
  return paneRightAnchor(visible ?? tables[0]);
}
