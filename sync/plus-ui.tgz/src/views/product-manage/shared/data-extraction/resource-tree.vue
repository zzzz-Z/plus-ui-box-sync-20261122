<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
/**
 * 数据提取左侧资源树 —— 与「数据浏览」页（data-browse/index.vue）同款。
 *
 * 数据源：GET /platform/metadata/tree（getMetadataBrowseTree），后端直接返回
 *   「产品类别 → 任务（资源）」两级递归树，前端只按产品线根收窄 + 剪掉空类别，
 *   不再像旧 import-tree.vue 那样按 category→task→folder→file 四层懒加载拼装。
 *
 * 为什么用这棵树：数据提取的 preview 接受「资源 uid」（实测 resourceUid 可直接换
 *   previewToken + fileCount），而旧 import-tree 收的 importUid（任务 uid）多数已失效、
 *   folder uid 是相对路径根本不是 UUID，导致预览/创建 404。本树勾选的资源叶子即提取对象。
 *
 * 勾选语义照数据浏览：check-strictly=false（父子联动），勾父类别 = 该类别下全部资源；
 *   getCheckedKeys 里躺着的是 key（cat:xxx / res:xxx），须展开成资源 uid 才能交给 preview。
 */
import { FolderOpened, Document, Search, Location, Picture, Grid, Memo } from '@element-plus/icons-vue';
import { getMetadataBrowseTree, type MetadataTreeNode } from '@/api/product-manage/platform/metadata-browse';
import { scopeTreeByRoot } from '../category-root';

defineOptions({ name: 'ExtractionResourceTree' });

const props = withDefaults(defineProps<{ categoryRoot?: string }>(), { categoryRoot: '' });
const emit = defineEmits<{ change: [uids: string[], picked: { name: string; layer: string }[]] }>();

type NodeKind = 'cat' | 'res';
interface TreeNodeVM {
  key: string;
  label: string;
  kind: NodeKind;
  resourceUid?: string;
  dataType?: string;
  count?: number;
  children?: TreeNodeVM[];
}

const loading = ref(false);
const browseTree = ref<MetadataTreeNode[]>([]);
const treeRef = ref();
const keyword = ref('');

/** 后端节点 → 展示节点；返回 null 表示整枝无资源，剪掉（与数据浏览同口径） */
function toTreeNode(n: MetadataTreeNode): TreeNodeVM | null {
  if (n.nodeType === 'resource') {
    return { key: `res:${n.uid}`, label: n.displayName || n.uid, kind: 'res', resourceUid: n.uid, dataType: n.dataType };
  }
  const children = (n.children ?? []).map(toTreeNode).filter((c): c is TreeNodeVM => !!c);
  if (!children.length) return null;
  return { key: `cat:${n.uid}`, label: n.displayName || n.categoryName || n.uid, kind: 'cat', count: countResources(children), children };
}

function countResources(nodes: TreeNodeVM[]): number {
  let total = 0;
  for (const node of nodes) {
    if (node.kind === 'res') total += 1;
    else total += countResources(node.children ?? []);
  }
  return total;
}

/**
 * 按节点类型 / 资源数据类型选图标与颜色 —— 与数据浏览页（data-browse/index.vue）同款。
 * 配色沿用语义色：矢量青 / 栅格蓝 / 表格绿 / 文本灰，类别为文件夹、主题色。
 */
function nodeIconMeta(data: TreeNodeVM): { icon: any; color: string } {
  if (data.kind === 'cat') return { icon: FolderOpened, color: 'var(--el-color-primary)' };
  switch (String(data.dataType ?? '').toLowerCase()) {
    case 'vector':
      return { icon: Location, color: '#13a8a8' };
    case 'raster':
      return { icon: Picture, color: '#3f8cff' };
    case 'table':
      return { icon: Grid, color: '#2ba471' };
    case 'text':
      return { icon: Memo, color: '#909399' };
    default:
      return { icon: Document, color: 'var(--el-text-color-secondary)' };
  }
}

/** 展示树：按产品线根收窄 → 剪空类别 */
const treeData = computed<TreeNodeVM[]>(() => {
  const scoped = scopeTreeByRoot(browseTree.value, props.categoryRoot);
  return scoped.map(toTreeNode).filter((n): n is TreeNodeVM => !!n);
});

function findByKey(nodes: TreeNodeVM[], key: string): TreeNodeVM | null {
  for (const n of nodes) {
    if (n.key === key) return n;
    const hit = n.children ? findByKey(n.children, key) : null;
    if (hit) return hit;
  }
  return null;
}

/** 把一个（类别/资源）节点子树里的资源 uid 展开出来 */
function collectResourceUids(node: TreeNodeVM): string[] {
  const out: string[] = [];
  const walk = (n: TreeNodeVM) => {
    if (n.kind === 'res' && n.resourceUid) out.push(n.resourceUid);
    n.children?.forEach(walk);
  };
  walk(node);
  return out;
}

/** 勾选变化 → 展开成资源 uid（按树序稳定输出）→ 通知父组件 */
function onCheck() {
  const keys = (treeRef.value?.getCheckedKeys?.() ?? []) as string[];
  const uidSet = new Set<string>();
  for (const key of keys) {
    const node = findByKey(treeData.value, key);
    if (node) collectResourceUids(node).forEach((uid) => uidSet.add(uid));
  }
  const ordered: { uid: string; name: string }[] = [];
  const walk = (nodes: TreeNodeVM[]) => {
    for (const n of nodes) {
      if (n.kind === 'res') {
        if (n.resourceUid && uidSet.has(n.resourceUid)) ordered.push({ uid: n.resourceUid, name: n.label });
      } else walk(n.children ?? []);
    }
  };
  walk(treeData.value);
  emit(
    'change',
    ordered.map((x) => x.uid),
    // layer 统一按 'task'（资源叶子）：sanitizeBase 不必去扩展名
    ordered.map((x) => ({ name: x.name, layer: 'task' }))
  );
}

function filterNode(value: string, data: TreeNodeVM) {
  if (!value) return true;
  return data.label.toLowerCase().includes(value.toLowerCase());
}
watch(keyword, (val) => treeRef.value?.filter(val));

async function loadData() {
  loading.value = true;
  try {
    const res: any = await getMetadataBrowseTree();
    browseTree.value = res?.data?.items ?? [];
    await nextTick();
    treeRef.value?.filter?.(keyword.value);
  } finally {
    loading.value = false;
  }
}

/** 清空勾选（供父组件重置新建表单调用） */
function clear() {
  treeRef.value?.setCheckedKeys?.([]);
  onCheck();
}

onMounted(loadData);

defineExpose({ clear });
</script>

<template>
  <div v-loading="loading" class="resource-tree">
    <div class="rt-head">
      <el-input v-model="keyword" :placeholder="pt('搜索资源 / 类别')" clearable :prefix-icon="Search" />
    </div>
    <div class="rt-body">
      <el-tree
        ref="treeRef"
        :data="treeData"
        node-key="key"
        :props="{ label: 'label', children: 'children' }"
        :indent="14"
        :default-expand-all="true"
        :expand-on-click-node="false"
        :check-on-click-node="false"
        :check-on-click-leaf="false"
        highlight-current
        show-checkbox
        :check-strictly="false"
        :filter-node-method="filterNode"
        @check="onCheck"
      >
        <template #default="{ data }">
          <span class="rt-node" :class="`is-${data.kind}`">
            <el-icon class="rt-node__ic" :style="{ color: nodeIconMeta(data).color }"><component :is="nodeIconMeta(data).icon" /></el-icon>
            <span class="rt-node__label" :title="data.label">{{ data.label }}</span>
            <span v-if="data.count" class="rt-node__count">{{ data.count }}</span>
          </span>
        </template>
      </el-tree>
      <el-empty v-if="!loading && !treeData.length" description="暂无资源" :image-size="50" />
    </div>
  </div>
</template>

<style scoped lang="scss">
.resource-tree {
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100%;
  min-height: 0;
  padding: 0;
  overflow: hidden;
  background: var(--el-bg-color);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 6px;
}
.rt-head {
  flex: 0 0 auto;
  padding: 10px 10px 8px;
  border-bottom: 1px solid var(--el-border-color-lighter);
}
.rt-body {
  flex: 1;
  min-height: 0;
  padding: 6px 6px 10px;
  overflow: auto;
}
.rt-node {
  display: flex;
  align-items: center;
  gap: 6px;
  width: 100%;
  padding-right: 4px;
  font-size: 13px;
}
.rt-node__ic {
  display: inline-flex;
  flex: none;
  align-items: center;
  width: 15px;
  font-size: 13px;
  color: var(--el-text-color-placeholder);
}
/* 节点图标颜色由 nodeIconMeta 按数据类型内联给出（矢量青/栅格蓝/表格绿/文本灰），此处不再统一上色 */
.rt-node__label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.rt-node__count {
  flex: none;
  min-width: 20px;
  padding: 0 5px;
  color: var(--el-text-color-secondary);
  font-size: 11px;
  line-height: 16px;
  text-align: center;
  background: var(--el-fill-color-light);
  border-radius: 8px;
}
:deep(.el-tree-node__content) {
  height: 30px;
  border-radius: 4px;
}
:deep(.el-tree-node.is-current > .el-tree-node__content) {
  background: var(--el-color-primary-light-9);
  .rt-node__count {
    color: var(--el-color-primary);
    background: var(--el-color-primary-light-8);
  }
}
</style>
