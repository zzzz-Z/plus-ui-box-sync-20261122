<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
/**
 * 数据提取任务页（左资源树 + 右侧「新建提取 / 提取列表」Tab）
 *
 * 布局范式照数据入库页 data-into-store/index.vue：
 * - 左侧资源树通过 useTreeHost + Teleport 挂到布局左列；独立挂载时退化为内联左树右表。
 * - 右侧 el-tabs：new 内嵌新建提取表单，list 内嵌任务列表 Table。
 * - 必须在 onMounted 里设 treeHost.hasContent=true（useTreeHost 自己的 onMounted 会重置为 false）。
 *
 * 列表 Table 使用 render 函数渲染列（Table 组件只认 action/search/append/default/header 五个顶层 slot）。
 * 后端 operationStatus 全中文，前端不映射英文枚举。
 */
import {
  UploadFilled,
  VideoPlay,
  VideoPause,
  Refresh,
  RefreshRight,
  Download,
  CircleClose,
  Delete,
  Setting,
  Tickets,
  FolderOpened
} from '@element-plus/icons-vue';
import Table from '@/components/product-manage/table/index.vue';
import {
  listExtractions,
  startExtraction,
  pauseExtraction,
  resumeExtraction,
  cancelExtraction,
  retryExtraction,
  deleteExtraction,
  getExtraction,
  getImportTree,
  previewExtraction,
  createExtraction,
  buildCreateExtractionPayload,
  updateExtractionPriority,
  getExtractionErrors,
  subscribeExtractionEvents,
  parseExtractionArchiveUrl,
  downloadExtractionArchive,
  type ExtractionListItem,
  type ExtractionProgress,
  type ExtractionListParams,
  type ExtractionPreviewResult,
  type ExtractionPreviewItem,
  type ExtractionPreviewFile,
  type ExtractionError,
  type ExtractionPriority,
  type ExtractionEventPayload
} from '@/api/product-manage/platform/file-extraction';
import { ElMessage, ElMessageBox, ElTag } from 'element-plus';
import { ref, reactive, computed, onUnmounted, onMounted, inject, nextTick, watch } from 'vue';
import ResourceTree from './resource-tree.vue';
import { PRODUCT_BASE_URL } from '@/api/product-manage/http';
import { BEST_EFFORT_HEADER } from '@/utils/request';
import { useTreeHost } from '../tree-host';

const tableRef = ref<InstanceType<typeof Table>>();

/* ---------------- 布局：左侧资源树 + 右侧 Tab ---------------- */

/** 布局注入了树挂载位时非 null；null 表示独立挂载 */
const treeHost = useTreeHost();
const hosted = computed(() => !!treeHost?.el.value);
const treeTarget = computed(() => treeHost?.el.value ?? 'body');

const activeTab = ref<'new' | 'list'>('new');
/** 当前页面的产品类别编码；树按此收窄 */
const categoryRoot = inject<string>('product-category-root', '');

onMounted(() => {
  // useTreeHost 自己的 onMounted 会把 hasContent 重置为 false，必须在这里覆盖：
  // 本页左侧有常驻资源树，不能因「未勾选」被布局收起详情区。
  if (!treeHost) return;
  treeHost.checkedCount.value = 0;
  treeHost.hasContent.value = true;
});

/* ---------------- 状态 / 类别（列表查询条件） ---------------- */

/** 状态下拉：值必须是后端合法英文枚举（实测中文与 SUCCESS 均 400） */
const STATE_OPTIONS = [
  { label: pt('排队中'), value: 'QUEUED' },
  { label: pt('正在提取'), value: 'RUNNING' },
  { label: pt('已暂停'), value: 'PAUSED' },
  { label: pt('成功'), value: 'SUCCEEDED' },
  { label: pt('失败'), value: 'FAILED' },
  { label: pt('已取消'), value: 'CANCELLED' }
];

/** 产品类别下拉：取树接口根层类别 */
const categoryOptions = ref<{ label: string; value: string }[]>([]);
async function loadCategoryOptions() {
  try {
    const res: any = await getImportTree({});
    const list = res?.data?.nodes ?? res?.data?.items ?? [];
    categoryOptions.value = list.filter((n: any) => n.nodeType === 'category' && n.uid).map((n: any) => ({ label: n.name, value: n.uid }));
  } catch (e) {
    categoryOptions.value = [];
  }
}
onMounted(loadCategoryOptions);
const queryParams = reactive<ExtractionListParams>({ categoryUid: '', state: '', page: 1, pageSize: 20 });

/* ---------------- 新建提取（内联表单：勾选 → 预览 → 创建 → 启动） ---------------- */

const treeRef = ref<InstanceType<typeof ResourceTree>>();
const createFormRef = ref<InstanceType<typeof import('element-plus').ElForm>>();
/** 勾选的资源 uid 列表（来自左树） */
const items = ref<string[]>([]);
/** 勾选节点的名称/层级：仅用于自动生成任务名 */
const picked = ref<{ name: string; layer: string }[]>([]);
/** 上一次自动生成的任务名：用于判断用户是否手改过 */
const autoTaskName = ref('');
/** 勾选资源后自动加载的文件分组（每个资源一组，含该资源的全部文件） */
const fileGroups = ref<ExtractionPreviewItem[]>([]);
/** 当前勾选用于提取的文件 fileUid（默认全选） */
const selectedFileUids = ref<string[]>([]);
/** 文件列表加载中 */
const loadingFiles = ref(false);
const creating = ref(false);
/** 提取数据树引用（el-tree 复选） */
const fileTreeRef = ref<any>();

/**
 * 提取数据树数据：一级=资源组，二级=文件。
 * node-key 用带前缀的 key，避免资源 uid 与文件 uid 恰好相同导致 el-tree key 冲突；
 * 叶子 key=`f:${fileUid}`，其集合即 selectedFileUids 的树形态。
 */
interface FileTreeNode {
  key: string;
  label: string;
  kind: 'resource' | 'file';
  sizeBytes?: number;
  children?: FileTreeNode[];
}
const fileTreeData = computed<FileTreeNode[]>(() =>
  fileGroups.value.map((g) => ({
    key: `r:${g.resourceUid}`,
    label: g.resourceName || g.resourceDir || g.resourceUid,
    kind: 'resource',
    children: (g.files ?? []).map((f) => ({
      key: `f:${f.fileUid}`,
      label: f.relativePath || f.displayPath || f.fileUid,
      kind: 'file',
      sizeBytes: f.sizeBytes
    }))
  }))
);
/** el-tree 默认展开全部资源组 */
const fileTreeExpandedKeys = computed(() => fileGroups.value.map((g) => `r:${g.resourceUid}`));

/** 全部文件（按资源分组顺序铺平） */
const allFiles = computed<ExtractionPreviewFile[]>(() => fileGroups.value.flatMap((g) => g.files ?? []));
/** 已选文件数 / 总文件数 */
const selectedCount = computed(() => selectedFileUids.value.length);
const totalCount = computed(() => allFiles.value.length);
/** 当前是否全选 */
const allSelected = computed(() => totalCount.value > 0 && selectedFileUids.value.length === totalCount.value);
/** 是否已选部分（用于分组头半选状态） */
const summaryBytes = computed(() =>
  allFiles.value.filter((f) => selectedFileUids.value.includes(f.fileUid)).reduce((n, f) => n + (f.sizeBytes ?? 0), 0)
);
const summaryCategories = computed(() => {
  const map = new Map<string, string>();
  for (const g of fileGroups.value) if (g.categoryUid) map.set(g.categoryUid, g.categoryName ?? '');
  return [...map.values()];
});

const createForm = reactive({
  taskName: '',
  targetPath: '',
  priority: 'medium' as 'high' | 'medium' | 'low'
});

// taskName 后端可选（缺省「数据提取」），无需必填规则
const createRules = {};

/** 文件名/路径非法字符（任务名同时是 ZIP 顶层目录名） */
const ILLEGAL_CHARS = /[\\/:*?"<>|\s]+/g;
/** 任务名主体长度上限：给时间戳留余量，远低于后端 200 限制 */
const BASE_MAX = 60;

function pad2(n: number) {
  return String(n).padStart(2, '0');
}

/** 14 位时间戳 YYYYMMDDHHmmss，可排序、无分隔符（做目录名安全） */
function stamp() {
  const d = new Date();
  return `${d.getFullYear()}${pad2(d.getMonth() + 1)}${pad2(d.getDate())}${pad2(d.getHours())}${pad2(d.getMinutes())}${pad2(d.getSeconds())}`;
}

/** 去掉非法字符与首尾连字符；文件节点顺带去扩展名 */
function sanitizeBase(raw: string, layer: string) {
  let s = String(raw ?? '');
  if (layer === 'file') s = s.replace(/\.[^.]+$/, '');
  s = s.replace(ILLEGAL_CHARS, '-').replace(/^-+|-+$/g, '');
  return s.slice(0, BASE_MAX).replace(/-+$/, '') || '数据提取';
}

/** 依据「首个勾选节点的名称 + 当前时间戳」生成任务名 */
function buildAutoTaskName(): string {
  if (!picked.value.length) return '';
  const first = picked.value[0];
  return `${sanitizeBase(first.name, first.layer)}_${stamp()}`;
}

/** 只在「用户还没填」或「当前值仍是上一次自动生成的值」时覆盖，避免冲掉手改 */
function syncTaskName() {
  const auto = buildAutoTaskName();
  if (!auto) return;
  if (!createForm.taskName || createForm.taskName === autoTaskName.value) {
    createForm.taskName = auto;
    autoTaskName.value = auto;
  }
}

function onTreeChange(next: string[], nextPicked: { name: string; layer: string }[]) {
  items.value = next;
  picked.value = nextPicked ?? [];
  syncTaskName();
  // 勾选即加载文件列表（无需点预览）
  void loadFiles();
}

/**
 * 勾选资源后自动加载文件列表：每个资源各自 selectAll:true 预览，响应 items[].files[]
 * 即是该资源下的全部文件。并行请求，逐组组装。
 *
 * CONSTRAINT 这是「探测」请求而非用户主动操作：资源没有可用文件是常见业务状态（422），
 * 不应弹红色错误打断用户。故带 x-best-effort 头让全局拦截器静默，失败的资源直接跳过，
 * 也不再弹「N 个资源无可用文件，已跳过」的黄色提示——无数据就是空态，不报错。
 */
async function loadFiles() {
  fileGroups.value = [];
  selectedFileUids.value = [];
  if (!items.value.length) return;
  loadingFiles.value = true;
  try {
    const results = await Promise.all(
      items.value.map((uid) =>
        previewExtraction({ resources: [{ resourceUid: uid, selectAll: true }] }, { headers: { [BEST_EFFORT_HEADER]: '1' } }).catch(() => null)
      )
    );
    const groups: ExtractionPreviewItem[] = [];
    results.forEach((res: any) => {
      const it = res?.data?.items?.[0];
      // 无可用文件 / 探测失败的资源直接跳过，静默处理
      if (it?.files?.length) groups.push(it);
    });
    fileGroups.value = groups;
    // 默认全选所有文件
    selectedFileUids.value = groups.flatMap((g) => (g.files ?? []).map((f) => f.fileUid));
  } catch (e: any) {
    // 探测类请求整体失败也不打扰用户，保留空态
    fileGroups.value = [];
    selectedFileUids.value = [];
  } finally {
    loadingFiles.value = false;
  }
}

/** 文件树勾选回调：只取叶子（文件）key 回写 selectedFileUids；组节点由父子联动派生，不单独计入 */
function onFileTreeCheck() {
  const checked = (fileTreeRef.value?.getCheckedKeys?.() ?? []) as string[];
  selectedFileUids.value = checked.filter((k) => k.startsWith('f:')).map((k) => k.slice(2));
}

/** 全选 / 全不选：直接驱动 el-tree 勾选态，联动由树负责，回调统一回写 selectedFileUids */
function toggleSelectAll(val: boolean) {
  const fileKeys = fileTreeData.value.flatMap((n) => n.children?.map((c) => c.key) ?? []);
  fileTreeRef.value?.setCheckedKeys?.(val ? fileKeys : []);
  selectedFileUids.value = val ? allFiles.value.map((f) => f.fileUid) : [];
}

/**
 * 文件分组变化时把 el-tree 的勾选态重建为「全选」。
 * WHY：el-tree 内部勾选态是自身维护的，data 换掉后不会自动跟随外部 selectedFileUids；
 * 这里显式 setCheckedKeys 同步，保证「勾选资源→加载文件→默认全选」的视觉与提交口径一致。
 */
watch(
  fileTreeData,
  async (nodes) => {
    await nextTick();
    fileTreeRef.value?.setCheckedKeys?.(nodes.flatMap((n) => n.children?.map((c) => c.key) ?? []));
  },
  { flush: 'post' }
);

function resetCreateForm() {
  (treeRef.value as any)?.clear?.();
  items.value = [];
  picked.value = [];
  autoTaskName.value = '';
  fileGroups.value = [];
  selectedFileUids.value = [];
  createForm.taskName = '';
  createForm.targetPath = '';
  createForm.priority = 'medium';
}

/** 提交创建：按勾选文件组装 resources[] → preview 换 token → create(previewToken) → start，一个任务 */
async function submitCreate() {
  if (!fileGroups.value.length) {
    ElMessage.warning(pt('请先在左侧勾选资源'));
    return;
  }
  if (!selectedFileUids.value.length) {
    ElMessage.warning(pt('请至少勾选一个文件'));
    return;
  }
  if (creating.value) return;
  creating.value = true;
  try {
    // 每个资源只带本组内被勾选的文件；整组全选时传 selectAll:true，否则传 fileUids
    const resources = fileGroups.value
      .map((g) => {
        const files = g.files ?? [];
        const pickedUids = files.filter((f) => selectedFileUids.value.includes(f.fileUid)).map((f) => f.fileUid);
        if (!pickedUids.length) return null;
        if (pickedUids.length === files.length) return { resourceUid: g.resourceUid, selectAll: true };
        return { resourceUid: g.resourceUid, fileUids: pickedUids };
      })
      .filter(Boolean) as { resourceUid: string; selectAll?: boolean; fileUids?: string[] }[];
    if (!resources.length) {
      ElMessage.warning(pt('请至少勾选一个文件'));
      return;
    }

    // 契约：create 没有 uid，必须用选中范围换 previewToken
    const pv: any = await previewExtraction({ resources });
    const previewToken = pv?.data?.previewToken;
    if (!previewToken) {
      ElMessage.error(pt('预览失败，无法创建'));
      return;
    }
    const built = buildCreateExtractionPayload({
      taskName: createForm.taskName,
      previewToken,
      targetPath: createForm.targetPath || null,
      priority: createForm.priority,
      requestId: (crypto as any).randomUUID?.() || String(Date.now())
    });
    if (!built.ok || !built.payload) {
      ElMessage.warning(built.message || '参数非法');
      return;
    }
    const createdRes: any = await createExtraction(built.payload);
    const taskUid = createdRes?.data?.taskUid;
    if (!taskUid) {
      ElMessage.error(pt('创建失败'));
      return;
    }
    await startExtraction(taskUid);
    ElMessage.success(`已创建并启动，共提取 ${selectedFileUids.value.length} 个文件`);
    resetCreateForm();
    activeTab.value = 'list';
    await tableRef.value?.getData();
  } catch {
    // axios 响应拦截器已对 4xx 弹过后端 message，这里不重复弹
  } finally {
    creating.value = false;
  }
}

/* ---------------- 列表 ---------------- */

async function loadList(params: any) {
  const req: ExtractionListParams = {
    page: params.page || 1,
    pageSize: params.pageSize || 20,
    categoryUid: queryParams.categoryUid || undefined,
    state: queryParams.state || undefined
  };
  const res: any = await listExtractions(req);
  const rows: ExtractionListItem[] = res?.data?.items ?? [];
  listCache.value = rows;
  rows.forEach((row) => {
    // 「等待提取」（排队/已暂停）也要订阅：启动后到真正开始提取之间仍有状态与队列位置变化
    if (row.operationStatus === '正在提取' || row.operationStatus === '等待提取') ensureStream(row);
  });
  return { code: 0, data: { items: rows, total: res?.data?.total ?? 0 } };
}

/** 每个任务一条 SSE 订阅；key=taskUid，value=AbortController */
const streams = new Map<string, AbortController>();
/** 断线重连次数（防止网络故障时无限重连） */
const streamRetries = new Map<string, number>();
const MAX_STREAM_RETRIES = 10;

/** 列表本地镜像：供 SSE 事件按 taskUid 定位行 */
const listCache = ref<ExtractionListItem[]>([]);

/** 把 SSE 快照同步到列表镜像，保证进度/状态实时刷新 */
function applyExtractionSnapshot(uid: string, snap: any) {
  if (!snap) return;
  const target: any = listCache.value.find((x) => x.taskUid === uid);
  if (target) {
    if (snap.progress) target.progress = snap.progress;
    if (typeof snap.state === 'string' && snap.state !== target.state) {
      target.state = snap.state;
      if (snap.operationStatus) target.operationStatus = snap.operationStatus;
    }
  }
}

/**
 * 确保「正在提取 / 等待提取」任务有 SSE 订阅。
 * 用提取专用端点（/data-extractions/{uid}/events，事件 ready/selection/progress/done）。
 * done 是唯一终止事件；网络故障（onError）退订后延迟重连，故障解除即自动恢复进度同步。
 */
function ensureStream(row: ExtractionListItem) {
  const uid = row.taskUid;
  if (!uid || streams.has(uid)) return;
  const ctrl = new AbortController();
  streams.set(uid, ctrl);
  subscribeExtractionEvents(
    uid,
    {
      onEvent: (payload: ExtractionEventPayload) => {
        // ready/selection/progress 都带 state 快照；selection 不是结束事件
        if (payload.event === 'ready' || payload.event === 'selection' || payload.event === 'progress') {
          applyExtractionSnapshot(uid, payload.data);
        }
      },
      onDone: (payload: ExtractionEventPayload) => {
        applyExtractionSnapshot(uid, payload.data ?? { state: 'SUCCEEDED' });
        dropStream(uid);
        streamRetries.delete(uid);
        void tableRef.value?.getData();
      },
      onError: () => {
        dropStream(uid);
        const retries = streamRetries.get(uid) ?? 0;
        if (retries >= MAX_STREAM_RETRIES) return;
        streamRetries.set(uid, retries + 1);
        // 故障解除后自动恢复：3s 后若任务仍活跃且组件未卸载则重连
        setTimeout(() => {
          if (ctrl.signal.aborted) return;
          const live = listCache.value.find((x) => x.taskUid === uid);
          if (live && (live.operationStatus === '正在提取' || live.operationStatus === '等待提取')) ensureStream(live);
        }, 3000);
      }
    },
    ctrl.signal
  );
}

const STATUS_META: Record<string, { type: 'info' | 'warning' | 'primary' | 'success' | 'danger'; text: string }> = {
  等待提取: { type: 'warning', text: pt('等待中') },
  正在提取: { type: 'primary', text: pt('正在提取') },
  完成提取: { type: 'success', text: pt('完成') },
  提取错误: { type: 'danger', text: pt('失败') },
  // state 语义兜底：operationStatus 为空/英文时改用 state，避免状态列出现原始字符串或「未知」
  已创建: { type: 'info', text: pt('已创建') },
  排队中: { type: 'warning', text: pt('排队中') },
  进行中: { type: 'primary', text: pt('进行中') },
  已暂停: { type: 'warning', text: pt('已暂停') },
  已取消: { type: 'info', text: pt('已取消') },
  成功: { type: 'success', text: pt('完成') },
  失败: { type: 'danger', text: pt('失败') },
  CREATED: { type: 'info', text: pt('已创建') },
  QUEUED: { type: 'warning', text: pt('排队中') },
  RUNNING: { type: 'primary', text: pt('进行中') },
  PAUSED: { type: 'warning', text: pt('已暂停') },
  SUCCEEDED: { type: 'success', text: pt('完成') },
  FAILED: { type: 'danger', text: pt('失败') },
  CANCELLED: { type: 'info', text: pt('已取消') }
};

function statusOf(row: ExtractionListItem) {
  return STATUS_META[row.operationStatus] ?? STATUS_META[row.state] ?? { type: 'info' as const, text: row.operationStatus || row.state || '未知' };
}
function fmtSize(bytes?: number) {
  if (!bytes || bytes <= 0) return '-';
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / 1024 / 1024).toFixed(1) + ' MB';
}

/* ---------------- 进度列语义化 ---------------- */

type ProgressTone = 'primary' | 'success' | 'exception' | 'warning' | 'info';

interface ProgressView {
  percent: number;
  stageText: string;
  tone: ProgressTone;
  color: string;
  /** 失败/取消等异常状态不展示误导性的百分比数字，只保留状态文案 */
  showPercent: boolean;
}

type ExtractionRow = ExtractionListItem & { progress?: ExtractionProgress };

/** 后端 stage / stageText 原始串可能是英文枚举，统一映射为中文，避免列表出现 FAILED/cancelled 等裸串 */
const STAGE_TEXT: Record<string, string> = {
  FAILED: pt('失败'),
  FAILURE: pt('失败'),
  ERROR: pt('失败'),
  failed: pt('失败'),
  CANCELLED: pt('已取消'),
  CANCELED: pt('已取消'),
  cancelled: pt('已取消'),
  canceled: pt('已取消'),
  SUCCEEDED: pt('完成'),
  SUCCESS: pt('完成'),
  COMPLETED: pt('完成'),
  DONE: pt('完成'),
  success: pt('完成'),
  RUNNING: pt('进行中'),
  running: pt('进行中'),
  QUEUED: pt('排队中'),
  PENDING: pt('等待中'),
  WAITING: pt('等待中'),
  PAUSED: pt('已暂停'),
  SELECTION: pt('选取中'),
  READY: pt('就绪'),
  等待提取: pt('等待中'),
  正在提取: pt('进行中'),
  完成提取: pt('完成'),
  提取错误: pt('失败'),
  已创建: pt('已创建'),
  排队中: pt('排队中'),
  进行中: pt('进行中'),
  已暂停: pt('已暂停'),
  已取消: pt('已取消'),
  成功: pt('完成'),
  失败: pt('失败')
};

const TONE_COLOR: Record<ProgressTone, string> = {
  primary: '#409eff',
  success: '#67c23a',
  exception: '#f56c6c',
  warning: '#e6a23c',
  info: '#909399'
};

function stageTextOf(raw?: string): string {
  if (!raw) return '';
  const key = String(raw).trim();
  return STAGE_TEXT[key] ?? key;
}

/**
 * 以任务状态为准派生进度显示：后端 progress 在失败/取消/排队时仍可能返回 100% 快照，
 * 直接渲染会出现「失败 100% 绿条」「等待中 100%」等矛盾。这里按状态改色、钳制百分比并统一文案。
 */
function progressView(row: ExtractionRow): ProgressView | null {
  const p = row.progress;
  if (!p || typeof p.percent !== 'number') return null;
  const pct = Math.max(0, Math.min(100, Math.round(p.percent)));
  const op = String(row.operationStatus || '');
  const state = String(row.state || '');
  const stageRaw = String(p.stageText || p.stage || '');
  const stage = stageTextOf(stageRaw);

  let tone: ProgressTone = 'primary';
  let percent = pct;
  let stageText = stage;

  let showPercent = true;

  if (op === '提取错误' || state === 'FAILED' || state === '失败' || /FAILED|FAILURE|ERROR/i.test(stageRaw)) {
    tone = 'exception';
    stageText = '失败';
    showPercent = false;
  } else if (op === '已取消' || state === 'CANCELLED' || /CANCELLED|CANCELED/i.test(stageRaw)) {
    tone = 'info';
    percent = 0;
    stageText = '已取消';
    showPercent = false;
  } else if (op === '等待提取' || state === 'QUEUED' || state === 'CREATED' || /QUEUED|WAITING|PENDING/i.test(stageRaw)) {
    tone = 'warning';
    percent = Math.min(pct, 5);
    stageText = stageText || '排队中';
  } else if (op === '完成提取' || state === 'SUCCEEDED' || state === '成功' || /SUCCEEDED|SUCCESS|COMPLETED|DONE/i.test(stageRaw)) {
    tone = 'success';
    percent = 100;
    stageText = '完成';
  } else if (op === '已暂停' || state === 'PAUSED' || /PAUSED/i.test(stageRaw)) {
    tone = 'warning';
    stageText = stageText || '已暂停';
  }

  return { percent, stageText, tone, color: TONE_COLOR[tone], showPercent };
}

const columns = [
  { prop: 'taskName', label: pt('任务名'), minWidth: 180 },
  {
    label: pt('状态'),
    width: 110,
    render: ({ row }: any) => (
      <ElTag type={statusOf(row).type} size="small">
        {statusOf(row).text}
      </ElTag>
    )
  },
  {
    label: pt('产品类别'),
    minWidth: 160,
    render: ({ row }: any) => (row.categories || []).map((c: any) => c.categoryName).join('、') || '-'
  },
  { prop: 'fileCount', label: pt('文件数'), width: 90 },
  {
    label: pt('进度'),
    minWidth: 180,
    render: ({ row }: any) => {
      const view = progressView(row as ExtractionRow);
      // 后端任何状态都可能带 progress 快照（暂停/取消/失败/完成），只要有就展示；
      // 仅按 operationStatus==='正在提取' 过滤会把绝大多数行挡成 '-'。
      if (!view) return <span class="is-placeholder">-</span>;
      return (
        <div class="progress-cell">
          <el-progress
            percentage={view.percent}
            stroke-width={6}
            color={view.color}
            format={view.showPercent ? () => `${view.percent}%` : () => ''}
          />
          {view.stageText && <span class={`progress-stage progress-stage--${view.tone}`}>{view.stageText}</span>}
        </div>
      );
    }
  },
  {
    label: pt('总大小'),
    width: 110,
    render: ({ row }: any) => fmtSize(row.sourceBytes)
  },
  { prop: 'errorCount', label: pt('错误'), width: 80 },
  { prop: 'createdAt', label: pt('创建时间'), minWidth: 160 },
  { prop: 'finishedAt', label: pt('完成时间'), minWidth: 160 },
  {
    action: true,
    label: pt('操作'),
    fixed: 'right',
    render: ({ row }: any) => {
      const st = row.operationStatus;
      return (
        <div class="row-actions">
          {st === '等待提取' && <el-button v-tooltip={'启动'} link type="primary" icon={VideoPlay} onClick={() => onStart(row)} />}
          {st === '等待提取' && <el-button v-tooltip={'恢复'} link type="primary" icon={RefreshRight} onClick={() => onResume(row)} />}
          {st === '正在提取' && <el-button v-tooltip={'暂停'} link type="warning" icon={VideoPause} onClick={() => onPause(row)} />}
          {st === '提取错误' && <el-button v-tooltip={'重试'} link type="primary" icon={Refresh} onClick={() => onRetry(row)} />}
          {st === '完成提取' && <el-button v-tooltip={'下载结果'} link type="success" icon={Download} onClick={() => onDownloadOrReceipt(row)} />}
          <el-button
            v-tooltip={'下载ZIP包'}
            link
            type="primary"
            icon={FolderOpened}
            disabled={downloadingZip.value.includes(row.taskUid)}
            onClick={() => onDownloadZip(row)}
          />
          {(st === '等待提取' || st === '正在提取' || st === '提取错误') && (
            <el-button v-tooltip={'取消'} link type="danger" icon={CircleClose} onClick={() => onCancel(row)} />
          )}
          {(st === '完成提取' || st === '提取错误') && (
            <el-button v-tooltip={'删除'} link type="danger" icon={Delete} onClick={() => onDelete(row)} />
          )}
          {st === '等待提取' && <el-button v-tooltip={'调整优先级'} link icon={Setting} onClick={() => openPriority(row)} />}
          {row.errorCount > 0 && <el-button v-tooltip={'错误明细'} link type="danger" icon={Tickets} onClick={() => openErrors(row)} />}
        </div>
      );
    }
  }
];

/* ---------------- 调整优先级（契约 538395398，PATCH + expectedVersion CAS） ---------------- */
const priorityVisible = ref(false);
const prioritySaving = ref(false);
const priorityRow = ref<ExtractionListItem | null>(null);
const priorityForm = reactive<{ priority: ExtractionPriority }>({ priority: 'medium' });

function openPriority(row: ExtractionListItem) {
  priorityRow.value = row;
  priorityForm.priority = 'medium';
  priorityVisible.value = true;
}
async function savePriority() {
  if (!priorityRow.value) return;
  prioritySaving.value = true;
  try {
    // 列表行无 version 字段时不传 expectedVersion，让后端按当前版本处理
    await updateExtractionPriority(priorityRow.value.taskUid, { priority: priorityForm.priority });
    ElMessage.success(pt('优先级调整成功'));
    priorityVisible.value = false;
    await tableRef.value?.getData();
  } catch (e: any) {
    const msg = e?.response?.data?.message || e?.message || '优先级调整失败';
    // 409：版本冲突或当前状态不允许调整，提示刷新后重试
    if (e?.response?.status === 409) ElMessage.warning(`任务状态或版本已变化，请刷新后重试：${msg}`);
    else ElMessage.error(msg as string);
  } finally {
    prioritySaving.value = false;
  }
}

/* ---------------- 错误明细（契约 538395414） ---------------- */
const errorsVisible = ref(false);
const errorsLoading = ref(false);
const errorsRow = ref<ExtractionListItem | null>(null);
const errorItems = ref<ExtractionError[]>([]);
const errorsTotal = ref(0);
const errorQuery = reactive({ page: 1, pageSize: 20 });

async function loadErrors() {
  if (!errorsRow.value) return;
  errorsLoading.value = true;
  try {
    const res: any = await getExtractionErrors(errorsRow.value.taskUid, { page: errorQuery.page, pageSize: errorQuery.pageSize });
    errorItems.value = res?.data?.items ?? [];
    errorsTotal.value = res?.data?.total ?? 0;
  } catch (e: any) {
    ElMessage.error((e?.response?.data?.message || e?.message || '错误明细加载失败') as string);
  } finally {
    errorsLoading.value = false;
  }
}
function openErrors(row: ExtractionListItem) {
  errorsRow.value = row;
  errorQuery.page = 1;
  errorsVisible.value = true;
  void loadErrors();
}
function onErrorPageChange(page: number) {
  errorQuery.page = page;
  void loadErrors();
}
/** 定位字段为空时不伪造 filePath，统一显示占位符 */
function errorLocation(err: ExtractionError) {
  const loc = err.filePath || err.location || (err as any).relativePath || (err as any).resourceName;
  return loc ? String(loc) : '-';
}

async function act(fn: () => Promise<unknown>, label: string) {
  try {
    await fn();
    ElMessage.success(label + '成功');
    await tableRef.value?.getData();
  } catch (e: any) {
    ElMessage.error((e?.response?.data?.message || e?.message || label + '失败') as string);
  }
}

function onStart(row: ExtractionListItem) {
  act(() => startExtraction(row.taskUid), pt('启动'));
}
function onPause(row: ExtractionListItem) {
  act(() => pauseExtraction(row.taskUid), pt('暂停'));
}
function onResume(row: ExtractionListItem) {
  act(() => resumeExtraction(row.taskUid), pt('恢复'));
}
function dropStream(uid: string) {
  const c = streams.get(uid);
  if (c) {
    c.abort();
    streams.delete(uid);
  }
}
function onCancel(row: ExtractionListItem) {
  dropStream(row.taskUid);
  ElMessageBox.confirm(pt('确认取消该提取任务？'), pt('提示'), { type: 'warning' })
    .then(() => act(() => cancelExtraction(row.taskUid), pt('取消')))
    .catch(() => {});
}
function onRetry(row: ExtractionListItem) {
  act(() => retryExtraction(row.taskUid), pt('重试'));
}
function onDelete(row: ExtractionListItem) {
  ElMessageBox.confirm(pt('确认删除该提取任务记录？删除后不可恢复。'), pt('提示'), { type: 'warning' })
    .then(() => act(() => deleteExtraction(row.taskUid), pt('删除')))
    .catch(() => {});
}

async function onDownloadOrReceipt(row: ExtractionListItem) {
  const res: any = await getExtraction(row.taskUid);
  const detail = res?.data;
  if (!detail) return;
  if (detail.result?.downloadUrl) {
    const url = detail.result.downloadUrl.startsWith('http') ? detail.result.downloadUrl : PRODUCT_BASE_URL + detail.result.downloadUrl;
    window.open(url, '_blank');
  } else if (detail.delivery) {
    ElMessageBox.alert(
      '该任务按创建时的目标路径直接投递到共享目录，无在线下载。\n\n' +
        '交付状态：' +
        detail.delivery.status +
        '\n' +
        '相对路径：' +
        detail.delivery.relativePath +
        '\n' +
        '文件大小：' +
        (detail.delivery.sizeBytes / 1024).toFixed(1) +
        ' KB\n' +
        '目标目录：' +
        detail.delivery.targetPath +
        '\n' +
        'SHA256：' +
        detail.delivery.sha256,
      pt('已投递至共享目录'),
      { dangerouslyUseHTMLString: false }
    );
  } else {
    ElMessage.warning(pt('暂无结果'));
  }
}

/** 下载 ZIP 包中：taskUid 集合，避免同一行重复触发 */
const downloadingZip = ref<string[]>([]);

/** 触发浏览器保存 blob；用原生 a[download]，不额外引依赖 */
function saveBlobAs(blob: Blob, fileName: string) {
  const objectUrl = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = objectUrl;
  anchor.download = fileName;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  // 延迟回收，避免部分浏览器在 click 未落盘前就失效
  setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
}

/**
 * 下载 ZIP 包（契约 538395419）。
 * generation / token 必须来自详情返回的 downloadUrl，前端不拼接；
 * 在线归档需带 clientid + Authorization 头，故走 fetch/blob 而非 window.open。
 */
async function onDownloadZip(row: ExtractionListItem) {
  if (downloadingZip.value.includes(row.taskUid)) return;
  downloadingZip.value = [...downloadingZip.value, row.taskUid];
  try {
    const res: any = await getExtraction(row.taskUid);
    const detail = res?.data;
    // 契约：downloadUrl 在详情顶层；历史数据可能在 result.downloadUrl，双重兜底
    const downloadUrl: string | undefined = detail?.downloadUrl || detail?.result?.downloadUrl;
    const ref = parseExtractionArchiveUrl(downloadUrl, row.taskUid);
    if (!ref) {
      ElMessage.warning(pt('该任务暂无在线 ZIP 下载地址，或地址缺少生成参数'));
      return;
    }
    const result = await downloadExtractionArchive(ref);
    const rawName = detail?.result?.archiveName || row.taskName || '数据提取归档';
    const fileName = /\.zip$/i.test(rawName) ? rawName : rawName.replace(/[\\/:*?"<>|]/g, '_') + '.zip';
    saveBlobAs(result.blob, fileName);
    ElMessage.success(
      result.status === 206 ? '已下载归档分片（' + fmtSize(result.blob.size) + '）' : '已开始下载 ZIP 包（' + fmtSize(result.blob.size) + '）'
    );
  } catch (e: any) {
    ElMessage.error(e?.message || '下载 ZIP 包失败');
  } finally {
    downloadingZip.value = downloadingZip.value.filter((uid) => uid !== row.taskUid);
  }
}

onUnmounted(() => {
  streams.forEach((c) => c.abort());
  streams.clear();
  streamRetries.clear();
});
</script>

<template>
  <div class="extract-page">
    <!-- 左：资源树。布局注入挂载位时 Teleport 到左列；独立挂载时退化为内联左树 -->
    <Teleport :to="treeTarget" :disabled="!hosted">
      <div class="extract-tree" :class="{ 'is-hosted': hosted }">
        <ResourceTree ref="treeRef" :category-root="categoryRoot" @change="onTreeChange" />
      </div>
    </Teleport>
    <div v-if="!hosted" class="extract-split" />

    <section class="extract-detail">
      <!-- 保存按钮定位到 tab 栏右侧（仅新建提取 tab 显示）：EP 的 el-tabs 无 #extra 插槽 -->
      <el-button v-if="activeTab === 'new'" class="extract-save-btn" type="primary" :loading="creating" :icon="UploadFilled" @click="submitCreate">{{
        pt('创建并启动')
      }}</el-button>
      <el-tabs v-model="activeTab" class="extract-tabs">
        <el-tab-pane :label="pt('新建提取')" name="new">
          <div class="extract-create">
            <el-form ref="createFormRef" :model="createForm" :rules="createRules" label-width="120px" class="extract-edit-form">
              <!-- 卡片 1：基本信息（高度由内容决定） -->
              <section class="edit-card edit-card--basic">
                <h3 class="edit-card__title">{{ pt('基本信息') }}</h3>
                <div class="edit-card__body">
                  <el-form-item :label="pt('任务名')">
                    <el-input
                      v-model="createForm.taskName"
                      :placeholder="pt('勾选数据后自动生成，可手动修改；也是 ZIP 顶层目录名')"
                      maxlength="200"
                    />
                  </el-form-item>
                  <el-form-item :label="pt('优先级')">
                    <el-radio-group v-model="createForm.priority">
                      <el-radio value="high">{{ pt('高') }}</el-radio>
                      <el-radio value="medium">{{ pt('中') }}</el-radio>
                      <el-radio value="low">{{ pt('低') }}</el-radio>
                    </el-radio-group>
                  </el-form-item>
                  <el-form-item :label="pt('目标路径')">
                    <el-input v-model="createForm.targetPath" :placeholder="pt('留空返回下载链接；非空须为已登记共享目录内绝对路径')" />
                  </el-form-item>
                </div>
              </section>

              <!-- 卡片 2：提取数据（勾选资源即自动加载文件列表，可勾选文件，占满剩余高度） -->
              <section class="edit-card edit-card--data">
                <div class="edit-card__header">
                  <h3 class="edit-card__title">{{ pt('提取数据') }}</h3>
                  <div class="edit-card__header-actions">
                    <el-checkbox
                      :model-value="allSelected"
                      :indeterminate="selectedCount > 0 && !allSelected"
                      :disabled="!totalCount"
                      @change="toggleSelectAll"
                      >{{ pt('全选') }}</el-checkbox
                    >
                    <span class="ec-selected">已选 {{ selectedCount }} / {{ totalCount }} 个文件</span>
                  </div>
                </div>
                <div class="ec-file-summary" v-if="totalCount">
                  <span
                    >{{ pt('总大小：') }}<b>{{ (summaryBytes / 1024).toFixed(1) }} KB</b></span
                  >
                  <span>产品类别：{{ summaryCategories.join('、') || '-' }}</span>
                </div>
                <div class="edit-card__body" v-loading="loadingFiles">
                  <el-tree
                    v-if="fileTreeData.length"
                    ref="fileTreeRef"
                    class="ec-file-tree"
                    :data="fileTreeData"
                    node-key="key"
                    :props="{ label: 'label', children: 'children' }"
                    :default-expanded-keys="fileTreeExpandedKeys"
                    :expand-on-click-node="false"
                    :check-on-click-node="false"
                    :check-on-click-leaf="false"
                    show-checkbox
                    :check-strictly="false"
                    @check="onFileTreeCheck"
                  >
                    <template #default="{ data }">
                      <div class="ec-tree-node" :class="`is-${data.kind}`">
                        <span class="ec-tree-node__label" :title="data.label">{{ data.label }}</span>
                        <span v-if="data.kind === 'resource'" class="ec-tree-node__count">{{ data.children?.length ?? 0 }} 个文件</span>
                        <span v-else-if="data.sizeBytes != null" class="ec-tree-node__size">{{ (data.sizeBytes / 1024).toFixed(1) }} KB</span>
                      </div>
                    </template>
                  </el-tree>
                  <div class="ec-hint" v-else-if="!loadingFiles">
                    在左侧资源树勾选数据后，这里会自动列出可提取的文件，勾选后点「创建并启动」执行提取。
                  </div>
                </div>
              </section>
            </el-form>
          </div>
        </el-tab-pane>

        <el-tab-pane label="提取列表" name="list">
          <Table
            ref="tableRef"
            :columns="columns"
            :request="loadList"
            :query-params="queryParams"
            :request-cfg="{ page: 'page', size: 'pageSize', list: 'items' }"
          >
            <template #search>
              <el-select v-model="queryParams.state" label="状态" placeholder="全部状态" clearable>
                <el-option v-for="o in STATE_OPTIONS" :key="o.value" :label="o.label" :value="o.value" />
              </el-select>
              <el-select v-model="queryParams.categoryUid" label="产品类别" placeholder="全部类别" clearable>
                <el-option v-for="o in categoryOptions" :key="o.value" :label="o.label" :value="o.value" />
              </el-select>
            </template>
          </Table>
        </el-tab-pane>
      </el-tabs>

      <!-- 调整优先级弹窗 -->
      <el-dialog v-model="priorityVisible" title="调整提取优先级" width="360px" append-to-body>
        <el-form label-width="80px">
          <el-form-item label="优先级">
            <el-radio-group v-model="priorityForm.priority">
              <el-radio value="high">高</el-radio>
              <el-radio value="medium">中</el-radio>
              <el-radio value="low">低</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-form>
        <template #footer>
          <el-button @click="priorityVisible = false">取消</el-button>
          <el-button type="primary" :loading="prioritySaving" @click="savePriority">确定</el-button>
        </template>
      </el-dialog>

      <!-- 错误明细弹窗 -->
      <el-dialog v-model="errorsVisible" :title="`错误明细 · ${errorsRow?.taskName || ''}`" width="820px" append-to-body>
        <el-table v-loading="errorsLoading" :data="errorItems" border size="small" max-height="420">
          <el-table-column prop="errorUid" label="错误ID" min-width="160" show-overflow-tooltip />
          <el-table-column prop="code" label="错误码" min-width="120" show-overflow-tooltip />
          <el-table-column prop="message" label="错误信息" min-width="200" show-overflow-tooltip />
          <el-table-column label="定位" min-width="180" show-overflow-tooltip>
            <template #default="{ row }"
              ><span :class="{ 'is-placeholder': errorLocation(row) === '-' }">{{ errorLocation(row) }}</span></template
            >
          </el-table-column>
          <el-table-column label="修复令牌" min-width="140" show-overflow-tooltip>
            <template #default="{ row }">{{ row.repairToken || '-' }}</template>
          </el-table-column>
        </el-table>
        <div class="errors-pagination">
          <el-pagination
            v-model:current-page="errorQuery.page"
            :page-size="errorQuery.pageSize"
            :total="errorsTotal"
            layout="total, prev, pager, next"
            @current-change="onErrorPageChange"
          />
        </div>
      </el-dialog>
    </section>
  </div>
</template>

<style scoped lang="scss">
/* 主区：左树 + 右表。被布局接管时树已 Teleport 到布局左列，本容器只剩右表 section。 */
.extract-page {
  display: flex;
  flex-direction: row;
  align-items: stretch;
  height: 100%;
  min-height: 0;
  overflow: hidden;
  /* 与数据入库 import-page 一致：容器透明，唯一可见框由 .extract-detail 提供，
     避免「白底大层托着悬浮边框框」的双层视觉。 */
  background: transparent;
}
.extract-tree {
  flex: 0 0 auto;
  width: 300px;
  min-width: 0;
  padding: 10px 8px 10px 14px;
  box-sizing: border-box;
  overflow: hidden;
  &.is-hosted {
    flex: 1 1 auto;
    width: 100%;
    padding: 0;
  }
}
.extract-split {
  flex: 0 0 auto;
  width: 1px;
  background: var(--el-border-color-light);
}
.extract-detail {
  position: relative;
  display: flex;
  flex: 1;
  flex-direction: column;
  min-width: 0;
  min-height: 0;
  overflow: hidden;
  /* 与数据入库 import-detail 一致：单个撑满的框（margin:0 + 6px 圆角），
     不再是带外边距的悬浮小框，消除多余的一层视觉。 */
  margin: 0;
  background: var(--el-bg-color-overlay);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 6px;
}
.extract-save-btn {
  position: absolute;
  z-index: 2;
  top: 4px;
  right: 14px;
}
.extract-tabs {
  display: flex;
  flex: 1;
  flex-direction: column;
  min-height: 0;
}
.extract-create {
  display: flex;
  flex: 1;
  height: 100%;
  min-height: 0;
  padding: 0;
}
/* 与数据入库新建表单同款：单框 + 标题横线分区。唯一边框由外层 .extract-detail 提供，
   内部 section 不再各自套圆角卡片，消除「外框套两个卡片」的盒中盒。 */
.extract-edit-form {
  display: flex;
  flex-direction: column;
  gap: 0;
  width: 100%;
  height: 100%;
  min-height: 0;
  padding: 0;
  box-sizing: border-box;
  overflow: auto;
  background: transparent;
}
.edit-card {
  display: flex;
  flex-direction: column;
  min-height: 0;
  background: var(--el-fill-color-blank);
  &--basic {
    flex: none;
  }
  &--data {
    flex: 1 1 auto;
    /* 两个分区之间一条横线（标题自身横线 + 本线，形成清晰分段） */
    border-top: 1px solid var(--el-border-color-lighter);
  }
}
.edit-card__header {
  display: flex;
  flex: none;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 0 16px;
  border-bottom: 1px solid var(--el-border-color-lighter);
}
.edit-card__header-actions {
  display: flex;
  align-items: center;
  gap: 12px;
}
.edit-card__title {
  margin: 0;
  padding: 12px 16px;
  font-size: 14px;
  font-weight: 600;
  color: var(--el-text-color-primary);
  border-bottom: 1px solid var(--el-border-color-lighter);
}
.edit-card__header .edit-card__title {
  padding: 12px 0;
  border-bottom: 0;
}
.edit-card__body {
  flex: 1;
  min-height: 0;
  padding: 12px 16px;
  overflow: auto;
}
.ec-file-summary {
  display: flex;
  flex: none;
  flex-wrap: wrap;
  gap: 6px 18px;
  padding: 8px 16px;
  font-size: 13px;
  line-height: 1.6;
  color: var(--el-text-color-regular);
  background: var(--el-fill-color-light);
}
.ec-hint {
  font-size: 13px;
  color: var(--el-text-color-secondary);
}
.ec-selected {
  font-size: 13px;
  color: var(--el-text-color-secondary);
}
/* 文件清单树：一级资源组、二级文件，父子勾选联动 */
.ec-file-tree {
  min-height: 0;
  padding: 4px 2px;
  background: transparent;
}
.ec-tree-node {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
  width: 100%;
  padding-right: 8px;
  font-size: 13px;
}
.ec-tree-node__label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  color: var(--el-text-color-regular);
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ec-tree-node.is-resource .ec-tree-node__label {
  font-weight: 600;
  color: var(--el-text-color-primary);
}
.ec-tree-node__count,
.ec-tree-node__size {
  flex: none;
  font-size: 12px;
  color: var(--el-text-color-secondary);
}
:deep(.ec-file-tree .el-tree-node__content) {
  height: 30px;
}
:deep(.ec-file-tree > .el-tree-node > .el-tree-node__content) {
  background: var(--el-fill-color-light);
  border-radius: 4px;
}
:deep(.extract-tabs > .el-tabs__header) {
  margin: 0;
  padding: 0 14px;
  border-bottom: 1px solid var(--el-border-color-lighter);
}
:deep(.el-tabs__nav-wrap::after) {
  display: none;
}
:deep(.extract-tabs > .el-tabs__content) {
  flex: 1;
  min-height: 0;
  overflow: hidden;
}
:deep(.el-tab-pane) {
  height: 100%;
}
/* 下面三个类只出现在 columns 的 JSX render 里：scoped 编的 [data-v-xxx] 匹配不到
   ElTable 渲染上下文产出的 vnode，改用 :deep() 由本组件 scope 锚定。 */
:deep(.row-actions) {
  white-space: nowrap;
}
:deep(.progress-cell) {
  display: flex;
  align-items: center;
  gap: 8px;
}
:deep(.progress-cell .el-progress) {
  flex: 1 1 auto;
  min-width: 72px;
}
:deep(.progress-cell .el-progress__text) {
  flex: none;
  min-width: 38px;
  font-size: 12px;
  color: var(--el-text-color-regular);
  text-align: right;
}
:deep(.progress-stage) {
  flex: none;
  max-width: 64px;
  overflow: hidden;
  font-size: 11px;
  color: var(--el-text-color-secondary);
  text-overflow: ellipsis;
  white-space: nowrap;
}
:deep(.progress-stage--success) {
  color: var(--el-color-success);
}
:deep(.progress-stage--exception) {
  color: var(--el-color-danger);
}
:deep(.progress-stage--warning) {
  color: var(--el-color-warning);
}
:deep(.progress-stage--info) {
  color: var(--el-text-color-placeholder);
}

.is-placeholder {
  color: var(--el-text-color-placeholder);
}
.errors-pagination {
  display: flex;
  justify-content: flex-end;
  margin-top: 12px;
}
</style>
