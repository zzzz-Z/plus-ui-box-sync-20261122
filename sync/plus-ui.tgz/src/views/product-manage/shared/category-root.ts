/**
 * 产品类别根作用域：把外层 `provide('product-category-root', '<语义编码>')` 落到类别树上。
 *
 * WHY 独立成模块：数据浏览（metadata/tree）与数据查询（resources/tree）用的是**两棵不同的树**，
 * 但「按根收窄」的判定口径必须一致 —— 否则同一条产品线在两页看到的范围会不一样。
 *
 * 后端约束（2026-11 实测，勿再尝试）：
 *   - `/platform/metadata/tree`、`/platform/resources/tree` 对 categoryRoot / productCategoryRoot /
 *     categoryKey / rootCategoryKey / categoryUid 等**查询参数一律忽略**，恒返回 primary + result 两棵全量根；
 *   - `/platform/resources` 列表仅支持**单个** `categoryUid` 精确过滤（重复参数只认第一个，逗号/数组写法无效），
 *     且父类别不会自动含子类（不支持递归）。
 * 因此「按根取数」只能在前端完成：树按根裁剪，列表按根子树下的资源所在类别 uid 收敛。
 */

/** provide/inject 的键：值为产品语义根编码（如 attribute_primary / primary / result） */
export const CATEGORY_ROOT_KEY = 'product-category-root';

/**
 * 语义编码精确匹配失败时的类别名兜底。
 * CONSTRAINT 仅覆盖根级编码（primary / result）——第二层编码（attribute_primary 等）在实测树里
 * 与 categoryKey 逐字相同，无需兜底；乱加关键字反而可能命中多个节点造成歧义。
 */
const ROOT_NAME_HINTS: Record<string, string[]> = {
  primary: ['初级'],
  result: ['成果']
};

/** 读外层下发的产品语义根编码；未注入时返回空串（表示不做根收窄，元数据管理页即此情形） */
export function injectCategoryRoot(): string {
  return inject<string>(CATEGORY_ROOT_KEY, '') || '';
}

/** 是否资源节点（两棵树的资源叶子 nodeType 均为 'resource'） */
function isResourceNode(node: any): boolean {
  return node?.nodeType === 'resource';
}

/**
 * 按 categoryKey / categoryUid / uid 深度查找类别节点（含自身）。
 *
 * WHY 三个键都试：metadata/tree 的类别节点带 categoryUid 与 categoryKey，
 * resources/tree 的类别节点带 uid 与 categoryKey，两套口径都要认。
 * 资源叶子不参与匹配（它的 uid 是资源 id，不是类别）。
 */
export function findCategoryNode(list: any[], key: string): any | null {
  if (!key) return null;
  for (const node of list ?? []) {
    if (!isResourceNode(node)) {
      if (node.categoryKey === key || node.categoryUid === key || node.uid === key) return node;
    }
    const hit = node.children?.length ? findCategoryNode(node.children, key) : null;
    if (hit) return hit;
  }
  return null;
}

/** 按类别名关键字深度查找（兜底路径，仅在编码精确匹配失败时启用） */
function findCategoryNodeByHints(list: any[], hints: string[]): any | null {
  for (const node of list ?? []) {
    if (!isResourceNode(node) && hints.some((hint) => String(node.categoryName || '').indexOf(hint) !== -1)) return node;
    const hit = node.children?.length ? findCategoryNodeByHints(node.children, hints) : null;
    if (hit) return hit;
  }
  return null;
}

/**
 * 把语义根编码解析成类别树上的根节点；解析不到返回 null。
 *
 * WHY 解析失败要交给调用方显式决定回退（而不是这里直接返回全量）：
 * 静默退回全量时页面看起来「没改」，排查成本很高；调用方至少要在注释/行为上说明回退口径。
 */
export function pickRootNode(list: any[], categoryRoot: string): any | null {
  if (!categoryRoot) return null;
  const hints = ROOT_NAME_HINTS[categoryRoot] ?? [];
  return findCategoryNode(list, categoryRoot) || (hints.length ? findCategoryNodeByHints(list, hints) : null);
}

/**
 * 收集根子树内**资源实际挂靠的类别 uid**（去重）。
 *
 * WHY 取「资源节点的 categoryUid」而不是「叶子类别 uid」：
 * `/platform/resources` 的过滤键是资源自身的 categoryUid，而树里既有「叶子类别直挂资源」，
 * 也有「中间类别直挂资源」，按资源节点反推才不会漏。
 * 返回空数组表示该根下确实没有资源（如 result 系列），调用方据此返回空列表而非全量。
 */
export function collectScopedCategoryUids(root: any): string[] {
  const out = new Set<string>();
  const walk = (node: any, parentUid?: string) => {
    if (isResourceNode(node)) {
      const uid = node.categoryUid || parentUid;
      if (uid) out.add(uid);
      return;
    }
    const uid = node.categoryUid || node.uid;
    for (const child of node.children ?? []) walk(child, uid);
  };
  if (root) walk(root);
  return [...out];
}

/**
 * 按根收窄一棵类别树：命中返回 [根节点]（保留完整子树），未命中回退全量。
 * 未注入 categoryRoot 时也回退全量，保证元数据管理页（无产品线上下文）行为不变。
 */
export function scopeTreeByRoot<T = any>(list: T[], categoryRoot: string): T[] {
  if (!categoryRoot) return list;
  const hit = pickRootNode(list as any[], categoryRoot);
  return hit ? ([hit] as T[]) : list;
}
