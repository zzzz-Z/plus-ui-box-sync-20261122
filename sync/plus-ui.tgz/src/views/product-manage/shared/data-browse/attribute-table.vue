<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
/**
 * 资源属性表（元数据浏览 / 元数据查询右侧「详情列表」）
 *
 * 数据源：GET /platform/resources/{resourceUid}/metadata-attributes
 * 交互契约（用户 2026-11-03 确认）：
 *   1. 表格铺开**全部字段**，横向滚动；表头「列设置」可控制显隐；
 *   2. 点行 → 地图定位到该条记录对应的图层范围并高亮（要素所属类别色实线 + 白色垫边，见 selection-style）；
 *      默认单选（再点别的行即替换），Ctrl/Cmd+左键 = 加选/取消该行的多选；
 *      多选时镜头贴合所有已选范围的并集；同时右侧抽屉打开该行全部字段（不遮挡列表与地图）。
 *   3. 行末「详情」按钮 → 同样打开右侧抽屉看全部字段（两列描述列表）。
 *   4. 一个资源可有多张元数据表 → 用 el-tabs 分表展示。
 *   5. 入参是**资源集合**：交付方（元数据浏览）传的是树上勾选的整批资源，
 *      tabs = 这批资源的全部元数据表（每 tab 一个资源的一张表），
 *      这样「勾选哪些资源」与「能看哪些表」是同一口径，不需要再回树里二次确认。
 *
 * WHY 不用项目通用 Table 组件：
 *   Table 的 request 契约要求返回 `data.items`，且 params 恒带 `pageNum`；
 *   本接口返回 `records` + `total`，分页字段是 `page`。两边字段全对不上，
 *   用 requestCfg 只能改读取端、改不了发送端的 pageNum，得再包一层适配函数，
 *   反而比直接用 el-table 更难读。属性表列是运行时决定的，也用不上列设置。
 */

import { Setting, View } from '@element-plus/icons-vue';
import type { TableInstance } from 'element-plus';
import {
  listAttributeTables,
  listResourceAttributes,
  resolveAttributeColumns,
  orderAttributeColumns,
  localizeFieldLabel,
  METADATA_ATTR_PAGE_SIZE_MAX,
  type AttributeTableOption,
  type MetadataAttributeColumn,
  type MetadataAttributeRecord
} from '@/api/product-manage/platform/metadata-attributes';
import { useMap } from '@/views/product-manage/shared/map/use-map';
import { MAP_SELECTION } from '@/components/product-manage/geo-map/selection-style';
import { geometryBounds, mergeBounds, spatialRangeToGeometry, type Bounds4 } from '@/views/product-manage/shared/map/spatial-range';
import { featureSelection, matchRecord, type FeatureSelection } from '@/views/product-manage/shared/map/feature-selection';
import AttributeRowDialog from '@/views/product-manage/shared/attribute-row-dialog.vue';
import { paneRightAnchor } from '@/views/product-manage/shared/detail-drawer-anchor';
import { closeRecordDetail, showRecordDetail } from '@/views/product-manage/shared/record-detail-host';

defineOptions({ name: 'ResourceAttributeTable' });

/**
 * resourceUids：要展示的资源集合（元数据浏览页传的就是树上勾选的那批资源）。
 *
 * WHY 用集合而不是单个 uid：用户的口径是「勾选哪些资源，就把它们的表都列出来」，
 * 勾选与「能看哪些表」必须是同一份数据；只传一个 uid 时会退化成「点谁看谁」，
 * 勾了三个资源却只看到最后一个的表，勾选这个动作在右栏就没有回馈了。
 *
 * resourceNames：uid → 资源中文名，用于多资源时给页签加前缀。
 * WHY 需要：不同资源常有同名表（如都叫「要素属性表」），只显示表名分不清是哪批数据；
 * 单资源场景不加前缀（前缀与自己名字重复，纯噪音）。
 */
const props = withDefaults(
  defineProps<{ resourceUids: string[]; resourceNames?: Record<string, string>; resourceColors?: Record<string, string> }>(),
  { resourceNames: () => ({}), resourceColors: () => ({}) }
);

/**
 * 本组件实例：传给 createDrawer 当 owner，让抽屉随本组件卸载一起销毁。
 * WHY 必须在 setup 顶层取：openDetail 是事件回调，那时 getCurrentInstance() 为 null。
 */
const owner = getCurrentInstance();

/**
 * 本表打开记录详情时拿到的宿主令牌：卸载时据此收起自己打开的那份，
 * 不会误关随后由地图等其它入口打开的详情（令牌校验在 closeRecordDetail 里做）。
 */
let detailToken: symbol | null = null;

const map = useMap();

/* ---------------------------- 高亮图层常量 ---------------------------- */
/**
 * 行高亮图层 id。
 *
 * WHY 不用 useMap 的 createLayerGroup：那套组件的配色/透明度由 palette + selectedIds 决定
 * （选中态填充不透明度 0.85），拿来做「框选一条记录」会把底图糊住；
 * 这里只要一个固定样式的虚线框，直接建 source/layer 更可控，且 id 前缀独立不与业务图层冲突。
 */
const HL_SRC = 'attr-row-hl-src';
const HL_FILL = 'attr-row-hl-fill';
const HL_HALO = 'attr-row-hl-halo';
const HL_LINE = 'attr-row-hl-line';
const HL_CIRCLE = 'attr-row-hl-circle';

/** 高亮线/填充/点颜色：优先取要素自身类别色，缺失时回退系统色（含非要素兜底场景） */
const HL_COLOR = ['coalesce', ['get', 'hlColor'], MAP_SELECTION.color] as any;

/**
 * 一个页签 = 某个资源的一张元数据表。
 *
 * WHY key 里带 resourceUid：`tableKey` 只在单个资源内唯一，两个资源都可能有
 * `flys_sx`（同名英文账本键），只用 tableKey 当页签名会撞车（el-tabs 的 name 冲突 → 点谁都是第一个）。
 * 拼成 `${resourceUid}::${tableKey}` 后既唯一，也能从 key 里反解出该拉哪个资源的接口。
 */
interface AttrTab {
  key: string;
  resourceUid: string;
  tableKey: string;
  label: string;
}

/**
 * 页签清单：勾选资源的全部元数据表，按「资源顺序 → 表顺序」展平。
 *
 * WHY 一次汇总所有资源的表：用户要的是「勾选的这批资源有哪些表」，
 * 切页签时再按需拉清单会先显示空 tabs 再弹出内容，而且切回上一个页签还要再拉一次。
 */
const tabs = ref<AttrTab[]>([]);
/** 当前激活页签的 key（`${resourceUid}::${tableKey}`）；空串表示这批资源还没有任何表 */
const activeTabKey = ref('');

/** 当前页签对应的资源 uid（拉属性时用；没有页签时为空，loadData 直接空态） */
const activeResourceUid = computed(() => tabs.value.find((t) => t.key === activeTabKey.value)?.resourceUid ?? '');
/** 当前页签对应的表键（为空表示不限表 —— 后端会混合返回该资源的全部表，仅作兜底） */
const activeTableKey = computed(() => tabs.value.find((t) => t.key === activeTabKey.value)?.tableKey ?? '');

/**
 * 当前页签所属资源的类别色（高亮用要素自身颜色）。
 * WHY 由父组件传入而非本组件重算：父级已有 uid→categoryName→palette 的同一份口径，
 * 这里再推一遍会漂移；取不到时高亮层回退 MAP_SELECTION.color。
 */
const activeColor = computed(() => props.resourceColors[activeResourceUid.value] || MAP_SELECTION.color);

/**
 * 全量记录（不分页：一次拉到契约上限，用户去掉了分页控件）。
 * WHY 用 MAX 而不是 DEFAULT：没有翻页出口后若只拉默认 50 条，多余记录既看不到也翻不到，
 * 会变成静默丢数据；接口单页上限 200，取上限一次拉全，表格内部纵向滚动即可看全。
 */
const records = ref<MetadataAttributeRecord[]>([]);
/** 后端返回的列（列名 + 中文标签），顺序即展示顺序 */
const columns = ref<MetadataAttributeColumn[]>([]);
const total = ref(0);

const loading = ref(false);
/** 资源确实没有元数据表（业务码 40404）时的空态文案开关 */
const noTable = ref(false);

/** 表格实例：列表行滚动定位（地图点图斑 → 滚到对应行）用 */
const tableRef = ref<TableInstance>();

/**
 * 详情抽屉的纵向锚点：右侧整列（上半地图 / 下半列表）。
 *
 * WHY 不锚表格本身：抽屉要「从地图顶部贯穿到页面底部」（用户 2026-11-10 确认），
 * 锚表格只能盖住下半区，上半截地图旁边还是空的；`.pane-right` 的矩形恰好是
 * 地图上沿 → 列表底沿，一次对齐就覆盖整列。解析细节见 detail-drawer-anchor.ts。
 *
 * WHY 传函数不缓存元素：布局里的 h-split / v-split 会实时改高度，元素不换、尺寸会变，
 * createDrawer 每次重新对齐都会再调一次这个函数。
 */
const drawerAnchor = () => paneRightAnchor(tableRef.value?.$el as HTMLElement | undefined);

/**
 * 空态文案：区分「这批勾选资源一张表都没有」与「某个资源没有表」。
 * WHY 要分：勾了 5 个资源却一个表都没有，说「该资源暂无元数据表」会让人以为只是当前这个资源没表、
 * 勾选动作没生效；直接把口径说成「勾选的资源都没有元数据表」才对得上用户刚做的操作。
 */
const emptyText = computed(() => (props.resourceUids.length > 1 ? pt('勾选的资源都没有元数据表') : pt('该资源暂无元数据表')));

/** 列设置面板里被勾选的列（默认全选 = 铺开全部字段） */
const shownKeys = ref<string[]>([]);

/**
 * 已「定位」到地图的行。
 *
 * 口径（用户 2026-11-04 确认）：默认**单选**——普通左键点行即替换成这一行；
 * Ctrl / Cmd + 左键 = 多选，再点已选行则取消它的定位。
 * CONSTRAINT 存 rowKey + 要素 + 范围，不存行对象引用：翻页后 `records` 是全新对象，
 * 拿旧引用比对不上，选中态会莫名其妙丢失；而第 1 页选中的行翻到第 2 页仍应保持高亮，
 * 所以要素必须自带（不能回头去 `records` 里反查）。
 */
interface LocatedRow {
  key: string;
  feature: any;
  bounds: Bounds4;
}
/**
 * 已定位行的容器用 shallowRef：
 * WHY 不用 ref —— ref 会把 feature 的 GeoJSON 坐标数组做深度响应式代理，
 * maplibre 读取时全部走 Proxy（几万条坐标就是几万次数组拦截），纯亏无益。
 * 这里只整体替换数组，不需要逐元素深层响应。
 */
const locatedRows = shallowRef<LocatedRow[]>([]);
/** rowKey 集合：行样式用（模板里逐行判定，避免每次 O(n) includes） */
const locatedKeySet = computed(() => new Set(locatedRows.value.map((r) => r.key)));

/**
 * 用户是否手动改过列显隐。
 * WHY 要记：切表（tab）/ 切资源后列集合会变，未手动改过时自动全选最符合预期；
 * 一旦用户自己勾掉过某列，再全选就等于覆盖他的选择。
 */
let columnTouched = false;

/**
 * 表格的完整列集合：后端列（有中文名）+ 行内出现但后端没列出的键（系统字段）。
 *
 * WHY 补行内键：`fieldLabels` 只覆盖业务字段，created_at / metadata_uid 这类系统字段
 * 只存在于 `values` 里；用户要求「显示所有字段」，这些也要能看能勾。
 *
 * WHY 用 localizeFieldLabel：这些键没有后端中文名，直接拿列名当表头就会出现英文表头。
 * 内置映射查得到就显示中文名，查不到的纯英文键**不补列**（表头不许有英文）；
 * 后端一列都没给时退回首行键，保证不是空表——空表比英文表头更糟。
 */
const allColumns = computed<MetadataAttributeColumn[]>(() => {
  const known = new Set(columns.value.map((c) => c.key));
  // 已有列的展示名也算「已知」：行内再冒出同名键（如中文列名对应的英文键）就是重复列
  const knownLabels = new Set(columns.value.map((c) => c.label));
  const extra: MetadataAttributeColumn[] = [];
  for (const row of records.value) {
    for (const key of Object.keys(row?.values ?? {})) {
      if (known.has(key) || knownLabels.has(key)) continue;
      known.add(key);
      const label = localizeFieldLabel(key);
      knownLabels.add(label || key);
      // 查不到中文名的英文键不补列：宁可少一列，也不让英文表头出现
      if (!label) continue;
      extra.push({ key, label });
    }
  }
  const merged = [...columns.value, ...extra];
  if (merged.length) return merged;
  // 后端一列都没给（只返回 fields 或空响应）时兜底用首行键，保证不是空表
  const first = records.value[0]?.values ?? {};
  return Object.keys(first).map((key) => ({ key, label: localizeFieldLabel(key) || key }));
});

/** 展示顺序：重要字段优先，其余保持后端 / 行内原序（与详情共用 orderAttributeColumns） */
const orderedColumns = computed<MetadataAttributeColumn[]>(() => orderAttributeColumns(allColumns.value));

/** 实际渲染的列（按展示顺序过滤掉被隐藏的） */
const displayColumns = computed<MetadataAttributeColumn[]>(() => orderedColumns.value.filter((c) => shownKeys.value.includes(c.key)));

/**
 * 列最小宽度（按表头文字估算）。
 *
 * WHY 不能固定 140：后端给的中文标签有长有短，「要素（图斑）个数统计」（实测文字宽 130px）、
 * 「影像色彩模式/波段」（111px）在 140px 列里只余 ~116px 内容宽 —— 装不下就折行，
 * 表头被撑成两行。这里按字数给宽度，配合表头 nowrap，保证单行显示；
 * 短标签（「数据格式」）也不会被拉成 140px 的空宽列。
 */
const COLMIN_FALLBACK = 120;
/** 单元格左右内边距（EP 默认 12+12）+ 留白余量 */
const COL_PADDING = 30;
/** 单字估算宽度：表头是 13px 字重 600，实测汉字约 13px，取 14 留出余量 */
const COL_CHAR_WIDTH = 14;

function columnMinWidth(label: string): number {
  const text = String(label ?? '');
  if (!text) return COLMIN_FALLBACK;
  // 半角字符（括号/斜杠/字母）按 0.6 个汉字宽估算，避免中文标签估得过宽
  let units = 0;
  for (const ch of text) units += /[\x00-\xff]/.test(ch) ? 0.6 : 1;
  return Math.max(COLMIN_FALLBACK, Math.ceil(units * COL_CHAR_WIDTH + COL_PADDING));
}

/**
 * 行唯一键。
 * 属性记录没有稳定主键（不同表主键列名不同），用「账本表键 + 物理表名 + 行内容哈希」拼一个：
 * 同一页里重复数据行也能区分，且翻页/筛选后同一行仍得到同一个 key（el-table 的 row-key 需要）。
 */
function rowKeyOf(row: MetadataAttributeRecord): string {
  let raw = '';
  try {
    raw = JSON.stringify(row?.values ?? {});
  } catch {
    raw = String(row?.values);
  }
  let h = 0;
  for (let i = 0; i < raw.length; i++) h = (h * 31 + raw.charCodeAt(i)) | 0;
  return `${row?.tableKey || ''}|${row?.pgTable || ''}|${h}`;
}

/**
 * 行样式：已定位的行加 `is-located`。
 *
 * WHY 不用 el-table 的 `highlight-current-row`：那是「当前单行」语义，
 * Ctrl 多选时第二行一点就把第一行的选中态顶掉了，用户看不出自己到底选了哪几条。
 * 自己按 rowKey 集合给 class，选中态与 el-table 的内部状态解耦，翻页也保得住。
 */
function rowClassName({ row }: { row: MetadataAttributeRecord }) {
  return locatedKeySet.value.has(rowKeyOf(row)) ? 'is-located' : '';
}

/** 单元格取值：后端 value 可能是对象/数组，直接渲染成 [object Object]，故统一字符串化 */
function cellText(row: MetadataAttributeRecord, field: string): string {
  const v = row?.values?.[field];
  if (v == null || v === '') return '-';
  if (typeof v === 'object') {
    try {
      return JSON.stringify(v);
    } catch {
      return String(v);
    }
  }
  return String(v);
}

/* ---------------------------- 数据加载 ---------------------------- */

/**
 * 拉取轮次：连续切页签 / 勾选变化都会打接口，先发的请求可能后返回。
 * 只有最新一轮允许写 records，否则会出现「点第 2 个页签，先显示它的数据，随后被第 1 个页签的迟到响应覆盖」。
 */
let loadToken = 0;

async function loadData() {
  const token = ++loadToken;
  const uid = activeResourceUid.value;
  if (!uid) {
    // 没有页签 = 这批资源一张表都没有：清空并走空态，不要发无意义请求
    records.value = [];
    columns.value = [];
    total.value = 0;
    noTable.value = !tabs.value.length;
    return;
  }
  loading.value = true;
  try {
    const res = await listResourceAttributes(uid, {
      tableKey: activeTableKey.value || undefined,
      // 无分页：固定第 1 页 + 单页上限，一次拉全量
      page: 1,
      pageSize: METADATA_ATTR_PAGE_SIZE_MAX
    });
    if (token !== loadToken) return;
    const data = res?.data;
    records.value = data?.records ?? [];
    // 列从响应归一：后端给的是 fieldLabels（列名 → 中文名），契约的 fields 实测为空
    columns.value = resolveAttributeColumns(data);
    total.value = data?.total ?? 0;
    noTable.value = false;
  } catch (e: any) {
    if (token !== loadToken) return;
    // 40404 = 该资源没有元数据表，是空态不是错误；其它错误由全局拦截器提示
    records.value = [];
    columns.value = [];
    total.value = 0;
    noTable.value = Number(e?.code) === 40404 || /40404/.test(String(e?.message ?? ''));
  } finally {
    // 迟到的响应不能把 loading 关掉（最新一轮还在跑）
    if (token === loadToken) loading.value = false;
  }
}

/** 表格渲染用的数据源（不分页：一次服务端返回即全量记录，前端不做二次过滤） */
const displayRecords = computed<MetadataAttributeRecord[]>(() => records.value);

/**
 * 初始化轮次：连续勾选会连续触发 init，先一轮的 await 可能后返回。
 * 只有最新一轮允许写 tabs / 拉数据，避免「取消了 A 却被上一轮写回来」。
 */
let initToken = 0;

/**
 * 首屏 / 勾选集合变化：汇总这批资源的表清单，挑一个页签，再拉第一页。
 *
 * WHY 并发拉全部资源：勾选一个类别可能带出十几个资源，串行 await 会让右栏白屏十几轮 RTT。
 * 顺序必须与入参一致（`resourceUids` 是树上勾选的树序），Promise.all 天然保序。
 *
 * prefer：重新初始化时希望保住的页签（同一张表在勾选变化后仍然存在，就停在这张表上）。
 * WHY 要保：勾一个资源看到第 3 个页签，再勾一个资源如果跳回第 1 个页签，等于每次勾选都把
 * 用户正在看的数据顶掉；只有原页签确实消失了（那个资源被取消勾选）才退回第一个。
 */
async function init(prefer?: string) {
  const token = ++initToken;
  // 重建页签会换掉整批 records：让仍在进行中的地图自动切表联动失效，别把旧点击落回新数据
  cancelPendingMapSelection();
  clearHighlight();
  const uids = props.resourceUids.filter(Boolean);
  if (!uids.length) {
    tabs.value = [];
    activeTabKey.value = '';
    await loadData();
    return;
  }

  const perResource = await Promise.all(
    uids.map(async (uid) => {
      try {
        return await listAttributeTables(uid);
      } catch {
        // 单个资源拉不到表不应拖垮整批：跳过它，其余资源照常展示
        return [] as AttributeTableOption[];
      }
    })
  );
  if (token !== initToken) return;

  // 多资源时给页签加资源名前缀；单资源不加（前缀=自己名字，纯噪音）
  const multi = uids.length > 1;
  const next: AttrTab[] = [];
  uids.forEach((uid, i) => {
    const name = props.resourceNames[uid] || uid;
    for (const opt of perResource[i]) {
      next.push({
        key: `${uid}::${opt.key}`,
        resourceUid: uid,
        tableKey: opt.key,
        label: multi ? `${name} · ${opt.label}` : opt.label
      });
    }
  });

  tabs.value = next;
  const keep = prefer && next.some((t) => t.key === prefer) ? prefer : next[0]?.key || '';
  activeTabKey.value = keep;
  await loadData();
}

function onTabChange() {
  // 用户手动切表：作废尚未落地的地图自动切表联动，避免它的 delayed 选中盖过这次主动选择
  cancelPendingMapSelection();
  // 换表 = 换了一整套记录，上一页表里攒的定位留着只会让人误认是新表的记录，清掉
  clearHighlight();
  loadData();
}

/* ---------------------------- 行操作 ---------------------------- */

function openDetail(row: MetadataAttributeRecord) {
  // 记录详情统一进布局右侧真实占位列（地图通道点要素也进同一列）：
  // 内容写入宿主即可，面板由布局集中渲染；点另一行原地换内容，不叠出第二列。
  detailToken = showRecordDetail({ row, columns: orderedColumns.value });
  if (detailToken) return;
  // 独立挂载（如 __debug 页面单挂 DataQuery）：没有布局注册的宿主，回落为原来的非模态抽屉
  createDrawer({
    title: pt('记录详情'),
    // 高度覆盖整个右侧内容区：从地图上沿到底部列表下沿（h-split 拖动时由 ResizeObserver 跟随）
    anchor: drawerAnchor,
    // 随本组件卸载销毁：路由不变但表格被换掉时，抽屉不会残留在 body 上
    owner,
    render: () => <AttributeRowDialog row={row} columns={orderedColumns.value} />
  });
}

// 表格卸载（换表 / 离开页面）时收起本表打开的详情列，避免残留一列空白
onBeforeUnmount(() => {
  if (detailToken) closeRecordDetail(detailToken);
  detailToken = null;
});

/**
 * 一条属性记录 → 它在图层上的几何（要素）+ 包围盒。
 *
 * 取值优先级：
 *   1. `spatial_range`（WKT / GeoJSON，归一见 map/spatial-range.ts）——**真实几何**，
 *      高亮画的是这条记录的图斑轮廓，而不是它的外接矩形；
 *   2. 取不到几何时退回 `nw/ne/sw/se` 四角经纬度（元数据表里必有的一组字段）拼矩形。
 * 都没有返回 null —— 此时行点击退回打开详情，不把镜头甩到 (0,0)。
 */
function recordFeature(row: MetadataAttributeRecord): { feature: any; bounds: Bounds4 } | null {
  const values = row?.values ?? {};

  const geom = spatialRangeToGeometry(values.spatial_range);
  const geomBounds = geom ? geometryBounds(geom) : null;
  if (geom && geomBounds) return { feature: toFeature(geom, geomBounds), bounds: geomBounds };

  const lngs: number[] = [];
  const lats: number[] = [];
  const corners: Array<[unknown, unknown]> = [
    [values.nw_lon, values.nw_lat],
    [values.ne_lon, values.ne_lat],
    [values.sw_lon, values.sw_lat],
    [values.se_lon, values.se_lat]
  ];
  for (const [lngRaw, latRaw] of corners) {
    const lng = Number(lngRaw);
    const lat = Number(latRaw);
    if (!Number.isFinite(lng) || !Number.isFinite(lat)) continue;
    lngs.push(lng);
    lats.push(lat);
  }

  if (!lngs.length) return null;
  const bounds: Bounds4 = [Math.min(...lngs), Math.min(...lats), Math.max(...lngs), Math.max(...lats)];
  return { feature: boundsFeature(bounds), bounds };
}

/**
 * 要素渲染支持的 GeoJSON 类型。
 * WHY 要筛：`GeometryCollection` maplibre 的 geojson source 不认（要素被静默丢弃），
 * 遇到这类混合几何就退回包围盒矩形，保证「点了行地图上一定有东西亮起来」。
 */
const RENDERABLE_GEOMETRY_TYPES = new Set(['Point', 'MultiPoint', 'LineString', 'MultiLineString', 'Polygon', 'MultiPolygon']);

/** 几何 → 要素；包围盒退化（点 / 单线）或类型不可渲染时换成扩过框的矩形 */
function toFeature(geometry: any, bounds: Bounds4) {
  const degenerate = bounds[2] - bounds[0] < MIN_SPAN || bounds[3] - bounds[1] < MIN_SPAN;
  const pointLike = geometry.type === 'Point' || geometry.type === 'MultiPoint';
  const usable = RENDERABLE_GEOMETRY_TYPES.has(geometry.type) && (!degenerate || pointLike);
  return { type: 'Feature', properties: { hlColor: activeColor.value }, geometry: usable ? geometry : boundsGeometry(bounds) };
}

/** 包围盒 → 矩形几何；零尺寸（点 / 单线）向四周扩一点，保证框得出来 */
const MIN_SPAN = 0.004;
function boundsGeometry(b: Bounds4) {
  let [minLng, minLat, maxLng, maxLat] = b;
  if (maxLng - minLng < MIN_SPAN) {
    const mid = (minLng + maxLng) / 2;
    minLng = mid - MIN_SPAN / 2;
    maxLng = mid + MIN_SPAN / 2;
  }
  if (maxLat - minLat < MIN_SPAN) {
    const mid = (minLat + maxLat) / 2;
    minLat = mid - MIN_SPAN / 2;
    maxLat = mid + MIN_SPAN / 2;
  }
  return {
    type: 'Polygon',
    coordinates: [
      [
        [minLng, minLat],
        [maxLng, minLat],
        [maxLng, maxLat],
        [minLng, maxLat],
        [minLng, minLat]
      ]
    ]
  };
}

/** 包围盒 → 矩形要素（四角兜底通道用） */
function boundsFeature(b: Bounds4) {
  return { type: 'Feature', properties: { hlColor: activeColor.value }, geometry: boundsGeometry(b) };
}

/**
 * 高亮 source / 四个 layer 幂等挂载（底图 setStyle 后会被清空，需重挂）。
 *
 * 线色取要素自身类别色（feature.properties.hlColor，由所属资源的 palette 推出），取不到回退 MAP_SELECTION.color；
 * 白色 halo 只做垫边。WHY 保留 halo：选中框与图斑同色时也靠白边切开轮廓，避免淹在填充里。
 */
function ensureHighlightLayers(m: any) {
  if (!m.getSource(HL_SRC)) {
    m.addSource(HL_SRC, { type: 'geojson', data: { type: 'FeatureCollection', features: [] } });
  }
  if (!m.getLayer(HL_FILL)) {
    m.addLayer({
      id: HL_FILL,
      type: 'fill',
      source: HL_SRC,
      paint: { 'fill-color': HL_COLOR, 'fill-opacity': MAP_SELECTION.fillOpacity }
    });
  }
  // halo 先加，垫在彩色线下
  if (!m.getLayer(HL_HALO)) {
    m.addLayer({
      id: HL_HALO,
      type: 'line',
      source: HL_SRC,
      paint: { 'line-color': MAP_SELECTION.haloColor, 'line-width': MAP_SELECTION.haloWidth, 'line-opacity': MAP_SELECTION.haloOpacity }
    });
  }
  if (!m.getLayer(HL_LINE)) {
    m.addLayer({
      id: HL_LINE,
      type: 'line',
      source: HL_SRC,
      paint: { 'line-color': HL_COLOR, 'line-width': MAP_SELECTION.lineWidth }
    });
  }
  // 点几何 fill / line 都画不出来，仍需 circle 兜底；但必须用 filter 限定只画 Point/MultiPoint：
  // maplibre 的 circle 图层会对几何的每个顶点都生成一个圆，不过滤的话定位到面/线记录时矩形四角也会冒出圆点
  if (!m.getLayer(HL_CIRCLE)) {
    m.addLayer({
      id: HL_CIRCLE,
      type: 'circle',
      source: HL_SRC,
      filter: ['match', ['geometry-type'], ['Point', 'MultiPoint'], true, false],
      paint: {
        'circle-color': HL_COLOR,
        'circle-radius': MAP_SELECTION.circleRadius,
        'circle-stroke-color': MAP_SELECTION.haloColor,
        'circle-stroke-width': MAP_SELECTION.circleStrokeWidth
      }
    });
  }
}

/**
 * 把所有已定位行的要素写进 source（不删图层）。图层只在「有东西要画」时才建，
 * 否则底图一切换就白挂三个空图层。
 * CONSTRAINT 末尾必须无条件 `syncIdleWatcher()`：清空定位走的是提前 return 分支，
 * 放在分支里会漏解绑，留下一个永远监听 idle 的僵尸回调。
 */
function applyHighlight() {
  const m = map.mapInstance.value;
  if (m && locatedRows.value.length) ensureHighlightLayers(m);
  const source: any = m?.getSource(HL_SRC);
  if (source?.setData) {
    source.setData({ type: 'FeatureCollection', features: locatedRows.value.map((r) => r.feature) });
    raiseHighlight(m);
  }
  syncIdleWatcher();
}

/**
 * 把高亮四层提到图层栈顶（fill → halo → line → circle，相对次序不变）。
 *
 * WHY 需要它：maplibre 的 addLayer 默认追加到栈顶，左侧树勾选资源挂瓦片图层、
 * 或底图切换后重挂，都会把选中框压到瓦片下面 —— 表现为「点了行、地图没反应」。
 * CONSTRAINT 只在图层已存在时提层：底图刚 setStyle 完会先清掉所有 source/layer，
 * 对不存在的 id 调 moveLayer 直接抛错，而这里的 watch 比业务侧重挂更早触发。
 */
function raiseHighlight(m: any) {
  const layers: any[] = m.getStyle()?.layers ?? [];
  const ours = [HL_FILL, HL_HALO, HL_LINE, HL_CIRCLE].filter((id) => m.getLayer(id));
  if (!ours.length) return;
  // 已在栈顶就不动：moveLayer 会触发重绘 → 又进 idle → 再 moveLayer，
  // 不挡这一层就是永动渲染循环（掉帧 + 风扇狂转）。
  const topIdx = Math.max(...ours.map((id) => layers.findIndex((l) => l?.id === id)));
  if (topIdx >= layers.length - 1) return;
  for (const id of ours) m.moveLayer(id);
}

/**
 * 地图空闲时补一次提层。
 *
 * WHY 还要挂 idle：点行之后再去左侧树勾资源，父组件会把瓦片图层追加到栈顶把选中框盖住；
 * 本组件拿不到「别人什么时候 addLayer」的时机，idle（渲染安静下来）是唯一稳定钩子。
 * CONSTRAINT ① 只在有定位行时监听、清空定位立即解绑，不给底图留常驻回调；
 * ② 提频（idle 在持续取瓦片时会连着触发，`getStyle()` 要序列化整份 style，
 * 不加节流就是白烧 CPU）。
 */
let idleBound: any = null;
let lastRaiseAt = 0;
function onMapIdle() {
  const m = map.mapInstance.value;
  if (!m || !locatedRows.value.length) return;
  const now = Date.now();
  if (now - lastRaiseAt < 250) return;
  lastRaiseAt = now;
  raiseHighlight(m);
}
function syncIdleWatcher() {
  const m = map.mapInstance.value;
  if (locatedRows.value.length && m && idleBound !== m) {
    m.on('idle', onMapIdle);
    idleBound = m;
  } else if (!locatedRows.value.length && idleBound) {
    try {
      idleBound.off('idle', onMapIdle);
    } catch {
      /* 地图已销毁 */
    }
    idleBound = null;
  }
}

/** 镜头贴合「全部已定位行」范围的并集 */
function fitLocated(m: any) {
  const merged = mergeBounds(locatedRows.value.map((r) => r.bounds));
  if (!merged) return;
  // 记录详情已改为右列真实占位（.pane-record），地图容器已被 flex 挤窄，
  // 无需再为悬浮抽屉额外留右侧 padding，按常规四边 80px 贴合即可。
  m.fitBounds(
    [
      [merged[0], merged[1]],
      [merged[2], merged[3]]
    ],
    {
      padding: 80,
      maxZoom: 13,
      duration: 600
    }
  );
}

function clearHighlight() {
  locatedRows.value = [];
  applyHighlight();
}

/**
 * 地图点要素 → 列表/地图双向联动（反向链路）。
 *
 * WHY 直接写 locatedRows 而不另起一套状态：locatedRows 一份状态同时驱动
 * ① 地图高亮边框（applyHighlight 写 source）② 列表行选中态（locatedKeySet → is-located）。
 * 把地图点击匹配到的行写进去，两个需求一次性满足，且 Ctrl 多选语义与点行完全一致。
 *
 * 高亮几何优先用点击命中的原始 geometry（精确贴合图斑），取不到再退回该行的 spatial_range。
 * CONSTRAINT 不调 fitLocated：地图 → 列表不该甩镜头，用户点哪块地镜头就留在哪。
 */
function applySelectionFromMap(sel: FeatureSelection) {
  const matched = matchRecord(records.value, sel.values);
  // sel.geometry 来自 MVT 聚合后的完整要素几何；spatialRangeToGeometry 是老入口（spatial_range 文本→几何），
  // 这里对已解析的 Geometry 对象直接透传，避免把瓦片片段的外接矩形当成要素高亮。
  const geom =
    (sel.geometry && typeof sel.geometry === 'object' && 'type' in (sel.geometry as any)
      ? (sel.geometry as any)
      : spatialRangeToGeometry(sel.geometry)) ?? (matched ? spatialRangeToGeometry(matched.values?.spatial_range) : null);
  const bounds = geom ? geometryBounds(geom) : null;
  const located = geom && bounds ? { feature: toFeature(geom, bounds), bounds } : matched ? recordFeature(matched) : null;
  if (!located) return;

  // 匹配不到行时仍画高亮边框（key 用 seq 保证唯一），只是列表没有选中态
  const key = matched ? rowKeyOf(matched) : `map-${sel.seq}`;
  locatedRows.value = [{ key, ...located }];
  applyHighlight();

  // 列表行滚入可视区：地图点到的记录可能很靠下，选中了却看不见等于没联动
  nextTick(() => {
    const rowEl = (tableRef.value?.$el as HTMLElement | undefined)?.querySelector?.('.el-table__row.is-located');
    rowEl?.scrollIntoView?.({ block: 'nearest' });
  });
}

/* ------------------- 地图点击 → 自动切页签（双向联动） ------------------- */

/**
 * 地图自动切表的轮次：连点不同图斑 / 用户手动切表 / 重建页签时，只让最后一次落地。
 * WHY 需要显式 token：切表要 await loadData()，期间用户可能又点了别的图斑或自己切了 tab，
 * 若让先发起的那次 await 返回后照旧写 locatedRows，就会用旧点击覆盖用户最新的选择。
 */
let mapSelectionToken = 0;
/** 切表拉数据期间暂存「最后一次」地图点击，loadData 完成后以它为准重放 */
let pendingMapSelection: FeatureSelection | null = null;

/** 用户主动改变上下文（切表 / 点行 / 取消定位 / 重建页签）：作废尚未落地的地图切表联动 */
function cancelPendingMapSelection() {
  mapSelectionToken += 1;
  pendingMapSelection = null;
}

/**
 * 地图点要素 → 同步高亮边框 + 选中列表行（与点行定位形成双向闭环）。
 *
 * 多资源叠加时地图一次显示所有资源的图斑，而列表一次只有一个页签的数据：
 * 点到别的资源的图斑，当前 records 里根本没这行，matchRecord 会正确拒绝误匹配，
 * 结果只有边框没有列表选中。故按点击携带的 resourceUid + tableKey 先自动切到对应页签，
 * 等新 records 到位再匹配 —— 「列表自动选中状态」才算真正闭环。
 *
 * CONSTRAINT 不调 fitLocated：地图 → 列表不该甩镜头，用户点哪块地镜头就留在哪。
 */
async function handleMapSelection(sel: FeatureSelection) {
  const token = ++mapSelectionToken;
  pendingMapSelection = sel;

  const targetKey = `${sel.resourceUid ?? ''}::${sel.tableKey ?? ''}`;
  const tabExists = !!sel.resourceUid && !!sel.tableKey && tabs.value.some((t) => t.key === targetKey);
  // 当前页签已能匹配到这行，或根本没有对应页签 → 无需切表，直接落地。
  // 连点时 activeTabKey 可能已是目标页签但 records 还在拉，用 matchRecord 兜住「必须等数据」。
  const needSwitch = tabExists && (targetKey !== activeTabKey.value || !matchRecord(records.value, sel.values));
  if (needSwitch) {
    activeTabKey.value = targetKey;
    clearHighlight();
    // 程序化改 v-model 不会触发 el-tabs 的 tab-change，必须自己拉数据
    await loadData();
  }

  // 期间又有新点击 / 用户动作：本次作废，以最后一次为准
  if (token !== mapSelectionToken) return;
  const latest = pendingMapSelection ?? sel;
  pendingMapSelection = null;
  applySelectionFromMap(latest);
}

/** 模板「取消定位」：清高亮的同时作废尚未落地的地图切表联动 */
function clearLocatedByUser() {
  cancelPendingMapSelection();
  clearHighlight();
}

/**
 * 行点击 → 高亮并定位到该记录对应的图层范围。
 *
 * 单选 / 多选（第三个参数是 el-table 透传的原生 MouseEvent）：
 * - 普通左键 = **替换**成这一行（默认单选）；
 * - Ctrl / Cmd + 左键 = **加选**这一行；点已选中的行则取消它的定位（toggle）。
 * CONSTRAINT 多选时镜头贴合所有已选行的并集；取消到一条不剩时只清空高亮、不甩镜头。
 */
function onRowClick(row: MetadataAttributeRecord, _column: unknown, event: MouseEvent) {
  // 用户点行即主动选择：作废尚未落地的地图自动切表联动
  cancelPendingMapSelection();
  // 点行同时打开右侧记录详情列：边看全字段边继续点别的行（详情列原地换内容），且不遮挡地图定位
  openDetail(row);

  const key = rowKeyOf(row);
  const multi = !!(event?.ctrlKey || event?.metaKey);
  const picked = locatedRows.value;
  const hit = picked.findIndex((r) => r.key === key);

  // 多选 + 已选 → 取消该行（无需再解析几何）
  if (multi && hit >= 0) {
    locatedRows.value = picked.filter((_, i) => i !== hit);
    applyHighlight();
    return;
  }

  const m = map.mapInstance.value;
  const located = recordFeature(row);
  if (!m || !located) return;

  locatedRows.value = multi ? [...picked, { key, ...located }] : [{ key, ...located }];
  applyHighlight();
  fitLocated(m);
}

/* ---------------------------- 列设置 ---------------------------- */

function toggleColumn(key: string) {
  columnTouched = true;
  shownKeys.value = shownKeys.value.includes(key) ? shownKeys.value.filter((k) => k !== key) : [...shownKeys.value, key];
}

function selectAllColumns() {
  columnTouched = true;
  shownKeys.value = orderedColumns.value.map((c) => c.key);
}

function invertColumns() {
  columnTouched = true;
  const shown = new Set(shownKeys.value);
  shownKeys.value = orderedColumns.value.filter((c) => !shown.has(c.key)).map((c) => c.key);
}

/* ---------------------------- 生命周期 / 监听 ---------------------------- */

// 列集合变化：未手动改过就全选；改过则只剔除已不存在的列（不覆盖用户选择）
watch(
  orderedColumns,
  (cols) => {
    const keys = cols.map((c) => c.key);
    if (!columnTouched) {
      shownKeys.value = keys;
      return;
    }
    const exists = new Set(keys);
    shownKeys.value = shownKeys.value.filter((k) => exists.has(k));
  },
  { immediate: true }
);

// 底图切换（setStyle）会清掉所有 source/layer：重挂图层并回填当前高亮
watch(
  () => map.styleVersion.value,
  () => {
    if (!map.mapInstance.value) return;
    applyHighlight();
  }
);

// 地图 → 列表：点地图要素后同步高亮边框 + 选中列表行（与点行定位形成双向闭环）
watch(featureSelection, (sel) => {
  if (sel) handleMapSelection(sel);
});

onMounted(() => init());

/**
 * 勾选集合变化 → 重建页签。
 *
 * WHY 比较内容而不比较数组引用：父组件每次重算都会产生新数组，
 * 只凭引用变化会在一模一样的勾选上反复重建（白拉一遍接口 + 丢定位）；
 * 拼成字符串比较才能判定「勾选集合真的变了没有」，顺带保住树序。
 *
 * WHY 保 activeTabKey：见 init 的 prefer 说明 —— 勾一个资源不该把正在看的表顶掉。
 */
watch(
  () => props.resourceUids.join(','),
  () => init(activeTabKey.value)
);

onBeforeUnmount(() => {
  // 先走 clearHighlight 解绑 idle：地图挂在 useMap 单例上、比本组件活得久，
  // 不解绑的话卸载后这个闭包仍会被每次 idle 调到（僵尸监听 + 幽灵提层）。
  clearHighlight();
  const m = map.mapInstance.value;
  if (!m) return;
  for (const id of [HL_CIRCLE, HL_LINE, HL_HALO, HL_FILL]) {
    if (m.getLayer(id)) m.removeLayer(id);
  }
  if (m.getSource(HL_SRC)) m.removeSource(HL_SRC);
});
</script>

<template>
  <div class="attr-page">
    <!-- 表切换 + 列设置：同一行，tabs 占左侧、工具占右侧 -->
    <div class="attr-bar">
      <div v-if="tabs.length" class="attr-tabs">
        <el-tabs v-model="activeTabKey" @tab-change="onTabChange">
          <el-tab-pane v-for="opt in tabs" :key="opt.key" :label="opt.label" :name="opt.key" />
        </el-tabs>
      </div>

      <div class="attr-tools">
        <!-- 有定位行时给个计数 + 「取消定位」出口：Ctrl 多选攒下几个框后，
             只能逐行 Ctrl 点掉太难用，切资源/换表也不会误留旧 selection。 -->
        <span v-if="locatedRows.length" class="attr-located">
          {{ pt('已定位') }} <b>{{ locatedRows.length }}</b> {{ pt('条') }}
          <el-button link type="primary" size="small" @click="clearLocatedByUser">{{ pt('取消定位') }}</el-button>
        </span>
        <span class="attr-count">{{ total }} 条 · 显示 {{ displayColumns.length }}/{{ orderedColumns.length }} 列</span>
        <el-popover placement="bottom-end" :width="300" trigger="click" popper-class="attr-col-popper">
          <template #reference>
            <el-button size="small" :icon="Setting">{{ pt('列设置') }}</el-button>
          </template>
          <div class="col-panel">
            <div class="col-panel__head">
              <span>字段显隐</span>
              <span class="col-panel__ops">
                <el-button link type="primary" size="small" @click="selectAllColumns">全选</el-button>
                <el-button link type="primary" size="small" @click="invertColumns">反选</el-button>
              </span>
            </div>
            <div class="col-panel__list">
              <el-checkbox v-for="col in orderedColumns" :key="col.key" :model-value="shownKeys.includes(col.key)" @change="toggleColumn(col.key)">
                {{ col.label }}
              </el-checkbox>
            </div>
          </div>
        </el-popover>
      </div>
    </div>

    <div v-loading="loading" class="attr-body">
      <el-table
        v-if="displayColumns.length"
        ref="tableRef"
        :data="displayRecords"
        height="100%"
        border
        stripe
        :row-key="rowKeyOf"
        :row-class-name="rowClassName"
        class="attr-table"
        @row-click="onRowClick"
      >
        <el-table-column type="index" label="#" width="56" align="center" fixed />
        <el-table-column
          v-for="col in displayColumns"
          :key="col.key"
          :label="col.label"
          :prop="`values.${col.key}`"
          :min-width="columnMinWidth(col.label)"
          show-overflow-tooltip
        >
          <template #default="{ row }">{{ cellText(row as MetadataAttributeRecord, col.key) }}</template>
        </el-table-column>
        <!-- 操作列固定在右侧：列很多时横向滚动后仍能点到「详情」 -->
        <el-table-column label="操作" width="72" align="center" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" :icon="View" title="查看详情" @click.stop="openDetail(row as MetadataAttributeRecord)" />
          </template>
        </el-table-column>
      </el-table>

      <el-empty v-else :description="noTable ? emptyText : loading ? '加载中…' : '暂无属性记录'" :image-size="80" />
    </div>
  </div>
</template>

<style scoped lang="scss">
.attr-page {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
  padding: 0;
  overflow: hidden;
  background: var(--el-bg-color);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 6px;
}

.attr-bar {
  display: flex;
  flex: 0 0 auto;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 0 12px;
  border-bottom: 1px solid var(--el-border-color-lighter);
}

.attr-tabs {
  flex: 1 1 auto;
  min-width: 0;

  :deep(.el-tabs__header) {
    margin: 0;
  }
  :deep(.el-tabs__nav-wrap::after) {
    display: none;
  }
}

.attr-tools {
  display: flex;
  flex: 0 0 auto;
  align-items: center;
  gap: 10px;
}

.attr-located {
  color: var(--el-color-primary);
  font-size: 12px;
  white-space: nowrap;
  b {
    font-variant-numeric: tabular-nums;
  }
}

.attr-count {
  color: var(--el-text-color-secondary);
  font-size: 12px;
  white-space: nowrap;
}

.attr-body {
  flex: 1 1 auto;
  min-height: 0;
  padding: 0 12px;
  overflow: hidden;
}

/* 点击行定位地图：鼠标形态要给出来，否则用户不知道行是可点的 */
.attr-table {
  :deep(.el-table__row) {
    cursor: pointer;
  }

  /* 已定位（is-located）行样式已归一到全局 src/assets/styles/index.scss
     的 html.group-manage 块（地图联动列表选中行唯一真源），此处不再重复。 */

  /* 表头单行：后端中文标签常是 8–10 字，默认会被折成两行、把表头撑高；
     宽度已在 columnMinWidth 里按字数给足，这里禁止换行并兜底省略号。
     不改 padding —— 与表体单元格保持同一内边距，否则表头文字和表体会偏移。 */
  :deep(.el-table__header-wrapper .cell),
  :deep(.el-table__fixed-header-wrapper .cell) {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    word-break: keep-all;
    overflow-wrap: normal;
  }
}

/* 列设置面板：字段可能有几十个，限高滚动 */
.col-panel__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 6px;
  color: var(--el-text-color-regular);
  font-size: 12px;
}

.col-panel__ops {
  display: flex;
  gap: 4px;
}

.col-panel__list {
  display: grid;
  grid-template-columns: 1fr;
  gap: 2px;
  max-height: 320px;
  overflow: auto;
}
</style>
