<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
/**
 * 元数据抽取
 *
 * 对齐 Apifox「元数据抽取」分组 7 个契约接口：
 *   run / report / listErrors / locate / correct / resolve / delete
 * 列表遵循项目 Table 契约：:request 回调 + #search 直挂控件 + #action 操作区，
 * 分页/加载由 Table 自管，刷新统一走 tableRef.getData()；clientid 由 request 拦截器注入。
 */
import { CircleClose, Plus, Refresh } from '@element-plus/icons-vue';
import { ElMessage, ElMessageBox } from 'element-plus';

import {
  correctExtractionError,
  deleteExtractionError,
  getExtractionErrorDetail,
  getExtractionReport,
  listExtractionErrors,
  runExtraction,
  type ExtractionErrorItem,
  type ExtractionReportBatch,
  type RunExtractionPayload
} from '@/api/product-manage/platform/extraction';

type ErrorScope = 'open' | 'resolved';

const activeTab = ref<'task' | 'error'>('task');
const reportTableRef = ref();
const errorTableRef = ref();

const running = ref(false);
const errorScope = ref<ErrorScope>('open');
const overview = ref<Record<string, unknown>>({});
const errorStats = ref<Record<string, unknown>>({});
const errorTotal = ref(0);

/** 搜索区参数：交给 Table 的 query-params，getData 会拼进 request 回调 */
const reportQuery = reactive({ keyword: '' });
const errorQuery = reactive({ keyword: '' });

const statusText = (value: unknown): string => {
  if (value == null || value === '') return '—';
  return String(value);
};

/** 契约 #2 report：拉全量批次后按关键词过滤，再本地切片交给 Table 分页 */
async function getBatches(params: any) {
  const res = await getExtractionReport({ limit: 200 });
  const data = res?.data;
  overview.value = (data?.overview ?? {}) as Record<string, unknown>;
  errorStats.value = (data?.errors ?? {}) as Record<string, unknown>;
  // 实测 report.batches 是 { items: [...] } 对象而非裸数组，须取 .items，否则 all.filter/slice 抛错
  let all: ExtractionReportBatch[] = data?.batches?.items ?? [];
  const kw = String(params?.keyword ?? '')
    .trim()
    .toLowerCase();
  if (kw) {
    all = all.filter((b) => [b.importUid, b.importStateText, b.metadataStatus, b.sourceKind, b.sourceFile].join(' ').toLowerCase().includes(kw));
  }
  const page = Number(params?.page) || 1;
  const size = Number(params?.pageSize) || 10;
  const items = all.slice((page - 1) * size, (page - 1) * size + size);
  return { code: 0, data: { items, total: all.length } };
}

/** 契约 #3 listErrors：按 scope 拉全量，关键词过滤字段键/错误码/信息后本地切片 */
async function getErrors(params: any) {
  const res = await listExtractionErrors({ scope: errorScope.value, limit: 200 });
  const data = res?.data;
  errorTotal.value = data?.total ?? data?.items?.length ?? 0;
  let all: ExtractionErrorItem[] = data?.items ?? [];
  const kw = String(params?.keyword ?? '')
    .trim()
    .toLowerCase();
  if (kw) {
    all = all.filter((e) => [e.errorUid, e.taskUid, e.fieldKey, e.code, e.message].join(' ').toLowerCase().includes(kw));
  }
  const page = Number(params?.page) || 1;
  const size = Number(params?.pageSize) || 10;
  const items = all.slice((page - 1) * size, (page - 1) * size + size);
  return { code: 0, data: { items, total: all.length } };
}

/** 执行自动抽取（契约 #1 run） */
async function openRunDialog() {
  const form = reactive<RunExtractionPayload>({ resourceUid: '', importUid: '', taskUid: '', write: true, recordErrors: true });
  createDialog({
    title: pt('执行元数据自动抽取'),
    width: '560px',
    render: () => (
      <Form model={form} span={24}>
        <el-input v-model={form.resourceUid} label="资源 UID (resourceUid)" placeholder="与导入批次 UID / 任务 UID 至少填一项" />
        <el-input v-model={form.importUid} label="入库批次 UID (importUid)" placeholder="可选；与其余两项至少填一项" />
        <el-input v-model={form.taskUid} label="任务 UID (taskUid)" placeholder="可选；与其余两项至少填一项" />
        <el-switch v-model={form.write} label="写回元数据表" />
        <el-switch v-model={form.recordErrors} label="记录抽取错误" />
      </Form>
    ),
    save: async () => {
      if (!form.resourceUid?.trim() && !form.importUid?.trim() && !form.taskUid?.trim()) {
        return { code: 1, message: pt('resourceUid / importUid / taskUid 至少填一项') };
      }
      try {
        running.value = true;
        const res = await runExtraction({
          resourceUid: form.resourceUid?.trim() || undefined,
          importUid: form.importUid?.trim() || undefined,
          taskUid: form.taskUid?.trim() || undefined,
          write: form.write,
          recordErrors: form.recordErrors
        });
        const ex = res?.data?.extraction;
        if (ex && ex.available === false) {
          ElMessage.warning('抽取不可用：' + statusText(ex.errorCode ?? '来源不可用'));
        } else {
          ElMessage.success('抽取完成，注入字段 ' + (ex?.injectedFieldCount ?? 0) + ' 个，记录错误 ' + (ex?.recordedErrorCount ?? 0) + ' 条');
        }
        reportTableRef.value?.getData();
        return { code: 0, message: pt('抽取已执行') };
      } catch (error) {
        ElMessage.error('执行抽取失败：' + (error instanceof Error ? error.message : String(error)));
        throw error;
      } finally {
        running.value = false;
      }
    }
  });
}

/** 对单个批次重新抽取（复用 run，预填 importUid） */
function reRun(batch: ExtractionReportBatch) {
  const form = reactive<RunExtractionPayload>({ importUid: batch.importUid, write: true, recordErrors: true });
  createDialog({
    title: pt('重新抽取'),
    width: '460px',
    render: () => (
      <Form model={form} span={24}>
        <el-input v-model={form.importUid} label="入库批次 UID (importUid)" />
        <el-switch v-model={form.write} label="写回元数据表" />
        <el-switch v-model={form.recordErrors} label="记录抽取错误" />
      </Form>
    ),
    save: async () => {
      await runExtraction({ importUid: form.importUid, write: form.write, recordErrors: form.recordErrors });
      ElMessage.success(pt('已重新提交抽取'));
      reportTableRef.value?.getData();
      return { code: 0, message: pt('已重新提交') };
    }
  });
}

/** 契约 #4 locate：查看错误定位与字段定义 */
async function openErrorDetail(item: ExtractionErrorItem) {
  try {
    const res = await getExtractionErrorDetail(item.errorUid);
    const detail = res?.data;
    if (!detail) return;
    const loc = detail.locate ?? {};
    const field = detail.field ?? null;
    const fieldLocated = detail.fieldLocated !== false && !!field;
    const lines: string[] = [];
    lines.push('错误 UID：' + item.errorUid);
    lines.push('错误码：' + statusText(item.code));
    lines.push('字段键：' + statusText(item.fieldKey));
    lines.push('字段中文名：' + statusText(loc.displayName));
    lines.push('值类型：' + statusText(loc.valueType));
    lines.push('必填：' + (loc.required ? pt('是') : pt('否')));
    if (!fieldLocated) lines.push('字段定义：未定位（' + statusText(loc.reason) + '）');
    else if (field) {
      lines.push('字段定义：' + statusText(field.name));
      lines.push('字段类型：' + statusText(field.type));
      lines.push('字段长度：' + (field.fieldLength != null ? String(field.fieldLength) : '—'));
      lines.push('可空：' + (field.nullable ? pt('是') : pt('否')));
    }
    lines.push('错误信息：' + statusText(item.message));
    await ElMessageBox.alert(lines.join('\n'), '错误定位 · ' + statusText(loc.tableName ?? loc.tableKey), {
      confirmButtonText: pt('关闭'),
      customClass: 'error-detail-box'
    });
  } catch (error) {
    ElMessage.error('定位失败：' + (error instanceof Error ? error.message : String(error)));
  }
}

/** 契约 #5 correct：先定位拿字段类型，再按类型纠正 */
async function correctError(item: ExtractionErrorItem) {
  try {
    const detailRes = await getExtractionErrorDetail(item.errorUid);
    const detail = detailRes?.data;
    const locate = detail?.locate ?? {};
    const field = detail?.field ?? null;
    const form = reactive({ value: '', note: '' });
    const valueType = String(locate.valueType ?? field?.valueType ?? '').toLowerCase();
    createDialog({
      title: pt('纠正抽取错误'),
      width: '520px',
      render: () => (
        <Form model={form} span={24}>
          <el-input v-model={form.value} label="纠正值" placeholder="按字段类型输入：整数/数值/布尔/文本" />
          <el-input v-model={form.note} label="备注（只入审计）" placeholder="可选" />
        </Form>
      ),
      save: async () => {
        if (form.value === '' || form.value == null) {
          return { code: 1, message: pt('纠正值不能为空') };
        }
        let value: string | number | boolean = form.value;
        if (
          valueType.includes('int') ||
          valueType.includes('num') ||
          valueType.includes('decimal') ||
          valueType.includes('double') ||
          valueType.includes('float')
        )
          value = Number(value);
        else if (valueType.includes('bool')) value = value === 'true' || value === '1' || value === 'yes';
        const res = await correctExtractionError(item.errorUid, { value, note: form.note || undefined });
        if (!res?.data?.resolved) return { code: 1, message: pt('后端未确认纠正成功') };
        ElMessage.success(pt('错误已纠正并消除'));
        errorTableRef.value?.getData();
        return { code: 0, message: pt('纠正成功') };
      }
    });
  } catch (error) {
    ElMessage.error('打开纠正窗口失败：' + (error instanceof Error ? error.message : String(error)));
  }
}

/** 契约 #7 delete：物理删除已纠正错误（后端强制 confirm:true） */
async function deleteError(item: ExtractionErrorItem) {
  try {
    await ElMessageBox.confirm('确认删除已纠正错误 ' + item.errorUid + ' ？该操作物理删除，不可恢复。', pt('删除确认'), { type: 'warning' });
    await deleteExtractionError(item.errorUid);
    ElMessage.success(pt('已删除'));
    errorTableRef.value?.getData();
  } catch (error) {
    if (error !== 'cancel' && error !== 'close') {
      ElMessage.error('删除失败：' + (error instanceof Error ? error.message : String(error)));
    }
  }
}

watch(errorScope, () => errorTableRef.value?.query());

const batchColumns: TableColumn<ExtractionReportBatch>[] = [
  { label: pt('入库批次 UID'), prop: 'importUid', minWidth: 200, showOverflowTooltip: true },
  { label: pt('入库状态'), prop: 'importStateText', width: 130 },
  { label: pt('元数据状态'), prop: 'metadataStatus', width: 140 },
  { label: pt('来源类型'), prop: 'sourceKind', width: 130 },
  { label: pt('来源文件'), prop: 'sourceFile', minWidth: 200, showOverflowTooltip: true },
  { label: pt('记录数'), prop: 'recordCount', width: 90 },
  { label: pt('错误数'), prop: 'errorCount', width: 90 },
  {
    action: true,
    label: pt('操作'),
    width: 120,
    fixed: 'right',
    render: ({ row }) => (
      <el-button link type="primary" icon={Refresh} disabled={running.value} onClick={() => reRun(row)}>
        重新抽取
      </el-button>
    )
  }
];

const errorColumns: TableColumn<ExtractionErrorItem>[] = [
  { label: pt('错误 UID'), prop: 'errorUid', minWidth: 220, showOverflowTooltip: true },
  { label: pt('任务 UID'), prop: 'taskUid', minWidth: 160, showOverflowTooltip: true },
  { label: pt('字段键'), prop: 'fieldKey', width: 160, showOverflowTooltip: true },
  { label: pt('错误码'), prop: 'code', width: 140 },
  { label: pt('错误信息'), prop: 'message', minWidth: 220, showOverflowTooltip: true },
  {
    label: pt('状态'),
    width: 90,
    render: ({ row }) => (
      <el-tag type={row.resolved ? 'success' : 'danger'} size="small">
        {row.resolved ? pt('已纠正') : pt('待纠正')}
      </el-tag>
    )
  },
  { label: pt('创建时间'), prop: 'createdAt', width: 170 },
  {
    action: true,
    label: pt('操作'),
    width: 200,
    fixed: 'right',
    render: ({ row }) => (
      <div class="row-actions">
        <el-button link type="primary" onClick={() => void openErrorDetail(row)}>
          定位
        </el-button>
        <el-button link type="primary" disabled={row.resolved} onClick={() => void correctError(row)}>
          纠正
        </el-button>
        <el-button link type="danger" icon={CircleClose} disabled={!row.resolved} onClick={() => void deleteError(row)}>
          删除
        </el-button>
      </div>
    )
  }
];
</script>

<template>
  <div class="extract-page">
    <section class="extract-detail">
      <!-- 主按钮定位到 tab 栏右端（EP el-tabs 无 #extra 插槽，沿用数据入库页做法） -->
      <el-button class="extract-run-btn" type="primary" :icon="Plus" :loading="running" @click="openRunDialog">{{ pt('执行自动抽取') }}</el-button>
      <el-tabs v-model="activeTab" class="extract-tabs">
        <el-tab-pane :label="pt('抽取报告')" name="task">
          <div class="extract-pane">
            <div class="extract-stats">
              <el-tag size="small" type="info">入库批次 {{ statusText(overview.importCount ?? 0) }}</el-tag>
              <el-tag size="small" type="info">元数据行 {{ statusText(overview.metadataRowCount ?? 0) }}</el-tag>
              <el-tag size="small" type="warning"
                >错误 未处理 {{ statusText(errorStats.open ?? 0) }} / 共 {{ statusText(errorStats.total ?? 0) }}</el-tag
              >
              <span class="extract-stats__hint">{{ pt('四来源自动抽取：元数据文件 / 数据生产记录 / 数据库配置 / 入库记录') }}</span>
            </div>
            <Table
              ref="reportTableRef"
              class="extract-table"
              :columns="batchColumns"
              :request="getBatches"
              :query-params="reportQuery"
              row-key="importUid"
            >
              <template #search>
                <el-input v-model="reportQuery.keyword" :label="pt('关键词')" :placeholder="pt('批次 UID / 状态 / 来源')" clearable />
              </template>
              <template #empty><el-empty description="暂无抽取报告数据" :image-size="70" /></template>
            </Table>
          </div>
        </el-tab-pane>
        <el-tab-pane :label="'元数据错误表（' + errorTotal + '）'" name="error">
          <div class="extract-pane">
            <div class="extract-stats">
              <el-radio-group v-model="errorScope" size="small">
                <el-radio-button value="open">待纠正</el-radio-button>
                <el-radio-button value="resolved">已纠正</el-radio-button>
              </el-radio-group>
              <span class="extract-stats__hint">双击行可查看错误定位；纠正成功后可按需删除</span>
            </div>
            <Table
              ref="errorTableRef"
              class="extract-table"
              :columns="errorColumns"
              :request="getErrors"
              :query-params="errorQuery"
              row-key="errorUid"
              @row-dblclick="openErrorDetail"
            >
              <template #search>
                <el-input v-model="errorQuery.keyword" label="关键词" placeholder="错误 UID / 字段键 / 错误码" clearable />
              </template>
              <template #empty><el-empty description="暂无抽取错误记录" :image-size="70" /></template>
            </Table>
          </div>
        </el-tab-pane>
      </el-tabs>
    </section>
  </div>
</template>

<style scoped lang="scss">
/* 卡片化外壳，与数据入库页 .import-detail 保持同一视觉口径 */
.extract-page {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
  overflow: hidden;
  background: var(--el-bg-color);
}

.extract-detail {
  position: relative;
  display: flex;
  flex: 1;
  flex-direction: column;
  min-width: 0;
  min-height: 0;
  overflow: hidden;
  background: var(--el-bg-color);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 6px;
}

/* 主按钮绝对定位到 tab 栏右端（EP el-tabs 无 #extra 插槽） */
.extract-run-btn {
  position: absolute;
  z-index: 2;
  top: 4px;
  right: 14px;
}

.extract-tabs {
  flex: 1;
  min-height: 0;

  /* 右侧留出主按钮宽度，避免标签与按钮重叠 */
  :deep(.extract-tabs > .el-tabs__header) {
    margin: 0;
    padding: 0 140px 0 14px;
    border-bottom: 1px solid var(--el-border-color-lighter);
  }

  :deep(.extract-tabs .el-tabs__nav-wrap::after) {
    display: none;
  }

  :deep(.extract-tabs > .el-tabs__content) {
    flex: 1;
    min-height: 0;
    overflow: hidden;
  }

  :deep(.extract-tabs .el-tab-pane) {
    height: 100%;
  }
}

.extract-pane {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
}

.extract-stats {
  display: flex;
  flex: 0 0 auto;
  align-items: center;
  gap: 8px;
  padding: 10px 14px;
  border-bottom: 1px solid var(--el-border-color-lighter);

  &__hint {
    margin-left: auto;
    color: var(--el-text-color-secondary);
    font-size: 12px;
  }
}

.extract-table {
  flex: 1;
  min-height: 0;
}

/* JSX render 产出的 vnode 带 ElTable 自身 scopeId，须用 :deep() 由本组件 scope 锚定 */
:deep(.row-actions) {
  white-space: nowrap;
}
</style>
