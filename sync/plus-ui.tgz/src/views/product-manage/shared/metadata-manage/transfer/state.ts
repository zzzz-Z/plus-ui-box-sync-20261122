import { computed, ref } from 'vue';
import { getAllMetadataRecords, getModelTableOptions } from '@/api/product-manage/adapter/records';
import type { MetadataRecord } from '@/api/product-manage/types';

/**
 * 元数据导入导出共享状态
 *
 * 承载元数据记录、模型表选项与导入导出任务记录，并集中实现导出文件生成、
 * 下载与导入解析等业务逻辑，供 transfer/index.vue 容器与 export-dialog /
 * import-dialog 弹窗组件共同使用，避免兄弟组件互相引用。
 *
 * UI 反馈（ElMessage）由组件层负责，本模块只做数据与业务操作。
 */

export interface TableOption {
  modelUid: string;
  modelName: string;
  tableUid: string;
  tableName: string;
}

export interface JobRecord {
  id: number;
  name: string;
  type: '导入' | '导出';
  format: string;
  scope: string;
  result: string;
  createdAt: string;
}

/** 导出格式（标准分幅/各类初级产品元数据） */
export const EXPORT_FORMATS = ['CSV', 'TXT', 'XML（国标）', 'XML（J标）', 'XML（地质）', 'XML（海洋）', 'HTML'];
/** 导入格式（为数据目录交换共享提供元数据支持） */
export const IMPORT_FORMATS = ['国标 XML', 'J标 XML', '地质 XML', '海洋 XML', 'Excel(XLSX)', 'TXT'];

export const records = ref<MetadataRecord[]>([]);
export const tableOptions = ref<TableOption[]>([]);
export const jobs = ref<JobRecord[]>([
  {
    id: 1,
    name: '交通路网元数据导出（国标 XML）',
    type: '导出',
    format: '国标 XML',
    scope: 'traffic-structure',
    result: '成功 · 18 条',
    createdAt: '2026-09-08 10:20:00'
  }
]);

/** 导出范围下拉：全部元数据表 + 各模型表 */
export const scopeOptions = computed(() => [
  { label: '全部元数据表', value: 'all' },
  ...tableOptions.value.map((table) => ({ label: `${table.modelName} / ${table.tableName}`, value: table.tableUid }))
]);

/** 指定导出范围下的记录集合 */
export function getScopeRecords(scope: string) {
  return scope === 'all' ? records.value : records.value.filter((record) => record.tableUid === scope);
}

export async function loadData() {
  const [recordRes, tableRes] = await Promise.all([getAllMetadataRecords(), getModelTableOptions()]);
  records.value = recordRes?.data ?? [];
  tableOptions.value = tableRes?.data?.items ?? [];
}

function pushJob(job: Omit<JobRecord, 'id' | 'createdAt'>) {
  jobs.value.unshift({
    ...job,
    id: Date.now(),
    createdAt: new Date().toLocaleString('zh-CN', { hour12: false })
  });
}

// ---------------------------------------------------------------------------
// 导出
// ---------------------------------------------------------------------------

const EXPORT_HEADER = ['产品名称', '产品类别', '数据版本', '数据级别', '行政区划', '所属元数据表', '更新时间'];

function toTag(label: string) {
  return label.replace(/\s+/g, '');
}

function escapeXml(text: string) {
  return String(text).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
}

function buildPayload(scopeRecords: MetadataRecord[]) {
  const body = scopeRecords.map((record) => [
    record.name,
    record.category,
    record.version,
    record.dataLevel,
    record.region,
    record.tableName,
    record.updatedAt
  ]);
  return { header: EXPORT_HEADER, body };
}

function buildContent(format: string, header: string[], body: string[][]) {
  if (format.startsWith('XML')) {
    const spec = format.replace('XML（', '').replace('）', '');
    const content = `<?xml version="1.0" encoding="UTF-8"?>\n<metadataRecords format="${spec}">\n${body.map((row) => `  <record ${header.map((h, i) => `${toTag(h)}="${escapeXml(row[i])}"`).join(' ')} />`).join('\n')}\n</metadataRecords>`;
    return { content, ext: 'xml' };
  }
  if (format === 'HTML') {
    const content = `<meta charset="utf-8"><h3>元数据导出（${format}）</h3><table border="1" cellspacing="0" style="border-collapse:collapse">${header.map((h) => `<th>${h}</th>`).join('')}${body.map((row) => `<tr>${row.map((cell) => `<td>${cell}</td>`).join('')}</tr>`).join('')}</table>`;
    return { content, ext: 'html' };
  }
  const content = [header, ...body].map((row) => row.join(',')).join('\n');
  return { content, ext: 'csv' };
}

/**
 * 执行导出：生成文件内容、触发浏览器下载并写入任务记录。
 * 返回导出条数；范围为空时返回 null（组件层据此提示）。
 */
export function runExport(scope: string, format: string): number | null {
  const scopeRecords = getScopeRecords(scope);
  if (!scopeRecords.length) return null;

  const { header, body } = buildPayload(scopeRecords);
  const { content, ext } = buildContent(format, header, body);

  const url = URL.createObjectURL(new Blob([ext === 'csv' ? `\uFEFF${content}` : content], { type: 'text/plain;charset=utf-8' }));
  const link = document.createElement('a');
  link.href = url;
  link.download = `元数据导出-${Date.now()}.${ext}`;
  link.click();
  URL.revokeObjectURL(url);

  pushJob({
    name: `${scopeRecords[0]?.tableName ?? '元数据'} 导出`,
    type: '导出',
    format,
    scope,
    result: `成功 · ${scopeRecords.length} 条`
  });
  return scopeRecords.length;
}

// ---------------------------------------------------------------------------
// 导入
// ---------------------------------------------------------------------------

/**
 * 解析导入文件并写入任务记录（模拟）。
 * 读取失败时 reject，由组件层转换为失败提示。
 */
export function runImport(file: File, format: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      pushJob({
        name: file.name,
        type: '导入',
        format,
        scope: '导入校验',
        result: `模拟成功 · ${file.size || 0} B`
      });
      resolve();
    };
    reader.onerror = () => reject(new Error('文件读取失败'));
    reader.readAsText(file);
  });
}
