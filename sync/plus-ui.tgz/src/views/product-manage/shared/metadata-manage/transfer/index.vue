<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
import { Download, UploadFilled } from '@element-plus/icons-vue';
import ExportDialog from './export-dialog.vue';
import ImportDialog from './import-dialog.vue';
import type { JobRecord } from './state';
import { jobs, loadData } from './state';

function onExport() {
  createDialog({
    title: pt('批量导出元数据'),
    width: '640px',
    okText: pt('导出'),
    render: () => <ExportDialog />
  });
}

function onImport() {
  createDialog({
    title: pt('批量导入元数据'),
    width: '560px',
    okText: pt('导入'),
    render: () => <ImportDialog />
  });
}

const columns: TableColumn<JobRecord>[] = [
  { label: pt('任务名称'), prop: 'name', minWidth: 260, showOverflowTooltip: true },
  {
    label: pt('类型'),
    width: 90,
    render: ({ row }) => (
      <el-tag type={row.type === '导入' ? 'success' : 'primary'} size="small">
        {row.type}
      </el-tag>
    )
  },
  { label: pt('格式'), prop: 'format', width: 150 },
  { label: pt('结果'), prop: 'result', minWidth: 180 },
  { label: pt('时间'), prop: 'createdAt', width: 190 }
];

onMounted(loadData);
</script>

<template>
  <Table :columns="columns" :data="jobs">
    <template #action>
      <el-button type="primary" :icon="Download" @click="onExport"> {{ pt('导出元数据') }} </el-button>
      <el-button type="success" :icon="UploadFilled" @click="onImport"> {{ pt('导入元数据') }} </el-button>
    </template>
  </Table>
</template>

<style scoped lang="scss"></style>
