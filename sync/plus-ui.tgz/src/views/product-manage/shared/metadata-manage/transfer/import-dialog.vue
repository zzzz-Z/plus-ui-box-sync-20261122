<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
import { UploadFilled } from '@element-plus/icons-vue';
import { IMPORT_FORMATS, runImport } from './state';

const form = ref();
const model = reactive({ format: pt('国标 XML') });
const selectedFile = ref<File | null>(null);

function onChange(uploadFile: any) {
  selectedFile.value = (uploadFile?.raw ?? null) as File | null;
}

/** createDialog 提交回调：解析导入文件并返回统一响应（成功码 0） */
async function save() {
  if (!selectedFile.value) return { code: 1, message: pt('请先选择需要导入的元数据文件') };
  try {
    const file = selectedFile.value;
    await runImport(file, model.format);
    return { code: 0, message: `已导入「${file.name}」（${model.format}），元数据格式校验通过并写入（模拟）` };
  } catch {
    return { code: 1, message: pt('文件读取失败') };
  }
}

defineExpose({ save, form });
</script>

<template>
  <div class="import-dialog">
    <Form ref="form" :model="model" :span="24">
      <el-select v-model="model.format" :label="pt('导入格式')">
        <el-option v-for="format in IMPORT_FORMATS" :key="format" :label="format" :value="format" />
      </el-select>
    </Form>
    <el-upload drag :auto-upload="false" :limit="1" accept=".xml,.xlsx,.xls,.txt,.csv" :on-change="onChange">
      <el-icon class="el-icon--upload">
        <UploadFilled />
      </el-icon>
      <div class="el-upload__text">
        {{ pt('将文件拖到此处，或') }}<em>{{ pt('点击选择') }}</em>
      </div>
      <template #tip>
        <div class="el-upload__tip">
          {{ pt('支持国标/J标/地质/海洋 XML、Excel(XLSX)、TXT 元数据文件；接入真实接口后将按导入批次写入元数据表。') }}
        </div>
      </template>
    </el-upload>
  </div>
</template>

<style scoped lang="scss">
.import-dialog {
  :deep(.el-upload-dragger) {
    width: 100%;
  }
}
</style>
