<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
import { EXPORT_FORMATS, getScopeRecords, runExport, scopeOptions } from './state';

const form = ref();
const model = reactive({ scope: 'all', format: 'CSV' });

const count = computed(() => getScopeRecords(model.scope).length);

/** createDialog 提交回调：执行导出并返回统一响应（成功码 0） */
function save() {
  const exported = runExport(model.scope, model.format);
  if (exported === null) return { code: 1, message: pt('当前范围没有可导出的元数据') };
  return { code: 0, message: `已导出 ${model.format} 格式元数据（${exported} 条）` };
}

defineExpose({ save, form });
</script>

<template>
  <div class="export-dialog">
    <Form ref="form" :model="model" :span="24">
      <el-select v-model="model.scope" :label="pt('导出范围')">
        <el-option v-for="option in scopeOptions" :key="option.value" :label="option.label" :value="option.value" />
      </el-select>
      <el-radio-group v-model="model.format" :label="pt('导出格式')">
        <el-radio-button v-for="format in EXPORT_FORMATS" :key="format" :value="format">
          {{ format }}
        </el-radio-button>
      </el-radio-group>
    </Form>
    <div class="export-dialog__tip">
      {{ pt('当前范围可导出') }} <strong>{{ count }}</strong> {{ pt('条元数据记录，支持 CSV / TXT / 国标·J标·地质·海洋 XML / HTML 格式。') }}
    </div>
  </div>
</template>

<style scoped lang="scss">
.export-dialog__tip {
  margin-top: 4px;
  color: #8592a6;
  font-size: 12px;
  line-height: 1.6;

  strong {
    color: #2563a8;
    font-size: 14px;
  }
}
</style>
