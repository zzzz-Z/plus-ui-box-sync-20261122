<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
/**
 * 批量编辑 / 批量删除弹窗（createDialog 内容）
 *
 * 契约：`POST .../records/batch`（docId 531714898）
 *   - `operation` = `update` | `delete`
 *   - `metadataUids` 1—200 条
 *   - `update` 必带 `values`；`delete` 必带 `confirm: true`
 *   - `dryRun` 只预演不落库；`atomic` 全成全败（默认 true）
 *
 * ## WHY 这两个功能合并到一个弹窗
 * 契约里 update 与 delete 是**同一个端点**的两种 operation，载荷只差 `values` / `confirm`。
 * 拆成两个弹窗会各写一份载荷（正是 SKILL 铁律 2 禁止的形态），合并后走同一处 `buildRecordBatchPayload()`。
 *
 * ## 替代了什么
 * 本文件取代已删除的 `batch-edit-dialog.vue`：旧版只对内存数组 `Object.assign`，
 * 用户看到「批量修改 N 条」提示但**零写请求**，刷新即丢失。现在全部走真实接口。
 */
import { WarningFilled } from '@element-plus/icons-vue';
import {
  batchEditMetadataRecords,
  getEditSchema,
  METADATA_BATCH_MAX,
  withEditLock,
  isMetadataPermissionDenied
} from '@/api/product-manage/platform/metadata-records';
import type { MetadataEditField } from '@/api/product-manage/types/platform';
import type { MetadataAttributeColumn, MetadataAttributeRecord } from '@/api/product-manage/platform/metadata-attributes';

defineOptions({ name: 'AttributeBatchDialog' });

const props = defineProps<{
  /** 本次要批处理的记录（来自表格勾选） */
  rows: MetadataAttributeRecord[];
  resourceUid: string;
  tableKey: string;
  /** 列清单 / 字段定义：决定哪些字段可批量统一赋值 */
  columns?: MetadataAttributeColumn[];
  onSaved?: () => void;
}>();

/** 批量编辑字段清单（取自 edit-schema，缺 schema 时退回列清单） */
const fields = ref<MetadataEditField[]>([]);
const form = reactive({
  /** 操作类型 */
  operation: 'update' as 'update' | 'delete',
  /** 统一赋值的字段键（update 时必填） */
  key: '',
  /** 新值 */
  value: '',
  /** 是否只预演 */
  dryRun: false
});
const saving = ref(false);
/** schema 加载失败说明：允许删除（不依赖 schema），但阻断批量更新 */
const schemaError = ref('');

/** 勾选记录的 metadataUid（契约 metadataUids） */
const metadataUids = computed(() => props.rows.map((r) => String(r?.values?.metadata_uid ?? '')).filter(Boolean));

/** 勾选记录的 rowVersion（契约 expectedRowVersions，键=metadataUid） */
const expectedRowVersions = computed(() => {
  const out: Record<string, number> = {};
  for (const r of props.rows) {
    const uid = String(r?.values?.metadata_uid ?? '');
    const raw: any = r?.values?.row_version ?? r?.values?.rowVersion;
    const n = Number(raw);
    if (uid && Number.isFinite(n)) out[uid] = n;
  }
  return out;
});

/** 可批量赋值的字段：writable !== false、非只读 */
const editableFields = computed(() => fields.value.filter((f) => f && f.fieldKey && f.writable !== false && !f.readOnly));

/** 下拉选项：schema 字段（优先中文名） */
const fieldOptions = computed(() => editableFields.value.map((f) => ({ label: f.label || f.fieldKey, value: f.fieldKey })));

const activeField = computed(() => editableFields.value.find((f) => f.fieldKey === form.key));
const activeLabel = computed(() => activeField.value?.label || form.key || '新值');

/** 切换目标字段时清空上一个字段的新值，防止误用残留值提交（旧版同样的纪律） */
watch(
  () => form.key,
  () => {
    form.value = '';
  }
);

/** 脏数据前置校验：Uid 缺失 / 条数超限 / 无版本，都在提交前说清楚 */
const precheck = computed(() => {
  if (!metadataUids.value.length) return pt('勾选的记录缺少 metadata_uid，无法批量操作（请刷新列表后重试）');
  if (metadataUids.value.length > METADATA_BATCH_MAX) return `单次最多 ${METADATA_BATCH_MAX} 条，当前 ${metadataUids.value.length} 条`;
  if (form.operation === 'update' && !Object.keys(expectedRowVersions.value).length) return pt('勾选记录均缺少 row_version，无法做并发校验');
  return '';
});

async function loadSchema() {
  try {
    const res = await getEditSchema(props.resourceUid, props.tableKey);
    fields.value = res?.data?.fields ?? [];
    if (!fields.value.length) schemaError.value = '该表未返回可编辑字段定义，批量更新不可用（仍可批量删除）';
  } catch (e: any) {
    fields.value = [];
    schemaError.value = isMetadataPermissionDenied(e)
      ? pt('缺少 metadata.edit 权限，批量更新不可用（删除同样会受权限门限制）')
      : `字段定义加载失败：${e?.message ?? '接口异常'}`;
  }
}

function validate() {
  if (precheck.value) throw new Error(precheck.value);
  if (form.operation === 'update') {
    if (!form.key) throw new Error(pt('请选择要批量修改的字段'));
    const val = form.value;
    if (val === undefined || val === null || val === '') throw new Error(`请录入「${activeLabel.value}」的新值`);
    const f = activeField.value;
    if (f?.required && !String(val).trim()) throw new Error(`「${activeLabel.value}」为必填字段，不能清空`);
  }
  return true;
}

/**
 * 提交：拿锁（records 模式，锁目标=全部勾选记录）→ batch → 自动放锁。
 *
 * WHY records 模式而不是 table：批量操作只针对勾选的这几条，
 * 用整表锁会把同表其他用户的编辑一起挡住，粒度没必要这么大。
 */
async function save() {
  const uids = metadataUids.value;
  if (!uids.length) return { code: 1, message: pt('勾选的记录缺少 metadata_uid，无法批量操作') };

  saving.value = true;
  try {
    const res = await withEditLock(props.resourceUid, props.tableKey, { mode: 'records', metadataUids: uids }, async (lock) => {
      if (form.operation === 'delete') {
        return batchEditMetadataRecords(props.resourceUid, props.tableKey, {
          operation: 'delete',
          metadataUids: uids,
          lockToken: lock.lockToken,
          confirm: true,
          requestId: `batch-del-${Date.now()}`
        });
      }
      return batchEditMetadataRecords(props.resourceUid, props.tableKey, {
        operation: 'update',
        metadataUids: uids,
        lockToken: lock.lockToken,
        values: { [form.key]: String(form.value) },
        expectedRowVersions: expectedRowVersions.value,
        dryRun: form.dryRun,
        requestId: `batch-upd-${Date.now()}`
      });
    });

    // 预演路径不落库，刷新没有意义且会误导
    if (form.operation === 'update' && form.dryRun) {
      const okCount = res?.data?.affected ?? res?.data?.updated ?? 0;
      const failed = res?.data?.failed ?? 0;
      const issues = (res?.data?.issues ?? [])
        .slice(0, 3)
        .map((i) => i.message)
        .filter(Boolean);
      return {
        code: 0,
        message: failed
          ? `预演：${okCount} 条可改、${failed} 条有问题${issues.length ? '（' + issues.join('；') + '）' : ''}`
          : `预演通过：${okCount} 条可改`
      };
    }

    props.onSaved?.();
    if (form.operation === 'delete') {
      const deleted = res?.data?.deleted;
      // 契约：单条 boolean / 批量 number —— 只能判「非 falsy」，不能比数字
      const n = typeof deleted === 'number' ? deleted : deleted ? uids.length : 0;
      return { code: 0, message: `已删除 ${n} 条记录` };
    }
    const updated = res?.data?.updated ?? res?.data?.affected ?? uids.length;
    const failed = res?.data?.failed ?? 0;
    return { code: 0, message: failed ? `已修改 ${updated} 条，${failed} 条失败` : `已批量修改 ${updated} 条的「${activeLabel.value}」` };
  } catch (e: any) {
    if (isMetadataPermissionDenied(e)) return { code: 1, message: pt('缺少 metadata.edit 权限，请联系管理员开通后再试') };
    return { code: 1, message: String(e?.message || '批量操作失败') };
  } finally {
    saving.value = false;
  }
}

onMounted(loadSchema);

defineExpose({ save, validate, form });
</script>

<template>
  <div class="attr-batch">
    <el-alert v-if="precheck" type="warning" :closable="false" show-icon :title="precheck" class="attr-batch__alert" />
    <el-alert
      v-else-if="schemaError && form.operation === 'update'"
      type="warning"
      :closable="false"
      show-icon
      :title="schemaError"
      class="attr-batch__alert"
    />

    <el-form label-width="110px" class="attr-batch__form">
      <el-form-item :label="pt('操作类型')" required>
        <el-radio-group v-model="form.operation" :disabled="saving">
          <el-radio-button label="update">{{ pt('批量修改字段') }}</el-radio-button>
          <el-radio-button label="delete">{{ pt('批量删除') }}</el-radio-button>
        </el-radio-group>
      </el-form-item>

      <template v-if="form.operation === 'update'">
        <el-form-item :label="pt('目标字段')" required>
          <el-select v-model="form.key" clearable filterable :disabled="saving || !fieldOptions.length" :placeholder="pt('请选择要批量修改的字段')">
            <el-option v-for="opt in fieldOptions" :key="opt.value" :label="opt.label" :value="opt.value" />
          </el-select>
        </el-form-item>

        <el-form-item :label="activeLabel" :required="!!activeField?.required">
          <el-select v-if="activeField?.options && activeField.options.length" v-model="form.value" clearable :disabled="saving">
            <el-option v-for="opt in activeField.options" :key="opt.value" :label="opt.label || opt.value" :value="opt.value" />
          </el-select>
          <el-input
            v-else
            v-model="form.value"
            :disabled="saving || !form.key"
            :placeholder="form.key ? `请输入「${activeLabel}」的新值` : '请先选择目标字段'"
          />
        </el-form-item>

        <el-form-item :label="pt('只预演')">
          <el-switch v-model="form.dryRun" :disabled="saving" />
          <span class="attr-batch__hint">{{ pt('开启后只校验并返回可改条数，不写数据库') }}</span>
        </el-form-item>
      </template>

      <template v-else>
        <el-form-item label="删除确认">
          <div class="attr-batch__danger">
            <el-icon class="attr-batch__danger-ic"><WarningFilled /></el-icon>
            <span
              >将删除已勾选的 <b>{{ rows.length }}</b> 条记录；删除后记录不再出现在列表，变更历史仍保留</span
            >
          </div>
        </el-form-item>
      </template>
    </el-form>

    <el-alert
      type="info"
      :closable="false"
      show-icon
      :title="`本次作用于已勾选的 ${rows.length} 条记录${form.operation === 'update' ? '，仅修改所选字段' : '（不可撤销，请确认后提交）'}`"
    />
  </div>
</template>

<style scoped lang="scss">
.attr-batch__alert {
  margin-bottom: 12px;
}

.attr-batch__form {
  :deep(.el-form-item) {
    margin-bottom: 16px;
  }
}

.attr-batch__hint {
  margin-left: 10px;
  color: var(--el-text-color-secondary);
  font-size: 12px;
}

.attr-batch__danger {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  color: var(--el-color-danger);
  font-size: 13px;
  line-height: 1.7;
}

.attr-batch__danger-ic {
  flex: 0 0 auto;
  margin-top: 3px;
}
</style>
