<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
/**
 * 资源属性表（元数据浏览 / 元数据查询右侧「详情列表」）
 *
 * 数据源：GET /platform/resources/{resourceUid}/metadata-attributes
 * 交互契约（用户 2026-11-03 确认）：
 *   1. 表格铺开**全部字段**，横向滚动；表头「列设置」可控制显隐；
 *   2. 点行 → 地图定位到该条记录对应的图层范围并高亮（系统蓝实线 + 白色垫边，见 selection-style）；
 *      默认单选（再点别的行即替换），Ctrl/Cmd+左键 = 加选/取消该行的多选；
 *      多选时镜头贴合所有已选范围的并集；非编辑态同时打开右侧抽屉看全字段。
 *   3. 行末「详情」按钮 → 右侧抽屉看全部字段（两列描述列表，不遮挡列表与地图）。
 *   4. 一个资源可有多张元数据表 → 用 el-tabs 分表展示。
 *   5. 入参是**资源集合**：交付方（元数据浏览）传的是树上勾选的整批资源，
 *      tabs = 这批资源的全部元数据表（每 tab 一个资源的一张表），
 *      这样「勾选哪些资源」与「能看哪些表」是同一口径，不需要再回树里二次确认。
 *
 * WHY 不用项目通用 Table 组件：
 *   Table 的 request 契约要求返回 `data.items`，且 params 恒带 `pageNum`；
 *   本接口返回 `records` + `total`，分页字段是 `page`。两边字段全对不上，
 *   用 requestCfg 只能改读取端、改不了发送端的 pageNum，得再包一层适配函数，
 *   反而比直接用 el-table 更难读。属性表列是运行时决定的，也用不上列设置。
 */

import { Check, Clock, Delete, EditPen, Plus, Setting, View } from '@element-plus/icons-vue';
import type { TableInstance } from 'element-plus';
import {
  listAttributeTables,
  listResourceAttributes,
  resolveAttributeColumns,
  orderAttributeColumns,
  localizeFieldLabel,
  METADATA_ATTR_PAGE_SIZE_MAX,
  type AttributeTableOption,
  type MetadataAttributeColumn,
  type MetadataAttributeRecord
} from '@/api/product-manage/platform/metadata-attributes';
import type { Directive } from 'vue';
import type { MetadataEditField } from '@/api/product-manage/types/platform';
import {
  deleteMetadataRecord,
  getEditSchema,
  isMetadataPermissionDenied,
  normalizeFieldValues,
  updateMetadataRecord,
  withEditLock
} from '@/api/product-manage/platform/metadata-records';
import { useMap } from '@/views/product-manage/shared/map/use-map';
import { MAP_SELECTION } from '@/components/product-manage/geo-map/selection-style';
import { geometryBounds, mergeBounds, spatialRangeToGeometry, type Bounds4 } from '@/views/product-manage/shared/map/spatial-range';
import { featureSelection, matchRecord, type FeatureSelection } from '@/views/product-manage/shared/map/feature-selection';
import AttributeRowDialog from '@/views/product-manage/shared/attribute-row-dialog.vue';
import { paneRightAnchor } from '@/views/product-manage/shared/detail-drawer-anchor';
import { closeRecordDetail, showRecordDetail } from '@/views/product-manage/shared/record-detail-host';
import AttributeHistoryDialog from './attribute-history-dialog.vue';
import AttributeCreateDialog from './attribute-create-dialog.vue';
import AttributeBatchDialog from './attribute-batch-dialog.vue';

defineOptions({ name: 'ResourceAttributeTable' });

/**
 * resourceUids：要展示的资源集合（元数据浏览页传的就是树上勾选的那批资源）。
 *
 * WHY 用集合而不是单个 uid：用户的口径是「勾选哪些资源，就把它们的表都列出来」，
 * 勾选与「能看哪些表」必须是同一份数据；只传一个 uid 时会退化成「点谁看谁」，
 * 勾了三个资源却只看到最后一个的表，勾选这个动作在右栏就没有回馈了。
 *
 * resourceNames：uid → 资源中文名，用于多资源时给页签加前缀。
 * WHY 需要：不同资源常有同名表（如都叫「要素属性表」），只显示表名分不清是哪批数据；
 * 单资源场景不加前缀（前缀与自己名字重复，纯噪音）。
 */
const props = withDefaults(
  defineProps<{ resourceUids: string[]; resourceNames?: Record<string, string>; resourceColors?: Record<string, string> }>(),
  { resourceNames: () => ({}), resourceColors: () => ({}) }
);

/**
 * 本组件实例：传给 createDrawer 当 owner，让抽屉随本组件卸载一起销毁。
 * WHY 必须在 setup 顶层取：openDetail 是事件回调，那时 getCurrentInstance() 为 null。
 */
const owner = getCurrentInstance();

/**
 * 本表打开记录详情时拿到的宿主令牌：卸载时据此收起自己打开的那份，
 * 不会误关随后由地图等其它入口打开的详情（令牌校验在 closeRecordDetail 里做）。
 */
let detailToken: symbol | null = null;

/* ---------------------------- 行内编辑（元数据编辑功能） ---------------------------- */
/**
 * 交互契约（用户 2026-11-06 确认，依据《数据管理产品文档》3.7.7.5 / 3.7.8.5「元数据编辑功能」）：
 *   1. 工具栏「编辑」按钮 → 先取 edit-schema（metadata.edit 权限门）→ 进入编辑模式、按钮转「保存」；
 *   2. 编辑模式下**单击单元格** → 该格变成输入框（按字段类型给下拉/数值框/长文本等快捷方式）；
 *   3. 改动只落在独立的 editBuffer，不碰 records（否则 rowKeyOf 的 values-hash 会变、el-table 复用错行）；
 *   4. 点「保存」一次性把所有改动行按「一次租约 + 逐行 updateMetadataRecord」提交（事务模式），
 *      保存成功刷新当前页；字段校验依据 schema 的 required / maxLength / pattern / minimum / maximum / options。
 */

/** schema 中被视作「数值」的字段类型：这类单元格用 el-input-number 快捷输入 */
const NUMERIC_VALUE_TYPES = new Set(['integer', 'number', 'decimal', 'double', 'float', 'numeric', 'int', 'long', 'bigint']);
/** 单元格原始值：'-'（cellText 的空值占位）在编辑时等价于空串 */
const EMPTY_CELL = '-';

/** 是否处于整表编辑模式 */
const isEditing = ref(false);
/** 编辑字段定义（edit-schema）：字段类型 / 约束 / 枚举 / 可写性的唯一真相来源 */
const editFields = ref<MetadataEditField[]>([]);
/** 可编辑字段 key 集合（writable !== false 且非 readOnly），只读单元格单击不进入编辑 */
const editableKeySet = computed(
  () => new Set(editFields.value.filter((f) => f && f.fieldKey && f.writable !== false && !f.readOnly).map((f) => f.fieldKey))
);
/** fieldKey → 字段定义 */
const fieldByKey = computed(() => {
  const map: Record<string, MetadataEditField> = {};
  for (const f of editFields.value) if (f?.fieldKey) map[f.fieldKey] = f;
  return map;
});
/**
 * 编辑缓存：metadataUid → (fieldKey → 字符串值)。
 * WHY 独立于 records：records 里的 values 参与 rowKeyOf 的 hash，一旦原地改值，
 * el-table 会认为换了一批行，复用错行、选中/定位全丢；只有保存成功后 loadData() 才刷新真值。
 */
const editBuffer = reactive<Record<string, Record<string, string>>>({});
/** 当前正在输入（单元格已变输入框）的坐标：`${uid}::${fieldKey}` */
const editingCell = ref('');
/** 改动过的单元格坐标集合：用于黄色高亮 + 保存时只收集 diff */
const dirtyCells = ref<Set<string>>(new Set());
const saving = ref(false);
/** 进入编辑模式时 schema 不可用（权限 / 40404 / 网络）的说明 */
const schemaError = ref('');

/** 单元格坐标：行身份用 metadata_uid（跨翻页稳定），列身份用 fieldKey */
function cellId(uid: string, fieldKey: string): string {
  return `${uid}::${fieldKey}`;
}
/** 从行对象取记录身份（属性表接口把身份放在 values 里，见文件头说明） */
function recordUid(row: MetadataAttributeRecord): string {
  return String((row?.values?.metadata_uid as any) ?? '');
}
/** 从行对象取乐观并发版本 */
function recordVersion(row: MetadataAttributeRecord): number | null {
  const raw = (row?.values?.row_version as any) ?? (row?.values?.rowVersion as any);
  const n = Number(raw);
  return Number.isFinite(n) ? n : null;
}
/** 单元格当前显示值：优先编辑缓存，否则回落后端值（空值统一显示为 '-'） */
function cellValue(row: MetadataAttributeRecord, fieldKey: string): string {
  const uid = recordUid(row);
  const buf = editBuffer[uid];
  if (buf && Object.prototype.hasOwnProperty.call(buf, fieldKey)) return buf[fieldKey];
  const raw = row?.values?.[fieldKey];
  if (raw == null || raw === '') return '';
  return typeof raw === 'object' ? cellText(row, fieldKey) : String(raw);
}
/** 文本态显示值：编辑缓存优先（改完立刻看到新值），空值给 '-' 占位 */
function displayCellText(row: MetadataAttributeRecord, fieldKey: string): string {
  const v = cellValue(row, fieldKey);
  return v === '' ? EMPTY_CELL : v;
}
/** 字段中文名：schema.label → 列中文名 → 原始 key */
function fieldLabel(fieldKey: string): string {
  return fieldByKey.value[fieldKey]?.label || localizeFieldLabel(fieldKey) || fieldKey;
}
/** 字段是否数值型 */
function isNumericField(fieldKey: string): boolean {
  return NUMERIC_VALUE_TYPES.has(String(fieldByKey.value[fieldKey]?.valueType ?? '').toLowerCase());
}
/** 字段是否长文本（用 textarea 而非单行框） */
function isLongTextField(fieldKey: string): boolean {
  const widget = String(fieldByKey.value[fieldKey]?.widget ?? '').toLowerCase();
  const type = String(fieldByKey.value[fieldKey]?.valueType ?? '').toLowerCase();
  return widget.includes('textarea') || type === 'text' || type === 'json' || (fieldByKey.value[fieldKey]?.maxLength ?? 0) > 255;
}
/** 字段枚举选项（下拉快捷输入） */
function fieldOptions(fieldKey: string): Array<{ value: string; label: string }> {
  return fieldByKey.value[fieldKey]?.options ?? [];
}

/**
 * el-table 的 @cell-click 适配：数据列的 prop 是 `values.${fieldKey}`，
 * 从这里反解出 fieldKey 再交给行内编辑逻辑。选择列 / 序号列 / 操作列没有 property，
 * 反解为空串直接忽略，不会被误当成可编辑字段。
 *
 * WHY 用 cell-click 而非 cell-dblclick：双击要先等一次单击落定，手感上「点了没反应」；
 * 且单击进入编辑后 row-click 会同步触发，故 onRowClick 里用 isEditing 守卫挡住地图定位与详情抽屉。
 * 单击进入编辑后，行点击的地图定位 / 开详情都由 onRowClick 里的 isEditing 守卫挡掉，互不干扰。
 */
function onCellClickEvent(row: MetadataAttributeRecord, column: any) {
  const prop = String(column?.property ?? '');
  const fieldKey = prop.startsWith('values.') ? prop.slice('values.'.length) : prop;
  if (fieldKey) onCellClick(row, fieldKey);
}

/** 给「已改动」单元格挂高亮 class（cell-class-name 回调） */
function cellClassName({ row, column }: { row: MetadataAttributeRecord; column: any }): string {
  const prop = String(column?.property ?? '');
  const fieldKey = prop.startsWith('values.') ? prop.slice('values.'.length) : prop;
  return fieldKey && isCellDirty(row, fieldKey) ? 'is-dirty-cell' : '';
}

/** 输入框出现即自动聚焦：单击后立刻能打字，不用再点一下 */
const vFocus: Directive<HTMLElement> = {
  mounted(el) {
    const target = el.querySelector('input, textarea') as HTMLElement | null;
    (target ?? el).focus();
  }
};

const map = useMap();

/* ---------------------------- 高亮图层常量 ---------------------------- */
/**
 * 行高亮图层 id。
 *
 * WHY 不用 useMap 的 createLayerGroup：那套组件的配色/透明度由 palette + selectedIds 决定
 * （选中态填充不透明度 0.85），拿来做「框选一条记录」会把底图糊住；
 * 这里只要一个固定样式的虚线框，直接建 source/layer 更可控，且 id 前缀独立不与业务图层冲突。
 */
const HL_SRC = 'attr-row-hl-src';
const HL_FILL = 'attr-row-hl-fill';
const HL_HALO = 'attr-row-hl-halo';
const HL_LINE = 'attr-row-hl-line';
const HL_CIRCLE = 'attr-row-hl-circle';

/** 高亮线/填充/点颜色：优先取要素自身类别色，缺失时回退系统色（含非要素兜底场景） */
const HL_COLOR = ['coalesce', ['get', 'hlColor'], MAP_SELECTION.color] as any;

/**
 * 一个页签 = 某个资源的一张元数据表。
 *
 * WHY key 里带 resourceUid：`tableKey` 只在单个资源内唯一，两个资源都可能有
 * `flys_sx`（同名英文账本键），只用 tableKey 当页签名会撞车（el-tabs 的 name 冲突 → 点谁都是第一个）。
 * 拼成 `${resourceUid}::${tableKey}` 后既唯一，也能从 key 里反解出该拉哪个资源的接口。
 */
interface AttrTab {
  key: string;
  resourceUid: string;
  tableKey: string;
  label: string;
}

/**
 * 页签清单：勾选资源的全部元数据表，按「资源顺序 → 表顺序」展平。
 *
 * WHY 一次汇总所有资源的表：用户要的是「勾选的这批资源有哪些表」，
 * 切页签时再按需拉清单会先显示空 tabs 再弹出内容，而且切回上一个页签还要再拉一次。
 */
const tabs = ref<AttrTab[]>([]);
/** 当前激活页签的 key（`${resourceUid}::${tableKey}`）；空串表示这批资源还没有任何表 */
const activeTabKey = ref('');

/** 当前页签对应的资源 uid（拉属性时用；没有页签时为空，loadData 直接空态） */
const activeResourceUid = computed(() => tabs.value.find((t) => t.key === activeTabKey.value)?.resourceUid ?? '');
/** 当前页签对应的表键（为空表示不限表 —— 后端会混合返回该资源的全部表，仅作兜底） */
const activeTableKey = computed(() => tabs.value.find((t) => t.key === activeTabKey.value)?.tableKey ?? '');

/**
 * 当前页签所属资源的类别色（高亮用要素自身颜色）。
 * WHY 由父组件传入：父级已有 uid→categoryName→palette 的同一份口径，这里重算会漂移；
 * 取不到时高亮层回退 MAP_SELECTION.color。
 */
const activeColor = computed(() => props.resourceColors[activeResourceUid.value] || MAP_SELECTION.color);

/**
 * 全量记录（不分页：一次拉到契约上限，用户去掉了分页控件）。
 * WHY 用 MAX 而不是 DEFAULT：没有翻页出口后若只拉默认 50 条，多余记录既看不到也翻不到，
 * 会变成静默丢数据；接口单页上限 200，取上限一次拉全，表格内部纵向滚动即可看全。
 */
const records = ref<MetadataAttributeRecord[]>([]);
/** 后端返回的列（列名 + 中文标签），顺序即展示顺序 */
const columns = ref<MetadataAttributeColumn[]>([]);
const total = ref(0);

const loading = ref(false);
/**
 * 表清单汇总（init 阶段）的请求中标记：勾一个类别带十几个资源时这一阶段最耗时，
 * 原先没有任何反馈，用户会以为勾选「卡住了」。
 */
const initLoading = ref(false);
/** 资源确实没有元数据表（业务码 40404）时的空态文案开关 */
const noTable = ref(false);

/** 表格实例：列表行滚动定位（地图点图斑 → 滚到对应行）用 */
const tableRef = ref<TableInstance>();

/**
 * 详情抽屉的纵向锚点：右侧整列（上半地图 / 下半列表）。
 *
 * WHY 不锚表格本身：抽屉要「从地图顶部贯穿到页面底部」（用户 2026-11-10 确认），
 * 锚表格只能盖住下半区，上半截地图旁边还是空的；`.pane-right` 的矩形恰好是
 * 地图上沿 → 列表底沿，一次对齐就覆盖整列。解析细节见 detail-drawer-anchor.ts。
 *
 * WHY 传函数不缓存元素：布局里的 h-split / v-split 会实时改高度，元素不换、尺寸会变，
 * createDrawer 每次重新对齐都会再调一次这个函数。
 */
const drawerAnchor = () => paneRightAnchor(tableRef.value?.$el as HTMLElement | undefined);

/**
 * 空态文案：区分「这批勾选资源一张表都没有」与「某个资源没有表」。
 * WHY 要分：勾了 5 个资源却一个表都没有，说「该资源暂无元数据表」会让人以为只是当前这个资源没表、
 * 勾选动作没生效；直接把口径说成「勾选的资源都没有元数据表」才对得上用户刚做的操作。
 */
const emptyText = computed(() => (props.resourceUids.length > 1 ? pt('勾选的资源都没有元数据表') : pt('该资源暂无元数据表')));

/** 列设置面板里被勾选的列（默认全选 = 铺开全部字段） */
const shownKeys = ref<string[]>([]);

/**
 * 已「定位」到地图的行。
 *
 * 口径（用户 2026-11-04 确认）：默认**单选**——普通左键点行即替换成这一行；
 * Ctrl / Cmd + 左键 = 多选，再点已选行则取消它的定位。
 * CONSTRAINT 存 rowKey + 要素 + 范围，不存行对象引用：翻页后 `records` 是全新对象，
 * 拿旧引用比对不上，选中态会莫名其妙丢失；而第 1 页选中的行翻到第 2 页仍应保持高亮，
 * 所以要素必须自带（不能回头去 `records` 里反查）。
 */
interface LocatedRow {
  key: string;
  feature: any;
  bounds: Bounds4;
}
/**
 * 已定位行的容器用 shallowRef：
 * WHY 不用 ref —— ref 会把 feature 的 GeoJSON 坐标数组做深度响应式代理，
 * maplibre 读取时全部走 Proxy（几万条坐标就是几万次数组拦截），纯亏无益。
 * 这里只整体替换数组，不需要逐元素深层响应。
 */
const locatedRows = shallowRef<LocatedRow[]>([]);
/** rowKey 集合：行样式用（模板里逐行判定，避免每次 O(n) includes） */
const locatedKeySet = computed(() => new Set(locatedRows.value.map((r) => r.key)));

/**
 * 用户是否手动改过列显隐。
 * WHY 要记：切表（tab）/ 切资源后列集合会变，未手动改过时自动全选最符合预期；
 * 一旦用户自己勾掉过某列，再全选就等于覆盖他的选择。
 */
let columnTouched = false;

/**
 * 表格的完整列集合：后端列（有中文名）+ 行内出现但后端没列出的键（系统字段）。
 *
 * WHY 补行内键：`fieldLabels` 只覆盖业务字段，created_at / metadata_uid 这类系统字段
 * 只存在于 `values` 里；用户要求「显示所有字段」，这些也要能看能勾。
 *
 * WHY 用 localizeFieldLabel：这些键没有后端中文名，直接拿列名当表头就会出现英文表头。
 * 内置映射查得到就显示中文名，查不到的纯英文键**不补列**（表头不许有英文）；
 * 后端一列都没给时退回首行键，保证不是空表——空表比英文表头更糟。
 */
const allColumns = computed<MetadataAttributeColumn[]>(() => {
  const known = new Set(columns.value.map((c) => c.key));
  // 已有列的展示名也算「已知」：行内再冒出同名键（如中文列名对应的英文键）就是重复列
  const knownLabels = new Set(columns.value.map((c) => c.label));
  const extra: MetadataAttributeColumn[] = [];
  for (const row of records.value) {
    for (const key of Object.keys(row?.values ?? {})) {
      if (known.has(key) || knownLabels.has(key)) continue;
      known.add(key);
      const label = localizeFieldLabel(key);
      knownLabels.add(label || key);
      // 查不到中文名的英文键不补列：宁可少一列，也不让英文表头出现
      if (!label) continue;
      extra.push({ key, label });
    }
  }
  const merged = [...columns.value, ...extra];
  if (merged.length) return merged;
  // 后端一列都没给（只返回 fields 或空响应）时兜底用首行键，保证不是空表
  const first = records.value[0]?.values ?? {};
  return Object.keys(first).map((key) => ({ key, label: localizeFieldLabel(key) || key }));
});

/** 展示顺序：重要字段优先，其余保持后端 / 行内原序（与详情共用 orderAttributeColumns） */
const orderedColumns = computed<MetadataAttributeColumn[]>(() => orderAttributeColumns(allColumns.value));

/** 实际渲染的列（按展示顺序过滤掉被隐藏的） */
const displayColumns = computed<MetadataAttributeColumn[]>(() => orderedColumns.value.filter((c) => shownKeys.value.includes(c.key)));

/**
 * 列最小宽度（按表头文字估算）。
 *
 * WHY 不能固定 140：后端给的中文标签有长有短，「要素（图斑）个数统计」（实测文字宽 130px）、
 * 「影像色彩模式/波段」（111px）在 140px 列里只余 ~116px 内容宽 —— 装不下就折行，
 * 表头被撑成两行。这里按字数给宽度，配合表头 nowrap，保证单行显示；
 * 短标签（「数据格式」）也不会被拉成 140px 的空宽列。
 */
const COLMIN_FALLBACK = 120;
/** 单元格左右内边距（EP 默认 12+12）+ 留白余量 */
const COL_PADDING = 30;
/** 单字估算宽度：表头是 13px 字重 600，实测汉字约 13px，取 14 留出余量 */
const COL_CHAR_WIDTH = 14;

function columnMinWidth(label: string): number {
  const text = String(label ?? '');
  if (!text) return COLMIN_FALLBACK;
  // 半角字符（括号/斜杠/字母）按 0.6 个汉字宽估算，避免中文标签估得过宽
  let units = 0;
  for (const ch of text) units += /[\x00-\xff]/.test(ch) ? 0.6 : 1;
  return Math.max(COLMIN_FALLBACK, Math.ceil(units * COL_CHAR_WIDTH + COL_PADDING));
}

/**
 * 行唯一键。
 * 属性记录没有稳定主键（不同表主键列名不同），用「账本表键 + 物理表名 + 行内容哈希」拼一个：
 * 同一页里重复数据行也能区分，且翻页/筛选后同一行仍得到同一个 key（el-table 的 row-key 需要）。
 */
function rowKeyOf(row: MetadataAttributeRecord): string {
  let raw = '';
  try {
    raw = JSON.stringify(row?.values ?? {});
  } catch {
    raw = String(row?.values);
  }
  let h = 0;
  for (let i = 0; i < raw.length; i++) h = (h * 31 + raw.charCodeAt(i)) | 0;
  return `${row?.tableKey || ''}|${row?.pgTable || ''}|${h}`;
}

/**
 * 行样式：已定位的行加 `is-located`。
 *
 * WHY 不用 el-table 的 `highlight-current-row`：那是「当前单行」语义，
 * Ctrl 多选时第二行一点就把第一行的选中态顶掉了，用户看不出自己到底选了哪几条。
 * 自己按 rowKey 集合给 class，选中态与 el-table 的内部状态解耦，翻页也保得住。
 */
function rowClassName({ row }: { row: MetadataAttributeRecord }) {
  return locatedKeySet.value.has(rowKeyOf(row)) ? 'is-located' : '';
}

/** 单元格取值：后端 value 可能是对象/数组，直接渲染成 [object Object]，故统一字符串化 */
function cellText(row: MetadataAttributeRecord, field: string): string {
  const v = row?.values?.[field];
  if (v == null || v === '') return '-';
  if (typeof v === 'object') {
    try {
      return JSON.stringify(v);
    } catch {
      return String(v);
    }
  }
  return String(v);
}

/* ---------------------------- 数据加载 ---------------------------- */

/**
 * 按「资源节点」缓存：勾选集合变化时组件实例不重建（index.vue 刻意不加 :key），
 * 这两个 Map 随组件常驻，第一次勾选拉到的数据就挂在对应资源 uid 下，
 * 之后取消/再勾选、切页签、翻页都优先读缓存，不再重复打接口。
 */
const tablesCache = new Map<string, AttributeTableOption[]>();
interface RowsSnapshot {
  records: MetadataAttributeRecord[];
  columns: MetadataAttributeColumn[];
  total: number;
}
const rowsCache = new Map<string, RowsSnapshot>();

/** 表清单缓存：命中零请求；单个资源拉不到表也缓存空数组，避免失败节点反复重试 */
async function ensureTables(uid: string): Promise<AttributeTableOption[]> {
  const hit = tablesCache.get(uid);
  if (hit) return hit;
  try {
    const tables = (await listAttributeTables(uid)) ?? [];
    tablesCache.set(uid, tables);
    return tables;
  } catch {
    tablesCache.set(uid, []);
    return [];
  }
}

/** 不分页后缓存维度只剩「资源 + 表」：一个页签一份全量快照 */
function rowsCacheKey(uid: string, tableKey: string): string {
  return `${uid}|${tableKey}`;
}

/** 写操作后清掉该资源该表的旧快照，下一轮强制回源，避免脏数据 */
function invalidateRows(uid: string, tableKey: string): void {
  rowsCache.delete(`${uid}|${tableKey}`);
}

/**
 * 拉取轮次：连续切页签 / 勾选变化都会打接口，先发的请求可能后返回。
 * 只有最新一轮允许写 records，否则会出现「点第 2 个页签，先显示它的数据，随后被第 1 个页签的迟到响应覆盖」。
 */
let loadToken = 0;

async function loadData(force = false) {
  const token = ++loadToken;
  const uid = activeResourceUid.value;
  if (!uid) {
    // 没有页签 = 这批资源一张表都没有：清空并走空态，不要发无意义请求
    records.value = [];
    columns.value = [];
    total.value = 0;
    noTable.value = !tabs.value.length;
    // 本轮已经是最新的拉取轮次，收起可能由上一轮遗留的遮罩（取消全部勾选时会走到这里）
    if (token === loadToken) loading.value = false;
    return;
  }
  const cacheKey = rowsCacheKey(uid, activeTableKey.value);
  if (force) {
    // 写操作后的强制回源：先清掉该资源该表的旧快照，否则下次切回会命中脏数据
    invalidateRows(uid, activeTableKey.value);
  } else {
    // 命中缓存直接回填，零请求；连 loading 都不用亮，交互是即时的
    const hit = rowsCache.get(cacheKey);
    if (hit) {
      records.value = hit.records;
      columns.value = hit.columns;
      total.value = hit.total;
      noTable.value = false;
      loading.value = false;
      return;
    }
  }
  loading.value = true;
  try {
    const res = await listResourceAttributes(uid, {
      tableKey: activeTableKey.value || undefined,
      // 无分页：固定第 1 页 + 单页上限，一次拉全量
      page: 1,
      pageSize: METADATA_ATTR_PAGE_SIZE_MAX
    });
    if (token !== loadToken) return;
    const data = res?.data;
    records.value = data?.records ?? [];
    // 列从响应归一：后端给的是 fieldLabels（列名 → 中文名），契约的 fields 实测为空
    columns.value = resolveAttributeColumns(data);
    total.value = data?.total ?? 0;
    noTable.value = false;
    // 首次拉到就挂到当前资源节点下：之后切回该表不再打接口
    rowsCache.set(cacheKey, { records: records.value, columns: columns.value, total: total.value });
  } catch (e: any) {
    if (token !== loadToken) return;
    // 40404 = 该资源没有元数据表，是空态不是错误；其它错误由全局拦截器提示
    records.value = [];
    columns.value = [];
    total.value = 0;
    noTable.value = Number(e?.code) === 40404 || /40404/.test(String(e?.message ?? ''));
  } finally {
    // 迟到的响应不能把 loading 关掉（最新一轮还在跑）
    if (token === loadToken) loading.value = false;
  }
}

/** 表格渲染用的数据源（一次服务端返回即当前页全部记录，前端不做二次过滤） */
const displayRecords = computed<MetadataAttributeRecord[]>(() => records.value);

/**
 * 初始化轮次：连续勾选会连续触发 init，先一轮的 await 可能后返回。
 * 只有最新一轮允许写 tabs / 拉数据，避免「取消了 A 却被上一轮写回来」。
 */
let initToken = 0;

/**
 * 首屏 / 勾选集合变化：汇总这批资源的表清单，挑一个页签，再拉第一页。
 *
 * WHY 并发拉全部资源：勾选一个类别可能带出十几个资源，串行 await 会让右栏白屏十几轮 RTT。
 * 顺序必须与入参一致（`resourceUids` 是树上勾选的树序），Promise.all 天然保序。
 *
 * prefer：重新初始化时希望保住的页签（同一张表在勾选变化后仍然存在，就停在这张表上）。
 * WHY 要保：勾一个资源看到第 3 个页签，再勾一个资源如果跳回第 1 个页签，等于每次勾选都把
 * 用户正在看的数据顶掉；只有原页签确实消失了（那个资源被取消勾选）才退回第一个。
 */
async function init(prefer?: string) {
  const token = ++initToken;
  // 重建页签会换掉整批 records：让仍在进行中的地图自动切表联动失效，别把旧点击落回新数据
  cancelPendingMapSelection();
  clearHighlight();
  const uids = props.resourceUids.filter(Boolean);
  if (!uids.length) {
    // 本轮就是最新一轮，收起可能由上一轮遗留的遮罩（上一轮 await 返回时因 token 过期不会自己关）
    if (token === initToken) initLoading.value = false;
    tabs.value = [];
    activeTabKey.value = '';
    await loadData();
    return;
  }

  initLoading.value = true;
  try {
    // 表清单按资源 uid 缓存：已勾过的资源零请求，只有新勾选的资源才回源
    const perResource = await Promise.all(uids.map((uid) => ensureTables(uid)));
    if (token !== initToken) return;

    // 多资源时给页签加资源名前缀；单资源不加（前缀=自己名字，纯噪音）
    const multi = uids.length > 1;
    const next: AttrTab[] = [];
    uids.forEach((uid, i) => {
      const name = props.resourceNames[uid] || uid;
      for (const opt of perResource[i]) {
        next.push({
          key: `${uid}::${opt.key}`,
          resourceUid: uid,
          tableKey: opt.key,
          label: multi ? `${name} · ${opt.label}` : opt.label
        });
      }
    });

    tabs.value = next;
    const keep = prefer && next.some((t) => t.key === prefer) ? prefer : next[0]?.key || '';
    activeTabKey.value = keep;
    await loadData();
  } finally {
    // 只有最新一轮有权收起遮罩，避免先发后至的 init 把新一轮的 loading 提前关掉
    if (token === initToken) initLoading.value = false;
  }
}

/**
 * 页签切换前拦截：编辑态有未保存改动时先确认。
 * WHY 用 before-leave 而不是 @tab-change 里守卫：tab-change 触发时 v-model 已把
 * activeTabKey 改成新表，用户点「取消」后会出现「页签显示新表、数据还是旧表」的错位，
 * 而 before-leave 返回 false 能让 el-tabs 连 activeTabKey 一起留在原页签。
 */
function beforeTabLeave(): Promise<boolean> {
  return guardDataChange();
}

function onTabChange() {
  // 用户手动切表：作废尚未落地的地图自动切表联动，避免旧点击 await 回来覆盖用户选择
  cancelPendingMapSelection();
  // 换表 = 换了一整套记录，上一页表里攒的定位留着只会让人误认是新表的记录，清掉
  clearHighlight();
  loadData();
}

/* ---------------------------- 行操作 ---------------------------- */

function openDetail(row: MetadataAttributeRecord) {
  // 记录详情统一进布局右侧真实占位列（地图通道点要素也进同一列，编辑页同样能边看边改）：
  // 内容写入宿主即可，面板由布局集中渲染；点另一行原地换内容，不叠出第二列。
  detailToken = showRecordDetail({ row, columns: orderedColumns.value });
  if (detailToken) return;
  // 独立挂载（没有布局注册的宿主）：回落为原来的非模态抽屉
  createDrawer({
    title: pt('记录详情'),
    // 高度覆盖整个右侧内容区：从地图上沿到底部列表下沿（h-split 拖动时由 ResizeObserver 跟随）
    anchor: drawerAnchor,
    // 随本组件卸载销毁：路由不变但表格被换掉时，抽屉不会残留在 body 上
    owner,
    render: () => <AttributeRowDialog row={row} columns={orderedColumns.value} />
  });
}

// 表格卸载（换表 / 离开页面）时收起本表打开的详情列，避免残留一列空白
onBeforeUnmount(() => {
  if (detailToken) closeRecordDetail(detailToken);
  detailToken = null;
});

/* ---------------------------- 行内编辑模式 ---------------------------- */

/** 原始单元格值（空值统一 ''，对象转 JSON 串）：editBuffer 初始化与 diff 比对的基准 */
function originalValue(row: MetadataAttributeRecord, fieldKey: string): string {
  const raw = row?.values?.[fieldKey];
  if (raw == null || raw === '') return '';
  return typeof raw === 'object' ? cellText(row, fieldKey) : String(raw);
}

/** 丢弃全部编辑缓存并退出编辑模式 */
function discardEdit() {
  for (const uid of Object.keys(editBuffer)) delete editBuffer[uid];
  dirtyCells.value = new Set();
  editingCell.value = '';
  schemaError.value = '';
  isEditing.value = false;
}

/**
 * 数据即将被替换（切页签 / 翻页 / 切换勾选资源）前调用：
 * 编辑态且有未保存改动 → 二次确认后才放行，避免改了一半的单元格被静默丢掉。
 */
async function guardDataChange(): Promise<boolean> {
  if (!isEditing.value) return true;
  if (dirtyCells.value.size) {
    try {
      await ElMessageBox.confirm(pt('当前有未保存的修改，切换后将丢弃。确认继续？'), pt('退出编辑'), {
        type: 'warning',
        confirmButtonText: pt('丢弃修改'),
        cancelButtonText: pt('继续编辑')
      });
    } catch {
      return false;
    }
  }
  discardEdit();
  return true;
}

/** 工具栏「编辑」：取 edit-schema（metadata.edit 权限门）→ 快照当前页 → 进入编辑模式 */
async function enterEditMode() {
  if (!activeResourceUid.value || !activeTableKey.value) {
    ElMessage.warning(pt('当前页签没有可用的元数据表，无法编辑'));
    return;
  }
  if (!records.value.length) {
    ElMessage.warning(pt('当前页没有可编辑的记录'));
    return;
  }
  try {
    const res = await getEditSchema(activeResourceUid.value, activeTableKey.value);
    const fields = res?.data?.fields ?? [];
    editFields.value = fields;
    if (!fields.length) {
      schemaError.value = '该表未返回可编辑字段定义';
      ElMessage.warning(schemaError.value);
      return;
    }
    if (!editableKeySet.value.size) {
      ElMessage.warning(pt('该表没有可编辑字段（字段均为只读）'));
      return;
    }
  } catch (e: any) {
    if (isMetadataPermissionDenied(e)) ElMessage.error(pt('缺少 metadata.edit 权限，编辑功能需该权限开通后可用'));
    else ElMessage.error(`字段定义加载失败：${e?.message ?? '接口异常'}`);
    return;
  }
  // 快照当前页：buffer 只装可编辑字段，值取自原始行（编辑期间绝不改 records）
  for (const row of records.value) {
    const uid = recordUid(row);
    if (!uid) continue;
    const buf: Record<string, string> = {};
    for (const key of editableKeySet.value) buf[key] = originalValue(row, key);
    editBuffer[uid] = buf;
  }
  dirtyCells.value = new Set();
  editingCell.value = '';
  schemaError.value = '';
  isEditing.value = true;
  ElMessage.success(pt('已进入编辑模式：单击单元格修改，完成后点击「保存」提交'));
}

/** 单击单元格 → 该格变输入框（只读列 / 无身份行不放行） */
function onCellClick(row: MetadataAttributeRecord, fieldKey: string) {
  if (!isEditing.value) return;
  if (!editableKeySet.value.has(fieldKey)) {
    ElMessage.warning(`「${fieldLabel(fieldKey)}」是只读字段，不可编辑`);
    return;
  }
  const uid = recordUid(row);
  if (!uid || !editBuffer[uid]) {
    ElMessage.warning(pt('该记录缺少 metadata_uid，无法编辑（请刷新列表后重试）'));
    return;
  }
  editingCell.value = cellId(uid, fieldKey);
}

/** 输入框写回缓存：el-input-number / el-select 的非字符串值统一串化 */
function setCellValue(row: MetadataAttributeRecord, fieldKey: string, value: unknown) {
  const uid = recordUid(row);
  if (!editBuffer[uid]) return;
  editBuffer[uid][fieldKey] = value == null ? '' : String(value);
  onCellChange(row, fieldKey);
}

/** 值变化后与原值比对，维护 dirtyCells（改动高亮 + 保存时只收 diff） */
function onCellChange(row: MetadataAttributeRecord, fieldKey: string) {
  const uid = recordUid(row);
  const id = cellId(uid, fieldKey);
  const next = new Set(dirtyCells.value);
  const cur = editBuffer[uid]?.[fieldKey] ?? '';
  if (cur === originalValue(row, fieldKey)) next.delete(id);
  else next.add(id);
  dirtyCells.value = next;
}

/** 失焦 / 回车 / 选中枚举后收起输入框，回到文本态 */
function finishCell() {
  editingCell.value = '';
}

/** 该单元格当前是否处于「输入框」态 */
function isEditingCell(row: MetadataAttributeRecord, fieldKey: string): boolean {
  return isEditing.value && editingCell.value === cellId(recordUid(row), fieldKey);
}

/** 文本/数值输入框写回缓存（即时写回，不收起；失焦时 finishCell 收起） */
function onEditorInput(row: MetadataAttributeRecord, fieldKey: string, value: unknown) {
  setCellValue(row, fieldKey, value);
}

/** 下拉选中后写回缓存并立即收起，回到文本态 */
function onEditorSelect(row: MetadataAttributeRecord, fieldKey: string, value: unknown) {
  setCellValue(row, fieldKey, value);
  finishCell();
}

/** 单元格是否显示黄色「已改动」标记 */
function isCellDirty(row: MetadataAttributeRecord, fieldKey: string): boolean {
  return dirtyCells.value.has(cellId(recordUid(row), fieldKey));
}

/**
 * 按 edit-schema 自动校验所有改动字段（呼应产品文档「字段类型、取值范围和约束条件自动校验」）。
 * 返回第一条错误信息；空串表示通过。
 */
function validateDirtyCells(): string {
  const rowByUid = new Map(records.value.map((r) => [recordUid(r), r]));
  for (const id of dirtyCells.value) {
    const split = id.indexOf('::');
    const uid = id.slice(0, split);
    const key = id.slice(split + 2);
    const row = rowByUid.get(uid);
    if (!row) return pt('有改动的记录已不在当前页，请刷新后重试');
    const f = fieldByKey.value[key];
    const value = editBuffer[uid]?.[key] ?? '';
    const label = fieldLabel(key);
    if (f?.required && !value.trim()) return `「${label}」为必填字段，不能为空`;
    if (f?.maxLength != null && value.length > f.maxLength) return `「${label}」不能超过 ${f.maxLength} 个字符`;
    if (f?.pattern) {
      try {
        if (value && !new RegExp(f.pattern).test(value)) return `「${label}」格式不正确`;
      } catch {
        // schema 里的非法正则不阻塞保存，跳过该规则
      }
    }
    if (f?.options?.length && value && !f.options.some((o) => o.value === value)) return `「${label}」的值不在可选范围内`;
    if (isNumericField(key) && value.trim()) {
      const num = Number(value);
      if (!Number.isFinite(num)) return `「${label}」必须是数字`;
      if (f?.minimum != null && num < f.minimum) return `「${label}」不能小于 ${f.minimum}`;
      if (f?.maximum != null && num > f.maximum) return `「${label}」不能大于 ${f.maximum}`;
    }
  }
  return '';
}

/** 工具栏「保存」：一次租约覆盖全部改动行，逐行 update，成功后刷新当前页 */
async function saveEdit() {
  const dirtyIds = [...dirtyCells.value];
  if (!dirtyIds.length) {
    discardEdit();
    ElMessage.info(pt('没有需要保存的修改，已退出编辑模式'));
    return;
  }
  const err = validateDirtyCells();
  if (err) {
    ElMessage.warning(err);
    return;
  }
  // 按行聚合改动（一条记录可能被改多个字段，只提交一次）
  const uids = [...new Set(dirtyIds.map((id) => id.slice(0, id.indexOf('::'))))];
  const rowByUid = new Map(records.value.map((r) => [recordUid(r), r]));
  const targets: Array<{ uid: string; values: Record<string, string>; version: number }> = [];
  for (const uid of uids) {
    const row = rowByUid.get(uid);
    if (!row) {
      ElMessage.error(pt('有改动的记录已不在当前页，请刷新后重试'));
      return;
    }
    const version = recordVersion(row);
    if (version == null) {
      ElMessage.error(pt('该记录缺少 row_version，无法做并发校验（请刷新列表后重试）'));
      return;
    }
    targets.push({ uid, values: editBuffer[uid] ?? {}, version });
  }

  const resourceUid = activeResourceUid.value;
  const tableKey = activeTableKey.value;
  saving.value = true;
  try {
    // 一次租约覆盖全部改动行（呼应产品文档「编辑时自动进入编辑模式并锁定文件」）；
    // 逐行 update 是现有写门面的唯一形态（批量门面只支持「所有行改同一字段」），
    // 任一行失败即整体抛错，已提交的行需刷新后按最新 row_version 重新编辑。
    await withEditLock(resourceUid, tableKey, { mode: 'records', metadataUids: uids }, async (lock) => {
      for (const t of targets) {
        await updateMetadataRecord(resourceUid, tableKey, t.uid, {
          values: normalizeFieldValues(t.values),
          expectedRowVersion: t.version,
          lockToken: lock.lockToken,
          lockRevision: lock.lockRevision
        });
      }
    });
    discardEdit();
    ElMessage.success(`已保存 ${targets.length} 条记录的修改`);
    loadData(true);
  } catch (e: any) {
    if (isMetadataPermissionDenied(e)) ElMessage.error(pt('缺少 metadata.edit 权限，请联系管理员开通后再试'));
    else ElMessage.error(String(e?.message || '保存失败'));
  } finally {
    saving.value = false;
  }
}

/**
 * 打开「新增记录」弹窗（走真实写接口：schema → **表锁** → create → 自动放锁）。
 *
 * WHY 创建用表锁而不是记录锁：契约明示「create必须表锁」；新建记录还不存在，
 * 按记录锁锁一条「不存在的记录」服务端会以「本人持有且未过期的编辑锁」校验失败。
 */
function openCreate() {
  // 没有页签（这批资源没有元数据表）时无从新建：表键是路径必要段
  if (!activeResourceUid.value || !activeTableKey.value) {
    ElMessage.warning(pt('当前页签没有可用的元数据表，无法新增记录'));
    return;
  }
  const tab = tabs.value.find((t) => t.key === activeTabKey.value);
  createDialog({
    title: `新增记录${tab?.label ? ' · ' + tab.label : ''}`,
    width: '760px',
    okText: pt('保存'),
    render: () => (
      <AttributeCreateDialog
        resourceUid={activeResourceUid.value}
        tableKey={activeTableKey.value}
        tableLabel={tab?.label}
        columns={orderedColumns.value}
        onSaved={() => loadData(true)}
      />
    )
  });
}

/**
 * 打开「变更历史 + 撤销」弹窗（只读历史 + 单条撤销写操作）。
 *
 * WHY 撤销放在历史弹窗内而不是行内按钮：契约要求「撤销目标必须为最新历史UUID」，
 * 用户必须先看见哪一条是最新、撤了什么，才谈得上决定要不要撤 —— 放进历史面板才是正确交互。
 */
function openHistory(row: MetadataAttributeRecord) {
  const uid = String(row?.values?.metadata_uid ?? '');
  if (!uid) {
    ElMessage.warning(pt('该记录缺少 metadata_uid，无法查询变更历史'));
    return;
  }
  createDialog({
    title: pt('变更历史'),
    width: '820px',
    footer: false,
    render: () => (
      <AttributeHistoryDialog
        row={row}
        resourceUid={activeResourceUid.value}
        tableKey={activeTableKey.value || row.tableKey}
        columns={orderedColumns.value}
        onSaved={() => loadData(true)}
      />
    )
  });
}

/** 已勾选待批量操作的行 */
const selectedRows = ref<MetadataAttributeRecord[]>([]);

/** 表格勾选变化：保留行对象（批量操作要读 values 里的 metadata_uid / row_version） */
function onSelectionChange(rows: MetadataAttributeRecord[]) {
  selectedRows.value = rows;
}

/**
 * 打开「批量编辑 / 批量删除」弹窗（走真实 `POST .../records/batch`）。
 *
 * WHY 必须至少勾一条：批量接口的 metadataUids 是必填且 1—200 条，
 * 空选提交只会拿到 40001；在入口处拦住比让用户提交后看报错更清楚。
 */
function openBatch() {
  if (!selectedRows.value.length) {
    ElMessage.warning(pt('请先在表格左侧勾选要批量操作的记录'));
    return;
  }
  if (!activeResourceUid.value || !activeTableKey.value) {
    ElMessage.warning(pt('当前页签没有可用的元数据表，无法批量操作'));
    return;
  }
  createDialog({
    title: `批量操作（已选 ${selectedRows.value.length} 条）`,
    width: '620px',
    okText: pt('提交'),
    render: () => (
      <AttributeBatchDialog
        rows={selectedRows.value}
        resourceUid={activeResourceUid.value}
        tableKey={activeTableKey.value}
        columns={orderedColumns.value}
        onSaved={() => {
          // 批量删除后原勾选行已不存在，必须清空选择，否则再次点批量会带上失效 uid
          selectedRows.value = [];
          loadData(true);
        }}
      />
    )
  });
}

/**
 * 删除单条记录（走真实 `DELETE .../records/{metadataUid}`）。
 *
 * 契约三个 query 必填：expectedRowVersion / lockToken / confirm=true。
 * WHY 用弹窗二次确认而不是行内直接删：删除不可逆，且契约本身要求 confirm=true 显式确认。
 */
async function removeRow(row: MetadataAttributeRecord) {
  const uid = String(row?.values?.metadata_uid ?? '');
  const version = Number(row?.values?.row_version ?? row?.values?.rowVersion);
  if (!uid) {
    ElMessage.warning(pt('该记录缺少 metadata_uid，无法删除'));
    return;
  }
  if (!Number.isFinite(version)) {
    ElMessage.warning(pt('该记录缺少 row_version，无法做并发校验（请刷新列表后重试）'));
    return;
  }
  try {
    await ElMessageBox.confirm(pt('删除后记录不再出现在列表，变更历史仍保留。确认删除该记录？'), pt('删除确认'), {
      type: 'warning',
      confirmButtonText: pt('确认删除'),
      cancelButtonText: pt('取消')
    });
  } catch {
    // 用户取消：正常分支，不发请求
    return;
  }
  try {
    const res = await withEditLock(
      activeResourceUid.value,
      activeTableKey.value || row.tableKey,
      { mode: 'records', metadataUids: [uid] },
      async (lock) =>
        deleteMetadataRecord(activeResourceUid.value, activeTableKey.value || row.tableKey, uid, {
          expectedRowVersion: version,
          lockToken: lock.lockToken,
          confirm: true,
          requestId: `del-${uid.slice(0, 8)}-${Date.now()}`
        })
    );
    // 契约单条删除的 deleted 是 boolean，批量才是数量 —— 只判非 falsy
    const deleted = res?.data?.deleted;
    if (deleted === false) {
      ElMessage.warning(pt('服务端未删除该记录（可能已被他人修改，请刷新后重试）'));
    } else {
      ElMessage.success(pt('已删除该记录'));
    }
    loadData(true);
  } catch (e: any) {
    if (isMetadataPermissionDenied(e)) ElMessage.error(pt('缺少 metadata.edit 权限，请联系管理员开通后再试'));
    else ElMessage.error(String(e?.message || '删除失败'));
  }
}

/**
 * 一条属性记录 → 它在图层上的几何（要素）+ 包围盒。
 *
 * 取值优先级：
 *   1. `spatial_range`（WKT / GeoJSON，归一见 map/spatial-range.ts）——**真实几何**，
 *      高亮画的是这条记录的图斑轮廓，而不是它的外接矩形；
 *   2. 取不到几何时退回 `nw/ne/sw/se` 四角经纬度（元数据表里必有的一组字段）拼矩形。
 * 都没有返回 null —— 此时行点击退回打开详情，不把镜头甩到 (0,0)。
 */
function recordFeature(row: MetadataAttributeRecord): { feature: any; bounds: Bounds4 } | null {
  const values = row?.values ?? {};

  const geom = spatialRangeToGeometry(values.spatial_range);
  const geomBounds = geom ? geometryBounds(geom) : null;
  if (geom && geomBounds) return { feature: toFeature(geom, geomBounds), bounds: geomBounds };

  const lngs: number[] = [];
  const lats: number[] = [];
  const corners: Array<[unknown, unknown]> = [
    [values.nw_lon, values.nw_lat],
    [values.ne_lon, values.ne_lat],
    [values.sw_lon, values.sw_lat],
    [values.se_lon, values.se_lat]
  ];
  for (const [lngRaw, latRaw] of corners) {
    const lng = Number(lngRaw);
    const lat = Number(latRaw);
    if (!Number.isFinite(lng) || !Number.isFinite(lat)) continue;
    lngs.push(lng);
    lats.push(lat);
  }

  if (!lngs.length) return null;
  const bounds: Bounds4 = [Math.min(...lngs), Math.min(...lats), Math.max(...lngs), Math.max(...lats)];
  return { feature: boundsFeature(bounds), bounds };
}

/**
 * 要素渲染支持的 GeoJSON 类型。
 * WHY 要筛：`GeometryCollection` maplibre 的 geojson source 不认（要素被静默丢弃），
 * 遇到这类混合几何就退回包围盒矩形，保证「点了行地图上一定有东西亮起来」。
 */
const RENDERABLE_GEOMETRY_TYPES = new Set(['Point', 'MultiPoint', 'LineString', 'MultiLineString', 'Polygon', 'MultiPolygon']);

/** 几何 → 要素；包围盒退化（点 / 单线）或类型不可渲染时换成扩过框的矩形 */
function toFeature(geometry: any, bounds: Bounds4) {
  const degenerate = bounds[2] - bounds[0] < MIN_SPAN || bounds[3] - bounds[1] < MIN_SPAN;
  const pointLike = geometry.type === 'Point' || geometry.type === 'MultiPoint';
  const usable = RENDERABLE_GEOMETRY_TYPES.has(geometry.type) && (!degenerate || pointLike);
  return { type: 'Feature', properties: { hlColor: activeColor.value }, geometry: usable ? geometry : boundsGeometry(bounds) };
}

/** 包围盒 → 矩形几何；零尺寸（点 / 单线）向四周扩一点，保证框得出来 */
const MIN_SPAN = 0.004;
function boundsGeometry(b: Bounds4) {
  let [minLng, minLat, maxLng, maxLat] = b;
  if (maxLng - minLng < MIN_SPAN) {
    const mid = (minLng + maxLng) / 2;
    minLng = mid - MIN_SPAN / 2;
    maxLng = mid + MIN_SPAN / 2;
  }
  if (maxLat - minLat < MIN_SPAN) {
    const mid = (minLat + maxLat) / 2;
    minLat = mid - MIN_SPAN / 2;
    maxLat = mid + MIN_SPAN / 2;
  }
  return {
    type: 'Polygon',
    coordinates: [
      [
        [minLng, minLat],
        [maxLng, minLat],
        [maxLng, maxLat],
        [minLng, maxLat],
        [minLng, minLat]
      ]
    ]
  };
}

/** 包围盒 → 矩形要素（四角兜底通道用） */
function boundsFeature(b: Bounds4) {
  return { type: 'Feature', properties: { hlColor: activeColor.value }, geometry: boundsGeometry(b) };
}

/**
 * 高亮 source / 四个 layer 幂等挂载（底图 setStyle 后会被清空，需重挂）。
 *
 * 线色取要素自身类别色（feature.properties.hlColor，由所属资源的 palette 推出），取不到回退 MAP_SELECTION.color；
 * 白色 halo 只做垫边。WHY 保留 halo：选中框与图斑同色时也靠白边切开轮廓，避免淹在填充里。
 */
function ensureHighlightLayers(m: any) {
  if (!m.getSource(HL_SRC)) {
    m.addSource(HL_SRC, { type: 'geojson', data: { type: 'FeatureCollection', features: [] } });
  }
  if (!m.getLayer(HL_FILL)) {
    m.addLayer({
      id: HL_FILL,
      type: 'fill',
      source: HL_SRC,
      paint: { 'fill-color': HL_COLOR, 'fill-opacity': MAP_SELECTION.fillOpacity }
    });
  }
  // halo 先加，垫在彩色线下
  if (!m.getLayer(HL_HALO)) {
    m.addLayer({
      id: HL_HALO,
      type: 'line',
      source: HL_SRC,
      paint: { 'line-color': MAP_SELECTION.haloColor, 'line-width': MAP_SELECTION.haloWidth, 'line-opacity': MAP_SELECTION.haloOpacity }
    });
  }
  if (!m.getLayer(HL_LINE)) {
    m.addLayer({
      id: HL_LINE,
      type: 'line',
      source: HL_SRC,
      paint: { 'line-color': HL_COLOR, 'line-width': MAP_SELECTION.lineWidth }
    });
  }
  // 点几何 fill / line 都画不出来，仍需 circle 兜底；但必须用 filter 限定只画 Point/MultiPoint：
  // maplibre 的 circle 图层会对几何的每个顶点都生成一个圆，不过滤的话定位到面/线记录时矩形四角也会冒出圆点
  if (!m.getLayer(HL_CIRCLE)) {
    m.addLayer({
      id: HL_CIRCLE,
      type: 'circle',
      source: HL_SRC,
      filter: ['match', ['geometry-type'], ['Point', 'MultiPoint'], true, false],
      paint: {
        'circle-color': HL_COLOR,
        'circle-radius': MAP_SELECTION.circleRadius,
        'circle-stroke-color': MAP_SELECTION.haloColor,
        'circle-stroke-width': MAP_SELECTION.circleStrokeWidth
      }
    });
  }
}

/**
 * 把所有已定位行的要素写进 source（不删图层）。图层只在「有东西要画」时才建，
 * 否则底图一切换就白挂三个空图层。
 * CONSTRAINT 末尾必须无条件 `syncIdleWatcher()`：清空定位走的是提前 return 分支，
 * 放在分支里会漏解绑，留下一个永远监听 idle 的僵尸回调。
 */
function applyHighlight() {
  const m = map.mapInstance.value;
  if (m && locatedRows.value.length) ensureHighlightLayers(m);
  const source: any = m?.getSource(HL_SRC);
  if (source?.setData) {
    source.setData({ type: 'FeatureCollection', features: locatedRows.value.map((r) => r.feature) });
    raiseHighlight(m);
  }
  syncIdleWatcher();
}

/**
 * 把高亮四层提到图层栈顶（fill → halo → line → circle，相对次序不变）。
 *
 * WHY 需要它：maplibre 的 addLayer 默认追加到栈顶，左侧树勾选资源挂瓦片图层、
 * 或底图切换后重挂，都会把选中框压到瓦片下面 —— 表现为「点了行、地图没反应」。
 * CONSTRAINT 只在图层已存在时提层：底图刚 setStyle 完会先清掉所有 source/layer，
 * 对不存在的 id 调 moveLayer 直接抛错，而这里的 watch 比业务侧重挂更早触发。
 */
function raiseHighlight(m: any) {
  const layers: any[] = m.getStyle()?.layers ?? [];
  const ours = [HL_FILL, HL_HALO, HL_LINE, HL_CIRCLE].filter((id) => m.getLayer(id));
  if (!ours.length) return;
  // 已在栈顶就不动：moveLayer 会触发重绘 → 又进 idle → 再 moveLayer，
  // 不挡这一层就是永动渲染循环（掉帧 + 风扇狂转）。
  const topIdx = Math.max(...ours.map((id) => layers.findIndex((l) => l?.id === id)));
  if (topIdx >= layers.length - 1) return;
  for (const id of ours) m.moveLayer(id);
}

/**
 * 地图空闲时补一次提层。
 *
 * WHY 还要挂 idle：点行之后再去左侧树勾资源，父组件会把瓦片图层追加到栈顶把选中框盖住；
 * 本组件拿不到「别人什么时候 addLayer」的时机，idle（渲染安静下来）是唯一稳定钩子。
 * CONSTRAINT ① 只在有定位行时监听、清空定位立即解绑，不给底图留常驻回调；
 * ② 提频（idle 在持续取瓦片时会连着触发，`getStyle()` 要序列化整份 style，
 * 不加节流就是白烧 CPU）。
 */
let idleBound: any = null;
let lastRaiseAt = 0;
function onMapIdle() {
  const m = map.mapInstance.value;
  if (!m || !locatedRows.value.length) return;
  const now = Date.now();
  if (now - lastRaiseAt < 250) return;
  lastRaiseAt = now;
  raiseHighlight(m);
}
function syncIdleWatcher() {
  const m = map.mapInstance.value;
  if (locatedRows.value.length && m && idleBound !== m) {
    m.on('idle', onMapIdle);
    idleBound = m;
  } else if (!locatedRows.value.length && idleBound) {
    try {
      idleBound.off('idle', onMapIdle);
    } catch {
      /* 地图已销毁 */
    }
    idleBound = null;
  }
}

/** 镜头贴合「全部已定位行」范围的并集 */
function fitLocated(m: any) {
  const merged = mergeBounds(locatedRows.value.map((r) => r.bounds));
  if (!merged) return;
  m.fitBounds(
    [
      [merged[0], merged[1]],
      [merged[2], merged[3]]
    ],
    { padding: 80, maxZoom: 13, duration: 600 }
  );
}

function clearHighlight() {
  locatedRows.value = [];
  applyHighlight();
}

/**
 * 地图点要素 → 列表/地图双向联动（反向链路）。
 *
 * WHY 直接写 locatedRows 而不另起一套状态：locatedRows 一份状态同时驱动
 * ① 地图高亮边框（applyHighlight 写 source）② 列表行选中态（locatedKeySet → is-located）。
 * 把地图点击匹配到的行写进去，两个需求一次性满足，且 Ctrl 多选语义与点行完全一致。
 *
 * 高亮几何优先用点击命中的原始 geometry（精确贴合图斑），取不到再退回该行的 spatial_range。
 * CONSTRAINT 不调 fitLocated：地图 → 列表不该甩镜头，用户点哪块地镜头就留在哪。
 * 编辑态不打断编辑：地图联动只改高亮/选中，不触碰 isEditing 与表单。
 */
function applySelectionFromMap(sel: FeatureSelection) {
  const matched = matchRecord(records.value, sel.values);
  // sel.geometry 来自 MVT 聚合后的完整要素几何；spatialRangeToGeometry 是老入口（spatial_range 文本→几何），
  // 这里对已解析的 Geometry 对象直接透传，避免把瓦片片段的外接矩形当成要素高亮。
  const geom =
    (sel.geometry && typeof sel.geometry === 'object' && 'type' in (sel.geometry as any)
      ? (sel.geometry as any)
      : spatialRangeToGeometry(sel.geometry)) ?? (matched ? spatialRangeToGeometry(matched.values?.spatial_range) : null);
  const bounds = geom ? geometryBounds(geom) : null;
  const located = geom && bounds ? { feature: toFeature(geom, bounds), bounds } : matched ? recordFeature(matched) : null;
  if (!located) return;

  // 匹配不到行时仍画高亮边框（key 用 seq 保证唯一），只是列表没有选中态
  const key = matched ? rowKeyOf(matched) : `map-${sel.seq}`;
  locatedRows.value = [{ key, ...located }];
  applyHighlight();

  // 列表行滚入可视区：地图点到的记录可能很靠下，选中了却看不见等于没联动
  nextTick(() => {
    const rowEl = (tableRef.value?.$el as HTMLElement | undefined)?.querySelector?.('.el-table__row.is-located');
    rowEl?.scrollIntoView?.({ block: 'nearest' });
  });
}

/* ------------------- 地图点击 → 自动切页签（双向联动） ------------------- */

/**
 * 地图自动切表的轮次：连点不同图斑 / 用户手动切表 / 重建页签时，只让最后一次落地。
 * WHY 需要显式 token：切表要 await loadData()，期间用户可能又点了别的图斑或自己切了 tab，
 * 若让先发起的那次 await 返回后照旧写 locatedRows，就会用旧点击覆盖用户最新的选择。
 */
let mapSelectionToken = 0;
/** 切表拉数据期间暂存「最后一次」地图点击，loadData 完成后以它为准重放 */
let pendingMapSelection: FeatureSelection | null = null;

/** 用户主动改变上下文（切表 / 点行 / 取消定位 / 重建页签）：作废尚未落地的地图切表联动 */
function cancelPendingMapSelection() {
  mapSelectionToken += 1;
  pendingMapSelection = null;
}

/**
 * 地图点要素 → 同步高亮边框 + 选中列表行（与点行定位形成双向闭环）。
 *
 * 多资源叠加时地图一次显示所有资源的图斑，而列表一次只有一个页签的数据：
 * 点到别的资源的图斑，当前 records 里根本没这行，matchRecord 会正确拒绝误匹配，
 * 结果只有边框没有列表选中。故按点击携带的 resourceUid + tableKey 先自动切到对应页签，
 * 等新 records 到位再匹配 —— 「列表自动选中状态」才算真正闭环。
 *
 * CONSTRAINT 编辑态不切页签：切表会换掉整批 records、触发 before-leave 的数据守卫，
 * 打断用户正在进行的编辑；此时只按当前页签数据尽量匹配、画高亮边框，不强行跳表。
 * CONSTRAINT 不调 fitLocated：地图 → 列表不该甩镜头，用户点哪块地镜头就留在哪。
 */
async function handleMapSelection(sel: FeatureSelection) {
  const token = ++mapSelectionToken;
  pendingMapSelection = sel;

  const targetKey = `${sel.resourceUid ?? ''}::${sel.tableKey ?? ''}`;
  const tabExists = !!sel.resourceUid && !!sel.tableKey && tabs.value.some((t) => t.key === targetKey);
  // 当前页签已能匹配到这行，或根本没有对应页签 → 无需切表，直接落地。
  // 连点时 activeTabKey 可能已是目标页签但 records 还在拉，用 matchRecord 兜住「必须等数据」。
  const needSwitch = !isEditing.value && tabExists && (targetKey !== activeTabKey.value || !matchRecord(records.value, sel.values));
  if (needSwitch) {
    activeTabKey.value = targetKey;
    clearHighlight();
    // 程序化改 v-model 不会触发 el-tabs 的 tab-change，必须自己拉数据
    await loadData();
  }

  // 期间又有新点击 / 用户动作：本次作废，以最后一次为准
  if (token !== mapSelectionToken) return;
  const latest = pendingMapSelection ?? sel;
  pendingMapSelection = null;
  applySelectionFromMap(latest);
}

/** 模板「取消定位」：清高亮的同时作废尚未落地的地图切表联动 */
function clearLocatedByUser() {
  cancelPendingMapSelection();
  clearHighlight();
}

/**
 * 行点击 → 高亮并定位到该记录对应的图层范围。
 *
 * 单选 / 多选（第三个参数是 el-table 透传的原生 MouseEvent）：
 * - 普通左键 = **替换**成这一行（默认单选）；
 * - Ctrl / Cmd + 左键 = **加选**这一行；点已选中的行则取消它的定位（toggle）。
 * CONSTRAINT 多选时镜头贴合所有已选行的并集；取消到一条不剩时只清空高亮、不甩镜头。
 */
function onRowClick(row: MetadataAttributeRecord, _column: unknown, event: MouseEvent) {
  // 编辑模式下单击单元格会连带触发一次 row-click：此时不做地图定位 / 开详情，
  // 否则点开输入框的同时镜头被甩走、或弹出详情遮住表格。
  if (isEditing.value) return;

  // 用户点行即主动选择：作废尚未落地的地图切表联动
  cancelPendingMapSelection();

  // 非编辑态点行同时打开右侧记录详情列：边看全字段边继续点别的行（详情列原地换内容）
  openDetail(row);

  const key = rowKeyOf(row);
  const multi = !!(event?.ctrlKey || event?.metaKey);
  const picked = locatedRows.value;
  const hit = picked.findIndex((r) => r.key === key);

  // 多选 + 已选 → 取消该行（无需再解析几何）
  if (multi && hit >= 0) {
    locatedRows.value = picked.filter((_, i) => i !== hit);
    applyHighlight();
    return;
  }

  const m = map.mapInstance.value;
  const located = recordFeature(row);
  if (!m || !located) return;

  locatedRows.value = multi ? [...picked, { key, ...located }] : [{ key, ...located }];
  applyHighlight();
  fitLocated(m);
}

/* ---------------------------- 列设置 ---------------------------- */

function toggleColumn(key: string) {
  columnTouched = true;
  shownKeys.value = shownKeys.value.includes(key) ? shownKeys.value.filter((k) => k !== key) : [...shownKeys.value, key];
}

function selectAllColumns() {
  columnTouched = true;
  shownKeys.value = orderedColumns.value.map((c) => c.key);
}

function invertColumns() {
  columnTouched = true;
  const shown = new Set(shownKeys.value);
  shownKeys.value = orderedColumns.value.filter((c) => !shown.has(c.key)).map((c) => c.key);
}

/* ---------------------------- 生命周期 / 监听 ---------------------------- */

// 列集合变化：未手动改过就全选；改过则只剔除已不存在的列（不覆盖用户选择）
watch(
  orderedColumns,
  (cols) => {
    const keys = cols.map((c) => c.key);
    if (!columnTouched) {
      shownKeys.value = keys;
      return;
    }
    const exists = new Set(keys);
    shownKeys.value = shownKeys.value.filter((k) => exists.has(k));
  },
  { immediate: true }
);

// 底图切换（setStyle）会清掉所有 source/layer：重挂图层并回填当前高亮
watch(
  () => map.styleVersion.value,
  () => {
    if (!map.mapInstance.value) return;
    applyHighlight();
  }
);

// 地图 → 列表：点地图要素后同步高亮边框 + 选中列表行（与点行定位形成双向闭环）
// 多资源叠加时先自动切到对应页签，等新 records 到位再匹配，保证「列表自动选中」闭环
watch(featureSelection, (sel) => {
  if (sel) handleMapSelection(sel);
});

onMounted(() => init());

/**
 * 勾选集合变化 → 重建页签。
 *
 * WHY 比较内容而不比较数组引用：父组件每次重算都会产生新数组，
 * 只凭引用变化会在一模一样的勾选上反复重建（白拉一遍接口 + 丢定位）；
 * 拼成字符串比较才能判定「勾选集合真的变了没有」，顺带保住树序。
 *
 * WHY 保 activeTabKey：见 init 的 prefer 说明 —— 勾一个资源不该把正在看的表顶掉。
 */
watch(
  () => props.resourceUids.join(','),
  async () => {
    // 勾选集合变了会重建页签并换一批 records：编辑态未保存的改动先确认，避免被静默丢弃
    if (!(await guardDataChange())) return;
    init(activeTabKey.value);
  }
);

onBeforeUnmount(() => {
  // 先走 clearHighlight 解绑 idle：地图挂在 useMap 单例上、比本组件活得久，
  // 不解绑的话卸载后这个闭包仍会被每次 idle 调到（僵尸监听 + 幽灵提层）。
  clearHighlight();
  const m = map.mapInstance.value;
  if (!m) return;
  for (const id of [HL_CIRCLE, HL_LINE, HL_HALO, HL_FILL]) {
    if (m.getLayer(id)) m.removeLayer(id);
  }
  if (m.getSource(HL_SRC)) m.removeSource(HL_SRC);
});
</script>

<template>
  <div class="attr-page">
    <!-- 表切换 + 列设置：同一行，tabs 占左侧、工具占右侧 -->
    <div class="attr-bar">
      <div v-if="tabs.length" class="attr-tabs">
        <el-tabs v-model="activeTabKey" :before-leave="beforeTabLeave" @tab-change="onTabChange">
          <el-tab-pane v-for="opt in tabs" :key="opt.key" :label="opt.label" :name="opt.key" />
        </el-tabs>
      </div>

      <div class="attr-tools">
        <!-- 有定位行时给个计数 + 「取消定位」出口：Ctrl 多选攒下几个框后，
             只能逐行 Ctrl 点掉太难用，切资源/换表也不会误留旧 selection。 -->
        <span v-if="locatedRows.length" class="attr-located">
          {{ pt('已定位') }} <b>{{ locatedRows.length }}</b> {{ pt('条') }}
          <el-button link type="primary" size="small" @click="clearLocatedByUser">{{ pt('取消定位') }}</el-button>
        </span>
        <!-- 已勾选计数：批量操作只作用于勾选行，必须让用户随时看到自己选了几条 -->
        <span v-if="selectedRows.length" class="attr-selected"
          >{{ pt('已勾选') }} <b>{{ selectedRows.length }}</b> {{ pt('条') }}</span
        >
        <el-button v-if="!isEditing" size="small" type="primary" :icon="EditPen" :disabled="!activeTableKey" @click="enterEditMode">{{
          pt('编辑')
        }}</el-button>
        <template v-else>
          <el-button size="small" type="success" :icon="Check" :loading="saving" @click="saveEdit">{{ pt('保存') }}</el-button>
          <el-button size="small" :disabled="saving" @click="discardEdit">{{ pt('取消') }}</el-button>
          <span class="attr-edit-tip">{{ pt('单击单元格修改') }}</span>
        </template>
        <!-- <el-button size="small" type="primary" :icon="Plus" :disabled="!activeTableKey || isEditing" @click="openCreate">新增记录</el-button> -->
        <el-button size="small" :icon="Delete" :disabled="!selectedRows.length || isEditing" @click="openBatch">批量操作</el-button>
        <span class="attr-count">{{ total }} 条 · 显示 {{ displayColumns.length }}/{{ orderedColumns.length }} 列</span>
        <el-popover placement="bottom-end" :width="300" trigger="click" popper-class="attr-col-popper">
          <template #reference>
            <el-button size="small" :icon="Setting">列设置</el-button>
          </template>
          <div class="col-panel">
            <div class="col-panel__head">
              <span>字段显隐</span>
              <span class="col-panel__ops">
                <el-button link type="primary" size="small" @click="selectAllColumns">全选</el-button>
                <el-button link type="primary" size="small" @click="invertColumns">反选</el-button>
              </span>
            </div>
            <div class="col-panel__list">
              <el-checkbox v-for="col in orderedColumns" :key="col.key" :model-value="shownKeys.includes(col.key)" @change="toggleColumn(col.key)">
                {{ col.label }}
              </el-checkbox>
            </div>
          </div>
        </el-popover>
      </div>
    </div>

    <div v-loading="loading || initLoading" class="attr-body">
      <el-table
        v-if="displayColumns.length"
        ref="tableRef"
        :data="displayRecords"
        height="100%"
        border
        stripe
        :row-key="rowKeyOf"
        :row-class-name="rowClassName"
        :cell-class-name="cellClassName"
        :class="{ 'is-editing': isEditing }"
        class="attr-table"
        @row-click="onRowClick"
        @cell-click="onCellClickEvent"
        @selection-change="onSelectionChange"
      >
        <!-- 勾选列固定在最左：批量操作的作用对象必须随时可见，横向滚动后也不能丢 -->
        <el-table-column type="selection" width="44" align="center" fixed />
        <el-table-column type="index" label="#" width="56" align="center" fixed />
        <el-table-column
          v-for="col in displayColumns"
          :key="col.key"
          :label="col.label"
          :prop="`values.${col.key}`"
          :min-width="columnMinWidth(col.label)"
          show-overflow-tooltip
        >
          <template #default="{ row }">
            <!-- 编辑态：单击激活的单元格按字段类型渲染成输入框 / 数值框 / 下拉 / 多行文本；
                 其余单元格只显示文本，改动过的单元格由 cell-class-name 挂黄色高亮。 -->
            <template v-if="isEditingCell(row as MetadataAttributeRecord, col.key)">
              <el-select
                v-if="fieldOptions(col.key).length"
                v-focus
                :model-value="cellValue(row as MetadataAttributeRecord, col.key)"
                size="small"
                placeholder="请选择"
                @change="onEditorSelect(row as MetadataAttributeRecord, col.key, $event)"
                @blur="finishCell"
              >
                <el-option v-for="opt in fieldOptions(col.key)" :key="opt.value" :label="opt.label" :value="opt.value" />
              </el-select>
              <el-input-number
                v-else-if="isNumericField(col.key)"
                v-focus
                :model-value="Number(cellValue(row as MetadataAttributeRecord, col.key)) || 0"
                size="small"
                controls-position="right"
                @input="onEditorInput(row as MetadataAttributeRecord, col.key, $event)"
                @change="onEditorInput(row as MetadataAttributeRecord, col.key, $event)"
                @blur="finishCell"
                @keyup.enter="finishCell"
              />
              <el-input
                v-else-if="isLongTextField(col.key)"
                v-focus
                :model-value="cellValue(row as MetadataAttributeRecord, col.key)"
                type="textarea"
                :autosize="{ minRows: 2, maxRows: 4 }"
                size="small"
                @input="onEditorInput(row as MetadataAttributeRecord, col.key, $event)"
                @blur="finishCell"
              />
              <el-input
                v-else
                v-focus
                :model-value="cellValue(row as MetadataAttributeRecord, col.key)"
                size="small"
                :maxlength="fieldByKey[col.key]?.maxLength"
                @input="onEditorInput(row as MetadataAttributeRecord, col.key, $event)"
                @blur="finishCell"
                @keyup.enter="finishCell"
              />
            </template>
            <span v-else class="attr-cell-text" :class="{ 'is-dirty': isCellDirty(row as MetadataAttributeRecord, col.key) }">
              {{ displayCellText(row as MetadataAttributeRecord, col.key) }}
            </span>
          </template>
        </el-table-column>
        <!-- 操作列固定在右侧：列很多时横向滚动后仍能点到全部行内操作 -->
        <el-table-column label="操作" width="150" align="center" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" :icon="View" title="查看详情" @click.stop="openDetail(row as MetadataAttributeRecord)" />
            <!-- 变更历史 / 删除成功后会 loadData() 刷新整页，编辑态下会冲掉未保存的缓存，先禁用 -->
            <el-button
              link
              type="primary"
              :icon="Clock"
              title="变更历史与撤销"
              :disabled="isEditing"
              @click.stop="openHistory(row as MetadataAttributeRecord)"
            />
            <el-button
              link
              type="danger"
              :icon="Delete"
              title="删除该记录"
              :disabled="isEditing"
              @click.stop="removeRow(row as MetadataAttributeRecord)"
            />
          </template>
        </el-table-column>
      </el-table>

      <el-empty v-else :description="noTable ? emptyText : loading || initLoading ? '加载中…' : '暂无属性记录'" :image-size="80" />
    </div>
  </div>
</template>

<style scoped lang="scss">
.attr-page {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
  padding: 0;
  overflow: hidden;
  background: var(--el-bg-color);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 6px;
}

.attr-bar {
  display: flex;
  flex: 0 0 auto;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 0 12px;
  border-bottom: 1px solid var(--el-border-color-lighter);
}

.attr-tabs {
  flex: 1 1 auto;
  min-width: 0;

  :deep(.el-tabs__header) {
    margin: 0;
  }
  :deep(.el-tabs__nav-wrap::after) {
    display: none;
  }
}

.attr-tools {
  display: flex;
  flex: 0 0 auto;
  align-items: center;
  gap: 10px;
}

.attr-selected {
  color: var(--el-color-primary);
  font-size: 12px;

  b {
    font-weight: 600;
  }
}

.attr-located {
  color: var(--el-color-primary);
  font-size: 12px;
  white-space: nowrap;
  b {
    font-variant-numeric: tabular-nums;
  }
}

.attr-count {
  color: var(--el-text-color-secondary);
  font-size: 12px;
  white-space: nowrap;
}

.attr-body {
  flex: 1 1 auto;
  min-height: 0;
  padding: 0 12px;
  overflow: hidden;
}

/* 点击行定位地图：鼠标形态要给出来，否则用户不知道行是可点的 */
.attr-table {
  :deep(.el-table__row) {
    cursor: pointer;
  }

  /* 已定位（is-located）行样式已归一到全局 src/assets/styles/index.scss
     的 html.group-manage 块（地图联动列表选中行唯一真源），此处不再重复。 */

  /* 表头单行：后端中文标签常是 8–10 字，默认会被折成两行、把表头撑高；
     宽度已在 columnMinWidth 里按字数给足，这里禁止换行并兜底省略号。
     不改 padding —— 与表体单元格保持同一内边距，否则表头文字和表体会偏移。 */
  :deep(.el-table__header-wrapper .cell),
  :deep(.el-table__fixed-header-wrapper .cell) {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    word-break: keep-all;
    overflow-wrap: normal;
  }
}

/* 列设置面板：字段可能有几十个，限高滚动 */
.col-panel__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 6px;
  color: var(--el-text-color-regular);
  font-size: 12px;
}

.col-panel__ops {
  display: flex;
  gap: 4px;
}

.col-panel__list {
  display: grid;
  grid-template-columns: 1fr;
  gap: 2px;
  max-height: 320px;
  overflow: auto;
}

/* ---------------------------- 行内编辑态 ---------------------------- */
.attr-edit-tip {
  color: var(--el-color-primary);
  font-size: 12px;
  white-space: nowrap;
}

/* 文本态单元格：撑满列宽，编辑态下留出可单击区域 */
.attr-cell-text {
  display: inline-block;
  width: 100%;
  min-height: 18px;
  line-height: 18px;
  &.is-dirty {
    color: var(--el-color-warning);
    font-weight: 600;
  }
}

/* 改动过的单元格：淡黄底 + 右上角小三角，扫一眼就能看出哪些格子没保存。
   !important 保证改动提醒优先于全局 is-located 选中行的淡蓝底（见 index.scss）。 */
.attr-table {
  :deep(td.el-table__cell.is-dirty-cell) {
    background: var(--el-color-warning-light-9) !important;
    position: relative;
    &::after {
      content: '';
      position: absolute;
      top: 0;
      right: 0;
      border-top: 6px solid var(--el-color-warning);
      border-left: 6px solid transparent;
    }
  }
  /* 编辑态输入框：与单元格同宽，避免 EP 默认 100% 宽度把列撑变形 */
  :deep(.el-table__cell .el-input),
  :deep(.el-table__cell .el-input-number),
  :deep(.el-table__cell .el-select),
  :deep(.el-table__cell .el-textarea) {
    width: 100%;
    max-width: 100%;
  }
  /* 编辑模式下整行不再像「可点定位」那样带手型提示 */
  &.is-editing :deep(.el-table__row) {
    cursor: default;
  }
}
</style>
