<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
/*
 * 元数据记录编辑
 *   左 = 元数据浏览树（后端 GET /platform/metadata/tree 直接返回「产品类别 → 任务（资源）」递归树）
 *   右 = 勾选资源时展示它们全部表的元数据属性记录（AttributeTable，数据源 metadata-attributes）；
 *        点类别卡片同样只对已勾选资源生效；零勾选时右栏保持空态。
 *
 * 勾选与点击（用户 2026-11-05 口径，替代 11-04 的「点击与勾选完全分开」）：
 *   勾选 = 画（把资源挂到地图上，右栏表格跟着勾选集合走）；
 *   点击 = 看，但**只对已勾选节点生效**（聚焦镜头、切右栏），绝不改勾选状态；
 *   未勾选节点点击不响应：不切右栏、不聚焦、不移动高亮，也不兜底打接口取范围。
 */
import { Document, FolderOpened, Search, Location, Picture, Grid, Memo } from '@element-plus/icons-vue';
import { getMetadataBrowseTree, type MetadataTreeNode } from '@/api/product-manage/platform/metadata-browse';
import { getResourceMetadataLayer } from '@/api/product-manage/platform/metadata-browse';
import { toTileUrl } from '@/api/product-manage/platform/metadata-tiles';
import { mountVectorTileLayer, unmountVectorTileLayer, restyleVectorTileLayer } from '@/views/product-manage/shared/map/vector-tile-layer';
import { mountedCategoryNames, claimMountedCategoryNames, releaseMountedCategoryNames } from '@/views/product-manage/shared/map/query/state';
import { useMap } from '@/views/product-manage/shared/map/use-map';
import i18n from '@/lang/index';
const t = (key: string) => i18n.global.t(key);
import { useTreeHost } from '@/views/product-manage/shared/tree-host';
import { useProductPalette } from '@/views/product-manage/shared/store';
import { injectCategoryRoot, scopeTreeByRoot } from '@/views/product-manage/shared/category-root';
import AttributeTable from './attribute-table.vue';
import DetailPage from '../../resource-detail/index.vue';

defineOptions({ name: 'RecordsEdit' });

/**
 * detailMode：右侧渲染模式。
 * - false（默认）= 选中资源显示属性列表（AttributeTable），用于「元数据记录编辑」。
 * - true  = 选中的资源显示原来的资源详情组件（DetailPage / detail.vue），用于「产品线」的元数据管理。
 * WHY 用 prop 而不物理复制两份：DataBrowse 主体（树 + 地图联动）1074 行，
 * 列表版与详情版差异只在右侧那块，复制两份会埋下双份 bug。产品线由外层
 * provide('product-category-root') 识别，在 shared/metadata-manage 里自动传 detailMode。
 */
const props = withDefaults(defineProps<{ detailMode?: boolean }>(), { detailMode: false });

/**
 * 产品线语义根编码（如 attribute_primary / primary / result），由外层 provide 下发。
 * 元数据管理页没有这层上下文，inject 得到空串 → 展示完整树，行为与改造前一致。
 * 收窄落在 treeData 上（唯一渲染入口），因此右侧资源卡片、图例、地图联动都自动同源。
 */
const categoryRoot = injectCategoryRoot();

const map = useMap();
/** 类别配色表：与图例 / 数据查询页同源，保证同一类别在地图与图例上颜色一致 */
const { palette } = useProductPalette();

/** 树的「已挂载类别」共享令牌：认领后才允许写入/释放 mountedCategoryNames（见 query/state.ts 的 owner 机制） */
const treeOwner = Symbol('records-edit-mounted-categories');
claimMountedCategoryNames(treeOwner);

/**
 * 树的挂载位（布局注入；独立挂载时为 null）。
 *
 * WHY 提到最前：下面「勾选集合 → 布局」的 watch 带 immediate，会在 setup 阶段立即读它；
 * 若仍留在文件后半段（树宽拖拽那一段）声明，immediate 回调会命中 TDZ 直接运行时报错。
 */
const treeHost = useTreeHost();

/* ---------------------------- 树节点 ---------------------------- */
type NodeKind = 'cat' | 'res';
interface TreeNodeVM {
  key: string;
  label: string;
  kind: NodeKind;
  categoryUid?: string;
  /**
   * 类别节点的后端类别中文名（与产品类别树的 `categoryName` 同源，也是配色表 palette 的键口径）。
   * WHY 与 label 分开存：label 优先用 displayName（可能带修饰），而图例的 palette 键来自
   * 类别接口的 categoryName，两者不保证逐字相同 —— 图例匹配时两个口径都要认，
   * 否则严格按树过滤会把所有类别滤掉、图例全空。
   */
  categoryName?: string;
  resourceUid?: string;
  dataType?: string;
  /** 资源节点状态（后端出参是中文，如「就绪」「待处理」） */
  state?: string;
  /** 资源持有的矢量图层数（契约明示 0 也保留，不能当过滤条件） */
  layerCount?: number;
  /** 资源版本号 */
  version?: number | string;
  /** 资源英文名 */
  nameEn?: string | null;
  createdAt?: string;
  updatedAt?: string;
  children?: TreeNodeVM[];
  /** 类别节点的资源计数（后端口径：整棵子树的资源数） */
  count?: number;
}

/** metadata-layer 返回的单张元数据表（只取地图渲染真正用到的字段） */
interface ResourceTableLite {
  metadataTableKey: string;
  /** 表注释；2026-11-03 起后端已不再返回，保留以兼容旧网关 */
  metadataTableComment?: string;
  /** 中文展示名（2026-11-03 实测新增，图例/提示文案优先用它） */
  displayName?: string;
  /** 图层展示名（与 displayName 同值居多，作兜底） */
  layerName?: string;
  tileTemplate?: string;
  /** 经纬度范围 [minLng, minLat, maxLng, maxLat] */
  extent2d?: number[];
}

const loading = ref(false);
/** 后端原始浏览树（类别 → 资源，最多两级语义，children 递归） */
const browseTree = ref<MetadataTreeNode[]>([]);
const currentKey = ref('');
const currentNode = ref<TreeNodeVM | null>(null);
const treeRef = ref();
const keyword = ref('');

const dataTypeLabels: Record<string, string> = { vector: pt('矢量'), raster: pt('栅格'), table: pt('表格'), text: pt('文本') };

/**
 * 后端浏览树节点 → 树节点 VM；返回 null 表示该类别子树内没有任何任务（资源），整枝丢弃。
 *
 * 剪枝只针对**类别**：契约明示没有矢量图层的资源仍要保留在树中（layerCount=0），
 * 所以资源节点一个都不能丢，否则用户点不到该任务。
 * 判定用「子树内实际资源节点数」而不是后端的 resourceCount —— 后者是聚合口径，
 * 一旦后端口径变化（直挂 vs 整棵子树），剪枝边界就会跟着漂。
 */
function toTreeNode(n: MetadataTreeNode): TreeNodeVM | null {
  const isRes = n.nodeType === 'resource';
  if (isRes) {
    return {
      key: `res:${n.uid}`,
      label: n.displayName || n.categoryName || n.uid,
      kind: 'res',
      categoryUid: n.categoryUid,
      resourceUid: n.uid,
      dataType: n.dataType,
      state: n.state,
      layerCount: n.layerCount ?? 0,
      version: n.version,
      nameEn: n.nameEn,
      createdAt: n.createdAt,
      updatedAt: n.updatedAt
    };
  }
  const children = (n.children ?? []).map(toTreeNode).filter((c): c is TreeNodeVM => !!c);
  // 剪枝：自身无资源、子级也无资源的类别整枝丢弃，只展示有任务的产品类型
  if (!children.length) return null;
  return {
    key: `cat:${n.uid}`,
    label: n.displayName || n.categoryName || n.uid,
    kind: 'cat',
    categoryUid: n.uid,
    categoryName: n.categoryName,
    // 计数按剪枝后的实际资源数展示，避免出现「徽标 3 个但卡片只有 0 个」的自相矛盾
    count: countResources(children),
    children
  };
}

/** 统计一棵子树里的资源节点数（剪枝与徽标共用同一口径） */
function countResources(nodes: TreeNodeVM[]): number {
  let total = 0;
  for (const node of nodes) {
    if (node.kind === 'res') total += 1;
    else total += countResources(node.children ?? []);
  }
  return total;
}

/**
 * 树的展示数据：后端完整层级 → 按产品线根收窄 → 只保留「子树里有任务」的分支。
 *
 * 后端把整个产品分类体系都返回（实测 91 个类别 / 5 个资源），
 * 原样渲染会让用户在一屏空类别里翻找；元数据浏览的使用场景是「找任务」，
 * 空类别没有可点内容，故在视图层剪掉。数据仍以后端为准，不做任何增补。
 *
 * WHY 先按根收窄再剪枝：`/platform/metadata/tree` 实测不响应任何根过滤参数
 * （categoryRoot / productCategoryRoot / categoryKey / categoryUid 全被忽略），
 * 只能前端裁剪。若先剪枝后收窄，收窄命中的子树已是剪枝后的结构，逻辑上等价，
 * 但顺序上先收窄意图更清楚：范围由产品线决定，剪枝只负责去掉空类别。
 */
const treeData = computed<TreeNodeVM[]>(() => {
  const scoped = scopeTreeByRoot(browseTree.value, categoryRoot);
  return scoped.map(toTreeNode).filter((n): n is TreeNodeVM => !!n);
});

/**
 * 把「实际挂载（勾选）资源所属的类别」同步给图例（经 queryState 共享）。
 *
 * WHY 不是「树上出现过的类别」：地图只渲染用户在左侧树勾选的资源
 * （checkedKeys → syncTileLayers 上图链路），未勾选的类别在地图上根本没有数据，
 * 图例若列出来会自相矛盾。故图例口径 = 勾选资源所属的类别。
 *
 * 取值来源：勾选节点里挑出资源节点（类别节点展开成其全部子资源），
 * 每个资源节点取它所属类别的**两个口径名**——`label`（树上看到的字样）
 * 与 `categoryName`（后端类别名 / palette 配色键）——都收进集合，保证图例严格
 * 按 palette 键匹配时不会因为两个口径不一致而漏列类别。
 * 名称口径见 toTreeNode 处的说明（displayName 与点位色键可能不同）。
 */
function collectMountedCategoryNames(nodes: TreeNodeVM[], keys: Set<string>, acc: Set<string>) {
  const expand = (n: TreeNodeVM) => {
    if (n.kind === 'res') {
      // 资源节点：收集其所属类别的两个口径名
      const parent = findByKey(nodes, `cat:${n.categoryUid}`);
      if (parent) {
        if (parent.label) acc.add(parent.label);
        if (parent.categoryName && parent.categoryName !== parent.label) acc.add(parent.categoryName);
      }
    } else if (n.children?.length) {
      // 类别节点：展开成子树内的资源去收集（避免按类别勾选时漏算）
      n.children.forEach(expand);
    }
  };
  for (const key of keys) {
    const node = findByKey(nodes, key);
    if (node) expand(node);
  }
}

function filterNode(value: string, data: TreeNodeVM) {
  if (!value) return true;
  return data.label.toLowerCase().includes(value.toLowerCase());
}

watch(keyword, (val) => treeRef.value?.filter(val));

/**
 * 按节点类型 / 资源数据类型选图标与颜色。
 * 配色沿用 detail.vue 文件图标的语义色（矢量青 / 栅格蓝 / 表格绿 / 文本灰），
 * 让「树上的资源」与「详情里的文件」同一类数据看起来是同一个东西。
 */
function nodeIconMeta(data: TreeNodeVM): { icon: any; color: string } {
  if (data.kind === 'cat') return { icon: FolderOpened, color: 'var(--el-color-primary)' };
  switch (String(data.dataType ?? '').toLowerCase()) {
    case 'vector':
      return { icon: Location, color: '#13a8a8' };
    case 'raster':
      return { icon: Picture, color: '#3f8cff' };
    case 'table':
      return { icon: Grid, color: '#2ba471' };
    case 'text':
      return { icon: Memo, color: '#909399' };
    default:
      return { icon: Document, color: 'var(--el-text-color-secondary)' };
  }
}

function findByKey(list: TreeNodeVM[], key: string): TreeNodeVM | null {
  for (const n of list) {
    if (n.key === key) return n;
    const hit = n.children ? findByKey(n.children, key) : null;
    if (hit) return hit;
  }
  return null;
}

watch(currentKey, (k) => {
  if (!k) {
    currentNode.value = null;
    return;
  }
  // onNodeClick 已直接赋值时不再覆盖；仅当 key 与当前节点不一致时回查（如 setCurrentKey 程序化选中）
  if (currentNode.value?.key !== k) currentNode.value = findByKey(treeData.value, k);
});

/* ---------------------------- 加载 ---------------------------- */
/**
 * 只打一个接口：GET /platform/metadata/tree。
 *
 * 树里每个 resource 节点已经带 displayName / dataType / state / layerCount / version / 时间，
 * 右侧卡片所需字段全部够用，故不再额外拉 listResources() 补数据。
 * 失败时不加 x-best-effort：浏览树是页面主体，失败必须让用户看见（由全局拦截器提示），
 * 这里只负责清空树、走 el-empty 空态，避免拿半截旧数据误导。
 */
async function loadData() {
  loading.value = true;
  try {
    const res = await getMetadataBrowseTree();
    browseTree.value = res?.data?.items ?? [];
  } catch {
    browseTree.value = [];
  } finally {
    loading.value = false;
  }
}

/* ---------------------- 右侧：类别下资源卡片 ---------------------- */
/**
 * 选中类别时，右侧展示该类别**整棵子树**下的资源节点。
 *
 * 数据源是树本身（不是资源列表）：只有树里挂着的资源才属于这个类别，
 * 用 listResources 按 categoryUid 再查一遍反而会混进后端树里没挂上来的资源。
 */
const catResources = computed<TreeNodeVM[]>(() => {
  const n = currentNode.value;
  if (!n || n.kind !== 'cat') return [];
  const out: TreeNodeVM[] = [];
  const walk = (node: TreeNodeVM) => {
    if (node.kind === 'res' && node.resourceUid) out.push(node);
    node.children?.forEach(walk);
  };
  walk(n);
  return out;
});

function selectResource(r: TreeNodeVM) {
  // 卡片点击与树节点点击同一口径：仅已勾选资源才生效（用户 2026-11-05）。
  // 否则在 detailMode 下点未勾选卡片会绕过 onNodeClick 守卫，直接把右栏切到该资源详情。
  if (!r.resourceUid || !isNodeChecked(r)) return;
  const key = 'res:' + r.resourceUid;
  treeRef.value?.setCurrentKey?.(key);
  currentKey.value = key;
  currentNode.value = findByKey(treeData.value, key);
}

/**
 * 按 resourceUid 选中树上的资源节点（父组件调用，如数据查询页点选地图命中要素）。
 *
 * WHY 走「先算 key 再回查树」而不是直接塞一个构造出来的节点：
 * 右侧卡片 / 属性表消费的是树节点 VM（带 layerCount / version / state 等），
 * 自己拼一个假节点会丢掉这些字段；树上找不到（该资源不在浏览树里）时静默忽略。
 */
function selectByResourceUid(uid?: string) {
  if (!uid) return;
  const key = 'res:' + uid;
  const node = findByKey(treeData.value, key);
  if (!node) return;
  treeRef.value?.setCurrentKey?.(key);
  currentKey.value = key;
  currentNode.value = node;
}

defineExpose({ selectByResourceUid });

/* ---------------------- 树勾选 → 瓦片图层 ---------------------- */
/**
 * 树上的勾选节点（el-tree show-checkbox 的 key 集合）。
 *
 * WHY 与「当前选中节点」分开：选中是导航语义（右栏看谁），勾选是渲染语义（地图上画谁）。
 * 两者混在一个状态里会让「看一眼别的资源」顺手把地图图层换掉，多选叠加更无从实现。
 */
const checkedKeys = ref<string[]>([]);

/**
 * 把「实际挂载（勾选）资源所属的类别」同步给图例（经 queryState 共享）。
 * 见 collectMountedCategoryNames 上方的说明。放在 checkedKeys 声明之后，
 * 因为 watch 带 immediate 会在 setup 阶段立即读取 checkedKeys。
 */
watch(
  [treeData, checkedKeys],
  ([nodes, keys]) => {
    const acc = new Set<string>();
    collectMountedCategoryNames(nodes, new Set(keys), acc);
    mountedCategoryNames.value = acc;
  },
  { immediate: true }
);
/** 已挂到地图上的瓦片图层 key（`${resourceUid}:${tableKey}`），用于增量增删 */
const mountedTileKeys = ref<string[]>([]);
/** 每张元数据表的可用最大 zoom：实测服务端 z≥14 返回 404，声明 maxzoom 让 maplibre 停止取瓦片 */
const TILE_MAX_ZOOM = 13;

/**
 * 兜底色：类别配色表（palette）里没有该类别时才用，多张表按序号区分。
 * 命中 palette 的类别一律用类别色 —— 与图例 / 数据查询页同源，避免同一类别在两处颜色不同。
 */
const TILE_COLORS = ['#2563a8', '#13a8a8', '#e6a23c', '#8b5cf6', '#2ba471', '#f56c6c'];

/**
 * 每张表的经纬度范围（来自 metadata-layer 的 extent2d）。
 * WHY 另存一份：maplibre 的 querySourceFeatures 只返回**当前视口内已加载瓦片**的要素，
 * 勾选后视野还停在旧位置时它常常什么也查不到；extent2d 是后端给的权威范围，用作聚焦兜底。
 */
const tileExtents = ref<Record<string, number[]>>({});

/**
 * 勾选一个类别时，把它的整棵子树里的资源 uid 收集出来。
 *
 * WHY 即便树已开父子联动（check-strictly=false）仍要显式展开：联动只解决「勾父 = 后代全勾」
 * 的**勾选框状态**，而 checkedKeys 里躺着的是类别 key（`cat:xxx`），不是资源的 resourceUid，
 * 直接当 uid 用会挂出一张不存在的图层。展开成资源集合是喂给瓦片图层的唯一口径。
 * 父子同时出现在集合里时由 Set 去重，不会重复上图。
 */
function collectResourceUids(node: TreeNodeVM): string[] {
  const out: string[] = [];
  const walk = (n: TreeNodeVM) => {
    if (n.kind === 'res' && n.resourceUid) out.push(n.resourceUid);
    n.children?.forEach(walk);
  };
  walk(node);
  return out;
}

/**
 * resourceUid → 所属类别的中文名（palette 的键口径）。
 *
 * WHY 由树推导：res 节点只带 categoryUid 不带中文名，而 palette / 图例用的都是
 * categoryName；沿树向下继承最近祖先类别节点的 categoryName，零额外请求，
 * 且与图例过滤同源，不会出现两套口径。
 */
function buildCategoryOf(): Map<string, string> {
  const out = new Map<string, string>();
  const walk = (n: TreeNodeVM, cat?: string) => {
    const name = n.kind === 'cat' ? (n.categoryName ?? cat) : cat;
    if (n.kind === 'res' && n.resourceUid && name) out.set(n.resourceUid, name);
    n.children?.forEach((c) => walk(c, name));
  };
  treeData.value.forEach((n) => walk(n));
  return out;
}

/**
 * 每个资源的元数据表清单缓存（resourceUid → tables）。
 *
 * WHY 必须缓存：勾选/取消勾选都会触发 syncTileLayers，而「取消勾选」只是要把已挂的图层卸掉，
 * 剩余勾选项的表清单早就拉过了；不缓存就会把**没变化的资源**再请求一遍，
 * 表现为「取消选中也会打接口」。缓存命中即零请求。
 * 底图切换（setStyle）时图层被清空需要重挂，但表清单没变，同样走缓存。
 */
const resourceTablesCache = new Map<string, ResourceTableLite[]>();

/**
 * 取某个资源的元数据表清单（命中缓存则零请求）。
 *
 * WHY 单独抽出来：勾选要挂图层、点击要算聚焦范围，两条路径都需要这份清单；
 * 各自写一遍会漏掉缓存的「失败也缓存空数组」分支，让拉失败的资源被反复重试。
 */
async function ensureResourceTables(uid: string): Promise<ResourceTableLite[]> {
  const hit = resourceTablesCache.get(uid);
  if (hit) return hit;
  try {
    const res = await getResourceMetadataLayer(uid);
    const tables = (res?.data?.metadataTables ?? []) as ResourceTableLite[];
    resourceTablesCache.set(uid, tables);
    return tables;
  } catch {
    // 该资源没有元数据表（40404）或拉取失败：缓存空数组，避免反复重试打接口
    resourceTablesCache.set(uid, []);
    return [];
  }
}

/**
 * 同步序号：勾选/取消勾选会连续触发多次 sync，异步请求返回时可能已经不是最新一轮。
 * 只有最新一轮允许挂载/卸载，避免「取消后又被上一轮的 await 挂回来」。
 */
let syncToken = 0;

/**
 * 勾选变化 → 同步瓦片图层。
 *
 * 流程：勾选节点里挑出资源节点（类别节点展开成其全部子资源）→ **仅对未缓存的资源**
 * 拉 metadata-layer 拿表清单与 tileTemplate → 对每张表调 mountVectorTileLayer；
 * 取消勾选的资源把它的所有表卸掉（纯本地操作，不发请求）。
 *
 * CONSTRAINT 不在这里清空全部图层：勾选是增量的，全量重建会让未勾选的图层闪一下。
 */
async function syncTileLayers() {
  const m = map.mapInstance.value;
  if (!m) return;

  // 勾选集合：资源节点直接用；类别节点展开成子树内全部资源（去重，父子同时勾选也只算一次）
  const uidSet = new Set<string>();
  for (const key of checkedKeys.value) {
    const n = findByKey(treeData.value, key);
    if (!n) continue;
    if (n.kind === 'res' && n.resourceUid) uidSet.add(n.resourceUid);
    else if (n.kind === 'cat') for (const uid of collectResourceUids(n)) uidSet.add(uid);
  }

  const token = ++syncToken;

  // 只拉缓存里没有的资源；已缓存的直接复用，取消勾选场景这里一次请求都不会发
  await Promise.all([...uidSet].map((uid) => ensureResourceTables(uid)));

  // 本轮已被更新的 sync 取代：放弃挂载，交给最新一轮处理
  if (token !== syncToken) return;

  // 由勾选集合推导「应该挂在地图上的表 key」
  // 类别色优先（与图例 / 查询页同源），palette 未命中才退回兜底色
  const categoryOf = buildCategoryOf();
  const wanted = new Set<string>();
  for (const uid of uidSet) {
    const tables = resourceTablesCache.get(uid) ?? [];
    const categoryColor = palette[categoryOf.get(uid) ?? ''];
    tables.forEach((t, i) => {
      const key = `${uid}:${t.metadataTableKey}`;
      wanted.add(key);
      // 记录范围供聚焦兜底（extent2d 是 [minLng, minLat, maxLng, maxLat]）
      if (Array.isArray(t.extent2d) && t.extent2d.length === 4) tileExtents.value[key] = t.extent2d;
      // 已挂载的跳过，避免重复 addSource
      if (mountedTileKeys.value.includes(key)) return;
      mountVectorTileLayer(m, {
        key,
        url: toTileUrl(uid, t.metadataTableKey, t.tileTemplate),
        label: t.displayName || t.layerName || t.metadataTableComment || t.metadataTableKey,
        color: categoryColor ?? TILE_COLORS[i % TILE_COLORS.length],
        maxzoom: TILE_MAX_ZOOM
      });
    });
  }

  // 卸掉不再需要的（取消勾选的资源，或该资源已没有对应表）：纯本地卸载，不触发任何请求
  const added = [...wanted].some((key) => !mountedTileKeys.value.includes(key));
  for (const key of [...mountedTileKeys.value]) {
    if (!wanted.has(key)) unmountVectorTileLayer(m, key);
  }
  mountedTileKeys.value = [...wanted];

  // 只有**新挂载**图层时才聚焦：取消勾选只清图层，不甩镜头
  if (added) focusTileLayers();
}

/**
 * 把镜头套到一组经纬度包围盒上（[minLng, minLat, maxLng, maxLat]）。
 *
 * WHY 抽出来：勾选后聚焦（focusTileLayers）与点击未上图资源时的聚焦（focusNodeLayers）
 * 都要用同一套合并逻辑；写两份就会有一份忘了过滤长度不是 4 的坏数据，镜头被甩到 (0,0)。
 */
function fitExtentBoxes(boxes: number[][]) {
  const m = map.mapInstance.value;
  if (!m) return;
  const valid = boxes.filter((b) => Array.isArray(b) && b.length === 4 && b.every((v) => Number.isFinite(v)));
  if (!valid.length) return;
  const minLng = Math.min(...valid.map((b) => b[0]));
  const minLat = Math.min(...valid.map((b) => b[1]));
  const maxLng = Math.max(...valid.map((b) => b[2]));
  const maxLat = Math.max(...valid.map((b) => b[3]));
  m.fitBounds(
    [
      [minLng, minLat],
      [maxLng, maxLat]
    ],
    { padding: 60, maxZoom: TILE_MAX_ZOOM, duration: 600 }
  );
}

/**
 * 聚焦到指定瓦片图层（默认 = 当前已勾选的全部图层）。
 *
 * 优先用 maplibre 自己算的瓦片要素包围盒（querySourceFeatures 拿已加载瓦片里的要素）；
 * 瓦片还没到位时退回 metadata-layer 的 extent2d（后端给的经纬度范围），
 * 两者都没有就保持当前视野不动 —— 不把镜头甩到 (0,0)。
 *
 * keys：要聚焦的图层 key。WHY 要可传：点击某个节点时只想看**这一个节点**的范围，
 * 而「勾选后聚焦」看的是全部勾选；不传就退化成全量，点谁都会把镜头拉到所有图层上。
 */
async function focusTileLayers(keys: string[] = mountedTileKeys.value) {
  const m = map.mapInstance.value;
  // 只要求地图就绪：方案 B（extent2d）不需要 maplibre 的 utils，早期版本因为一并要求 utils
  // 导致工具未初始化时整条聚焦链路静默失效，点击树节点看着毫无反应。
  if (!m || !keys.length) return;

  // 等一帧让新加的 source 进入 style，再等瓦片 idle（最多 1.2s，超时用 extent2d 兜底）
  await nextTick();
  await new Promise<void>((resolve) => {
    const timer = setTimeout(() => {
      m.off('idle', onIdle);
      resolve();
    }, 1200);
    function onIdle() {
      clearTimeout(timer);
      m.off('idle', onIdle);
      resolve();
    }
    m.on('idle', onIdle);
  });

  // 方案 A：取已加载瓦片里要素的真实范围
  const coords: [number, number][] = [];
  for (const key of keys) {
    const srcId = `mvt-src-${key.replace(/[^a-zA-Z0-9_-]/g, '_')}`;
    if (!m.getSource(srcId)) continue;
    try {
      for (const f of m.querySourceFeatures(srcId)) {
        const g: any = (f as any).geometry;
        if (!g) continue;
        const walk = (c: any) => {
          if (typeof c?.[0] === 'number') coords.push(c as [number, number]);
          else if (Array.isArray(c)) c.forEach(walk);
        };
        walk(g.coordinates);
      }
    } catch {
      /* source 尚未就绪：走方案 B */
    }
  }

  if (coords.length) {
    let minLng = coords[0][0];
    let maxLng = minLng;
    let minLat = coords[0][1];
    let maxLat = minLat;
    for (const [lng, lat] of coords) {
      if (lng < minLng) minLng = lng;
      if (lng > maxLng) maxLng = lng;
      if (lat < minLat) minLat = lat;
      if (lat > maxLat) maxLat = lat;
    }
    m.fitBounds(
      [
        [minLng, minLat],
        [maxLng, maxLat]
      ],
      { padding: 60, maxZoom: TILE_MAX_ZOOM, duration: 600 }
    );
    return;
  }

  // 方案 B：metadata-layer 的 extent2d（[minLng, minLat, maxLng, maxLat]）
  fitExtentBoxes(keys.map((key) => tileExtents.value[key]));
}

/**
 * 勾选事件：用 getCheckedKeys 统一取勾选集合。
 *
 * 父子联动（check-strictly=false）下该集合只含「全选」节点：
 * - 勾父类别 → 后代全部变全选，父自身也在集合里；
 * - 子资源全勾 → 父类别自动升为全选；
 * - 部分子被勾 → 父是**半选**，不出现在 getCheckedKeys 里，故不会把未勾的资源误上图。
 */
function onCheck() {
  checkedKeys.value = (treeRef.value?.getCheckedKeys?.() ?? []) as string[];
  syncTileLayers();
}

/* ---------------------- 勾选集合 → 右栏表格 ---------------------- */
/**
 * 勾选集合推导出的资源节点（**按树序**排列）。
 *
 * WHY 不直接遍历 checkedKeys：勾选事件的先后顺序是随机的（先勾叶子再勾父、先勾第三个再勾第一个），
 * 页签顺序若跟着勾选顺序走，用户每次勾选都会看到右栏 tab 条重新洗牌。
 * 统一回到树上从上到下的顺序，页签才稳定。
 *
 * WHY 类别要展开：勾父类别时 checkedKeys 里是 `cat:xxx`，不展开就一个资源都收不到。
 */
const checkedResourceNodes = computed<TreeNodeVM[]>(() => {
  const uidSet = new Set<string>();
  const collect = (n: TreeNodeVM) => {
    if (n.kind === 'res' && n.resourceUid) uidSet.add(n.resourceUid);
    n.children?.forEach(collect);
  };
  for (const key of checkedKeys.value) {
    const n = findByKey(treeData.value, key);
    if (n) collect(n);
  }
  if (!uidSet.size) return [];

  const out: TreeNodeVM[] = [];
  const walk = (nodes: TreeNodeVM[]) => {
    for (const n of nodes) {
      if (n.kind === 'res') {
        if (n.resourceUid && uidSet.has(n.resourceUid)) out.push(n);
      } else walk(n.children ?? []);
    }
  };
  walk(treeData.value);
  return out;
});

/** 勾选资源的 uid 列表（喂给 AttributeTable 的 resourceUids） */
const checkedResourceUids = computed(() => checkedResourceNodes.value.map((n) => n.resourceUid!).filter(Boolean));

/**
 * 把「已勾选资源数」同步给布局（tree-host 契约的 checkedCount）。
 *
 * WHY 布局需要它：零勾选时下方详情区只有一块空表却占着半屏高度，地图被压成一半；
 * 布局据这个计数整块收起详情区、让地图独占右列，勾选后自动展开（用户 2026-11-06 口径）。
 * 用 watch 而不是在 onCheck 里赋值：勾选集合有两条写入路径 —— onCheck（用户勾选）与
 * 底图 setStyle 后 syncTileLayers 的重挂，watch 覆盖全部来源且不需要各自维护。
 * 独立挂载（无布局上下文）时 treeHost 为 null，这里自动跳过。
 */
watch(
  () => checkedResourceUids.value.length,
  (n) => {
    if (treeHost) treeHost.checkedCount.value = n;
  },
  { immediate: true }
);

/** uid → 资源名：多资源时给页签加前缀，避免同名表分不清属于哪个资源 */
const checkedResourceNames = computed<Record<string, string>>(() => {
  const acc: Record<string, string> = {};
  for (const n of checkedResourceNodes.value) {
    if (n.resourceUid) acc[n.resourceUid] = n.label;
  }
  return acc;
});

/**
 * 右栏属性表要展示的资源集合：**只认勾选集合**（用户 2026-11-05 口径）。
 *
 * WHY 不再回落到「当前点中的资源」：点击节点的功能已收敛到「仅已勾选节点生效」，
 * 未勾选节点点击不会更新 currentNode；若属性表仍按 currentNode 回落，就会出现
 * 「没勾任何东西、右栏却因初始选中的节点冒出一张表」这种与勾选语义不一致的展示。
 * 勾选 = 画 = 看，右栏与地图始终是同一份数据。
 */
const tableResourceUids = computed(() => checkedResourceUids.value);
const tableResourceNames = computed(() => checkedResourceNames.value);
/** uid → 类别色：与地图瓦片/图例同源（uid→categoryName→palette），供属性表高亮用要素自身颜色 */
const tableResourceColors = computed(() => {
  const categoryOf = buildCategoryOf();
  return Object.fromEntries(tableResourceUids.value.map((uid) => [uid, palette[categoryOf.get(uid) ?? ''] ?? '']));
});

/* ---------------------- 点击 → 仅已勾选节点生效 ---------------------- */
/**
 * 点击树节点的功能（切右栏 + 聚焦镜头）**只在该节点已被勾选时生效**（用户 2026-11-05 口径）。
 *
 * WHY 以「已勾选」为前提：勾选 = 把资源挂到地图上（画），点击 = 看已画的内容（聚焦 / 切右栏）。
 * 没勾选的节点在地图上本就没有数据，点它只会触发一次无意义的聚焦（甚至兜底打接口取范围），
 * 看起来像「点了有反应但什么也没看到」，反而更困惑。收敛到已勾选节点后，
 * 「先勾想看的、再点它聚焦」成为唯一路径，未勾选节点点击完全不响应。
 *
 * 判定口径与「上图 / 右栏表格」同源：checkedResourceUids 是 checkedKeys 展开后的资源集合，
 * 资源节点直接比对 uid；类别节点只要子树里有任一资源已勾选就算（覆盖勾父类别 / 半选 / 直勾资源）。
 * 不走 getCheckedKeys：那是「全选」口径，半选类别会被漏掉。
 */
function isNodeChecked(node: TreeNodeVM): boolean {
  const checked = new Set(checkedResourceUids.value);
  if (!checked.size) return false;
  if (node.kind === 'res') return !!node.resourceUid && checked.has(node.resourceUid);
  return collectResourceUids(node).some((uid) => checked.has(uid));
}

function onNodeClick(data: TreeNodeVM) {
  // 未勾选：不切右栏、不聚焦，也不让 el-tree 把高亮挪过去（保持「点了没反应」的视觉一致）
  if (!isNodeChecked(data)) {
    treeRef.value?.setCurrentKey?.(currentKey.value);
    return;
  }
  currentKey.value = data.key;
  // 直接用事件里的节点对象驱动右侧，避免 findByKey 在重算后的新树上找不到同 key 节点
  currentNode.value = data;
  focusNodeLayers(data);
}

/**
 * 聚焦到某个（已勾选）树节点对应的图层。
 *
 * 只有已勾选节点才会走到这里（onNodeClick 的 isNodeChecked 守卫），故其资源必然已上图；
 * 分两种情况：
 *   1. 图层已挂好 → 聚焦这些已存在的图层（「点谁看谁」）；
 *   2. 勾选后 syncTileLayers 还在异步上图（或底图刚切换）→ mounted 暂时为空，
 *      用 metadata-layer 的 extent2d 把镜头带到它的范围兜底，仍**不挂图层**。
 * 表清单走 resourceTablesCache，勾选时已缓存，这里不会重复打接口。
 */
async function focusNodeLayers(node: TreeNodeVM) {
  const uids = node.kind === 'res' ? (node.resourceUid ? [node.resourceUid] : []) : collectResourceUids(node);
  if (!uids.length) return;

  const uidSet = new Set(uids);
  const mounted = mountedTileKeys.value.filter((k) => uidSet.has(tileKeyUid(k)));
  if (mounted.length) {
    await focusTileLayers(mounted);
    return;
  }

  // 未上图：只取范围，不挂图层
  const boxes: number[][] = [];
  await Promise.all(
    uids.map(async (uid) => {
      await ensureResourceTables(uid);
      for (const t of resourceTablesCache.get(uid) ?? []) {
        if (Array.isArray(t.extent2d) && t.extent2d.length === 4) boxes.push(t.extent2d);
      }
    })
  );
  fitExtentBoxes(boxes);
}

/** 瓦片图层 key（`${resourceUid}:${tableKey}`）里取出 resourceUid */
function tileKeyUid(key: string): string {
  const i = key.lastIndexOf(':');
  return i > 0 ? key.slice(0, i) : key;
}

onBeforeUnmount(() => {
  // 释放「已挂载类别」共享令牌：仅当仍是持有者时清零（见 query/state.ts 的 owner 机制），
  // 切 tab 新面板已认领时不会误清新面板写入的类别集
  releaseMountedCategoryNames(treeOwner);
  // 瓦片图层挂在 map 单例上，组件卸载不会自动清理，必须显式卸掉
  const m = map.mapInstance.value;
  if (m) {
    for (const key of mountedTileKeys.value) unmountVectorTileLayer(m, key);
  }
  mountedTileKeys.value = [];
});

/**
 * 配色方案切换 → 已挂载瓦片层重涂。
 *
 * WHY 需要：瓦片颜色在 mount 时写死进 maplibre 的 paint 属性，而图例直接读响应式 palette
 * 实时变色；不重涂就会出现「图例已变色、地图还是旧色」的不一致。只对 palette 命中的
 * 类别重涂，兜底色（TILE_COLORS）层保持不动。palette 是 reactive 对象，watch 默认深监听。
 */
watch(palette, () => {
  const m = map.mapInstance.value;
  if (!m) return;
  const categoryOf = buildCategoryOf();
  for (const key of mountedTileKeys.value) {
    const color = palette[categoryOf.get(key.slice(0, key.lastIndexOf(':'))) ?? ''];
    if (color) restyleVectorTileLayer(m, key, color);
  }
});

/* 底图切换会 setStyle 清空所有 source/layer：版本号变化后按当前勾选重挂瓦片 */
watch(
  () => map.styleVersion.value,
  () => {
    mountedTileKeys.value = [];
    syncTileLayers();
  }
);

onMounted(async () => {
  await loadData();
  // 不再默认选中第一个节点（用户 2026-11-05 口径）：零勾选时 currentNode 保持 null、右栏为空态。
  // 旧逻辑「进页面先选中顶层类别、右栏直接铺开卡片」等于让未勾选节点凭空触发了功能，
  // 与「仅已勾选节点点击才生效」冲突；先勾选、再点已勾选节点才会在右栏展示内容 / 聚焦镜头。
  await nextTick();
  fitTreeWidth();
});

/* ---------------------- 树宽度拖拽 ---------------------- */
/**
 * 在布局里（Layout 注入了树挂载位）时：树被 Teleport 到左侧独立列，
 * 高度撑满整个内容区（用户要求「地图和列表模式下都占满容器」），宽度与拖拽由布局接管 ——
 * 本组件不再自绘树列与分隔条。
 * 独立挂载时（如 __debug 页）回落为原「内联树 + 自绘分隔条」布局。
 */
const pageRef = ref<HTMLElement>();
const hosted = computed(() => !!treeHost?.el.value);
/** Teleport 目标：布局的左侧树列（宿主常驻渲染，首帧后即有值）；独立挂载时退回 body 并禁用搬移 */
const treeTarget = computed(() => treeHost?.el.value ?? 'body');
const treeWidth = treeHost ? treeHost.width : ref(320);
const TREE_MIN = 200;
const TREE_MAX = 520;
let resizeStartX = 0;
let resizeStartW = 0;
function startResize(e: PointerEvent) {
  resizeStartX = e.clientX;
  resizeStartW = treeWidth.value;
  window.addEventListener('pointermove', onResize);
  window.addEventListener('pointerup', stopResize, { once: true });
}
function onResize(e: PointerEvent) {
  treeWidth.value = Math.min(TREE_MAX, Math.max(TREE_MIN, resizeStartW + (e.clientX - resizeStartX)));
}
function stopResize() {
  window.removeEventListener('pointermove', onResize);
}
function fitTreeWidth() {
  // 树宽由布局按内容区宽度分配并持久化，这里只在独立挂载时按容器 26% 自适应
  if (hosted.value) return;
  const total = pageRef.value?.clientWidth ?? 0;
  if (!total) return;
  treeWidth.value = Math.min(TREE_MAX, Math.max(TREE_MIN, Math.round(total * 0.26)));
}
onMounted(() => window.addEventListener('resize', fitTreeWidth));
onBeforeUnmount(() => window.removeEventListener('resize', fitTreeWidth));

function fmtTime(v?: string) {
  if (!v) return '-';
  const d = new Date(v.split(' ').join('T').split('+00').join('+00:00'));
  return isNaN(d.getTime()) ? v : d.toLocaleString();
}
</script>

<template>
  <div class="db-page">
    <!-- 左：产品类型类别树 + 资源叶子。
         布局注入了树挂载位时 Teleport 到左侧独立列（高度撑满整个内容区）；
         未注入（独立挂载，如 __debug 页）时 Teleport 退化为就地渲染，仍是原「内联树」布局。 -->
    <Teleport :to="treeTarget" :disabled="!hosted">
      <aside class="db-tree" :class="{ 'is-hosted': hosted }" :style="hosted ? undefined : { flexBasis: treeWidth + 'px' }">
        <div class="db-tree__head">
          <el-input v-model="keyword" :placeholder="t('common.searchResourceCategory')" clearable :prefix-icon="Search" />
        </div>
        <div class="db-tree__body">
          <!-- 父子勾选联动（check-strictly=false）：勾父类别 → 子树资源全勾；子资源全勾 → 父升为全选；
               子资源部分勾 → 父为半选（不进入 getCheckedKeys，故不会把未勾的资源误上图）。
               WHY 不给单独勾某个子而父保持未勾的能力：本树的勾选语义就是「这批资源上图」，
               类别与资源脱钩会让用户无法判断自己到底选了哪些（详见 collectResourceUids 的注释）。

               check-on-click-leaf 必须显式关掉：el-tree 该属性**默认 true**，
               只关 check-on-click-node 仍会出现「点资源叶子就顺手勾上」——勾选是「上图」的决定，
               不能由「点一下看看」触发（用户 2026-11-04 明确要求点击与勾选分开）。 -->
          <el-tree
            ref="treeRef"
            :data="treeData"
            node-key="key"
            :props="{ label: 'label', children: 'children' }"
            :indent="14"
            :default-expand-all="true"
            :expand-on-click-node="false"
            :check-on-click-node="false"
            :check-on-click-leaf="false"
            highlight-current
            show-checkbox
            :check-strictly="false"
            :filter-node-method="filterNode"
            @node-click="onNodeClick"
            @check="onCheck"
          >
            <template #default="{ data }">
              <span class="db-node" :class="`is-${data.kind}`">
                <el-icon class="db-node__ic" :style="{ color: nodeIconMeta(data).color }"><component :is="nodeIconMeta(data).icon" /></el-icon>
                <span class="db-node__label" :title="data.label">{{ data.label }}</span>
                <span v-if="data.count" class="db-node__count">{{ data.count }}</span>
              </span>
            </template>
          </el-tree>
          <el-empty v-if="!loading && !treeData.length" description="暂无资源" :image-size="50" />
        </div>
      </aside>
    </Teleport>

    <div v-if="!hosted" class="db-split" title="拖动调整树宽度" @pointerdown.prevent="startResize" />

    <!-- 右：属性表（跟随勾选）/ 资源详情 / 类别下资源卡片；零勾选时保持空态 -->
    <section class="db-detail">
      <!-- 勾选了资源时，表格只认勾选集合：勾了 3 个资源就列出这 3 个资源的全部表，
           与地图上正挂着的图层是同一份数据（勾选 = 画 + 看）。
           WHY 不加 :key —— 勾选变化交给组件内部 watch 处理，能保住当前页签与已定位行；
           加 key 会让每次勾选都把整个组件重建一遍，页签跳回第一个、翻页与高亮全丢。 -->
      <AttributeTable
        v-if="!detailMode && tableResourceUids.length"
        class="db-detail__inner"
        :resource-uids="tableResourceUids"
        :resource-names="tableResourceNames"
        :resource-colors="tableResourceColors"
      />

      <!-- 产品线（detailMode=true）：仅点中的「已勾选」资源才展示详情（onNodeClick 守卫） -->
      <DetailPage
        v-else-if="detailMode && currentNode && currentNode.kind === 'res' && currentNode.resourceUid"
        :resource-uid="currentNode.resourceUid"
      />

      <!-- 点中「已勾选」类别 → 该类别下资源卡片（对齐 mm-grid / mm-card） -->
      <template v-else-if="currentNode && currentNode.kind === 'cat'">
        <header class="db-head">
          <div class="db-head__title">
            <el-icon class="db-head__ic"><FolderOpened /></el-icon>
            <h2>{{ currentNode.label }}</h2>
            <span class="db-head__kind">产品类别</span>
            <span class="db-grow" />
          </div>
          <div class="db-head__meta">
            <span
              >共 <b>{{ catResources.length }}</b> 个资源</span
            >
            <span v-if="currentNode.count && currentNode.count !== catResources.length" class="db-head__kind">后端计数 {{ currentNode.count }}</span>
          </div>
        </header>
        <div class="db-grid-wrap">
          <el-empty v-if="!catResources.length" description="该类别下暂无资源" :image-size="70" />
          <div v-else class="db-grid">
            <article v-for="r in catResources" :key="r.resourceUid" class="db-card" @click="selectResource(r)">
              <div class="db-card__head">
                <span class="db-card__ic"
                  ><el-icon><Document /></el-icon
                ></span>
                <div class="db-card__titles">
                  <div class="db-card__title" :title="r.label">{{ r.label }}</div>
                </div>
                <span v-if="r.version != null" class="db-card__ver" title="版本号">v{{ r.version }}</span>
              </div>
              <p class="db-card__desc" :class="{ 'is-empty': !r.layerCount }">
                {{ r.layerCount ? `该资源下有 ${r.layerCount} 个矢量图层` : '该资源暂无矢量图层' }}
              </p>
              <div class="db-card__tags">
                <span class="db-card__tag">{{ dataTypeLabels[r.dataType || ''] || r.dataType || '未分类' }}</span>
                <span class="db-card__tag is-state">{{ r.state || '-' }}</span>
              </div>
              <div class="db-card__foot">
                <span class="db-card__stat"
                  ><b>{{ r.layerCount ?? 0 }}</b> 图层</span
                >
                <span class="db-card__dot">·</span>
                <span class="db-card__stat"
                  ><b>{{ r.version != null ? r.version : '-' }}</b> 版本</span
                >
                <span class="db-grow" />
                <time class="db-card__time">{{ fmtTime(r.updatedAt || r.createdAt) }}</time>
              </div>
            </article>
          </div>
        </div>
      </template>

      <!-- 零勾选 / 未点中已勾选节点：右栏保持空态，不回落展示任何未勾选对象 -->
      <el-empty v-else class="db-hint" description="请先勾选资源，再点击已勾选的节点查看" :image-size="80" />
    </section>
  </div>
</template>

<style scoped lang="scss">
.db-page {
  display: flex;
  gap: 0;
  height: 100%;
  min-height: 0;
  // padding: 0 12px 12px;
}

/* ---------- 左树（卡片化，对齐 mm-tree）---------- */
.db-tree {
  display: flex;
  flex: 0 0 auto;
  flex-direction: column;
  min-height: 0;
  max-width: 55%;
  padding: 0;
  overflow: hidden;
  background: var(--el-bg-color);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 6px;
}
/* 被 Teleport 到布局左列时：吃满整列（宽度由布局的树列给定，高度撑满整个内容区） */
.db-tree.is-hosted {
  flex: 1 1 auto;
  width: 100%;
  max-width: none;
  height: 100%;
}
.db-tree__head {
  padding: 10px 10px 8px;
  border-bottom: 1px solid var(--el-border-color-lighter);
}
.db-tree__body {
  flex: 1;
  min-height: 0;
  padding: 6px 6px 10px;
  overflow: auto;
}

/* 节点：对齐 mm-node —— 13px，图标 15px，类别橙/资源蓝，计数徽标 */
.db-node {
  display: flex;
  align-items: center;
  gap: 6px;
  width: 100%;
  padding-right: 4px;
  font-size: 13px;
}
.db-node__ic {
  display: inline-flex;
  flex: none;
  align-items: center;
  width: 15px;
  font-size: 13px;
  color: var(--el-text-color-placeholder);
}
/* 节点图标颜色由 nodeIconMeta 按数据类型内联给出（矢量青/栅格蓝/表格绿/文本灰），此处不再统一上色 */
.db-node__label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.db-node__count {
  flex: none;
  min-width: 20px;
  padding: 0 5px;
  color: var(--el-text-color-secondary);
  font-size: 11px;
  line-height: 16px;
  text-align: center;
  background: var(--el-fill-color-light);
  border-radius: 8px;
}

:deep(.el-tree-node__content) {
  height: 30px;
  border-radius: 4px;
}
:deep(.el-tree-node.is-current > .el-tree-node__content) {
  background: var(--el-color-primary-light-9);
  .db-node__count {
    color: var(--el-color-primary);
    background: var(--el-color-primary-light-8);
  }
}

/* 分隔条：热区 9px，悬停中央亮竖线（对齐 mm-split） */
.db-split {
  position: relative;
  display: flex;
  flex: 0 0 9px;
  align-self: stretch;
  cursor: col-resize;
  touch-action: none;
}
.db-split::after {
  content: '';
  position: absolute;
  top: 50%;
  left: 50%;
  width: 2px;
  height: 34px;
  background: var(--el-color-primary);
  border-radius: 1px;
  opacity: 0;
  transform: translate(-50%, -50%);
  transition: opacity 0.15s;
}
.db-split:hover::after {
  opacity: 0.65;
}

/* ---------- 右详情（对齐 mm-detail / mm-head）---------- */
.db-detail {
  display: flex;
  flex: 1;
  flex-direction: column;
  min-width: 0;
  min-height: 0;
  overflow: hidden;
  background: var(--el-bg-color);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 6px;
}
.db-head {
  flex: none;
  box-sizing: border-box;

  /* 固定高度 68px：避免右侧标题/统计行高变化导致整卡跳动 */
  min-height: 68px;
  padding: 10px 14px 8px;
  border-bottom: 1px solid var(--el-border-color-lighter);
}
.db-head__title {
  display: flex;
  align-items: center;
  gap: 10px;
  h2 {
    max-width: 400px;
    margin: 0;
    overflow: hidden;
    color: var(--el-text-color-primary);
    font-size: 17px;
    font-weight: 600;
    letter-spacing: -0.01em;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
}
.db-head__kind {
  padding: 0 7px;
  color: var(--el-text-color-secondary);
  font-size: 11px;
  line-height: 19px;
  background: var(--el-fill-color-light);
  border-radius: 4px;
}
.db-head__ic {
  display: inline-flex;
  flex: none;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  color: var(--el-color-primary);
  font-size: 15px;
  background: var(--el-color-primary-light-9);
  border-radius: 7px;
}
.db-head__meta {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-top: 6px;
  font-size: 12px;
  color: var(--el-text-color-secondary);
}
.db-body {
  flex: 1;
  min-height: 0;
  overflow: auto;
}
/* 资源详情 / 属性表：内容组件自带 height:100% 与内边距，这里只负责占满剩余空间 */
.db-detail__inner {
  flex: 1;
  min-height: 0;
}

/* ---------- 资源卡片（对齐 mm-card）---------- */
.db-grid-wrap {
  flex: 1;
  min-height: 0;
  padding: 4px 16px 16px;
  overflow: auto;
  &:has(> .el-empty) {
    display: flex;
    align-items: center;
    justify-content: center;
  }
}
.db-grid {
  display: grid;
  width: 100%;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  align-content: start;
  gap: 14px;
}
.db-card {
  display: flex;
  flex-direction: column;
  min-width: 0;
  padding: 14px;
  cursor: pointer;
  background: var(--el-bg-color);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 8px;
  transition:
    border-color 0.15s,
    box-shadow 0.15s,
    transform 0.15s;
}
.db-card:hover {
  border-color: var(--el-color-primary-light-5);
  box-shadow: 0 6px 18px rgb(31 45 61 / 8%);
  transform: translateY(-1px);
}
.db-card__head {
  display: flex;
  gap: 9px;
  align-items: flex-start;
  min-width: 0;
}
.db-card__ic {
  display: inline-flex;
  flex: none;
  align-items: center;
  justify-content: center;
  width: 30px;
  height: 30px;
  color: var(--el-color-primary);
  font-size: 15px;
  background: var(--el-color-primary-light-9);
  border-radius: 7px;
}
.db-card__titles {
  flex: 1;
  min-width: 0;
}
.db-card__title {
  overflow: hidden;
  color: var(--el-text-color-primary);
  font-size: 13px;
  font-weight: 600;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.db-card__ver {
  flex: none;
  padding: 0 6px;
  color: var(--el-text-color-secondary);
  font-size: 11px;
  line-height: 18px;
  font-variant-numeric: tabular-nums;
  background: var(--el-fill-color-light);
  border-radius: 4px;
}
.db-card__desc {
  display: -webkit-box;
  margin: 10px 0 8px;
  overflow: hidden;
  color: var(--el-text-color-secondary);
  font-size: 12px;
  line-height: 1.55;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  &.is-empty {
    color: var(--el-text-color-placeholder);
  }
}
.db-card__tags {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  min-height: 18px;
  margin-bottom: 10px;
}
.db-card__tag {
  padding: 0 6px;
  color: var(--el-color-primary);
  font-size: 11px;
  line-height: 18px;
  background: var(--el-color-primary-light-9);
  border-radius: 4px;
  &.is-state {
    color: var(--el-text-color-secondary);
    background: var(--el-fill-color-light);
  }
}
.db-card__foot {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-top: auto;
  color: var(--el-text-color-secondary);
  font-size: 12px;
}
.db-card__stat b {
  color: var(--el-text-color-primary);
  font-weight: 600;
  font-variant-numeric: tabular-nums;
}
.db-card__dot {
  color: var(--el-border-color);
}
.db-card__time {
  font-variant-numeric: tabular-nums;
}
.db-grow {
  flex: 1;
}

.db-hint {
  padding-top: 120px;
}
</style>
