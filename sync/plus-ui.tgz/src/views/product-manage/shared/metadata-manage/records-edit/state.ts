import type { DatasetAttribute, DatasetRecord } from '@/api/product-manage/mock/dataset';
import { computed, ref } from 'vue';
import { listResources, updateResource } from '@/api/product-manage/platform/resources';

/**
 * 数据集浏览面板共享状态（列表数据 + 编辑 / 批量编辑写回）
 *
 * WHY 用模块级单例而非组件内 ref：单条编辑弹窗、批量编辑弹窗与列表三者需
 * 读写同一份数据；AGENTS.md 要求「兄弟组件不要互相引用」，故以本模块承载
 * 共享状态，弹窗与列表都只从本模块导入。
 *
 * CONSTRAINT 数据源为内存态（dataset-mock 静态数组 + 运行时 patch），刷新
 * 页面即恢复初始数据；接真实接口时只需替换 updateRecord / batchUpdateField
 * 的实现，调用方（弹窗 + 列表）无需改动。
 */

/**
 * 深拷贝种子数据：DATASET_RECORDS 是模块级常量数组，若直接改其元素，
 * HMR 重载本模块时上次编辑仍在，导致初始数据「累积漂移」。
 */
function cloneSeed(): DatasetRecord[] {
  return DATASET_RECORDS.map((record) => ({
    ...record,
    bbox: [...record.bbox] as [number, number, number, number],
    attributes: record.attributes.map((attr) => ({ ...attr }))
  }));
}

/** 列表行：真实资源映射；resourceUid 用于写回 */
export interface RecordsEditRow extends DatasetRecord {
  resourceUid?: string;
  state?: string;
  dataType?: string;
}

/** 列表数据唯一数据源：Table 与编辑弹窗均读写此处（由 loadRecords() 填充） */
export const records = ref<RecordsEditRow[]>([]);

/** 真实数据映射：/platform/resources → 图幅级 UI 字段（真实没有的置空） */
export function toRow(r: any, idx: number): RecordsEditRow {
  return {
    id: idx,
    resourceUid: r?.resourceUid,
    zoneNumber: r?.resourceUid || '',
    category: r?.categoryUid || '',
    graphName: r?.name || r?.resourceName || '',
    manufactureInstitution: '',
    manuDate: '',
    mapScale: 0,
    qualityEvaluate: '',
    geodeticDatum: '',
    coordUnit: '',
    bbox: [0, 0, 0, 0],
    attributes: [],
    state: r?.state || '',
    dataType: r?.dataType || ''
  };
}

let rowsLoading: Promise<void> | null = null;
export function loadRecords(force = false): Promise<void> {
  if (!force && rowsLoading) return rowsLoading;
  rowsLoading = (async () => {
    const res: any = await listResources({ page: 1, size: 100 });
    const items: any[] = res?.data?.items || [];
    records.value = items.map(toRow);
  })();
  return rowsLoading;
}

/**
 * 单条编辑可改字段——与 detail.vue 展示内容一致：
 *   8 个摘要字段 + 空间范围 bbox + 完整属性表 attributes。
 */
export interface EditForm {
  zoneNumber: string;
  graphName: string;
  manufactureInstitution: string;
  manuDate: string;
  mapScale: number;
  qualityEvaluate: string;
  geodeticDatum: string;
  coordUnit: string;
  bbox: [number, number, number, number];
  attributes: DatasetAttribute[];
}

/**
 * 批量编辑允许的字段：仅 7 个摘要字段，不含 zoneNumber / bbox / attributes。
 * CONSTRAINT 图号批量设同值会触发唯一性冲突；bbox 与属性表属于逐条强相关数据，
 * 批量覆盖会把多条记录的几何/属性抹平，故从源头禁掉。
 */
export type BatchEditableKey = 'graphName' | 'manufactureInstitution' | 'manuDate' | 'mapScale' | 'qualityEvaluate' | 'geodeticDatum' | 'coordUnit';

/** 从记录摘出可编辑字段；引用类型字段（bbox / attributes）深拷贝，避免表单副本与原数据共享引用 */
export function pickEditable(record: DatasetRecord): EditForm {
  return {
    zoneNumber: record.zoneNumber,
    graphName: record.graphName,
    manufactureInstitution: record.manufactureInstitution,
    manuDate: record.manuDate,
    mapScale: record.mapScale,
    qualityEvaluate: record.qualityEvaluate,
    geodeticDatum: record.geodeticDatum,
    coordUnit: record.coordUnit,
    bbox: [...record.bbox] as [number, number, number, number],
    attributes: record.attributes.map((attr) => ({ ...attr }))
  };
}

/**
 * 按 id 写回单条记录，返回命中数。
 * CONSTRAINT 返回 0 表示记录不存在（可能被并发删除），调用方必须据此报错，
 * 不能静默成功——否则用户看到「保存成功」但列表无变化。
 * 传入的 bbox / attributes 必须再深拷贝一次：表单副本若被外部持有，
 * 直接 Object.assign 会让 records 与表单共享同一数组。
 */
export async function updateRecord(id: number, patch: Partial<EditForm>): Promise<number> {
  const target = records.value.find((record) => record.id === id);
  if (!target) return 0;
  const safe: Partial<EditForm> = { ...patch };
  if (safe.bbox) safe.bbox = [...safe.bbox] as [number, number, number, number];
  if (safe.attributes) safe.attributes = safe.attributes.map((attr) => ({ ...attr }));
  Object.assign(target, safe);
  if (target.resourceUid && patch.graphName != null) {
    await updateResource(target.resourceUid, { name: patch.graphName });
  }
  return 1;
}

/**
 * 批量写回同一组字段到多个 id，返回命中条数。
 * CONSTRAINT 传入 ids 与当前 records 不一致时只统计交集，不抛错——
 * 列表筛选变化可能导致 selection 中的行已不在当前视图。
 */
export async function batchUpdateField(ids: number[], patch: Partial<EditForm>): Promise<number> {
  const idSet = new Set(ids);
  let count = 0;
  const pending: Promise<any>[] = [];
  records.value.forEach((record) => {
    if (!idSet.has(record.id)) return;
    Object.assign(record, patch);
    count += 1;
    if (record.resourceUid && patch.graphName != null) {
      pending.push(updateResource(record.resourceUid, { name: patch.graphName }));
    }
  });
  await Promise.allSettled(pending);
  return count;
}

/** 图号下拉选项（搜索区与编辑弹窗唯一性提示共用） */
export const zoneNumberOptions = computed(() => records.value.map((record) => ({ label: record.zoneNumber, value: record.zoneNumber })));
