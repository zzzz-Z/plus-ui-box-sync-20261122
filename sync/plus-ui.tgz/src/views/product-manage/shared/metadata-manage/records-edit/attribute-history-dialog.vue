<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
/**
 * 记录变更历史 + 撤销（createDialog 内容）
 *
 * 契约：`GET .../records/{metadataUid}/history`（docId 531665055）
 *       `POST .../records/{metadataUid}/undo`（docId 531665133）
 *
 * ## 三轮前置条件（与新增 / 批量编辑弹窗共用 `withEditLock` 一套纪律）
 *   1. 本弹窗**只读**时不需要锁；点「撤销」时才取锁（records 模式，锁目标 = 该记录）。
 *   2. 撤销三个必填：`historyUid` + `expectedRowVersion` + `lockToken`，缺一后端 40001。
 *   3. 契约明示「撤销目标必须为**最新**历史UUID」——所以只允许撤 `items[0]`，
 *      其余行给禁用态而不是让用户点了才被后端 409 拒。
 *
 * ## WHY 身份仍从 values 取
 * 属性表接口返回的记录只有 `tableKey` / `pgTable` / `values`，没有顶层 `metadataUid` / `rowVersion`；
 * 但实测 `values` 里同时带 `metadata_uid` 与 `row_version`（与属性表行数据同源）。
 * 撤销需要的两把钥匙（metadataUid + expectedRowVersion）都从 values 取，无需再打详情接口。
 *
 * ## 权限门
 * 历史查询与撤销都需 `metadata.edit`。40301 不当系统异常，直接给出「待开通」提示。
 */
import { Refresh, Sort } from '@element-plus/icons-vue';
import {
  listMetadataRecordHistory,
  METADATA_RECORD_NOT_FOUND_CODE,
  undoMetadataRecord,
  withEditLock,
  type MetadataFieldValues,
  isMetadataPermissionDenied
} from '@/api/product-manage/platform/metadata-records';
import type { MetadataRecordHistoryItem, MetadataRecordHistoryOperation } from '@/api/product-manage/types/platform';
import type { MetadataAttributeColumn, MetadataAttributeRecord } from '@/api/product-manage/platform/metadata-attributes';

defineOptions({ name: 'AttributeHistoryDialog' });

const props = defineProps<{
  /** 目标记录（行对象） */
  row: MetadataAttributeRecord;
  /** 当前页签所属资源 uid */
  resourceUid: string;
  /** 当前页签的表键 */
  tableKey: string;
  /** 列清单：用于把 beforeValues/afterValues 的英文键翻成中文 */
  columns?: MetadataAttributeColumn[];
  /** 撤销成功后回调（父组件据此刷新列表） */
  onSaved?: () => void;
}>();

/** 记录身份（与批量编辑弹窗一致，从 values 取） */
const metadataUid = computed(() => String((props.row?.values?.metadata_uid as any) ?? ''));
/** 当前行版本；撤销的 expectedRowVersion 用它 */
const rowVersion = computed(() => {
  const raw = (props.row?.values?.row_version as any) ?? (props.row?.values?.rowVersion as any);
  const n = Number(raw);
  return Number.isFinite(n) ? n : null;
});

const items = ref<MetadataRecordHistoryItem[]>([]);
const total = ref(0);
const page = ref(1);
const pageSize = ref(20);
const loading = ref(false);
/** 加载失败说明（权限 / 40404 / 网络），决定是否放行撤销 */
const loadError = ref('');
/** 正在撤销的 historyUid（用于按钮 loading，防重复点击） */
const undoingUid = ref('');

/** 列清单 → 中文名映射（before/after 值用中文列名展示） */
const labelOfKey = computed(() => {
  const map: Record<string, string> = {};
  for (const c of props.columns ?? []) map[c.key] = c.label;
  return map;
});

/** 操作类型 → 中文文案 + 标签色（契约四值 create/update/delete/undo） */
const OPERATION_META: Record<MetadataRecordHistoryOperation, { text: string; type: 'primary' | 'success' | 'danger' | 'warning' }> = {
  create: { text: pt('创建'), type: 'success' },
  update: { text: pt('修改'), type: 'primary' },
  delete: { text: pt('删除'), type: 'danger' },
  undo: { text: pt('撤销'), type: 'warning' }
};
function opMeta(op?: string) {
  const key = (op ?? '') as MetadataRecordHistoryOperation;
  return OPERATION_META[key] ?? { text: op || '未知', type: 'warning' as const };
}

/**
 * 最新历史项才能撤销（契约硬约束）。
 * WHY 用 items[0]：契约明示历史按 `rowVersionAfter` 倒序，故第一条即最新。
 * 不按 createdAt 排序 —— 时间戳可能同时性，版本号才是权威序。
 */
const latestUid = computed(() => items.value[0]?.historyUid ?? '');

/** 一次历史项能否撤销：必须是最新项、且有 historyUid */
function canUndo(item: MetadataRecordHistoryItem): boolean {
  return !!latestUid.value && item.historyUid === latestUid.value && !undoingUid.value;
}

/** 字段值摘要：把 beforeValues/afterValues 转成「中文名: 值」列表，只显示实际变化的字段 */
function diffLines(item: MetadataRecordHistoryItem): Array<{ label: string; before: string; after: string }> {
  const before = item.beforeValues ?? {};
  const after = item.afterValues ?? {};
  const keys = new Set([...Object.keys(before), ...Object.keys(after)]);
  // 契约给了 changedFields，优先用它，避免整表几十个字段全铺出来
  const focus = item.changedFields?.length ? new Set(item.changedFields) : keys;
  const out: Array<{ label: string; before: string; after: string }> = [];
  for (const key of keys) {
    if (!focus.has(key)) continue;
    const b = fmtVal(before[key]);
    const a = fmtVal(after[key]);
    if (b === a) continue;
    out.push({ label: labelOfKey.value[key] || key, before: b, after: a });
  }
  return out;
}

function fmtVal(v: unknown): string {
  if (v == null || v === '') return '—';
  if (typeof v === 'object') {
    try {
      return JSON.stringify(v);
    } catch {
      return String(v);
    }
  }
  return String(v);
}

function fmtTime(v?: string): string {
  if (!v) return '—';
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? v : d.toLocaleString('zh-CN');
}

/** 拉取历史（分页参数是 page/pageSize，**不是** pageNum —— 见 metadata-records.ts 注释） */
async function loadHistory() {
  const uid = metadataUid.value;
  if (!uid) {
    loadError.value = '该记录缺少 metadata_uid，无法查询变更历史';
    return;
  }
  loading.value = true;
  loadError.value = '';
  try {
    const res = await listMetadataRecordHistory(props.resourceUid, props.tableKey, uid, {
      page: page.value,
      pageSize: pageSize.value
    });
    // items 契约标「非必填」，无历史时后端可能不返回该成员 → 必须 ?? []
    items.value = res?.data?.items ?? [];
    total.value = res?.data?.total ?? 0;
  } catch (e: any) {
    items.value = [];
    total.value = 0;
    if (isMetadataPermissionDenied(e)) {
      loadError.value = '缺少 metadata.edit 权限，变更历史无法加载（需该权限开通后可用）';
    } else if (
      Number(e?.code) === METADATA_RECORD_NOT_FOUND_CODE ||
      Number(e?.response?.data?.code) === METADATA_RECORD_NOT_FOUND_CODE ||
      e?.response?.status === 404
    ) {
      loadError.value = '该记录不存在或已被删除（无法查询历史）';
    } else {
      loadError.value = `变更历史加载失败：${e?.message ?? '接口异常'}`;
    }
  } finally {
    loading.value = false;
  }
}

function onPageChange(p: number) {
  page.value = p;
  loadHistory();
}

/**
 * 撤销：拿锁 → undo → 自动放锁。
 *
 * CONSTRAINT 必须先确认 expectedRowVersion 可用：缺它服务端固定 40001，
 * 与其让用户点了看到报错，不如提前拦住并说清楚原因。
 */
async function undo(item: MetadataRecordHistoryItem) {
  const uid = metadataUid.value;
  if (!uid || !item?.historyUid) return;
  const version = rowVersion.value;
  if (version == null) {
    ElMessage.warning(pt('该记录缺少 row_version，无法做并发校验（请刷新列表后重试）'));
    return;
  }
  undoingUid.value = item.historyUid;
  try {
    await withEditLock(props.resourceUid, props.tableKey, { mode: 'records', metadataUids: [uid] }, async (lock) => {
      await undoMetadataRecord(props.resourceUid, props.tableKey, uid, {
        historyUid: item.historyUid!,
        expectedRowVersion: version,
        lockToken: lock.lockToken,
        lockRevision: lock.lockRevision
      });
    });
    ElMessage.success(pt('已撤销该次编辑'));
    props.onSaved?.();
    // 撤销本身会新增一条 undo 历史，必须重拉：撤销后 rowVersion 已变，
    // 继续用旧的 rowVersion 再撤必然 409；重拉同时把「最新项」更新为新的 undo 记录。
    page.value = 1;
    await loadHistory();
  } catch (e: any) {
    if (isMetadataPermissionDenied(e)) {
      ElMessage.error(pt('缺少 metadata.edit 权限，请联系管理员开通后再试'));
    } else {
      // 409 / 40001：版本冲突或历史已被覆盖，把后端原话透出来（这是真实业务原因，不能吞）
      ElMessage.error(String(e?.message || '撤销失败'));
    }
    // 冲突后同样重拉：让用户看到最新的历史与版本，而不是停留在过期视图上反复点
    await loadHistory();
  } finally {
    undoingUid.value = '';
  }
}

onMounted(loadHistory);

/**
 * 供 createDialog 使用：footer:false 时由本组件自管操作，
 * 但撤销成功需要关闭弹窗时由父组件决定；这里暴露 refresh 供外部调用。
 */
defineExpose({ refresh: loadHistory });
</script>

<template>
  <div v-loading="loading" class="attr-history">
    <el-alert v-if="loadError" type="warning" :closable="false" show-icon :title="loadError" class="attr-history__alert" />

    <div class="attr-history__meta">
      <span
        >{{ pt('当前行版本') }} <code>{{ rowVersion ?? '—' }}</code></span
      >
      <span
        >{{ pt('历史共') }} <b>{{ total }}</b> {{ pt('条') }}</span
      >
      <el-button size="small" :icon="Refresh" :loading="loading" @click="loadHistory">{{ pt('刷新') }}</el-button>
    </div>

    <el-empty v-if="!loading && !items.length" :description="pt('该记录暂无变更历史')" :image-size="70" />

    <el-timeline v-else class="attr-history__timeline">
      <el-timeline-item
        v-for="(item, idx) in items"
        :key="item.historyUid || idx"
        :timestamp="fmtTime(item.createdAt)"
        placement="top"
        :type="opMeta(item.operation).type"
        :hollow="idx !== 0"
      >
        <div class="attr-history__item">
          <div class="attr-history__head">
            <el-tag :type="opMeta(item.operation).type" size="small" effect="light">{{ opMeta(item.operation).text }}</el-tag>
            <span v-if="idx === 0" class="attr-history__latest">{{ pt('最新') }}</span>
            <span class="attr-history__ver">版本 {{ item.rowVersionBefore ?? '—' }} → {{ item.rowVersionAfter ?? '—' }}</span>
            <span class="attr-history__actor" :title="item.actor || ''">{{ item.actor || '—' }}</span>
            <span class="attr-history__grow" />
            <el-button
              v-if="canUndo(item)"
              link
              type="warning"
              size="small"
              :icon="Refresh"
              :loading="undoingUid === item.historyUid"
              @click="undo(item)"
            >
              {{ pt('撤销到此前') }}
            </el-button>
            <span v-else-if="idx !== 0" class="attr-history__hint" :title="pt('契约要求只能撤销最新的历史项')">{{ pt('仅可撤销最新一项') }}</span>
          </div>

          <div v-if="diffLines(item).length" class="attr-history__diff">
            <div v-for="d in diffLines(item)" :key="d.label" class="attr-history__diff-row">
              <span class="attr-history__field" :title="d.label">{{ d.label }}</span>
              <span class="attr-history__before">{{ d.before }}</span>
              <el-icon class="attr-history__arrow"><Sort /></el-icon>
              <span class="attr-history__after">{{ d.after }}</span>
            </div>
          </div>
          <div v-else class="attr-history__nodiff">{{ pt('无字段值变化') }}</div>
        </div>
      </el-timeline-item>
    </el-timeline>

    <div v-if="total > pageSize" class="attr-history__pager">
      <el-pagination
        size="small"
        background
        layout="total, prev, pager, next"
        :total="total"
        :current-page="page"
        :page-size="pageSize"
        @current-change="onPageChange"
      />
    </div>
  </div>
</template>

<style scoped lang="scss">
.attr-history {
  min-height: 0;
}

.attr-history__alert {
  margin-bottom: 12px;
}

.attr-history__meta {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 14px;
  padding-bottom: 10px;
  margin-bottom: 12px;
  color: var(--el-text-color-secondary);
  font-size: 12px;
  border-bottom: 1px solid var(--el-border-color-lighter);

  code {
    font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  }
}

/* 弹窗 body 自己滚动，时间线不设 max-height，避免双滚动条 */
.attr-history__timeline {
  padding-right: 6px;
}

.attr-history__item {
  padding: 8px 10px;
  background: var(--el-fill-color-blank);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 6px;
}

.attr-history__head {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
  font-size: 12px;
}

.attr-history__latest {
  padding: 0 5px;
  color: var(--el-color-primary);
  font-size: 11px;
  border: 1px solid var(--el-color-primary-light-5);
  border-radius: 3px;
}

.attr-history__ver,
.attr-history__actor {
  color: var(--el-text-color-secondary);
}

.attr-history__actor {
  max-width: 220px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.attr-history__grow {
  flex: 1 1 auto;
}

.attr-history__hint {
  color: var(--el-text-color-placeholder);
  font-size: 11px;
}

.attr-history__diff {
  margin-top: 8px;
}

.attr-history__diff-row {
  display: flex;
  align-items: baseline;
  gap: 8px;
  padding: 2px 0;
  font-size: 12px;
  line-height: 1.6;
}

.attr-history__field {
  flex: 0 0 132px;
  color: var(--el-text-color-regular);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.attr-history__before {
  flex: 1 1 0;
  min-width: 0;
  color: var(--el-text-color-secondary);
  word-break: break-all;
}

.attr-history__arrow {
  flex: 0 0 auto;
  color: var(--el-text-color-placeholder);
}

.attr-history__after {
  flex: 1 1 0;
  min-width: 0;
  color: var(--el-color-primary);
  word-break: break-all;
}

.attr-history__nodiff {
  margin-top: 6px;
  color: var(--el-text-color-placeholder);
  font-size: 12px;
}

.attr-history__pager {
  display: flex;
  justify-content: flex-end;
  padding-top: 10px;
}
</style>
