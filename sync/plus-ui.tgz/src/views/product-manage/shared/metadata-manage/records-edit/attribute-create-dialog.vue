<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
/**
 * 新增元数据记录弹窗（createDialog 内容）
 *
 * 契约：`POST .../records`（docId 531575505）
 *
 * ## 三级前置条件（不可跳级）
 *   1. `getEditSchema()` → `fields[]` 的 writable / required / options 是唯一校验依据；
 *   2. `withEditLock({ mode: 'table' })` → **创建必须持表锁**（契约原文：“create必须表锁”）。
 *      表锁要求 `metadataUids` 为空，与编辑时的 records 锁不是一回事，写成 records 会被拒；
 *   3. `createMetadataRecord()` 带 values + lockToken，结束后自动释放锁。
 *
 * ## 与「编辑」的差异（易错点）
 * - 创建**没有** `expectedRowVersion`（新记录还没有版本）；
 * - 必须有 `lockToken`（表锁）；
 * - `values` 只放 writable !== false 的字段。
 */
import {
  getEditSchema,
  createMetadataRecord,
  normalizeFieldValues,
  withEditLock,
  isMetadataPermissionDenied
} from '@/api/product-manage/platform/metadata-records';
import type { MetadataEditField } from '@/api/product-manage/types/platform';
import type { MetadataAttributeColumn } from '@/api/product-manage/platform/metadata-attributes';

defineOptions({ name: 'AttributeCreateDialog' });

const props = defineProps<{
  /** 当前页签所属资源 uid */
  resourceUid: string;
  /** 当前页签的表键 */
  tableKey: string;
  /** 页签展示名（弹窗标题用） */
  tableLabel?: string;
  /** 列清单（schema 没给 label 时兜底中文名） */
  columns?: MetadataAttributeColumn[];
  /** 保存成功后回调 */
  onSaved?: () => void;
}>();

const fields = ref<MetadataEditField[]>([]);
const form = reactive<Record<string, string>>({});
const schemaLoading = ref(false);
const saving = ref(false);
const schemaError = ref('');

/** 列清单 → 中文名兜底 */
const labelOfKey = computed(() => {
  const map: Record<string, string> = {};
  for (const c of props.columns ?? []) map[c.key] = c.label;
  return map;
});

/** 可写字段：writable !== false 且非只读（与编辑弹窗同一判据） */
const editableFields = computed(() => fields.value.filter((f) => f && f.fieldKey && f.writable !== false && !f.readOnly));

async function loadSchema() {
  schemaLoading.value = true;
  schemaError.value = '';
  try {
    const res = await getEditSchema(props.resourceUid, props.tableKey);
    fields.value = res?.data?.fields ?? [];
    if (!fields.value.length) schemaError.value = '该表未返回可编辑字段定义，无法新增';
    else {
      // 初始值：schema.defaultValue 优先，其余空串
      for (const f of editableFields.value) {
        if (form[f.fieldKey] == null) form[f.fieldKey] = f.defaultValue ?? '';
      }
    }
  } catch (e: any) {
    fields.value = [];
    schemaError.value = isMetadataPermissionDenied(e)
      ? pt('缺少 metadata.edit 权限，字段定义无法加载（新增功能需该权限开通后可用）')
      : `字段定义加载失败：${e?.message ?? '接口异常'}`;
  } finally {
    schemaLoading.value = false;
  }
}

/** 供 createDialog 提交前校验：只校验 schema 标注 required 的字段 */
function validate() {
  if (!editableFields.value.length) throw new Error(schemaError.value || '没有可填写的字段');
  for (const f of editableFields.value) {
    if (!f.required) continue;
    const val = String(form[f.fieldKey] ?? '').trim();
    if (!val) throw new Error(`请填写「${f.label || labelOfKey.value[f.fieldKey] || f.fieldKey}」`);
  }
  return true;
}

/**
 * 提交：拿**表锁** → 创建 → 自动放锁。
 *
 * WHY mode 必须是 'table'：契约明示「create必须表锁」；表锁的 metadataUids 必须为空。
 * 用 records 模式锁单条记录对「还没创建的记录」无从谈起，服务端会以「本人持有且未过期的编辑锁」校验失败。
 */
async function save() {
  if (!editableFields.value.length) return { code: 1, message: schemaError.value || '没有可填写的字段' };

  const values: Record<string, string> = {};
  for (const f of editableFields.value) values[f.fieldKey] = String(form[f.fieldKey] ?? '');

  saving.value = true;
  try {
    const res = await withEditLock(props.resourceUid, props.tableKey, { mode: 'table' }, async (lock) =>
      createMetadataRecord(props.resourceUid, props.tableKey, {
        values: normalizeFieldValues(values),
        lockToken: lock.lockToken,
        lockRevision: lock.lockRevision
      })
    );
    props.onSaved?.();
    const uid = res?.data?.metadataUid;
    return { code: 0, message: uid ? `已新增记录 ${uid.slice(0, 8)}…` : `已新增 1 条记录（${Object.keys(values).length} 个字段）` };
  } catch (e: any) {
    if (isMetadataPermissionDenied(e)) return { code: 1, message: pt('缺少 metadata.edit 权限，请联系管理员开通后再试') };
    return { code: 1, message: String(e?.message || '新增失败') };
  } finally {
    saving.value = false;
  }
}

onMounted(loadSchema);

defineExpose({ save, validate, form });
</script>

<template>
  <div v-loading="schemaLoading" class="attr-create">
    <el-alert v-if="schemaError" type="warning" :closable="false" show-icon :title="schemaError" class="attr-create__alert" />

    <el-form v-if="!schemaLoading && editableFields.length" label-width="150px" class="attr-create__form">
      <el-form-item v-for="f in editableFields" :key="f.fieldKey" :label="f.label || labelOfKey[f.fieldKey] || f.fieldKey" :required="!!f.required">
        <el-select v-if="f.options && f.options.length" v-model="form[f.fieldKey]" clearable filterable :disabled="saving">
          <el-option v-for="opt in f.options" :key="opt.value" :label="opt.label || opt.value" :value="opt.value" />
        </el-select>
        <el-input
          v-else-if="f.valueType && /^(integer|number|decimal|double|float|numeric|int|long|bigint)$/.test(f.valueType)"
          v-model="form[f.fieldKey]"
          inputmode="decimal"
          :disabled="saving"
        />
        <el-input
          v-else-if="(f.maxLength ?? 0) > 200 || f.widget === 'textarea'"
          v-model="form[f.fieldKey]"
          type="textarea"
          :rows="2"
          :maxlength="f.maxLength"
          :disabled="saving"
        />
        <el-input v-else v-model="form[f.fieldKey]" :maxlength="f.maxLength" clearable :disabled="saving" />
        <div v-if="f.description" class="attr-create__hint">{{ f.description }}</div>
      </el-form-item>
    </el-form>

    <el-empty v-else-if="!schemaLoading" :description="pt('该表没有可填写的字段')" :image-size="70" />

    <div class="attr-create__meta">
      {{ pt('目标表') }} <code>{{ tableLabel || tableKey }}</code> {{ pt('· 创建需持表锁') }}
    </div>
  </div>
</template>

<style scoped lang="scss">
.attr-create {
  min-height: 0;
}

.attr-create__alert {
  margin-bottom: 12px;
}

.attr-create__form {
  :deep(.el-form-item) {
    margin-bottom: 14px;
  }
}

.attr-create__hint {
  margin-top: 2px;
  color: var(--el-text-color-placeholder);
  font-size: 12px;
  line-height: 1.5;
}

.attr-create__meta {
  padding-top: 10px;
  color: var(--el-text-color-secondary);
  font-size: 12px;
  border-top: 1px solid var(--el-border-color-lighter);

  code {
    font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  }
}
</style>
