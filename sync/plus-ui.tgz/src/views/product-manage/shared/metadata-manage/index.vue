<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
import Layout from '@/views/product-manage/shared/index.vue';
import DataBrowse from '../data-browse/index.vue';
import DataQuery from '../data-query/index.vue';
import DataCheck from '../data-check/index.vue';
import VersionManage from '../version-manage/index.vue';
import Backup from '../backup/index.vue';
import DataPermission from '../data-permission/index.vue';
import Analysis from './analysis.vue';
import ModelManage from './model-manage/index.vue';
import RecordsEdit from './records-edit/index.vue';
import Transfer from './transfer/index.vue';
import Update from './update/index.vue';
import Extraction from './extraction.vue';
import { useProductRecords } from '@/views/product-manage/shared/store.js';

interface TabDef {
  label: string;
  /** 是否支持 地图/联动 视图 */
  geo: boolean;
  description: string;
}

const TABS: TabDef[] = [
  { label: pt('元数据浏览'), geo: true, description: pt('地图矩形/列表联动浏览，类别配色、图例、聚合展示') },
  { label: pt('元数据查询'), geo: true, description: pt('地图框选与列表条件查询选择，结果联动与报表导出') },
  {
    label: pt('元数据模型管理'),
    geo: false,
    description: pt('创建/维护元数据模型（结构/管理/发现/应用分类、模板、范例表自动生成，模型相对固定、管理员修改）')
  },
  { label: pt('元数据抽取'), geo: false, description: pt('按元数据模型从生产记录、库配置与入库记录自动抽取元数据，错误表可双击定位纠错') },
  { label: pt('元数据编辑'), geo: true, description: pt('元数据表记录增删改、批量修改、撤销与字段级校验，支持地图+列表联动编辑') },
  { label: pt('元数据检查'), geo: false, description: pt('入库/出库完整性、准确性检查，错误日志与错误报表') },
  { label: pt('元数据分析'), geo: false, description: pt('血缘/影响/冷热/关联/依赖/变更/一致性/重要性分析专题图与报告') },
  { label: pt('元数据更新'), geo: false, description: pt('模型/字段变更通知与向导式批量更新，事务提交/回滚') },
  { label: pt('元数据版本管理'), geo: false, description: pt('变更日志、版本比较/恢复、变更追踪与变更报告') },
  { label: pt('元数据导入导出'), geo: false, description: pt('批量导入导出，国标/J标/地质/海洋等格式与 Doc/PDF/XLS 等文档导出') },
  { label: pt('元数据备份恢复'), geo: false, description: pt('备份策略、本地/异地/离线完整与增量备份，恢复向导') },
  { label: pt('元数据安全管理'), geo: true, description: pt('属性字段/空间范围/图号列表规则限定，地图与列表屏蔽联动') }
];

/**
 * 元数据管理入口（共享层）
 *
 * 12 个 tab；骨架复用 shared/product/index.vue（插槽模式），面板组件在 shared 内相对路径引用。
 * 当前 6 个 tab 有实现（模型/编辑/分析/导入导出/更新/抽取），其余为后续迭代。
 * 面板组件读取 useProductRecords() 的记录数据，此处 onMounted 幂等预载。
 */
onMounted(() => {
  useProductRecords().load();
});
</script>

<template>
  <Layout :menu-types="TABS.map((tab) => tab.label)" :spatial-modules="TABS.filter((v) => v.geo).map((v) => v.label)" :tab-defs="TABS">
    <template #default="{ pageType, showMap }">
      <!-- 本文件即「元数据管理」：右侧一律用列表（AttributeTable / 结果表格），不传 detail-mode。
           产品线（primary/result 的 category-feature 等）走 shared/index.vue 的 context 分支，
           由那里传 detail-mode=true 显示详情组件 —— 两边各用各的，互不干扰。 -->
      <DataBrowse v-if="pageType === '元数据浏览'" />
      <DataQuery v-if="pageType === '元数据查询'" :map-visible="showMap" />
      <DataCheck v-if="pageType === '元数据检查'" />
      <ModelManage v-if="pageType === '元数据模型管理'" />
      <RecordsEdit v-if="pageType === '元数据编辑'" />
      <Analysis v-if="pageType === '元数据分析'" />
      <Transfer v-if="pageType === '元数据导入导出'" />
      <Update v-if="pageType === '元数据更新'" />
      <Extraction v-if="pageType === '元数据抽取'" />
      <VersionManage v-if="pageType === '元数据版本管理'" />
      <Backup v-if="pageType === '元数据备份恢复'" />
      <DataPermission v-if="pageType === '元数据安全管理'" />
    </template>
  </Layout>
</template>
