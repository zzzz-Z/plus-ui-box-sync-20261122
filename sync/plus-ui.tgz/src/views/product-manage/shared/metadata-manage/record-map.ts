/**
 * 元数据记录 → 地图要素 / 调色板 工具
 * 供「浏览 / 查询 / 编辑 / 安全管理」等面板的地图+列表联动复用
 */
import type { MetadataRecord } from '@/api/product-manage/types';

/**
 * 分类要素初级产品 9 类配色（与产品地图一致）。
 * 配色真源统一收敛到 services/palette（含内置预设与自定义方案），此处 re-export
 * 保持既有 `import { CATEGORY_PALETTE } from '../record-map'` 调用方不变。
 */
export { CATEGORY_PALETTE } from '@/api/product-manage/mock/palette';

function bboxToPolygon(bbox: [number, number, number, number]): any {
  const [minLng, minLat, maxLng, maxLat] = bbox;
  return {
    type: 'Polygon',
    coordinates: [
      [
        [minLng, minLat],
        [maxLng, minLat],
        [maxLng, maxLat],
        [minLng, maxLat],
        [minLng, minLat]
      ]
    ]
  };
}

/** 记录转为 GeoJSON Feature（地图矩形） */
export function recordToFeature(record: MetadataRecord): any {
  return {
    type: 'Feature',
    id: record.id,
    geometry: bboxToPolygon(record.bbox),
    properties: {
      id: record.id,
      name: record.name,
      category: record.category,
      version: record.version,
      dataLevel: record.dataLevel,
      description: record.description,
      region: record.region,
      tableName: record.tableName,
      recordUid: record.recordUid,
      operator: record.operator,
      // 供地图悬停浮窗展示「更新时间」（GeoMap hover 读取 properties.createTime）
      createTime: record.updatedAt
    }
  };
}

export function recordsToFeatures(records: MetadataRecord[]): any[] {
  return records.map(recordToFeature);
}

/** 记录字段展示值（字段级缺失回退） */
export function fieldValue(record: MetadataRecord, fieldName: string) {
  const value = record.fields?.[fieldName];
  return value === undefined || value === null || value === '' ? '-' : String(value);
}
