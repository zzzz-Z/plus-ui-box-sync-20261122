<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
import { Download, Histogram } from '@element-plus/icons-vue';
import type { EChartsOption } from 'echarts';
import { ElMessage } from 'element-plus';
import { getAllMetadataRecords } from '@/api/product-manage/adapter/records';
import { listModelTableOptions } from '@/api/product-manage/platform/model-tables';
import type { MetadataRecord, ModelTable } from '@/api/product-manage/types';

interface TableOption {
  modelUid: string;
  modelName: string;
  tableUid: string;
  tableName: string;
  fields: ModelTable['fields'];
}

const ANALYSIS_TYPES = [
  { key: 'lineage', label: pt('血缘分析') },
  { key: 'impact', label: pt('影响分析') },
  { key: 'hotcold', label: pt('冷热分析') },
  { key: 'relation', label: pt('关联分析') },
  { key: 'depend', label: pt('依赖分析') },
  { key: 'change', label: pt('变更分析') },
  { key: 'consistency', label: pt('一致性分析') },
  { key: 'importance', label: pt('重要性分析') }
] as const;

type AnalysisKey = (typeof ANALYSIS_TYPES)[number]['key'];

const activeType = ref<AnalysisKey>('lineage');
const records = ref<MetadataRecord[]>([]);
const tableOptions = ref<TableOption[]>([]);

async function loadData() {
  const [recordRes, tableRes] = await Promise.all([getAllMetadataRecords(), listModelTableOptions()]);
  records.value = recordRes?.data ?? [];
  tableOptions.value = tableRes?.data?.items ?? [];
}

function countBy(list: MetadataRecord[], pick: (record: MetadataRecord) => string) {
  const map = new Map<string, number>();
  list.forEach((record) => {
    const key = pick(record) || '未知';
    map.set(key, (map.get(key) ?? 0) + 1);
  });
  return [...map.entries()].sort((a, b) => b[1] - a[1]);
}

const option = computed<EChartsOption>(() => {
  const total = records.value.length;
  const categoryPairs = countBy(records.value, (record) => record.category);
  const levelPairs = countBy(records.value, (record) => record.dataLevel);
  const base: EChartsOption = {
    color: ['#5470c6', '#91cc75', '#fac858', '#ee6666', '#73c0de', '#3ba272', '#fc8452', '#9a60b4'],
    tooltip: { trigger: 'axis' }
  };

  if (activeType.value === 'lineage') {
    // 血缘分析：数据来源（生产方式/提供方）统计
    const sourcePairs = countBy(records.value, (record) => String(record.fields?.sourceType ?? record.fields?.provider ?? '数据生产记录'));
    return {
      ...base,
      title: { text: pt('元数据血缘来源分布'), left: 'center' },
      xAxis: { type: 'category', data: sourcePairs.map((item) => item[0]), axisLabel: { rotate: 20 } },
      yAxis: { type: 'value' },
      series: [{ type: 'bar', data: sourcePairs.map((item) => item[1]), name: '记录数', itemStyle: { borderRadius: [4, 4, 0, 0] } }]
    };
  }
  if (activeType.value === 'impact') {
    const usePairs = countBy(records.value, (record) => String(record.fields?.users ?? record.fields?.scenario ?? '业务系统'));
    return {
      ...base,
      title: { text: pt('影响分析 · 元数据使用方分布'), left: 'center' },
      tooltip: { trigger: 'item' },
      legend: { bottom: 0 },
      series: [{ type: 'pie', radius: ['38%', '64%'], data: usePairs.map(([name, value]) => ({ name, value })), label: { formatter: '{b}: {c}' } }]
    };
  }
  if (activeType.value === 'hotcold') {
    // 冷热分析：按更新时间距今天数划分为热/温/冷
    const now = Date.now();
    const buckets: Record<string, number> = { '热数据(<30天)': 0, '温数据(30-90天)': 0, '冷数据(>90天)': 0 };
    records.value.forEach((record) => {
      const days = (now - new Date(record.updatedAt.replace(' ', 'T')).getTime()) / 86400000;
      if (days < 30) buckets['热数据(<30天)']++;
      else if (days < 90) buckets['温数据(30-90天)']++;
      else buckets['冷数据(>90天)']++;
    });
    const pairs = Object.entries(buckets);
    return {
      ...base,
      title: { text: pt('冷热分析 · 元数据访问活跃度'), left: 'center' },
      xAxis: { type: 'category', data: pairs.map((item) => pt(item[0])) },
      yAxis: { type: 'value' },
      series: [{ type: 'bar', data: pairs.map((item) => item[1]), name: '记录数' }]
    };
  }
  if (activeType.value === 'relation' || activeType.value === 'depend') {
    const tablePairs = countBy(records.value, (record) => record.tableName);
    return {
      ...base,
      title: { text: `${activeType.value === 'relation' ? pt('关联') : pt('依赖')}分析 · 元数据表记录规模与字段依赖`, left: 'center' },
      xAxis: { type: 'category', data: tablePairs.map((item) => item[0]), axisLabel: { rotate: 24 } },
      yAxis: { type: 'value', name: '记录数' },
      series: [{ type: 'bar', data: tablePairs.map((item) => item[1]), name: '记录数' }]
    };
  }
  if (activeType.value === 'change') {
    const dayMap = new Map<string, number>();
    records.value.forEach((record) => {
      const day = record.updatedAt.slice(0, 10);
      dayMap.set(day, (dayMap.get(day) ?? 0) + 1);
    });
    const days = [...dayMap.keys()].sort().slice(-14);
    return {
      ...base,
      title: { text: pt('变更分析 · 近 14 天元数据变更量'), left: 'center' },
      xAxis: { type: 'category', data: days },
      yAxis: { type: 'value' },
      series: [{ type: 'line', smooth: true, areaStyle: { opacity: 0.2 }, data: days.map((day) => dayMap.get(day) ?? 0), name: '变更次数' }]
    };
  }
  if (activeType.value === 'consistency') {
    // 一致性分析：各级别/类别记录内部比例
    const pairs = levelPairs;
    return {
      ...base,
      title: { text: pt('一致性分析 · 数据级别构成'), left: 'center' },
      tooltip: { trigger: 'item' },
      legend: { bottom: 0 },
      series: [{ type: 'pie', radius: '62%', data: pairs.map(([name, value]) => ({ name, value })), label: { formatter: '{b}: {d}%' } }]
    };
  }
  // importance
  const rows = categoryPairs.map(([name, value]) => ({ name, value: Math.round((value / total) * 100) }));
  return {
    ...base,
    title: { text: pt('重要性分析 · 各类元数据占比'), left: 'center' },
    xAxis: { type: 'category', data: rows.map((item) => item.name) },
    yAxis: { type: 'value', name: '占比 %', max: 100 },
    series: [{ type: 'bar', data: rows.map((item) => item.value), name: '占比' }]
  };
});

const insight = computed(() => {
  const total = records.value.length;
  const internal = records.value.filter((record) => record.dataLevel === '内部').length;
  const top = countBy(records.value, (record) => record.category)[0];
  const tableCount = new Set(records.value.map((record) => record.tableUid)).size;
  const lines: string[] = [];
  if (activeType.value === 'lineage') lines.push(`来源集中度较高，前 3 类来源覆盖 ${total} 条记录中的多数，建议对主数据来源建立自动抽取。`);
  else if (activeType.value === 'impact')
    lines.push(`使用方集中在业务系统与审核共享渠道，内部数据占比 ${Math.round((internal / total) * 100)}%，推送前需走安全管理。`);
  else if (activeType.value === 'hotcold')
    lines.push(`冷数据占比 ${Math.round(((total - internal) / total) * 100)}% 相关字段近期无更新，可纳入冷备策略。`);
  else lines.push(`共 ${tableCount} 张元数据表、${total} 条记录；主体类别「${top?.[0] ?? '-'}」共 ${top?.[1] ?? 0} 条。`);
  lines.push(`内部数据 ${internal} 条 / 公开数据 ${total - internal} 条，建议依据安全管理规则控制访问。`);
  return lines;
});

function exportReport() {
  const report = [
    `元数据分析报告（${ANALYSIS_TYPES.find((item) => item.key === activeType.value)?.label ?? ''}）`,
    `生成时间：${new Date().toLocaleString('zh-CN')}`,
    `数据范围：${records.value.length} 条元数据记录`,
    '',
    '分析结论：',
    ...insight.value.map((line) => `- ${line}`)
  ].join('\n');
  const link = document.createElement('a');
  link.href = URL.createObjectURL(new Blob([report], { type: 'text/plain;charset=utf-8' }));
  link.download = `元数据分析报告-${activeType.value}.txt`;
  link.click();
  ElMessage.success(`已生成 ${activeType.value} 分析报告`);
}

onMounted(loadData);
</script>

<template>
  <div class="analysis-page">
    <div class="analysis-header">
      <div class="analysis-header__left">
        <el-icon><Histogram /></el-icon>
        <span>{{ pt('元数据分析工具') }}</span>
      </div>
      <el-button :icon="Download" @click="exportReport"> {{ pt('生成分析报告') }} </el-button>
    </div>
    <div class="analysis-types">
      <el-radio-group v-model="activeType" class="analysis-radios">
        <el-radio-button v-for="item in ANALYSIS_TYPES" :key="item.key" :value="item.key">
          {{ item.label }}
        </el-radio-button>
      </el-radio-group>
    </div>
    <div class="analysis-body">
      <div class="analysis-chart">
        <Chart :options="option" height="100%" />
      </div>
      <div class="analysis-insight">
        <div class="analysis-insight__title">{{ pt('分析结论与建议') }}</div>
        <p v-for="(line, index) in insight" :key="index">
          {{ line }}
        </p>
        <el-divider />
        <div class="analysis-insight__title">{{ pt('功能说明') }}</div>
        <p>
          {{
            pt(
              '提供血缘、影响、冷热、关联、依赖、变更、一致性、重要性等元数据分析工具；分析结果以专题图表展示，并可生成元数据分析报告（Doc/Docx/WPS/PDF/HTML 格式接入后支持）。'
            )
          }}
        </p>
      </div>
    </div>
  </div>
</template>

<style scoped lang="scss">
.analysis-page {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
  background: var(--el-bg-color);
}

.analysis-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 14px;
  border-bottom: 1px solid #eef1f6;

  &__left {
    display: flex;
    align-items: center;
    gap: 6px;
    color: #243752;
    font-weight: 600;
  }
}

.analysis-types {
  padding: 10px 14px;
  border-bottom: 1px solid #eef1f6;
}

.analysis-radios {
  flex-wrap: wrap;
}

.analysis-body {
  display: flex;
  flex: 1;
  min-height: 0;
  gap: 12px;
  padding: 12px;
}

.analysis-chart {
  flex: 1.4;
  min-width: 0;
  height: 100%;
  border: 1px solid #eef1f6;
}

.analysis-insight {
  flex: 1;
  min-width: 280px;
  height: 100%;
  padding: 14px;
  overflow: auto;
  border: 1px solid #eef1f6;

  &__title {
    margin-bottom: 8px;
    color: #243752;
    font-weight: 600;
  }

  p {
    margin: 6px 0;
    color: var(--el-text-color-regular);
    font-size: 13px;
    line-height: 1.8;
  }
}
</style>
