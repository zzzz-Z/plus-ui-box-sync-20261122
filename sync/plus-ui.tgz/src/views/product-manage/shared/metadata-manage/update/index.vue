<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
import NoticeBanner from './notice-banner.vue';
import ScopePanel from './scope-panel.vue';
import { executing, loadData, nextStep, pendingCount, prevStep, stats, step, STEPS } from './state';
import TxnPanel from './txn-panel.vue';
import UpdateWizard from './update-wizard.vue';

onMounted(loadData);
</script>

<template>
  <div class="update-page">
    <NoticeBanner />
    <div class="update-footer">
      <div class="update-footer__left">
        {{ pt('当前步骤：') }}<strong>{{ STEPS[step] }}</strong> {{ pt('· 已修改') }} <strong class="is-modified">{{ stats.modified }}</strong>
        {{ pt('条 · 待更新') }}
        <strong>{{ pendingCount }}</strong> {{ pt('条') }}
      </div>
      <div class="update-footer__right">
        <el-button v-if="step > 0 && step < 3" :disabled="executing" @click="prevStep"> {{ pt('上一步') }} </el-button>
        <el-button v-if="step < 3" type="primary" :loading="executing" @click="nextStep">
          {{ step === 2 ? '执行更新' : '下一步' }}
        </el-button>
      </div>
    </div>
    <div class="update-body">
      <ScopePanel />
      <UpdateWizard />
      <TxnPanel />
    </div>
  </div>
</template>

<style scoped lang="scss">
.update-page {
  display: flex;
  flex-direction: column;
  gap: 10px;
  height: 100%;
  min-height: 0;
  padding: 10px;
}

.update-body {
  display: flex;
  flex: 1;
  min-height: 0;
  gap: 10px;
}

.update-footer {
  display: flex;
  flex: none;
  align-items: center;
  justify-content: space-between;
  padding: 10px 14px;
  background: var(--el-bg-color);
  border: 1px solid #eef1f6;

  &__left {
    color: #5a6a7d;
    font-size: 13px;

    strong {
      color: #2563a8;
    }

    .is-modified {
      color: #fa8c16;
    }
  }

  &__right {
    display: flex;
    gap: 8px;
  }
}
</style>
