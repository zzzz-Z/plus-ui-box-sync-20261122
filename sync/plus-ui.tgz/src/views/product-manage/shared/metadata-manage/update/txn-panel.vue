<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
import { errors, locateError, txn } from './state';

const statusMeta = computed(() => {
  switch (txn.status) {
    case 'running':
      return { label: pt('事务进行中…'), type: 'primary' as const };
    case 'success':
      return { label: pt('已提交'), type: 'success' as const };
    case 'failed':
      return { label: pt('已回退（检测到错误）'), type: 'danger' as const };
    default:
      return { label: pt('等待开始'), type: 'info' as const };
  }
});

const progressStatus = computed(() => {
  if (txn.status === 'success') return 'success';
  if (txn.status === 'failed') return 'exception';
  return undefined;
});
</script>

<template>
  <div class="txn-panel">
    <div class="txn-panel__header">
      {{ pt('事务状态') }}
      <span class="txn-panel__id">{{ txn.id || '--' }}</span>
    </div>

    <div class="txn-panel__body">
      <div class="txn-card">
        <div class="txn-card__status">
          <el-tag :type="statusMeta.type" effect="dark" size="small">
            {{ statusMeta.label }}
          </el-tag>
        </div>
        <el-progress :percentage="txn.progress" :status="progressStatus" :stroke-width="12" text-inside class="txn-card__progress" />
        <div class="txn-card__meta">
          <span
            >{{ pt('已处理') }} <strong>{{ txn.processed }}</strong> / {{ txn.total }}</span
          >
          <span>耗时 {{ txn.elapsed }}s</span>
        </div>
      </div>

      <div class="txn-panel__subtitle">
        {{ pt('错误日志') }}
        <el-badge v-if="errors.length" :value="errors.length" type="danger" />
      </div>

      <div v-if="!errors.length" class="txn-panel__empty">{{ pt('暂无错误') }}</div>
      <div v-else class="error-log">
        <div v-for="error in errors" :key="error.recordUid + error.fieldName" class="error-log__item" @click="locateError(error)">
          <div class="error-log__title">{{ error.recordName }} · {{ error.fieldLabel }}</div>
          <div class="error-log__desc">
            {{ error.reason }}
          </div>
          <div class="error-log__help">{{ error.help }}（点击定位）</div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped lang="scss">
.txn-panel {
  display: flex;
  flex-direction: column;
  width: 280px;
  flex: none;
  overflow: hidden;
  background: #fafbfc;
  border: 1px solid #eef1f6;
}

.txn-panel__header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex: none;
  padding: 10px 14px;
  color: #243752;
  font-weight: 600;
  font-size: 13px;
  background: var(--el-bg-color);
  border-bottom: 1px solid #eef1f6;
}

.txn-panel__id {
  color: #98a4b4;
  font-weight: 400;
  font-size: 11px;
}

.txn-panel__body {
  flex: 1;
  min-height: 0;
  padding: 14px;
  overflow-y: auto;
}

.txn-card {
  padding: 12px;
  margin-bottom: 14px;
  background: var(--el-bg-color);
  border: 1px solid #eef1f6;
  border-radius: 8px;

  &__status {
    margin-bottom: 10px;
  }

  &__progress {
    margin-bottom: 8px;
  }

  &__meta {
    display: flex;
    justify-content: space-between;
    color: #8695a8;
    font-size: 12px;

    strong {
      color: #243752;
    }
  }
}

.txn-panel__subtitle {
  display: flex;
  align-items: center;
  gap: 8px;
  padding-bottom: 6px;
  margin-bottom: 8px;
  color: #243752;
  font-weight: 600;
  font-size: 13px;
  border-bottom: 1px solid #eef1f6;
}

.txn-panel__empty {
  padding: 20px 0;
  color: #b6bfcb;
  font-size: 12px;
  text-align: center;
}

.error-log__item {
  padding: 10px 12px;
  margin-bottom: 8px;
  cursor: pointer;
  background: #fff1f0;
  border: 1px solid #ffccc7;
  border-radius: 6px;
  transition: 0.2s;

  &:hover {
    border-color: #ff7875;
  }
}

.error-log__title {
  color: #cf1322;
  font-weight: 600;
  font-size: 12px;
}

.error-log__desc {
  margin-top: 4px;
  color: #666;
  font-size: 12px;
}

.error-log__help {
  margin-top: 6px;
  color: #1890ff;
  font-size: 12px;
  text-decoration: underline;
}
</style>
