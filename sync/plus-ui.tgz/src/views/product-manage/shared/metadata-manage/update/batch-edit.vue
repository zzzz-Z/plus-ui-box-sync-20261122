<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
import { Close, EditPen, RefreshLeft, RefreshRight, Search } from '@element-plus/icons-vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import {
  activeField,
  batchFill,
  canRedo,
  canUndo,
  cellHasError,
  discardEdits,
  findReplace,
  handleSelection,
  isChanged,
  keyword,
  levelOptions,
  locating,
  pushHistory,
  redo,
  scope,
  selectedIds,
  undo,
  visibleRows
} from './state';
import type { MetadataRecord } from '@/api/product-manage/types';

/** 目标字段行内编辑器：修改草稿 fields[field.name]，聚焦即压入撤销快照 */
function fieldEditor(row: MetadataRecord) {
  const field = activeField.value;
  if (!field) return <span class="cell-empty">—</span>;

  const bind = {
    'modelValue': row.fields?.[field.name],
    'onUpdate:modelValue': (next: any) => {
      if (!row.fields) row.fields = {};
      row.fields[field.name] = next;
    },
    'onFocus': () => pushHistory()
  };
  const cls = ['cell-edit', isChanged(row) ? 'is-changed' : '', cellHasError(row.recordUid) ? 'is-error' : ''].filter(Boolean).join(' ');

  if (field.type === 'level' || field.type === 'enum') {
    const options = field.type === 'level' ? levelOptions.value : (field.options ?? []);
    return (
      <el-select {...bind} size="small" class={cls} style="width: 100%">
        {options.map((option) => (
          <el-option key={option} label={option} value={option} />
        ))}
      </el-select>
    );
  }
  return (
    <el-input
      {...bind}
      size="small"
      class={cls}
      clearable={field.nullable}
      placeholder={`${field.displayName}${field.nullable ? '' : pt('（必填）')}`}
    />
  );
}

const columns = computed<TableColumn<MetadataRecord>[]>(() => {
  const field = activeField.value;
  const cols: TableColumn<MetadataRecord>[] = [
    { type: 'selection', width: 42 },
    { label: pt('记录ID'), prop: 'id', width: 76 },
    { label: pt('产品名称'), prop: 'name', minWidth: 170, showOverflowTooltip: true }
  ];
  if (field) {
    cols.push({
      label: `${field.displayName}（待更新）`,
      minWidth: 240,
      render: ({ row }) => fieldEditor(row)
    });
  }
  cols.push({ label: pt('版本'), prop: 'version', width: 88 }, { label: pt('更新时间'), prop: 'updatedAt', width: 168 });
  return cols;
});

async function onBatchFill() {
  const field = activeField.value;
  if (!field) return;
  if (scope.value === 'selected' && !selectedIds.value.length) {
    ElMessage.warning(pt('请先勾选要填充的记录行'));
    return;
  }
  try {
    const { value } = await ElMessageBox.prompt(
      `将「${field.displayName}」批量填充为固定值（应用于${scope.value === 'selected' ? pt('已勾选') : pt('全部')}记录）`,
      pt('批量填充'),
      { inputPlaceholder: field.displayName, inputValue: field.type === 'path' ? '/data/primary/' : '' }
    );
    pushHistory();
    const count = batchFill(value ?? '');
    ElMessage.success(`已填充 ${count} 条记录的「${field.displayName}」`);
  } catch {
    /* 取消 */
  }
}

async function onFindReplace() {
  const field = activeField.value;
  if (!field) return;
  try {
    const { value: from } = await ElMessageBox.prompt(`在「${field.displayName}」中查找文本片段`, pt('查找替换 · 第一步'), {
      inputPlaceholder: pt('原文本片段')
    });
    if (!from) return;
    const { value: to } = await ElMessageBox.prompt(`将「${from}」替换为`, pt('查找替换 · 第二步'), { inputPlaceholder: pt('新文本片段') });
    pushHistory();
    const count = findReplace(from, to ?? '');
    ElMessage.success(count ? `已替换 ${count} 条记录` : pt('没有匹配到需要替换的内容'));
  } catch {
    /* 取消 */
  }
}

function onUndo() {
  if (!undo()) ElMessage.info(pt('没有可撤销的操作'));
}

function onRedo() {
  if (!redo()) ElMessage.info(pt('没有可重做的操作'));
}

function onDiscard() {
  ElMessageBox.confirm(pt('确定放弃所有修改吗？草稿将回退到修改前状态。'), pt('放弃修改'), { type: 'warning' })
    .then(() => {
      pushHistory();
      discardEdits();
      ElMessage.success(pt('已放弃修改，恢复到更新前状态'));
    })
    .catch(() => {});
}

function rowClassName({ row }: { row: any }) {
  return locating.value?.recordUid === row.recordUid ? 'is-locating' : '';
}

/** Ctrl+Z 撤销 / Ctrl+Shift+Z 重做（输入框内保留原生撤销） */
function onKeydown(event: KeyboardEvent) {
  const tag = (event.target as HTMLElement)?.tagName;
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'z' && tag !== 'INPUT' && tag !== 'TEXTAREA') {
    event.preventDefault();
    if (event.shiftKey) onRedo();
    else onUndo();
  }
}

onMounted(() => window.addEventListener('keydown', onKeydown));
onUnmounted(() => window.removeEventListener('keydown', onKeydown));
</script>

<template>
  <div class="batch-edit">
    <div class="batch-edit__toolbar">
      <el-button size="small" :icon="EditPen" @click="onBatchFill"> {{ pt('批量填充') }} </el-button>
      <el-button size="small" :icon="Search" @click="onFindReplace"> {{ pt('查找替换') }} </el-button>
      <el-button size="small" :icon="RefreshLeft" :disabled="!canUndo" @click="onUndo"> {{ pt('撤销') }} </el-button>
      <el-button size="small" :icon="RefreshRight" :disabled="!canRedo" @click="onRedo"> {{ pt('重做') }} </el-button>
      <el-button size="small" type="danger" plain :icon="Close" @click="onDiscard"> {{ pt('放弃修改') }} </el-button>
      <el-input v-model="keyword" size="small" class="batch-edit__search" :placeholder="pt('搜索记录ID/名称')" clearable :prefix-icon="Search" />
    </div>

    <div class="batch-edit__tip">
      {{ pt('双击单元格即可编辑；勾选行后可批量填充。支持查找替换、撤销（Ctrl+Z）/重做，编辑时按模型约束（类型/范围/必填）自动校验。') }}
    </div>

    <div class="batch-edit__table">
      <Table
        :columns="columns"
        :data="visibleRows"
        :pagination="false"
        :row-class-name="rowClassName"
        auto-height
        @selection-change="handleSelection"
      />
    </div>
  </div>
</template>

<style scoped lang="scss">
.batch-edit {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
}

.batch-edit__toolbar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
}

.batch-edit__search {
  width: 200px;
  margin-left: auto;
}

.batch-edit__tip {
  margin-bottom: 8px;
  color: #8695a8;
  font-size: 12px;
  line-height: 1.6;
}

.batch-edit__table {
  flex: 1;
  min-height: 0;
}

/* .cell-empty 只出现在 columns 的 JSX render 里（不在 <template> 中）。
   formatter 由 ElTable 在其自身渲染上下文执行，产出的 vnode 带的是 ElTable 的 scopeId，
   不是本组件的，因此 `scoped` 编出的 `.cell-empty[data-v-xxx]` 永远匹配不到，占位色静默失效。
   改用 :deep()：编译成 `[data-v-xxx] .cell-empty`，由 .batch-edit 上的本组件 scope 锚定。 */
:deep(.cell-empty) {
  color: #c0c4cc;
}
</style>

<style lang="scss">
.batch-edit .cell-edit.is-changed .el-input__wrapper,
.batch-edit .cell-edit.is-changed .el-select__wrapper {
  background: #fff7e6;
  box-shadow: 0 0 0 1px #ffd591 inset;
}

.batch-edit .cell-edit.is-error .el-input__wrapper,
.batch-edit .cell-edit.is-error .el-select__wrapper {
  background: #fff1f0;
  box-shadow: 0 0 0 1px #ff4d4f inset;
}

.batch-edit .el-table__row.is-locating > td.el-table__cell {
  background: #fff7e6;
}
</style>
