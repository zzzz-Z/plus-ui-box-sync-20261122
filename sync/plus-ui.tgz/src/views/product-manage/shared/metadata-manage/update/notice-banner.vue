<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
import { Bell } from '@element-plus/icons-vue';
import { bannerText, bannerVisible, pendingCount, selectTask, tasks } from './state';

/** 立即处理：定位到首个待处理任务并进入向导第一步 */
function handleNow() {
  bannerVisible.value = false;
  const firstPending = tasks.value.find((task) => task.status === 'pending');
  if (firstPending) selectTask(firstPending.id);
}
</script>

<template>
  <div v-if="bannerVisible && bannerText" class="notify-banner">
    <el-icon class="notify-banner__icon">
      <Bell />
    </el-icon>
    <div class="notify-banner__msg">
      {{ bannerText }}
    </div>
    <el-tag size="small" type="warning" effect="dark" round> 待更新 {{ pendingCount }} 条 </el-tag>
    <el-button type="warning" size="small" @click="handleNow"> {{ pt('立即处理') }} </el-button>
    <el-button text size="small" @click="bannerVisible = false"> {{ pt('稍后') }} </el-button>
  </div>
</template>

<style scoped lang="scss">
.notify-banner {
  display: flex;
  align-items: center;
  gap: 10px;
  flex: none;
  padding: 8px 14px;
  color: #ad6800;
  font-size: 13px;
  background: linear-gradient(90deg, #fff7e6, #fffbe6);
  border: 1px solid #ffd591;
  border-radius: 4px;

  &__icon {
    color: #fa8c16;
    font-size: 16px;
  }

  &__msg {
    flex: 1;
    min-width: 0;
    line-height: 1.5;
  }
}
</style>
