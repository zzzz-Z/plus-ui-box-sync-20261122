<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
import { ElMessage } from 'element-plus';
import BatchEdit from './batch-edit.vue';
import { activeField, activeTask, changeLog, diffRows, lastResult, nowText, restart, scope, SCOPE_OPTIONS, stats, step, STEPS, txn } from './state';

/** 预览影响：已修改记录的变更前后对比（扁平化供 el-table 渲染） */
const previewData = computed(() =>
  diffRows().map((item) => ({
    id: item.row.id,
    name: item.row.name,
    fieldLabel: item.fieldLabel,
    before: item.before,
    after: item.after
  }))
);

/** 下载更新报告（复用 Blob + a[download] 模式，生成变更明细文本） */
function downloadReport() {
  const task = activeTask.value;
  const lines = [
    '元数据更新报告',
    '================================',
    `事务ID：${txn.id}`,
    `更新任务：${task?.name ?? ''}`,
    `目标元数据表：${task?.tableName ?? ''}`,
    `目标字段：${task?.fieldLabel ?? ''}`,
    `更新记录：${lastResult.value?.count ?? 0} 条`,
    `耗时：${lastResult.value?.duration ?? 0}s`,
    `生成时间：${nowText()}`,
    '',
    '变更历史：',
    ...changeLog.value.map((log) => `· [${log.time}] ${log.text}`)
  ];
  const url = URL.createObjectURL(new Blob([`\uFEFF${lines.join('\n')}`], { type: 'text/plain;charset=utf-8' }));
  const link = document.createElement('a');
  link.href = url;
  link.download = `元数据更新报告-${Date.now()}.txt`;
  link.click();
  URL.revokeObjectURL(url);
  ElMessage.success(pt('更新报告已下载'));
}
</script>

<template>
  <div class="wizard">
    <el-steps :active="step" finish-status="success" align-center class="wizard__steps">
      <el-step v-for="label in STEPS" :key="label" :title="label" />
    </el-steps>

    <div class="wizard__body">
      <!-- ① 选择更新范围 -->
      <template v-if="step === 0">
        <el-descriptions :column="2" border size="small" class="wizard__desc">
          <el-descriptions-item :label="pt('更新任务')">
            {{ activeTask?.name ?? '—' }}
          </el-descriptions-item>
          <el-descriptions-item :label="pt('目标元数据表')">
            {{ activeTask?.tableName ?? '—' }}
          </el-descriptions-item>
          <el-descriptions-item :label="pt('目标字段')">
            {{ activeField?.displayName ?? '—' }}
            <el-tag v-if="activeField" size="small" type="info">
              {{ activeField.type }}
            </el-tag>
          </el-descriptions-item>
          <el-descriptions-item :label="pt('影响记录')"> {{ stats.total }} 条 </el-descriptions-item>
          <el-descriptions-item :label="pt('变更说明')" :span="2">
            {{ activeTask?.changeSummary ?? '—' }}
          </el-descriptions-item>
        </el-descriptions>

        <div class="wizard__scope">
          <div class="wizard__scope-title">{{ pt('选择更新范围') }}</div>
          <el-radio-group v-model="scope" class="wizard__scope-group">
            <el-radio v-for="option in SCOPE_OPTIONS" :key="option.value" :value="option.value" border class="wizard__scope-item">
              {{ option.label }}
              <span class="wizard__scope-hint">{{ option.hint }}</span>
            </el-radio>
          </el-radio-group>
        </div>
      </template>

      <!-- ② 预览影响 -->
      <template v-else-if="step === 1">
        <el-alert type="success" :closable="false" show-icon class="wizard__alert">
          <template #title>
            将更新 <strong>{{ previewData.length || stats.total }}</strong> 条记录，涉及字段「{{ activeField?.displayName }}」
          </template>
          <div class="wizard__alert-desc">变更类型：{{ activeTask?.changeSummary }}</div>
        </el-alert>

        <el-table v-if="previewData.length" :data="previewData" size="small" border class="wizard__diff">
          <el-table-column prop="id" label="记录ID" width="80" />
          <el-table-column prop="name" label="产品名称" min-width="150" show-overflow-tooltip />
          <el-table-column prop="fieldLabel" label="字段" width="110" />
          <el-table-column label="变更前" min-width="180">
            <template #default="{ row }">
              <span class="diff-before">{{ row.before || '（空）' }}</span>
            </template>
          </el-table-column>
          <el-table-column label="变更后" min-width="180">
            <template #default="{ row }">
              <span class="diff-after">{{ row.after || '（空）' }}</span>
            </template>
          </el-table-column>
        </el-table>
        <el-empty v-else description="尚未修改字段值，可在「批量编辑」步骤填充/替换后再预览差异" :image-size="70" />
      </template>

      <!-- ③ 批量编辑 -->
      <template v-else-if="step === 2">
        <BatchEdit />
      </template>

      <!-- ④ 执行更新 -->
      <template v-else-if="step === 3">
        <div class="wizard__exec">
          <el-progress
            :percentage="txn.progress"
            :status="txn.status === 'success' ? 'success' : txn.status === 'failed' ? 'exception' : undefined"
            :stroke-width="16"
            text-inside
          />
          <div class="wizard__exec-msg">
            {{ txn.status === 'running' ? '事务进行中，正在批量写入元数据…' : txn.status === 'success' ? '事务已提交' : '事务已回退' }}
          </div>
          <div class="wizard__exec-sub">已处理 {{ txn.processed }} / {{ txn.total }} · 耗时 {{ txn.elapsed }}s · {{ txn.id }}</div>
        </div>
      </template>

      <!-- ⑤ 完成确认 -->
      <template v-else>
        <el-result
          :icon="lastResult?.success === false ? 'error' : 'success'"
          :title="lastResult?.success === false ? '更新失败，已回退' : '更新完成'"
          :sub-title="
            lastResult?.success === false
              ? `检测到 ${lastResult?.count ?? 0} 处校验错误，事务未提交，请返回批量编辑修正后重试`
              : `事务 ${txn.id} 已提交，成功更新 ${lastResult?.count ?? 0} 条记录，耗时 ${lastResult?.duration ?? 0}s`
          "
        >
          <template #extra>
            <el-button v-if="lastResult?.success !== false" type="primary" @click="downloadReport"> 下载更新报告 </el-button>
            <el-button v-else type="primary" @click="step = 2"> 返回修改 </el-button>
            <el-button @click="restart"> 重新开始 </el-button>
          </template>
        </el-result>
      </template>
    </div>
  </div>
</template>

<style scoped lang="scss">
.wizard {
  display: flex;
  flex-direction: column;
  flex: 1;
  min-width: 0;
  min-height: 0;
  overflow: hidden;
  background: var(--el-bg-color);
  border: 1px solid #eef1f6;
}

.wizard__steps {
  flex: none;
  padding: 16px 24px;
  background: #fafbfc;
  border-bottom: 1px solid #eef1f6;
}

.wizard__body {
  flex: 1;
  min-height: 0;
  padding: 16px 20px;
  overflow: auto;
}

.wizard__desc {
  margin-bottom: 16px;
}

.wizard__scope-title {
  margin-bottom: 10px;
  color: #243752;
  font-weight: 600;
  font-size: 13px;
}

.wizard__scope-group {
  display: flex;
  flex-direction: column;
  gap: 10px;
  width: 100%;
}

.wizard__scope-item {
  width: 100%;
  height: auto;
  margin-right: 0;
  padding: 10px 14px;

  :deep(.el-radio__label) {
    display: flex;
    flex-direction: column;
    gap: 2px;
    white-space: normal;
    line-height: 1.5;
  }
}

.wizard__scope-hint {
  color: #98a4b4;
  font-size: 12px;
  font-weight: 400;
}

.wizard__alert {
  margin-bottom: 14px;
}

.wizard__alert-desc {
  font-size: 12px;
}

.wizard__diff {
  width: 100%;
}

.diff-before {
  color: #ff4d4f;
  text-decoration: line-through;
}

.diff-after {
  color: #52c41a;
  font-weight: 500;
}

.wizard__exec {
  padding: 40px 30px;
  text-align: center;

  &-msg {
    margin-top: 18px;
    color: #243752;
    font-weight: 600;
    font-size: 15px;
  }

  &-sub {
    margin-top: 8px;
    color: #8695a8;
    font-size: 12px;
  }
}
</style>
