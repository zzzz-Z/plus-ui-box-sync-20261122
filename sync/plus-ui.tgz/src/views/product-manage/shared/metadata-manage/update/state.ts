import { computed, reactive, ref } from 'vue';
import { queryMetadataRecords } from '@/api/product-manage/platform/metadata-query';
import { withEditLock } from '@/api/product-manage/platform/metadata-records';
import { planChangeWizard, applyChangeWizard } from '@/api/product-manage/platform/change-wizard';
import type { MetadataRecord, ModelField } from '@/api/product-manage/types';

/**
 * 元数据更新共享状态（向导式批量更新）
 *
 * 数据全部来自真实接口，无 mock、无 adapter 包装：
 *  - 取数：POST /platform/metadata-records/query（items=真实记录，fields=真实字段定义）；
 *  - 预览：POST /platform/metadata/change-wizard/plan（只读影响计划）；
 *  - 提交：先 POST /platform/metadata-records/{...}/edit-sessions 取 lockToken，
 *    再 POST /platform/metadata/change-wizard/apply 原子落库（同一事务 + 权威历史 + outbox）。
 *
 * 字段一律用契约真实键：resourceUid / tableKey / metadataUid / rowVersion /
 * fieldKey(→ 本地 field.name) / values / expectedRowVersions / lockToken。
 * UI 反馈（ElMessage/ElMessageBox）由组件层负责，本模块只做数据与业务操作。
 */

/** query 响应 fields[] 的真实字段定义（字段名为契约原文，可能随后端扩展，故宽松） */
export interface WizardFieldDef {
  fieldKey: string;
  name?: string;
  displayName?: string;
  label?: string;
  type?: string;
  nullable?: boolean;
  required?: boolean;
  options?: string[];
  length?: number;
  description?: string;
  tableKey?: string;
  modelUid?: string;
}

/** 向导内的真实记录：兼容 MetadataRecord 结构（供批量编辑表格使用），并携带 apply 必需的真实键 */
export interface WizardRecord extends MetadataRecord {
  metadataUid: string;
  resourceUid: string;
  tableKey: string;
  rowVersion: number;
}

export interface TableOption {
  modelUid: string;
  modelName: string;
  tableUid: string;
  tableName: string;
  fields: ModelField[];
}

export type UpdateStatus = 'pending' | 'done' | 'failed';
export type ScopeMode = 'all' | 'selected' | 'filter';
export type TxnStatus = 'idle' | 'running' | 'success' | 'failed';

/** 一条待更新的元数据模型变更（由真实元数据表 + 真实字段定义派生） */
export interface UpdateTask {
  id: number;
  name: string;
  changeSummary: string;
  tableUid: string;
  tableName: string;
  fieldName: string;
  fieldLabel: string;
  affectedCount: number;
  status: UpdateStatus;
  createdAt: string;
}

export interface TxnState {
  id: string;
  status: TxnStatus;
  progress: number;
  processed: number;
  total: number;
  elapsed: number;
}

/** 可定位的错误日志条目：双击/点击跳转到批量编辑对应记录字段 */
export interface ErrorEntry {
  recordUid: string;
  recordName: string;
  fieldName: string;
  fieldLabel: string;
  reason: string;
  help: string;
}

export interface ChangeLogEntry {
  text: string;
  time: string;
}

/** 向导五步（el-steps active 使用 0-based 索引） */
export const STEPS = ['选择范围', '预览影响', '批量编辑', '执行更新', '完成确认'];

export const SCOPE_OPTIONS: Array<{ label: string; value: ScopeMode; hint: string }> = [
  { label: '全部受影响记录', value: 'all', hint: '更新目标元数据表内全部记录' },
  { label: '仅选中记录', value: 'selected', hint: '仅更新批量编辑中勾选的记录' },
  { label: '当前筛选结果', value: 'filter', hint: '仅更新搜索命中的记录' }
];

export const TASK_STATUS_TAG: Record<UpdateStatus, { label: string; type: 'warning' | 'success' | 'danger' }> = {
  pending: { label: '待处理', type: 'warning' },
  done: { label: '已完成', type: 'success' },
  failed: { label: '已回退', type: 'danger' }
};

// ---------------------------------------------------------------------------
// 响应式状态
// ---------------------------------------------------------------------------

export const tableOptions = ref<TableOption[]>([]);
export const allRecords = ref<WizardRecord[]>([]);
export const wizardFields = ref<WizardFieldDef[]>([]);
export const tasks = ref<UpdateTask[]>([]);
export const activeTaskId = ref<number>();

export const scope = ref<ScopeMode>('all');
export const keyword = ref('');
export const selectedIds = ref<number[]>([]);

/** 批量编辑草稿与修改前快照（事务回退基准） */
export const editRows = ref<WizardRecord[]>([]);
export const originRows = ref<WizardRecord[]>([]);

export const step = ref(0);
export const executing = ref(false);
export const bannerVisible = ref(true);
export const locating = ref<{ recordUid: string; fieldName: string } | null>(null);

export const txn = reactive<TxnState>({ id: '', status: 'idle', progress: 0, processed: 0, total: 0, elapsed: 0 });
export const errors = ref<ErrorEntry[]>([]);
export const changeLog = ref<ChangeLogEntry[]>([]);
/** 最近一次事务结果（供完成确认步骤展示，独立于 stats 基线） */
export const lastResult = ref<{ success: boolean; count: number; duration: number } | null>(null);

// 撤销/重做：以 editRows 的 JSON 快照为粒度
const undoStack = ref<string[]>([]);
const redoStack = ref<string[]>([]);

// ---------------------------------------------------------------------------
// 计算属性
// ---------------------------------------------------------------------------

export const activeTask = computed(() => tasks.value.find((task) => task.id === activeTaskId.value));

export const activeField = computed<ModelField | undefined>(() => {
  const task = activeTask.value;
  if (!task) return undefined;
  const table = tableOptions.value.find((item) => item.tableUid === task.tableUid);
  return table?.fields.find((field) => field.name === task.fieldName);
});

const originMap = computed(() => new Map(originRows.value.map((row) => [row.recordUid, row])));

/** 搜索过滤后的可见行（批量编辑表格数据源） */
export const visibleRows = computed(() => {
  const kw = keyword.value.trim().toLowerCase();
  if (!kw) return editRows.value;
  return editRows.value.filter((row) => `${row.id}${row.name}${row.recordUid}`.toLowerCase().includes(kw));
});

/** 待更新记录总数（横幅/头部统计） */
export const pendingCount = computed(() =>
  tasks.value.filter((task) => task.status === 'pending').reduce((sum, task) => sum + task.affectedCount, 0)
);

/** 横幅文案：聚合待处理变更 */
export const bannerText = computed(() => {
  const pending = tasks.value.filter((task) => task.status === 'pending');
  if (!pending.length) return '';
  const items = pending.map((task, index) => `${index + 1}）${task.changeSummary}`).join('；');
  return `检测到 ${pending.length} 项可更新的元数据模型变更：${items}。影响 ${pendingCount.value} 条记录，建议尽快处理。`;
});

function isRowChanged(row: WizardRecord) {
  const field = activeField.value;
  const origin = originMap.value.get(row.recordUid);
  if (!field || !origin) return false;
  return origin.fields?.[field.name] !== row.fields?.[field.name];
}

/** 更新统计：总数 / 已修改 / 校验通过 / 校验失败 */
export const stats = computed(() => {
  const field = activeField.value;
  let modified = 0;
  let valid = 0;
  let invalid = 0;
  if (field) {
    editRows.value.forEach((row) => {
      if (!isRowChanged(row)) return;
      modified++;
      if (validateField(field, row.fields?.[field.name]).valid) valid++;
      else invalid++;
    });
  }
  return { total: editRows.value.length, modified, valid, invalid };
});

// ---------------------------------------------------------------------------
// 工具
// ---------------------------------------------------------------------------

export function nowText() {
  return new Date().toLocaleString('zh-CN', { hour12: false });
}

function clone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value));
}

export function isChanged(row: WizardRecord) {
  return isRowChanged(row);
}

/** 某记录目标字段是否处于错误态（用于单元格高亮） */
export function cellHasError(recordUid: string) {
  return errors.value.some((error) => error.recordUid === recordUid);
}

// ---------------------------------------------------------------------------
// 字段校验（类型 / 范围 / 枚举）——一律基于真实字段定义，不含硬编码枚举
// ---------------------------------------------------------------------------

export function validateField(field: ModelField, value: any): { valid: boolean; reason: string; help: string } {
  const empty = value === undefined || value === null || String(value).trim() === '';
  if (!field.nullable && empty) return { valid: false, reason: '必填字段不能为空', help: `「${field.displayName}」为必填项，请输入有效值` };
  if (empty) return { valid: true, reason: '', help: '' };

  const text = String(value);
  if (field.type === 'path') {
    const max = field.length ?? 512;
    if (text.length > max) return { valid: false, reason: `路径超过 ${max} 字符`, help: `路径长度需 ≤ ${max}` };
  }
  if ((field.type === 'level' || field.type === 'enum') && field.options?.length && !field.options.includes(text))
    return { valid: false, reason: '取值不在枚举范围内', help: `可选值：${field.options.join(' / ')}` };
  if (field.type === 'integer' && !/^-?\d+$/.test(text)) return { valid: false, reason: '取值必须是整数', help: '请输入合法整数' };

  return { valid: true, reason: '', help: '' };
}

/** 字段下拉选项：完全来自真实字段定义 */
export const levelOptions = computed(() => {
  const field = activeField.value;
  return field?.options ?? [];
});

/** 收集将被更新（已修改）记录中的校验错误 */
export function collectErrors(): ErrorEntry[] {
  const field = activeField.value;
  if (!field) return [];
  const list: ErrorEntry[] = [];
  editRows.value.forEach((row) => {
    if (!isRowChanged(row)) return;
    const result = validateField(field, row.fields?.[field.name]);
    if (!result.valid) {
      list.push({
        recordUid: row.recordUid,
        recordName: row.name,
        fieldName: field.name,
        fieldLabel: field.displayName,
        reason: result.reason,
        help: result.help
      });
    }
  });
  return list;
}

/** 预览影响：已修改记录的变更前后对比 */
export function diffRows() {
  const field = activeField.value;
  if (!field) return [];
  return editRows.value
    .map((row) => {
      const origin = originMap.value.get(row.recordUid);
      const before = origin?.fields?.[field.name];
      const after = row.fields?.[field.name];
      return { row, fieldLabel: field.displayName, before, after, changed: before !== after };
    })
    .filter((item) => item.changed);
}

// ---------------------------------------------------------------------------
// 真实数据加载与任务构建（无 mock）
// ---------------------------------------------------------------------------

/** query 单条真实记录 → 向导记录（attributes 即真实业务字段字典） */
function toWizardRecord(item: any, index: number): WizardRecord {
  const attributes = item.attributes ?? {};
  const name = String(attributes.name ?? attributes.product_name ?? attributes.title ?? String(item.metadataUid ?? '').slice(0, 8));
  return {
    id: index + 1,
    recordUid: String(item.metadataUid ?? ''),
    metadataUid: String(item.metadataUid ?? ''),
    resourceUid: String(item.resourceUid ?? ''),
    tableKey: String(item.tableKey ?? ''),
    rowVersion: Number(item.rowVersion ?? 1),
    modelUid: String(item.modelUid ?? ''),
    tableUid: String(item.tableKey ?? ''),
    tableName: String(item.resourceName ?? item.tableKey ?? ''),
    name,
    version: item.versionNo ?? 1,
    category: item.categoryName,
    createdAt: item.createdAt ?? '',
    updatedAt: item.updatedAt ?? '',
    fields: { ...attributes }
  } as WizardRecord;
}

/** 由真实字段定义 + 真实记录表名，构建每张表的可编辑字段选项 */
function buildTableOptions() {
  const nameByTable = new Map<string, string>();
  allRecords.value.forEach((r) => {
    if (!nameByTable.has(r.tableKey) && r.tableName) nameByTable.set(r.tableKey, r.tableName);
  });

  const map = new Map<string, TableOption>();
  wizardFields.value.forEach((fd) => {
    const tk = String(fd.tableKey ?? '');
    if (!tk) return;
    if (!map.has(tk))
      map.set(tk, {
        modelUid: String(fd.modelUid ?? ''),
        modelName: String(fd.modelUid ?? tk),
        tableUid: tk,
        tableName: nameByTable.get(tk) ?? tk,
        fields: []
      });
    const fields = map.get(tk)!.fields;
    if (!fields.some((f) => f.name === fd.fieldKey)) {
      fields.push({
        uid: fd.fieldKey,
        name: fd.fieldKey,
        displayName: fd.displayName || fd.label || fd.name || fd.fieldKey,
        type: fd.type || 'string',
        nullable: fd.nullable ?? true,
        options: fd.options,
        length: fd.length,
        description: fd.description
      } as ModelField);
    }
  });

  // 补只有真实记录、没有字段定义的表（字段从记录 attributes 推断）
  allRecords.value.forEach((r) => {
    if (map.has(r.tableKey)) return;
    const keys = Object.keys(r.fields ?? {});
    map.set(r.tableKey, {
      modelUid: r.modelUid,
      modelName: r.modelUid || r.tableKey,
      tableUid: r.tableKey,
      tableName: r.tableName || r.tableKey,
      fields: keys.map((key) => ({ uid: key, name: key, displayName: key, type: 'string', nullable: true }) as ModelField)
    });
  });

  tableOptions.value = [...map.values()];
}

/** 任务由真实表 + 真实字段定义派生：每个表定位到一个「在真实记录中存在」的可编辑字段 */
function buildTasks() {
  tasks.value = tableOptions.value.map((table, index) => {
    const records = allRecords.value.filter((r) => r.tableKey === table.tableUid);
    const field =
      table.fields.find((f) => records.some((r) => r.fields && Object.prototype.hasOwnProperty.call(r.fields, f.name))) ?? table.fields[0];
    return {
      id: index + 1,
      name: `${table.tableName} · ${field?.displayName ?? field?.name ?? '字段'} 批量更新`,
      changeSummary: `基于真实字段「${field?.displayName ?? field?.name ?? ''}」更新 ${records.length} 条存量记录`,
      tableUid: table.tableUid,
      tableName: table.tableName,
      fieldName: field?.name ?? '',
      fieldLabel: field?.displayName ?? field?.name ?? '',
      affectedCount: records.length,
      status: 'pending' as UpdateStatus,
      createdAt: records[0]?.updatedAt || nowText()
    };
  });
}

/** 依据当前任务重建批量编辑草稿与快照 */
export function buildEditRows() {
  const task = activeTask.value;
  const rows = task ? allRecords.value.filter((r) => r.tableKey === task.tableUid) : [];
  editRows.value = clone(rows);
  originRows.value = clone(rows);
  undoStack.value = [];
  redoStack.value = [];
}

export async function loadData() {
  const res = await queryMetadataRecords({ page: 1, pageSize: 200, includeFieldSchema: true });
  const data = res?.data as any;
  wizardFields.value = (data?.fields ?? []) as WizardFieldDef[];
  allRecords.value = (data?.items ?? []).map((item: any, index: number) => toWizardRecord(item, index));
  buildTableOptions();
  buildTasks();
  if (!activeTaskId.value && tasks.value.length) selectTask(tasks.value[0].id);
}

// ---------------------------------------------------------------------------
// 任务 / 范围选择
// ---------------------------------------------------------------------------

export function selectTask(id: number) {
  if (executing.value) return;
  activeTaskId.value = id;
  buildEditRows();
  scope.value = 'all';
  keyword.value = '';
  selectedIds.value = [];
  errors.value = [];
  locating.value = null;
  lastResult.value = null;
  resetTxn();
  step.value = 0;
}

export function handleSelection(rows: MetadataRecord[]) {
  selectedIds.value = rows.map((row) => row.id);
}

/** 当前范围下将被更新的行 */
export function scopedRows() {
  if (scope.value === 'selected' && selectedIds.value.length) return editRows.value.filter((row) => selectedIds.value.includes(row.id));
  if (scope.value === 'filter' && keyword.value.trim()) return visibleRows.value;
  return editRows.value;
}

// ---------------------------------------------------------------------------
// 撤销 / 重做（快照栈）
// ---------------------------------------------------------------------------

function snapshot() {
  return JSON.stringify(editRows.value);
}

/** 变更前调用：压入当前草稿快照（自动去重相邻重复） */
export function pushHistory() {
  const snap = snapshot();
  if (undoStack.value[undoStack.value.length - 1] === snap) return;
  undoStack.value.push(snap);
  if (undoStack.value.length > 50) undoStack.value.shift();
  redoStack.value = [];
}

export function undo() {
  if (!undoStack.value.length) return false;
  redoStack.value.push(snapshot());
  editRows.value = JSON.parse(undoStack.value.pop() as string);
  return true;
}

export function redo() {
  if (!redoStack.value.length) return false;
  undoStack.value.push(snapshot());
  editRows.value = JSON.parse(redoStack.value.pop() as string);
  return true;
}

export const canUndo = computed(() => undoStack.value.length > 0);
export const canRedo = computed(() => redoStack.value.length > 0);

// ---------------------------------------------------------------------------
// 批量编辑操作
// ---------------------------------------------------------------------------

/** 批量填充：将范围内记录的目标字段设为固定值（调用前请 pushHistory） */
export function batchFill(value: string) {
  const field = activeField.value;
  if (!field) return 0;
  const rows =
    scope.value === 'selected' && selectedIds.value.length ? editRows.value.filter((row) => selectedIds.value.includes(row.id)) : editRows.value;
  rows.forEach((row) => {
    if (!row.fields) row.fields = {};
    row.fields[field.name] = value;
  });
  return rows.length;
}

/** 查找替换：对范围内记录目标字段的文本片段做替换（调用前请 pushHistory） */
export function findReplace(from: string, to: string) {
  const field = activeField.value;
  if (!field || !from) return 0;
  let count = 0;
  scopedRows().forEach((row) => {
    const value = row.fields?.[field.name];
    if (typeof value === 'string' && value.includes(from)) {
      row.fields[field.name] = value.replaceAll(from, to);
      count++;
    }
  });
  return count;
}

/** 放弃修改：草稿回退到修改前快照（调用前请 pushHistory） */
export function discardEdits() {
  editRows.value = clone(originRows.value);
  errors.value = [];
}

// ---------------------------------------------------------------------------
// 事务：执行更新（真实 plan 预览 + edit-sessions 取锁 + change-wizard/apply 提交）
// ---------------------------------------------------------------------------

function buildTxnId() {
  const date = new Date();
  const stamp = `${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, '0')}${String(date.getDate()).padStart(2, '0')}`;
  const seq = String(changeLog.value.length + 1).padStart(3, '0');
  return `TXN-${stamp}-${seq}`;
}

export function resetTxn() {
  txn.id = buildTxnId();
  txn.status = 'idle';
  txn.progress = 0;
  txn.processed = 0;
  txn.total = editRows.value.length;
  txn.elapsed = 0;
}

interface ApplyGroup {
  resourceUid: string;
  tableKey: string;
  value: string;
  rows: WizardRecord[];
}

/**
 * 真实事务执行：
 *  1. 本地校验失败 → 不写库、保留草稿、回退批量编辑（步骤 2）；
 *  2. 按 (resourceUid, tableKey, 目标值) 分组（apply 的 values 对组内全部 metadataUids 统一生效）；
 *  3. 每组先调 plan（只读影响计划），再在同一 edit-session 锁内调 apply 原子提交；
 *  4. 进度按实际提交记录数推进，异常写入可定位错误日志并回退。
 */
export async function executeUpdate(): Promise<{ success: boolean; count: number }> {
  const task = activeTask.value;
  const field = activeField.value;
  if (!task || !field || executing.value) return { success: false, count: 0 };

  executing.value = true;
  errors.value = [];
  locating.value = null;
  step.value = 3;
  resetTxn();
  txn.status = 'running';
  const started = Date.now();

  const found = collectErrors();
  if (found.length) {
    errors.value = found;
    txn.status = 'failed';
    txn.elapsed = Number(((Date.now() - started) / 1000).toFixed(1));
    executing.value = false;
    task.status = 'failed';
    lastResult.value = { success: false, count: found.length, duration: txn.elapsed };
    step.value = 2;
    return { success: false, count: found.length };
  }

  const changed = diffRows();
  const total = changed.length || 1;
  txn.total = total;

  if (!changed.length) {
    txn.status = 'success';
    executing.value = false;
    lastResult.value = { success: true, count: 0, duration: 0 };
    step.value = 4;
    return { success: true, count: 0 };
  }

  const groups = new Map<string, ApplyGroup>();
  changed.forEach(({ row, after }) => {
    const value = after == null ? '' : String(after);
    const key = `${row.resourceUid}||${row.tableKey}||${value}`;
    if (!groups.has(key)) groups.set(key, { resourceUid: row.resourceUid, tableKey: row.tableKey, value, rows: [] });
    groups.get(key)!.rows.push(row);
  });

  try {
    let processed = 0;
    let totalUpdated = 0;
    for (const group of groups.values()) {
      const metadataUids = group.rows.map((r) => r.metadataUid);
      const values: Record<string, string> = { [field.name]: group.value };

      // 服务端只读影响计划（plan 契约：无 lockToken）
      const planRes = await planChangeWizard({
        resourceUid: group.resourceUid,
        tableKey: group.tableKey,
        operation: 'update',
        metadataUids,
        values
      });
      (planRes?.data?.steps ?? []).forEach((s) => {
        if (!s.exists)
          errors.value.push({
            recordUid: s.metadataUid,
            recordName: s.metadataUid,
            fieldName: field.name,
            fieldLabel: field.displayName,
            reason: '记录不存在或已删除',
            help: '请刷新后重试'
          });
      });

      const expectedRowVersions: Record<string, number> = {};
      group.rows.forEach((r) => {
        expectedRowVersions[r.metadataUid] = r.rowVersion;
      });

      // 同一编辑锁内应用变更（apply 契约：lockToken + expectedRowVersions）
      const applyRes = await withEditLock(group.resourceUid, group.tableKey, { mode: 'records', metadataUids }, async (lock) =>
        applyChangeWizard({
          resourceUid: group.resourceUid,
          tableKey: group.tableKey,
          operation: 'update',
          metadataUids,
          values,
          expectedRowVersions,
          lockToken: lock.lockToken,
          lockRevision: lock.lockRevision,
          requestId: txn.id
        })
      );

      totalUpdated += applyRes?.data?.updated ?? metadataUids.length;
      processed += group.rows.length;
      txn.processed = processed;
      txn.progress = Math.round((processed / total) * 100);
      txn.elapsed = Number(((Date.now() - started) / 1000).toFixed(1));
    }

    const success = errors.value.length === 0;
    txn.status = success ? 'success' : 'failed';
    executing.value = false;
    task.status = success ? 'done' : 'failed';
    lastResult.value = { success, count: totalUpdated, duration: txn.elapsed };
    changeLog.value.unshift({
      text: `「${task.tableName}」字段「${task.fieldLabel}」经 change-wizard 更新：成功 ${totalUpdated} 条（plan 预览 + apply 事务提交）`,
      time: nowText()
    });
    if (!success) {
      step.value = 2;
      return { success: false, count: totalUpdated };
    }
    step.value = 4;
    return { success: true, count: totalUpdated };
  } catch (err: any) {
    txn.status = 'failed';
    executing.value = false;
    task.status = 'failed';
    const msg = err?.message ?? (typeof err === 'string' ? err : '更新失败');
    errors.value.push({
      recordUid: '',
      recordName: '',
      fieldName: field.name,
      fieldLabel: field.displayName,
      reason: msg,
      help: '请检查接口返回或稍后重试'
    });
    lastResult.value = { success: false, count: 0, duration: Number(((Date.now() - started) / 1000).toFixed(1)) };
    step.value = 2;
    return { success: false, count: 0 };
  }
}

/** 错误日志定位：跳转到批量编辑并标记目标记录 */
export function locateError(entry: ErrorEntry) {
  locating.value = { recordUid: entry.recordUid, fieldName: entry.fieldName };
  step.value = 2;
}

/** 重新开始：重置当前任务向导（保留已完成任务状态） */
export function restart() {
  selectTask(activeTaskId.value ?? tasks.value[0]?.id ?? 0);
  bannerVisible.value = true;
}

// ---------------------------------------------------------------------------
// 步骤导航
// ---------------------------------------------------------------------------

export function goToStep(target: number) {
  if (executing.value || target < 0 || target > 4) return;
  step.value = target;
}

export function nextStep() {
  if (executing.value) return;
  if (step.value < 2) step.value++;
  else if (step.value === 2) executeUpdate();
}

export function prevStep() {
  if (step.value > 0 && !executing.value) step.value--;
}
