<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
import { activeTaskId, selectTask, stats, TASK_STATUS_TAG, tasks } from './state';
</script>

<template>
  <div class="scope-panel">
    <div class="scope-panel__block">
      <div class="scope-panel__title">
        {{ pt('更新任务') }}
        <el-badge :value="tasks.length" type="primary" />
      </div>
      <div v-for="task in tasks" :key="task.id" class="task-item" :class="{ active: task.id === activeTaskId }" @click="selectTask(task.id)">
        <div class="task-item__name">
          {{ task.name }}
          <el-tag :type="TASK_STATUS_TAG[task.status].type" size="small" effect="light" round>
            {{ TASK_STATUS_TAG[task.status].label }}
          </el-tag>
        </div>
        <div class="task-item__meta">影响 {{ task.affectedCount }} 条 · {{ task.createdAt }}</div>
      </div>
    </div>

    <div class="scope-panel__block">
      <div class="scope-panel__title">{{ pt('更新统计') }}</div>
      <ul class="stat-list">
        <li>
          {{ pt('总记录') }} <strong>{{ stats.total }}</strong>
        </li>
        <li>
          {{ pt('已修改') }} <strong class="is-modified">{{ stats.modified }}</strong>
        </li>
        <li>
          {{ pt('校验通过') }} <strong class="is-valid">{{ stats.valid }}</strong>
        </li>
        <li>
          {{ pt('校验失败') }} <strong class="is-invalid">{{ stats.invalid }}</strong>
        </li>
      </ul>
    </div>
  </div>
</template>

<style scoped lang="scss">
.scope-panel {
  display: flex;
  flex-direction: column;
  gap: 16px;
  width: 240px;
  flex: none;
  padding: 14px;
  overflow-y: auto;
  background: var(--el-bg-color);
  border: 1px solid #eef1f6;
}

.scope-panel__title {
  display: flex;
  align-items: center;
  gap: 8px;
  padding-bottom: 6px;
  margin-bottom: 8px;
  color: #243752;
  font-weight: 600;
  font-size: 13px;
  border-bottom: 1px solid #f1f3f6;
}

.task-item {
  padding: 10px 12px;
  margin-bottom: 6px;
  cursor: pointer;
  border: 1px solid transparent;
  border-radius: 6px;
  transition: 0.2s;

  &:hover {
    background: #f5f7fa;
  }

  &.active {
    background: #ecf5ff;
    border-color: #b3d8ff;
  }

  &__name {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 6px;
    color: #243752;
    font-weight: 500;
    font-size: 13px;
  }

  &__meta {
    margin-top: 4px;
    color: #98a4b4;
    font-size: 11px;
  }
}

.stat-list {
  margin: 0;
  padding: 0;
  color: #5a6a7d;
  font-size: 12px;
  line-height: 2;
  list-style: none;

  strong {
    float: right;
    color: #243752;
  }

  .is-modified {
    color: #fa8c16;
  }

  .is-valid {
    color: #52c41a;
  }

  .is-invalid {
    color: #ff4d4f;
  }
}
</style>
