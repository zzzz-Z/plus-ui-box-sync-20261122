<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
import * as metadataApi from '@/api/product-manage/platform/metadata';
import type { FieldTypeOption } from '@/api/product-manage/platform/metadata';
import * as categoryApi from '@/api/product-manage/platform/category';
import { ElMessage, ElMessageBox } from 'element-plus';
import { Delete, Edit, Plus } from '@element-plus/icons-vue';
import FieldEdit from './field-edit.vue';
import TableEdit from './table-edit.vue';

const props = defineProps<{
  row?: Params;
  /**
   * 新建时的默认产品类别（由调用方从当前树选中节点带过来）。
   * 只在模型自身没有任何类别时才生效 —— 编辑已有模型必须尊重它已保存的归属。
   */
  defaultCategoryKeys?: string[];
}>();

/**
 * 接口业务失败时补一句用户可见的提示。
 *
 * WHY：useAsyncData 只认 `res.code === 0`，非 0（最典型的是网关 body.code=401「token 已被冻结」）
 * 既不赋值也不报错，页面表现成「下拉空着 / 表格空着」，排查时完全看不出是接口挂了。
 * 这里包一层：原样返回响应给 useAsyncData 消费，同时把失败原因弹出来。
 */
function withLoadHint<T extends { code?: number; message?: string; msg?: string }>(loader: () => Promise<T>, label: string) {
  return async () => {
    const res = await loader();
    if (res?.code !== 0) ElMessage.error(`${label}加载失败：${res?.message ?? res?.msg ?? '接口异常'}`);
    return res;
  };
}

const form = ref();
const activeName = ref(0);
const template = ref('');
const draggedField = ref<any>();
const [fieldLibrary] = useAsyncData<any[]>(withLoadHint(metadataApi.getFieldLibrary, pt('字段库')));
// 模板只在新建时可选（编辑态已隐藏该下拉），编辑态不必再拉模板列表
const [templates] = useAsyncData<any>(withLoadHint(metadataApi.getMetadataTemplateList, pt('模型模板')), { immediate: !props.row });
// 字段类型下拉：契约 GET /metadata/field-types 是字段类型的唯一数据源，不做本地兜底
const [fieldTypes] = useAsyncData<FieldTypeOption[]>(withLoadHint(metadataApi.getFieldTypes, pt('字段类型')));
const fieldTypeOptions = computed<{ label: string; value: string }[]>(() =>
  (fieldTypes.value ?? []).filter((t) => t && t.code).map((t) => ({ label: t.displayName || t.code, value: t.code }))
);
const [category] = useAsyncData<{ tree: any[]; items: any[]; total: number }>(withLoadHint(categoryApi.getProductCategoryTree, pt('产品类别')));
const [model, , modelLoading] = useAsyncData<Params>(
  async (id) => {
    const uid = id || props.row?.modelUid;
    // 模板与模型是两套资源：模板走 /templates/{uid}，串到 /models 会 404，
    // 这正是「编辑范例模型时接口 404」的根因（save 分流对了，详情加载漏了）
    const res = await (props.row?.isTemplate ? metadataApi.getMetadataTemplateDetail(uid) : metadataApi.getMetadataModelDetail(uid));
    if (res?.code !== 0) ElMessage.error(`${props.row?.isTemplate ? pt('模板') : pt('模型')}详情加载失败：${res?.message ?? '接口异常'}`);
    return res;
  },
  {
    immediate: !!props.row,
    initialValue: { tables: [], productCategoryKeys: [], description: '', modelKey: '' },
    // 详情出参与请求成员名不一致（length / fieldLength、name / displayName、-32767 哨兵值），
    // 统一在入口抹平，页面里就只认一套名字
    transform: hydrateModel
  }
);

/**
 * 产品类别：契约里是**编码数组**，且 PATCH 传了就整组替换。
 * 所以不能再只取第一个提交 —— 多类别模型保存一次就只剩一个，且没有任何提示。
 */
const categoryKeys = ref<string[]>([]);

watch(
  model,
  (val) => {
    if (!val) return;
    // 编辑态靠详情回 modelKey；万一版本没回，用列表行兜底，至少只读框里看得到编码
    if (!val.modelKey && props.row?.modelKey) val.modelKey = props.row.modelKey;
    // 取值优先级：已保存的编码 → 详情里的完整节点 → 调用方从树带过来的默认类别
    const saved = (val.productCategoryKeys ?? []).filter(Boolean);
    const fromNodes = (val.productCategories ?? []).map((c: any) => c?.categoryKey).filter(Boolean);
    categoryKeys.value = saved.length
      ? Array.from(new Set(saved))
      : fromNodes.length
        ? Array.from(new Set(fromNodes))
        : [...(props.defaultCategoryKeys ?? [])];
  },
  { immediate: true }
);

/** 描述列宽：新建时前面有「选择模板」，描述与产品类别凑满一行；编辑态整行给描述 */
const descSpan = computed(() => (props.row ? 24 : 16));

/** 类别树预处理：「初级产品管理」「产品成果管理」仅作后端分组，不对外展示，其子级提升到顶层 */
const HIDDEN_ROOT_KEYS = new Set(['primary', 'result']);
const categoryTree = computed(() => {
  const tree = category.value?.tree ?? [];
  return tree.flatMap((node: any) => (HIDDEN_ROOT_KEYS.has(node.categoryKey) ? (node.children ?? []) : [node]));
});

/* ------------------------------------------------------------------ */
/* 契约常量：成员名 / 枚举 / 哨兵值                                     */
/* ------------------------------------------------------------------ */

/**
 * 字段语义分类。契约只认这 4 个英文值，而库里存量数据有中文（结构/管理/发现/应用），
 * 原样透传会 400「category 不受支持」。提交前统一映射，认不出的归「结构」。
 */
const FIELD_CATEGORY_MAP: Record<string, string> = {
  structure: 'structure',
  management: 'management',
  discovery: 'discovery',
  application: 'application',
  结构: 'structure',
  管理: 'management',
  发现: 'discovery',
  应用: 'application'
};

function normalizeCategory(raw: unknown): string {
  return (
    FIELD_CATEGORY_MAP[
      String(raw ?? '')
        .trim()
        .toLowerCase()
    ] ?? 'structure'
  );
}

/**
 * 是否提交字段 category。契约里它是可选成员（4 个英文枚举值），正常应当带；
 * 若某个后端版本仍报「category 不受支持」，把这里改成 false 即可整段不发。
 */
const SEND_FIELD_CATEGORY = true;

/** 契约只允许这 6 个校验规则键；本地历史数据出现过 min/max，映射后剔掉其余 */
const RULE_KEY_MAP: Record<string, string> = {
  minlength: 'minLength',
  maxlength: 'maxLength',
  minimum: 'minimum',
  maximum: 'maximum',
  min: 'minimum',
  max: 'maximum',
  pattern: 'pattern',
  enum: 'enum'
};

function normalizeValidationRule(rule: any) {
  const out: Record<string, unknown> = {};
  if (!rule || typeof rule !== 'object') return out;
  Object.keys(rule).forEach((key) => {
    const target = RULE_KEY_MAP[key.toLowerCase()];
    const value = rule[key];
    if (!target || value === undefined || value === null || value === '') return;
    out[target] = value;
  });
  return out;
}

/** 数值类型集合：判断 -32767 是不是「SQL NULL 的替代值」 */
const NUMERIC_TYPES = new Set(['integer', 'number', 'decimal', 'double', 'float', 'numeric', 'int', 'long', 'bigint']);
/** 详情接口把数值字段的 NULL 缺省值补成 -32767（契约明示），读的时候必须还原，否则一保存就固化 */
const NUMERIC_DEFAULT_SENTINEL = -32767;

function readDefaultValue(field: any) {
  const raw = field?.defaultValue;
  if (raw === null || raw === undefined || raw === '') return null;
  const type = String(field?.valueType ?? field?.type ?? '').toLowerCase();
  if (NUMERIC_TYPES.has(type) && Number(raw) === NUMERIC_DEFAULT_SENTINEL) return null;
  return raw;
}

/* ------------------------------------------------------------------ */
/* 读写两侧的成员名抹平                                                 */
/* ------------------------------------------------------------------ */

/**
 * 读侧：详情出参与请求成员名不一致，不抹平就会「显示空 + 保存清空」。
 *   · 字段长度只以 length 输出（请求名才是 fieldLength）；
 *   · 显示名/类型是 name+displayName、type+valueType 双成员并存；
 *   · category 可能是中文；defaultValue 有 -32767 哨兵。
 */
function hydrateTables(rawTables: any[]): any[] {
  return (rawTables ?? []).map((table: any) => ({
    ...table,
    tableName: table.tableName ?? table.name ?? '',
    fields: (table.fields ?? []).map((field: any) => ({
      ...field,
      displayName: field.displayName ?? field.name ?? '',
      valueType: field.valueType ?? field.type ?? 'string',
      fieldLength: field.fieldLength ?? field.length,
      category: normalizeCategory(field.category),
      defaultValue: readDefaultValue(field),
      options: Array.isArray(field.options) ? field.options : [],
      validationRule: normalizeValidationRule(field.validationRule)
    }))
  }));
}

/** 详情响应 → 表单模型（补 productCategoryKeys：详情只回 productCategories 完整节点） */
function hydrateModel(data: any) {
  const next: any = { ...(data ?? {}) };
  next.description = next.description ?? '';
  const keys = (next.productCategoryKeys ?? []).filter(Boolean);
  next.productCategoryKeys = keys.length ? keys : (next.productCategories ?? []).map((c: any) => c?.categoryKey).filter(Boolean);
  next.tables = hydrateTables(next.tables);
  return next;
}

/**
 * 保存前规范化。三条硬约束都来自契约：
 * 1) PATCH 的 tables 是**完整替换**，少传的成员等于清空 ⇒ 长度/精度/空间约束必须补回来；
 * 2) 表与字段对象没有未知成员白名单，拼错会被静默忽略 ⇒ 这里只按白名单构造；
 * 3) sortOrder 按当前显示顺序重排，否则「新增插到最前、sortOrder 却最大」会让保存后顺序翻掉。
 */
function normalizeTables(rawTables: any[]) {
  return (rawTables ?? []).map((table: any, tableIndex: number) => {
    const next: any = {
      tableKey: String(table.tableKey ?? '').trim(),
      tableName: String(table.tableName ?? '').trim(),
      tableType: table.tableType || 'table',
      description: table.description ?? '',
      sortOrder: (tableIndex + 1) * 10,
      fields: (table.fields ?? []).map((field: any, fieldIndex: number) => normalizeField(field, fieldIndex))
    };
    // spatialConstraint 是「仅设置时返回」的可选成员，漏传等于把整套坐标约束清掉
    if (table.spatialConstraint && Object.keys(table.spatialConstraint).length) next.spatialConstraint = table.spatialConstraint;
    return next;
  });
}

/** 字段白名单构造：必填项显式给，可选项「有值才带」，不凭空造默认值 */
function normalizeField(field: any, fieldIndex: number) {
  const valueType = String(field.valueType ?? '').trim() || 'string';
  // 「允许为空」开关是唯一入口：关掉就等于必填，避免存出「既不必填也不可空」的矛盾组合
  const nullable = Boolean(field.nullable);
  const next: any = {
    fieldKey: String(field.fieldKey ?? '').trim(),
    displayName: String(field.displayName ?? '').trim(),
    valueType,
    nullable,
    required: !nullable,
    options: (field.options ?? []).map((opt: any) => String(opt).trim()).filter(Boolean),
    description: field.description ?? '',
    helpText: field.helpText ?? '',
    // 显式 null 才会存成 NULL；省略该成员时数值字段会被后端补成 -32767
    defaultValue: field.defaultValue === '' || field.defaultValue === undefined ? null : field.defaultValue,
    sortOrder: (fieldIndex + 1) * 10
  };
  if (SEND_FIELD_CATEGORY) next.category = normalizeCategory(field.category);
  const fieldPath = String(field.fieldPath ?? '').trim();
  if (fieldPath) next.fieldPath = fieldPath;
  // 上限类成员：0 也合法（scale=0 表示整数），所以判空不判假值
  (['fieldLength', 'precision', 'scale'] as const).forEach((key) => {
    const num = Number(field[key]);
    if (field[key] !== null && field[key] !== undefined && field[key] !== '' && Number.isFinite(num) && num >= 0) next[key] = num;
  });
  const rule = normalizeValidationRule(field.validationRule);
  if (Object.keys(rule).length) next.validationRule = rule;
  if (field.exampleValue !== null && field.exampleValue !== undefined && field.exampleValue !== '') next.exampleValue = field.exampleValue;
  // 可选项：有就原样带回，没有就不传（让后端保持自己的默认，别硬塞 text / manual）
  (['inputWidget', 'valueSource', 'editable', 'repeatable', 'metadata'] as const).forEach((key) => {
    if (field[key] !== null && field[key] !== undefined) next[key] = field[key];
  });
  return next;
}

/** 生成表内唯一的编码占位（table_1 / field_1…），用户可改；不预填则新建项永远缺编码、保存必失败 */
function uniqueKey(existing: any[], base: string): string {
  const taken = new Set((existing ?? []).map((item) => String(item?.tableKey ?? item?.fieldKey ?? '').trim()));
  let index = 1;
  let key = `${base}_${index}`;
  while (taken.has(key)) {
    index += 1;
    key = `${base}_${index}`;
  }
  return key;
}

/**
 * 模板下拉数据源。
 *
 * 两个坑都必须在这里兜住，否则表现为「下拉里空空」或「选了模板没反应」：
 * 1. 列表口径：模板列表可能直接回数组，也可能回 { items, total }，不能只认 .items；
 * 2. 主键字段：模板实体与模型同构，主键是 modelUid（templateUid 只存在于早期 mock 类型里，
 *    真实接口没有这个字段 —— 用它当 value 会让每一项的 value 都是 undefined，
 *    选中后 applyTemplate 收到空 uid 直接 return，看起来就是「点了一下什么都没发生」）。
 */
const templateOptions = computed(() => {
  const raw: any = templates.value;
  const list: any[] = Array.isArray(raw) ? raw : Array.isArray(raw?.items) ? raw.items : Array.isArray(raw?.rows) ? raw.rows : [];
  return list
    .map((item: any) => ({
      value: item?.modelUid ?? item?.templateUid ?? item?.uid ?? '',
      label: item?.modelName ?? item?.name ?? '未命名模板',
      tableCount: item?.tables?.length ?? item?.tableCount ?? 0
    }))
    .filter((opt) => !!opt.value);
});

/**
 * 套用模板：列表项无表结构，需先请求详情获取完整 tables。
 * CONSTRAINT 只借「名称 + 表结构」：模型编码、产品类别、版本号都是当前模型自己的，不能被模板覆盖。
 */
async function applyTemplate(uid?: string) {
  // 清空选择（clearable / 套用后重置）都会触发 change，空值直接忽略
  if (!uid) return;
  const res = await metadataApi.getMetadataTemplateDetail(uid);
  if (res.code !== 0 || !res.data) {
    ElMessage.error(pt('模板详情加载失败'));
    return;
  }
  const tpl: any = res.data;
  // 模板详情与模型详情同构，同样要抹平 length/fieldLength 这类成员名差异
  const tables = hydrateTables(JSON.parse(JSON.stringify(tpl.tables ?? [])));
  model.value = {
    // 用户可能已填过编码，套模板不能把它清掉
    modelKey: model.value.modelKey ?? '',
    modelName: tpl.modelName ?? model.value.modelName ?? '',
    description: tpl.description ?? '',
    productCategoryKeys: [...categoryKeys.value],
    productCategories: [],
    // 编辑态套模板仍走 PATCH，乐观锁版本号不能丢，否则保存报「版本号缺失」
    versionNo: model.value.versionNo,
    tables
  };
  // 套用后清空选中：同一个模板再选一次也能重新套用（值不变不会触发 change）
  template.value = '';
  if (!tables.length) {
    ElMessage.warning(`模板「${tpl.modelName}」没有模型表，仅同步了名称与描述`);
  } else {
    ElMessage.success(`已套用「${tpl.modelName}」模板（${tables.length} 张模型表），可继续按数据类别调整字段`);
  }
}

/**
 * 模型编码（modelKey）的契约：后端只收「稳定的小写键」，中文名直接当编码会被拒
 * （实测报错 `modelKey 必须是稳定的小写键`）。前端先行拦一道，别等提交才弹错。
 */
const MODEL_KEY_RE = /^[a-z][a-z0-9_-]*$/;

/**
 * 提交前校验。逐条对应接口契约里的必填项，避免「前端放行 → 后端 400 → 用户不知道哪一项」：
 * modelKey 正则+长度、名称类 ≤160、tableKey 必填且模型内唯一、fieldKey 必填且同表唯一、
 * 表下 fields 必填非空（契约明确不接受空表）。
 */
function validateModel(): string | null {
  const modelName = String(model.value.modelName ?? '').trim();
  if (!modelName) return pt('请填写模型名称');
  if (modelName.length > 160) return pt('模型名称不能超过 160 个字符');
  // 编辑态 PATCH 拒收 modelKey（提交即 400），编码只在新建时填
  if (!props.row) {
    const key = String(model.value.modelKey ?? '').trim();
    if (!key) return pt('请填写模型编码（英文小写标识，如 hyjc_hmys）');
    if (key.length > 120) return pt('模型编码不能超过 120 个字符');
    if (!MODEL_KEY_RE.test(key)) return pt('模型编码只能用小写字母、数字、下划线或短横线，且必须以小写字母开头');
  }
  if (!categoryKeys.value.length) return pt('请选择该模型关联的产品类别');
  const tables = model.value.tables ?? [];
  if (!tables.length) return pt('请至少添加一个元数据模型表');

  const tableKeys = new Set<string>();
  for (const [tableIndex, table] of tables.entries()) {
    const tableKey = String(table.tableKey ?? '').trim();
    if (!tableKey) return `第 ${tableIndex + 1} 张模型表缺少表编码`;
    if (/\s/.test(tableKey)) return `表编码「${tableKey}」不能包含空格`;
    if (tableKeys.has(tableKey)) return `表编码「${tableKey}」重复`;
    tableKeys.add(tableKey);

    const tableName = String(table.tableName ?? '').trim();
    if (!tableName) return `模型表「${tableKey}」缺少表名称`;
    if (tableName.length > 160) return `表名称「${tableName}」超过 160 个字符`;

    const fields = table.fields ?? [];
    // 契约：fields 必填且非空 —— 空表会被后端直接拒掉
    if (!fields.length) return `模型表「${tableName}」至少要有一个字段`;

    const fieldKeys = new Set<string>();
    for (const [fieldIndex, field] of fields.entries()) {
      const fieldKey = String(field.fieldKey ?? '').trim();
      if (!fieldKey) return `模型表「${tableName}」第 ${fieldIndex + 1} 个字段缺少字段编码`;
      if (/\s/.test(fieldKey)) return `字段编码「${fieldKey}」不能包含空格`;
      if (fieldKeys.has(fieldKey)) return `模型表「${tableName}」的字段编码「${fieldKey}」重复`;
      fieldKeys.add(fieldKey);

      const label = String(field.displayName ?? '').trim();
      if (!label) return `模型表「${tableName}」第 ${fieldIndex + 1} 个字段缺少字段名称`;
      if (label.length > 160) return `字段名称「${label}」超过 160 个字符`;
      if (!String(field.valueType ?? '').trim()) return `字段「${label}」缺少字段类型`;
    }
  }
  return null;
}

/**
 * 字段类型的中文名：表格里只展示名称，编码放在弹窗里改。
 * 接口给不出该类型时退化成编码本身，不显示空白，避免用户以为没填。
 */
const typeLabelMap = computed(() => new Map((fieldTypeOptions.value ?? []).map((opt) => [opt.value, opt.label])));

function fieldTypeLabel(code: unknown) {
  const key = String(code ?? '');
  return typeLabelMap.value.get(key) ?? (key || '—');
}

/**
 * 表序号：v-for 的 index 由 any 推成 string|number，直接 +1 会报 TS2365，
 * 统一转成数字再算成 1 起。
 */
function tableNo(index: string | number) {
  return Number(index) + 1;
}

/** 空表提示文案：模式切换按钮已移除，录入统一走拖拽 + 字段弹窗，文案固定提字段库 */
const fieldEmptyText = pt('暂无字段，点「新增字段」或从左侧字段库拖入');

/** 新增模型表：tableKey 必填且模型内唯一，先按 table_N 预填一个不重复的占位，用户可改 */
function addTable() {
  model.value.tables.unshift({
    tableKey: uniqueKey(model.value.tables ?? [], 'table'),
    tableName: '',
    tableType: 'table',
    description: '',
    sortOrder: (model.value.tables.length + 1) * 10,
    fields: []
  });
}

/* ------------------------------------------------------------------ */
/* 字段编辑弹窗                                                        */
/* ------------------------------------------------------------------ */

/**
 * 字段不再在表格行内直接编辑：一行只有 100px 宽，长度/精度/枚举/缺省值
 * 全被压成看不见内容的输入框。改为「表格只读 + 弹窗录入」。
 *
 * 弹窗走项目统一的 createDialog：字段没有接口调用，所以子组件用 onSubmit 回调
 * 把值交回来，写回 table.fields 的动作由 openFieldDialog 负责。
 */

/**
 * 构造一个新字段。
 * fieldKey 必填：拖入字段库时沿用库里的编码，手填时预填 field_N 占位（不预填则新增项永远缺编码、保存必失败）。
 * sortOrder 只是占位，保存时按显示顺序重排。
 */
function buildField(table: Params, preset?: Params): Params {
  return {
    fieldKey: String(preset?.fieldKey ?? preset?.fieldPath ?? '').trim() || uniqueKey(table.fields ?? [], 'field'),
    fieldPath: preset?.fieldPath ?? preset?.fieldKey ?? '',
    displayName: preset?.displayName ?? preset?.name ?? '',
    // 拖入时沿用字段库的分类；新建按契约枚举给默认值「结构」
    category: normalizeCategory(preset?.category),
    valueType: preset?.valueType ?? preset?.type ?? 'string',
    // 控件与来源不凭空造：字段库带了就带上，没有就让后端用自己的默认
    inputWidget: preset?.inputWidget,
    valueSource: preset?.valueSource,
    editable: preset?.editable ?? true,
    nullable: preset?.nullable ?? false,
    required: !(preset?.nullable ?? false),
    repeatable: preset?.repeatable ?? false,
    fieldLength: preset?.fieldLength ?? preset?.length,
    precision: preset?.precision,
    scale: preset?.scale,
    options: preset?.options ?? [],
    validationRule: normalizeValidationRule(preset?.validationRule),
    exampleValue: preset?.exampleValue ?? '',
    defaultValue: preset?.defaultValue ?? '',
    description: preset?.description ?? '',
    helpText: preset?.helpText ?? '',
    metadata: preset?.metadata ?? {},
    sortOrder: ((table.fields?.length ?? 0) + 1) * 10
  };
}

/**
 * 打开字段弹窗（走项目统一的 createDialog）。
 *
 * 提交链接回 createDialog 自己那套：它先调 content.save()，按返回的 code 决定
 * 关闭 / 用 message 弹错误。所以这里只负责「把写回逻辑作为回调传进去」：
 *   · 新增 → unshift 到最前（与「最新加的排在上面」一致）
 *   · 编辑 → 原位替换，不打乱用户看到的顺序
 * 写回上下文（哪张表、第几个）留在这里，表单组件本身不认识模型表结构。
 *
 * @param table 字段所属的模型表
 * @param index 字段下标；-1 表示新增（字段库拖入已改为直接落表，不走本弹窗）
 */
function openFieldDialog(table: Params, index = -1) {
  const isEdit = index >= 0;
  // 深拷贝：弹窗里的修改不能直接落到列表上，取消要能原样还原
  const draft: Params = isEdit ? JSON.parse(JSON.stringify(table.fields[index] ?? {})) : buildField(table);
  // 同表内除自己以外的字段，供 fieldKey 唯一校验
  const siblings = (table.fields ?? []).filter((_: Params, i: number) => i !== index);

  createDialog({
    title: isEdit ? pt('编辑字段') : pt('新增字段'),
    width: '880px',
    okText: pt('确定'),
    render: () => (
      <FieldEdit
        field={draft}
        fieldTypes={fieldTypeOptions.value}
        siblings={siblings}
        onSubmit={(field: Params) => {
          if (isEdit) {
            table.fields.splice(index, 1, field);
          } else {
            table.fields.unshift(field);
          }
        }}
      />
    )
  });
}

/**
 * 表级信息编辑弹窗（H-08）：表编码 / 表名称 / 表描述由内嵌填写行改为弹窗录入。
 * H-05 已移除「表类型」下拉，弹窗不再提供该项；tableType 契约默认值仍在提交时保留。
 * 写回按字段赋值而非整对象替换，避免断开 model.tables 数组与 v-for 的对象引用。
 */
function openTableDialog(table: Params) {
  createDialog({
    title: pt('编辑表信息'),
    width: '640px',
    okText: pt('确定'),
    render: () => (
      <TableEdit
        table={table}
        onSubmit={(next: Params) => {
          table.tableKey = next.tableKey;
          table.tableName = next.tableName;
          table.description = next.description;
        }}
      />
    )
  });
}

/** 删除字段：字段是表格里唯一会造成「数据丢失」的操作，先确认再删 */
async function removeField(table: Params, index: number) {
  const field = table.fields[index] ?? {};
  try {
    await ElMessageBox.confirm(`确定删除字段「${field.displayName || field.fieldKey || '未命名'}」吗？`, pt('删除字段'), {
      type: 'warning',
      confirmButtonText: pt('删除'),
      cancelButtonText: pt('取消')
    });
  } catch {
    return;
  }
  table.fields.splice(index, 1);
}

function handleDragStart(field: Params, event: DragEvent) {
  draggedField.value = field;
  event.dataTransfer?.setData('text/plain', field.displayName ?? field.fieldKey ?? '');
  if (event.dataTransfer) {
    event.dataTransfer.effectAllowed = 'copy';
  }
}

/**
 * 落点高亮：记的是「哪张表的字段区」而不是一个布尔量 —— 折叠面板的内容用 v-show 保留在 DOM 里，
 * 布尔量会让所有表的面板同时点亮，按表对象比对才只亮鼠标悬停的那一张。
 */
const dropTarget = ref<Params | null>(null);

function handleDragEnter(item: Params) {
  dropTarget.value = item;
}

/** 字段行等子元素会冒泡 dragleave，用 contains(relatedTarget) 滤掉面板内部的移动，避免高亮闪烁 */
function handleDragLeave(item: Params, event: DragEvent) {
  const panel = event.currentTarget as HTMLElement | null;
  if (panel && event.relatedTarget instanceof Node && panel.contains(event.relatedTarget)) return;
  if (dropTarget.value === item) dropTarget.value = null;
}

/** 拖拽被取消（松手在面板外 / 按 Esc）时面板收不到 dragleave，这里兜底清掉状态 */
function handleDragEnd() {
  draggedField.value = undefined;
  dropTarget.value = null;
}

/**
 * 拖入字段库的字段：直接落到表里，不再开弹窗确认。
 * 字段库条目自带完整契约（编码 / 类型 / 长度 / 分类），拖入即定形，
 * 需要微调时点行内编辑按钮走字段弹窗，比每拖一个都确认一次要快。
 * 插到第一行（与「＋新增字段」同口径）：字段表带 max-height 内部滚动，
 * 追加到末尾等于落进可视区之外，用户看不到新字段、容易重复拖同一个。
 * 同表已有同编码则拦下并提示，避免静默塞进重复字段。
 */
function handleDrop(item: Params, event?: DragEvent) {
  const src = draggedField.value;
  draggedField.value = undefined;
  dropTarget.value = null;
  if (!src) return;
  const field = buildField(item, src);
  const key = String(field.fieldKey ?? '').trim();
  if ((item.fields ?? []).some((f: Params) => String(f.fieldKey ?? '').trim() === key)) {
    ElMessage.warning(`字段「${field.displayName || key}」已在本表，未重复添加`);
    return;
  }
  if (!item.fields) item.fields = [];
  item.fields.unshift(field);
  scrollToFieldTop(event);
  ElMessage.success(`已加入字段「${field.displayName || key}」，点行内编辑可调整`);
}

/**
 * 新字段插到第一行后把该表的字段区滚回顶部：用户可能已经滚到列表中段才拖，
 * 不滚回来第一行仍然在可视区上方，看不到添加结果。
 * 只处理事件来源面板，避免把其它表的面板一起滚动。
 */
function scrollToFieldTop(event?: DragEvent) {
  const panel = event?.currentTarget as HTMLElement | null;
  if (!panel) return;
  // EP 各版本 el-table 的内部滚动节点类名不同（2.2+ 是 .el-scrollbar__wrap，旧版是 .el-table__body-wrapper），
  // 逐个探测取第一个真有滚动能力的；都找不到就退回面板自身（无害，最多不滚）
  const candidates = ['.el-scrollbar__wrap', '.el-table__body-wrapper', '.el-table__body-wrapper > .el-scrollbar__wrap'];
  const wrap =
    candidates.map((s) => panel.querySelector<HTMLElement>(s)).find((el) => el && el.scrollHeight > el.clientHeight) ??
    candidates.map((s) => panel.querySelector<HTMLElement>(s)).find(Boolean) ??
    panel;
  // 数据变更后的重排发生在 nextTick，浏览器又可能按滚动锚定把位置保持在原处，
  // 所以两帧各归零一次，确保第一行确实进入可视区
  nextTick(() => {
    wrap.scrollTop = 0;
    requestAnimationFrame(() => {
      wrap.scrollTop = 0;
    });
  });
}

/**
 * 供 createDialog 提交：直接返回接口响应（code === 0 视为成功，失败提示由 createDialog 统一处理）。
 * 请求体严格按契约白名单构造 —— POST/PATCH 都只接受 5 个成员，多传直接 400。
 */
async function save() {
  const error = validateModel();
  if (error) {
    ElMessage.error(error);
    return;
  }
  const data: any = {
    modelName: String(model.value.modelName ?? '').trim(),
    description: model.value.description ?? '',
    // 整组替换语义：必须把已有的多类别整组带上，不能只传第一个
    productCategoryKeys: [...categoryKeys.value],
    tables: normalizeTables(model.value.tables ?? [])
  };
  if (props.row) {
    // PATCH 不接受 modelKey（提交即 400），也不接受只带 expectedVersionNo 的请求
    // 乐观并发：expectedVersionNo 必填且必须等于当前版本号，取详情接口返回的 versionNo
    const versionNo = Number(model.value.versionNo ?? props.row.versionNo);
    if (!versionNo || versionNo < 1) {
      ElMessage.error(pt('模型版本号缺失，请返回列表重新打开'));
      return;
    }
    data.expectedVersionNo = versionNo;
    // 模板（canEdit=false）在列表页就被拦住，走不到这里；统一走模型 PATCH
    return await metadataApi.updateMetadataModel(props.row.modelUid, data);
  }
  // 创建分支才补 modelKey：中文名不是合法编码，后端会报「modelKey 必须是稳定的小写键」
  data.modelKey = String(model.value.modelKey ?? '').trim();
  return await metadataApi.createMetadataModel(data);
}

defineExpose({ save });
</script>

<template>
  <div v-loading="modelLoading" element-loading-text="加载模型数据中…" class="metadata-edit">
    <el-card class="section-card" shadow="never">
      <template #header>
        <div class="card-head">
          <div class="card-head-left">
            <span class="card-title">{{ pt('基本信息') }}</span>
            <span class="card-sub">{{ pt('套用模板可一次生成常用表结构') }}</span>
          </div>
          <div v-if="!props.row" class="card-head-right">
            <span class="tmpl-label">{{ pt('套用模板') }}</span>
            <el-select v-model="template" style="width: 260px" filterable clearable :placeholder="pt('不套用模板')" @change="applyTemplate">
              <el-option v-for="opt in templateOptions" :key="opt.value" :label="opt.label" :value="opt.value">
                <span class="tmpl-opt-name">{{ opt.label }}</span>
                <span class="tmpl-opt-count">{{ opt.tableCount }} 张表</span>
              </el-option>
              <template #empty>
                <div class="tmpl-empty">{{ pt('暂无可用模板，可在模型列表选中模型后点「生成范例」') }}</div>
              </template>
            </el-select>
          </div>
        </div>
      </template>
      <Form ref="form" v-model="model" :span="24">
        <el-input v-model="model.modelName" label="模型名称" :span="8" />
        <!-- 模型编码：POST 必填（不填后端会拿中文名兜底并报「必须是稳定的小写键」）；
             PATCH 不收该字段，所以编辑态只读展示，让用户查得到但不能改 -->
        <el-input
          v-model="model.modelKey"
          label="模型编码"
          :span="8"
          :disabled="!!props.row"
          placeholder="如 hyjc_hmys"
          tooltip="小写字母开头，只能含小写字母、数字、下划线或短横线；创建后不可修改"
        />
        <!-- 产品类别：契约是编码数组，可多选；PATCH 传了就整组替换，所以必须整组提交 -->
        <el-tree-select
          v-model="categoryKeys"
          :span="8"
          :props="{ label: 'categoryName', children: 'children' }"
          :data="categoryTree"
          node-key="categoryKey"
          multiple
          show-checkbox
          collapse-tags
          collapse-tags-tooltip
          :max-collapse-tags="1"
          clearable
          check-strictly
          default-expand-all
          label="产品类别"
        />
        <el-input v-model="model.description" :span="24" type="textarea" :rows="2" label="描述" />
      </Form>
    </el-card>

    <el-card class="model-table-card section-card" shadow="never">
      <template #header>
        <div class="card-head">
          <div class="card-head-left">
            <span class="card-title">模型表</span>
            <el-tag type="info" round>{{ model?.tables?.length ?? 0 }} 张</el-tag>
          </div>
          <div class="card-head-right">
            <el-tooltip content="新增模型表" placement="top">
              <el-button type="primary" :icon="Plus" @click="addTable"></el-button>
            </el-tooltip>
          </div>
        </div>
      </template>
      <el-empty v-if="!model?.tables?.length" description="暂无模型表，点右上角「新增模型表」开始" :image-size="72" />
      <div v-else class="table-workspace">
        <!-- 字段库：模式切换按钮移除后常驻（即默认拖拽录入），宽度固定，标签内左名右类型 -->
        <aside class="field-library">
          <div v-for="(group, gi) in fieldLibrary" :key="gi" class="library-group">
            <div class="group-title">
              <span>{{ group.categoryName }}</span>
              <span class="group-count">{{ group.fields?.length ?? 0 }}</span>
            </div>
            <el-tag
              v-for="(field, fieldIndex) in group.fields"
              :key="fieldIndex"
              class="field-tag"
              draggable="true"
              @dragstart="handleDragStart(field, $event)"
              @dragend="handleDragEnd"
            >
              <span class="tag-name">{{ field.displayName }}</span>
              <span class="tag-type">{{ field.typeLabel }}</span>
            </el-tag>
          </div>
          <el-empty v-if="!fieldLibrary?.length" description="字段库为空" :image-size="48" />
        </aside>
        <el-collapse v-model="activeName" class="table-collapse" :accordion="true" expand-icon-position="left">
          <el-collapse-item v-for="(item, index) in model?.tables" :key="index" :name="index">
            <template #title>
              <div class="table-title">
                <div class="table-title-left">
                  <el-tag type="primary" effect="plain" round size="small">表 {{ tableNo(index) }}</el-tag>
                  <!-- 表级信息全并到标题一行：表名为主，编码/描述弱化成次要信息，过长省略号截断 -->
                  <span class="table-title__name">{{ item.tableName || '未命名模型表' }}</span>
                  <span v-if="item.tableKey" class="table-title__key">{{ item.tableKey }}</span>
                  <span v-if="item.description" class="table-title__desc" :title="item.description">{{ item.description }}</span>
                </div>
                <div class="table-title-right" @click.stop>
                  <el-tag type="info" effect="plain" round size="small">{{ item.fields?.length ?? 0 }} 个字段</el-tag>
                  <!-- 三个操作统一 size=small + 纯图标 + tooltip，避免一个带文字的按钮把整行撑高 -->
                  <el-tooltip content="编辑表信息（表编码 / 表名称 / 表描述）" placement="top">
                    <el-button size="small" type="primary" plain :icon="Edit" @click="openTableDialog(item)" />
                  </el-tooltip>
                  <el-tooltip content="新增字段" placement="top">
                    <el-button size="small" type="primary" plain :icon="Plus" @click="openFieldDialog(item)" />
                  </el-tooltip>
                  <el-tooltip content="删除该表" placement="top">
                    <el-button size="small" type="danger" plain :icon="Delete" @click="model.tables.splice(index, 1)" />
                  </el-tooltip>
                </div>
              </div>
            </template>
            <!-- 字段区：只读表格 + 操作列，录入统一走字段弹窗；拖拽模式下整块都是落点 -->
            <div
              class="field-panel"
              :class="{ 'is-drop-active': dropTarget === item }"
              @dragover.prevent
              @dragenter="handleDragEnter(item)"
              @dragleave="handleDragLeave(item, $event)"
              @drop.prevent="handleDrop(item, $event)"
            >
              <div v-if="!item.fields?.length" class="field-empty">
                <el-empty :description="fieldEmptyText" :image-size="56" />
              </div>
              <el-table v-else class="field-table" :data="item.fields" border size="small" max-height="260">
                <el-table-column type="index" label="#" width="52" align="center" />
                <el-table-column prop="displayName" label="字段名称" min-width="120" show-overflow-tooltip />
                <el-table-column prop="fieldKey" label="字段编码" min-width="120" show-overflow-tooltip />
                <el-table-column label="类型" width="88">
                  <template #default="{ row }">{{ fieldTypeLabel(row.valueType) }}</template>
                </el-table-column>
                <el-table-column label="长度" width="64" align="right">
                  <template #default="{ row }">{{ row.fieldLength ?? '—' }}</template>
                </el-table-column>
                <el-table-column label="必填" width="68" align="center">
                  <template #default="{ row }">
                    <el-tag :type="row.nullable ? 'info' : 'warning'" size="small" effect="plain">
                      {{ row.nullable ? '可空' : '必填' }}
                    </el-tag>
                  </template>
                </el-table-column>
                <el-table-column label="枚举值" min-width="90" show-overflow-tooltip>
                  <template #default="{ row }">{{ (row.options ?? []).join(' / ') || '—' }}</template>
                </el-table-column>
                <el-table-column label="缺省值" width="84" show-overflow-tooltip>
                  <template #default="{ row }">{{ row.defaultValue || '—' }}</template>
                </el-table-column>
                <el-table-column label="操作" width="96" align="center" fixed="right">
                  <template #default="{ $index }">
                    <el-button link type="primary" :icon="Edit" @click="openFieldDialog(item, $index)"></el-button>
                    <el-button link type="danger" :icon="Delete" @click="removeField(item, $index)" />
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </el-collapse-item>
        </el-collapse>
      </div>
    </el-card>
  </div>
</template>

<style lang="scss" scoped>
/* 弹窗 body 自带 max-height:70vh + padding:16，这里再收一层：
   约定内部高度上限，表格用 flex 吃掉剩余空间，而不是靠固定 px 把 body 撑出滚动条 */
.metadata-edit {
  display: flex;
  flex-direction: column;
  gap: 12px;
  height: 100%;
  max-height: calc(70vh - 32px);
  min-height: 0;
  /* 溢出滚动交给弹窗体：卡片内部若再挂滚动条（EP 原生 .el-card__body overflow:auto），
     用户会在「基本信息」卡右侧看到一个只剩几像素的细滚动条——卡片被 flex 压缩导致 */
  overflow-y: auto;
  overflow-x: hidden;
}

/* ---- 卡片统一外壳 ---- */
.section-card {
  /* 基本信息卡不参与 flex 压缩：否则 el-card__body 的 overflow:auto 会在卡右侧出滚动条 */
  flex: 0 0 auto;
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 8px;

  :deep(.el-card__header) {
    display: flex;
    align-items: center;
    padding: 0 14px !important;
    border-bottom: 1px solid var(--el-border-color-lighter);
  }

  :deep(.el-card__body) {
    padding: 14px;
  }
}

/* 卡头高度固定为 48px：原 min-height 44px 在右侧含按钮组（28~32px + 内边距）时会被撑高，
   导致「基本信息」与「模型表」两张卡的卡头视觉不等高。固定 height + overflow: hidden 保证一致 */
.card-head {
  /* 卡头本身是 flex 容器（.section-card :deep(.el-card__header)），这里必须显式撑满宽度，
     否则 .card-head 按内容收缩，space-between 失效，右侧按钮会贴着标题而不是靠右 */
  display: flex;
  flex: 1 1 auto;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  width: 100%;
  height: 48px;
  min-height: 48px;
  overflow: hidden;
}

.card-head-left,
.card-head-right {
  display: flex;
  align-items: center;
  gap: 8px;
}

.card-title {
  font-size: 14px;
  font-weight: 600;
  color: var(--el-text-color-primary);
}

/* 标题后的说明文字：解释这一块在编辑什么，避免用户面对裸标题猜 */
.card-sub {
  font-size: 12px;
  color: var(--el-text-color-placeholder);
}

/* 「套用模板」前的文字标签：让下拉读起来是动作而不是输入框 */
.tmpl-label {
  font-size: 12px;
  color: var(--el-text-color-secondary);
}

/* 下拉项：模板名左对齐、表数量右对齐弱化，避免只看到一串名字不知道会带几张表 */
.tmpl-opt-name {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.tmpl-opt-count {
  float: right;
  margin-left: 12px;
  font-size: 12px;
  line-height: 34px;
  color: var(--el-text-color-placeholder);
}

/* 没有模板时的空态提示：直接说清去哪里生成，不然用户只会以为功能坏了 */
.tmpl-empty {
  padding: 12px 16px;
  font-size: 12px;
  line-height: 1.6;
  color: var(--el-text-color-placeholder);
}

.model-table-card {
  display: flex;
  flex: 1 1 auto;
  flex-direction: column;
  min-height: 0;

  :deep(.el-card__body) {
    display: flex;
    flex: 1 1 auto;
    flex-direction: column;
    min-height: 0;
  }
}

/* 折叠面板内的工作区：左字段库 + 右表结构 */
.table-workspace {
  display: flex;
  flex: 1 1 auto;
  gap: 12px;
  min-height: 0;
}

/* ---- 字段区 ---- */
.field-panel {
  padding: 10px 12px 12px;
  min-height: 96px;
  border: 1px dashed transparent;
  border-radius: 6px;
  transition:
    background-color 0.15s,
    border-color 0.15s;

  /* 拖入即落表（无确认弹窗），所以落点必须明确：悬停时整块高亮 + 虚线描边，
     让用户看清字段会加进哪张表再松手 */
  &.is-drop-active {
    background: var(--el-color-primary-light-9);
    border-color: var(--el-color-primary);
  }
}

.field-empty {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 12px 0;
  border: 1px dashed var(--el-border-color);
  border-radius: 6px;
}

.field-table {
  font-size: 12px;

  :deep(.el-table__header-wrapper th.el-table__cell) {
    font-size: 12px;
    font-weight: 600;
    color: var(--el-text-color-regular);
    background: var(--el-fill-color-light);
  }

  :deep(.el-table__cell) {
    padding: 5px 0;
  }

  /* 操作列的链接按钮压紧，两个按钮并排不换行 */
  :deep(.el-button.is-link) {
    padding: 0 2px;
    font-size: 12px;
  }
}
/* ---- 折叠面板：每张模型表独立成卡 ---- */
.table-collapse {
  flex: 1 1 auto;
  min-width: 0;
  min-height: 0;
  overflow-y: auto;
  border: none;

  :deep(.el-collapse-item) {
    margin-bottom: 10px;
    overflow: hidden;
    background: var(--el-bg-color);
    border: 1px solid var(--el-border-color-lighter);
    border-radius: 6px;

    &:last-child {
      margin-bottom: 0;
    }
  }

  /* 右侧只剩 small 图标按钮后把行高压到 36px，整列更紧凑 */
  :deep(.el-collapse-item__header) {
    height: auto;
    min-height: 36px;
    gap: 6px;
    padding: 4px 10px;
    background: var(--el-fill-color-lighter);
    border-bottom: none;
  }

  :deep(.el-collapse-item__wrap) {
    background: var(--el-bg-color);
    border-bottom: none;
  }

  :deep(.el-collapse-item__content) {
    padding: 0;
  }
}

.table-title {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  width: 100%;
}

.table-title-left {
  display: flex;
  flex: 1 1 auto;
  align-items: center;
  gap: 6px;
  min-width: 0;
}

/* 表名是标题的主角，编码弱化成次要信息 */
.table-title__name {
  overflow: hidden;
  font-size: 13px;
  font-weight: 600;
  color: var(--el-text-color-primary);
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* 表描述：一行里的最次要信息，吃掉剩余宽度并在不足时省略号截断 */
.table-title__desc {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  color: var(--el-text-color-placeholder);
  text-overflow: ellipsis;
  white-space: nowrap;
}

.table-title__key {
  flex-shrink: 0;
  padding: 0 6px;
  font-size: 11px;
  line-height: 18px;
  color: var(--el-text-color-secondary);
  background: var(--el-bg-color);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 3px;
}

.table-title-right {
  display: flex;
  flex-shrink: 0;
  align-items: center;
  gap: 4px;

  /* 纯图标按钮去掉 EP 默认的左右内边距，宽度收到接近正方形 */
  :deep(.el-button) {
    padding: 5px 6px;
  }
}

/* ---- 字段库 ---- */
.field-library {
  display: flex;
  flex: 0 0 168px;
  flex-direction: column;
  gap: 8px;
  width: 168px;
  padding: 10px;
  overflow-y: auto;
  background: var(--el-fill-color-lighter);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 6px;
}

.library-title {
  font-size: 13px;
  font-weight: 600;
  color: var(--el-text-color-primary);
}

/* 拖拽用法提示：字段库只靠拖，不给提示容易被当成纯展示 */
.library-hint {
  margin-top: -4px;
  font-size: 11px;
  line-height: 1.4;
  color: var(--el-text-color-placeholder);
}

.library-group {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.group-title {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 12px;
  font-weight: 500;
  color: var(--el-text-color-secondary);
}

.group-count {
  font-size: 11px;
  color: var(--el-text-color-placeholder);
  font-variant-numeric: tabular-nums;
}

.field-tag {
  width: 100%;
  height: 26px;
  padding: 0 8px;
  cursor: grab;
  background: var(--el-bg-color);
  border-color: var(--el-border-color-lighter);
  transition:
    color 0.15s,
    border-color 0.15s,
    transform 0.15s;

  :deep(.el-tag__content) {
    display: flex;
    justify-content: space-between;
    width: 100%;
    min-width: 0;
    gap: 6px;
  }

  &:hover {
    color: var(--el-color-primary);
    border-color: var(--el-color-primary-light-5);
    transform: translateY(-1px);
  }

  &:active {
    cursor: grabbing;
  }
}

.tag-name {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* 类型标注弱化，不跟字段名抢注意力 */
.tag-type {
  flex-shrink: 0;
  font-size: 11px;
  color: var(--el-text-color-placeholder);
}
</style>
