<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
/**
 * 字段编辑弹窗的内容体：只负责「一个字段」的录入与自校验。
 *
 * 草稿模式：不直接改父组件传进来的 field —— 组件内深拷贝一份自己持有，
 * 「取消」整份丢弃；「确定」由本组件的 save() 通过 onSubmit 交回父组件，
 * 由调用方决定写回哪张表的第几个位置（这些上下文不该漏进表单组件里）。
 *
 * 放在弹窗里而不是表格行内的原因：字段有 12 个属性，行内那一格只有 100px 宽，
 * 长度/精度/枚举/缺省值全被压成看不见内容的输入框，改了也不知道改的是哪个。
 */
const props = defineProps<{
  /** 字段初始值（父组件持有，本组件只读） */
  field: Params;
  /** 字段类型下拉，来自契约 GET /metadata/field-types */
  fieldTypes: { label: string; value: string }[];
  /** 同表内的其他字段（不含自己），用于 fieldKey 唯一校验 */
  siblings: Params[];
  /** 校验通过后把字段交回调用方（新增 / 原位替换由调用方决定） */
  onSubmit?: (field: Params) => void;
}>();

/** 深拷贝：options / metadata 这类数组对象也必须断开引用，否则改草稿会连带改到原字段 */
const draft = reactive<Params>(JSON.parse(JSON.stringify(props.field ?? {})));
if (!Array.isArray(draft.options)) draft.options = [];

/** 数值类型才认精度/小数位，其它类型这两项置灰，避免填了被后端静默忽略 */
const NUMERIC_TYPES = new Set(['integer', 'number', 'decimal', 'double', 'float', 'numeric', 'int', 'long', 'bigint']);
const isNumeric = computed(() => NUMERIC_TYPES.has(String(draft.valueType ?? '').toLowerCase()));

/**
 * 提交前校验。与模型弹窗里的 validateModel 保持同一套口径（必填 + 无空格 + 同表唯一 + 长度上限），
 * 只是把「哪一项不对」说得更具体。
 * @returns 错误文案；null 表示通过
 */
function validate(): string | null {
  const label = String(draft.displayName ?? '').trim();
  if (!label) return pt('请填写字段名称');
  if (label.length > 160) return pt('字段名称不能超过 160 个字符');

  const key = String(draft.fieldKey ?? '').trim();
  if (!key) return pt('请填写字段编码');
  if (/\s/.test(key)) return pt('字段编码不能包含空格');
  const duplicated = (props.siblings ?? []).some((item) => String(item?.fieldKey ?? '').trim() === key);
  if (duplicated) return `当前表里已经有字段编码「${key}」，请换一个`;

  if (!String(draft.valueType ?? '').trim()) return pt('请选择字段类型');

  // 长度/精度/小数位：留空表示不限制，填了就必须是合法非负整数（0 对小数位合法）
  if (draft.fieldLength !== null && draft.fieldLength !== undefined && draft.fieldLength !== '') {
    const length = Number(draft.fieldLength);
    if (!Number.isInteger(length) || length < 1) return pt('字段长度必须是大于 0 的整数');
  }
  for (const [field, name] of [
    ['precision', '精度'],
    ['scale', '小数位']
  ] as const) {
    const raw = draft[field];
    if (raw === null || raw === undefined || raw === '') continue;
    const num = Number(raw);
    if (!Number.isInteger(num) || num < 0) return `${name}必须是不小于 0 的整数`;
  }
  return null;
}

/**
 * 供 createDialog 调用（它先调 validate 再调 save，最后按返回值决定是否关闭）。
 * 校验没过时返回 code !== 0：createDialog 会用 message 弹一条 error 并保持弹窗不关，
 * 所以这里不必自己 ElMessage，错误提示只有一个出口。
 */
async function save() {
  const error = validate();
  if (error) return { code: -1, message: error };

  // 非数值类型不展示精度/小数位，但改类型前填过的值还留在草稿里；不清掉会随提交带上，
  // 表现为「界面上没填的项后端却有值」。这里按当前类型收敛。
  if (!isNumeric.value) {
    draft.precision = undefined;
    draft.scale = undefined;
  }

  // required 与 nullable 必须联动，否则会存出「既不必填也不可空」的矛盾组合
  draft.required = !draft.nullable;
  props.onSubmit?.(draft);

  // 字段只是暂存进模型表单，真正入库发生在外层「提交」，提示里要说清这一点
  return { code: 0, message: pt('字段已保存，提交模型后生效'), data: draft };
}

defineExpose({ save });
</script>

<template>
  <!-- 每行两个（span=12）；枚举值与两段说明文本是长内容，保持整行（span=24） -->
  <Form :span="12" :model="draft">
    <el-input v-model="draft.displayName" :label="pt('字段名称')" :span="12" required :placeholder="pt('如 行政区名称')" />
    <el-input
      v-model="draft.fieldKey"
      :label="pt('字段编码')"
      :span="12"
      required
      :placeholder="pt('如 district_name')"
      :tooltip="pt('同表内唯一，建议用小写英文 + 下划线，保存后作为列的稳定标识')"
    />
    <el-select v-model="draft.valueType" :label="pt('字段类型')" :span="12" required filterable>
      <el-option v-for="opt in fieldTypes" :key="opt.value" :label="opt.label" :value="opt.value" />
    </el-select>
    <el-input-number
      v-model="draft.fieldLength"
      :label="pt('字段长度')"
      :span="12"
      :min="1"
      :step="50"
      :controls="false"
      :placeholder="pt('如 255')"
      :tooltip="pt('留空表示不限制；文本类字段一般填 255 或 1000')"
    />
    <el-switch
      v-model="draft.nullable"
      :label="pt('允许为空')"
      :span="12"
      inline-prompt
      active-text="可空"
      inactive-text="必填"
      :tooltip="pt('关掉即为必填（提交时 required = 非 nullable）')"
    />
    <!-- 精度 / 小数位只对数值类型生效：非数值时整项隐藏而不是置灰 —— 置灰的输入框既占行又读作「必填但被锁住」 -->
    <el-input-number
      v-if="isNumeric"
      v-model="draft.precision"
      :label="pt('精度')"
      :span="12"
      :min="0"
      :controls="false"
      :tooltip="pt('有效数字总位数')"
    />
    <el-input-number
      v-if="isNumeric"
      v-model="draft.scale"
      :label="pt('小数位')"
      :span="12"
      :min="0"
      :controls="false"
      :tooltip="pt('小数位数，0 表示整数')"
    />
    <el-input-tag
      v-model="draft.options"
      :label="pt('枚举值')"
      :span="12"
      :placeholder="pt('回车添加一个可选值')"
      :tooltip="pt('仅枚举类字段需要；留空表示不限制取值')"
    />
    <el-input v-model="draft.defaultValue" :label="pt('缺省值')" :span="12" :placeholder="pt('不填则存 NULL')" />
    <el-input
      v-model="draft.description"
      :label="pt('字段描述')"
      :span="24"
      type="textarea"
      :rows="2"
      :placeholder="pt('这个字段在业务上是什么意思')"
    />
    <el-input
      v-model="draft.helpText"
      :label="pt('备注')"
      :span="24"
      type="textarea"
      :rows="2"
      :placeholder="pt('填报口径 / 取值范围 / 与其它字段的关系')"
    />
  </Form>
</template>

<style lang="scss" scoped>
/* 表单项之间已有 16px 间距，这里只压一下行高，让字段属性在两屏内看完 */
:deep(.el-form-item) {
  margin-bottom: 14px;
}
</style>
