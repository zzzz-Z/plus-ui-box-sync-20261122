<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
import * as api from '@/api/product-manage/platform/metadata';
import type { ModelTableDefinition } from '@/api/product-manage/platform/metadata';
import { getProductCategoryTree } from '@/api/product-manage/platform/category';
import { getResourceTree } from '@/api/product-manage/platform/resources';
import {
  ArrowDown,
  ArrowRight,
  Coin,
  Collection,
  Connection,
  Delete,
  Document,
  DocumentCopy,
  Edit,
  Files,
  FolderOpened,
  Grid,
  Picture,
  Plus,
  Search,
  Tickets
} from '@element-plus/icons-vue';
import { dayjs, ElMessage, ElMessageBox } from 'element-plus';
import { createDialog } from '@/composables/create-dialog';
import EditForm from './edit.vue';

/**
 * 元数据模型管理 —— 展示层
 *
 * 布局：左侧「产品 + 资源」拼接树 → 右侧只读详情（字段 / Meta Data）。
 * 新增与编辑**仍走原来的大弹窗**（createBlock + edit.vue），本页不承担编辑职责，
 * 因此右侧所有内容都是展示态，唯一入口是头部的「编辑」按钮。
 *
 * 树的两段：
 *   · 产品维度：GET /platform/product-categories（类别树，含 modelCount）
 *   · 资源维度：GET /platform/resources/tree（资源目录树）
 * 模型挂到节点下按 categoryKey 匹配（模型只有 productCategoryKeys 这一个关联维度）：
 *   - 产品段的 key 天然是 categoryKey ⇒ 一定能挂上；
 *   - 资源段能否挂上取决于 resources/tree 节点是否也带 categoryKey。
 *     挂不上时该段退化为纯导航（点节点右侧给出空态说明），不伪造关联。
 *
 * CONSTRAINT 列表接口（getMetadataModelList）只回 tableCount / fieldCount，不含表结构；
 * 字段明细要选中模型后再拉 getMetadataModelDetail。详情失败不阻塞页面，头部信息仍可用列表行兜底。
 */

/* ------------------------------------------------------------------ */
/* 类型                                                                */
/* ------------------------------------------------------------------ */

interface TreeNodeVM {
  /** 树内唯一 key：group:xx / cat:xx / res:xx / model:xx */
  key: string;
  label: string;
  kind: 'group' | 'cat' | 'res' | 'model';
  /** 右侧计数（模型数）；0 不显示 */
  count?: number;
  /** 搜索匹配用的附加关键字（modelKey 等） */
  keyword?: string;
  modelUid?: string;
  children?: TreeNodeVM[];
}

/**
 * 树节点图标：产品类型（类别）用文件夹、数据资源用数据/资源类图标、模型用文档，
 * 再配合 is-cat / is-res 的颜色差，两类维度在树里一眼能分开（不必读文字）。
 */
const NODE_ICONS = {
  group: Grid,
  cat: FolderOpened,
  res: Coin,
  /* 元数据模型 = 一组被组织在一起的结构定义，Collection 语义最贴，且与 Grid/Folder/Coin 不撞 */
  model: Collection
} as const;

function nodeIcon(kind: TreeNodeVM['kind']) {
  return NODE_ICONS[kind] ?? Document;
}

/* ------------------------------------------------------------------ */
/* 状态                                                                */
/* ------------------------------------------------------------------ */

const loading = ref(false);
const models = ref<any[]>([]);
/** 列表接口声明的 total（0 = 接口没给或给的不合法），用于解释「页面数不到全部」 */
const listTotal = ref(0);
const categoryTree = ref<any[]>([]);
const resourceTree = ref<any[]>([]);

/**
 * 上下文根：primary-product / result-product 页面 provide 下来的根类别编码（primary / result）。
 * 有值时树只展示该根这一级（初级产品管理入口 → 只有初级产品管理那棵树）。
 */
const categoryRoot = inject<string>('product-category-root', '');

/** 在类别树里按 categoryKey / categoryUid 找节点（命中即返回该节点及其子树） */
function findCategoryNode(list: any[], key: string): any | null {
  if (!key) return null;
  for (const node of list ?? []) {
    if (node.categoryKey === key || node.categoryUid === key) return node;
    const hit = node.children?.length ? findCategoryNode(node.children, key) : null;
    if (hit) return hit;
  }
  return null;
}

/** 编码对不上时的名称兜底（初级产品管理 / 成果产品管理） */
const ROOT_NAME_HINTS: Record<string, string[]> = { primary: ['初级'], result: ['成果'] };

/** 只作后端分组的根编码：不是可选的产品类别，不能当作模型归属带进弹窗 */
const RAW_ROOT_KEYS = new Set(Object.keys(ROOT_NAME_HINTS));

/**
 * 取上下文根节点：先按编码精确匹配，再按根名称兜底。
 * WHY 要兜底：一旦后端把根 categoryKey 从 primary/result 改掉（或换成 uuid），
 * 精确匹配失败会让树静默退回「全量两段」，页面看起来像没改，排查成本很高。
 */
function pickRootNode(): any | null {
  if (!categoryRoot) return null;
  const hit = findCategoryNode(categoryTree.value, categoryRoot);
  if (hit) return hit;
  const hints = ROOT_NAME_HINTS[categoryRoot] ?? [];
  return categoryTree.value.find((n) => hints.some((h) => String(n.categoryName ?? '').includes(h))) ?? null;
}

const currentKey = ref('');
const currentModel = ref<any>(null);
const detail = ref<any>(null);
const detailLoading = ref(false);
const tab = ref<'fields' | 'meta'>('fields');
const keyword = ref('');
const treeRef = ref();
const generatingExample = ref(false);

/* 树宽：初始「按内容 + 按容器」取大者，并夹在 [220, 460]；用户拖过分隔条后不再自动改。
   不设固定宽度 —— 产品类别名普遍 6~10 个汉字，深层节点再叠缩进，定宽会把名字截成省略号。 */
const mmRef = ref();
const treeWidth = ref(280);
const TREE_MIN = 220;
const TREE_MAX = 460;
let userResized = false;

/** 估算单行需要的宽度：中文/全角 13px、其余 7px，加上左侧缩进（el-tree indent=14）、图标、计数徽标与内边距 */
function estimateNodeWidth(label: string, depth: number) {
  let text = 0;
  for (const ch of label) text += /[\u2e80-\u9fff\uff00-\uffef]/.test(ch) ? 13 : 7;
  return text + depth * 14 + 62;
}

function measureTreeWidth(): number {
  let max = 0;
  const walk = (list: TreeNodeVM[], depth: number) =>
    list.forEach((n) => {
      max = Math.max(max, estimateNodeWidth(n.label, depth));
      if (n.children?.length) walk(n.children, depth + 1);
    });
  walk(treeData.value, 0);
  return max;
}

function fitTreeWidth() {
  if (userResized) return;
  const total = mmRef.value?.clientWidth ?? 0;
  const byContent = measureTreeWidth();
  const byRatio = total ? Math.round(total * 0.24) : 0;
  treeWidth.value = Math.min(TREE_MAX, Math.max(TREE_MIN, byContent, byRatio));
}

let resizeStartX = 0;
let resizeStartW = 0;

function startResize(e: PointerEvent) {
  userResized = true;
  resizeStartX = e.clientX;
  resizeStartW = treeWidth.value;
  window.addEventListener('pointermove', onResize);
  window.addEventListener('pointerup', stopResize);
  // pointercancel：拖到窗口外松手 / 被系统手势打断时也要收尾，否则光标和 user-select 会一直挂着
  window.addEventListener('pointercancel', stopResize);
  document.body.style.cursor = 'col-resize';
  document.body.style.userSelect = 'none';
}

function onResize(e: PointerEvent) {
  const next = resizeStartW + (e.clientX - resizeStartX);
  treeWidth.value = Math.min(TREE_MAX, Math.max(TREE_MIN, next));
}

function stopResize() {
  window.removeEventListener('pointermove', onResize);
  window.removeEventListener('pointerup', stopResize);
  window.removeEventListener('pointercancel', stopResize);
  document.body.style.cursor = '';
  document.body.style.userSelect = '';
}

/* 窗口宽度变化时重算（用户手动拖过之后 fitTreeWidth 内部会直接返回，不覆盖用户选择） */
onMounted(() => window.addEventListener('resize', fitTreeWidth));
onBeforeUnmount(() => {
  stopResize();
  window.removeEventListener('resize', fitTreeWidth);
});

/* ------------------------------------------------------------------ */
/* 数据加载                                                            */
/* ------------------------------------------------------------------ */

/** 统一取列表：接口返回体可能是 { items } / { tree } / { nodes } / 数组本身 */
function pickList(res: any): any[] {
  const d = res?.data ?? res;
  if (Array.isArray(d)) return d;
  return d?.items ?? d?.tree ?? d?.nodes ?? [];
}

/** 兜底组树：类别接口若只回平铺 items，按 parentCategoryUid 拼 */
function buildTreeFromItems(items: any[]): any[] {
  const nodes = (items ?? []).map((item) => ({ ...item, children: [] as any[] }));
  const byUid = new Map<string, any>(nodes.map((n) => [n.categoryUid, n]));
  const roots: any[] = [];
  nodes.forEach((n) => {
    const parent = n.parentCategoryUid ? byUid.get(n.parentCategoryUid) : null;
    if (parent) parent.children.push(n);
    else roots.push(n);
  });
  return roots;
}

async function loadData() {
  loading.value = true;
  try {
    const [modelRes, catRes, resRes] = await Promise.all([api.getMetadataModelList(), getProductCategoryTree(), getResourceTree()]);
    // 后端 /models 本身已返回 isTemplate=true 的模板（实测 19 条里含 3 条模板），
    // 若再额外拉 /templates 并 append，同一模板会出现两次 → 列表里重名。
    // 这里只取 /models 一次。
    models.value = pickList(modelRes);
    // 接口声明的总数：与 items 实际长度不一致时说明后端做了分页/权限过滤，页面要如实说出来
    const total = Number((modelRes as any)?.data?.total ?? (modelRes as any)?.total ?? 0);
    listTotal.value = Number.isFinite(total) && total > 0 ? total : 0;
    const catData: any = (catRes as any)?.data ?? {};
    categoryTree.value = catData.tree?.length ? catData.tree : buildTreeFromItems(catData.items ?? []);
    resourceTree.value = pickList(resRes);
  } catch {
    ElMessage.error(pt('元数据模型数据加载失败'));
  } finally {
    loading.value = false;
  }
}

/* ------------------------------------------------------------------ */
/* 模型 → 类别关联                                                     */
/* ------------------------------------------------------------------ */

/** 模型的类别编码：优先用详情里的完整节点，回落 productCategoryKeys */
function catKeysOf(model: any): string[] {
  const fromNodes = (model?.productCategories ?? []).map((c: any) => c?.categoryKey).filter(Boolean);
  return fromNodes.length ? fromNodes : (model?.productCategoryKeys ?? []).filter(Boolean);
}

/** categoryKey → 该类别下的模型列表（一个模型可关联多个类别，故可能出现在多处） */
const modelsByCatKey = computed(() => {
  const map = new Map<string, any[]>();
  models.value.forEach((m) => {
    catKeysOf(m).forEach((k) => {
      const arr = map.get(k) ?? [];
      arr.push(m);
      map.set(k, arr);
    });
  });
  return map;
});

/** 类别/资源节点 key 的全集，用于判定「未分类」——两棵树都算，避免只挂资源目录的模型被误判 */
const allCatKeys = computed(() => {
  const set = new Set<string>();
  const walk = (list: any[], readKey: (n: any) => string) =>
    list.forEach((n) => {
      const key = readKey(n);
      if (key) set.add(key);
      if (n.children?.length) walk(n.children, readKey);
    });
  walk(categoryTree.value, (n) => n.categoryKey || n.categoryUid);
  walk(resourceTree.value, resNodeKey);
  return set;
});

/* ------------------------------------------------------------------ */
/* 树构建                                                              */
/* ------------------------------------------------------------------ */

/**
 * 模型叶子节点。
 * CONSTRAINT 同一模型可关联多个产品类别 ⇒ 会在树里出现多次，
 * key 必须带所在节点作用域，否则 el-tree 的 node-key 重复、setCurrentKey 只能命中第一个。
 */
/* ------------------------------------------------------------------ */
/* 表类型：图标 + 中文 + 主题色（详情页头部 / 表清单共用）              */
/* ------------------------------------------------------------------ */
interface TableTypeMeta {
  label: string;
  icon: any;
  color: string;
}
const TABLE_TYPE_META: Record<string, TableTypeMeta> = {
  table: { label: pt('数据表'), icon: Grid, color: 'var(--el-color-primary)' },
  layer: { label: pt('矢量图层'), icon: Connection, color: '#6f42c1' },
  raster: { label: pt('栅格'), icon: Picture, color: '#e67e22' },
  band: { label: pt('波段'), icon: Tickets, color: '#0097a7' },
  resource: { label: pt('资源'), icon: FolderOpened, color: '#2e7d32' },
  file: { label: pt('文件'), icon: Files, color: '#607d8b' }
};

function tableTypeMeta(raw: unknown): TableTypeMeta {
  const key = String(raw ?? '')
    .trim()
    .toLowerCase();
  return TABLE_TYPE_META[key] ?? { label: key ? key.toUpperCase() : pt('未指定'), icon: Document, color: 'var(--el-text-color-secondary)' };
}

function modelNode(m: any, scope: string): TreeNodeVM {
  // 模板（范例）与源模型同名同类别，树里光看 label 无法区分：
  // 后端 /models 会同时返回两者（isTemplate 标记），这里给模板加后缀
  const baseName = m.modelName || '未命名模型';
  const label = m.isTemplate ? `${baseName}（范例）` : baseName;
  return {
    key: `model:${scope}::${m.modelUid}`,
    label,
    kind: 'model',
    keyword: `${baseName} ${m.modelKey ?? ''}`,
    modelUid: m.modelUid
  };
}

function buildCategoryNodes(list: any[], prefix = 'c'): TreeNodeVM[] {
  return (list ?? []).map((node, index) => {
    // categoryKey 缺失时用 uid / 序号兜底，避免 node-key 重复
    const key = node.categoryKey || node.categoryUid || `${prefix}${index}`;
    const own = modelsByCatKey.value.get(key) ?? [];
    const children = [...buildCategoryNodes(node.children ?? [], `${prefix}-${index}`), ...own.map((m) => modelNode(m, `cat:${key}`))];
    return {
      key: `cat:${key}`,
      label: node.categoryName || '未命名类别',
      kind: 'cat',
      count: own.length || undefined,
      keyword: node.categoryName ?? '',
      children: children.length ? children : undefined
    };
  });
}

/**
 * 剪掉「整枝都挂不上模型」的类别分支：产品类型段只展示模型里真实用到的类别。
 *
 * WHY：产品类别来自产品类型管理维护的完整分类树，大部分类别在本页没有任何模型可看，
 * 全量铺开会把真正有模型的分支挤到看不见，用户还得一层层点进去才能确认是空的。
 * 判据是「本节点挂着模型，或任一子级还有内容」⇒ 有模型子级的上层类别会整条链保留，层次不会断。
 * CONSTRAINT 只剪展示用的树，不动 allCatKeys / categoryKeySet：
 * 那两个集合要保留全量类别，否则「模型挂的类别是否还在」会误判成未分类。
 */
function pruneEmptyCategories(nodes: TreeNodeVM[]): TreeNodeVM[] {
  const kept: TreeNodeVM[] = [];
  (nodes ?? []).forEach((node) => {
    const children = pruneEmptyCategories(node.children ?? []);
    // 模型叶子恒保留；类别节点只有还挂着模型时才留
    if (node.kind !== 'model' && !children.length) return;
    kept.push({ ...node, children: children.length ? children : undefined });
  });
  return kept;
}

/** 资源树节点字段兼容兜底（实测节点可能是类别 categoryKey 或资源 uid，旧数据偶见 nodeUid/nodeName），三处都兜 */
function resNodeKey(node: any): string {
  return node?.categoryKey || node?.categoryUid || node?.nodeUid || '';
}
function resNodeLabel(node: any): string {
  return node?.categoryName || node?.nodeName || node?.displayName || '未命名目录';
}

function buildResourceNodes(list: any[], prefix = 'r'): TreeNodeVM[] {
  return (list ?? []).map((node, index) => {
    const raw = resNodeKey(node);
    const key = raw || `${prefix}${index}`;
    const own = raw ? (modelsByCatKey.value.get(raw) ?? []) : [];
    const children = [...buildResourceNodes(node.children ?? [], `${prefix}-${index}`), ...own.map((m) => modelNode(m, `res:${key}`))];
    return {
      key: `res:${key}`,
      label: resNodeLabel(node),
      kind: 'res',
      count: own.length || undefined,
      keyword: resNodeLabel(node),
      children: children.length ? children : undefined
    };
  });
}

/** 既没挂产品类别、也没挂资源目录的模型（真正需要治理的孤儿模型） */
const orphanModels = computed(() => models.value.filter((m) => !catKeysOf(m).some((k) => allCatKeys.value.has(k))));

/** 产品类别树里真实存在的全部编码：用来判定「模型挂的类别是否还在」 */
const categoryKeySet = computed(() => {
  const set = new Set<string>();
  const walk = (list: any[]) =>
    list.forEach((n) => {
      const key = n.categoryKey || n.categoryUid;
      if (key) set.add(key);
      if (n.children?.length) walk(n.children);
    });
  walk(categoryTree.value);
  return set;
});

/**
 * 完全没挂产品类别（或挂的类别已被删）的模型。
 *
 * WHY 与 orphanModels 分开：按上下文根收窄后树里不再渲染「数据资源」段，
 * 只挂了资源目录的模型在 root 模式下也无处可去；而 orphanModels 认为「挂在资源树上就算有归属」。
 * 所以 root 模式要单独兜住这批，否则列表接口返回 18 条、树里只数出 17 条（用户实测踩过）。
 */
const uncategorizedModels = computed(() => models.value.filter((m) => !catKeysOf(m).some((k) => categoryKeySet.value.has(k))));

const treeData = computed<TreeNodeVM[]>(() => {
  /*
   * 有上下文根（初级产品 / 成果产品入口）时，树只保留「该根这一级」：
   * 初级产品管理入口 → 根节点就是「初级产品管理」，其下才是类别与模型，不再出现兄弟根。
   *
   * WHY 同时不再挂「产品类型 / 数据资源」两个分组：后端 resources/tree 与 product-categories
   * 返回的是同一套分类（两段的根节点名、层级、模型数完全一致，截图实证），
   * 过滤到同一根后两段内容一模一样，留着只会让同一批模型在树里出现两遍。
   */
  const rootNode = pickRootNode();
  if (rootNode) {
    const [rootVm] = buildCategoryNodes([rootNode]);
    // 只剪子级：上下文根自己必须留着，否则该入口一个模型都没有时整棵树会空成一片、连点都点不了
    const kept = pruneEmptyCategories(rootVm.children ?? []);
    rootVm.children = kept.length ? kept : undefined;
    // 收窄后没有类别可挂的模型不能凭空消失：作为根节点的最后一个子节点挂上「未分类」，
    // 保证根节点统计到的模型数 = 列表接口给的模型数（挂在根外面会让根的数少一截，等于没修）
    if (uncategorizedModels.value.length) {
      rootVm.children = [
        ...(rootVm.children ?? []),
        {
          key: 'cat:__uncat',
          label: pt('未分类'),
          kind: 'cat',
          count: uncategorizedModels.value.length,
          keyword: pt('未分类'),
          children: uncategorizedModels.value.map((m) => modelNode(m, 'cat:__uncat'))
        }
      ];
    }
    return [rootVm];
  }

  // 无上下文根（通用入口）时保持原样：产品类型 / 数据资源 两段
  // 产品类型段只留挂得上模型的类别；「数据资源」段与本次诉求无关，保持全量
  const allCategoryNodes = buildCategoryNodes(categoryTree.value);
  const prunedCategoryNodes = pruneEmptyCategories(allCategoryNodes);
  // CONSTRAINT 剪枝后为空必须退回全量：本页唯一的「新建模型」入口挂在类别节点上，
  // 树被剪空就等于新库（一条模型都没有）时彻底建不了模型。
  const productNodes = prunedCategoryNodes.length ? prunedCategoryNodes : allCategoryNodes;
  if (orphanModels.value.length) {
    productNodes.push({
      key: 'cat:__orphan',
      label: pt('未分类'),
      kind: 'cat',
      count: orphanModels.value.length,
      keyword: pt('未分类'),
      children: orphanModels.value.map((m) => modelNode(m, 'cat:__orphan'))
    });
  }
  return [
    { key: 'group:product', label: pt('产品类型'), kind: 'group', count: models.value.length, children: productNodes },
    { key: 'group:resource', label: pt('数据资源'), kind: 'group', children: buildResourceNodes(resourceTree.value) }
  ];
});

/* ------------------------------------------------------------------ */
/* 右侧详情                                                            */
/* ------------------------------------------------------------------ */

async function selectModel(uid: string, key: string) {
  currentKey.value = key;
  const row = models.value.find((m) => m.modelUid === uid) ?? null;
  currentModel.value = row;
  detail.value = null;
  tab.value = 'fields';
  detailLoading.value = true;
  try {
    // 模板与模型详情都是 GET；列表接口里两类 uid 都能命中 /models/{uid}（实测模板 uid 亦 200）
    const res = await (row?.isTemplate ? api.getMetadataTemplateDetail(uid) : api.getMetadataModelDetail(uid));
    if (res?.code === 0) detail.value = res.data;
  } catch {
    // 详情失败不阻塞：头部仍用列表行展示，字段页签给空态
  } finally {
    detailLoading.value = false;
  }
}

function onNodeClick(data: TreeNodeVM) {
  currentKey.value = data.key;
  if (data.kind === 'model' && data.modelUid) {
    selectModel(data.modelUid, data.key);
    return;
  }
  currentModel.value = null;
  detail.value = null;
}

/** 反查某模型在树里的第一个节点 key（同一模型可能在多个类别下重复出现） */
function findModelNodeKey(uid: string): string {
  let found = '';
  const walk = (list: TreeNodeVM[]) =>
    list.forEach((n) => {
      if (!found && n.kind === 'model' && n.modelUid === uid) found = n.key;
      if (n.children?.length) walk(n.children);
    });
  walk(treeData.value);
  return found;
}

/** 类别 / 资源 / 分组节点下（含子级）的模型，用于卡片网格 */
const currentNode = computed(() => {
  if (!currentKey.value || currentKey.value.startsWith('model:')) return null;
  const find = (list: TreeNodeVM[]): TreeNodeVM | null => {
    for (const n of list) {
      if (n.key === currentKey.value) return n;
      if (n.children?.length) {
        const hit = find(n.children);
        if (hit) return hit;
      }
    }
    return null;
  };
  return find(treeData.value);
});

/**
 * 节点下（含子级）的模型。
 *
 * WHY 按 uid 去重：一个模型可以关联多个产品类别，在树里就是多个叶子节点，
 * 直接 collect 会把同一个模型数两次（「共 N 个模型」虚高、卡片重复出现）。
 */
function collectModels(node: TreeNodeVM): any[] {
  const seen = new Set<string>();
  const out: any[] = [];
  const walk = (n: TreeNodeVM) => {
    if (n.kind === 'model' && n.modelUid && !seen.has(n.modelUid)) {
      const m = models.value.find((x) => x.modelUid === n.modelUid);
      if (m) {
        seen.add(n.modelUid);
        out.push(m);
      }
    }
    (n.children ?? []).forEach(walk);
  };
  walk(node);
  return out;
}

const gridModels = computed(() => (currentNode.value ? collectModels(currentNode.value) : []));

/** 节点类型的中文名（详情头部的小标签） */
function nodeKindLabel(kind: TreeNodeVM['kind']) {
  return kind === 'res' ? pt('资源目录') : kind === 'group' ? pt('维度') : pt('产品类别');
}

const sumTables = (list: any[]) => list.reduce((n, m) => n + (m.tableCount ?? 0), 0);
const sumFields = (list: any[]) => list.reduce((n, m) => n + (m.fieldCount ?? 0), 0);

/** 当前节点是不是树的根（按上下文根收窄后只有一个根）：只有根节点才谈得上「全库」口径 */
const isRootNode = computed(() => !!currentNode.value && treeData.value[0]?.key === currentNode.value.key);

/** 列表接口有、但当前节点下数不到的模型数（它们的类别归在别的产品类型下） */
const outOfScopeCount = computed(() => Math.max(0, models.value.length - gridModels.value.length));

/** 全库模型数：接口声明与实际返回取大者，两者不一致本身就是信息 */
const globalCount = computed(() => Math.max(listTotal.value, models.value.length));

/**
 * 「页面统计」与「接口数字」对不上时的一句话解释；没差异就返回空串（不显示）。
 * 三种口径差：后端分页/权限过滤只回了一部分、模型的类别属于别的产品类型、模型没挂类别。
 * 第三种已由树里的「未分类」兜住，前两种只能写出来，否则用户只会看到两个不一致的数字。
 */
const countNote = computed(() => {
  if (!isRootNode.value) return '';
  const notes: string[] = [];
  if (listTotal.value > models.value.length) {
    notes.push(`列表接口声明 ${listTotal.value} 个，实际只返回 ${models.value.length} 条（可能被分页或权限过滤）`);
  }
  if (outOfScopeCount.value) {
    notes.push(`${outOfScopeCount.value} 个的所属类别不在当前产品类型下，需切到对应产品类型查看`);
  }
  return notes.join('；');
});

/**
 * 卡片上的类别标签：当前就在看某个类别时，把他自己那一枚去掉。
 * 否则一整屏卡片都重复同一个标签（和头部标题一模一样），白占一行、零信息量；
 * 只有在「父级 / 维度」节点下（模型跨类别混排）才需要这个标签说明归属。
 */
function cardCats(row: any) {
  const self = currentNode.value?.kind === 'cat' ? currentNode.value.label : '';
  return (row?.productCategories ?? []).filter((c: any) => c.categoryName !== self);
}

/* 明确表/字段类型：模板里 v-for 的索引才会被推断成 number（写成 any[] 时是 string | number，
   `{{ i + 1 }}` 会报 TS2365） */
const tables = computed<ModelTableDefinition[]>(() => detail.value?.tables ?? []);

/* 多表时允许点击表头折叠内容：以「表 key / 序号」为索引存折叠态，切模型时重置 */
const collapsed = ref<Record<string, boolean>>({});

/** 表的稳定 key（与模板里 v-for 的 key 保持一致） */
function tableKeyOf(table: any, ti: number): string {
  return table.tableKey || table.tableName || `table-${ti}`;
}

/** 点击表头：仅多表时切换折叠态 */
function toggleTable(table: any, ti: number) {
  if (tables.value.length <= 1) return;
  const k = tableKeyOf(table, ti);
  collapsed.value[k] = !collapsed.value[k];
}

/** 切换模型时清掉折叠态，避免上一个模型的折叠态串到新模型 */
watch(
  () => currentModel.value?.modelUid,
  () => (collapsed.value = {})
);

const detailMeta = computed(() => {
  const m = currentModel.value ?? {};
  return {
    tableCount: detail.value?.tables?.length ?? m.tableCount ?? 0,
    fieldCount: tables.value.length ? tables.value.reduce((n, t) => n + (t.fields?.length ?? 0), 0) : (m.fieldCount ?? 0),
    version: m.versionNo ? `v${m.versionNo}` : '',
    updatedAt: m.updatedAt ? dayjs(m.updatedAt).format('YYYY-MM-DD HH:mm') : ''
  };
});

/* ------------------------------------------------------------------ */
/* 字段类型展示                                                        */
/* ------------------------------------------------------------------ */

const VALUE_TYPES: Record<string, { label: string; sym: string; color: string; bg: string }> = {
  string: { label: pt('文本'), sym: 'T', color: '#5f6a7a', bg: '#f1f3f7' },
  text: { label: pt('文本'), sym: 'T', color: '#5f6a7a', bg: '#f1f3f7' },
  integer: { label: pt('整数'), sym: '#', color: '#b88230', bg: '#fdf4e6' },
  int: { label: pt('整数'), sym: '#', color: '#b88230', bg: '#fdf4e6' },
  number: { label: pt('数值'), sym: '#', color: '#b88230', bg: '#fdf4e6' },
  float: { label: pt('浮点'), sym: '#', color: '#b88230', bg: '#fdf4e6' },
  double: { label: pt('浮点'), sym: '#', color: '#b88230', bg: '#fdf4e6' },
  decimal: { label: pt('小数'), sym: '#', color: '#b88230', bg: '#fdf4e6' },
  boolean: { label: pt('布尔'), sym: '⊙', color: '#5b6bc0', bg: '#eef1fb' },
  bool: { label: pt('布尔'), sym: '⊙', color: '#5b6bc0', bg: '#eef1fb' },
  date: { label: pt('日期'), sym: '◷', color: '#5d9643', bg: '#eef7ec' },
  datetime: { label: pt('日期时间'), sym: '◷', color: '#5d9643', bg: '#eef7ec' },
  timestamp: { label: pt('时间戳'), sym: '◷', color: '#5d9643', bg: '#eef7ec' },
  enum: { label: pt('枚举'), sym: '≡', color: '#8256c4', bg: '#f5eefc' },
  geometry: { label: pt('几何'), sym: '{}', color: '#2f7ad6', bg: '#eaf3ff' },
  geojson: { label: pt('几何'), sym: '{}', color: '#2f7ad6', bg: '#eaf3ff' },
  object: { label: pt('对象'), sym: '{}', color: '#5f6a7a', bg: '#f1f3f7' },
  json: { label: 'JSON', sym: '{}', color: '#5f6a7a', bg: '#f1f3f7' },
  array: { label: pt('数组'), sym: '[]', color: '#5f6a7a', bg: '#f1f3f7' },
  file: { label: pt('文件'), sym: '▤', color: '#c05e7c', bg: '#fdeef2' },
  url: { label: pt('链接'), sym: '⌁', color: '#3f8f9e', bg: '#eef6f8' }
};

function typeMeta(valueType: string) {
  return VALUE_TYPES[String(valueType ?? '').toLowerCase()] ?? { label: valueType || '未知', sym: '·', color: '#6b7686', bg: '#f1f3f7' };
}

/* ------------------------------------------------------------------ */
/* 操作（沿用原弹窗）                                                  */
/* ------------------------------------------------------------------ */

/**
 * 当前树选中节点对应的产品类别编码，用于新建模型时自动带入「产品类别」。
 *
 * 只在能确定唯一类别时才给值，宁可不带也不乱带：
 *   · 类别节点 → 自身 categoryKey；虚拟节点（__uncat / __orphan）与只作后端分组的
 *     primary / result 都不是可选类别，返回空；
 *   · 模型节点 → 该模型已挂的第一个类别（从模型详情点「编辑」时口径与列表一致）；
 *   · 分组 / 资源目录 / 未选中 → 空串，交给用户在弹窗里自己选。
 */
function selectedCategoryKey(): string {
  const key = currentKey.value;
  if (key.startsWith('cat:')) {
    const raw = key.slice(4);
    if (!raw || raw.startsWith('__') || RAW_ROOT_KEYS.has(raw)) return '';
    return raw;
  }
  if (key.startsWith('model:')) return catKeysOf(currentModel.value)[0] ?? '';
  return '';
}

function openEdit(row?: any) {
  // 模板不可编辑（后端未实现 PATCH /templates），其余模型都能编辑。
  // 注意：不能改用后端 canEdit —— 实测 19 个模型的 canEdit 全为 false，会全部锁死。
  if (row && row.isTemplate) {
    ElMessage.warning(pt('模板不可直接编辑，请在「新建元数据模型」时套用模板'));
    return;
  }
  // 用户在某个类别下点「新建」，弹窗里的产品类别就默认是他正看着的那个节点，
  // 不再让他从一棵长树里重新找一遍（弹窗里仍可改，类别不是硬绑定）。
  const categoryKey = selectedCategoryKey();
  // 新建成功要直接落到「新模型的详情」：先记下打开弹窗前的 uid 快照，
  // 这样即便后端创建响应不回 modelUid，也能用差集把这次新增的模型挑出来。
  const beforeUids = row ? null : new Set(models.value.map((m) => m.modelUid));
  // WHY createDialog 而非 createBlock：与改造前保持一致（宽度 1100 + minHeight 80vh），
  // 本次只改展示层，录入弹窗的形态和尺寸不动。
  createDialog({
    title: row ? (row.isTemplate ? pt('编辑模板（范例）') : pt('编辑元数据模型')) : pt('创建元数据模型'),
    width: '1180px',
    style: { minHeight: '80vh' },
    render: () => <EditForm row={row} defaultCategoryKeys={categoryKey ? [categoryKey] : []} />,
    /**
     * 保存成功后刷新列表并切到本次模型的详情。
     * 编辑态用原 uid；新建态优先用 createDialog 回传的创建响应（save() 的返回值）里的 modelUid，
     * 缺失时按「刷新后新出现 + 编码一致」兜底 —— 否则新增完只刷新列表、右侧仍停在原来的类别/模型，
     * 用户看不到刚建好的模型，得自己去树里找。
     */
    afterSave: async (res?: any) => {
      await loadData();
      const created: any = res?.data ?? {};
      const uid: string =
        row?.modelUid ||
        created.modelUid ||
        (beforeUids
          ? models.value.find((m) => !beforeUids.has(m.modelUid) && (!created.modelKey || m.modelKey === created.modelKey))?.modelUid
          : '') ||
        '';
      if (!uid) return;
      // treeData 是 computed，等 DOM 重建后再定位，否则 setCurrentKey 找不到新 key
      await nextTick();
      const key = findModelNodeKey(uid);
      if (key) treeRef.value?.setCurrentKey(key);
      // 即使树里暂时定位不到该节点，也要把右侧切到新模型详情（详情分支由 currentModel 决定）
      selectModel(uid, key || currentKey.value);
    }
  });
}

async function removeModel(row: any) {
  await ElMessageBox.confirm(`确认删除元数据模型「${row.modelName}」？删除后其元数据表与记录将一并移除。`, pt('删除元数据模型'), { type: 'warning' });
  const res = await api.deleteMetadataModel(row.modelUid);
  if (res.code === 0) {
    ElMessage.success(pt('元数据模型已删除'));
    currentKey.value = '';
    currentModel.value = null;
    detail.value = null;
    await loadData();
  } else {
    ElMessage.error(res.message || '删除失败');
  }
}

/**
 * 生成范例：把当前模型复制成「范例模型」（模板），并在左侧树里定位到新生成的范例。
 * 后端 /save-as-template 会新建一条 isTemplate=true 的模型（原模型不变），
 * 随后刷新列表 + setCurrentKey/selectModel，复用 openEdit.afterSave 的定位模式。
 */
async function generateExampleModel(row: any) {
  if (generatingExample.value) return;
  generatingExample.value = true;
  try {
    // 模板与源模型同名同类别，靠创建前的 uid 快照才能把新出现的范例挑出来
    const before = new Set(models.value.map((m) => m.modelUid));
    const res = await api.saveModelAsTemplate(row.modelUid, {
      modelName: row.modelName,
      description: row.description ?? ''
    });
    if (res.code !== 0) {
      ElMessage.error(res.message || '范例模型生成失败');
      return;
    }
    await loadData();
    // 后端通常回传新建的模板对象；没回 data 时退化为按 uid 差集在刷新后的列表里找同名范例
    const createdUid = res.data?.modelUid;
    const fallbackUid = models.value.find((m) => m.isTemplate && !before.has(m.modelUid) && m.modelName === row.modelName)?.modelUid;
    const created = createdUid || fallbackUid;
    if (created) {
      // treeData 是 computed，等 DOM 重建后再定位，否则 setCurrentKey 找不到新 key
      await nextTick();
      const key = findModelNodeKey(created);
      treeRef.value?.setCurrentKey(key);
      if (key) selectModel(created, key);
    }
    ElMessage.success(pt('已生成范例模型'));
  } catch {
    ElMessage.error(pt('范例模型生成失败'));
  } finally {
    generatingExample.value = false;
  }
}

/** 卡片点击 → 定位到树里的模型节点 */
function openModelCard(row: any) {
  const key = findModelNodeKey(row.modelUid);
  if (key) treeRef.value?.setCurrentKey(key);
  selectModel(row.modelUid, key || currentKey.value);
}

/* ------------------------------------------------------------------ */
/* 树搜索                                                              */
/* ------------------------------------------------------------------ */

function filterNode(value: string, data: TreeNodeVM) {
  if (!value) return true;
  const hay = `${data.label} ${data.keyword ?? ''}`.toLowerCase();
  return hay.includes(value.toLowerCase());
}

watch(keyword, (val) => treeRef.value?.filter(val));

/* ------------------------------------------------------------------ */

onMounted(async () => {
  await loadData();
  // 数据到齐后再量：树宽要按真实类别名算，空树量出来的宽度没有意义
  await nextTick();
  fitTreeWidth();
  // 默认选中第一个模型，避免右侧空白
  const first = models.value[0];
  if (!first) return;
  const key = findModelNodeKey(first.modelUid);
  treeRef.value?.setCurrentKey(key);
  if (key) selectModel(first.modelUid, key);
});
</script>

<template>
  <div v-loading="loading" ref="mmRef" class="mm">
    <!-- 左：产品类型 + 数据资源 拼接树（宽度按容器自适应，可拖拽调整） -->
    <aside class="mm-tree" :style="{ flexBasis: treeWidth + 'px' }">
      <div class="mm-tree__head">
        <el-input v-model="keyword" :placeholder="pt('搜索模型 / 类别')" clearable :prefix-icon="Search" class="mm-tree__search" />
        <!-- 树头部就近创建：与右上角「新建元数据模型」共用 openEdit()，并沿用当前选中节点自动带入产品类别 -->
        <el-tooltip :content="pt('新建元数据模型')" placement="bottom">
          <el-button type="primary" :icon="Plus" :aria-label="pt('新建元数据模型')" class="mm-tree__add" @click="openEdit()" />
        </el-tooltip>
      </div>
      <div class="mm-tree__body">
        <el-tree
          ref="treeRef"
          :data="treeData"
          node-key="key"
          :props="{ label: 'label', children: 'children' }"
          :indent="14"
          :default-expand-all="true"
          :expand-on-click-node="false"
          highlight-current
          :filter-node-method="filterNode"
          @node-click="onNodeClick"
        >
          <template #default="{ data }">
            <span class="mm-node" :class="`is-${data.kind}`">
              <el-icon class="mm-node__ic"><component :is="nodeIcon(data.kind)" /></el-icon>
              <span class="mm-node__label" :title="data.label">{{ data.label }}</span>
              <span v-if="data.count" class="mm-node__count">{{ data.count }}</span>
            </span>
          </template>
        </el-tree>
        <el-empty v-if="!loading && !models.length" description="暂无元数据模型" :image-size="50" />
      </div>
      <!-- <div class="mm-tree__foot">
        <el-button type="primary" plain :icon="Plus" class="w-full" @click="openEdit()">新建元数据模型</el-button>
      </div> -->
    </aside>

    <!-- 拖拽分隔条：树宽自适应之外的微调手段 -->
    <div class="mm-split" title="拖动调整树宽度" @pointerdown.prevent="startResize" />

    <!-- 右：详情（只读） -->
    <section class="mm-detail">
      <!-- 模型详情 -->
      <template v-if="currentModel">
        <header class="mm-head">
          <div class="mm-head__title">
            <el-icon class="mm-head__ic"><Document /></el-icon>
            <h2>{{ currentModel.modelName }}</h2>
            <el-tag v-if="currentModel.isTemplate" size="small" type="warning" effect="plain" round>范例</el-tag>
            <!-- 标题后面不再挂 modelKey：模板生成的模型它的值是 template-<uuid>，对用户毫无信息量，
                 真需要核对编码时「基本信息」页签里的「模型编码」照样能查 -->
          </div>
          <div class="mm-head__actions">
            <!-- 判据：只用 isTemplate。后端 canEdit / canDelete 在列表接口里对全部 19 个模型都返回 false
                 （实测），拿它做 disabled 会把所有模型锁死，不能用 -->
            <el-button v-if="!currentModel.isTemplate" type="primary" :icon="Edit" @click="openEdit(currentModel)">编辑</el-button>
            <el-button v-if="!currentModel.isTemplate" :icon="DocumentCopy" :loading="generatingExample" @click="generateExampleModel(currentModel)"
              >生成范例</el-button
            >
            <el-button v-if="!currentModel.isTemplate" type="danger" :icon="Delete" @click="removeModel(currentModel)">删除</el-button>
          </div>
          <div class="mm-head__meta mm-head__meta--full">
            <span v-for="item in currentModel.productCategories || []" :key="item.categoryUid || item.categoryName" class="mm-head__cat">
              {{ item.categoryName }}
            </span>
            <span v-if="!currentModel.productCategories?.length" class="mm-head__cat is-empty">未分类</span>
            <span class="mm-head__sep" />
            <span>{{ detailMeta.tableCount }} 张表</span>
            <i>·</i>
            <span>{{ detailMeta.fieldCount }} 个字段</span>
            <template v-if="detailMeta.version">
              <i>·</i>
              <span>{{ detailMeta.version }}</span>
            </template>
            <template v-if="detailMeta.updatedAt">
              <i>·</i>
              <span>更新于 {{ detailMeta.updatedAt }}</span>
            </template>
          </div>
        </header>

        <el-tabs v-model="tab" class="mm-tabs">
          <el-tab-pane :label="`字段 (${detailMeta.fieldCount})`" name="fields">
            <div v-loading="detailLoading" class="mm-fields-pane">
              <template v-if="tables.length">
                <!-- key 不能只用 tableKey：多表模型里后端可能给空/重复的 tableKey，撞 key 会让整块不重渲染 -->
                <div v-for="(table, ti) in tables" :key="table.tableKey || table.tableName || `table-${ti}`" class="mm-table">
                  <!-- 多表时表头可点击折叠：is-collapsible 只在多表下生效（单表不折叠、不显示箭头） -->
                  <div
                    class="mm-table__head"
                    :class="{ 'is-collapsible': tables.length > 1, 'is-collapsed': tables.length > 1 && collapsed[tableKeyOf(table, ti)] }"
                    @click="toggleTable(table, ti)"
                  >
                    <el-icon v-if="tables.length > 1" class="mm-table__toggle"
                      ><component :is="collapsed[tableKeyOf(table, ti)] ? ArrowRight : ArrowDown"
                    /></el-icon>
                    <el-icon class="mm-table__ic" :style="{ color: tableTypeMeta(table.tableType).color }"
                      ><component :is="tableTypeMeta(table.tableType).icon"
                    /></el-icon>
                    <!-- 多表时给序号：表名常由后端按模型名生成，几块标题长得一样，只能靠序号分辨 -->
                    <span v-if="tables.length > 1" class="mm-table__ord">表 {{ ti + 1 }}</span>
                    <span class="mm-table__name">{{ table.tableName || '未命名表' }}</span>
                    <span
                      class="mm-table__type"
                      :style="{ color: tableTypeMeta(table.tableType).color, borderColor: tableTypeMeta(table.tableType).color }"
                    >
                      <el-icon><component :is="tableTypeMeta(table.tableType).icon" /></el-icon>
                      {{ tableTypeMeta(table.tableType).label }}
                    </span>
                    <span class="mm-table__key">{{ table.tableKey }}</span>
                    <span class="mm-grow" />
                    <span class="mm-table__count">{{ table.fields?.length ?? 0 }} 字段</span>
                  </div>
                  <!-- 列与原详情弹窗一致（序号/名称/类型/长度/允许为空/枚举值/描述/缺省值/备注），
                       额外补了「字段编码」——原详情没这列，但排查接口对字段时天天要用 -->
                  <div v-show="!(tables.length > 1 && collapsed[tableKeyOf(table, ti)])" class="mm-ftable-wrap">
                    <table v-if="table.fields?.length" class="mm-ftable">
                      <colgroup>
                        <col class="c-idx" />
                        <col class="c-name" />
                        <col class="c-code" />
                        <col class="c-type" />
                        <col class="c-len" />
                        <col class="c-rule" />
                        <col class="c-enum" />
                        <col class="c-def" />
                        <col class="c-desc" />
                        <col class="c-note" />
                      </colgroup>
                      <thead>
                        <tr>
                          <th class="is-center">#</th>
                          <th>字段名称</th>
                          <th>字段编码</th>
                          <th>字段类型</th>
                          <th class="is-center">长度</th>
                          <th>允许为空</th>
                          <th>枚举值</th>
                          <th>缺省值</th>
                          <th>字段描述</th>
                          <th>备注</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr v-for="(field, fi) in table.fields" :key="field.fieldKey || fi">
                          <td class="is-center mm-ftable__idx">{{ fi + 1 }}</td>
                          <td :title="field.displayName || field.fieldKey">{{ field.displayName || field.fieldKey }}</td>
                          <td class="mm-ftable__code" :title="field.fieldKey">{{ field.fieldKey }}</td>
                          <td>
                            <span class="mm-ftable__type">
                              <i class="mm-ftable__ic" :style="{ color: typeMeta(field.valueType).color, background: typeMeta(field.valueType).bg }">
                                {{ typeMeta(field.valueType).sym }}
                              </i>
                              {{ typeMeta(field.valueType).label }}
                            </span>
                          </td>
                          <!-- 接口真实返回 length，fieldLength 恒为 null；用 fieldLength ?? length 兼容旧字段 -->
                          <td class="is-center mm-ftable__dim">{{ field.length ?? field.fieldLength ?? '-' }}</td>
                          <td>
                            <span class="mm-pill" :class="field.nullable ? 'is-opt' : 'is-req'">{{ field.nullable ? '是' : '否' }}</span>
                            <span v-if="field.repeatable" class="mm-pill is-rep">可重复</span>
                          </td>
                          <td class="mm-ftable__enum" :title="(field.options || []).join('、')">
                            <template v-if="field.options?.length">
                              <span v-for="(opt, oi) in field.options" :key="oi" class="mm-ftable__opt">{{ opt }}</span>
                            </template>
                            <span v-else class="mm-muted">-</span>
                          </td>
                          <td :title="field.defaultValue">{{ field.defaultValue || '-' }}</td>
                          <td :title="field.description">{{ field.description || '-' }}</td>
                          <td :title="field.helpText">{{ field.helpText || '-' }}</td>
                        </tr>
                      </tbody>
                    </table>
                    <el-empty v-else description="该表暂无字段" :image-size="40" />
                  </div>
                </div>
              </template>
              <el-empty v-else-if="!detailLoading" description="未获取到表结构，请点「编辑」查看完整定义" :image-size="70" />
            </div>
          </el-tab-pane>

          <el-tab-pane label="基本信息" name="meta">
            <el-descriptions :column="1" border class="mm-desc">
              <el-descriptions-item label="模型名称">{{ currentModel.modelName || '-' }}</el-descriptions-item>
              <el-descriptions-item label="模型编码">{{ currentModel.modelKey || '-' }}</el-descriptions-item>
              <el-descriptions-item label="产品类别">
                <template v-if="currentModel.productCategories?.length">
                  <el-tag v-for="item in currentModel.productCategories" :key="item.categoryUid || item.categoryName" size="small" class="mr-1">
                    {{ item.categoryName }}
                  </el-tag>
                </template>
                <span v-else class="mm-muted">未分类</span>
              </el-descriptions-item>
              <el-descriptions-item label="描述">{{ currentModel.description || '暂无描述' }}</el-descriptions-item>
              <el-descriptions-item label="表数量">{{ detailMeta.tableCount }} 张</el-descriptions-item>
              <el-descriptions-item label="字段总数">{{ detailMeta.fieldCount }} 个</el-descriptions-item>
              <el-descriptions-item label="版本号">{{ detailMeta.version || '-' }}</el-descriptions-item>
              <el-descriptions-item label="更新时间">{{ detailMeta.updatedAt || '-' }}</el-descriptions-item>
              <el-descriptions-item label="表清单">
                <div v-if="tables.length" class="mm-table-list">
                  <div v-for="(table, ti) in tables" :key="table.tableKey || table.tableName || `t-${ti}`">
                    <span class="mm-table__key">{{ table.tableKey }}</span>
                    <span>{{ table.tableName || '未命名表' }}</span>
                    <span
                      class="mm-table__type"
                      :style="{ color: tableTypeMeta(table.tableType).color, borderColor: tableTypeMeta(table.tableType).color }"
                    >
                      <el-icon><component :is="tableTypeMeta(table.tableType).icon" /></el-icon>
                      {{ tableTypeMeta(table.tableType).label }}
                    </span>
                    <span class="mm-muted">{{ table.fields?.length ?? 0 }} 字段</span>
                  </div>
                </div>
                <span v-else class="mm-muted">未获取到表结构</span>
              </el-descriptions-item>
            </el-descriptions>
          </el-tab-pane>
        </el-tabs>
      </template>

      <!-- 类别 / 资源 / 分组节点下的模型卡片 -->
      <template v-else-if="currentNode">
        <header class="mm-head">
          <div class="mm-head__title">
            <el-icon class="mm-head__ic"><component :is="nodeIcon(currentNode.kind)" /></el-icon>
            <h2>{{ currentNode.label }}</h2>
            <span class="mm-head__kind">{{ nodeKindLabel(currentNode.kind) }}</span>
          </div>
          <div class="mm-head__actions">
            <!-- 有内容时头部给入口；空态时按钮交给下方 el-empty 居中显示，避免同一屏出现两个一模一样的按钮 -->
            <el-button v-if="currentNode.kind !== 'res' && gridModels.length" type="primary" :icon="Plus" @click="openEdit()">
              新建元数据模型
            </el-button>
          </div>
          <div v-if="gridModels.length" class="mm-head__meta mm-head__meta--full">
            <span
              >共 <b>{{ gridModels.length }}</b> 个模型</span
            >
            <i>·</i>
            <span>{{ sumTables(gridModels) }} 张表</span>
            <i>·</i>
            <span>{{ sumFields(gridModels) }} 个字段</span>
            <!-- 数不到的那部分要说清去哪了，否则「接口 18 条、这里 17 个」看着像 bug -->
            <template v-if="countNote">
              <i>·</i>
              <span class="mm-head__hint" :title="countNote">全库 {{ globalCount }} 个</span>
            </template>
          </div>
        </header>
        <div class="mm-grid-wrap">
          <el-empty
            v-if="!gridModels.length"
            :description="currentNode.kind === 'res' ? '该资源目录下暂无关联模型（模型目前通过「产品类别」关联）' : '该节点下暂无关联模型'"
            :image-size="70"
          >
            <el-button v-if="currentNode.kind !== 'res'" type="primary" plain :icon="Plus" @click="openEdit()">新建元数据模型</el-button>
          </el-empty>
          <div v-else class="mm-grid">
            <article v-for="row in gridModels" :key="row.modelUid" class="mm-card" @click="openModelCard(row)">
              <div class="mm-card__head">
                <span class="mm-card__ic"
                  ><el-icon><Document /></el-icon
                ></span>
                <div class="mm-card__titles">
                  <div class="mm-card__title" :title="row.modelName">
                    {{ row.modelName || '未命名模型' }}
                    <el-tag v-if="row.isTemplate" size="small" type="warning" effect="plain" round class="mm-card__tmpl">范例</el-tag>
                  </div>
                  <div class="mm-card__key" :title="row.modelKey">{{ row.modelKey }}</div>
                </div>
                <span class="mm-card__ver" title="模型版本号">v{{ row.versionNo ?? 1 }}</span>
              </div>
              <p class="mm-card__desc" :class="{ 'is-empty': !row.description }">{{ row.description || '暂无描述' }}</p>
              <!-- 只有当卡片上确实有「归属」信息可写时才占这一行：类别节点下已去掉同名标签 -->
              <div v-if="cardCats(row).length || !row.productCategories?.length" class="mm-card__tags">
                <span v-for="c in cardCats(row)" :key="c.categoryUid || c.categoryName" class="mm-card__tag">
                  {{ c.categoryName }}
                </span>
                <span v-if="!row.productCategories?.length" class="mm-card__tag is-empty">未分类</span>
              </div>
              <div class="mm-card__foot">
                <span class="mm-card__stat"
                  ><b>{{ row.tableCount ?? 0 }}</b> 张表</span
                >
                <span class="mm-card__dot">·</span>
                <span class="mm-card__stat"
                  ><b>{{ row.fieldCount ?? 0 }}</b> 字段</span
                >
                <span class="mm-grow" />
                <time class="mm-card__time">{{ row.updatedAt ? dayjs(row.updatedAt).format('MM-DD HH:mm') : '-' }}</time>
              </div>
            </article>
          </div>
        </div>
      </template>

      <!-- 未选中 -->
      <el-empty v-else class="mm-empty" description="在左侧选择一个模型或类别查看详情" :image-size="80" />
    </section>
  </div>
</template>

<style lang="scss" scoped>
.mm {
  display: flex;
  gap: 0;
  height: 100%;
  min-height: 0;
  padding: 0 12px 12px;
}

/* ---------- 左树 ---------- */
.mm-tree {
  display: flex;
  flex: 0 0 auto;
  flex-direction: column;
  min-height: 0;
  /* 宽度由 treeWidth 控制；上限只兜住极端窄窗口，不干扰用户把树拖宽 */
  max-width: 55%;
  overflow: hidden;
  background: var(--el-bg-color);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 6px;
  padding: 0;
  &__head {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 10px 8px;
    border-bottom: 1px solid var(--el-border-color-lighter);
  }

  /* 搜索框吃掉剩余宽度；窄树时创建按钮固定不动，不把输入框挤没 */
  &__search {
    flex: 1;
    min-width: 0;
  }

  /* 纯图标创建按钮：与 el-input 默认 32px 高度对齐，去掉默认内边距压成正方形 */
  &__add {
    flex: none;
    width: 32px;
    height: 32px;
    padding: 0;
  }

  &__body {
    flex: 1;
    min-height: 0;
    padding: 6px 6px 10px;
    overflow: auto;
  }

  &__foot {
    padding: 8px 10px;
    border-top: 1px solid var(--el-border-color-lighter);
  }
}

.mm-node {
  display: flex;
  align-items: center;
  gap: 6px;
  width: 100%;
  padding-right: 4px;
  font-size: 13px;

  &__ic {
    display: inline-flex;
    flex: none;
    align-items: center;
    width: 15px;
    color: var(--el-text-color-placeholder);
    font-size: 13px;
  }

  &__label {
    flex: 1;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  &__count {
    flex: none;
    min-width: 20px;
    padding: 0 5px;
    color: var(--el-text-color-secondary);
    font-size: 11px;
    line-height: 16px;
    text-align: center;
    background: var(--el-fill-color-light);
    border-radius: 8px;
  }

  /* 产品类型 = 蓝色文件夹、数据资源 = 橙色数据图标、模型 = 灰色文档：不读文字也能分清两类维度 */
  &.is-cat .mm-node__ic {
    color: var(--el-color-primary);
  }

  &.is-res .mm-node__ic {
    color: var(--el-color-warning);
  }

  &.is-model {
    color: var(--el-text-color-regular);

    .mm-node__ic {
      color: var(--el-text-color-secondary);
    }
  }

  &.is-group {
    color: var(--el-text-color-primary);
    font-weight: 600;
    letter-spacing: 0.02em;

    .mm-node__ic {
      color: var(--el-text-color-regular);
    }
  }
}

/* 拖拽分隔条：热区 9px，悬停时中间亮一条竖线（平时不画，避免多出一条视觉分割线） */
.mm-split {
  position: relative;
  display: flex;
  flex: 0 0 9px;
  align-self: stretch;
  cursor: col-resize;
  touch-action: none;

  &::after {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 2px;
    height: 34px;
    background: var(--el-color-primary);
    border-radius: 1px;
    opacity: 0;
    transform: translate(-50%, -50%);
    transition: opacity 0.15s;
  }

  &:hover::after {
    opacity: 0.65;
  }
}

:deep(.el-tree-node__content) {
  height: 30px;
  border-radius: 4px;
}

:deep(.el-tree-node.is-current > .el-tree-node__content) {
  background: var(--el-color-primary-light-9);

  .mm-node__count {
    color: var(--el-color-primary);
    background: var(--el-color-primary-light-8);
  }
}

/* ---------- 右详情 ---------- */
.mm-detail {
  display: flex;
  flex: 1;
  flex-direction: column;
  min-width: 0;
  min-height: 0;
  overflow: hidden;
  background: var(--el-bg-color);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 6px;
}

.mm-head {
  display: flex;
  flex: none;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px 12px;
  padding: 14px 16px 8px;

  &__title {
    display: flex;
    align-items: center;
    gap: 8px;
    min-width: 0;

    h2 {
      max-width: 400px;
      margin: 0;
      overflow: hidden;
      color: var(--el-text-color-primary);
      font-size: 17px;
      font-weight: 600;
      letter-spacing: -0.01em;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }

  /* 头部图标：浅色底方块，与树上的节点图标呼应，让「这是模型 / 这是类别」一眼可辨 */
  &__ic {
    display: inline-flex;
    flex: none;
    align-items: center;
    justify-content: center;
    width: 28px;
    height: 28px;
    color: var(--el-color-primary);
    font-size: 15px;
    background: var(--el-color-primary-light-9);
    border-radius: 7px;
  }

  &__kind {
    padding: 0 7px;
    color: var(--el-text-color-secondary);
    font-size: 11px;
    line-height: 19px;
    background: var(--el-fill-color-light);
    border-radius: 4px;
  }

  &__meta {
    display: flex;
    align-items: center;
    gap: 6px;
    color: var(--el-text-color-secondary);
    font-size: 12px;

    i {
      color: var(--el-border-color);
      font-style: normal;
    }

    b {
      color: var(--el-text-color-primary);
      font-weight: 600;
      font-variant-numeric: tabular-nums;
    }
  }

  /* 类别标签与统计独占一行，避免和标题、按钮抢横向空间导致换行错位 */
  &__meta--full {
    flex-basis: 100%;
    flex-wrap: wrap;
    row-gap: 4px;
  }

  &__cat {
    padding: 0 7px;
    color: var(--el-color-primary);
    font-size: 11px;
    line-height: 18px;
    background: var(--el-color-primary-light-9);
    border-radius: 4px;

    &.is-empty {
      color: var(--el-text-color-secondary);
      background: var(--el-fill-color-light);
    }
  }

  &__sep {
    width: 1px;
    height: 12px;
    background: var(--el-border-color);
  }

  /* 「全库 N 个」：解释口径差，弱化成辅助信息，不跟主统计抢注意力 */
  &__hint {
    color: var(--el-text-color-placeholder);
    cursor: help;
    border-bottom: 1px dashed var(--el-border-color);
  }

  &__actions {
    display: flex;
    align-items: center;
    gap: 2px;
    margin-left: auto;
  }
}

.mm-tabs {
  display: flex;
  flex: 1;
  flex-direction: column;
  min-height: 0;
  padding: 0 16px;
  overflow: hidden;

  :deep(.el-tabs__header) {
    flex: none;
    margin-bottom: 10px;
  }

  :deep(.el-tabs__content) {
    flex: 1;
    min-height: 0;
    overflow: auto;
  }
}

.mm-fields-pane {
  padding-bottom: 16px;
}

.mm-table {
  margin-bottom: 12px;
  overflow: hidden;
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 6px;

  &__head {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 9px 12px;
    background: var(--el-fill-color-lighter);
    border-bottom: 1px solid var(--el-border-color-lighter);

    /* 多表时表头可点击折叠：给指针与 hover 反馈；单表保持原样（不可点） */
    &.is-collapsible {
      cursor: pointer;

      &:hover {
        background: var(--el-fill-color-light);
      }
    }
  }

  /* 折叠箭头：多表时才渲染，弱化处理，别跟表类型图标抢注意力 */
  &__toggle {
    flex: none;
    color: var(--el-text-color-secondary);
    font-size: 13px;
    transition: transform 0.16s;
  }

  &__ic {
    flex: none;
    color: var(--el-color-primary);
    font-size: 14px;
  }

  /* 表序号：多表时才渲染，弱化处理，别跟表名抢注意力 */
  &__ord {
    flex: none;
    padding: 0 6px;
    color: var(--el-color-primary);
    font-size: 11px;
    line-height: 18px;
    background: var(--el-color-primary-light-9);
    border: 1px solid var(--el-color-primary-light-7);
    border-radius: 9px;
  }

  &__name {
    color: var(--el-text-color-primary);
    font-size: 13px;
    font-weight: 600;
  }

  &__key {
    color: var(--el-text-color-secondary);
    font-family: 'SF Mono', Menlo, Consolas, monospace;
    font-size: 11px;
  }

  /* 表类型 chip：图标 + 文字，颜色由行内 style 注入，与图标同色 */
  &__type {
    display: inline-flex;
    flex-shrink: 0;
    gap: 3px;
    align-items: center;
    padding: 0 6px;
    font-size: 11px;
    line-height: 18px;
    border: 1px solid currentColor;
    border-radius: 9px;
    opacity: 0.85;
  }

  &__count {
    padding: 0 6px;
    color: var(--el-text-color-secondary);
    font-size: 11px;
    line-height: 18px;
    background: var(--el-fill-color);
    border-radius: 9px;
  }
}

/* ---------- 字段表（列集合对齐原详情弹窗） ---------- */
/* 只有横向滚动容器：窄窗口下宁可横向滚，也不要把每列压成省略号 */
.mm-ftable-wrap {
  overflow-x: auto;
}

.mm-ftable {
  width: 100%;
  /* 固定列宽之和 ≈ 770，留 120 给描述/备注；1440 屏的详情区（≈1013）刚好不出横向滚动 */
  min-width: 1010px;
  border-spacing: 0;
  /* 固定布局：内容长短不一也不会把「长度」这类窄列挤成两行 */
  table-layout: fixed;

  th {
    padding: 7px 10px;
    color: var(--el-text-color-secondary);
    font-size: 11.5px;
    font-weight: 500;
    text-align: left;
    white-space: nowrap;
    background: var(--el-fill-color-lighter);
    border-bottom: 1px solid var(--el-border-color-lighter);
  }

  td {
    padding: 8px 10px;
    overflow: hidden;
    color: var(--el-text-color-regular);
    font-size: 12.5px;
    line-height: 1.5;
    text-overflow: ellipsis;
    white-space: nowrap;
    border-bottom: 1px solid var(--el-fill-color-lighter);
  }

  tbody tr:last-child td {
    border-bottom: 0;
  }

  tbody tr:hover td {
    background: var(--el-fill-color-lighter);
  }

  .is-center {
    text-align: center;
  }

  /* 列宽：描述 / 备注不给宽度 —— table-layout:fixed 下会平分剩余空间，宽屏自动变宽 */
  .c-idx {
    width: 46px;
  }

  .c-name {
    width: 150px;
  }

  .c-code {
    width: 118px;
  }

  .c-type {
    width: 92px;
  }

  .c-len {
    width: 62px;
  }

  .c-rule {
    width: 108px;
  }

  .c-enum {
    width: 112px;
  }

  .c-def {
    width: 82px;
  }

  &__idx {
    color: var(--el-text-color-placeholder);
    font-variant-numeric: tabular-nums;
  }

  &__code {
    color: var(--el-text-color-secondary);
    font-family: 'SF Mono', Menlo, Consolas, monospace;
  }

  &__dim {
    color: var(--el-text-color-secondary);
    font-variant-numeric: tabular-nums;
  }

  &__type {
    display: inline-flex;
    align-items: center;
    gap: 6px;
  }

  &__ic {
    display: inline-flex;
    flex: none;
    align-items: center;
    justify-content: center;
    width: 20px;
    height: 20px;
    font-family: 'SF Mono', Menlo, Consolas, monospace;
    font-size: 10px;
    font-style: normal;
    font-weight: 600;
    border-radius: 4px;
  }

  /* 枚举值可能三五个：允许换行显示，靠行高撑开而不是省略。
     必须写成 td.xxx —— 上面 `td { white-space: nowrap }` 的特异性比单类高，单写 &__enum 不生效（踩过） */
  td.mm-ftable__enum {
    white-space: normal;
  }

  &__opt {
    display: inline-block;
    margin: 1px 4px 1px 0;
    padding: 0 5px;
    color: var(--el-color-primary);
    font-size: 11px;
    line-height: 17px;
    background: var(--el-color-primary-light-9);
    border-radius: 3px;
  }
}

.mm-pill {
  flex: none;
  padding: 0 5px;
  font-size: 11px;
  line-height: 17px;
  border-radius: 3px;

  &.is-req {
    color: var(--el-color-danger);
    background: var(--el-color-danger-light-9);
  }

  &.is-opt {
    color: var(--el-text-color-secondary);
    background: var(--el-fill-color-light);
  }

  &.is-rep {
    color: var(--el-color-success);
    background: var(--el-color-success-light-9);
  }
}

.mm-grow {
  flex: 1;
}

.mm-desc {
  :deep(.el-descriptions__label) {
    width: 110px;
  }
}

.mm-table-list {
  display: flex;
  flex-direction: column;
  gap: 4px;

  > div {
    display: flex;
    gap: 10px;
  }
}

/* ---------- 卡片网格 ---------- */
.mm-grid-wrap {
  flex: 1;
  min-height: 0;
  padding: 4px 16px 16px;
  overflow: auto;

  /* 空态时垂直居中，避免缩在顶部、下面一大片空白（有卡片时容器仍是普通块级） */
  &:has(> .el-empty) {
    display: flex;
    align-items: center;
    justify-content: center;
  }
}

.mm-grid {
  display: grid;
  width: 100%;
  /* auto-fit：轨道数随卡片数量收缩，2 张卡就各占一半铺满，不会在右侧留出一大片空轨道
     （auto-fill 会先铺满空轨道，卡片少时右半边全空，正是之前「大片空白」的来源） */
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  /* 卡片行不要被容器高度拉伸，否则卡片少时会被拉成很高的大色块 */
  align-content: start;
  gap: 14px;
}

.mm-card {
  display: flex;
  flex-direction: column;
  min-width: 0;
  padding: 14px;
  background: var(--el-bg-color);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 8px;
  cursor: pointer;
  transition:
    border-color 0.16s,
    box-shadow 0.16s,
    transform 0.16s;

  &:hover {
    background: var(--el-bg-color);
    border-color: var(--el-color-primary-light-5);
    box-shadow: 0 6px 18px rgb(31 45 61 / 8%);
    transform: translateY(-1px);
  }

  &__head {
    display: flex;
    gap: 9px;
    align-items: flex-start;
    min-width: 0;
  }

  &__ic {
    display: inline-flex;
    flex: none;
    align-items: center;
    justify-content: center;
    width: 30px;
    height: 30px;
    color: var(--el-color-primary);
    font-size: 15px;
    background: var(--el-color-primary-light-9);
    border-radius: 7px;
  }

  &__titles {
    flex: 1;
    min-width: 0;
  }

  /* 版本号贴在标题行右端：宽卡片时正好吃掉标题右侧的空白，也不用为它单开一行 */
  &__ver {
    flex: none;
    padding: 0 6px;
    color: var(--el-text-color-secondary);
    font-size: 11px;
    line-height: 18px;
    font-variant-numeric: tabular-nums;
    background: var(--el-fill-color-light);
    border-radius: 4px;
  }

  &__title {
    overflow: hidden;
    color: var(--el-text-color-primary);
    font-size: 14px;
    font-weight: 600;
    line-height: 1.35;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  &__key {
    margin-top: 2px;
    overflow: hidden;
    color: var(--el-text-color-placeholder);
    font-family: 'SF Mono', Menlo, Consolas, monospace;
    font-size: 11px;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  &__desc {
    display: -webkit-box;
    min-height: 36px;
    margin: 10px 0 8px;
    overflow: hidden;
    color: var(--el-text-color-secondary);
    font-size: 12px;
    line-height: 1.55;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;

    &.is-empty {
      color: var(--el-text-color-placeholder);
    }
  }

  &__tags {
    display: flex;
    flex-wrap: wrap;
    gap: 4px;
    min-height: 18px;
    margin-bottom: 10px;
  }

  /* 标题里的「范例」标签：与标题同行、略窄，避免把长名挤成省略号 */
  &__tmpl {
    margin-left: 6px;
    vertical-align: middle;
    font-weight: 400;
  }

  &__tag {
    padding: 0 6px;
    color: var(--el-color-primary);
    font-size: 11px;
    line-height: 18px;
    background: var(--el-color-primary-light-9);
    border-radius: 4px;

    &.is-empty {
      color: var(--el-text-color-secondary);
      background: var(--el-fill-color-light);
    }
  }

  /* margin-top:auto 让高矮不一的卡片把底部信息压到同一水平线 */
  &__foot {
    display: flex;
    gap: 5px;
    align-items: center;
    margin-top: auto;
    padding-top: 9px;
    color: var(--el-text-color-secondary);
    font-size: 11.5px;
    border-top: 1px solid var(--el-border-color-lighter);
  }

  &__stat b {
    color: var(--el-text-color-primary);
    font-weight: 600;
    font-variant-numeric: tabular-nums;
  }

  &__dot {
    color: var(--el-border-color);
  }

  &__time {
    color: var(--el-text-color-placeholder);
    font-variant-numeric: tabular-nums;
  }
}

.mm-muted {
  color: var(--el-text-color-placeholder);
}

.mm-empty {
  flex: 1;
}
</style>
