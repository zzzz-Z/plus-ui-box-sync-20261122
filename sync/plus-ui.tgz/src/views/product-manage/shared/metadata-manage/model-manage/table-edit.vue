<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
/**
 * 表信息编辑弹窗的内容体（H-08）：表编码 / 表名称 / 表描述。
 *
 * 草稿模式：不直接改父组件传进来的 table —— 组件内深拷贝一份自己持有，
 * 「取消」整份丢弃；「确定」由 save() 通过 onSubmit 交回调用方按字段写回。
 * H-05 已删除「表类型」下拉，故本弹窗不含该项；tableType 契约默认值由模型提交逻辑保留。
 *
 * 放在弹窗里而不是表体内嵌行的原因：表级字段散在折叠面板里容易被忽略，
 * 集中成弹窗后录入与校验只有一个出口，也与字段编辑弹窗（field-edit.vue）保持一致。
 */
const props = defineProps<{
  /** 表初始值（父组件持有，本组件只读） */
  table: Params;
  /** 校验通过后把表信息交回调用方（由调用方按字段写回原对象） */
  onSubmit?: (table: Params) => void;
}>();

/** 深拷贝：取消时不能连带改到模型里的原表对象 */
const draft = reactive<Params>(JSON.parse(JSON.stringify(props.table ?? {})));

function validate(): string | null {
  const key = String(draft.tableKey ?? '').trim();
  if (!key) return pt('请填写表编码');
  if (/\s/.test(key)) return pt('表编码不能包含空格');
  if (!String(draft.tableName ?? '').trim()) return pt('请填写表名称');
  return null;
}

/**
 * 供 createDialog 调用（先 validate 再 save，按返回值决定是否关闭）。
 * 必须是 async：createDialog 的 submit 对返回值取 .finally，同步对象会被判为 undefined 而不关闭弹窗。
 */
async function save() {
  const error = validate();
  if (error) return { code: -1, message: error };
  props.onSubmit?.(draft);
  return { code: 0, message: pt('表信息已保存，提交模型后生效'), data: draft };
}

defineExpose({ save });
</script>

<template>
  <Form :span="24" :model="draft">
    <el-input
      v-model="draft.tableKey"
      :label="pt('表编码')"
      required
      :placeholder="pt('如 district_base')"
      :tooltip="pt('同模型内唯一，建议用小写英文 + 下划线')"
    />
    <el-input v-model="draft.tableName" :label="pt('表名称')" required :placeholder="pt('请输入模型表名称')" />
    <el-input v-model="draft.description" :label="pt('表描述')" type="textarea" :rows="3" :placeholder="pt('这张表存什么数据')" />
  </Form>
</template>

<style lang="scss" scoped>
:deep(.el-form-item) {
  margin-bottom: 14px;
}
</style>
