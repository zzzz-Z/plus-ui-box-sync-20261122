import { inject, onBeforeUnmount, onMounted, type InjectionKey, type Ref } from 'vue';

/**
 * 左侧「树」列的挂载位（布局 → 业务面板 的注入契约）
 *
 * WHY 需要它：树由业务面板（数据浏览 / 数据查询）自己渲染，数据和交互都在面板内；
 * 但用户要求「树单独成列、高度撑满整个内容区」，而撑满整个内容区意味着树必须跳出
 * 「地图上下分栏」的下半区 —— 所以布局提供一列空的挂载位，面板用 Teleport 把树搬进去，
 * 面板实例与状态留在原地（选中节点、图层联动都不受影响）。
 *
 * 约定：
 *  - `el`：布局那一列的宿主元素。布局始终渲染它（用 v-show 控制显隐），
 *    保证 ref 稳定，Teleport 目标不会在一帧内消失；
 *  - `claimed`：当前是否有面板把树搬进来了。布局据此决定要不要显示「树」这一列与开关 ——
 *    没有树的 tab（数据检查 / 版本管理等）不会凭空多出一列空白；
 *  - `checkedCount`：树上已勾选（上图）的**资源数**。0 表示尚未勾选任何资源，
 *    布局据此把下方详情区整块收起、让地图独占右列（用户 2026-11-06 口径：
 *    「第一次进页面左侧没有勾选资源，下方 table 是空的还占地方，所以隐藏，勾选后再显示」）；
 *  - `owner`：内部占位令牌，解决「切 tab 时新面板先挂载、旧面板后卸载」导致 claimed 被误清成 false。
 *
 * 未注入（如 `src/views/__debug/map-draw-sim.vue` 单独挂 DataQuery）时面板回落为内联渲染，
 * 行为与改造前一致。
 */
export interface TreeHost {
  /** 布局左侧树列的宿主元素 */
  el: Ref<HTMLElement | undefined>;
  /** 当前是否有面板把树搬进来了 */
  claimed: Ref<boolean>;
  /**
   * 树上已勾选（上图）的**资源数**；0 = 尚未勾选任何资源。
   *
   * WHY 用计数而不是布尔：面板侧本来就把「勾选集合展开后的资源节点」缓存成 computed，
   * 直接取长度即可，无需再维护一份 hasChecked 布尔（两份状态必然不同步）。
   * 布局据此在 0 时收起下方详情区 —— 空表占着半屏高度、地图被迫只剩一半，是最明显的浪费。
   */
  checkedCount: Ref<number>;
  /**
   * 详情区当前是否**有可展示的内容**（面板自己判断后回写）。
   *
   * WHY 需要它：checkedCount === 0 收起详情区的动机是「只有一块空表占着半屏」。
   * 但产品线的「数据浏览」右栏是详情 / 资源卡片，进页面就默认选中树第一级、
   * 铺开本产品线全部资源卡片（用户 2026-11-10 口径），此时虽然没勾选任何资源，
   * 详情区里却是有内容的 —— 再按零勾选收起，就等于把刚铺开的卡片藏起来。
   * 所以「收起」的条件是「没勾选 **且** 详情区没内容」，由面板把后者的事实告诉布局。
   */
  hasContent: Ref<boolean>;
  /** 占位令牌：只有持有者才能清除 claimed */
  owner: symbol | null;
  /** 布局侧：树列宽度（px），面板侧只读 */
  width: Ref<number>;
}

export const TREE_HOST_KEY: InjectionKey<TreeHost> = Symbol('product-tree-host');

/**
 * 面板侧接管：注入挂载位并在生命周期里登记 / 释放。
 * 返回 null 表示没有布局上下文（独立挂载场景），调用方应回落为内联渲染。
 */
export function useTreeHost(): TreeHost | null {
  const host = inject(TREE_HOST_KEY, null);
  if (!host) return null;

  const token = Symbol('tree-host-claim');
  onMounted(() => {
    host.owner = token;
    host.claimed.value = true;
    // 认领时清掉上一个面板留下的「详情区有内容」：切 tab 时旧面板常晚于新面板卸载
    // （见 owner 注释的同一时序），它的 onBeforeUnmount 会因 owner 已变而提前返回，
    // 于是残留的 true 会让新面板（如元数据编辑，零勾选本该收起空表）凭空撑住详情区。
    // 新面板自己的 watch 会在内容就绪后重新写入，重置不会丢信息。
    host.hasContent.value = false;
  });
  onBeforeUnmount(() => {
    // 新面板已经挂载并接管时不要清掉，否则切 tab 后树列会整段消失
    if (host.owner !== token) return;
    host.owner = null;
    host.claimed.value = false;
    // 勾选计数随面板一起释放：否则切到无树 tab（数据检查 / 版本管理）后，
    // 布局仍以为「有勾选资源」，下方详情区会凭空保留一块空白
    host.checkedCount.value = 0;
    host.hasContent.value = false;
  });

  return host;
}
