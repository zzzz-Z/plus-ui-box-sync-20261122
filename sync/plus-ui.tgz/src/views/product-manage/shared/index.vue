<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
import { useMap } from '@/views/product-manage/shared/map/use-map';
import { hasQueryResult } from '@/views/product-manage/shared/map/query/state';
import DataBrowse from './data-browse/index.vue';
import DataCheck from './data-check/index.vue';
import DataIntoStore from './data-into-store/index.vue';
import DataPermission from './data-permission/index.vue';
import DataQuery from './data-query/index.vue';
import DataReport from './data-report/index.vue';
import Backup from './backup/index.vue';
import VersionManage from './version-manage/index.vue';
import DataUpdate from './data-update/index.vue';
import Map from '@/views/product-manage/shared/map/index.vue';
import { useProductRecords } from './store.js';
import FileExtract from './data-extraction/index.vue';
import { TREE_HOST_KEY, type TreeHost } from './tree-host';
import { MAP_VISIBILITY_KEY, type MapVisibility } from './map-visibility';
import { registerRecordDetailHost } from './record-detail-host';
import RecordDetailPanel from './record-detail-panel.vue';
import { CaretBottom, CaretTop } from '@element-plus/icons-vue';
import { clearSelection } from './metacheck-selection';
import i18n from '@/lang/index';
import { translateRouteTitle } from '@/utils/i18n';

/** 展示层翻译：tab value/pageType 内部仍用中文原文，只在渲染时翻译，避免破坏子页 v-if 契约 */
const t = (key: string) => i18n.global.t(key);

/**
 * 产品管理 · 布局（初级产品 / 产品成果 / 元数据管理共用）
 *
 * 承载：tab 组、三块区域（树 / 详情列表 / 地图）的独立显隐、地图与业务面板容器。
 * 差异通过 props 与插槽：
 *  - context：'primary' | 'result' 决定内置菜单清单与面板组装；未传时走 #default 插槽（如元数据管理）；
 *  - menuTypes / spatialModules：调用方覆盖菜单与空间模块清单；
 *  - clearLayersOnTabChange：切 tab 是否清地图图层（默认 true）；
 *  - ready 事件：菜单初始化后通知调用方预载数据。
 */
const props = defineProps<{
  menuTypes?: string[];
  spatialModules?: string[];
  context?: 'primary' | 'result';
  clearLayersOnTabChange?: boolean;
}>();

const emit = defineEmits<{ ready: [tabName: string] }>();

const tabName = defineModel<string>();

/**
 * 三块区域的显隐（多选，可全关）：
 *   '3' 树 / '1' 详情列表 / '2' 地图。
 *
 * WHY 保留字符串数组而不是三个布尔：原来是「列表(1) / 地图(2)」的 el-checkbox-group，
 * 对外插槽还以 `:view-mode` 暴露过；沿用同一 model 可让 metadata-manage 这类调用方零改动，
 * 只是多了一个 '3'。
 *
 * WHY 切到非空间 tab 时**不**强行改写取值：地图开关在该 tab 直接不渲染、地图也不显示
 * （showMap 里判 isSpatialModule），用户在地图 tab 上的偏好得以保留 —— 旧实现会把值重置成 ['1']，
 * 导致在「数据检查」点一下再回来，地图就没了。
 *
 * 默认偏好按 tab 分两类（用户 2026-11-13 / 2026-11-18 口径）：
 *  - 产品线详情「数据浏览」与「数据入库 / 数据提取」：树 + 详情，地图默认不显示 ——
 *    数据浏览进来直接铺资源卡片墙（见 data-browse/index.vue 的 detailMode 默认选中第一级），
 *    地图开关照常给，用户想看空间分布时点开「地图」即可；
 *  - 「数据查询 / 数据更新」等其余空间 tab：三块齐全（树 + 地图 + 详情），进来即见空间分布。
 *  「元数据浏览」虽然名字里含「数据浏览」，但它走插槽、不属产品线 detailMode，仍按开地图类处理。
 * 默认值不写死在 defineModel 里，改由 watch(tabName) 在首帧及跨类切换时按当前 tab 落入对应偏好；
 * 用户进入任一 tab 后的手动开关结果都保留，不会被同类 tab 之间的切换覆盖。
 */
const viewModes = defineModel<string[]>('viewModes', { default: () => ['1', '2', '3'] });

/** 默认关地图的 tab：数据入库 / 数据提取 / 数据更新（子串匹配）。地图开关仍可用，开了即显示 */
const NO_MAP_DEFAULT_MODULES = ['数据入库', '数据提取', '数据更新'];
/**
 * 当前 tab 是否属于「默认不显示地图」的一类：
 *  - 产品线「数据浏览」：精确匹配 —— 进来直接铺资源卡片墙（data-browse 的 detailMode 默认选中第一级），
 *    用 === 而非 includes，避免把元数据管理的「元数据浏览」也一起关掉地图（它走插槽，仍默认开地图）；
 *  - 数据入库 / 数据提取 / 数据更新：子串匹配（沿用原口径），这三类都是「左树 + 右业务面板」工作区，
 *    默认只铺左树 + 右详情、不显示地图，与数据入库页布局一致；
 *  - 数据查询等其余空间 tab 不在其中，保持默认三块齐全。
 */
const isNoMapDefaultTab = (name?: string) => !!name && (name === '数据浏览' || NO_MAP_DEFAULT_MODULES.some((m) => name.includes(m)));

/**
 * 数据入库 / 数据提取 / 数据更新页：queryBg 会把两行查询区的底图(two_input.png)误挂到共享 .content
 * 及其后代（如新建表单 .extract-create / .create-panel）上，在 padding / 卡片间隙透出蓝色斜纹。
 * 本 computed 在这几个「左树 + 右详情」tab 为真，给 .content 加局部屏蔽类；
 * 切到其它 tab 自动移除，不影响别的页面。
 */
const isIngestTab = computed(() => tabName.value === '数据入库' || tabName.value === '数据提取' || tabName.value === '数据更新');
/** 按当前 tab 取初始显隐偏好：数据浏览 / 入库 / 提取 / 数据更新默认关地图（树 + 详情），其余默认三块齐全 */
function defaultViewModesFor(name?: string) {
  return isNoMapDefaultTab(name) ? ['1', '3'] : ['1', '2', '3'];
}

const mapStore = useMap();

/** 内容区（全屏目标 + 左右分栏容器） */
const contentRef = ref<HTMLElement>();
/** 右半区（地图 / 详情列表上下分栏的容器） */
const rightRef = ref<HTMLElement>();
/** 左右分栏容器（树宽度的百分比上限据此计算） */
const panesRef = ref<HTMLElement>();
/** 布局根容器：记录详情宿主用它判断当前页是否真正可见（KeepAlive 缓存页会移出 document） */
const rootEl = ref<HTMLElement>();

/**
 * 地图 / 详情列表联动时的上下分栏高度（仅两者同时显示时生效）。
 * 默认各占一半，拖中间的分隔条调整；容器高度变化时由 composable 按比例纠偏。
 */
const {
  dragging: splitDragging,
  topStyle: mapPaneStyle,
  startDrag: startSplitDrag
} = useVerticalSplit(rightRef, {
  initialRatio: 0.5,
  minTop: 160,
  minBottom: 180
});

/* --------------------------- 左侧树挂载位 --------------------------- */
const TREE_MIN = 200;
const TREE_MAX = 520;
const treeWidth = ref(320);
const treeHostEl = ref<HTMLElement>();
const treeClaimed = ref(false);
/**
 * 树上已勾选（上图）的资源数，由面板（数据浏览 / 元数据编辑）实时回写。
 * 0 = 尚未勾选任何资源，此时下方详情区收起、地图独占右列；
 * 勾选后自动展开为「上地图 / 下列表」的默认上下分栏。
 */
const treeCheckedCount = ref(0);
/**
 * 详情区当前是否有可展示的内容（面板回写，见 tree-host.ts 的 hasContent）。
 * 与 treeCheckedCount 配合：只有「没勾选 **且** 详情区空」才自动收起详情区。
 */
const treeHasContent = ref(false);

/**
 * 注入给业务面板（数据浏览 / 数据查询）的树挂载位。
 * 面板用 Teleport 把树搬进左边这一列，面板自身实例与状态留在右半区 —— 见 tree-host.ts 的 WHY。
 */
const treeHost: TreeHost = {
  el: treeHostEl,
  claimed: treeClaimed,
  checkedCount: treeCheckedCount,
  hasContent: treeHasContent,
  owner: null,
  width: treeWidth
};
provide(TREE_HOST_KEY, treeHost);

/**
 * 注入给业务面板的地图显隐控制器。
 * ensureMapVisible 只在 viewModes 未含 '2' 时补上，已显示时不动（保留用户的开关偏好）；
 * 写入口与顶部开关共用同一份 viewModes，不会出现两处状态漂移。
 */
const mapVisibility: MapVisibility = {
  ensureMapVisible() {
    if (!viewModes.value.includes('2')) viewModes.value = [...viewModes.value, '2'];
  }
};
provide(MAP_VISIBILITY_KEY, mapVisibility);

/* --------------------------- 右侧记录详情占位列 --------------------------- */
/**
 * 右侧「记录详情」列：属性表（元数据浏览 / 元数据编辑）与地图要素点击三个入口
 * 都调 showRecordDetail 把内容写进本布局注册的宿主，面板在这里集中渲染一份。
 *
 * WHY 只在打开详情时显示：详情是「点一行看一行」的辅助视图，没有打开时若常驻一列，
 * 地图与列表会被凭空挤窄。宿主契约与令牌口径见 record-detail-host.ts。
 */
// 传入布局根容器作为可见性判据：KeepAlive 缓存页 DOM 会从 document 移走，
// 不参与「当前宿主」裁决，点图层时详情才会写进眼前这一份布局
const recordDetailHost = registerRecordDetailHost(() => !!rootEl.value?.isConnected && rootEl.value.getClientRects().length > 0);
const recordDetailContent = recordDetailHost.content;
/** 每次打开都重挂面板：AttributeRowDialog 的 enrich 只在 onMounted 跑一次，重挂才能补当前内容 */
const recordDetailSeq = ref(0);
watch(recordDetailContent, () => recordDetailSeq.value++);
onBeforeUnmount(recordDetailHost.unregister);

function maxTreeWidth() {
  const total = panesRef.value?.clientWidth ?? 0;
  return total ? Math.max(TREE_MIN, Math.min(TREE_MAX, Math.round(total * 0.5))) : TREE_MAX;
}

let treeDragX = 0;
let treeDragW = 0;
let treePrevCursor = '';
let treePrevUserSelect = '';
/**
 * 树宽度拖动中。拖树同样在改地图容器的宽度，和拖上下分隔条是一个性质的问题：
 * 每帧都会触发地图 ResizeObserver → map.resize() → 重建画布位图并重拉瓦片，
 * 表现为地图闪屏。所以两者共用同一个 pauseResize 闸门（见下面 Map 的 :pause-resize）。
 */
const treeDragging = ref(false);
function startTreeDrag(e: PointerEvent) {
  if (e.pointerType === 'mouse' && e.button !== 0) return;
  treeDragX = e.clientX;
  treeDragW = treeWidth.value;
  treeDragging.value = true;
  // 捕获指针：拖到地图上再松开也能收到 pointerup，否则 treeDragging 会卡在 true、
  // 地图 resize 被永久挂起（表现为拖动结束后地图尺寸再也不跟随容器）。
  (e.currentTarget as HTMLElement | null)?.setPointerCapture?.(e.pointerId);
  treePrevCursor = document.body.style.cursor;
  treePrevUserSelect = document.body.style.userSelect;
  document.body.style.cursor = 'col-resize';
  document.body.style.userSelect = 'none';
  window.addEventListener('pointermove', onTreeDrag);
  window.addEventListener('pointerup', stopTreeDrag);
  window.addEventListener('pointercancel', stopTreeDrag);
}
function onTreeDrag(e: PointerEvent) {
  treeWidth.value = Math.round(Math.min(maxTreeWidth(), Math.max(TREE_MIN, treeDragW + (e.clientX - treeDragX))));
}
function stopTreeDrag() {
  if (!treeDragging.value) return;
  treeDragging.value = false;
  window.removeEventListener('pointermove', onTreeDrag);
  window.removeEventListener('pointerup', stopTreeDrag);
  window.removeEventListener('pointercancel', stopTreeDrag);
  document.body.style.cursor = treePrevCursor;
  document.body.style.userSelect = treePrevUserSelect;
}
/** 窗口变窄时把树宽收回可用范围（只收缩、不主动放宽，避免用户刚拖好的宽度被顶回去） */
function clampTreeWidth() {
  treeWidth.value = Math.round(Math.min(maxTreeWidth(), Math.max(TREE_MIN, treeWidth.value)));
}

/** 初级产品主菜单（10 项，含版本管理、备份恢复） */
const PRIMARY_MENUS = ['数据浏览', '数据查询', '元数据检查', '数据入库', '数据提取', '数据更新', '版本管理', '备份恢复', '权限设置', '数据资产报告'];

/** 产品成果主菜单（8 项，剔除版本管理、备份恢复） */
const RESULT_MENUS = ['数据浏览', '数据查询', '元数据检查', '数据入库', '数据提取', '数据更新', '权限设置', '数据资产报告'];

/** 菜单优先级：props.menuTypes > context 分支 > primary 默认 */
const MENU_TYPES = computed(() => {
  if (props.menuTypes && props.menuTypes.length) return props.menuTypes;
  return props.context === 'result' ? RESULT_MENUS : PRIMARY_MENUS;
});

/** tab 显示文本：中文原文不参与渲染，复用路由标题映射（tab 标签已登记） */
const displayTabLabel = (label: string) => translateRouteTitle(label);

/** 空间模块：props 显式传入优先；否则按 context 走默认（初级含元数据编辑） */
const SPATIAL_MODULES = computed(() => {
  if (props.spatialModules) return props.spatialModules;
  // 用户 2026-11-13 口径：「数据入库」「数据提取」也要能展示地图（只是默认不显示、展示列表），
  // 故纳入空间模块清单 —— mapAvailable=true ⇒ 三开关出现、点「地图」即渲染 Map。
  // 默认关地图由 defaultViewModesFor() 在切到这两类 tab 时落入 viewModes 实现。
  return props.context === 'result'
    ? ['数据浏览', '数据查询', '数据入库', '数据提取', '数据更新']
    : ['数据浏览', '数据查询', '数据入库', '数据提取', '数据更新', '元数据编辑'];
});

const isSpatialModule = computed(() => SPATIAL_MODULES.value.find((name) => tabName.value?.includes(name)));
/** 该 tab 有没有地图可用（决定「地图」开关是否出现） */
const mapAvailable = computed(() => !!isSpatialModule.value);
/** 该 tab 的面板把树搬进左列了才显示「树」开关与左列，没树的 tab 不凭空多一列空白 */
const treeAvailable = computed(() => treeClaimed.value);

/**
 * 顶部开关组（树 / 数据 / 地图）只在有地图的 tab 出现。
 * WHY：开关的意义是「三块区域怎么分配空间」，而空间分配只在地图存在时才成立 ——
 * 没有地图的 tab（元数据抽取 / 检查 / 分析等）右列只有业务面板，树与详情本就该常显，
 * 摆一个「数据」开关反而让人以为可以关掉，关掉后整页空白。
 */
const showPaneSwitches = computed(() => mapAvailable.value);

const showMap = computed(() => mapAvailable.value && viewModes.value.includes('2'));

/**
 * 「有树、但一条资源都没勾」——「数据浏览」详情区该隐藏的根因条件。
 *
 * WHY 单独抽出来：分隔条把手、顶部「列表」开关、详情区显隐三处都要判它，
 * 各写一份表达式迟早漂移。与 viewModes 无关：用户对「列表」开关的偏好是另一回事。
 * 必须带 mapAvailable：没有地图的 tab（元数据抽取 / 检查等）右列只有业务面板，
 * 详情恒显示，不该因为某天给它接了树就被自动收起。
 *
 * 再加 showMap（用户 2026-11-10 口径）：零勾选收起的动机是「地图被空表压成半屏」，
 * 只有地图**真正显示**时才成立。默认关地图时右列本就只有详情区，点了资源详情要能直接看到，
 * 此时不能因为没勾选就把它整块收起 —— 否则「点击资源展示详情」会表现为点了没反应。
 *
 * 还要「详情区确实没内容」（treeHasContent，面板回写）：产品线「数据浏览」进页面就默认选中
 * 树第一级、铺开全部资源卡片（用户 2026-11-10 口径），此时一条都没勾选但右栏有卡片可看，
 * 按零勾选收起会把刚铺开的卡片藏起来。空态才收起，才是「别让空表占半屏」的本意。
 */
const treeNoChecked = computed(() => showMap.value && treeAvailable.value && treeCheckedCount.value === 0 && !treeHasContent.value);

/**
 * 当前是否是「数据查询」类 tab（含元数据管理里的「元数据查询」，后者含前者的子串）。
 * 这类 tab 的详情区是**查询结果列表**，不是「数据浏览」的勾选资源属性表。
 */
const isQueryTab = computed(() => !!tabName.value?.includes('数据查询'));

/**
 * 详情区自动收起的**统一条件**：分隔条把手、顶部「列表」开关、详情区显隐三处共用。
 *
 * 两类 tab 口径不同：
 *  - 数据查询 tab：详情区是查询结果列表，只按「有无查询结果」显隐（用户 2026-11-10 口径
 *    「默认不显示列表，查询到数据的时候才显示列表」）。**不看 treeNoChecked**：数据查询
 *    没有左侧树（资源范围树已移除），查询靠图号 / 产品类别，详情区只认查询结果。
 *  - 数据浏览等其余 tab：详情区是勾选资源的属性表，沿用 treeNoChecked（零勾选收起空表）。
 *
 * 必须带 mapAvailable：没有地图的 tab 右列只有业务面板，详情恒显示，收起会整页空白。
 * WHY 取交集而不改写 viewModes：收起时不抹掉用户对「列表」开关的偏好，
 * 条件解除后列表与分隔条自动回来，无需额外记忆状态。
 */
const detailAutoCollapsed = computed(() => (isQueryTab.value ? mapAvailable.value && !hasQueryResult.value : treeNoChecked.value));

/**
 * 详情列表显隐。
 *
 * 用户 2026-11-06 口径：第一次进页面左侧树还没勾选资源时，下方 table 只有空表却占着半屏高度，
 * 地图被压成一半 —— 零勾选就整块隐藏，勾选资源后再显示。
 * 与 viewModes 的关系是**取交集**（不是替换）：用户手动关掉「列表」开关时依旧不显示；
 * 自动收起时不改写 viewModes，所以条件解除后列表自动回来，无需记忆额外状态。
 * 无地图的 tab detailAutoCollapsed 恒为 false ⇒ 详情恒显示，不受 viewModes 影响 —— 否则关掉「数据」会得到一片空白。
 */
const showDetail = computed(() => (!mapAvailable.value || viewModes.value.includes('1')) && !detailAutoCollapsed.value);
/** 同理：无地图时树只要被面板接管就恒显示 */
const showTree = computed(() => treeAvailable.value && (!mapAvailable.value || viewModes.value.includes('3')));
/** 地图与详情列表同时出现才需要上下分栏与拖拽条 */
const isMapLinked = computed(() => showMap.value && showDetail.value);

/**
 * 地图下方的分隔条是否渲染。
 *
 * 原先是「地图显示时恒渲染」（哪怕列表已收起），因为那是把列表拉回来的唯一入口 ——
 * 用户手动收起列表后仍要能点回来。唯一的例外是自动收起（零勾选 / 查询无结果）：
 * 此时详情区本就没有内容，拉回来只会得到一块空表，所以连分隔条与把手一起不渲染；
 * 条件解除后它会自己回来。判据用 detailAutoCollapsed 本身而不是「viewModes 是否含 '1'」：
 * 用户偏好里本就没有 '1' 时同样不该出现「展开详情列表」把手 —— 点了也不会显示任何东西。
 */
const showHSplit = computed(() => showMap.value && !detailAutoCollapsed.value);

/**
 * 面板显隐统一由顶部开关（viewModes）与右侧「详情」把手（togglePane('1')）写同一份状态，
 * 不额外记一份「收起」布尔。
 * WHY：两个入口各记一份必然不同步 —— 顶部开关关掉、把手还以为自己是展开态，
 * 或者反过来，就会出现「按钮显示收起、面板其实已经没了」的错位。
 */
function togglePane(mode: '1' | '2' | '3') {
  const set = new Set(viewModes.value);
  if (set.has(mode)) set.delete(mode);
  else set.add(mode);
  viewModes.value = [...set];
}

/**
 * 上下分隔条的拖动只在「地图 + 详情」同时显示时有意义（两侧才有东西可分配）。
 * 单独一条分隔线时它只是收起按钮的落点，拖起来会拿错比例，所以在这里拦掉。
 */
function onHSplitDown(e: PointerEvent) {
  if (!isMapLinked.value) return;
  startSplitDrag(e);
}

/** 左右分隔条同理：树收起后没有可拖动的一侧 */
function onVSplitDown(e: PointerEvent) {
  if (!showTree.value) return;
  startTreeDrag(e);
}

/**
 * tab 切换：清空上一 tab 的地图图层 + 按目标 tab 落入默认显隐偏好。
 * WHY 业务面板通过 useMap().renderLayers 注册的图层挂在单例上，组件卸载不会自动清理。
 *
 * WHY 只在「默认关地图」与「默认开地图」两类之间跨越时才改写 viewModes（用 lastNoMapDefault 记住
 * 上一个 tab 的类别，而非每次切换都重置）：用户在这一类里手动开/关过地图或列表，切到同类另一个 tab
 * 时不该被抹掉；但从「数据浏览」切到「数据入库」必须落回「只展示列表」，否则入库页会带着上一页
 * 的地图偏好直接铺开地图，违背「默认不显示地图」；反向切回来也要恢复默认三块齐全。
 * immediate:true 让首帧（onMounted 设 tabName 之前/之后都能覆盖）即拥有正确默认值。
 */
let lastNoMapDefault: boolean | null = null;
watch(
  tabName,
  (name, oldName) => {
    if (props.clearLayersOnTabChange ?? true) mapStore.clearRenderLayers();
    // 检查页「去入库」写入的检查绑定属于本次入库意图；用户切到别的模块即视为放弃，
    // 清掉避免下次再进「数据入库」时回显一份早已过期的检查单（用户 2026-11-20 口径）。
    // 只在「离开数据入库」时清；检查→入库那次是「切进」入库，不能清。
    if (oldName?.includes('数据入库') && !name?.includes('数据入库')) clearSelection();
    // 切 tab 一并关掉「记录详情」列：详情属于上一个 tab 的行 / 地图要素上下文，
    // 图层与面板都已换新，留着旧详情会误导（用户 2026-11-17 口径「切换顶部 tab 需要关闭详情」）
    recordDetailHost.close();
    const noMapDefault = isNoMapDefaultTab(name);
    if (lastNoMapDefault === null || lastNoMapDefault !== noMapDefault) {
      viewModes.value = defaultViewModesFor(name);
    }
    lastNoMapDefault = noMapDefault;
  },
  { immediate: true }
);

onMounted(() => {
  tabName.value = MENU_TYPES.value[0];
  emit('ready', MENU_TYPES.value[0]);
  // context 语境（primary/result）下预载记录；插槽场景（如元数据管理）自行处理
  if (props.context) useProductRecords().load();
  clampTreeWidth();
  window.addEventListener('resize', clampTreeWidth);
});

onBeforeUnmount(() => {
  stopTreeDrag();
  window.removeEventListener('resize', clampTreeWidth);
  // 切左侧菜单路由导致本布局卸载，同样结束本次入库意图，清掉检查→入库的临时缓存
  clearSelection();
});

/**
 * 从「元数据检查」跳到「数据入库」。
 *
 * WHY 由布局承接而不是子页直接写 tabName：tab 是 `defineModel<string>` 的单一数据源，
 * 子页自己改会绕过 `watch(tabName)` 的清图层副作用，且两边各持一份值必然不同步。
 * 选中值必须精确等于菜单项原文（`MENU_TYPES` 里是「数据入库」），否则 radio 无高亮。
 */
function goIngest() {
  tabName.value = '数据入库';
}

function testName(name: string) {
  return tabName.value?.includes(name);
}
</script>

<template>
  <div ref="rootEl" class="product-manage-layout h-100% flex flex-col">
    <div class="header">
      <div class="flex items-center">
        <el-radio-group v-model="tabName">
          <el-radio-button v-for="item in MENU_TYPES" :key="item" :value="item">
            {{ displayTabLabel(item) }}
          </el-radio-button>
        </el-radio-group>
      </div>
      <!-- 右侧控件组：ml-auto 靠右；三块区域各自独立开关，可全部关闭。
           只在有地图的 tab 出现 —— 没有地图时右列只有业务面板，开关没有可分配的空间可言。
           工具条不再提供「收起」：tab 组与开关常显，避免藏掉入口后用户找不到（用户 2026-11-13 口径） -->
      <div class="flex items-center gap-2 ml-auto">
        <el-checkbox-group v-if="showPaneSwitches" v-model="viewModes" class="pane-switches">
          <el-checkbox-button v-if="treeAvailable" value="3"> {{ t('route.paneTree') }} </el-checkbox-button>
          <!-- 自动收起时（零勾选 / 查询无结果）「列表」禁用：此刻详情区里没有内容，
               点它只会把 '1' 从偏好里抹掉，导致条件解除后列表不再回来。有结果后自动恢复可点 -->
          <el-checkbox-button value="1" :disabled="detailAutoCollapsed"> {{ t('route.paneList') }} </el-checkbox-button>
          <el-checkbox-button value="2"> {{ t('route.paneMap') }} </el-checkbox-button>
        </el-checkbox-group>
      </div>
    </div>
    <div ref="contentRef" class="content" :class="{ 'content--no-query-bg': isIngestTab }">
      <div ref="panesRef" class="panes">
        <!-- 左：树（内容由业务面板 Teleport 搬进来；宿主常驻，仅切换显隐，保证目标元素稳定） -->
        <div v-show="showTree" ref="treeHostEl" class="pane-tree" :style="{ width: `${treeWidth}px` }" />
        <!-- 树 / 右侧之间的分隔条：只负责拖动调宽。
             树的显隐统一走顶部「树」开关，这里不再挂收起/展开把手 —— 两个入口各记一份状态
             容易错位，且把手会压在树卡片描边上显得多余。树收起时整条缝一起消失，不留空档 -->
        <div v-if="treeAvailable && showTree" class="v-split" :title="t('common.dragTreeWidth')" @pointerdown.prevent="onVSplitDown" />
        <!-- 右：上地图 / 下详情列表 -->
        <div ref="rightRef" class="pane-right">
          <!-- fullscreen-container：全屏目标用「树 + 地图 + 分隔条 + 表格」的整个内容区，
               而不是地图自身 —— 否则一进全屏表格就被裁掉（requestFullscreen 只绘制全屏元素的子树） -->
          <Map
            v-if="showMap"
            :tab-name="tabName"
            :fullscreen-container="contentRef"
            :pause-resize="splitDragging || treeDragging"
            :style="isMapLinked ? mapPaneStyle : undefined"
          />
          <!-- 地图 / 详情之间的分隔条：拖动改高度，右侧按钮收起 / 展开详情列表。
               只在**地图真正显示时**才出现 —— 它既是地图的下边界，也是「在地图与列表之间分配高度」
               的唯一入口；地图关掉后列表独占右列，既没有可分配的高度，那个把手也就只剩一个
               能把整页收成空白的副作用，没必要留。
               地图显示时这条线照常渲染（哪怕用户手动收起列表），按钮才有地方停、也才能把列表拉回来；
               唯一不渲染的场景是「零勾选自动收起」（showHSplit）：此时详情区本来就不该出现，
               能把它拉回来的把手会让用户拉回一块空表 —— 勾选资源后它会自己回来 -->
          <div
            v-if="showHSplit"
            class="h-split"
            :class="{ 'is-dragging': splitDragging, 'is-linked': isMapLinked, 'is-collapsed': !showDetail }"
            :title="isMapLinked ? t('common.dragListHeight') : undefined"
            @pointerdown="onHSplitDown"
          >
            <span v-if="isMapLinked" class="h-split__grip" />
            <button
              type="button"
              class="pane-toggle pane-toggle--detail"
              :title="showDetail ? t('common.collapseDetail') : t('common.expandDetail')"
              @pointerdown.stop
              @click="togglePane('1')"
            >
              <el-icon>
                <CaretBottom v-if="showDetail" />
                <CaretTop v-else />
              </el-icon>
            </button>
          </div>
          <!-- 用 v-show 而非 v-if：面板是树的提供方（DataBrowse/DataQuery 把树 Teleport 到左列），
               卸载会让「树」开关跟着消失、且丢失选中/滚动等状态；隐藏时保持挂载更稳 -->
          <div v-show="showDetail" class="pane-detail">
            <template v-if="props.context">
              <!-- 产品线（context 分支）一律走详情组件：detailMode=true → 右侧 DetailPage；
                   元数据管理（shared/metadata-manage）不进此分支、也不传 detail-mode → 保持列表 -->
              <DataBrowse v-if="testName('数据浏览')" :detail-mode="true" />
              <!-- map-visible：有地图时数据查询的列表搜索栏让位给地图上的查询面板 -->
              <DataQuery v-if="testName('数据查询')" :map-visible="showMap" :detail-mode="true" />
              <!-- 检查页行内「去入库」：只发事件，由本组件改 tabName（单一数据源） -->
              <DataCheck v-if="testName('数据检查')" @go-ingest="goIngest" />
              <DataIntoStore v-if="testName('数据入库')" />
              <FileExtract v-if="testName('数据提取')" />
              <DataUpdate v-if="testName('数据更新')" />
              <DataPermission v-if="testName('权限设置')" />
              <DataReport v-if="testName('数据资产报告')" />
              <VersionManage v-if="testName('版本管理')" />
              <Backup v-if="testName('备份恢复')" />
            </template>
            <slot v-else :page-type="tabName" :showMap="showMap" :view-mode="viewModes" />
          </div>
          <!-- 三块都关掉时给个空态，避免整片空白让人以为页面挂了 -->
          <el-empty v-if="!showMap && !showDetail" class="panes-empty" :description="t('common.panesHidden')" />
        </div>
        <!-- 右：记录详情（属性表与地图通道写入宿主的统一内容；真实占位列，打开时把地图与列表挤向中心） -->
        <div v-if="recordDetailContent" class="pane-record">
          <RecordDetailPanel :key="recordDetailSeq" :content="recordDetailContent" @close="recordDetailHost.close()" />
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped lang="scss">
.header {
  background: var(--el-bg-color);
  padding: 10px 15px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-shrink: 0;
  flex-wrap: wrap;
  gap: 8px;

  :deep(.el-radio-group) {
    flex-wrap: wrap;
    row-gap: 6px;
  }

  :deep(.el-checkbox-group) {
    flex-shrink: 0;
  }
}

.content {
  /* WHY flex:1 而非 calc(100% - 50px)：header 宽度不足时会折行变高，固定减 50px 与实际高度不符 */
  flex: 1;
  min-height: 0;
  display: flex;
  flex-direction: column;
  padding-top: 5px;
}

/* 数据入库页：queryBg 会把 two_input.png 底图挂到 .content 或其后代（如 .panes），逐个覆盖掉。
   :deep 跨 scoped 边界匹配动态挂载的后代；条件类随 tab 移除，其它页面不受影响。 */
.content.content--no-query-bg,
.content.content--no-query-bg :deep([class*='query-bg']) {
  background-image: none;
}

/* 全屏态：.content 作为全屏元素时，默认是透明底（浏览器画成黑），这里补页面底色；
   原来为避让 header 留的 padding-top 也不需要了。地图 / 表格的上下分栏规则不变，分隔条同样可拖。 */
.content:fullscreen {
  padding: 0;
  background: var(--el-bg-color-page, #f2f3f5);
}

/* 左右分栏：左列树（全高），右列上地图下详情列表 */
.panes {
  flex: 1;
  min-height: 0;
  display: flex;
  align-items: stretch;
}

.pane-tree {
  flex: 0 0 auto;
  min-height: 0;
  height: 100%;
  padding: 0;
  box-sizing: border-box;
  /* 宿主只负责「位置与尺寸」，卡片外观由被 Teleport 进来的树自己给（.db-tree / .tree-panel） */
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

/* 树 / 详情之间的左右缝：11px 热区，常态不画任何线 —— 两侧面板各自已有描边，
   缝里再画一条就是并排第三条线，那正是「分割感」的来源。只有悬停时亮一道主色光，
   提示这里可以拖。 */
.v-split {
  position: relative;
  z-index: 5;
  display: flex;
  flex: 0 0 3px;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  cursor: col-resize;
  touch-action: none;
}
.v-split::after {
  content: '';
  position: absolute;
  top: 0;
  bottom: 0;
  left: 50%;
  width: 2px;
  background: var(--el-color-primary);
  opacity: 0;
  transform: translateX(-50%);
  transition: opacity 0.15s;
}
.v-split:hover::after {
  opacity: 0.35;
}

/* 展开 / 收起把手：做成挂在面板边上的「小舌头」，参考 AntV L7 Editor 右侧属性面板的收起把手。
   做法是给它同一张白底、同一道描边色，只在朝外的三边描边并带圆角，朝面板那一侧不描边、
   并往里压 1px 盖住面板自身的描边 —— 于是它读作「面板自己长出来的一块」，
   而不是浮在缝里的一个按钮，也就没有第三圈轮廓可言。
   WHY 实心三角：L7 用的是 Ant 的 caret（填充三角），比细线箭头更像「这条边上的一枚标记」。 */
.pane-toggle {
  position: absolute;
  z-index: 4;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0;
  color: var(--el-text-color-secondary);
  cursor: pointer;
  background: var(--el-bg-color);
  border: 1px solid var(--el-border-color-lighter);
  transition:
    color 0.16s ease,
    border-color 0.16s ease;
}
.pane-toggle:hover {
  color: var(--el-color-primary);
  border-color: rgb(37 99 235 / 45%);
}
.pane-toggle:focus-visible {
  outline: 2px solid rgb(37 99 235 / 40%);
  outline-offset: 1px;
}
.pane-toggle .el-icon {
  font-size: 12px;
}

/* 收起态：详情列表已经不在，没有边可挂 —— 把手退回缝中间当「点这里展开」的入口，四边补齐描边 */
.h-split.is-collapsed > .pane-toggle {
  color: var(--el-color-primary);
}

/* 右：记录详情列。真实占位 —— 打开时 .pane-right 被 flex 挤窄，地图与列表自然往中心让位，
   而不是悬浮遮挡。宽度比原抽屉收窄一档（用户 2026-11-17 口径「整体详情宽度小一点」）：
   详情是辅助视图，不该吃掉近四分之一屏宽 */
.pane-record {
  flex: 0 0 auto;
  min-width: 0;
  min-height: 0;
  height: 100%;
  padding: 0;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  width: clamp(300px, 22vw, 400px);
}

/* 右列：地图 / 分隔条 / 详情列表 */
.pane-right {
  flex: 1 1 0;
  display: flex;
  flex-direction: column;
  min-width: 0;
  min-height: 0;
}

.pane-detail {
  flex: 1 1 0;
  display: flex;
  flex-direction: column;
  min-width: 0;
  min-height: 0;
  overflow: hidden;
}

/* 面板根元素多带 height:100%，用 flex-basis:0 按剩余空间分配，避免与 100% 相互影响而溢出。
   只在地图也显示时（上下分栏）才需要收缩，独占右列时让面板自己撑满即可。 */
.pane-detail > :deep(*) {
  flex: 1 1 0;
  min-height: 0;
}

/* 地图 / 详情都不显示时的空态；右侧留白让开分隔条上的展开把手（停在 right:10px，宽 48px） */
.panes-empty {
  flex: 1 1 0;
  min-height: 0;
  padding-right: 68px;
}

/* 只有地图、没有详情列表时地图独占右列（联动时高度由内联 style 接管，会覆盖这条） */
.pane-right > .map-panel {
  flex: 1 1 0;
  min-height: 0;
}

/* 地图 / 详情之间的分隔条：热区 12px，视觉只露一条短抓手 */
.h-split {
  position: relative;
  z-index: 5;
  display: flex;
  flex: 0 0 3px;
  align-items: center;
  justify-content: center;
  cursor: row-resize;
  touch-action: none;
  user-select: none;
}

/* 只有一侧时没有可拖的东西，光标与抓手都撤掉，只留右侧那个收起/展开按钮 */
.h-split:not(.is-linked) {
  cursor: default;
}

.h-split__grip {
  width: 44px;
  height: 3px;
  background: var(--el-border-color-darker);
  border-radius: 2px;
  transition: background-color 0.15s;
}

.h-split:hover .h-split__grip,
.h-split.is-dragging .h-split__grip {
  background: var(--el-color-primary);
}

/* 上下缝上的把手：挂在详情卡片顶描边上、朝地图那侧探出，朝卡片一侧不描边 */
.h-split > .pane-toggle--detail {
  bottom: -1px;
  width: 56px;
  height: 18px;
  border-bottom: 0;
  border-radius: 6px 6px 0 0;
}
</style>

<style lang="scss">
/* product-manage 列表页高度修复
   AppMain 用 :has(.pagination-container) 区分列表页与长内容页；
   本模块 ITable 的分页 class 是 .table-pagination，识别不到 ⇒ 页面根被强制
   height:auto ⇒ 表格不撑满剩余高度。此处用作用域类把高度链拉回 100%。
   选择器自带 product-manage-layout 限定，不影响其他页面。 */
.main-container .app-main .app-main__view:has(.product-manage-layout) {
  overflow: hidden;
}
.main-container .app-main .app-main__view:has(.product-manage-layout) > * {
  height: 100%;
  min-height: 0;
  display: flex;
  flex-direction: column;
}
/* AppMain 在 :not(:has(.pagination-container)) 分支还额外把 .el-table 的三层结构重置为
   flex:none / height:auto / display:block。仅拉回页面根容器不够，需在本作用域内一并拉回。 */
.main-container .app-main .app-main__view:has(.product-manage-layout) .el-table {
  flex: 1 1 auto;
  min-height: 0;
}
.main-container .app-main .app-main__view:has(.product-manage-layout) .el-table > .el-table__inner-wrapper {
  height: 100%;
  display: flex;
  flex-direction: column;
}
.main-container .app-main .app-main__view:has(.product-manage-layout) .el-table .el-table__body-wrapper {
  flex: 1 1 auto;
  min-height: 0;
  overflow-y: auto;
}
</style>
