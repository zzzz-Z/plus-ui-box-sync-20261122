<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
/**
 * 来源文件三件套按钮：共享目录 / 共享路径 / 本地上传（图标 + 文字，不用 tooltip）。
 *
 * WHY 收敛为公共组件：数据入库「入库清单」与数据更新「更新清单」顶部工具栏都要这三项，
 * 交互与文案必须与入库保持一致（图标 + 文字直显，用户 2026-11-20 口径），只把点击事件交给宿主实现。
 * 是否显示「清空清单」由宿主通过 showClear 决定（入库页保留，更新页不需要）。
 */
import { Connection, Delete, Folder, Upload } from '@element-plus/icons-vue';

defineOptions({ name: 'SourceToolbarActions' });

withDefaults(defineProps<{ showClear?: boolean; clearDisabled?: boolean }>(), { showClear: false, clearDisabled: false });

const emit = defineEmits<{
  'share-dir': [];
  'share-path': [];
  upload: [];
  clear: [];
}>();
</script>

<template>
  <div class="source-toolbar-actions">
    <el-button :icon="Folder" size="small" @click="emit('share-dir')">{{ pt('共享目录') }}</el-button>
    <el-button :icon="Connection" size="small" @click="emit('share-path')">{{ pt('共享路径') }}</el-button>
    <el-button :icon="Upload" size="small" @click="emit('upload')">{{ pt('本地上传') }}</el-button>
    <el-button v-if="showClear" :icon="Delete" size="small" :disabled="clearDisabled" @click="emit('clear')">{{ pt('清空清单') }}</el-button>
  </div>
</template>

<style scoped lang="scss">
.source-toolbar-actions {
  display: inline-flex;
  align-items: center;
  gap: 8px;

  :deep(.el-button) {
    height: 32px;
    padding: 0 12px;
  }
}
</style>
