<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
import { computed, h, nextTick, onMounted, onUnmounted, ref, watch } from 'vue';
import { ArrowRight, Close, FolderOpened } from '@element-plus/icons-vue';
import BrowseDialog from './browse-dialog.vue';
import SelectedFileTree from './selected-file-tree.vue';
import { createDialog } from '@/composables/create-dialog';
import { listStorageConfigs } from '@/api/product-manage/platform/storage-config';

defineOptions({ name: 'LocationTreeSelect', inheritAttrs: false });

/**
 * 存储位置 / 文件选择器（触发控件 + 子弹窗）。
 *
 * 定位：替代原 el-cascader 懒加载级联，改成像「产品数据查询详情」那样的文件浏览器——
 * 点触发框打开弹窗，逐层浏览已登记共享目录、勾选文件。
 *
 * 子弹窗改由 createDialog 缓存常驻承载（visible:false → 实例只挂载一次、close 只隐藏不销毁）。
 * 为什么：弹窗内容只在首次挂载时定位一次，重新打开不再把「已回填的文件路径」当目录去
 * browseLocation，从根上避开重开时的 4xx 红字；同时省掉重复挂载/销毁与重复请求。
 * 评审口径：共享目录选择统一用弹窗承载（模态、带遮罩），不再用右侧非模态抽屉；
 * 宽度沿用 820px，双栏（左浏览 + 右已选清单）在弹窗 body 内按 100% 高度铺开。
 *
 * 对外契约（见 .dsh/artifacts/metacheck-ingest/03-shared-contract.md §一）：
 *   props { locationUid?, path?, files?, fileNames?, mode?, pickFilter?, placeholder? }
 *   emit  pick:{ locationUid, dataRootPath, files, fileNames, path }
 *
 * 回显（竖向两段式）：
 *   第一段 位置名 —— 已登记共享目录；
 *   第二段 文件清单 —— **逐个竖排**，展示名 + 相对路径，超过约 4 行内滚。
 * 为什么把文件清单收进本组件：此前「入库页」在字段下方自己渲染 ul.picked-files，
 * 与触发框里的「（N 个文件）」重复且两处样式各写一套；检查页则完全没有清单。
 * 现在统一由本组件渲染，调用方只传 files / fileNames，不再各自拼展示。
 *
 * CONSTRAINT 向后兼容：`path` 与 `dataRootPath` 同义（都是「相对登记根的数据根」），
 * 两个都发，旧调用方（data-into-store 旧写法只读 payload.path）不改代码也能继续工作；
 * 新代码一律读 `dataRootPath` + `files`。等所有调用方迁移完再删 `path` 字段。
 *
 * CONSTRAINT inheritAttrs:false —— Form 组件会给插槽节点 cloneVNode 注入
 * filterable / placeholder；filterable 不属于本组件，被拦下不落到根 div，
 * placeholder 已声明为 prop 正常接收（Form 会按 label 自动补「请选择…」）。
 */
interface SharedLocationOption {
  uid: string;
  displayName: string;
}

/** browse-dialog.vue 通过 defineExpose 暴露的方法 */
interface BrowseDialogExpose {
  sync: (locationUid?: string, path?: string, files?: string[], uncPath?: string, targets?: string[]) => Promise<void>;
}

/** 子弹窗回填载荷；与 browse-dialog 的 emit 同形（这里只需用到的字段） */
interface BrowsePickPayload {
  locationUid: string;
  dataRootPath: string;
  path?: string;
  files?: string[];
  fileNames?: string[];
  /** 与 files 等长的目标路径并行数组（树上拖动后的入库路径） */
  targets?: string[];
}

const props = withDefaults(
  defineProps<{
    /** 位置 uid（受控） */
    locationUid?: string;
    /** 数据根（受控）——兼容旧用法：入库页可不传 files 只用 path */
    path?: string;
    /** 已选文件相对路径清单（受控，回显用）；元素相对 `path`（数据根） */
    files?: string[];
    /**
     * 已选文件的展示名（受控，回显用）；与 `files` 同序，仅用于展示、不提交。
     * 不传时按 `files` 的 basename 兜底，保证清单不会因为没有名字而整段消失。
     */
    fileNames?: string[];
    /**
     * 已选文件的目标路径（与 `files` 同序，受控，回显用）。
     *
     * WHY 与 files 分开：files 是「来源里选了哪些文件」，targets 是「入到哪儿」。
     * 用户在树上拖动改变的是后者；不传时视为与 files 相同（绝大多数场景）。
     */
    targets?: string[];
    /**
     * 选择模式：
     * - 'auto'（默认）目录与文件都可回填（当前入库页与检查页统一）
     * - 'file-only' 只能选文件（历史严格口径，现已无调用方）
     */
    mode?: 'auto' | 'file-only';
    /** 过滤口径：'checkable'（历史严格）/ 'selectable'（当前入库页与检查页统一） */
    pickFilter?: 'checkable' | 'selectable';
    /** 占位文案；由 Form 按 label 自动注入，独立使用时走默认值 */
    placeholder?: string;
    /**
     * 数据来源类型（2026-11-12 契约三型）。
     *
     * WHY 由调用方传入而不是本组件自己选：来源是「业务上下文」，检查页/入库页各自
     * 有自己的来源单选（可能还带上传分支）；本组件只负责在给定来源下浏览与回填。
     */
    sourceType?: 'registered_share' | 'direct_shared_path';
    /** 用户输入的 UNC 根（sourceType=direct_shared_path 时必填，浏览时作为 uncPath 传后端） */
    uncPath?: string;
    /**
     * 内嵌模式：把浏览区直接渲染在表单里，而不是打开浮层弹窗。
     *
     * WHY 需要：表单本身已经是弹窗/抽屉时，再叠一层浮层会把上下文（模型、类别、名称）
     * 盖住，用户看不到自己在给哪个任务选文件；内嵌让「选文件」与其它字段同屏可见。
     * 默认 false（保持既有调用方行为不变）。
     */
    inline?: boolean;
    /**
     * 实时模式：**不渲染触发框**，浏览区常显且勾选即回填（隐含 inline）。
     *
     * WHY 需要：宿主把这一项当作「一块可交互的区域」而不是「一个待打开的输入框」时，
     * 触发框与浏览区底部的「取消 / 选择内容」会形成三道无意义的确认（点框展开 → 点勾选 →
     * 点选择内容），而用户看得到的树和已选清单已经表达了全部状态。
     * 打开后 live 会把 pick 事件在每次勾选 / 移除时实时发出，宿主表单立刻拿到值。
     */
    live?: boolean;
    /**
     * 纯下拉树模式：保留触发框（点开才展开），展开后只有一棵目录树，
     * 不渲染右侧「已选内容」栏，也不在触发框里复述清单 —— 勾选即实时回填宿主。
     *
     * WHY 需要（入库页 2026-11-12 改造）：来源下沉到 files 每条后，一个入库任务可以同时
     * 混排共享目录 / UNC / 本地上传三种来源，权威清单只剩宿主表单里的「入库清单」一份。
     * 若这里再显示一份已选内容，用户会看到两个都能拖能删的清单，无法判断哪个是提交依据。
     * 所以本模式把树退化成纯「添加器」：勾选写进宿主清单，撤销也在宿主清单里做。
     */
    treeOnly?: boolean;
  }>(),
  {
    mode: 'auto',
    pickFilter: 'selectable',
    files: () => [],
    fileNames: () => [],
    targets: () => [],
    sourceType: 'registered_share',
    uncPath: '',
    inline: false,
    live: false,
    treeOnly: false
  }
);

const emit = defineEmits<{
  /**
   * 回填。
   *
   * - `dataRootPath`：本次数据根（相对登记根；空串=登记根），提交给检查/入库的 dataRootPath；
   * - `files`：选中文件的相对路径（相对 dataRootPath，来自 entry.relativePath），选目录时为空数组；
   * - `fileNames`：仅展示，不提交；
   * - `targets`：与 files 等长的入库目标路径并行数组（树拖动后可能不同），缺省即同 files；
   * - `path`：dataRootPath 的旧字段同义副本，只为未迁移的调用方保留。
   */
  pick: [payload: { locationUid: string; dataRootPath: string; files: string[]; fileNames: string[]; path: string; targets?: string[] }];
}>();

const locations = ref<SharedLocationOption[]>([]);
/** createDialog 缓存实例；懒创建，首次点击触发框时才建 */
let fileDialog: ReturnType<typeof createDialog> | null = null;

/** 反查位置显示名：仅用于触发框回显，列表很小、只在挂载时拉一次 */
onMounted(async () => {
  try {
    const res = await listStorageConfigs({ kind: 'shared_directory' });
    locations.value = ((res?.data?.items ?? []) as unknown as SharedLocationOption[]).map((l) => ({
      uid: l.uid,
      displayName: l.displayName || l.uid
    }));
  } catch {
    locations.value = [];
  }
});

const locationName = computed(() => locations.value.find((l) => l.uid === props.locationUid)?.displayName || props.locationUid || '');

/** 已选清单是否展开（默认折叠：表单里这一格不该随文件数线性变高） */
const filesExpanded = ref(false);

const hasValue = computed(() => !!props.locationUid);

/** 有效文件路径清单（去掉空串，保持提交顺序） */
const fileList = computed(() => (props.files || []).filter(Boolean));

/**
 * 路径是否指向文件夹。
 *
 * WHY 用末段有无扩展名判定：`files` 只是相对路径字符串，契约不带类型标记；
 * 而入库口径下文件夹也可以被勾选提交（勾文件夹=选中整个目录），
 * 回显时必须区分「3 个文件」与「3 个文件夹」，否则用户会误判自己选了什么。
 * 目录名带点的极端情况（如 `v1.2`）会把目录误判成文件，只影响这行统计文案，不影响提交值。
 */
function isDirPath(p: string): boolean {
  const leaf = p.split(/[\\/]/).pop() || p;
  return leaf.lastIndexOf('.') <= 0;
}

/** 已选条目按类型拆分：文件夹数与文件数 */
const dirCount = computed(() => fileList.value.filter(isDirPath).length);
const plainFileCount = computed(() => fileList.value.length - dirCount.value);

/** 已选总数（fileNames 可能比 files 多，取较大值，避免清单与统计不一致） */
const fileCount = computed(() => Math.max(fileList.value.length, (props.fileNames || []).filter(Boolean).length));

/** 数量文案：全文件「N 个文件」/ 全目录「N 个文件夹」/ 混合「X 文件 + Y 文件夹」 */
const countText = computed(() => {
  const d = dirCount.value;
  const f = plainFileCount.value;
  if (!d) return `${fileCount.value} 个文件`;
  if (!f) return `${Math.max(d, fileCount.value)} 个文件夹`;
  return `${f} 文件 + ${d} 文件夹`;
});

/**
 * 回显用的文件名清单。
 *
 * WHY 不直接用 props.fileNames：检查页早期回填、以及「只选文件未带名字」的旧数据都可能
 * 让 fileNames 缺失；此时按 files 的 basename 兜底（兼容 `\` 与 `/` 两种分隔符），
 * 否则用户明明选了 3 个文件、清单却整段空白，会误以为没选上。
 */
const displayFileNames = computed(() => {
  const names = (props.fileNames || []).filter(Boolean);
  if (names.length) return names;
  return fileList.value.map((p) => p.split(/[\\/]/).pop() || p);
});

/** 整框的悬浮提示（长路径被省略号截断时用） */
const summaryText = computed(() => {
  if (!hasValue.value) return '';
  const tail = fileCount.value ? `（${countText.value}）` : '';
  return `${locationName.value}${tail}`;
});

/**
 * 触发框已选清单的目标路径覆盖表（下标 → 入库路径）。
 *
 * WHY 需要本地覆盖而不是直接依赖 props.targets：触发框是**受控**回显，
 * 但树上的拖动必须立刻有视觉反馈；等宿主回写 props 再更新会有一帧跳变，
 * 宿主若不接 targets 则拖动完全没反应。这里先本地生效并 emit，
 * props.files / props.targets 一变（含宿主回写）就清空覆盖，避免旧覆盖串到新数据。
 */
const targetOverrides = ref<Record<number, string>>({});

watch(
  [() => props.files, () => props.targets],
  () => {
    targetOverrides.value = {};
  },
  { deep: true }
);

/** 触发框清单的行数据：与入库清单同一棵树的输入 */
const treeRows = computed(() => {
  const list = fileList.value;
  const names = displayFileNames.value;
  const targets = props.targets || [];
  return list.map((p, i) => ({
    id: `${p}#${i}`,
    sourcePath: p,
    targetPath: targetOverrides.value[i] || targets[i] || p,
    kind: isDirPath(p) ? ('directory' as const) : ('file' as const)
  }));
});

/** 当前应提交的目标路径数组（与 files 同序，缺省即 files 自身） */
function currentTargets(): string[] {
  const targets = props.targets || [];
  return fileList.value.map((p, i) => targetOverrides.value[i] || targets[i] || p);
}

/** 用「除目标路径外全部沿用当前值」的方式整体回填，避免局部拼装漏字段 */
function emitCurrent(targets: string[]) {
  emit('pick', {
    locationUid: props.locationUid || '',
    dataRootPath: props.path || '',
    files: fileList.value.slice(),
    fileNames: displayFileNames.value.slice(),
    path: props.path || '',
    targets
  });
}

/** 树上拖动：只改目标路径，不动来源文件清单 */
function onTreeMove(payload: { id: string; targetPath: string }) {
  const index = fileList.value.findIndex((p, i) => `${p}#${i}` === payload.id);
  if (index < 0) return;
  targetOverrides.value = { ...targetOverrides.value, [index]: payload.targetPath };
  emitCurrent(currentTargets());
}

/** 树上删除：从已选文件里移除该条，位置与数据根保持不动 */
function onTreeRemove(id: string) {
  const index = fileList.value.findIndex((p, i) => `${p}#${i}` === id);
  if (index < 0) return;
  const files = fileList.value.slice();
  const names = displayFileNames.value.slice();
  const targets = currentTargets();
  files.splice(index, 1);
  names.splice(index, 1);
  targets.splice(index, 1);
  targetOverrides.value = {};
  // 全删空时一并清位置，避免「有位置无文件」的半成品状态被保存校验当成已选
  emit('pick', {
    locationUid: files.length ? props.locationUid || '' : '',
    dataRootPath: files.length ? props.path || '' : '',
    files,
    fileNames: names,
    path: files.length ? props.path || '' : '',
    targets
  });
}

/** 树上箭头：把首个已选项移进该目录 */
function onTreeMoveInto(dirPath: string) {
  const row = treeRows.value[0];
  if (!row) return;
  const name =
    String(row.targetPath || row.sourcePath)
      .split('/')
      .filter(Boolean)
      .pop() || '';
  const next = dirPath ? dirPath + '/' + name : name;
  if (next !== row.targetPath) onTreeMove({ id: row.id, targetPath: next });
}

/**
 * 懒创建缓存弹窗：visible:false 让它「先不打开、留着复用」，之后一律用 open() 再次显示。
 *
 * 评审口径：共享目录选择统一用弹窗承载（模态 + 遮罩 + 锁滚动），不再用右侧非模态抽屉，
 * 因此不再有 modal=false / modal-penetrable 这类抽屉专属配置。
 *
 * CONSTRAINT 调用签名按 createDialog 而非照搬 createDrawer：弹窗宽度用 width（抽屉是 size），
 * 其余 visible:false 缓存、footer:false、bodyStyle、render 与返回 API（open/close/destroy/contentRef）
 * 两者一致。bodyStyle 落到 .el-dialog__body，改成 flex 列让 BrowseDialog 的 height:100% 铺满，
 * 滚动交给内部左右两栏各自处理。
 * CONSTRAINT footer:false —— createDialog 不渲染底部，改由 BrowseDialog 在 template 内自管按钮
 * （与 createDrawer 时期同一范式，BrowseDialog 无需改动按钮逻辑）。
 */
function ensureDialog() {
  if (fileDialog) return fileDialog;
  fileDialog = createDialog({
    title: pt('选择元数据位置'),
    width: '820px',
    visible: false,
    footer: false,
    bodyStyle: { padding: '12px 16px', display: 'flex', flexDirection: 'column', overflow: 'hidden' },
    render: () =>
      h(BrowseDialog, {
        locationUid: props.locationUid,
        path: props.path,
        files: props.files,
        pickFilter: props.pickFilter,
        mode: props.mode,
        sourceType: props.sourceType,
        uncPath: props.uncPath,
        treeOnly: props.treeOnly,
        onPick,
        onCancel: () => fileDialog?.close()
      })
  });
  return fileDialog;
}

/**
 * 打开（或再次打开）：先按当前表单值同步一次定位，再显示；重开且值未变时零请求。
 * 首次打开时内容组件尚未挂载（EP 在 modelValue=false 时不渲染 default slot），
 * contentRef 为空、sync 为 no-op，定位由 BrowseDialog 的 onMounted 用 props 初值完成；
 * 之后内容常驻，sync 才会按需按新值重新定位。
 */
async function openDialog() {
  // live 模式浏览区常显，触发框本身不渲染 —— 这里只可能被键盘/其它调用方触发，直接返回
  if (props.live) return;
  // 内嵌模式：不打开浮层，直接展开下方内嵌浏览区（状态由 inlineOpen 控制）
  if (props.inline || props.treeOnly) {
    inlineOpen.value = true;
    await nextTick();
    await inlineRef.value?.sync(props.locationUid, props.path, props.files, props.uncPath, props.targets);
    return;
  }
  const dialog = ensureDialog();
  await (dialog.contentRef.value as BrowseDialogExpose | undefined)?.sync(props.locationUid, props.path, props.files, props.uncPath, props.targets);
  dialog.open();
}

/**
 * 是否走内嵌浏览（inline / live / treeOnly 都算：三者都不叠浮层）。
 *   - live：常显 + 无触发框 + 勾选即回填；
 *   - inline：点触发框展开，选出结果后收起；
 *   - treeOnly：触发框常显，点开是**只有树**的浏览区，勾选即回填、且不收起。
 */
const isInlineMode = computed(() => props.inline || props.live || props.treeOnly);

/** 内嵌模式：浏览区是否展开（点触发框展开；回填后自动收起，把空间还给表单） */
const inlineOpen = ref(props.live);
/** 内嵌 BrowseDialog 实例（用于 sync 定位） */
const inlineRef = ref<BrowseDialogExpose | null>(null);

/** 清除：位置、数据根与文件一起清空，避免残留 uid 让保存校验误判为已选 */
function clearPick() {
  emit('pick', { locationUid: '', dataRootPath: '', files: [], fileNames: [], path: '' });
}

/** 选中后回填并关闭浮层弹窗 / 收起内嵌浏览区（缓存模式下只隐藏，状态留给下次打开） */
function onPick(payload: BrowsePickPayload) {
  const dataRootPath = payload.dataRootPath ?? payload.path ?? '';
  emit('pick', {
    locationUid: payload.locationUid,
    dataRootPath,
    files: payload.files ?? [],
    fileNames: payload.fileNames ?? [],
    path: dataRootPath,
    targets: payload.targets
  });
  // live / treeOnly 模式：浏览区常显，不收起（收起会把用户刚勾选的上下文藏掉）
  if (props.live || props.treeOnly) return;
  if (props.inline) {
    inlineOpen.value = false;
    return;
  }
  fileDialog?.close();
}

/** 内嵌模式下的取消：只收起浏览区，不改变已选值 */
function closeInline() {
  inlineOpen.value = false;
}

/**
 * live 模式浏览区常显、只挂载一次，所以外部改值（切换策略清空 / 回显新单）必须靠 watch 同步。
 *
 * WHY 不能只在 openDialog 里 sync：live 下没有触发框，也就没有「打开」这个时机。
 * 若值由本组件自己实时 emit 出去再回写，BrowseDialog 的 sync 会判定为 same 而直接返回，
 * 不会打断用户正在进行的勾选。
 */
watch([() => props.locationUid, () => props.path, () => props.files, () => props.targets], async () => {
  if (!props.live && !props.treeOnly) return;
  if (!inlineOpen.value) return;
  await nextTick();
  await inlineRef.value?.sync(props.locationUid, props.path, props.files, props.uncPath, props.targets);
});

/** 宿主卸载时彻底销毁缓存实例，避免隐藏的 div 常驻 body */
onUnmounted(() => {
  fileDialog?.destroy();
  fileDialog = null;
});
</script>

<template>
  <!--
    live 模式整块不渲染触发框：浏览区已常显，触发框只是重复展示同一份「已选内容」，
    还多一道「点它才能操作」的门槛。
  -->
  <div v-if="!live" class="location-picker">
    <div
      class="lp-trigger"
      :class="{ 'is-empty': !hasValue, 'is-filled': hasValue, 'is-expanded': hasValue && filesExpanded }"
      role="button"
      tabindex="0"
      :title="summaryText || undefined"
      @click="openDialog"
      @keydown.enter="openDialog"
      @keydown.space.prevent="openDialog"
    >
      <!-- 空态：单行，视觉上与普通表单项同高 -->
      <template v-if="!hasValue">
        <el-icon class="lp-icon"><FolderOpened /></el-icon>
        <span class="lp-placeholder">{{ props.placeholder || '请选择存储位置或文件' }}</span>
        <el-icon class="lp-arrow"><ArrowRight /></el-icon>
      </template>

      <!--
        已选态：两段信息压在一行内（位置 / 数量 + 操作），清单默认折叠成一行摘要。
        WHY 不再默认竖向列出全部文件：检查页/入库页的表单里这一格会被 10+ 个文件撑到半屏高，
        把下面的任务名称、优先级等字段挤出视野；摘要行 + 按需展开既保住「看得见选了什么」，
        又不让表单长度随文件数线性增长。
      -->
      <template v-else>
        <div class="lp-head">
          <el-icon class="lp-icon is-active"><FolderOpened /></el-icon>
          <span class="lp-location" :title="summaryText">{{ locationName }}</span>
          <span v-if="fileCount" class="lp-badge">{{ countText }}</span>
          <span class="lp-action" title="清除已选" @click.stop="clearPick">
            <el-icon class="lp-clear"><Close /></el-icon>
          </span>
        </div>

        <div v-if="treeRows.length && !treeOnly" class="lp-files">
          <button type="button" class="lp-files__toggle" @click.stop="filesExpanded = !filesExpanded">
            <el-icon class="lp-files__caret" :class="{ 'is-open': filesExpanded }"><ArrowRight /></el-icon>
            <span class="lp-files__cap">{{ filesExpanded ? '收起已选内容' : `展开已选内容（${fileCount}）` }}</span>
          </button>
          <!--
            已选内容与入库清单同一套树：目录层级、拖动改路径、删除都在这里直接可用。
            WHY 不再自己渲染 ul/li 清单：同一份「已选元数据」在检查页、入库页、浏览弹窗、
            触发框四处出现，各写一套扁平清单会四处不一致（只有一处能拖动改路径）。
          -->
          <div v-show="filesExpanded" class="lp-files__tree" @click.stop>
            <SelectedFileTree
              :rows="treeRows"
              empty-text="暂无已选内容"
              tip="拖动文件到目录可改变入库路径；拖到空白处移回根目录。"
              :max-height="180"
              @move="onTreeMove"
              @remove="onTreeRemove"
              @move-into="onTreeMoveInto"
            />
          </div>
        </div>
      </template>
    </div>
  </div>

  <!--
    内嵌浏览区（inline 模式）：直接占用表单纵向空间，不再叠浮层。
    WHY 在根容器内而不是另起一个组件：浏览区就是 BrowseDialog 的内容组件，
    让它原地渲染即可复用全部浏览 / 勾选 / 拖拽逻辑，不必维护第二套实现。
  -->
  <div v-if="isInlineMode && inlineOpen" class="lp-inline" :class="{ 'is-live': live }">
    <div v-if="!live" class="lp-inline__bar">
      <span class="lp-inline__title">选择位置与文件</span>
      <span class="lp-inline__grow" />
      <el-button link type="primary" size="small" @click="closeInline">收起</el-button>
    </div>
    <div class="lp-inline__body">
      <BrowseDialog
        ref="inlineRef"
        :location-uid="locationUid"
        :path="path"
        :files="files"
        :file-names="fileNames"
        :pick-filter="pickFilter"
        :mode="mode"
        :source-type="sourceType"
        :unc-path="uncPath"
        :live="live"
        :tree-only="treeOnly"
        @pick="onPick"
        @cancel="closeInline"
      />
    </div>
  </div>
</template>

<style scoped lang="scss">
.location-picker {
  width: 100%;
  /* 内嵌模式要独占整行：Form 用 ElCol 控制列宽，靠 :deep 无法作用于父级，改由调用方传 :span="24" */
  box-sizing: border-box;
}

/* 内嵌浏览区：与表单同宽，固定高度内滚动，避免把后续字段挤到视野外 */
.lp-inline {
  /* 撑满 Form 给的整行宽度（ElCol 已是 24 栏），block + width:100% 避免被 inline 上下文收窄 */
  display: block;
  width: 100%;
  margin-top: 8px;
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 6px;
  overflow: hidden;

  /* live 模式上方没有触发框，不需要那 8px 间隔 */
  &.is-live {
    margin-top: 0;
  }
}

.lp-inline__bar {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 5px 10px;
  background: var(--el-fill-color-lighter);
  border-bottom: 1px solid var(--el-border-color-lighter);
}

.lp-inline__title {
  font-size: 12px;
  font-weight: 600;
  color: var(--el-text-color-secondary);
}

.lp-inline__grow {
  flex: 1;
}

/* 高度给足浏览区（树 + 已选清单两栏），溢出内部滚动 */
.lp-inline__body {
  display: block;
  width: 100%;
  height: 420px;
  padding: 10px 12px;
  overflow: hidden;
  box-sizing: border-box;
}

/* 表单弹窗只有 680px 时，双栏会把树挤成一条缝：窄屏改为上下堆叠 */
@media (max-width: 900px) {
  .lp-inline__body {
    height: 520px;
  }

  .lp-inline__body :deep(.fp-body) {
    flex-direction: column;
    gap: 10px;
  }

  .lp-inline__body :deep(.fp-picked) {
    flex: 0 0 auto;
    max-height: 160px;
    padding-left: 0;
    border-left: none;
    border-top: 1px solid var(--el-border-color-lighter);
    padding-top: 8px;
  }
}

/* 触发框：空态单行（32px，与 el-input 同高），已选态纵向堆叠 */
.lp-trigger {
  display: flex;
  align-items: center;
  gap: 6px;
  width: 100%;
  min-height: 32px;
  padding: 0 10px;
  font-size: 14px;
  line-height: 1.4;
  color: var(--el-text-color-regular);
  cursor: pointer;
  background: var(--el-fill-color-blank);
  border: 1px solid var(--el-border-color);
  border-radius: 4px;
  box-shadow: 0 0 0 1px var(--el-input-border-color, transparent) inset;
  box-sizing: border-box;
  transition:
    border-color 0.2s,
    box-shadow 0.2s;

  &:hover {
    border-color: var(--el-color-primary-light-5);
  }
  &:focus-visible {
    outline: none;
    border-color: var(--el-color-primary);
    box-shadow: 0 0 0 1px var(--el-color-primary) inset;
  }

  &.is-empty {
    color: var(--el-text-color-placeholder);
  }

  /*
   * 已选态：默认压成单行摘要（位置 / 数量 / 清除），展开清单时才切竖排。
   * WHY：表单里这一格原来把每个文件竖着列出来，选 10 个文件就撑到半屏，
   * 把「检查任务名称」等后续字段挤到视野外；摘要 + 按需展开让高度与原控件同量级。
   */
  &.is-filled {
    align-items: center;
    padding: 6px 10px;

    &.is-expanded {
      flex-direction: column;
      align-items: stretch;
      gap: 6px;
      padding-bottom: 10px;
    }
  }
}

.lp-icon {
  flex-shrink: 0;
  font-size: 15px;
  color: var(--el-text-color-placeholder);

  &.is-active {
    color: var(--el-color-primary);
  }
}

.lp-arrow {
  flex-shrink: 0;
  margin-left: auto;
  font-size: 14px;
  color: var(--el-text-color-placeholder);
}

.lp-placeholder {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* 单行摘要：位置名（可缩） + 数量 + 清除 */
.lp-head {
  display: flex;
  flex: 1;
  align-items: center;
  gap: 6px;
  min-width: 0;
}

.lp-location {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 13px;
  font-weight: 600;
  color: var(--el-text-color-primary);
  text-overflow: ellipsis;
  white-space: nowrap;
}

.lp-badge {
  flex-shrink: 0;
  padding: 0 8px;
  font-size: 12px;
  font-weight: 400;
  line-height: 18px;
  color: var(--el-color-primary);
  background: var(--el-color-primary-light-9);
  border-radius: 9px;
}

.lp-clear {
  flex-shrink: 0;
  font-size: 14px;
}

/* 清除热区：图标本身很小，包一层 20px 可点区域并做 hover 反馈 */
.lp-action {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: 20px;
  height: 20px;
  color: var(--el-text-color-placeholder);
  cursor: pointer;
  border-radius: 50%;
  transition:
    color 0.15s,
    background-color 0.15s;

  &:hover {
    color: var(--el-color-primary);
    background: var(--el-fill-color);
  }
}

/* 已选清单：默认折叠成一行开关，展开后竖向逐条排列（超 4 行内滚，不撑爆表单） */
.lp-files {
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
}

.lp-files__toggle {
  display: inline-flex;
  align-self: flex-start;
  align-items: center;
  gap: 4px;
  padding: 0;
  font-size: 12px;
  line-height: 16px;
  color: var(--el-text-color-secondary);
  cursor: pointer;
  background: none;
  border: none;

  &:hover {
    color: var(--el-color-primary);
  }
}

/* 展开箭头：折叠时朝右、展开时朝下（rotate 90deg） */
.lp-files__caret {
  font-size: 12px;
  transition: transform 0.15s;

  &.is-open {
    transform: rotate(90deg);
  }
}

.lp-files__cap {
  font-size: 12px;
  line-height: 16px;
}

/* 已选清单容器：树本体样式由 SelectedFileTree 自管，这里只负责折叠区的高度与分隔 */
.lp-files__tree {
  max-height: 200px;
  padding-top: 6px;
  overflow-y: auto;
  overscroll-behavior: contain;
  border-top: 1px dashed var(--el-border-color-lighter);
}
</style>
