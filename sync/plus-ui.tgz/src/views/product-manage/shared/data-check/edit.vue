<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
import { computed, h, onMounted, reactive, ref, watch } from 'vue';
import type { MetadataCheckScope, MetadataCheckSourceType } from '@/api/product-manage/platform/metadata-check';
import {
  buildMetadataCheckPayload,
  isMetadataCheckNotAccepted,
  MAX_METADATA_FILES_PER_UPLOAD,
  metadataCheckNotAcceptedMessage,
  precheckMetadataFiles,
  submitMetadataFileCheck,
  uploadMetadataFile,
  validateMetadataFilePath,
  validateMetadataFilePaths
} from '@/api/product-manage/platform/metadata-check';
import { getMetadataModelList } from '@/api/product-manage/platform/metadata';
import { getProductCategoryTree } from '@/api/product-manage/platform/category';
import { Connection, Folder, Upload } from '@element-plus/icons-vue';
import { ElMessage, type UploadUserFile } from 'element-plus';
import { pickTypesByRoot } from '../data-into-store/category-scope';
import BrowseDialog from './browse-dialog.vue';
import SelectedFileTree from './selected-file-tree.vue';

/**
 * 产品类别树节点（含层级）。
 *
 * WHY 用 getProductCategoryTree 而非 listProductCategories：本字段与「元数据浏览」
 * 左侧产品类别树需同源同形（后端只返回平铺 items，树由前端 category.ts 组装）。
 */
interface CategoryTreeNode {
  value: string;
  label: string;
  children?: CategoryTreeNode[];
}

/**
 * 检查清单的一行（SelectedFileTree 的 TreeRow 契约）。
 *
 * CONSTRAINT sourcePath 与 targetPath 分离：
 *   - sourcePath 是「相对当前来源根」的真实路径，是提交给 checks/files 的 files 元素；
 *   - targetPath 只用于清单树的层级组织（拖动到目录改它），检查任务没有「入库目标路径」的概念，
 *     因此拖动只改变清单视觉分组，**绝不影响提交值**。
 * CONSTRAINT 单来源：本页所有行同属 model.sourceType 这一个来源（检查接口只认一个来源），
 *   切换来源会替换整份清单；不像入库页那样混排多来源。
 */
interface CheckRow {
  id: string;
  sourcePath: string;
  targetPath: string;
  /** 来源展示名（清单徽标，与入库页一致） */
  sourceLabel?: string;
}

/**
 * 表单模型：只存直接绑定控件 + 交给 buildMetadataCheckPayload 校验的字段。
 *
 * CONSTRAINT 来源字段（sourceStorageUid / dataRootPath / uploadUid）不放在 model 里：
 *   它们不再由表单控件直接绑定，而是由「清单弹窗 / 清单按钮」维护成独立 ref，
 *   save() 按 sourceType 挑选其中一组提交。放两个地方必然出现「改了一处、另一处是旧值」。
 * CONSTRAINT sourceType 保留为**内部态**：不再有「来源类型」单选，由工具栏按钮 / 选择弹窗切换。
 */
interface MetadataCheckFormModel {
  modelUid: string;
  categoryUid: string;
  scope: MetadataCheckScope;
  /** 内部来源态（registered_share / direct_shared_path / upload），不显示 radio */
  sourceType: MetadataCheckSourceType;
  taskName: string;
}

/**
 * 对外事件声明。
 *
 * CONSTRAINT **只声明、不触发** submit：save() 自己完成提交并把响应返回给 createDialog，
 * 由它按 code===0 关弹窗并触发 afterSave。父级 index.vue 不传 onSubmit，但声明过 emit
 * 才能把它从 attrs 中摘掉，避免作为原生监听透传到 ElForm 根 <form>。
 */
const emit = defineEmits<{ submit: [payload: Record<string, unknown>] }>();

/**
 * 当前页面所属的类别语义根编码（由菜单页 provide 下发，index.vue 显式作 prop 传入）。
 * CONSTRAINT 不用 inject：本组件被 createDialog 以独立 render 挂到 body，vnode 无 parent，inject 拿不到。
 */
const props = defineProps<{ categoryRoot?: string }>();

const form = ref();

const model = reactive<MetadataCheckFormModel>({
  modelUid: '',
  categoryUid: '',
  scope: 'full',
  sourceType: 'registered_share',
  taskName: ''
});

const scopeOptions = [
  { label: pt('检查全部类型'), value: 'full' },
  { label: pt('完整性'), value: 'completeness' },
  { label: pt('准确性'), value: 'accuracy' }
];

/* ---------------- 数据选择：清单工具按钮 / 弹窗 + 清单工具树 ---------------- */

/**
 * 来源根状态（与 model 分离，理由见 MetadataCheckFormModel 注释）。
 *   - locationUid：登记共享位置 uid（registered_share 专用）
 *   - dataRootPath：registered_share=登记根内相对路径（空串=登记根，合法）；
 *                   direct_shared_path=完整 UNC 根原文
 *   - uploadFileList：本地上传的 File 对象（真正上传需要字节流，路径字符串拿不到）
 */
const locationUid = ref('');
const dataRootPath = ref('');
const uploadFileList = ref<UploadUserFile[]>([]);
const uploading = ref(false);
const uploadPickerRef = ref<HTMLInputElement | null>(null);

/** 检查清单（唯一真源）：共享目录弹窗勾选 / 本地上传都汇到这里，提交从这里取 files */
const checkRows = ref<CheckRow[]>([]);

/** 当前上传批次 uid（上传与提交共用同一批，避免「上传一批、提交另一批」） */
const currentUploadUid = ref('');

/** 清单文件数（工具栏统计徽标） */
const fileCount = computed(() => checkRows.value.length);

/** 取上传项的相对路径（与后端 relativePaths 同序同值）：优先 webkitRelativePath，回退文件名 */
function uploadPathOf(item: UploadUserFile): string {
  const raw = item.raw as (File & { webkitRelativePath?: string }) | undefined;
  return raw?.webkitRelativePath || raw?.name || item.name || '';
}

/** 来源批次展示名：数据根末段（空=共享根） */
function labelOfShare(rootPath: string): string {
  const raw = String(rootPath || '')
    .replace(/[\\/]+$/, '')
    .replace(/\\/g, '/');
  return raw.split('/').filter(Boolean).pop() || '共享根';
}

/**
 * 切换来源：检查接口是单来源三选一，切换即**替换整份清单**。
 *
 * WHY 必须清空所有来源态：后端按「哪些字段有值」推导来源，残留的 locationUid / dataRootPath
 * 会让 buildMetadataCheckPayload 推导出与声明 sourceType 不一致的结果并拒绝提交。
 */
function switchSource(type: MetadataCheckSourceType) {
  model.sourceType = type;
  checkRows.value = [];
  locationUid.value = '';
  dataRootPath.value = '';
  uploadFileList.value = [];
  currentUploadUid.value = '';
}

/**
 * 共享目录选择器确认后回填（BrowseDialog emit 全量结果）。
 *
 * CONSTRAINT 选了共享目录就是选了新来源：即使当前已是 registered_share，也先把旧清单 /
 * 旧 dataRootPath 清空，保证三种来源严格互斥，不会残留上一次选择的文件。
 *
 * CONSTRAINT 非空 uid = 真勾选（登记共享来源）；空 uid = 树里取消全部勾选 / 切换来源引起的
 *   空回填。空回填时若当前仍是登记共享来源则清空清单，切到别来源时忽略（别来源的行不该被误删）。
 * CONSTRAINT applyTreeFiles 用「全量覆盖」而非合并：树里取消勾选某个文件时，发回的是更短的列表，
 *   只有覆盖才能把被取消的那个从清单移除（入库页 replaceSourceBatch 同理）。
 */
function onTreePick(payload: { locationUid: string; dataRootPath?: string; path?: string; files?: string[]; targets?: string[] }) {
  const uid = String(payload?.locationUid || '').trim();
  if (!uid) {
    if (model.sourceType === 'registered_share') checkRows.value = [];
    return;
  }
  switchSource('registered_share');
  locationUid.value = uid;
  dataRootPath.value = payload?.dataRootPath ?? payload?.path ?? '';
  const files = Array.isArray(payload?.files) ? payload.files.filter(Boolean) : [];
  const targets = Array.isArray(payload?.targets) && payload.targets.length === files.length ? payload.targets : files;
  applyTreeFiles(files, targets);
}

/** 用选择器的全量结果重建登记共享来源的清单行（保留已有行的 id / 组织路径，避免重建抖动） */
function applyTreeFiles(files: string[], targets: string[]) {
  const existing = new Map(checkRows.value.map((r) => [r.sourcePath, r]));
  const label = labelOfShare(dataRootPath.value);
  checkRows.value = files.map((path, index) => {
    const old = existing.get(path);
    const targetPath = targets[index] || path;
    return old ? { ...old, targetPath, sourceLabel: label } : { id: 'tree:' + path + '#' + index, sourcePath: path, targetPath, sourceLabel: label };
  });
}

/* ---------------- 清单树操作（拖动 / 删除 / 目录） ---------------- */

/** 共享树的拖动结果：只改 targetPath，绝不动 sourcePath（提交值） */
function onTreeMove(payload: { id: string; targetPath: string }) {
  const row = checkRows.value.find((r) => r.id === payload.id);
  if (!row) return;
  row.targetPath = payload.targetPath;
}

/** 共享树的删除结果：本地上传行要同步从 uploadFileList 摘掉 File，否则下次重建又长回来 */
function onTreeRemove(id: string) {
  const at = checkRows.value.findIndex((r) => r.id === id);
  if (at < 0) return;
  const row = checkRows.value[at];
  if (model.sourceType === 'upload') {
    const i = uploadFileList.value.findIndex((item) => uploadPathOf(item) === row.sourcePath);
    if (i >= 0) uploadFileList.value.splice(i, 1);
  }
  checkRows.value.splice(at, 1);
}

/** 共享树的「移入目录」：把第一个可移动行移进 dirPath（拖动不可用时的兜底） */
function onTreeMoveInto(dirPath: string) {
  const row = checkRows.value[0];
  if (!row) {
    ElMessage.info(pt('清单里还没有文件'));
    return;
  }
  const name =
    String(row.targetPath || row.sourcePath)
      .split('/')
      .filter(Boolean)
      .pop() || row.sourcePath;
  const next = dirPath ? dirPath + '/' + name : name;
  if (next === row.targetPath) return;
  row.targetPath = next;
  ElMessage.success('已移入「' + (dirPath || '根目录') + '」');
}

/* ---------------- 清单工具栏：共享目录 / UNC / 本地上传 ---------------- */

/**
 * 打开共享位置选择器（BrowseDialog + createDialog）。
 * registered_share：登记共享目录 / 数据根 / 文件；direct_shared_path：用户输入的 UNC 根下浏览勾选。
 * CONSTRAINT footer:false —— BrowseDialog 自带确认 / 取消，外层 createDialog 的「提交」按钮会二次提交。
 */
function openBrowseDialog(sourceType: 'registered_share' | 'direct_shared_path', uncPath = '') {
  const isRegistered = sourceType === 'registered_share';
  let dialog: ReturnType<typeof createDialog> | null = null;
  dialog = createDialog({
    title: isRegistered ? pt('选择元数据位置') : pt('添加共享路径来源'),
    width: '820px',
    footer: false,
    closeOnClickModal: false,
    bodyStyle: { padding: '12px 16px', display: 'flex', flexDirection: 'column', overflow: 'hidden' },
    render: () =>
      h(BrowseDialog, {
        sourceType,
        uncPath,
        pickFilter: 'selectable',
        mode: 'auto',
        metadataOnly: true,
        locationUid: isRegistered ? locationUid.value : '',
        path: isRegistered && locationUid.value ? dataRootPath.value : '',
        files: isRegistered && model.sourceType === 'registered_share' ? checkRows.value.map((r) => r.sourcePath) : [],
        onPick: (payload: { locationUid: string; dataRootPath: string; path?: string; files?: string[]; targets?: string[] }) => {
          if (isRegistered) {
            onTreePick(payload);
          } else {
            const files = Array.isArray(payload.files) ? payload.files.filter(Boolean) : [];
            if (!files.length) {
              ElMessage.info(pt('未选择文件，共享路径来源未切换'));
              dialog?.close();
              return;
            }
            const rootPath = payload.dataRootPath || payload.path || '';
            if (!rootPath) {
              ElMessage.warning(pt('请先填写共享路径'));
              dialog?.close();
              return;
            }
            switchSource('direct_shared_path');
            dataRootPath.value = rootPath;
            const targets = Array.isArray(payload.targets) && payload.targets.length === files.length ? payload.targets : files;
            const label = labelOfShare(dataRootPath.value);
            checkRows.value = files.map((path, index) => ({
              id: 'unc:' + dataRootPath.value + ':' + path + '#' + index,
              sourcePath: path,
              targetPath: targets[index] || path,
              sourceLabel: label
            }));
          }
          dialog?.close();
        },
        onCancel: () => dialog?.close()
      })
  });
}

/** 清单工具栏「选择共享目录」：替代表单里的元数据位置控件 */
function openShareDirDialog() {
  openBrowseDialog('registered_share');
}

/** 清单工具栏「添加共享路径来源」：路径输入已并入 BrowseDialog，一步打开即可 */
function addUncSource() {
  openBrowseDialog('direct_shared_path');
}

/** 触发隐藏的文件选择框（清单工具栏「本地上传」按钮） */
function triggerUploadPicker() {
  uploadPickerRef.value?.click();
}

/** 隐藏 input 选中文件后：切到本地上传来源并加入清单（File 存在 uploadFileList，路径在 checkRows） */
function onUploadPicked(event: Event) {
  const input = event.target as HTMLInputElement;
  const picked = Array.from(input.files ?? []);
  input.value = '';
  if (!picked.length) return;
  // 本地上传只允许 SMS / GeoJSON 元数据文件（口径同元数据浏览 METADATA_EXTS）
  const allowed = picked.filter((file) => {
    const name = (file as File & { webkitRelativePath?: string }).webkitRelativePath || file.name;
    return ['sms', 'geojson'].includes(name.split('.').pop()?.toLowerCase() || '');
  });
  if (allowed.length !== picked.length) {
    ElMessage.warning('仅支持上传 .sms / .geojson 文件，已忽略 ' + (picked.length - allowed.length) + ' 个不支持的文件');
  }
  if (!allowed.length) return;
  if (model.sourceType !== 'upload') switchSource('upload');
  const seen = new Set(checkRows.value.map((r) => r.sourcePath));
  const room = MAX_METADATA_FILES_PER_UPLOAD - uploadFileList.value.length;
  let added = 0;
  let warning = '';
  for (const file of allowed) {
    const path = (file as File & { webkitRelativePath?: string }).webkitRelativePath || file.name;
    const pathErr = validateMetadataFilePath(path);
    const sizeErr = precheckMetadataFiles([file]);
    if (pathErr || sizeErr) {
      if (!warning) warning = pathErr || sizeErr || '';
      continue;
    }
    if (seen.has(path)) {
      if (!warning) warning = '已忽略重复选择的文件：' + path;
      continue;
    }
    if (added >= room) {
      if (!warning) warning = `单次最多上传 ${MAX_METADATA_FILES_PER_UPLOAD} 个文件`;
      break;
    }
    seen.add(path);
    uploadFileList.value.push({ name: path, size: file.size, raw: file } as UploadUserFile);
    checkRows.value.push({ id: 'upload:' + path, sourcePath: path, targetPath: path, sourceLabel: pt('本地上传') });
    added += 1;
  }
  if (warning) ElMessage.warning(warning);
  if (added) ElMessage.success('已加入 ' + added + ' 个本地文件，提交时统一上传');
}

/* ---------------- 提交前置：上传 / UNC / 扫描 ---------------- */

/** UNC 前缀归一化：多余前缀会让后端按 server 解析失败；非 UNC 写法原样返回 */
function normalizeUncPath(raw: string): string {
  const text = String(raw || '').trim();
  if (!text.startsWith('\\')) return text;
  const collapsed = text.replace(/\\{2,}/g, '\\');
  return '\\\\' + collapsed.replace(/^\\+/, '');
}

/** 生成客户端幂等键（前缀 + 时间 + 随机，刷新页面也不会归零重放） */
function makeRequestId(prefix: string): string {
  return prefix + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
}

/**
 * 提交时上传整批文件，返回该批次的 uploadUid 与相对路径清单。
 * WHY 并入提交：createDialog 用 save() 返回的 Promise 覆盖「上传 + 发起检查」两步，天然防重复点击。
 */
async function uploadPendingFiles(): Promise<{ uploadUid: string; files: string[] } | null> {
  if (!model.modelUid) {
    ElMessage.warning(pt('请先选择元数据模型'));
    return null;
  }
  const items = uploadFileList.value.filter((item) => !!item.raw) as (UploadUserFile & { raw: File })[];
  const files = items.map((item) => item.raw);
  const wholeErr = precheckMetadataFiles(files);
  if (wholeErr) {
    ElMessage.warning(wholeErr);
    return null;
  }
  const relativePaths = items.map(uploadPathOf);
  uploading.value = true;
  try {
    const res = await uploadMetadataFile(model.modelUid, files, { relativePaths });
    const uploadUid = res?.data?.uploadUid;
    if (!uploadUid) {
      ElMessage.error(pt('上传响应缺少 uploadUid'));
      return null;
    }
    return { uploadUid, files: relativePaths };
  } catch (e) {
    ElMessage.error((e as Error)?.message || '文件上传失败');
    return null;
  } finally {
    uploading.value = false;
  }
}

/* ---------------- 模型 / 类别下拉 ---------------- */

const modelOptions = ref<{ label: string; value: string }[]>([]);
const modelLoading = ref(false);
const productCategoryTree = ref<CategoryTreeNode[]>([]);
const productCategoryLoading = ref(false);
const taskNameEdited = ref(false);

/** 紧凑时间戳 YYYYMMDDHHmmss，用于任务名后缀保证同名产品可重复创建 */
function nameTimestamp(d: Date = new Date()): string {
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}

/** 任务名称按「产品-检查-时间戳」自动生成（产品=产品类别名，按 uid 反查 label） */
const selectedCategoryName = computed(() => findCategoryLabel(productCategoryTree.value, model.categoryUid));
const autoTaskName = computed(() => {
  const product = selectedCategoryName.value;
  return product ? `${product}-检查-${nameTimestamp()}` : '';
});

watch(autoTaskName, (name) => {
  if (!taskNameEdited.value) model.taskName = name;
});

/** 用户改动名称框：非空即锁定手工值；清空则立刻回落自动生成名 */
function handleTaskNameInput() {
  if ((model.taskName || '').trim()) {
    taskNameEdited.value = true;
  } else {
    taskNameEdited.value = false;
    model.taskName = autoTaskName.value;
  }
}

onMounted(loadModels);
onMounted(loadProductCategories);

function findCategoryLabel(nodes: CategoryTreeNode[], uid: string): string {
  if (!uid) return '';
  for (const n of nodes) {
    if (n.value === uid) return n.label;
    const hit = findCategoryLabel(n.children ?? [], uid);
    if (hit) return hit;
  }
  return '';
}

function toCategoryNode(n: { categoryUid: string; categoryName: string; children?: unknown[] }): CategoryTreeNode {
  const node: CategoryTreeNode = { value: n.categoryUid, label: n.categoryName };
  const kids = (n.children ?? []).map((c) => toCategoryNode(c as never));
  if (kids.length) node.children = kids;
  return node;
}

/** 拉取模型下拉；失败降级空数组（仍允许手动填 modelUid，但不静默当有效值提交） */
async function loadModels() {
  if (modelOptions.value.length || modelLoading.value) return;
  modelLoading.value = true;
  try {
    const res = await getMetadataModelList();
    modelOptions.value = (res.data?.items ?? []).map((m: any) => ({
      label: m.modelName || m.modelKey || m.modelUid,
      value: m.modelUid
    }));
  } catch {
    modelOptions.value = [];
  } finally {
    modelLoading.value = false;
  }
}

/** 加载产品类别树并按菜单语义根收窄（深度匹配，命中容器只取 children） */
async function loadProductCategories() {
  if (productCategoryTree.value.length || productCategoryLoading.value) return;
  productCategoryLoading.value = true;
  try {
    const res = await getProductCategoryTree();
    const full = (res.data?.tree ?? []) as unknown[] as Array<{
      categoryKey?: string;
      categoryUid: string;
      categoryName: string;
      children?: unknown[];
    }>;
    const root = props.categoryRoot;
    const scoped = root ? pickTypesByRoot(full, root) : [];
    const hit = scoped[0];
    const children = (hit?.children ?? []) as unknown[];
    const effective = hit ? (children.length ? children : [hit]) : full;
    productCategoryTree.value = effective.map((n) => toCategoryNode(n as never));
  } catch {
    productCategoryTree.value = [];
  } finally {
    productCategoryLoading.value = false;
  }
}

/* ---------------- 提交 ---------------- */

/**
 * 提交检查任务：载荷一律由 buildMetadataCheckPayload 构造，本函数只负责
 * 「按 sourceType 取正确的来源输入值」+ 上传批次 + 拦假成功。
 *
 *   upload → uploadUid（禁止 dataRootPath / sourceStorageUid）；
 *   registered_share → sourceStorageUid + 登记根内相对 dataRootPath；
 *   direct_shared_path → 完整 UNC dataRootPath 原文。
 * CONSTRAINT files 取 checkRows.sourcePath（真实来源相对路径），不取 targetPath（清单组织路径）。
 */
async function save() {
  const taskName = (model.taskName || '').trim();
  if (!taskName) {
    ElMessage.warning(pt('请填写任务名称'));
    return;
  }
  if (taskName.length > 200) {
    ElMessage.warning(pt('任务名称不能超过 200 字符'));
    return;
  }

  let files = checkRows.value.map((r) => r.sourcePath);
  if (!files.length) {
    ElMessage.warning(pt('请先在检查清单里选择文件'));
    return;
  }
  const filesError = validateMetadataFilePaths(files);
  if (filesError) {
    ElMessage.warning(filesError);
    return;
  }

  // H-02：发起检查前复核关联模型仍可见——软删除的模型不会出现在 getMetadataModelList 的列表里
  if (model.modelUid) {
    try {
      const res = await getMetadataModelList();
      const items = res.data?.items ?? [];
      if (!items.some((m: any) => m.modelUid === model.modelUid)) {
        ElMessage.warning(pt('关联元数据模型已被删除，请重新选择模型'));
        return;
      }
    } catch {
      // 复核请求失败时不阻断既有提交流程，仍以后端校验为准
    }
  }

  if (model.sourceType === 'registered_share' && !locationUid.value) {
    ElMessage.warning(pt('请先点清单工具栏的「选择共享目录」按钮选择登记位置'));
    return;
  }
  if (model.sourceType === 'direct_shared_path' && !String(dataRootPath.value || '').trim()) {
    ElMessage.warning(pt('请先填写共享路径'));
    return;
  }

  let uploadUid = '';
  if (model.sourceType === 'upload') {
    const batch = await uploadPendingFiles();
    if (!batch) return;
    uploadUid = batch.uploadUid;
    currentUploadUid.value = batch.uploadUid;
    files = batch.files;
  }

  const isRegistered = model.sourceType === 'registered_share';
  const isDirect = model.sourceType === 'direct_shared_path';
  const build = buildMetadataCheckPayload({
    modelUid: model.modelUid,
    categoryUid: model.categoryUid,
    scope: model.scope,
    taskName,
    files,
    sourceType: model.sourceType,
    uploadUid,
    sourceStorageUid: isRegistered ? locationUid.value : '',
    dataRootPath: isDirect ? normalizeUncPath(dataRootPath.value) : isRegistered ? dataRootPath.value || '' : undefined,
    requestId: makeRequestId('check')
  });
  if (!build.ok || !build.payload) {
    ElMessage.warning(build.message || '参数不完整，无法提交');
    return;
  }
  const res = await submitMetadataFileCheck(build.payload);
  /** 200 empty / partial 同样 code=0，但 checkUid=null、没有真正创建任务，必须先拦下 */
  if (isMetadataCheckNotAccepted(res)) {
    ElMessage.warning(metadataCheckNotAcceptedMessage(res));
    return;
  }
  return res;
}

defineExpose({ save, form });
</script>

<template>
  <Form ref="form" :model="model" :span="24" :gutter="0">
    <el-select
      v-model="model.modelUid"
      :label="pt('元数据模型')"
      :placeholder="pt('用于执行文件级元数据检查的模型')"
      clearable
      filterable
      :loading="modelLoading"
      :options="modelOptions"
      required
    />
    <el-tree-select
      v-model="model.categoryUid"
      :label="pt('产品类别')"
      check-strictly
      default-expand-all
      :render-after-expand="false"
      :data="productCategoryTree"
      :props="{ label: 'label', children: 'children' }"
      node-key="value"
      :loading="productCategoryLoading"
      required
    />
    <el-select v-model="model.scope" :label="pt('检查范围')" :options="scopeOptions" required />

    <!-- 名称放最后：选好产品类别后按「产品-检查-时间戳」自动生成，可手改 -->
    <el-input
      v-model="model.taskName"
      :label="pt('检查任务名称')"
      :placeholder="pt('选择产品类别后自动生成「产品-检查-时间戳」，可直接修改')"
      :maxlength="200"
      show-word-limit
      required
      @input="handleTaskNameInput"
    />
    <!-- 隐藏的本地文件选择器：由清单工具栏按钮触发，表单里不再摆一个上传拖拽区 -->
    <input ref="uploadPickerRef" type="file" multiple accept=".sms,.geojson" class="hidden-picker" @change="onUploadPicked" />
    <!-- 检查清单：所有来源选择的文件唯一权威清单，树结构、可拖动 -->
    <el-form-item :label="pt('检查清单')">
      <div v-loading="uploading" class="cand">
        <div class="cand__head">
          <span class="cand__stat">
            <el-tag size="small" type="primary" effect="plain" class="cand__chip">文件 {{ fileCount }}</el-tag>
          </span>
          <span class="cand__grow" />
          <div class="cand__actions">
            <el-button :icon="Folder" size="small" @click="openShareDirDialog">{{ pt('共享目录') }}</el-button>
            <el-button :icon="Connection" size="small" @click="addUncSource">{{ pt('共享路径') }}</el-button>
            <el-button :icon="Upload" size="small" @click="triggerUploadPicker">{{ pt('本地上传') }}</el-button>
          </div>
        </div>

        <div v-if="!checkRows.length" class="cand__empty">
          {{ pt('点工具栏「选择共享目录」勾选元数据文件，或用共享路径 / 本地上传按钮添加文件，这里会列出本次检查的完整清单。') }}
        </div>
        <SelectedFileTree
          v-else
          :rows="checkRows"
          flat
          :show-path="false"
          empty-text="还没有选择内容"
          tip="完整路径见悬浮提示；提交按来源相对路径。"
          :max-height="300"
          @move="onTreeMove"
          @remove="onTreeRemove"
          @move-into="onTreeMoveInto"
        />
      </div>
    </el-form-item>
  </Form>
</template>

<style scoped lang="scss">
/* 检查清单：紧凑卡片，与「数据入库」页同款 */
.cand {
  width: 100%;
  padding: 8px 10px;
  min-height: 300px;
  background: var(--el-fill-color-blank);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 4px;
}

.cand__head {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
}

.cand__stat {
  display: flex;
  align-items: center;
  gap: 6px;
}

.cand__chip {
  height: 20px;
  padding: 0 8px;
  font-size: 12px;
  line-height: 18px;
}

.cand__grow {
  flex: 1;
}

.cand__actions {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}

.cand__empty {
  padding: 10px 2px;
  font-size: 12px;
  color: var(--el-text-color-placeholder);
}

/* 本地上传由工具栏按钮触发，文件选择框本体不占布局 */
.hidden-picker {
  display: none;
}
</style>
