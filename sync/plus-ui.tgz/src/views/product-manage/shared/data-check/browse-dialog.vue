<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
/**
 * 存储位置 / 文件多选器（纯内容组件）。
 *
 * 外壳由父级用 createDrawer 承载并开启缓存常驻（close 只隐藏、不销毁），
 * 本组件只负责「内容 + 底部按钮」：逐层浏览已登记共享目录、勾选文件、回填数据根 + 文件清单。
 *
 * 左栏是**一棵懒加载树**：顶层节点是各「共享位置」，其下才是目录 / 文件。
 * WHY 用树而不是「位置下拉 + 面包屑 + 列表」三段控件：位置与目录本就是一棵树的两层，
 * 拆成两个控件后用户要在下拉与列表之间来回切，且面包屑只能表达「当前在哪」、表达不了
 * 「有哪些位置、彼此什么关系」。合并成一棵树后，位置切换 = 展开另一个根节点，零额外控件。
 *
 * 右侧是已选清单：单行紧凑展示（名称 + 相对路径），支持
 *   - 从左侧树**拖入**添加、已选内部**拖动重排**（纯前端顺序，不动磁盘文件）；
 *   - 「添加当前文件夹」把当前选中目录整体加入（等价于回上层勾该文件夹）。
 *
 * CONSTRAINT 三个路径字段语义不同（storage.ts 的 StorageBrowseEntry 注释同源）：
 *   - `entry.path`：**导航**语义（进入目录用），含父目录前缀，**绝不能当 files 值**；
 *   - `entry.relativePath`：相对**本次浏览目录**的路径，**这才是 files 元素**；
 *   - `dataRootPath`：本次提交的数据根（相对登记根，空串=登记根），与 files 拼起来才是完整路径。
 *
 * WHY 保留缓存常驻 sync：实例只挂载一次，之后重新打开不再重新初始化、不再把可能是文件路径的
 * 父表单 path 当目录去 browse，从根上避开重开时的 4xx 红字。父级每次 open() 前调 sync 显式对齐：
 * 值没变则完全保留状态、零请求。
 */
import { computed, nextTick, onMounted, ref, watch } from 'vue';
import type { Component } from 'vue';
import { ElMessage } from 'element-plus';
import SelectedFileTree from './selected-file-tree.vue';
import {
  ArrowRight,
  Box,
  Cpu,
  DataBoard,
  Document,
  Folder,
  FolderOpened,
  Grid,
  Headset,
  MapLocation,
  Memo,
  Picture,
  VideoCamera
} from '@element-plus/icons-vue';
import { browseLocation, browseUncPath, describeBrowseTruncation } from '@/api/product-manage/platform/storage';
import type { StorageBrowseEntry } from '@/api/product-manage/platform/storage';
import { listStorageConfigs } from '@/api/product-manage/platform/storage-config';

/** 共享位置（列表接口返回项）；字段名是 uid/displayName，不是 locationUid/locationName */
interface SharedLocationOption {
  uid: string;
  displayName: string;
  status: string;
  enabled?: boolean;
}

/**
 * 树节点数据。
 *
 * WHY 自己定形状而不是直接用 StorageBrowseEntry：树的顶层是「共享位置」，它不是文件条目
 * （没有 size / relativePath / selectable），但在树上必须与目录同样可展开。用一个统一的
 * TreeItem 承载两种语义，模板里只需判 isLocation。
 */
interface TreeItem {
  /** 树节点唯一键：位置 = loc:<uid>，其余 = <uid>\0<path> */
  key: string;
  /** 展示名 */
  label: string;
  /** 所属共享位置 uid */
  locationUid: string;
  /** 该节点自身的登记根相对路径（位置节点为空串） */
  path: string;
  /** 位置根节点：只用于承载多个共享位置，不可勾选、不可作为 files */
  isLocation?: boolean;
  isDir: boolean;
  /** 文件 / 目录条目（位置节点为 undefined） */
  entry?: StorageBrowseEntry;
}

/** el-tree 懒加载节点（只用到这几个成员，避免引入内部类型） */
interface LazyNode {
  level: number;
  data: TreeItem;
  key: string;
  loaded: boolean;
  childNodes: LazyNode[];
  expand: () => void;
}

/**
 * 一个已勾选的条目（文件或文件夹）。
 *
 * id 由「所在目录 + relativePath」构成：relativePath 只相对**当前浏览目录**，
 * 不同目录下同名文件会得到同一个 relativePath，只靠它会互相覆盖勾选态。
 *
 * CONSTRAINT 'selectable' 口径下文件夹也可勾选 —— 勾选文件夹表示「这一整个目录」，
 * 提交时把目录的相对路径作为一个 files 元素。契约 2026-11-11 起检查接口同样允许目录元素
 * （后端在任务执行期递归展开为叶子文件），因此检查页与入库页现统一走这一口径；
 * 'checkable' / 'file-only' 是历史严格口径，保留只为兼容可能的旧调用方。
 */
interface PickedFile {
  /** 勾选态身份键（目录 + relativePath） */
  id: string;
  /** 展示名 */
  name: string;
  /** 契约值：entry.relativePath（相对所在目录） */
  relativePath: string;
  /** 选择时所在的目录（登记根相对路径），提交时据它换算到数据根下的相对路径 */
  dir: string;
  /** 条目类型；'directory' 表示勾选的是整个文件夹 */
  kind: 'file' | 'directory';
  /**
   * 所属共享位置 uid。
   *
   * WHY 必须逐项记住：一次提交只能带一个 sourceStorageUid（契约三选一来源里
   * registered_share 只认单个位置），所以「能不能混选」取决于位置而不是目录 ——
   * 目录不一致可以靠上移数据根解决，位置不一致无解。
   */
  locationUid: string;
}

const props = withDefaults(
  defineProps<{
    /** 父表单已填的位置 uid；为空时默认取位置列表首条 */
    locationUid?: string;
    /** 父表单已填的数据根（兼容旧字段名 path）；作为初始定位 */
    path?: string;
    /** 已选文件（受控回显）；元素语义同 dataRootPath 下的相对路径 */
    files?: string[];
    /**
     * 过滤口径（按「能选什么」划分，与页面无关）：
     * - 'checkable' 仅 SMS/GeoJSON 可勾、目录不可勾（历史严格口径，现已无调用方）
     * - 'selectable' 普通文件与目录都可勾（当前入库页 / 检查页统一用此口径）
     */
    pickFilter?: 'checkable' | 'selectable';
    /**
     * 选择模式（按「能选什么」划分，与页面无关）：
     * - 'auto'（默认）目录与文件都可回填（可勾文件夹，与文件混合多选）
     * - 'file-only' 只能回填文件，目录不可勾（历史严格口径）
     */
    mode?: 'auto' | 'file-only';
    /** 数据来源类型：已登记共享（默认）/ 用户输入的 UNC */
    sourceType?: 'registered_share' | 'direct_shared_path';
    /** UNC 根（sourceType=direct_shared_path 时必填） */
    uncPath?: string;
    /**
     * 实时模式：勾选即回填，不渲染底部「取消 / 选择内容」按钮行。
     *
     * WHY 需要：宿主（入库弹窗）把浏览区直接铺在表单里，此时触发框与确认按钮是多余的一层
     * —— 用户看得到树和已选清单，却还要再点一次「选择内容」才生效，等于多一次无信息量的确认。
     * 实时模式下每次勾选 / 移除都会 emit pick，宿主表单立刻拿到最新的 files + dataRootPath。
     */
    live?: boolean;
    /**
     * 纯树模式：只渲染左栏目录树，不渲染右侧「已选内容」栏与底部按钮行。
     *
     * WHY 需要（契约 2026-11-12 起）：来源下沉到 files 每条后，一个任务可同时混排
     * 多个来源的文件，「已选内容」不再是单一来源的清单 —— 它由宿主页面的入库清单统一承载。
     * 浏览区里再放一份重复清单，两处都能拖动能删除，用户无法判断哪份是权威。
     * 因此宿主把树当成纯「添加器」：勾选即回填，已选与撤销都在宿主的入库清单里完成。
     */
    treeOnly?: boolean;
    /**
     * 仅显示元数据文件（SMS / GeoJSON），目录保留用于导航。
     * 检查页选源时打开：避免非元数据文件出现在树里被勾选后变成 ignoredDataFiles。
     */
    metadataOnly?: boolean;
  }>(),
  {
    pickFilter: 'selectable',
    mode: 'auto',
    files: () => [],
    sourceType: 'registered_share',
    uncPath: '',
    live: false,
    treeOnly: false,
    metadataOnly: false
  }
);

const emit = defineEmits<{
  /**
   * 回填。
   *
   * `files` 元素来自 entry.relativePath（相对 dataRootPath），`dataRootPath` 是本次的数据根；
   * `path` 是 dataRootPath 的**旧字段同义副本**，仅为未迁移的调用方保留（不要在新代码里读它）。
   */
  pick: [
    payload: {
      locationUid: string;
      dataRootPath: string;
      path: string;
      files: string[];
      fileNames: string[];
      /** 与 files 等长的目标路径并行数组（树上拖动后的入库路径）；缺省即与 files 相同 */
      targets?: string[];
    }
  ];
  /** 点「取消」时通知宿主关闭抽屉（createDrawer 的 X / Esc 走它自己的 close，不经过这里） */
  cancel: [];
}>();

/* ================= 文件图标 =================
 * 与 data-query/detail.vue 的文件列表同款分组：按扩展名归到语义组，
 * 每组固定一个 Element Plus 图标 + 主题色，认不出时退回通用文档图标。
 */
interface FileIconMeta {
  icon: Component;
  color: string;
}

const ICON_FOLDER: FileIconMeta = { icon: Folder, color: '#e6a23c' };
const ICON_FILE: FileIconMeta = { icon: Document, color: '#909399' };
const ICON_GEO: FileIconMeta = { icon: MapLocation, color: '#13a8a8' };
const ICON_RASTER: FileIconMeta = { icon: Picture, color: '#3f8cff' };
const ICON_IMAGE: FileIconMeta = { icon: Picture, color: '#52b788' };
const ICON_VIDEO: FileIconMeta = { icon: VideoCamera, color: '#8b5cf6' };
const ICON_AUDIO: FileIconMeta = { icon: Headset, color: '#06b6d4' };
const ICON_DOC: FileIconMeta = { icon: Document, color: '#3f8cff' };
const ICON_PDF: FileIconMeta = { icon: Document, color: '#f56c6c' };
const ICON_SHEET: FileIconMeta = { icon: Grid, color: '#2ba471' };
const ICON_SLIDE: FileIconMeta = { icon: DataBoard, color: '#f08c34' };
const ICON_ARCHIVE: FileIconMeta = { icon: Box, color: '#b4813f' };
const ICON_TEXT: FileIconMeta = { icon: Memo, color: '#909399' };
const ICON_CODE: FileIconMeta = { icon: Cpu, color: '#6b7ea8' };

const extGroups: Array<[FileIconMeta, string[]]> = [
  [
    ICON_GEO,
    [
      'shp',
      'shx',
      'dbf',
      'prj',
      'cpg',
      'sbn',
      'sbx',
      'qix',
      'fix',
      'gdb',
      'mdb',
      'geojson',
      'topojson',
      'kml',
      'kmz',
      'gpx',
      'gml',
      'wkt',
      'osm',
      'pbf',
      'dxf',
      'dwg',
      'tab',
      'mif',
      'mid'
    ]
  ],
  [ICON_RASTER, ['tif', 'tiff', 'img', 'jp2', 'ecw', 'sid', 'hdf', 'hdf5', 'nc', 'grib', 'dem', 'asc', 'pix', 'bil', 'bsq', 'vrt']],
  [ICON_IMAGE, ['png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp', 'svg', 'ico', 'heic', 'psd', 'ai', 'eps']],
  [ICON_PDF, ['pdf']],
  [ICON_DOC, ['doc', 'docx', 'rtf', 'odt', 'wps', 'pages', 'dot']],
  [ICON_SHEET, ['xls', 'xlsx', 'csv', 'tsv', 'ods', 'et', 'numbers']],
  [ICON_SLIDE, ['ppt', 'pptx', 'pps', 'odp', 'key', 'dps']],
  [ICON_TEXT, ['txt', 'md', 'markdown', 'log', 'readme', 'license', 'rst', 'nfo']],
  [ICON_ARCHIVE, ['zip', 'rar', '7z', 'tar', 'gz', 'tgz', 'bz2', 'xz', 'zst', 'jar', 'war']],
  [ICON_VIDEO, ['mp4', 'avi', 'mkv', 'mov', 'wmv', 'flv', 'webm', 'm4v', 'mpg', 'mpeg']],
  [ICON_AUDIO, ['mp3', 'wav', 'flac', 'aac', 'ogg', 'm4a', 'wma']],
  [
    ICON_CODE,
    [
      'js',
      'mjs',
      'cjs',
      'ts',
      'tsx',
      'jsx',
      'vue',
      'json',
      'xml',
      'html',
      'htm',
      'css',
      'scss',
      'less',
      'py',
      'java',
      'sql',
      'yml',
      'yaml',
      'sh',
      'bat',
      'ini',
      'conf',
      'toml',
      'ipynb'
    ]
  ]
];

const compositeExts = ['shp.xml', 'tar.gz', 'tar.bz2', 'tar.xz'];
const iconByExt: Record<string, FileIconMeta> = (() => {
  const map: Record<string, FileIconMeta> = {};
  for (const [meta, exts] of extGroups) for (const ext of exts) if (!map[ext]) map[ext] = meta;
  return map;
})();

/** 检查页可选的元数据扩展名；仅用于后端未返回 checkable 时的兜底判定 */
const METADATA_EXTS = ['sms', 'geojson'];

/** 树实例：只用到 filter / getNode / setCurrentKey */
const treeRef = ref<any>();
/** 树当前高亮节点（「添加当前文件夹」「改用当前目录」都以它为准） */
const currentNode = ref<TreeItem | null>(null);

/**
 * browse 分页上限。
 *
 * WHY 1000：契约建议值；递归拉平时它是「单页」上限，靠 nextCursor 续页，不是总量上限。
 */
const BROWSE_PAGE_LIMIT = 1000;
/** 递归拉平最多续多少页（防超大目录把浏览器拖死；超过就提示分批选） */
const BROWSE_MAX_PAGES = 10;

/** 是否为「用户输入 UNC」来源（决定 browse 走哪个端点） */
const isUncSource = computed(() => props.sourceType === 'direct_shared_path');

/** UNC 前缀归一化：多余前缀会让后端按 server 解析失败；非 UNC 写法原样返回 */
function normalizeUncPath(raw: string): string {
  const text = String(raw || '').trim();
  if (!text.startsWith('\\')) return text;
  const collapsed = text.replace(/\\{2,}/g, '\\');
  return '\\\\' + collapsed.replace(/^\\+/, '');
}

/** UNC 路径输入框的值：把「填路径」与「浏览勾选」合并到同一界面，不再弹「下一步」 */
const uncInput = ref(normalizeUncPath(props.uncPath || ''));
/** 当前生效的 UNC 根：输入框变化经归一化后的值，浏览 / 提交都以它为准 */
const currentUnc = computed(() => normalizeUncPath(uncInput.value));
/** 输入框占位示例（沿用宿主原 prompt 文案，含反斜杠字面） */
const uncPlaceholder = pt('\\\\192.168.1.10\\\\data\\\\居民地');

const locations = ref<SharedLocationOption[]>([]);
/** 位置列表是否在加载中（仅已登记来源会真正拉取；UNC 来源恒为 false） */
const locationsLoading = ref(false);
/** 树重建计数：sync 收到新定位值时 +1，让懒加载树从干净状态重新展开 */
const treeKey = ref(0);
const loadError = ref(false);
/** 已勾选文件（顺序即提交顺序，可在右栏拖动重排） */
const picked = ref<PickedFile[]>([]);
/**
 * 本次提交的数据根（relative 到登记根，空串=登记根）。
 *
 * WHY 在「首次勾选」时就钉住而不在提交时取当前目录：用户可能进入子目录后继续勾选，
 * 若 dataRootPath 随最后一次浏览目录漂移，已勾选的相对路径全部失效（拼出来不是原文件）。
 */
const dataRootPath = ref('');
/** 数据根是否已钉住 */
const rootPinned = ref(false);
/** 当前定位所依据的父表单值（本地副本，避免直接写只读 props；sync 变化时更新） */
const sourceUid = ref(props.locationUid);
const sourcePath = ref(props.path);
const sourceFiles = ref<string[]>((props.files || []).slice());
/** 当前定位所依据的 UNC 根（sync 变化判定用） */
const sourceUnc = ref(props.uncPath || '');
/** 上次回填给宿主的目标路径（变化判定用，避免拖动后不发事件） */
const sourceTargets = ref<string[]>([]);

/** 拖拽载荷：同一文档内的树节点，用模块内变量传递比 dataTransfer 更可靠 */
type DragPayload = { kind: 'add'; item: TreeItem };
let dragPayload: DragPayload | null = null;

/**
 * 已选行的目标路径覆盖表（id → 入库相对路径）。
 *
 * WHY 单独存：picked 元素描述的是「来源里选了什么」（absolute 的 dir + relativePath），
 * 而树上拖动改的是「入到哪儿」——两者是不同维度，硬塞进 PickedFile 会让
 * composeRel 的语义（来源 → 数据根相对路径）失真。覆盖表只影响提交的 targetPath。
 */
const targetOverrides = ref<Record<string, string>>({});

/** el-tree 的 props：位置节点与目录可展开，文件是叶子 */
const treeProps = {
  label: 'label',
  isLeaf: (data: TreeItem) => !data.isLocation && !data.isDir
};

/* ---------------- 图标与格式化 ---------------- */

const resolveFileIcon = (entry?: StorageBrowseEntry): FileIconMeta => {
  if (!entry) return ICON_FOLDER;
  if (isDir(entry)) return ICON_FOLDER;
  const name = (entry.name || '').toLowerCase();
  const composite = compositeExts.find((ext) => name.endsWith('.' + ext));
  if (composite) return iconByExt[composite];
  const dot = name.lastIndexOf('.');
  const ext = dot > 0 ? name.slice(dot + 1) : '';
  return (ext && iconByExt[ext]) || ICON_FILE;
};

function fmtBytes(n?: number | null): string {
  if (n == null) return '-';
  const u = ['B', 'KB', 'MB', 'GB'];
  let v = n;
  let i = 0;
  while (v >= 1024 && i < u.length - 1) {
    v /= 1024;
    i++;
  }
  return v.toFixed(2) + ' ' + u[i];
}

function isDir(e: StorageBrowseEntry): boolean {
  return ['directory', 'folder', 'dir'].includes(e.type);
}

/** 取扩展名（小写）；无扩展名返回空串 */
function extOf(name: string): string {
  const dot = (name || '').lastIndexOf('.');
  return dot > 0 ? name.slice(dot + 1).toLowerCase() : '';
}

/** 父目录（登记根相对路径）；根目录的父仍是根 */
function parentPathOf(path: string): string {
  const slash = (path || '').lastIndexOf('/');
  return slash > 0 ? path.slice(0, slash) : '';
}

/** 路径末段名称 */
function leafOf(path: string): string {
  const segs = (path || '').split('/').filter(Boolean);
  return segs.length ? segs[segs.length - 1] : '';
}

/* ---------------- 可选性判定 ---------------- */

/**
 * 目录是否可勾选。
 *
 * 'selectable' 口径下勾文件夹 = 选中「这一整个目录」，与文件混合多选：
 * 契约 2026-11-11 起检查接口 files 也允许目录元素（后端递归展开为叶子文件）。
 * 'checkable' 与 'file-only' 是历史严格口径，一律按不可勾处理。
 */
function isDirPickable(): boolean {
  return props.pickFilter === 'selectable' && props.mode !== 'file-only';
}

/**
 * 条目是否可勾选。
 *
 * 目录：只有 isDirPickable 为真时可勾；文件：按后端 checkable/selectable 标记，
 * 旧版本未返回时按扩展名兜底，避免整页全部勾不上又没有任何说明（新旧后端并存期）。
 */
function isPickable(e?: StorageBrowseEntry): boolean {
  if (!e) return false;
  if (isDir(e)) return isDirPickable();
  // 元数据检查只接受 SMS / GeoJSON：hidden 掉也不让勾，避免「列表里看不到却被选入」
  if (props.metadataOnly && !METADATA_EXTS.includes(extOf(e.name))) return false;
  if (props.pickFilter === 'checkable') {
    if (typeof e.checkable === 'boolean') return e.checkable;
    return METADATA_EXTS.includes(extOf(e.name));
  }
  if (typeof e.selectable === 'boolean') return e.selectable;
  return true;
}

/** 不可勾选原因（悬停提示用）；可勾选返回空串 */
function disabledReason(e?: StorageBrowseEntry): string {
  if (!e) return '';
  if (isPickable(e)) return '';
  if (isDir(e)) return pt('当前口径需选到具体文件');
  if (props.pickFilter === 'checkable') return pt('非 SMS / GeoJSON 元数据文件');
  return pt('当前文件不可选');
}

/* ---------------- 树节点 ---------------- */

/** 位置列表 → 树根节点 */
const locationItems = computed<TreeItem[]>(() => {
  // UNC 来源：没有登记位置，顶层用一个虚拟根承载（uid 传空，浏览时走 uncPath）
  if (isUncSource.value) {
    return [
      {
        key: 'unc:' + currentUnc.value,
        label: currentUnc.value || '（未填写共享路径）',
        locationUid: '',
        path: '',
        isLocation: true,
        isDir: true
      }
    ];
  }
  return locations.value.map((l) => ({
    key: 'loc:' + l.uid,
    label: l.displayName || l.uid,
    locationUid: l.uid,
    path: '',
    isLocation: true,
    isDir: true
  }));
});

/**
 * el-tree 懒加载：level 0 返回位置根，其余按目录逐层 browse。
 *
 * CONSTRAINT 第一个参数用 any：EP 的 LoadFunction 形参是内部类型 `Node`（未从包根导出），
 * 写成窄化的 LazyNode 会因函数参数逆变而不兼容；这里只读 level / data 两个稳定字段。
 * CONSTRAINT 失败时 resolve([]) 而不是抛错：抛错会让 el-tree 把节点标成加载失败且无法重试，
 * 这里改成空列表 + 顶部可点「刷新」重建树，用户至少能自己恢复。
 *
 * 2026-11-12 契约新增 recursive/cursor：这里仍按「逐层懒加载」调用（recursive=false），
 * 因为树的展开本身就是在逐层取数，一次拉全量反而会让大树首次加载很慢、也难以续页。
 * recursive 能力由 fetchBatch 承载，供「整目录一次拉平」的场景（如添加当前文件夹）复用。
 */
async function loadNode(node: any, resolve: (data: TreeItem[]) => void) {
  // 根层：返回全部可用共享位置
  if (node.level === 0) {
    resolve(locationItems.value);
    return;
  }
  const data = node.data as TreeItem;
  // 文件是叶子（isLeaf 已声明，正常不会进这里）；位置节点与目录都要列举其直接子项
  if (!data.isDir) {
    resolve([]);
    return;
  }
  try {
    const page = await fetchBatch(data.locationUid, data.path, false);
    const entries = props.metadataOnly ? page.entries.filter((e) => isDir(e) || METADATA_EXTS.includes(extOf(e.name))) : page.entries;
    resolve(
      entries.map((e) => ({
        key: data.locationUid + '\u0000' + e.path,
        label: e.name,
        locationUid: data.locationUid,
        path: e.path,
        isDir: isDir(e),
        entry: e
      }))
    );
  } catch {
    loadError.value = true;
    resolve([]);
  }
}

/** 一页 browse 结果：条目 + 续页游标 + 截断说明 */
interface BrowseBatch {
  entries: StorageBrowseEntry[];
  nextCursor: string;
  truncation: string;
  hasMore: boolean;
}

/**
 * 拉取一页 browse（支持 recursive + cursor）。
 *
 * WHY 收成一个函数：逐层懒加载、递归拉平、续页三种调用都是「取一页」这一个动作，
 * 各自写一遍必然在 cursor/limit/排序上漂移。排序（目录在前、名称升序）也在此收口。
 *
 * CONSTRAINT 递归拉平必须跟着 nextCursor 走完：truncatedReason=limit 时只拿第一页会漏项，
 * 而漏项在 UI 上表现为「目录里少了文件」，很难被发现。
 */
async function fetchBatch(locationUid: string, path: string, recursive: boolean, cursor?: string): Promise<BrowseBatch> {
  // 合并交互下首次挂载 uncPath 为空：不发坏请求，等用户填路径点「浏览」
  if (isUncSource.value && !currentUnc.value) {
    return { entries: [], nextCursor: '', truncation: '', hasMore: false };
  }
  const params = {
    path,
    recursive,
    limit: BROWSE_PAGE_LIMIT,
    ...(cursor ? { cursor } : {})
  };
  /**
   * UNC 来源走另一个端点：没有登记位置 uid，只给完整 UNC 根。
   * CONSTRAINT 不能用 browseLocation('') 顶替：该端点先按 uid 取凭据，空 uid 直接 404。
   */
  const res = isUncSource.value ? await browseUncPath(currentUnc.value, params) : await browseLocation(locationUid, params);
  const data = res?.data;
  const list = (data?.entries ?? []).slice();
  list.sort((a, b) => {
    const ad = isDir(a) ? 0 : 1;
    const bd = isDir(b) ? 0 : 1;
    return ad - bd || a.name.localeCompare(b.name);
  });
  const nextCursor = String(data?.nextCursor ?? '');
  return {
    entries: list,
    nextCursor,
    truncation: describeBrowseTruncation(data),
    hasMore: !!nextCursor
  };
}

/**
 * 递归拉平一个目录下的**全部文件**（自动续页）。
 *
 * WHY 需要：契约建议 browse 用 recursive=true 一次拿多层；但树的展开是逐层取数的，
 * 真正需要「一次拿全」的只有「添加当前文件夹/目录整体入清单」这类动作 —— 用户要的是
 * 这个目录底下到底有哪些文件，而不是再点开 N 层。
 */
async function fetchAllFiles(locationUid: string, path: string): Promise<{ files: StorageBrowseEntry[]; truncation: string }> {
  const files: StorageBrowseEntry[] = [];
  let cursor = '';
  let truncation = '';
  for (let guard = 0; guard < BROWSE_MAX_PAGES; guard++) {
    const page = await fetchBatch(locationUid, path, true, cursor);
    files.push(...page.entries.filter((e) => !isDir(e)));
    truncation = truncation || page.truncation;
    if (!page.hasMore) break;
    cursor = page.nextCursor;
    if (guard === BROWSE_MAX_PAGES - 1) truncation = '目录过大，已加载前 ' + BROWSE_MAX_PAGES + ' 页，请进入子目录分批选择';
  }
  return { files, truncation };
}

/** 树节点对应的勾选身份键（位置节点无身份） */
function idOfItem(item: TreeItem): string {
  if (!item.entry) return '';
  const dir = parentPathOf(item.path);
  return dir + '\u0000' + (item.entry.relativePath || item.entry.name);
}

/**
 * 已展开目录 → 该目录下应有文件数（用于判断目录勾选框的全选 / 半选态）。
 *
 * WHY 需要记数：目录被展开成文件行后，光看 picked 里有没有该目录自己，判断不出
 * 「子文件是不是全都在」。记下展开时返回的条数，再数当前 picked 里落在该目录下的行，
 * 两者相等才算全选，否则半选 —— 用户删掉其中一个文件时勾选框会立刻变成半选。
 */
const folderTotals = ref<Record<string, number>>({});

/** 某目录下当前被选中的行数 */
function pickedUnder(abs: string): number {
  const prefix = abs + '/';
  return picked.value.filter((p) => {
    const pAbs = p.dir ? p.dir + '/' + p.relativePath : p.relativePath;
    return pAbs === abs || pAbs.startsWith(prefix);
  }).length;
}

/**
 * 树节点是否「已完整选中」。
 *
 * 文件：自身在列即可。
 * 目录：自身以目录元素在列，或已知应有条数且当前选中数已达该条数，都算全选。
 */
function isCheckedItem(item: TreeItem): boolean {
  const id = idOfItem(item);
  if (!id) return false;
  if (picked.value.some((p) => p.id === id)) return true;
  if (!item.entry || !isDir(item.entry) || !item.path) return false;
  const total = folderTotals.value[item.path];
  return typeof total === 'number' && total > 0 && pickedUnder(item.path) >= total;
}

/** 目录节点是否「部分已选」（勾选框显示半选态，点击即补齐到全选） */
function isIndeterminateItem(item: TreeItem): boolean {
  if (!item.entry || !isDir(item.entry) || !item.path) return false;
  if (isCheckedItem(item)) return false;
  return pickedUnder(item.path) > 0;
}

/** 由目录节点构造 PickedFile（勾选态与提交都用它，与 addPicked 的入参一致） */
function folderPicked(item: TreeItem): PickedFile {
  return {
    id: parentPathOf(item.path) + '\u0000' + leafOf(item.path),
    name: leafOf(item.path) || item.entry?.name || '',
    relativePath: leafOf(item.path),
    dir: parentPathOf(item.path),
    kind: 'directory',
    locationUid: item.locationUid
  };
}

/**
 * 勾选目录 → 递归列出其下**全部文件**并逐个加入清单。
 *
 * WHY 展开成文件行而不是只放一个目录元素：
 *   - 用户要的是「这个目录里到底有哪些文件」，只有文件行才能在右栏看到、拖改入库路径、单独删除；
 *   - 目录元素提交后由后端递归展开，前端无从展示与干预，与「清单要能看到实际内容」相悖。
 * 失败/空目录时退回「目录元素」（后端仍会递归展开），保证不会因为查询失败而选不上。
 */
async function addFolderRecursive(item: TreeItem) {
  if (!item.path) {
    ElMessage.info(pt('登记根整体不能作为一个文件项，请选具体的文件夹'));
    return;
  }
  try {
    const { files, truncation } = await fetchAllFiles(item.locationUid, item.path);
    const rows: PickedFile[] = files
      .filter((e) => isPickable(e))
      .filter((e) => !!e.path)
      .map((e) => ({
        id: parentPathOf(e.path) + '\u0000' + leafOf(e.path),
        name: e.name || leafOf(e.path),
        relativePath: leafOf(e.path),
        dir: parentPathOf(e.path),
        kind: 'file' as const,
        locationUid: item.locationUid
      }));
    if (!rows.length) {
      if (props.metadataOnly) return;
      addPicked(folderPicked(item));
      return;
    }
    addPickedBatch(rows);
    // 记下应有条数：判定目录勾选框全选 / 半选要用它，缺了就永远是半选
    folderTotals.value[item.path] = rows.length;
  } catch {
    addPicked(folderPicked(item));
  }
}

/** 取消勾选：目录要连同它展开出的文件一起撤销 */
function removeFolderRecursive(item: TreeItem) {
  const id = idOfItem(item);
  const abs = item.path;
  const prefix = abs ? abs + '/' : '';
  const drop = new Set(
    picked.value
      .filter((p) => {
        if (p.id === id) return true;
        if (!abs) return false;
        const pAbs = p.dir ? p.dir + '/' + p.relativePath : p.relativePath;
        return pAbs === abs || pAbs.startsWith(prefix);
      })
      .map((p) => p.id)
  );
  if (!drop.size) return;
  picked.value = picked.value.filter((p) => !drop.has(p.id));
  // 清掉这个目录（及子目录）记下的应有条数，否则下次勾选会沿用旧数判成全选
  if (abs) {
    const absPrefix = abs + '/';
    for (const key of Object.keys(folderTotals.value)) {
      if (key === abs || key.startsWith(absPrefix)) delete folderTotals.value[key];
    }
  }
  if (!picked.value.length) {
    dataRootPath.value = '';
    rootPinned.value = false;
    folderTotals.value = {};
  }
}

/**
 * 点树节点上的勾选位。
 *
 * 目录按「整目录」语义切换：已全选（目录元素或展开出的文件全在列）→ 全部撤销；
 * 未选 / 半选 → 递归展开补齐。
 */
async function toggleItem(item: TreeItem) {
  if (!item.entry || !isPickable(item.entry)) return;
  const isFolder = isDir(item.entry);
  if (isFolder) {
    if (isCheckedItem(item)) removeFolderRecursive(item);
    else await addFolderRecursive(item);
    return;
  }
  const id = idOfItem(item);
  if (id && picked.value.some((p) => p.id === id)) {
    removeFolderRecursive(item);
    return;
  }
  addPicked({
    id,
    name: item.entry.name,
    relativePath: item.entry.relativePath || item.entry.name,
    dir: parentPathOf(item.path),
    kind: 'file',
    locationUid: item.locationUid
  });
}

/** 树当前节点变化（点行 / 键盘导航都会触发） */
function onCurrentChange(data: TreeItem | null) {
  currentNode.value = data;
}

/**
 * 重建树：sync 收到新定位值、或用户点刷新时调用。
 * treeKey 变化 → el-tree 重新 mount，懒加载从根开始；随后 locateTo 逐段展开到目标路径。
 */
async function rebuildTree() {
  treeKey.value += 1;
  await nextTick();
  await locateTo(sourceUid.value, sourcePath.value);
}

/** 轮询等待某个条件成立（树懒加载是异步的，没有可订阅的完成事件） */
async function waitFor<T>(fn: () => T | undefined, timeout = 4000): Promise<T | undefined> {
  const start = Date.now();
  let hit = fn();
  while (!hit && Date.now() - start < timeout) {
    await new Promise((r) => setTimeout(r, 60));
    hit = fn();
  }
  return hit;
}

/**
 * 逐段展开到目标路径，并把目标节点设为当前节点（回显定位）。
 *
 * CONSTRAINT 等待条件只能是「节点存在」，不能是 `node.loaded`：懒加载树里 loaded 表示
 * **子节点已加载**，刚建出来的根节点恒为 false，用它会一直等不到、定位静默失败。
 */
async function locateTo(uid: string, path: string) {
  // 空 UNC 根时不展开虚拟根（否则 waitFor 白等 4 秒），等用户填路径后 applyUnc 再重建
  if (isUncSource.value && !currentUnc.value) return;
  const tree = treeRef.value;
  if (!tree) return;
  // UNC 来源没有登记 uid，根节点键是 'unc:<路径>'；已登记来源仍按 uid 定位
  const wantedUid = isUncSource.value ? '' : uid || locations.value[0]?.uid || '';
  const rootKey = isUncSource.value ? 'unc:' + currentUnc.value : 'loc:' + wantedUid;
  if (!isUncSource.value && !wantedUid) return;
  const rootNode = await waitFor<LazyNode | undefined>(() => tree.getNode(rootKey) as LazyNode | undefined);
  if (!rootNode) return;
  // 自动展开目标位置根：多位置时用户一眼能看到「定位到了哪个位置」
  rootNode.expand();
  await waitFor(() => (rootNode.childNodes.length ? rootNode : undefined));
  // 按路径逐段下钻；某段不存在（脏数据 / 权限变化）就在能到的最深处停下
  const segs = (path || '').split('/').filter(Boolean);
  let node: LazyNode = rootNode;
  for (let i = 0; i < segs.length; i++) {
    const key = wantedUid + '\u0000' + segs.slice(0, i + 1).join('/');
    const hit = await waitFor<LazyNode | undefined>(() => {
      // 目标段可能在展开后才挂到父节点下，随父节点刷新查找
      const found = tree.getNode(key) as LazyNode | undefined;
      return found;
    });
    if (!hit) break;
    node = hit;
    if (i < segs.length - 1) {
      hit.expand();
      await waitFor(() => (hit.childNodes.length ? hit : undefined));
    }
  }
  tree.setCurrentKey(node.key);
  currentNode.value = node.data;
  const wanted = path.replace(/^\/+/, '');
  if (wanted && node.data.path !== wanted) {
    // 目标路径不存在时给出明确提示，避免用户以为「回显失败但没原因」
    ElMessage.warning('原数据根在当前位置下已不存在：' + path);
  }
}

/* ---------------- 已选清单 ---------------- */

/** 已选总数（fileNames 可能比 files 多，取较大值，避免清单与统计不一致） */
const pickedRows = computed(() => {
  const root = rootPinned.value ? dataRootPath.value : '';
  return picked.value.map((p) => ({ id: p.id, name: p.name, kind: p.kind, relative: composeRel(root, p) }));
});

/**
 * 树组件用的行数据：targetPath = 拖动覆盖值，缺省回落 sourcePath（来源相对路径）。
 *
 * WHY 与 pickedRows 分开：pickedRows.relative 是「来源 → 数据根」的换算结果，用作
 * 提交的 sourcePath；而树的派生依据是 targetPath（入到哪儿）。二者默认相同，
 * 但用户在树上拖过之后只有 targetPath 变，sourcePath 必须保持不变，否则提交的
 * 来源路径就指向不存在的文件了。
 */
const treeRows = computed(() =>
  pickedRows.value
    .filter((row) => row.relative != null)
    .map((row) => {
      const rel = String(row.relative || '');
      return {
        id: row.id,
        sourcePath: rel,
        targetPath: targetOverrides.value[row.id] || rel,
        kind: row.kind
      };
    })
);

/** 树上拖动：只改目标路径覆盖，不动 picked（来源选择保持原样） */
function onTreeMove(payload: { id: string; targetPath: string }) {
  targetOverrides.value = { ...targetOverrides.value, [payload.id]: payload.targetPath };
}

/** 树上移除：等价于取消勾选该来源项 */
function onTreeRemove(id: string) {
  removePicked(id);
}

/** 树上箭头：把首个可移动项移进该目录 */
function onTreeMoveInto(dirPath: string) {
  const row = treeRows.value[0];
  if (!row) return;
  const name =
    String(row.targetPath || row.sourcePath)
      .split('/')
      .filter(Boolean)
      .pop() || '';
  const next = dirPath ? dirPath + '/' + name : name;
  if (next !== row.targetPath) onTreeMove({ id: row.id, targetPath: next });
}

/** 是否存在无法换算到当前数据根的已选项（存在时禁止提交） */
const hasUncomposable = computed(() => pickedRows.value.some((row) => row.relative == null));

/** 勾选计数：文件数与文件夹数分开统计，底部按钮据此显示「选择内容（2+1）」 */
const pickedDirCount = computed(() => picked.value.filter((p) => p.kind === 'directory').length);
const pickedFileCount = computed(() => picked.value.length - pickedDirCount.value);
const pickedCountText = computed(() => {
  if (!picked.value.length) return '';
  if (!pickedDirCount.value) return `（${pickedFileCount.value}）`;
  if (!pickedFileCount.value) return `（${pickedDirCount.value} 个文件夹）`;
  return `（${pickedFileCount.value} 文件 + ${pickedDirCount.value} 文件夹）`;
});

/**
 * 计算 abs 相对 root 的路径；abs 不在 root 之下返回 null（不可换算），相等返回空串。
 * root 为空串表示登记根，任何 abs 都在其下。
 */
function relFrom(root: string, abs: string): string | null {
  if (!root) return abs || '';
  if (abs === root) return '';
  const prefix = root + '/';
  return abs.startsWith(prefix) ? abs.slice(prefix.length) : null;
}

/**
 * 已勾选文件 → 提交值（相对 dataRootPath）。
 *
 * 单目录场景（最常见）换算结果**就是** entry.relativePath，逐字节一致；
 * 跨子目录勾选时按目录差值拼接，绝不用 entry.path 直接充当 files 元素。
 */
function composeRel(root: string, p: PickedFile): string | null {
  const dirRel = relFrom(root, p.dir);
  if (dirRel == null) return null;
  return dirRel ? dirRel + '/' + p.relativePath : p.relativePath;
}

/**
 * 加入一项（**不拒绝、不弹校验**：任何文件 / 文件夹都可以加进清单）。
 *
 * 数据根不再「首次钉住后拒绝越界」，而是随选择**自动上移**到与已有项的最小公共祖先目录：
 *   - 只选同一目录下的条目 → 数据根就是该目录（与旧行为一致，提交值逐字节不变）；
 *   - 跨目录 / 跨层级选择 → 数据根上移到公共祖先，各项按「目录相对数据根的差值 + relativePath」换算；
 *   - 上移到登记根仍无法共处（不同共享位置）→ 这是**契约限制**而非交互限制：一次提交只能带
 *     一个 sourceStorageUid，因此只保留新项并提示，避免静默拼出后端必拒的载荷。
 *
 * WHY 改成自动上移而不是弹窗让用户去「清空重选」：数据根是前端派生出来的路径基准，
 * 不是一个需要用户手工维护的业务字段；让用户为它二次操作，是把内部实现泄漏成使用成本。
 * 上移是纯计算、结果唯一（最小公共祖先），由代码做比让人做更准。
 *
 * 文件夹与内部条目互斥（避免同一批数据被提交两次）：
 *   - 加文件夹 → 剔除它下面已勾选的条目（整体已覆盖）；
 *   - 加文件夹内部的条目 → 剔除该文件夹（局部优先）。
 */
function addPicked(next: PickedFile) {
  if (picked.value.some((p) => p.id === next.id)) return;

  // 位置不一致：登记共享位置是单值来源，无法用一次提交表达
  const otherLocation = picked.value.find((p) => p.locationUid !== next.locationUid);
  if (otherLocation) {
    const prevName = locations.value.find((l) => l.uid === otherLocation.locationUid)?.displayName || otherLocation.locationUid;
    const nextName = locations.value.find((l) => l.uid === next.locationUid)?.displayName || next.locationUid;
    picked.value = [];
    dataRootPath.value = '';
    rootPinned.value = false;
    ElMessage.warning(`一次检查只能选自同一个共享位置，已切换为「${nextName}」（原「${prevName}」的选择已清空）`);
  }

  // 数据根 = 已有各项所在目录与本次目录的最小公共祖先
  const roots = [next.dir, ...picked.value.map((p) => p.dir)];
  const root = commonAncestor(roots);
  // UNC 根是固定绝对根、不随浏览目录漂移：内部恒以 '' 为根，files 保留相对 UNC 根的完整层级；
  // 局部 root 仍用于目录/文件互斥判断（同一坐标系下前缀关系不变）。
  if (!isUncSource.value) {
    dataRootPath.value = root;
    rootPinned.value = true;
  }

  const nextRel = composeRel(root, next);
  const isFolder = next.kind === 'directory';
  picked.value = picked.value.filter((p) => {
    const rel = composeRel(root, p);
    if (rel == null) return true;
    if (isFolder) return !(rel === nextRel || (nextRel != null && rel.startsWith(nextRel + '/')));
    return !(p.kind === 'directory' && nextRel != null && nextRel.startsWith(rel + '/'));
  });
  picked.value.push(next);
}

/**
 * 批量加入（勾选文件夹递归展开时用）。
 *
 * WHY 不循环调 addPicked：addPicked 每次都重算最小公共祖先并对已选全表 filter，
 * 一个几百上千文件的目录会退化成 O(n²)；批量版只算一次祖先、按 id 与目录前缀各过滤一次。
 * 语义与 addPicked 保持一致：单共享位置约束、数据根自动上移、目录项与内部文件互斥。
 */
function addPickedBatch(list: PickedFile[]) {
  if (!list.length) return;
  const first = list[0];

  // 位置不一致：登记共享位置是单值来源，无法用一次提交表达
  const otherLocation = picked.value.find((p) => p.locationUid !== first.locationUid);
  if (otherLocation) {
    const prevName = locations.value.find((l) => l.uid === otherLocation.locationUid)?.displayName || otherLocation.locationUid;
    const nextName = locations.value.find((l) => l.uid === first.locationUid)?.displayName || first.locationUid;
    picked.value = [];
    dataRootPath.value = '';
    rootPinned.value = false;
    ElMessage.warning(`一次检查只能选自同一个共享位置，已切换为「${nextName}」（原「${prevName}」的选择已清空）`);
  }

  // UNC 来源不需要钉住数据根（见 addPicked）；批量版 root 后续无他用，直接省去
  if (!isUncSource.value) {
    dataRootPath.value = commonAncestor([...list.map((p) => p.dir), ...picked.value.map((p) => p.dir)]);
    rootPinned.value = true;
  }

  const incomingIds = new Set(list.map((p) => p.id));
  const incomingAbs = new Set(list.map((p) => (p.dir ? p.dir + '/' + p.relativePath : p.relativePath)));
  // 目录项已被本次加入的文件整体覆盖：剔除它，避免同一批数据提交两次
  const keep = picked.value.filter((p) => {
    if (incomingIds.has(p.id)) return false;
    if (p.kind !== 'directory') return true;
    const abs = p.dir ? p.dir + '/' + p.relativePath : p.relativePath;
    return !incomingAbs.has(abs) && ![...incomingAbs].some((a) => a.startsWith(abs + '/'));
  });
  picked.value = keep.concat(list);
}

/**
 * 求一组「登记根相对路径」的最小公共祖先目录。
 *
 * 空串代表登记根，它是所有路径的祖先，因此只要出现空串就直接返回空串。
 */
function commonAncestor(paths: string[]): string {
  const list = paths.map((p) => (p || '').replace(/^\/+|\/+$/g, ''));
  if (!list.length) return '';
  if (list.some((p) => !p)) return '';
  let common = list[0].split('/');
  for (const p of list.slice(1)) {
    const segs = p.split('/');
    let i = 0;
    while (i < common.length && i < segs.length && common[i] === segs[i]) i++;
    common = common.slice(0, i);
    if (!common.length) return '';
  }
  return common.join('/');
}

/** 按 id 移除单项 */
function removePicked(id: string) {
  picked.value = picked.value.filter((p) => p.id !== id);
  // 全删完回到「未钉住」状态，下次勾选会按当时的目录重新确定数据根
  if (!picked.value.length) {
    dataRootPath.value = '';
    rootPinned.value = false;
  }
}

/** 清空已勾选，回到「未钉住数据根」状态 */
function clearPicked() {
  picked.value = [];
  folderTotals.value = {};
  dataRootPath.value = '';
  rootPinned.value = false;
}

/**
 * 填写 / 更换共享路径后重新列举：清掉旧勾选与定位状态，按新 UNC 根重建懒加载树。
 * CONSTRAINT 清 targetOverrides / folderTotals / currentNode / source*：换根后旧相对路径全部失效，
 * 留着会让 composeRel 拿旧根换算、或让 locateTo 展开到新根下不存在的旧子目录。
 */
async function applyUnc() {
  const text = currentUnc.value;
  if (!text) {
    ElMessage.warning(pt('请输入共享路径'));
    return;
  }
  clearPicked();
  targetOverrides.value = {};
  folderTotals.value = {};
  loadError.value = false;
  currentNode.value = null;
  sourcePath.value = '';
  sourceFiles.value = [];
  sourceTargets.value = [];
  sourceUnc.value = text;
  await rebuildTree();
}

/**
 * 「添加当前文件夹」：把树上当前选中的目录整体加入已选。
 *
 * WHY 需要它：用户浏览到深层目录后想整体选中，回到上层再勾容易勾错兄弟目录。
 * 2026-11-12 起与勾选位一致 —— 都走 addFolderRecursive 展开成文件行，
 * 这样右栏能看到实际会入库哪些文件，也能逐个拖改路径。
 */
async function addCurrentFolder() {
  const node = currentNode.value;
  if (!node || node.isLocation) {
    ElMessage.info(pt('请先在左侧选中一个文件夹'));
    return;
  }
  if (!node.isDir) {
    ElMessage.info(pt('当前选中的是文件，请选一个文件夹'));
    return;
  }
  await addFolderRecursive(node);
}

/* ---------------- 拖拽 ---------------- */

/** 从左侧树拖出一个节点（只允许拖文件 / 目录，位置根不可拖） */
function onNodeDragStart(event: DragEvent, item: TreeItem) {
  if (!item.entry || !isPickable(item.entry)) {
    event.preventDefault();
    return;
  }
  dragPayload = { kind: 'add', item };
  event.dataTransfer?.setData('text/plain', item.label);
  if (event.dataTransfer) event.dataTransfer.effectAllowed = 'copy';
}

/**
 * 右侧容器 dragover：只服务「从左侧树拖入」的投放反馈。
 *
 * 行内拖动（改 targetPath）由 SelectedFileTree 自己处理，走到这里时 dragPayload 为空，
 * 直接放过，避免把两种拖动混成一个 drop 语义。
 */
function onPickDragOver(event: DragEvent, _index: number) {
  if (!dragPayload) return;
  event.preventDefault();
  if (event.dataTransfer) event.dataTransfer.dropEffect = 'copy';
}

/**
 * 落到清单空白处：只处理「从左侧树拖入」。
 *
 * 树内部的移动（改 targetPath）由 SelectedFileTree 自己 emit move，
 * 不再走这里的重排逻辑 —— 两种拖动语义不同（来源增删 vs 入库路径调整），
 * 混在一个 drop 处理器里会互相误判。
 */
function onPickDrop(event: DragEvent, _index: number) {
  event.preventDefault();
  const payload = dragPayload;
  dragPayload = null;
  if (!payload || payload.kind !== 'add') return;

  const item = payload.item;
  if (!item.entry) return;
  const next: PickedFile = {
    id: idOfItem(item),
    name: item.entry.name,
    relativePath: item.entry.relativePath || item.entry.name,
    dir: parentPathOf(item.path),
    kind: isDir(item.entry) ? 'directory' : 'file',
    locationUid: item.locationUid
  };
  addPicked(next);
}

/* ---------------- 回填 / 提交 ---------------- */

/**
 * 回显父表单传来的已选文件（受控回显）。
 *
 * WHY 直接拆路径字符串、不去树里比对：父表单的 files 是**相对数据根**的路径，可以跨子目录
 * （实测示例 files = ["...一.SMS", "数据二/...二.SMS"]），只在当前目录匹配会漏掉嵌套项。
 *
 * 拆解规则是 composeRel 的严格逆运算：末段=文件名，前面各段=相对数据根的目录，
 * 该目录的登记根相对路径 = root 前缀 + 目录。这样 composeRel 复原后逐字节等于原值。
 */
function restoreEchoSelection() {
  const root = (sourcePath.value || '').replace(/^\/+/, '');
  const want = sourceFiles.value.filter(Boolean);
  picked.value = [];
  // 外部值被改写（清空 / 重选）：拖动覆盖与目录应有条数同步作废，否则会残留指向旧项的判定
  targetOverrides.value = {};
  folderTotals.value = {};
  rootPinned.value = false;
  dataRootPath.value = '';
  if (!want.length) return;
  const restored: PickedFile[] = [];
  for (const rel of want) {
    const segs = String(rel).split('/').filter(Boolean);
    if (!segs.length) continue;
    const name = segs[segs.length - 1];
    const dirRel = segs.slice(0, -1).join('/');
    const dir = dirRel ? (root ? root + '/' + dirRel : dirRel) : root;
    restored.push({
      id: dir + '\u0000' + name,
      name,
      relativePath: name,
      dir,
      kind: extOf(name) ? 'file' : 'directory',
      locationUid: sourceUid.value || locations.value[0]?.uid || ''
    });
  }
  picked.value = restored;
  dataRootPath.value = root;
  rootPinned.value = true;
  /**
   * 回显目标路径覆盖：宿主传来的 targets 与 files 不等长就视为「没拖过」，
   * 只按 files 重建。等长时逐项比较，仅对不同的项写覆盖表，保持界面与宿主一致。
   */
  const wantedTargets = sourceTargets.value.length === restored.length ? sourceTargets.value : [];
  if (wantedTargets.length) {
    const overrides: Record<string, string> = {};
    restored.forEach((p, i) => {
      const rel = want[i] || '';
      const target = wantedTargets[i] || '';
      if (target && target !== rel) overrides[p.id] = target;
    });
    targetOverrides.value = overrides;
  }
}

/** 拉取可用共享位置（停用/异常位置调 browse 会 404，被全局拦截器弹错，必须过滤） */
async function loadLocations() {
  locationsLoading.value = true;
  try {
    const res = await listStorageConfigs({ kind: 'shared_directory' });
    const all = (res?.data?.items ?? []) as unknown as SharedLocationOption[];
    locations.value = all.filter((l) => l.status === '可用' && l.enabled !== false);
  } catch {
    locations.value = [];
  } finally {
    locationsLoading.value = false;
  }
}

/**
 * 首次挂载：拉位置 + 首建树 + 恢复回显。
 * 缓存常驻模式下只执行一次——之后关闭/重开都不再重新初始化。
 */
onMounted(async () => {
  if (!isUncSource.value) await loadLocations();
  restoreEchoSelection();
  await rebuildTree();
});

/**
 * 父级每次 open() 前调用：把外部表单值（位置 / 数据根 / 已选文件）同步进来。
 * - 值没变（最常见的重开场景）：什么都不做，完整保留展开状态与勾选态，零请求。
 * - 值被外部改动（清除 / 来源类型切换 / 回填新值）：更新本地副本后按新值重建定位。
 */
async function sync(locationUid?: string, path?: string, files?: string[], uncPath?: string, targets?: string[]) {
  const nextFiles = Array.isArray(files) ? files.slice() : [];
  const nextTargets = Array.isArray(targets) ? targets.slice() : nextFiles.slice();
  const nextUnc = uncPath ?? props.uncPath ?? '';
  const same =
    locationUid === sourceUid.value &&
    (path ?? '') === (sourcePath.value ?? '') &&
    nextUnc === sourceUnc.value &&
    nextFiles.join('\u0000') === sourceFiles.value.join('\u0000') &&
    nextTargets.join('\u0000') === sourceTargets.value.join('\u0000');
  if (same) return;
  sourceUid.value = locationUid;
  sourcePath.value = path;
  sourceUnc.value = nextUnc;
  uncInput.value = normalizeUncPath(nextUnc);
  sourceFiles.value = nextFiles;
  sourceTargets.value = nextTargets;
  if (!isUncSource.value && !locations.value.length) await loadLocations();
  restoreEchoSelection();
  await rebuildTree();
}

/**
 * 确认回填并通知宿主。
 * WHY 同时更新 sourceUid/sourcePath/sourceFiles：回填后父表单 props 会变成这个值，
 * 若定位源仍是旧值，下次 open() 的 sync 会误判为「外部改动」而重新定位一次。
 * WHY 位置取首项的 locationUid 而不是当前高亮节点：用户可能滚到别的位置去翻找，
 * 但真正要提交的是已选项所属位置（二者不一致时提交出去的后端必拒）。
 */
/**
 * 提交给宿主的 dataRootPath：UNC 来源恒为完整 UNC 根（files 是相对它的完整层级路径）；
 * 已登记来源仍是登记根内相对目录，语义不变。
 *
 * CONSTRAINT UNC 来源时 sourcePath / sourceFiles 必须保持内部相对值：
 * publishLive 的「与本地 source* 副本完全一致则不 emit」判定依赖它们，
 * 写完整 UNC 会把每次勾选都判定为「不一致」、触发重复 emit 回写宿主。
 */
function submitDataRoot(internalRoot: string): string {
  return isUncSource.value ? currentUnc.value : internalRoot;
}

function finish(dataRoot: string, files: string[], fileNames: string[], targets?: string[]) {
  // UNC 来源没有登记 uid：回填空 uid，由调用方按 sourceType=direct_shared_path 提交 UNC 根
  const uid = isUncSource.value ? '' : picked.value[0]?.locationUid || currentNode.value?.locationUid || locations.value[0]?.uid || '';
  if (!isUncSource.value && !uid) return;
  sourceUid.value = uid;
  sourcePath.value = dataRoot;
  sourceFiles.value = files.slice();
  sourceTargets.value = (targets ?? files).slice();
  const emitRoot = submitDataRoot(dataRoot);
  emit('pick', { locationUid: uid, dataRootPath: emitRoot, path: emitRoot, files, fileNames, targets });
}

/** 确认：回填数据根 + 已勾选文件（相对数据根，顺序即 picked 顺序） */
function commitFiles() {
  if (!picked.value.length) return;
  const root = dataRootPath.value;
  const files: string[] = [];
  const names: string[] = [];
  const targets: string[] = [];
  for (const p of picked.value) {
    const rel = composeRel(root, p);
    if (rel == null || !rel) {
      ElMessage.warning('「' + p.name + '」无法换算到数据根「' + (root || '登记根') + '」之下，请移除后重选');
      return;
    }
    files.push(rel);
    names.push(p.name);
    targets.push(targetOverrides.value[p.id] || rel);
  }
  finish(root, files, names, targets);
}

/** 取消：通知宿主关闭抽屉，不回填 */
function cancelPick() {
  emit('cancel');
}

/* ---------------- 实时回填（live） ---------------- */

/**
 * 把当前勾选结果实时回填给宿主。
 *
 * 与 commitFiles 的区别：不弹「无法换算到数据根」的阻断提示、允许空清单（清空操作要能生效），
 * 换算不了的行直接跳过 —— 宿主只关心能提交的值，界面上已有 is-invalid 红底提示。
 *
 * CONSTRAINT 与本地 source* 副本完全一致时不 emit：sync / restoreEchoSelection 会把宿主
 * 传来的值写回 picked，若无条件 emit 就会「回显值再写回宿主」，用户清空后会被顶回去。
 */
function publishLive() {
  // treeOnly 也要实时回填：宿主把本组件当纯「添加器」用（右侧清单和底部确认按钮都不渲染），
  // 没有任何「确认」时机，勾选/拖动就必须立刻写回宿主的入库清单，否则用户的操作全部丢失。
  if (!props.live && !props.treeOnly) return;
  const root = dataRootPath.value;
  const files: string[] = [];
  const names: string[] = [];
  const targets: string[] = [];
  for (const p of picked.value) {
    const rel = composeRel(root, p);
    if (rel == null || !rel) continue;
    files.push(rel);
    names.push(p.name);
    targets.push(targetOverrides.value[p.id] || rel);
  }
  // 清空态：uid 一并置空，否则宿主表单会留着「上次选的位置 + 空文件」这种半成品状态
  const uid = !picked.value.length
    ? ''
    : isUncSource.value
      ? ''
      : picked.value[0]?.locationUid || currentNode.value?.locationUid || locations.value[0]?.uid || '';
  const same =
    uid === (sourceUid.value || '') &&
    root === (sourcePath.value ?? '') &&
    files.join('\u0000') === sourceFiles.value.join('\u0000') &&
    targets.join('\u0000') === sourceTargets.value.join('\u0000');
  if (same) return;
  sourceUid.value = uid;
  sourcePath.value = root;
  sourceFiles.value = files.slice();
  sourceTargets.value = targets.slice();
  const emitRoot = submitDataRoot(root);
  emit('pick', { locationUid: uid, dataRootPath: emitRoot, path: emitRoot, files, fileNames: names, targets });
}

watch([picked, dataRootPath, targetOverrides], publishLive, { deep: true, flush: 'post' });

/** 暴露给父级 createDrawer 实例：开前同步（底部按钮自管，见 template） */
defineExpose({ sync });
</script>

<template>
  <div class="file-picker">
    <!-- UNC 来源：把「填共享路径」与「浏览勾选」合并到同一界面，不再弹「下一步」 -->
    <div v-if="isUncSource && !live && !treeOnly" class="fp-unc">
      <span class="fp-unc__label">{{ pt('共享路径') }}</span>
      <el-input v-model="uncInput" class="fp-unc__input" :placeholder="uncPlaceholder" clearable @keyup.enter="applyUnc" />
      <el-button type="primary" @click="applyUnc">{{ pt('浏览') }}</el-button>
      <span class="fp-unc__tip">{{ pt('点「浏览」列出路径内容') }}</span>
    </div>
    <div class="fp-body">
      <!-- 左：一棵懒加载树（位置 → 目录 → 文件），取代原来的「位置下拉 + 面包屑 + 列表」三段控件 -->
      <section class="fp-browse">
        <!--
          加载遮罩只看「是否正在拉位置列表」：UNC 来源不拉位置列表，
          用 !locations.length 当条件会让整棵树永久蒙在 loading 里（实测踩过）。
        -->
        <div class="fp-tree" v-loading="locationsLoading">
          <el-tree
            :key="treeKey"
            ref="treeRef"
            :props="treeProps"
            :load="loadNode"
            lazy
            node-key="key"
            :indent="14"
            highlight-current
            :expand-on-click-node="true"
            @current-change="onCurrentChange"
          >
            <template #default="{ data }">
              <div
                class="tree-row"
                :class="{ 'is-checked': isCheckedItem(data) || isIndeterminateItem(data), 'is-disabled': data.entry && !isPickable(data.entry) }"
                :draggable="!!data.entry && isPickable(data.entry)"
                :title="data.entry ? disabledReason(data.entry) || data.path : data.label"
                @dragstart="onNodeDragStart($event, data)"
              >
                <el-checkbox
                  v-if="data.entry && isPickable(data.entry)"
                  class="tree-check"
                  :model-value="isCheckedItem(data)"
                  :indeterminate="isIndeterminateItem(data)"
                  @click.stop
                  @change="toggleItem(data)"
                />
                <span v-else class="tree-check tree-check--placeholder" />
                <el-icon class="tree-icon" :style="{ color: resolveFileIcon(data.entry).color }">
                  <component :is="data.isLocation ? FolderOpened : resolveFileIcon(data.entry).icon" />
                </el-icon>
                <span class="tree-name">{{ data.label }}</span>
                <span v-if="data.entry && disabledReason(data.entry)" class="tree-tag">{{ disabledReason(data.entry) }}</span>
                <span v-if="data.entry && !data.isDir" class="tree-size">{{ fmtBytes(data.entry.size) }}</span>
              </div>
            </template>
          </el-tree>
          <!-- 空态只在「已登记来源且位置列表为空」时出现：UNC 来源本来就没有登记位置 -->
          <el-empty v-if="!isUncSource && !locations.length" description="没有可用的共享位置" :image-size="56" />
        </div>

        <div v-if="loadError" class="browse-tip">部分目录列举失败，可点右上角刷新重试。</div>
      </section>

      <!--
        右：已选清单（单行紧凑，可从左侧拖入、可拖动重排）
        treeOnly 模式下不渲染：宿主（入库页）的入库清单才是权威清单，
        这里再放一份会让同一批文件出现两个可拖动/可删除的入口。
      -->
      <aside v-if="!treeOnly" class="fp-picked">
        <div class="fp-picked__head">
          <span class="fp-picked__title">已选内容</span>
          <span v-if="picked.length" class="fp-picked__count">{{ pickedCountText || `（${picked.length}）` }}</span>
        </div>

        <!--
          数据根在这里不再展示：它是提交载荷的路径基准，用户关心的是「选了哪些文件」。
          数据根仍按选择自动上移到最小公共祖先（见 addPicked），提交语义不变。
        -->
        <div class="fp-picked__body" :class="{ 'is-empty': !picked.length }" @dragover="onPickDragOver($event, -1)" @drop="onPickDrop($event, -1)">
          <SelectedFileTree
            :rows="treeRows"
            :show-path="false"
            empty-text="还没有选择内容"
            tip=""
            :max-height="0"
            @move="onTreeMove"
            @remove="onTreeRemove"
            @move-into="onTreeMoveInto"
          />
        </div>
      </aside>
    </div>

    <!-- 抽屉不渲染底部按钮（footer:false），由内容组件自管（项目既有范式） -->
    <!--
      实时模式（live）不渲染底部按钮行：勾选已经直接写回宿主表单，
      「取消 / 选择内容」在这里没有语义 —— 取消无从回退，确认也是空动作。
    -->
    <div v-if="!live && !treeOnly" class="fp-footer">
      <div class="fp-footer__btns">
        <el-button @click="cancelPick">取消</el-button>
        <el-button type="primary" :disabled="!picked.length || hasUncomposable" @click="commitFiles">选择内容{{ pickedCountText }}</el-button>
      </div>
    </div>
  </div>
</template>

<style scoped lang="scss">
/**
 * 布局：左树 + 右已选清单。
 *
 * WHY 高度撑满父容器：承载在抽屉里，抽屉 body 是 flex 列、高度由视口决定；
 * 写死像素会在高视口留白、矮视口溢出。兜底 min-height 保证极矮视口下仍有可用列表。
 */
.file-picker {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 360px;
  gap: 12px;
}

/* UNC 路径输入行：与树同屏，填完即点「浏览」重新列举 */
.fp-unc {
  display: flex;
  flex-shrink: 0;
  align-items: center;
  gap: 8px;
}

.fp-unc__label {
  flex-shrink: 0;
  font-size: 13px;
  color: var(--el-text-color-regular);
}

.fp-unc__input {
  flex: 1;
  min-width: 0;
}

.fp-unc__tip {
  flex-shrink: 0;
  font-size: 12px;
  color: var(--el-text-color-secondary);
}

.fp-body {
  display: flex;
  flex: 1;
  gap: 12px;
  min-height: 0;
}

/* 左栏：工具栏 + 树（只有树滚动） */
.fp-browse {
  display: flex;
  flex: 1 1 auto;
  flex-direction: column;
  gap: 8px;
  min-width: 0;
  min-height: 0;
}

.fp-tree {
  flex: 1;
  min-height: 0;
  overflow: auto;
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 4px;

  :deep(.el-tree) {
    padding: 4px 0;
    background: transparent;
  }

  /* 节点行内边距压小，长目录名才能在一行里放得下更多层级 */
  :deep(.el-tree-node__content) {
    height: 30px;
    padding-right: 8px;
  }

  :deep(.el-tree-node.is-current > .el-tree-node__content) {
    background: var(--el-color-primary-light-9);
  }
}

/* 树节点一行：勾选位 + 图标 + 名称 + 禁用原因 + 大小 */
.tree-row {
  display: flex;
  flex: 1;
  align-items: center;
  gap: 6px;
  min-width: 0;
  cursor: pointer;

  &.is-checked .tree-name {
    color: var(--el-color-primary);
  }

  &.is-disabled .tree-name {
    color: var(--el-text-color-placeholder);
  }
}

.tree-check {
  flex-shrink: 0;
  height: auto;
  margin-right: 0;
}

/* 检查页的目录无可勾选位，用同宽占位保持缩进一致 */
.tree-check--placeholder {
  display: inline-block;
  width: 14px;
  height: 14px;
}

.tree-icon {
  flex-shrink: 0;
  font-size: 15px;
}

.tree-name {
  overflow: hidden;
  font-size: 13px;
  color: var(--el-text-color-primary);
  text-overflow: ellipsis;
  white-space: nowrap;
}

.tree-tag {
  flex-shrink: 0;
  font-size: 11px;
  color: var(--el-text-color-placeholder);
}

.tree-size {
  flex-shrink: 0;
  margin-left: auto;
  padding-left: 8px;
  font-size: 12px;
  color: var(--el-text-color-secondary);
  font-variant-numeric: tabular-nums;
}

.browse-tip {
  flex-shrink: 0;
  font-size: 12px;
  color: var(--el-color-warning);
}

/* 右栏：已选清单，固定宽度，清单内部滚动 */
.fp-picked {
  display: flex;
  flex: 0 0 300px;
  flex-direction: column;
  gap: 6px;
  min-height: 0;
  padding-left: 12px;
  border-left: 1px solid var(--el-border-color-lighter);
}

.fp-picked__head {
  display: flex;
  flex-shrink: 0;
  align-items: center;
  gap: 6px;
}

.fp-picked__title {
  font-size: 13px;
  font-weight: 600;
  color: var(--el-text-color-primary);
}

.fp-picked__count {
  font-size: 12px;
  color: var(--el-color-primary);
}

/* 标题栏的图标按钮：添加当前文件夹 / 清空 */
/* 数据根不再在右栏展示，样式随之移除（值仍由 addPicked 自动计算并提交） */

/* 已选清单容器：高度由 flex 撑满右栏，树本体在内部自适应滚动 */
.fp-picked__body {
  display: flex;
  flex: 1;
  flex-direction: column;
  gap: 6px;
  min-height: 0;
  overflow-y: auto;

  /* 空清单也保留一块可投放区域，否则只能靠「添加当前文件夹」 */
  &.is-empty {
    padding: 4px;
  }

  /* 让共享树组件撑满右栏剩余高度，滚动发生在树内部而非整块右栏 */
  :deep(.sft) {
    display: flex;
    flex: 1;
    flex-direction: column;
    min-height: 0;
  }

  :deep(.sft__tree) {
    flex: 1;
    min-height: 0;
  }
}

.icon-btn {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  padding: 0;
  font-size: 15px;
  color: var(--el-text-color-regular);
  cursor: pointer;
  background: none;
  border: none;
  border-radius: 4px;

  &:hover {
    color: var(--el-color-primary);
    background: var(--el-fill-color-light);
  }

  &:disabled {
    color: var(--el-text-color-disabled);
    cursor: not-allowed;
    background: none;
  }
}

/* 底部：只留操作按钮（已选清单与清空已在右栏，不再重复） */
.fp-footer {
  display: flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: flex-end;
  gap: 12px;
}

.fp-footer__btns {
  display: flex;
  gap: 8px;
  flex-shrink: 0;
}
</style>
