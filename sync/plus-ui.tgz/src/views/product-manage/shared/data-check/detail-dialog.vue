<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
import { computed, ref, watch } from 'vue';
import { ElMessage } from 'element-plus';
import { Files, Warning, CopyDocument } from '@element-plus/icons-vue';
import { isMetadataCheckAccepted, isMetadataCheckFinished, metadataCheckStateOf } from '@/api/product-manage/platform/metadata-check';
import type { MetadataCheckFileResult, MetadataCheckTaskSummary } from '@/api/product-manage/platform/metadata-check';
import { errorStats, errorToText, formatMessage, indexErrors, type CheckError, type IndexedError } from './error-utils';

/**
 * 检查任务详情：概览指标 + 基础信息 + 检查结果（清单 / 逐文件结果 / 错误明细同一切换面板）。
 *
 * 版式 WHY：去掉旧版顶部结论横幅（大图标 + 进度条），「能否入库」的结论与执行状态收敛进
 * 基础信息描述项，避免第一眼被一张大卡片占满；清单、逐文件结果与错误明细收进同一个可切换面板，
 * 错误明细按文件分组折叠，展开后按字段分列成表格，便于逐条定位与复制；用户可见处不暴露英文契约字段名。
 *
 * CONSTRAINT 状态与结论判据统一走接口层（isMetadataCheckFinished / isMetadataCheckAccepted），
 * 页面**不再自己拼字面量**：实测 9 条记录 state 全是中文「成功」，其中 4 条 decision=「拒绝」，
 * 用 state 当通过判据会把不合格记录显示成「通过」。progress.stage 只作进度展示。
 *
 * CONSTRAINT 空数组文案必须中性：实测 cd4037b6 的 checkedFiles / dataFiles / fileResults
 * 三个都是 []，而 files 有 2 项、fileCount=2 —— 说明历史记录未回填扫描结果。
 * 「[]」无法区分「确实没有」与「后端未回填」，因此一律写「后端未返回…」，
 * **绝不能**渲染成「0 个文件检查通过」（会让人以为检查跑过且全部未通过）。
 */
defineOptions({ name: 'MetadataCheckDetail' });

const props = defineProps<{ detail: MetadataCheckTaskSummary }>();

/** 检查结果切换：清单分组、逐文件结果、错误明细收进同一个面板，避免多段长列表把结论挤到屏幕外 */
type ViewKey = 'requestedFiles' | 'files' | 'checkedFiles' | 'dataFiles' | 'fileResults' | 'errors';
const activeView = ref<ViewKey>('files');

/**
 * 状态展示口径统一走接口层词表（与列表页同一份）。
 *
 * CONSTRAINT 详情页与列表页必须显示同一个标签文案：旧版详情直接用后端原文（「成功」），
 * 而列表显示「执行完成」，同一个任务在两处叫法不同。现在两处都取 metadataCheckStateOf。
 */
const stateView = computed(() => metadataCheckStateOf(props.detail.state));

/**
 * 状态标签文案：识别为已知状态时用词表文案（与列表页完全一致），
 * 未识别时保留后端原文——原文比「未知」更有诊断价值。
 */
const stateText = computed(() => {
  const raw = String(props.detail.state ?? '').trim();
  if (!raw) return pt('未返回');
  return stateView.value.key ? stateView.value.label : raw;
});

/** 状态标签类型：与列表页同源 */
function stateTagType(state?: string): 'success' | 'warning' | 'info' | 'primary' | 'danger' {
  return metadataCheckStateOf(state).type;
}

/** 是否已执行结束（不代表通过） */
const finished = computed(() => isMetadataCheckFinished(props.detail));

/** 是否可入库（accepted 布尔优先；缺失且无法识别时 fail-closed 为 false） */
const accepted = computed(() => isMetadataCheckAccepted(props.detail));

/** 结论标签：未结束时不能说「接受/拒绝」，否则 202 受理的单会被误读成结论 */
const decisionText = computed(() => {
  if (!finished.value) return pt('检查未结束（暂无结论）');
  return accepted.value ? pt('接受（可入库）') : pt('拒绝（不可入库）');
});

/**
 * 原始选择清单（契约 2026-11-11：files 允许目录，详情用 requestedFiles 保留原始选择）。
 * 目录会被后端递归展开，因此它与下面的 files（展开后叶子文件）可能不一致。
 */
const requestedFiles = computed<string[]>(() => normalizeList(props.detail.requestedFiles));

/** 完整选择清单（契约：string[]；目录已在任务执行期展开为叶子文件） */
const files = computed<string[]>(() => normalizeList(props.detail.files));

/**
 * 是否发生目录展开（用于「原始选择」tab 与顶部提示横幅）。
 *
 * 判据两条取其一，避免纯文件提交时多出一个与「选择清单」完全重复的 tab：
 *   - result.expanded 标志（契约明示）；
 *   - 或 requestedFiles 与 files（展开后）内容不同（后端未回填该标志时的兜底）。
 */
const hasExpansion = computed(() => {
  const r = props.detail.result as Record<string, unknown> | null | undefined;
  const byFlag = !!(r && typeof r === 'object' && r.expanded);
  const requested = requestedFiles.value;
  const byDiff = requested.length > 0 && (requested.length !== files.value.length || requested.some((p, i) => p !== files.value[i]));
  return byFlag || byDiff;
});

/** 实际参与检查的子集；空数组不代表「0 个通过」，见文件头 CONSTRAINT */
const checkedFiles = computed<string[]>(() => normalizeList(props.detail.checkedFiles));

/** 数据文件子集 */
const dataFiles = computed<string[]>(() => normalizeList(props.detail.dataFiles));

/** 逐文件结果 */
const fileResults = computed<MetadataCheckFileResult[]>(() => (Array.isArray(props.detail.fileResults) ? props.detail.fileResults : []));

/**
 * files 归一：契约是 string[]，但历史数据里可能存在对象数组（旧类型说谎来源）。
 *
 * WHY 兜底：直接 `.length` 渲染对象会显示成 [object Object]，或按对象取值渲染空白行。
 * 这里统一转成字符串展示，不丢条目——宁可显示原文，也不静默过滤掉「看起来解析不了」的项。
 */
function normalizeList(raw: unknown): string[] {
  if (!Array.isArray(raw)) return [];
  return raw.map((item) => {
    if (typeof item === 'string') return item;
    if (item && typeof item === 'object') {
      const o = item as Record<string, unknown>;
      const name = typeof o.path === 'string' ? o.path : typeof (o as { name?: unknown }).name === 'string' ? String(o.name) : '';
      if (name) return name;
      return JSON.stringify(item);
    }
    return String(item ?? '');
  });
}

/**
 * 清单分组。empty 文案逐组保留旧版中性口径——
 * checkedFiles / dataFiles 明确点出「可能是尚未扫描完成，也可能是历史记录未回填」，
 * fileResults 的空态在下方表格里单独给出，不混入此处。
 *
 * requestedFiles 是 2026-11-11 目录展开契约新增：仅在确实发生目录展开时列入分组
 * （hasExpansion），纯文件提交 / 老任务不显示这个 tab，避免多一个重复或永远空的面板。
 */
const listGroups = computed(() => [
  ...(hasExpansion.value && requestedFiles.value.length
    ? [
        {
          key: 'requestedFiles' as const,
          label: pt('原始选择'),
          field: 'requestedFiles',
          count: requestedFiles.value.length,
          items: requestedFiles.value,
          empty: pt('后端未返回原始选择清单。')
        }
      ]
    : []),
  {
    key: 'files' as const,
    label: pt('选择清单'),
    field: 'files',
    count: files.value.length,
    items: files.value,
    empty: pt('后端未返回选择清单。')
  },
  {
    key: 'checkedFiles' as const,
    label: pt('检查子集'),
    field: 'checkedFiles',
    count: checkedFiles.value.length,
    items: checkedFiles.value,
    empty: pt('后端未返回该清单。可能是尚未扫描完成，也可能是历史记录未回填，无法据此判断「没有文件通过」。')
  },
  {
    key: 'dataFiles' as const,
    label: pt('数据文件'),
    field: 'dataFiles',
    count: dataFiles.value.length,
    items: dataFiles.value,
    empty: pt('后端未返回该清单。可能是尚未扫描完成，也可能是历史记录未回填。')
  }
]);

/** 逐文件结果里成功/跳过等状态的标签类型（中文词表见契约） */
function resultTagType(status?: string): 'success' | 'warning' | 'danger' | 'info' {
  const s = String(status ?? '').trim();
  if (s === '成功' || s.toUpperCase() === 'SUCCESS' || s.toUpperCase() === 'SUCCEEDED') return 'success';
  if (s === '警告') return 'warning';
  if (s === '失败') return 'danger';
  return 'info';
}

/** 进度阶段中文映射：契约 progress.stage 为英文机器码，用户可见处统一转中文；未知值原样展示便于排障 */
const STAGE_TEXT: Record<string, string> = {
  queued: pt('已入队'),
  opening_shared_source: pt('打开共享来源'),
  opening_registered_share: pt('打开登记共享'),
  scanning_metadata_files: pt('扫描元数据文件'),
  verifying_upload: pt('校验上传'),
  checking_metadata_files: pt('检查元数据文件'),
  saving_check_report: pt('保存检查报告'),
  succeeded: pt('执行完成'),
  partial_success: pt('部分完成'),
  failed: pt('执行失败'),
  cancelled: pt('已取消')
};

const progressText = computed(() => {
  const p = props.detail.progress;
  if (!p) return '';
  const seg: string[] = [];
  if (typeof p.completed === 'number' && typeof p.total === 'number') seg.push(p.completed + ' / ' + p.total);
  if (p.stage) {
    const raw = String(p.stage).trim();
    seg.push(STAGE_TEXT[raw.toLowerCase()] || raw);
  }
  return seg.join('  ·  ');
});

const errors = computed<CheckError[]>(() => props.detail.errors || []);
const stats = computed(() => errorStats(errors.value));
const indexedErrors = computed<IndexedError[]>(() => indexErrors(errors.value));

/**
 * 错误按文件一一对应。
 *
 * CONSTRAINT 错误契约没有独立 path 字段；实测 sourceLayerKey 形如 `相对路径#图层名`
 * （例：`数据二/分类要素属性元数据二.SMS#flyssx_sx`）。取 # 之前的部分与 fileResults/checkedFiles
 * 的路径匹配即可把错误归到文件；没有 sourceLayerKey 的条目归入「未关联到文件」，绝不丢弃，
 * 保证分组后错误总数与完整账本一致。
 */
const UNASSIGNED_FILE = pt('未关联到文件');
function errorFilePath(error: CheckError): string {
  const raw = String(error.sourceLayerKey ?? '').trim();
  if (!raw) return UNASSIGNED_FILE;
  return raw.split('#')[0].trim() || UNASSIGNED_FILE;
}

const errorsByFile = computed(() => {
  const groups = new Map<string, IndexedError[]>();
  for (const item of indexedErrors.value) {
    const path = errorFilePath(item.error);
    const group = groups.get(path);
    if (group) group.push(item);
    else groups.set(path, [item]);
  }
  return Array.from(groups, ([path, items]) => ({ path, items }));
});

/**
 * 错误明细按文件折叠：默认只展示文件清单，展开哪个文件才展示哪个表格。
 * CONSTRAINT 展开状态按文件路径保存；详情数据变化时清掉已不存在的路径，
 * 避免残留项让「全部展开」的判定失真。
 */
const expandedErrorFiles = ref<string[]>([]);
const allErrorFilesExpanded = computed(() => errorsByFile.value.length > 0 && expandedErrorFiles.value.length === errorsByFile.value.length);
watch(errorsByFile, (groups) => {
  const paths = new Set(groups.map((group) => group.path));
  expandedErrorFiles.value = expandedErrorFiles.value.filter((path) => paths.has(path));
});

/** 一键在全部展开 / 全部收起之间切换 */
function toggleAllErrorFiles() {
  expandedErrorFiles.value = allErrorFilesExpanded.value ? [] : errorsByFile.value.map((group) => group.path);
}

/** 统一切换页签：清单分组沿用 listGroups，另加逐文件结果与错误明细 */
const detailTabs = computed(() => [
  ...listGroups.value.map((g) => ({ ...g, kind: 'list' as const })),
  { key: 'fileResults' as const, label: pt('逐文件结果'), count: fileResults.value.length, kind: 'result' as const },
  { key: 'errors' as const, label: pt('错误明细'), count: stats.value.total, kind: 'error' as const }
]);
const activeTab = computed(() => detailTabs.value.find((t) => t.key === activeView.value) || detailTabs.value[0]);
/** 当前清单分组；非清单页签时仍指向 files，仅模板的 list 分支会用到它 */
const activeListGroup = computed(() => listGroups.value.find((g) => g.key === activeView.value) || listGroups.value[0]);

/** 概览指标行：任务信息统计按评审口径只保留「文件数 / 错误总数」两项，用分隔线而非色块（比报表弹窗轻一档） */
const summaryMetrics = computed(() => [
  { key: 'files', label: pt('文件数'), value: props.detail.fileCount ?? '-', icon: Files, tone: 'neutral' },
  { key: 'errors', label: pt('错误总数'), value: stats.value.total, icon: Warning, tone: stats.value.total ? 'danger' : 'neutral' }
]);

/**
 * 来源描述。
 *
 * CONSTRAINT 分支判断用 sourceType（机器码），sourceKind/sourceKindCode 只展示——
 * 实测同一响应里 sourceKindCode=client_upload 与 sourceType=upload 并存，混用会误判。
 */
const sourceType = computed(() => String(props.detail.sourceType ?? '').trim());
const sourceKindText = computed(() => String(props.detail.sourceKind ?? '').trim() || sourceType.value || '-');
const sourceText = computed(() => {
  const d = props.detail;
  // 用户可见处一律不展示 uid（评审要求去 UUID），只给来源类型与可读路径
  if (sourceType.value === 'upload') return pt('本地上传');
  if (sourceType.value === 'registered_share') return '登记共享' + (d.dataRootPath ? ' · ' + d.dataRootPath : '');
  if (sourceType.value === 'direct_shared_path') return d.dataRootPath || '共享路径';
  // 历史数据可能没有 sourceType：退回展示路径，标注不确定来源
  return d.dataRootPath || d.sourcePath || '-';
});

/** 尺寸展示（fileResults.sizeBytes 可选） */
function fmtBytes(n?: number | null): string {
  if (n == null) return '-';
  const u = ['B', 'KB', 'MB', 'GB'];
  let v = n;
  let i = 0;
  while (v >= 1024 && i < u.length - 1) {
    v /= 1024;
    i++;
  }
  return v.toFixed(2) + ' ' + u[i];
}

/** sha256 截断展示（完整值放 title） */
function shortSha(v?: string): string {
  const s = String(v ?? '');
  if (!s) return '-';
  return s.length > 12 ? s.slice(0, 12) + '…' : s;
}

/** fileResults 是否含可选列（全空时不显示这些列，避免一片「-」） */
const hasSizeBytes = computed(() => fileResults.value.some((r) => typeof r.sizeBytes === 'number'));
const hasRecordCount = computed(() => fileResults.value.some((r) => typeof r.recordCount === 'number'));
const hasSha = computed(() => fileResults.value.some((r) => !!r.sha256));

/** 复制全部错误：与错误报表弹窗输出同一份纯文本快照格式 */
async function copyAllErrors() {
  const text = indexedErrors.value.map((item) => errorToText(item.error, item.index)).join('\n\n');
  try {
    await navigator.clipboard.writeText(text);
    ElMessage.success(pt('已复制全部错误明细'));
  } catch {
    ElMessage.warning(pt('复制失败，请手动选择文本'));
  }
}
</script>

<template>
  <div class="detail-dialog">
    <!-- 概览指标行 -->
    <div class="metric-strip">
      <div v-for="m in summaryMetrics" :key="m.key" class="strip-cell" :class="'strip-cell--' + m.tone">
        <div class="strip-icon">
          <el-icon><component :is="m.icon" /></el-icon>
        </div>
        <div class="strip-text">
          <span class="strip-value">{{ m.value }}</span>
          <span class="strip-label">{{ m.label }}</span>
        </div>
      </div>
    </div>

    <!-- 基础信息 -->
    <section class="section">
      <header class="section-head">
        <span class="section-accent" />
        <h3 class="section-title">{{ pt('基础信息') }}</h3>
        <span class="section-hint">{{ pt('检查范围与数据来源') }}</span>
      </header>
      <el-descriptions :column="2" border size="small" class="info-desc">
        <el-descriptions-item :label="pt('产品类别')">{{ detail.productCategoryPath || '-' }}</el-descriptions-item>
        <el-descriptions-item :label="pt('检查范围')">{{ detail.checkScope || '-' }}</el-descriptions-item>
        <el-descriptions-item :label="pt('来源类型')">{{ sourceKindText }}</el-descriptions-item>
        <el-descriptions-item :label="pt('执行状态')">
          <el-tag :type="stateTagType(detail.state)" size="small">{{ stateText }}</el-tag>
        </el-descriptions-item>
        <el-descriptions-item :label="pt('检查结论')">{{ decisionText }}</el-descriptions-item>
        <el-descriptions-item :label="pt('执行进度')">{{ progressText || '-' }}</el-descriptions-item>
        <el-descriptions-item :label="pt('来源位置')" :span="2">{{ sourceText }}</el-descriptions-item>
      </el-descriptions>
    </section>

    <!-- 检查结果：清单 / 逐文件结果 / 错误明细合并为一个可切换面板 -->
    <section class="section">
      <header class="section-head">
        <span class="section-accent" />
        <h3 class="section-title">{{ pt('检查结果') }}</h3>
        <span class="section-hint">{{ pt('按清单 / 逐文件结果 / 错误明细切换') }}</span>
      </header>
      <div v-if="hasExpansion && activeTab.kind === 'list'" class="list-panel__tip">
        {{
          pt(
            '本次选择包含目录，后端已在任务执行期递归展开；「原始选择」为提交时的清单（可能含目录）， 「选择清单」为展开后的叶子文件。目录本身不参与指纹与检查。'
          )
        }}
      </div>
      <div class="list-panel">
        <div class="list-switch-row">
          <el-radio-group v-model="activeView" size="small" class="list-switch">
            <el-radio-button v-for="t in detailTabs" :key="t.key" :value="t.key">
              {{ t.label }}<span class="seg-count">{{ t.count }}</span>
            </el-radio-button>
          </el-radio-group>
          <span v-if="activeView !== 'errors'" class="list-hint">共 {{ activeTab.count }} 项</span>
          <template v-else-if="errorsByFile.length">
            <span class="error-file-summary">共 {{ errorsByFile.length }} 个文件 · {{ errors.length }} 条错误</span>
            <el-button class="error-toggle" link size="small" @click="toggleAllErrorFiles">
              {{ allErrorFilesExpanded ? '全部收起' : '全部展开' }}
            </el-button>
          </template>
          <el-button
            v-if="activeView === 'errors' && errors.length"
            class="section-action"
            link
            size="small"
            :icon="CopyDocument"
            @click="copyAllErrors"
            >复制全部</el-button
          >
        </div>
        <template v-if="activeTab.kind === 'list'">
          <div v-if="!activeListGroup.items.length" class="empty-note">{{ activeListGroup.empty }}</div>
          <ul v-else class="plain-list">
            <li v-for="(f, i) in activeListGroup.items" :key="f + i" class="plain-item">
              <span class="idx">{{ i + 1 }}</span>
              <span class="path-text" :title="f">{{ f }}</span>
            </li>
          </ul>
        </template>

        <!-- 逐文件结果 -->
        <template v-else-if="activeTab.kind === 'result'">
          <div v-if="!fileResults.length" class="empty-note">后端未返回逐文件结果。不能据此认为「0 个文件通过」。</div>
          <el-table v-else :data="fileResults" size="small" border max-height="300" class="result-table">
            <el-table-column label="路径" min-width="220" show-overflow-tooltip>
              <template #default="{ row }">
                <span class="path-text" :title="row.path">{{ row.path || '-' }}</span>
              </template>
            </el-table-column>
            <el-table-column label="格式" width="88">
              <template #default="{ row }">{{ row.kind || '-' }}</template>
            </el-table-column>
            <el-table-column label="状态" width="88">
              <template #default="{ row }">
                <el-tag v-if="row.status" :type="resultTagType(row.status)" size="small">{{ row.status }}</el-tag>
                <span v-else>-</span>
              </template>
            </el-table-column>
            <el-table-column label="错误数" width="78" align="right">
              <template #default="{ row }">{{ typeof row.errorCount === 'number' ? row.errorCount : '-' }}</template>
            </el-table-column>
            <el-table-column v-if="hasRecordCount" label="记录数" width="88" align="right">
              <template #default="{ row }">{{ typeof row.recordCount === 'number' ? row.recordCount : '-' }}</template>
            </el-table-column>
            <el-table-column v-if="hasSizeBytes" label="大小" width="100" align="right">
              <template #default="{ row }">{{ fmtBytes(row.sizeBytes) }}</template>
            </el-table-column>
            <el-table-column v-if="hasSha" label="校验值" width="140">
              <template #default="{ row }">
                <span class="mono" :title="row.sha256">{{ shortSha(row.sha256) }}</span>
              </template>
            </el-table-column>
          </el-table>
        </template>

        <!-- 错误明细：按文件折叠，展开后展示该文件的错误表格（每条错误与所在文件一一对应） -->
        <template v-else>
          <div v-if="stats.resolved" class="resolved-hint resolved-hint--inline">已解决 {{ stats.resolved }}</div>
          <el-collapse v-if="errorsByFile.length" v-model="expandedErrorFiles" class="error-collapse" expand-icon-position="left">
            <el-collapse-item v-for="group in errorsByFile" :key="group.path" :name="group.path">
              <template #title>
                <div class="error-file-title">
                  <el-icon class="error-file-icon"><Files /></el-icon>
                  <span class="path-text" :title="group.path">{{ group.path }}</span>
                  <span class="error-file-count">{{ group.items.length }} 条</span>
                </div>
              </template>
              <el-table :data="group.items" class="error-table" size="small" border max-height="300">
                <el-table-column label="序号" prop="index" width="64" align="center" />
                <el-table-column label="错误码" width="140">
                  <template #default="{ row }">{{ row.error.code || '未知' }}</template>
                </el-table-column>
                <el-table-column label="字段" min-width="140">
                  <template #default="{ row }">{{ row.error.fieldKey || '-' }}</template>
                </el-table-column>
                <el-table-column label="错误描述" min-width="320">
                  <template #default="{ row }">
                    <span class="error-message">{{ formatMessage(row.error.message) }}</span>
                  </template>
                </el-table-column>
              </el-table>
            </el-collapse-item>
          </el-collapse>
          <div v-else class="empty-note">后端未返回错误明细。</div>
        </template>
      </div>
    </section>
  </div>
</template>

<style scoped lang="scss">
/* 弹窗 body 设为 padding:0，内边距由组件自管；整页只保留 body 这一条滚动轴 */
.detail-dialog {
  display: flex;
  flex-direction: column;
  gap: 18px;
  padding: 18px;
}

/* ---------- 错误明细列表（按文件分组折叠） ---------- */
.error-collapse {
  border-top: none;
  border-bottom: none;

  :deep(.el-collapse-item) {
    margin-bottom: 10px;
    overflow: hidden;
    border: 1px solid var(--el-border-color-lighter);
    border-radius: 6px;

    &:last-child {
      margin-bottom: 0;
    }
  }

  :deep(.el-collapse-item__header) {
    height: auto;
    min-height: 36px;
    gap: 8px;
    padding: 6px 10px;
    background: var(--el-fill-color-lighter);
    border-bottom: none;
  }

  :deep(.el-collapse-item__wrap) {
    border-bottom: none;
  }

  :deep(.el-collapse-item__content) {
    padding: 0;
  }
}

.error-file-title {
  display: flex;
  flex: 1;
  align-items: center;
  gap: 8px;
  min-width: 0;

  .path-text {
    flex: 1;
    min-width: 0;
  }
}

.error-file-icon {
  display: inline-flex;
  color: var(--el-color-primary);
}

.error-file-count {
  flex: none;
  color: var(--el-text-color-secondary);
  font-size: 12px;
  font-variant-numeric: tabular-nums;
}

.error-file-summary {
  color: var(--el-text-color-placeholder);
  font-size: 11.5px;
  font-variant-numeric: tabular-nums;
}

.error-toggle {
  font-size: 12px;
}

.error-table {
  width: 100%;
}

.error-message {
  display: inline-block;
  white-space: pre-wrap;
  word-break: break-word;
  line-height: 1.55;
}

/* ---------- 概览指标行 ---------- */
.metric-strip {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  padding: 12px 0;
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 8px;
  background: var(--el-fill-color-blank);
}

.strip-cell {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  padding: 0 12px;
  border-right: 1px solid var(--el-border-color-lighter);

  &:last-child {
    border-right: 0;
  }
}

.strip-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  border-radius: 6px;
  background: var(--el-fill-color);
  color: var(--el-text-color-secondary);
  font-size: 15px;
}

.strip-cell--danger .strip-icon {
  background: var(--el-color-danger-light-9);
  color: var(--el-color-danger);
}
.strip-cell--warning .strip-icon {
  background: var(--el-color-warning-light-9);
  color: var(--el-color-warning);
}
.strip-cell--success .strip-icon {
  background: var(--el-color-success-light-9);
  color: var(--el-color-success);
}

.strip-text {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}

.strip-value {
  color: var(--el-text-color-primary);
  font-size: 19px;
  font-weight: 650;
  font-variant-numeric: tabular-nums;
  line-height: 1.1;
}

.strip-cell--danger .strip-value {
  color: var(--el-color-danger);
}
.strip-cell--warning .strip-value {
  color: var(--el-color-warning);
}

.strip-label {
  color: var(--el-text-color-secondary);
  font-size: 12px;
  white-space: nowrap;
}

/* ---------- 通用分节 ---------- */
.section {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.section-head {
  display: flex;
  align-items: center;
  gap: 8px;
  min-height: 22px;
}

.section-accent {
  flex: 0 0 auto;
  width: 3px;
  height: 14px;
  border-radius: 2px;
  background: var(--el-color-primary);
}

.section-title {
  margin: 0;
  color: var(--el-text-color-primary);
  font-size: 14px;
  font-weight: 600;
}

.section-hint {
  color: var(--el-text-color-placeholder);
  font-size: 12px;
}

.count-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 20px;
  height: 20px;
  padding: 0 6px;
  border-radius: 10px;
  background: var(--el-fill-color);
  color: var(--el-text-color-secondary);
  font-size: 12px;
  font-weight: 500;
  font-variant-numeric: tabular-nums;
}

.resolved-hint {
  color: var(--el-color-success);
  font-size: 12px;
}

.section-action {
  margin-left: auto;
  font-size: 12px;
}

.info-desc {
  :deep(.el-descriptions__label) {
    color: var(--el-text-color-secondary);
    font-weight: 500;
  }
}

/* ---------- 文件清单面板 ---------- */
.list-panel__tip {
  margin-bottom: 8px;
  padding: 8px 12px;
  border-left: 2px solid var(--el-color-primary);
  border-radius: 0 4px 4px 0;
  background: var(--el-color-primary-light-9);
  color: var(--el-text-color-regular);
  font-size: 12px;
  line-height: 1.6;
}

.list-panel {
  padding: 12px;
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 8px;
  background: var(--el-fill-color-blank);
}

.list-switch-row {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 10px;
  margin-bottom: 10px;
}

.seg-count {
  display: inline-block;
  margin-left: 6px;
  padding: 0 5px;
  border-radius: 8px;
  background: var(--el-fill-color);
  color: var(--el-text-color-secondary);
  font-size: 11px;
  font-variant-numeric: tabular-nums;
}

.list-hint {
  margin-left: auto;
  color: var(--el-text-color-placeholder);
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 11.5px;
}

.empty-note {
  padding: 10px 12px;
  border-left: 2px solid var(--el-border-color);
  border-radius: 0 4px 4px 0;
  background: var(--el-fill-color-lighter);
  color: var(--el-text-color-secondary);
  font-size: 12.5px;
  line-height: 1.6;
}

.plain-list {
  display: flex;
  flex-direction: column;
  gap: 4px;
  max-height: 220px;
  margin: 0;
  padding: 0;
  overflow-y: auto;
  list-style: none;
}

.plain-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 5px 8px;
  border-radius: 4px;
  background: var(--el-bg-color);
  font-size: 13px;
}

.idx {
  flex: 0 0 auto;
  min-width: 20px;
  color: var(--el-text-color-placeholder);
  font-variant-numeric: tabular-nums;
  text-align: right;
}

.path-text {
  overflow: hidden;
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.mono {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 12px;
}

.result-table {
  width: 100%;
}

@media (max-width: 620px) {
  .metric-strip {
    grid-template-columns: repeat(2, 1fr);
    gap: 12px 0;
  }
  .strip-cell:nth-child(2) {
    border-right: 0;
  }
  .list-hint {
    margin-left: 0;
  }
}
</style>
