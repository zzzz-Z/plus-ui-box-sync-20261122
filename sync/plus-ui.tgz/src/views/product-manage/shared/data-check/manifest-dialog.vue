<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
import { onMounted, ref } from 'vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import { Delete } from '@element-plus/icons-vue';
import {
  deleteCheckManifest,
  listCheckManifests,
  type MetadataManifestFile,
  type MetadataManifestSummary
} from '@/api/product-manage/platform/metadata-check';

/** 清单管理弹窗：按检查任务列出关联清单，支持软删除。弹窗内只保留一个列表。 */
defineOptions({ name: 'MetadataCheckManifestDialog' });

const props = defineProps<{
  /** 关联检查任务 uid；为空时展示全部清单 */
  taskUid?: string;
}>();

const loading = ref(false);
const items = ref<MetadataManifestSummary[]>([]);

/** 文件摘要：文件名 + 格式 */
function fileBrief(f: MetadataManifestFile): string {
  const name = String(f?.fileName || '').trim() || '-';
  const fmt = String(f?.formatName || f?.format || '').trim();
  return fmt ? name + '  [' + fmt + ']' : name;
}

async function load() {
  loading.value = true;
  try {
    const res = await listCheckManifests({ taskUid: props.taskUid || undefined, limit: 100 });
    items.value = Array.isArray(res?.data?.items) ? res.data.items : [];
  } catch {
    // 失败原因由响应拦截器统一弹出
  } finally {
    loading.value = false;
  }
}

async function doDelete(row: Record<string, any>) {
  try {
    await ElMessageBox.confirm(pt('删除后该清单将从列表中移除，且不可恢复。确定删除此清单？'), pt('警告'), { type: 'warning' });
  } catch {
    return;
  }
  try {
    await deleteCheckManifest(row.manifestUid);
    ElMessage.success(pt('已删除清单'));
    items.value = items.value.filter((x) => x.manifestUid !== row.manifestUid);
  } catch {
    // 失败原因由响应拦截器统一弹出
  }
}

onMounted(load);
defineExpose({ load });
</script>

<template>
  <el-table v-loading="loading" :data="items" size="small" border height="400" class="manifest-table" row-key="manifestUid">
    <el-table-column :label="pt('序号')" type="index" width="60" align="center" />
    <el-table-column :label="pt('清单名称')" min-width="200" show-overflow-tooltip>
      <template #default="{ row }">
        <span>{{ row.task?.taskName || '-' }}</span>
      </template>
    </el-table-column>
    <el-table-column label="文件清单" min-width="260" show-overflow-tooltip>
      <template #default="{ row }">
        <span>{{ (row.files || []).map(fileBrief).join('、') || '-' }}</span>
      </template>
    </el-table-column>
    <el-table-column label="文件数" prop="fileCount" width="90" align="center" />
    <el-table-column label="创建时间" prop="createdAt" width="150" />
    <el-table-column label="操作" width="90" align="center" fixed="right">
      <template #default="{ row }">
        <el-button link type="danger" :icon="Delete" @click="doDelete(row)">删除</el-button>
      </template>
    </el-table-column>
    <template #empty><el-empty description="暂无关联清单" :image-size="60" /></template>
  </el-table>
</template>

<style scoped lang="scss">
.manifest-table {
  width: 100%;
  padding: 0 12px 12px;
}
</style>
