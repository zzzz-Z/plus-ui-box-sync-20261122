<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
import { computed } from 'vue';
import { ElMessage } from 'element-plus';
import { CopyDocument } from '@element-plus/icons-vue';
import {
  isMetadataCheckAccepted,
  isMetadataCheckFinished,
  metadataCheckStateOf,
  type MetadataCheckTaskSummary
} from '@/api/product-manage/platform/metadata-check';
import { errorToText, formatMessage, indexErrors, type CheckError, type IndexedError } from './error-utils';

/**
 * 错误报表：一次检查任务的基本信息 + 完整错误账本。
 *
 * 版式 = 「任务基本信息（结论/状态醒目） → 错误列表」两段，只展示真正需要看的内容。
 * 基本信息取详情接口的常用字段（任务名 / 产品类别 / 检查范围 / 来源 / 状态 / 结论 / 文件数 / 记录数），
 * 不展示任何 UUID 等内部字段；结论与状态口径复用接口层词表，与列表页、详情页完全一致。
 *
 * CONSTRAINT 字段严格按最新契约 errors[]（code / message / resolved / fieldKey / itemUid 等），
 * 不改写后端原文：formatMessage 只做换行排版，复制输出保持 #序号 [code] / message / 数据项 快照格式。
 */
defineOptions({ name: 'MetadataCheckErrorReport' });

const props = defineProps<{
  errors: any[];
  detail?: MetadataCheckTaskSummary;
}>();

/** 完整账本（带原始序号） */
const allErrors = computed<CheckError[]>(() => (Array.isArray(props.errors) ? props.errors : []));
const indexed = computed<IndexedError[]>(() => indexErrors(allErrors.value));

/** 状态：与列表页、详情页同词表，未识别时保留后端原文 */
const stateView = computed(() => metadataCheckStateOf(props.detail?.state));
const stateText = computed(() => {
  const raw = String(props.detail?.state ?? '').trim();
  if (!raw) return '-';
  return stateView.value.key ? stateView.value.label : raw;
});

/** 结论：accepted 布尔优先，未结束时不能说「接受/拒绝」 */
const finished = computed(() => (props.detail ? isMetadataCheckFinished(props.detail) : false));
const accepted = computed(() => (props.detail ? isMetadataCheckAccepted(props.detail) : false));
const decisionText = computed(() => {
  if (!props.detail) return '-';
  if (!finished.value) return pt('检查未结束（暂无结论）');
  return accepted.value ? pt('接受（可入库）') : pt('拒绝（不可入库）');
});
const decisionType = computed(() => (!finished.value ? 'info' : accepted.value ? 'success' : 'danger'));

/** 行强调：未解决红、已解决淡化，用行样式代替状态列 */
function rowClass({ row }: any): string {
  return row?.error?.resolved ? 'row--resolved' : 'row--open';
}

/** 一键复制全部（沿用旧版格式，跨系统报障可直接粘贴） */
async function copyAll() {
  const text = indexed.value.map((item) => errorToText(item.error, item.index)).join('\n\n');
  try {
    await navigator.clipboard.writeText(text);
    ElMessage.success(pt('已复制全部错误明细'));
  } catch {
    ElMessage.warning(pt('复制失败，请手动选择文本'));
  }
}
</script>

<template>
  <div class="error-report">
    <!-- 标题 + 一键复制 -->
    <header class="report-head">
      <div class="report-title">
        <span class="title-accent" />
        <h3>{{ pt('错误明细') }}</h3>
        <span class="title-count">{{ allErrors.length }}</span>
      </div>
      <el-button v-if="allErrors.length" type="primary" plain size="small" :icon="CopyDocument" @click="copyAll">{{ pt('复制全部') }}</el-button>
    </header>

    <!-- 任务基本信息：结论/状态醒目，其余次要；不展示 UUID -->
    <section v-if="detail" class="task-info">
      <div class="info-head">
        <span class="task-name">{{ detail.taskName || '元数据检查任务' }}</span>
        <el-tag :type="decisionType" size="small" effect="dark">{{ decisionText }}</el-tag>
      </div>
      <el-descriptions :column="2" size="small" class="info-desc">
        <el-descriptions-item :label="pt('产品类别')">{{ detail.productCategoryPath || '-' }}</el-descriptions-item>
        <el-descriptions-item :label="pt('检查范围')">{{ detail.checkScope || '-' }}</el-descriptions-item>
        <el-descriptions-item :label="pt('来源类型')">{{ detail.sourceKind || '-' }}</el-descriptions-item>
        <el-descriptions-item :label="pt('执行状态')">{{ stateText }}</el-descriptions-item>
        <el-descriptions-item :label="pt('文件数')">{{ detail.fileCount ?? '-' }}</el-descriptions-item>
        <el-descriptions-item :label="pt('记录数')">{{ detail.recordCount ?? '-' }}</el-descriptions-item>
      </el-descriptions>
    </section>

    <!-- 错误列表：有则展示全部，无则空态；与检查任务详情同口径的四列 -->
    <el-table v-if="indexed.length" :data="indexed" class="report-table" :row-class-name="rowClass" size="small" border>
      <el-table-column :label="pt('序号')" prop="index" width="72" align="center">
        <template #default="{ row }">
          <span class="row-index" :class="row.error.resolved ? 'is-resolved' : 'is-open'"> <i class="row-dot" />{{ row.index }} </span>
        </template>
      </el-table-column>
      <el-table-column label="错误码" width="150" show-overflow-tooltip>
        <template #default="{ row }"
          ><span class="code-text">{{ row.error.code || '未知' }}</span></template
        >
      </el-table-column>
      <el-table-column label="字段" min-width="140" show-overflow-tooltip>
        <template #default="{ row }">{{ row.error.fieldKey || '-' }}</template>
      </el-table-column>
      <el-table-column label="错误描述" min-width="320" show-overflow-tooltip>
        <template #default="{ row }">{{ formatMessage(row.error.message) }}</template>
      </el-table-column>
    </el-table>
    <el-empty v-else description="当前检查任务没有错误明细" :image-size="56" />
  </div>
</template>

<style scoped lang="scss">
/* 弹窗 body 设为 padding:0，内边距由组件自管；整页只保留 body 这一条滚动轴，列表不另设高度 */
.error-report {
  display: flex;
  flex-direction: column;
  gap: 12px;
  padding: 18px;
}

.report-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}

.report-title {
  display: flex;
  align-items: center;
  gap: 8px;

  h3 {
    margin: 0;
    color: var(--el-text-color-primary);
    font-size: 15px;
    font-weight: 650;
  }
}

.title-accent {
  width: 3px;
  height: 15px;
  border-radius: 2px;
  background: var(--el-color-primary);
}

.title-count {
  padding: 0 7px;
  border-radius: 10px;
  background: var(--el-fill-color);
  color: var(--el-text-color-secondary);
  font-size: 12px;
  font-variant-numeric: tabular-nums;
}

/* 任务基本信息：浅底紧凑块，结论 tag 醒目，其余文字弱化 */
.task-info {
  padding: 10px 14px;
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 8px;
  background: var(--el-fill-color-blank);

  :deep(.el-descriptions__label) {
    color: var(--el-text-color-secondary);
    font-weight: 400;
  }

  :deep(.el-descriptions__content) {
    color: var(--el-text-color-primary);
  }
}

.info-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 8px;
}

.task-name {
  color: var(--el-text-color-primary);
  font-size: 14px;
  font-weight: 650;
}

/* 列表：未解决行序号红点强调，已解决行淡化，不占状态列 */
.row-index {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-variant-numeric: tabular-nums;

  .row-dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: currentColor;
  }
}
.row-index.is-open {
  color: var(--el-color-danger);
  font-weight: 600;
}
.row-index.is-resolved {
  color: var(--el-color-success);
}

.code-text {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-weight: 600;
}

.report-table {
  :deep(.row--resolved) {
    .cell {
      color: var(--el-text-color-secondary);
    }
  }
}
</style>
