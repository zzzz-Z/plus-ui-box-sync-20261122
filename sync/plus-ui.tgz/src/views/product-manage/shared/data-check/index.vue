<script setup lang="tsx">
import { Delete, Document, Plus, Refresh, Tickets, Upload, View } from '@element-plus/icons-vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import Edit from './edit.vue';
import DetailDialog from './detail-dialog.vue';
import ErrorReportDialog from './error-report-dialog.vue';
import ManifestDialog from './manifest-dialog.vue';
import { CHECK_PAGE_SIZE, checkTasks, loadCheckTasks, loadCheckTasksPage } from './state.js';
import {
  buildMetadataCheckPayload,
  deleteMetadataFileCheck,
  getMetadataFileCheck,
  isMetadataCheckAccepted,
  isMetadataCheckFinished,
  isMetadataCheckNotAccepted,
  isMetadataCheckStateActive,
  METADATA_CHECK_STATE_OPTIONS,
  metadataCheckNotAcceptedMessage,
  metadataCheckStateOf,
  normalizeMetadataCheckState,
  submitMetadataFileCheck
} from '@/api/product-manage/platform/metadata-check';
import { subscribeTaskEvents } from '@/api/product-manage/platform/tasks';
import type { MetadataCheckTaskSummary } from '@/api/product-manage/platform/metadata-check';
import { setSelection } from '../metacheck-selection';
import i18n from '@/lang/index';

/**
 * 当前页面所属的类别根（primary / result）。
 *
 * WHY 在此 inject 而非在 Edit 里：Edit 由 createDialog 用独立 render 挂到 body，
 * vnode 没有 parent 组件，祖先 provide 传不进去；本组件在正常组件树上，能 inject 到。
 */
const categoryRoot = inject<string>('product-category-root', '');

/**
 * 请求切到「数据入库」tab。
 *
 * WHY 用事件而不是直接改 tabName：tab 状态属 `shared/index.vue`（`defineModel<string>`），
 * 子页直接写它会绕过它的 `watch(tabName)` 副作用（清地图图层等），也破坏了
 * 「单一数据源」——两个组件各持一份 tab 值必然不同步。
 */
const emit = defineEmits<{ 'go-ingest': [] }>();

const t = (key: string) => i18n.global.t(key);

/** 规范状态键 → 语言包 key；未识别状态回落词表原文 */
const STATE_KEY_I18N: Record<string, string> = {
  CREATED: 'dataCheck.stateCreated',
  QUEUED: 'dataCheck.stateQueued',
  RUNNING: 'dataCheck.stateRunning',
  PAUSING: 'dataCheck.statePausing',
  PAUSED: 'dataCheck.statePaused',
  PARTIAL_SUCCESS: 'dataCheck.statePartialSuccess',
  SUCCESS: 'dataCheck.stateSuccess',
  FAILED: 'dataCheck.stateFailed',
  CANCELED: 'dataCheck.stateCanceled'
};

const queryParams = reactive({ keyword: '', state: '' });

const table = ref<InstanceType<typeof Table>>();

/**
 * 状态筛选项**取自接口层词表**，与状态列标签同源。
 *
 * WHY 不在此手写：手写第二份必然漂移——旧版筛选项写「通过」而列表显示「执行完成」，
 * 用户以为筛的是「可入库」。取同一张表后「筛什么就看到什么」。
 */
const statusOptions = computed(() => METADATA_CHECK_STATE_OPTIONS.map((o) => ({ ...o, label: t(STATE_KEY_I18N[o.value] || o.label) })));

/**
 * 状态列展示文案：走接口层词表（已结束统一为「执行完成」，避免与「检查通过」混淆）。
 *
 * CONSTRAINT 判据用 **state**，不能用 progress.stage：实测同一响应里 `state="成功"`
 * 而 `progress.stage="SUCCEEDED"`（英文），两者不同源。
 * 未识别状态由 metadataCheckStateOf 回落原文，不会把未知状态吞成「-」。
 */
function execLabel(row: MetadataCheckTaskSummary): string {
  const view = metadataCheckStateOf(row.state);
  const key = view.key && STATE_KEY_I18N[view.key];
  return key ? t(key) : view.label;
}

/** 执行状态标签类型；未识别状态归 info，避免未知状态被误判成成功 */
function execTagType(row: MetadataCheckTaskSummary): 'success' | 'warning' | 'info' | 'primary' | 'danger' {
  return metadataCheckStateOf(row.state).type;
}

/** 执行状态是否已结束（结束才有 conclusions 可谈） */
function execFinished(row: MetadataCheckTaskSummary): boolean {
  return isMetadataCheckFinished(row);
}

/**
 * 结论列：以 **accepted 布尔** 为准。
 *
 * WHY 不复用 decision 直接渲染：实测 `decision` 是中文「接受/拒绝」，
 * 而 `accepted` 是无歧义布尔；两者不一致时（历史数据）以布尔为准。
 */
function conclusionLabel(row: MetadataCheckTaskSummary): string {
  if (!execFinished(row)) return '—';
  return isMetadataCheckAccepted(row) ? t('dataCheck.accepted') : t('dataCheck.rejected');
}

function conclusionTagType(row: MetadataCheckTaskSummary): 'success' | 'warning' | 'info' {
  if (!execFinished(row)) return 'info';
  return isMetadataCheckAccepted(row) ? 'success' : 'warning';
}

/** 任务可读名：列表页所有用户可见处统一走这里，不回落到 checkUid（评审要求去 UUID） */
function taskDisplayName(row: MetadataCheckTaskSummary): string {
  const name = String(row.taskName ?? '').trim();
  if (name) return name;
  const category = String(row.productCategoryPath ?? '').trim();
  if (category) return category + ' · ' + t('dataCheck.taskSuffix');
  return t('dataCheck.taskFallback');
}

const columns: TableColumn<MetadataCheckTaskSummary>[] = [
  {
    label: t('dataCheck.colTask'),
    prop: 'checkUid',
    minWidth: 240,
    showOverflowTooltip: true,
    render: ({ row }) => <span title={taskDisplayName(row)}>{taskDisplayName(row)}</span>
  },
  { label: t('dataCheck.colCategory'), prop: 'productCategoryPath', minWidth: 180, showOverflowTooltip: true },
  {
    label: t('dataCheck.colSource'),
    minWidth: 220,
    showOverflowTooltip: true,
    render: ({ row }) => [row.sourceKind, row.sourcePath].filter(Boolean).join('  ').trim()
  },
  { label: t('dataCheck.colRecordCount'), prop: 'recordCount', width: 90 },
  {
    label: t('dataCheck.colProgress'),
    minWidth: 200,
    render: ({ row }) => {
      const p = row.progress || {};
      const pct = typeof p.percent === 'number' ? Math.round(p.percent) : 0;
      // 进度条颜色跟执行状态走（成功后变绿、失败变红），不跟「能否入库」走
      const st = execTagType(row);
      return (
        <div class="progress-cell">
          <el-progress percentage={pct} status={st === 'danger' ? 'exception' : st === 'success' ? 'success' : undefined} />
        </div>
      );
    }
  },
  { label: t('dataCheck.colState'), width: 110, render: ({ row }) => <el-tag type={execTagType(row)}>{execLabel(row)}</el-tag> },
  {
    label: t('dataCheck.colConclusion'),
    width: 110,
    render: ({ row }) => (
      <el-tag type={conclusionTagType(row)} effect="plain">
        {conclusionLabel(row)}
      </el-tag>
    )
  },
  {
    label: t('dataCheck.colOperation'),
    action: true,
    fixed: 'right',
    render: ({ row }) => (
      <div class="row-actions">
        <el-button
          link
          type="primary"
          icon={Refresh}
          v-tooltip={t('dataCheck.tooltipResubmit')}
          disabled={isMetadataCheckStateActive(row.state)}
          onClick={() => resubmit(row)}
        />
        <el-button
          link
          type="primary"
          icon={Upload}
          v-tooltip={isMetadataCheckAccepted(row) ? t('dataCheck.tooltipIngest') : t('dataCheck.tooltipCannotIngest')}
          disabled={!isMetadataCheckAccepted(row)}
          onClick={() => goIngest(row)}
        />
        <el-button link type="primary" icon={Document} v-tooltip={t('dataCheck.tooltipManifest')} onClick={() => showManifest(row)} />
        <el-button link type="primary" icon={Tickets} v-tooltip={t('dataCheck.tooltipReport')} onClick={() => showReport(row)} />
        <el-button link type="primary" icon={View} v-tooltip={t('dataCheck.tooltipDetail')} onClick={() => showDetail(row)} />
        <el-button
          link
          type="danger"
          icon={Delete}
          v-tooltip={t('dataCheck.tooltipDelete')}
          disabled={isMetadataCheckStateActive(row.state)}
          onClick={() => doDelete(row)}
        />
      </div>
    )
  }
];

/**
 * 状态归一与活跃判据统一走接口层（normalizeMetadataCheckState / isMetadataCheckStateActive）。
 *
 * CONSTRAINT 后端出参 state 是**中文**（「成功」「已创建」「执行中」…），而筛选比较、
 * 按钮禁用、SSE 订阅都按规范键判断 —— 词表若散在本文件里，筛选项与列表标签必然漂移：
 * 旧版筛选项写「通过」、列表写「执行完成」，同一状态两种叫法。
 */

/** 单任务最大重连次数；超过即放弃，等待下次整表刷新再定夺 */
const SSE_MAX_RETRIES = 3;
/** 重连间隔；契约不支持 Last-Event-ID，重连即拿最新快照，无需退避等待 */
const SSE_RETRY_DELAY_MS = 5000;

/**
 * 已建立的订阅，按统一任务 uid 索引。
 *
 * CONSTRAINT 一个 taskUid 只允许一条订阅：SSE 契约明确不支持 Last-Event-ID，
 * 重连会重新下发最新快照，重复订阅只浪费连接；Map 同时承担去重与卸载时统一 abort。
 */
const sseControllers = new Map<string, AbortController>();

/** 每任务已重试次数；收到任一事件即清零，避免慢连接被误判为持续失败 */
const sseRetries = new Map<string, number>();

/** 待执行的重连定时器；卸载时统一清，避免定时器在组件销毁后仍建连 */
const sseRetryTimers = new Set<ReturnType<typeof setTimeout>>();

// 首次加载由 Table 的 request(getTasks) 触发；SSE 订阅随首次请求一并建立
onBeforeUnmount(stopAllSubscriptions);

/** 判断任务是否处于需要订阅的活跃态；未知状态按「不订阅」处理，避免误判 */
function isActiveState(state?: string): boolean {
  return isMetadataCheckStateActive(state);
}

/**
 * 为单个任务建立 SSE 订阅。
 *
 * WHY 独立成函数：断线重连要复用同一套 handler；若内联在 syncSubscriptions
 * 的 forEach 里，重连逻辑只能再抄一遍 handler，后续改事件语义必漏改。
 */
function subscribeOne(taskUid: string) {
  if (sseControllers.has(taskUid)) return;

  const controller = new AbortController();
  sseControllers.set(taskUid, controller);

  subscribeTaskEvents(
    taskUid,
    {
      /**
       * 进度事件：只合并 state/progress 两个字段，并清零重试计数。
       *
       * CONSTRAINT 快照形态与统一任务一致，不保证与检查任务行一一对应；
       * 其余字段（errors/decision 等）留待终态整表刷新覆盖，避免字段漂移。
       */
      onEvent: (payload) => {
        console.log(payload);

        sseRetries.delete(taskUid);
        const snapshot = (payload.data || {}) as Record<string, unknown>;
        const hit = checkTasks.find((x) => x.taskUid === taskUid);
        if (!hit) return;
        if (typeof snapshot.state === 'string') hit.state = snapshot.state;
        if (snapshot.progress) hit.progress = snapshot.progress as MetadataCheckTaskSummary['progress'];
      },
      /** 终态事件：断开订阅、清重试痕迹，并整表重拉一次拿到 errors/decision */
      onTerminal: () => {
        controller.abort();
        sseControllers.delete(taskUid);
        sseRetries.delete(taskUid);
        // 终态只改任务内容不改排序，游标仍有效：重拉当前页即可拿到 errors/decision
        table.value?.getData();
      },
      /**
       * 连接/解析异常：按次数上限自动重连。
       *
       * CONSTRAINT 契约明确「断线不回放历史事件，重连需调用方自行发起」；不重连会让
       * 该任务进度永久停在断线时的值，直到用户手动刷新。超过上限即放弃，等待下次
       * 整表刷新（getTasks / 提交成功后）重新计算订阅面。
       */
      onError: () => {
        sseControllers.delete(taskUid);
        const n = (sseRetries.get(taskUid) || 0) + 1;
        if (n > SSE_MAX_RETRIES) {
          sseRetries.delete(taskUid);
          return;
        }
        sseRetries.set(taskUid, n);
        const timer = setTimeout(() => {
          sseRetryTimers.delete(timer);
          const hit = checkTasks.find((x) => x.taskUid === taskUid);
          if (hit && isActiveState(hit.state)) subscribeOne(taskUid);
        }, SSE_RETRY_DELAY_MS);
        sseRetryTimers.add(timer);
      }
    },
    controller.signal
  );
}

/**
 * 对当前列表中活跃态且尚未订阅的任务建立 SSE 订阅。
 *
 * WHY 只订阅活跃态：终态不再产生进度事件，一并订阅会白占连接并反复建连。
 * WHY 不用 EventSource：契约要求 Authorization + clientid，原生 EventSource 不支持自定义头。
 */
function syncSubscriptions() {
  checkTasks.forEach((task) => {
    const taskUid = task.taskUid;
    if (!taskUid) return;
    if (!isActiveState(task.state)) return;
    subscribeOne(taskUid);
  });
}

/** 卸载前统一断开所有 SSE 连接与重连定时器，避免长连接与定时器泄漏 */
function stopAllSubscriptions() {
  sseControllers.forEach((c) => c.abort());
  sseControllers.clear();
  sseRetries.clear();
  sseRetryTimers.forEach((t) => clearTimeout(t));
  sseRetryTimers.clear();
}

/**
 * 列表数据源，两条通道（用户 2026-11-17 口径「接口一次请求10条」）：
 *  - 无筛选：接口原生页码分页（2026-11-17 契约：page/pageSize，cursor 已废弃），每页 10 条一次请求；
 *  - 有关键字/状态筛选：后端列表接口不支持筛选参数，只能按页码拉满上限（pageSize=200 为契约
 *    上限，常规数据量一次请求即全集）后本地过滤。
 */
async function getTasks(params: Params) {
  const keyword = String(params.keyword || '').toLowerCase();
  const state = String(params.state || '');
  if (!keyword && !state) {
    // CONSTRAINT Table 组件实测发 page/pageSize（_requestCfg 默认 page:'page'），不发 pageNum；读错键会恒回第 1 页
    const page = await loadCheckTasksPage(Number(params.page ?? params.pageNum) || 1, Number(params.pageSize) || CHECK_PAGE_SIZE);
    syncSubscriptions();
    return { code: 0, data: { items: page.items, total: page.total } };
  }
  await loadCheckTasks();
  syncSubscriptions();
  const items = checkTasks.filter((task) => {
    const hay = [task.checkUid, task.productCategoryPath, task.sourcePath].filter(Boolean).join(' ').toLowerCase();
    if (keyword && !hay.includes(keyword)) return false;
    /**
     * 筛选项 value 是规范键，后端 state 可能是中文（「成功」）/ 英文（SUCCEEDED）/
     * 带前后缀（「检查成功」），必须两端都归一后再比较——否则筛选恒空。
     * 归一函数与状态列标签共用接口层同一份词表，保证「筛什么就看到什么」。
     */
    if (state && normalizeMetadataCheckState(task.state) !== state) return false;
    return true;
  });
  return { code: 0, data: { items, total: items.length } };
}

/**
 * 用同一来源重新提交检查。
 *
 * CONSTRAINT 后端按来源三选一：uploadUid / sourceStorageUid+sourcePath / sourcePath(UNC)；
 * 缺来源直接拒绝，不构造空请求。
 */
/**
 * 用同一来源重新提交检查。
 *
 * 载荷由 buildMetadataCheckPayload 统一构造（含必填与来源三选一校验），
 * 避免页面内出现第二份字段拼装逻辑。
 */
async function resubmit(row: MetadataCheckTaskSummary) {
  /**
   * CONSTRAINT `files` 是契约必填（string[] 非空），列表接口**不返回**该字段
   * （实测列表项 files 恒 null，只有详情才是 string[]）。因此重新检查前必须先拉详情
   * 取回原文件清单；拿不到就直接拒绝，不构造一个必然 400 的请求。
   */
  let files: string[] = [];
  let detail: MetadataCheckTaskSummary | null = null;
  try {
    const res = await getMetadataFileCheck(row.checkUid);
    detail = (res?.data ?? null) as MetadataCheckTaskSummary | null;
    files = Array.isArray(detail?.files) ? detail.files : [];
  } catch {
    // 失败原因由响应拦截器统一弹出；这里只保证不发出半成品请求
  }
  if (!files.length) {
    ElMessage.warning(t('dataCheck.msgNoFiles'));
    return;
  }

  const build = buildMetadataCheckPayload({
    // 老任务可能没有 taskName（契约新增前创建）：用可读任务名，
    // 避免必填校验把「重新检查」拦死在列表页，也不把 UUID 暴露给用户。
    taskName: row.taskName || t('dataCheck.resubmitPrefix') + taskDisplayName(row),
    modelUid: row.modelUid,
    categoryUid: detail?.categoryUid || row.categoryUid,
    scope: row.checkScope,
    files,
    sourceType: (detail?.sourceType || row.sourceType) as never,
    uploadUid: row.uploadUid,
    sourceStorageUid: row.sourceStorageUid,
    dataRootPath: detail?.dataRootPath ?? row.dataRootPath
  });
  if (!build.ok || !build.payload) {
    ElMessage.warning(build.message || t('dataCheck.msgParamIncomplete'));
    return;
  }
  const res = await submitMetadataFileCheck(build.payload);
  /**
   * 与新建检查同理：200 empty / partial 也是 code=0，但 checkUid=null、没有新建任务。
   * 这里是列表页自己提示成功（不走 createDialog），必须显式区分，否则「重新检查」点了
   * 没生成新任务，用户却看到「已提交重新检查」。
   */
  if (isMetadataCheckNotAccepted(res)) {
    ElMessage.warning(metadataCheckNotAcceptedMessage(res));
    return;
  }
  ElMessage.success(t('dataCheck.msgResubmitted'));
  // 新任务插到列表头部：回第 1 页才能立刻看到
  table.value?.query();
}

/**
 * 行内「去入库」：把该检查的选择结果写进共享上下文，再切到「数据入库」tab。
 *
 * WHY 必须经共享上下文而不是直接改 tab：文档 §1 硬约束「检查页与入库页必须共用
 * 同一份文件选择结果」，入库页要拿 checkUid + 类别 + 文件数做只读摘要。
 */
function goIngest(row: MetadataCheckTaskSummary) {
  if (!isMetadataCheckAccepted(row)) {
    ElMessage.warning(t('dataCheck.msgNotAcceptedIngest'));
    return;
  }
  setSelection({
    checkUid: row.checkUid,
    accepted: true,
    locationUid: row.sourceStorageUid || '',
    dataRootPath: row.dataRootPath || '',
    files: [],
    fileNames: [],
    sourceType: (row.sourceType || 'registered_share') as never,
    categoryUid: row.categoryUid || row.productCategoryUid || '',
    modelUid: row.modelUid || '',
    taskName: taskDisplayName(row)
  });
  emit('go-ingest');
}

/**
 * 清单管理弹窗：列出与该检查任务关联的文件清单，支持软删除。
 *
 * CONSTRAINT 清单的 task.uid 与检查任务的 taskUid 同值；老任务可能没有 taskUid，
 * 回落到 checkUid（两者在检查任务里实测同值）。弹窗按此过滤，避免展示无关清单。
 */
function showManifest(row: MetadataCheckTaskSummary) {
  createDialog({
    title: t('dataCheck.dialogManifest'),
    closeOnClickModal: false,
    width: '980px',
    footer: false,
    bodyStyle: { padding: '0' },
    render: () => <ManifestDialog taskUid={row.taskUid || row.checkUid} />
  });
}

/** 详情弹窗：body 内边距交给组件根自管（{ padding: '0' }），避免和弹窗皮肤叠加出双倍留白 */
async function showDetail(row: MetadataCheckTaskSummary) {
  const res = await getMetadataFileCheck(row.checkUid);
  const detail = (res?.data ?? row) as MetadataCheckTaskSummary;
  createDialog({
    title: t('dataCheck.dialogDetail'),
    closeOnClickModal: false,
    width: '860px',
    footer: false,
    bodyStyle: { padding: '0' },
    render: () => <DetailDialog detail={detail} onClose={() => {}} />
  });
}

/**
 * 错误报表：只列后端 errors 的 message，不拼接任何本地兜底文本。
 *
 * CONSTRAINT 列表接口 items 不含 errors（只有终态 summary 摘要），必须按需拉详情：
 * 列表项 errors 恒 undefined 曾导致按钮 disabled 恒 true，用户点了没反应。
 * 详情接口 GET /platform/metadata/checks/files/{checkUid} 才返回完整 errors。
 */
async function showReport(row: MetadataCheckTaskSummary) {
  let detail: any = row;
  try {
    const res = await getMetadataFileCheck(row.checkUid);
    detail = res?.data ?? row;
  } catch {
    // 拉详情失败时退化为列表项数据（详情弹窗走空态分支）
  }
  const errs = Array.isArray(detail?.errors) ? detail.errors : [];
  createDialog({
    title: t('dataCheck.dialogReport'),
    closeOnClickModal: false,
    width: '800px',
    footer: false,
    bodyStyle: { padding: '0' },
    render: () => <ErrorReportDialog errors={errs} detail={detail} />
  });
}

/**
 * 删除元数据文件检查任务（物理删除，含磁盘报告）。
 * CONSTRAINT 后端状态门禁：统一任务 RUNNING / QUEUED / PAUSING 时返回 409；按钮已按 state 大写禁用，
 * 其余 404（不存在）等业务错由响应拦截器统一弹出。
 */
async function doDelete(row: MetadataCheckTaskSummary) {
  try {
    await ElMessageBox.confirm(t('dataCheck.msgDeleteConfirm', { name: taskDisplayName(row) }), t('dataCheck.warnTitle'), {
      type: 'warning'
    });
  } catch {
    return;
  }
  try {
    await deleteMetadataFileCheck(row.checkUid);
    ElMessage.success(t('dataCheck.msgDeleted'));
  } catch {
    // 失败原因由响应拦截器统一弹出（含 409 运行中 / 404 不存在）
  } finally {
    // 页码分页无状态：直接重拉当前页（后端先过滤再分页，页内容会自然前移）
    table.value?.getData();
  }
}

/** 新建任务：表单透传后端字段，不做字段改名 */

function openCheckDialog() {
  createDialog({
    title: t('dataCheck.dialogNew'),
    closeOnClickModal: false,
    /**
     * 2026-11-12 加宽：位置选择器改为内嵌双栏（浏览树 + 已选清单）后，
     * 680px 会把树挤成一条缝；900px 能让双栏都可读，又不至于占满屏幕。
     */
    width: '800px',
    /**
     * 提交成功后：刷新列表 + 把这次的选择写进共享上下文，供「数据入库」直接绑定。
     *
     * WHY 在这里取选择而不是在 Edit 里 emit：Edit 的 save() 已自己完成提交并返回响应，
     * 再 emit 一次会让同一份文件被受理两遍。这里拿到的 `r` 就是 submitMetadataFileCheck
     * 的响应（createDialog 在 code===0 时回传），其中的 checkUid / files / categoryUid
     * 就是本次「唯一真源」的文件选择结果。
     */
    afterSave: (r?: any) => {
      // 新任务在列表头部：回第 1 页，保证立刻看到本次检查
      table.value?.query();
      const data = r?.data ?? {};
      if (data.checkUid) {
        setSelection({
          checkUid: data.checkUid,
          accepted: false,
          locationUid: data.sourceStorageUid || '',
          dataRootPath: data.dataRootPath || '',
          files: Array.isArray(data.files) ? data.files : [],
          fileNames: [],
          sourceType: (data.sourceType || 'registered_share') as never,
          categoryUid: data.categoryUid || data.productCategoryUid || '',
          modelUid: data.modelUid || '',
          taskName:
            data.taskName || (data.productCategoryPath ? data.productCategoryPath + ' · ' + t('dataCheck.taskSuffix') : t('dataCheck.taskFallback'))
        });
      }
    },
    // 不传 onSubmit：Edit 的 save() 自管提交（见 edit.vue 里对 emit 只声明不触发的说明）
    render: () => <Edit categoryRoot={categoryRoot} />
  });
}
</script>

<template>
  <Table ref="table" :columns="columns" :request="getTasks" :query-params="queryParams">
    <template #action>
      <el-button type="primary" :icon="Plus" @click="openCheckDialog">{{ t('dataCheck.newCheck') }}</el-button>
    </template>
    <template #search>
      <el-input v-model="queryParams.keyword" :label="t('dataCheck.searchTaskCategoryPath')" :placeholder="t('dataCheck.searchPlaceholder')" />
      <el-select
        v-model="queryParams.state"
        :label="t('dataCheck.searchState')"
        :placeholder="t('dataCheck.searchStatePlaceholder')"
        clearable
        :options="statusOptions"
      />
    </template>
  </Table>
</template>

<style scoped lang="scss">
/* 本块里的类只出现在 columns 的 JSX render 中（不在 <template> 里）。
   formatter 由 ElTable 在其自身渲染上下文执行，产出的 vnode 带的是 ElTable 的 scopeId，
   不是本组件的，因此 `scoped` 编出的 `.progress-cell[data-v-xxx]` 永远匹配不到，样式静默失效。
   改用 :deep()：编译成 `[data-v-xxx] .progress-cell`，由本组件根节点上的 scope 锚定，
   后代选择器不再要求目标元素自带 scopeId。 */
:deep(.progress-cell) {
  display: flex;
  align-items: center;
  gap: 8px;
}
:deep(.progress-cell .el-progress) {
  flex: 1;
}
:deep(.progress-cell .stage) {
  min-width: 70px;
  color: #718097;
  font-size: 12px;
}
:deep(.row-actions) {
  white-space: nowrap;
}
</style>
