import type { MetadataCheckTaskSummary } from '@/api/product-manage/platform/metadata-check';

/**
 * 错误报表 / 任务详情共用的错误展示工具。
 *
 * WHY 抽出来：两个弹窗各自维护过一份 formatMessage 与错误卡片模板，结果详情页的 message
 * 是纯文本（PostgreSQL 多段报错挤成一坨）、报表页才做换行。视觉与语义必须同源，
 * 否则同一个错误在两个入口长得不一样，排障时会对不上。
 *
 * CONSTRAINT 只做「结构化展示」，不改写后端原文：formatMessage 仅把语义分隔符转成换行，
 * messageSegments 仅把已有的段前缀拆成标签 + 正文，一字不增删。
 */

/** 直接从契约派生，避免本地另写一份与接口脱节的错误对象类型 */
export type CheckError = NonNullable<MetadataCheckTaskSummary['errors']>[number];

/** 过滤后仍要显示原始序号，故把错误连同它在完整账本中的下标一起传递 */
export interface IndexedError {
  error: CheckError;
  index: number;
}

export type MessageTone = 'error' | 'detail' | 'hint' | 'context' | 'plain';

export interface MessageSegment {
  /** 段前缀（PostgreSQL 原文，如 `ERROR:`）；普通行为空 */
  label: string;
  /** 段前缀对应的语义色 */
  tone: MessageTone;
  /** 该行的正文（前缀之后的部分） */
  text: string;
  /** 空行标记：只用于排版留白，不含内容 */
  blank: boolean;
}

export interface ErrorStats {
  total: number;
  unresolved: number;
  resolved: number;
  /** 涉及字段数（按 fieldKey 去重，空值不计入） */
  fieldCount: number;
}

/** 把后端原始 message 的语义分隔符转为换行，让多段报错不再挤成一坨。只换行、不改字。 */
export function formatMessage(raw?: string): string {
  if (!raw) return '无描述';
  return String(raw)
    .replace(/\s+(ERROR:|DETAIL:|HINT:|CONTEXT:|错误:)/g, '\n$1')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

const SEGMENT_PREFIX = /^(ERROR:|错误:|DETAIL:|HINT:|CONTEXT:)\s*/;

const SEGMENT_TONE: Record<string, MessageTone> = {
  'ERROR:': 'error',
  '错误:': 'error',
  'DETAIL:': 'detail',
  'HINT:': 'hint',
  'CONTEXT:': 'context'
};

/**
 * 换行后的 message 逐行拆段：带 `ERROR:` / `DETAIL:` / `HINT:` / `CONTEXT:` 前缀的行
 * 渲染成带语义色的段标签 + 正文，其余为普通正文行。
 *
 * WHY 不用一整块 `<pre>`：多段报错里「哪句是主错误、哪句是上下文」靠前缀区分，
 * 纯等宽文本把它们的层级抹平了。拆段不改动任何文字，只是把已有前缀显式化。
 */
export function messageSegments(raw?: string): MessageSegment[] {
  return formatMessage(raw)
    .split('\n')
    .map((line): MessageSegment => {
      if (!line.trim()) return { label: '', tone: 'plain', text: '', blank: true };
      const matched = line.match(SEGMENT_PREFIX);
      if (!matched) return { label: '', tone: 'plain', text: line, blank: false };
      return {
        label: matched[1],
        tone: SEGMENT_TONE[matched[1]] || 'plain',
        text: line.slice(matched[0].length),
        blank: false
      };
    });
}

/** 给完整账本编号（从 1 开始），筛选后可以继续显示原始序号 */
export function indexErrors(errors: CheckError[]): IndexedError[] {
  return errors.map((error, i) => ({ error, index: i + 1 }));
}

/** 概览统计：已解决 / 未解决 / 涉及字段。空数组如实返回全 0，文案由调用方决定中性化。 */
export function errorStats(errors: CheckError[]): ErrorStats {
  const resolved = errors.filter((e) => e.resolved).length;
  const fields = new Set(errors.map((e) => e.fieldKey).filter((v): v is string => !!v));
  return {
    total: errors.length,
    unresolved: errors.length - resolved,
    resolved,
    fieldCount: fields.size
  };
}

/**
 * 单条错误的纯文本快照，用于「复制全部」与「复制本条」。
 *
 * CONSTRAINT 保持与旧版完全一致的字段与顺序（#N [code] / message / 数据项），
 * 便于直接贴到工单里。消息用 formatMessage 做换行排版（只换行、不改字），
 * 避免 PostgreSQL 多段报错在纯文本里继续挤成一坨。
 */
export function errorToText(e: CheckError, index: number): string {
  const head = '#' + index + ' [' + (e.code || '未知') + ']' + (e.resolved ? ' (已解决)' : '');
  const item = e.itemUid ? '\n数据项 ' + e.itemUid : '';
  return head + '\n' + formatMessage(e.message) + item;
}

/** 关键字匹配范围：错误码 / 字段 / 数据项 / 原文；大小写不敏感 */
export function matchError(e: CheckError, keyword: string): boolean {
  const k = keyword.trim().toLowerCase();
  if (!k) return true;
  return [e.code, e.fieldKey, e.itemUid, e.message].some((v) =>
    String(v ?? '')
      .toLowerCase()
      .includes(k)
  );
}
