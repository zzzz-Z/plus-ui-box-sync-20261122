<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
import { computed, ref, watch } from 'vue';
import { ArrowRight, Delete, Document, FolderOpened } from '@element-plus/icons-vue';
import { ElMessage } from 'element-plus';

/**
 * 已选文件树（「入库清单」/「元数据位置-已选内容」共用）。
 *
 * WHY 抽成共享组件：需求要求「已选内容」和「入库清单」展示一致（树结构、可拖动改路径）。
 * 三处调用方（入库页入库清单、BrowseDialog 右栏、LocationTreeSelect 触发框）各写一份
 * 树派生 + 拖拽逻辑必然漂移；这里把它收敛成「纯展示 + emit 变更请求」，
 * 数据真源始终留在各调用方手里（one source of truth），组件不自行增删行。
 *
 * CONSTRAINT 只用原生 HTML5 拖拽，不用 el-tree 的 draggable：后者自建拖拽模型与落点判定，
 * 与「拖到目录 = 改 targetPath」语义不一致，且接管后原生 drop 收不到。
 */
interface TreeRow {
  /** 稳定身份键 */
  id: string;
  /** 来源侧真实路径（只读展示，拖动不改它） */
  sourcePath: string;
  /** 入库侧路径：树的派生依据，也是拖动要改的值 */
  targetPath: string;
  /** 锁定行（如检查单冻结的 metadata）：不可删、标灰 */
  locked?: boolean;
  /** 角色标签：locked 行显示 metadata 标 */
  role?: string;
  sizeBytes?: number;
  /** 勾选模式下该行是否被勾选（undefined 视为勾选）；由宿主维护，组件只发 check 请求 */
  checked?: boolean;
  /** 'directory' 显示为目录图标（来源允许选目录时） */
  kind?: string;
  /**
   * 该行数据来自哪个来源（展示用短标签，如「共享存储一」「\\host\share」「本地上传」）。
   *
   * WHY 需要：入库清单现在允许三型来源混排（2026-11-12 契约，来源下沉到 files 每条），
   * 同一个清单里可能同时出现共享路径与上传文件；不标来源时用户无法判断某一行
   * 到底是从哪个根解析出来的，改错来源就会拼出非法 source。
   */
  sourceLabel?: string;
}

interface TreeNode {
  key: string;
  label: string;
  path: string;
  isDir: boolean;
  children: TreeNode[];
  row?: TreeRow;
}

const props = withDefaults(
  defineProps<{
    rows: TreeRow[];
    emptyText?: string;
    tip?: string;
    /** 是否显示每行的入库路径（targetPath） */
    showPath?: boolean;
    /** 是否显示目录节点右侧的数量徽标（data.children.length） */
    showCount?: boolean;
    /** 是否显示箭头/移除按钮（LocationTreeSelect 触发框纯回显时可关） */
    editable?: boolean;
    /** 树最大高度（px） */
    maxHeight?: number;
    /** 平铺模式：不按目录分层缩进，文件按清单顺序一行一行平铺；tooltip 显示完整路径 */
    flat?: boolean;
    /** 勾选模式：在数据行前显示 checkbox，勾选状态由宿主在 row.checked 上维护 */
    checkable?: boolean;
    /** 是否显示「移除」按钮（入库清单用勾选代替移除，可关；其它调用方默认保留） */
    removable?: boolean;
  }>(),
  {
    emptyText: pt('暂无已选内容'),
    tip: pt('拖动文件到目录可改变路径；拖到空白处移回根目录。'),
    showPath: true,
    showCount: true,
    editable: true,
    maxHeight: 300,
    flat: false,
    checkable: false,
    removable: true
  }
);

const emit = defineEmits<{
  /** 把某行移动到指定入库路径 */
  move: [{ id: string; targetPath: string }];
  /** 移除某行 */
  remove: [id: string];
  /** 把首个未锁定行移进某目录（树上的箭头按钮，交由宿主决定移谁） */
  moveInto: [dirPath: string];
  /** 数据行勾选状态变化（checked 存不存在由 row.checked 决定，默认勾选） */
  check: [{ id: string; checked: boolean }];
}>();

/** targetPath 的目录部分（末尾无 /）；顶层文件返回空串 */
function dirOfTarget(targetPath: string): string {
  const segs = String(targetPath || '')
    .replace(/^\/+/, '')
    .split('/')
    .filter(Boolean);
  return segs.length > 1 ? segs.slice(0, -1).join('/') : '';
}

/** targetPath 的文件名部分 */
function nameOfTarget(targetPath: string): string {
  const segs = String(targetPath || '')
    .replace(/^\/+/, '')
    .split('/')
    .filter(Boolean);
  return segs.length ? segs[segs.length - 1] : String(targetPath || '');
}

/** 由 targetPath 反推目录树：树是 targetPath 的纯函数派生，不另存一份结构 */
const tree = computed<TreeNode[]>(() => {
  // 平铺模式：一行一个文件，不派生目录节点、不缩进；完整路径放 tooltip
  if (props.flat) {
    return props.rows.map((row) => {
      const full = String(row.sourcePath || '').replace(/\\/g, '/');
      return {
        key: 'f:' + row.id,
        label: nameOfTarget(full),
        path: full,
        isDir: false,
        children: [],
        row
      } as TreeNode;
    });
  }
  const rootNodes: TreeNode[] = [];
  const dirMap = new Map<string, TreeNode>();
  function ensureDir(fullPath: string): TreeNode[] {
    if (!fullPath) return rootNodes;
    const existed = dirMap.get(fullPath);
    if (existed) return existed.children;
    const parentChildren = ensureDir(dirOfTarget(fullPath));
    const node: TreeNode = {
      key: 'd:' + fullPath,
      label: nameOfTarget(fullPath),
      path: fullPath,
      isDir: true,
      children: []
    };
    dirMap.set(fullPath, node);
    parentChildren.push(node);
    return node.children;
  }
  for (const row of props.rows) {
    const track = String(row.targetPath || row.sourcePath || '').replace(/^\/+/, '');
    if (!track) continue;
    ensureDir(dirOfTarget(track)).push({
      key: 'f:' + row.id,
      label: nameOfTarget(track),
      path: track,
      isDir: false,
      children: [],
      row
    });
  }
  /** 目录在前、名称升序，与资源浏览器一致 */
  const sortNodes = (nodes: TreeNode[]) => {
    nodes.sort((a, b) => (a.isDir === b.isDir ? a.label.localeCompare(b.label) : a.isDir ? -1 : 1));
    nodes.forEach((n) => n.children.length && sortNodes(n.children));
    return nodes;
  };
  return sortNodes(rootNodes);
});

/** 默认全展开；清单变化后重建 el-tree 让 default-expanded-keys 生效 */
const expandedKeys = ref<string[]>([]);
const treeVersion = ref(0);
watch(
  () => props.rows.map((r) => r.targetPath).join('|'),
  () => {
    const keys: string[] = [];
    const walk = (nodes: TreeNode[]) => {
      for (const n of nodes) {
        if (n.isDir) {
          keys.push(n.key);
          walk(n.children);
        }
      }
    };
    walk(tree.value);
    expandedKeys.value = keys;
    treeVersion.value += 1;
  },
  { immediate: true }
);

/** 勾选框变化：转发给宿主，由宿主改 row.checked（组件不自行改行，保持单一数据源） */
function onCheckChange(data: TreeNode, val: unknown) {
  if (!data.row) return;
  emit('check', { id: data.row.id, checked: !!val });
}

/** 拖动中的行 id（模块变量比 dataTransfer 稳） */
let draggingRowId = '';
const dropDirKey = ref('');

function onRowDragStart(event: DragEvent, data: TreeNode) {
  if (data.isDir) {
    event.preventDefault();
    return;
  }
  draggingRowId = data.row?.id || '';
  event.dataTransfer?.setData('text/plain', data.label);
  if (event.dataTransfer) event.dataTransfer.effectAllowed = 'move';
}

function onRowDragOver(event: DragEvent, data: TreeNode) {
  if (!draggingRowId || !data.isDir) return;
  event.preventDefault();
  event.stopPropagation();
  dropDirKey.value = data.key;
  if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
}

function onTreeDragLeave() {
  dropDirKey.value = '';
}

function onRowDrop(event: DragEvent, data: TreeNode) {
  if (!data.isDir) return;
  event.preventDefault();
  // 先消费身份再处理：即便冒泡到根处理器也拿不到 id，杜绝重复应用
  const id = draggingRowId;
  draggingRowId = '';
  event.stopPropagation();
  dropDirKey.value = '';
  if (!id) return;
  const row = props.rows.find((r) => r.id === id);
  if (!row) return;
  const name = nameOfTarget(row.targetPath || row.sourcePath);
  const next = data.path ? data.path + '/' + name : name;
  if (next === row.targetPath) return;
  ElMessage.success('已移动到「' + (data.path || '根目录') + '」');
  emit('move', { id, targetPath: next });
}

function onTreeRootDrop(event: DragEvent) {
  event.preventDefault();
  const id = draggingRowId;
  draggingRowId = '';
  dropDirKey.value = '';
  if (!id) return;
  const row = props.rows.find((r) => r.id === id);
  if (!row) return;
  const name = nameOfTarget(row.targetPath || row.sourcePath);
  if (row.targetPath === name) return;
  ElMessage.success(pt('已移动到根目录'));
  emit('move', { id, targetPath: name });
}
</script>

<template>
  <div class="sft">
    <div v-if="!rows.length" class="sft__empty">{{ emptyText }}</div>
    <div
      v-else
      class="sft__tree"
      :class="{ 'sft__tree--flat': flat }"
      :style="maxHeight ? { maxHeight: maxHeight + 'px' } : undefined"
      @dragover.prevent
      @drop="onTreeRootDrop"
    >
      <el-tree
        :key="treeVersion"
        :data="tree"
        node-key="key"
        :props="{ label: 'label', children: 'children' }"
        :default-expanded-keys="expandedKeys"
        :indent="flat ? 0 : 14"
        :expand-on-click-node="true"
      >
        <template #default="{ data }">
          <div
            class="trow"
            :class="{
              'is-dir': data.isDir,
              'is-drop': dropDirKey === data.key,
              'is-locked': data.row?.locked,
              'is-unchecked': checkable && data.row && !data.row.locked && data.row.checked === false
            }"
            :title="data.isDir ? data.path : data.row?.sourcePath"
            :draggable="!flat && !data.isDir"
            @dragstart="onRowDragStart($event, data)"
            @dragover="onRowDragOver($event, data)"
            @dragleave="onTreeDragLeave"
            @drop="onRowDrop($event, data)"
          >
            <el-icon class="trow__ic">
              <FolderOpened v-if="data.isDir || data.row?.kind === 'directory'" />
              <Document v-else />
            </el-icon>
            <el-checkbox
              v-if="checkable && data.row && !data.row.locked"
              :model-value="data.row.checked !== false"
              class="trow__check"
              @click.stop
              @change="(val) => onCheckChange(data, val)"
            />
            <span class="trow__nm">{{ data.label }}</span>
            <el-tag v-if="data.row?.locked" size="small" type="info" class="trow__tag">metadata</el-tag>
            <!-- 来源徽标：清单允许三型来源混排时，用它区分每行的来源根 -->
            <el-tag v-else-if="data.row?.sourceLabel" size="small" type="success" effect="plain" class="trow__tag trow__tag--src">
              {{ data.row.sourceLabel }}
            </el-tag>
            <span v-if="showCount && data.isDir" class="trow__cnt">{{ data.children.length }}</span>
            <span v-else-if="showPath && data.row" class="trow__path" :title="data.row.targetPath">{{ data.row.targetPath }}</span>

            <span v-if="editable" class="trow__ops">
              <el-tooltip v-if="data.isDir" :content="pt('把首个可移动文件放进此目录')" placement="top">
                <el-button :icon="ArrowRight" link size="small" @click.stop="emit('moveInto', data.path)" />
              </el-tooltip>
              <el-tooltip v-if="removable && data.row && !data.row.locked" :content="pt('从清单移除')" placement="top">
                <el-button :icon="Delete" link type="danger" size="small" @click.stop="emit('remove', data.row.id)" />
              </el-tooltip>
            </span>
          </div>
        </template>
      </el-tree>
    </div>
    <div v-if="tip" class="sft__tip">{{ tip }}</div>
  </div>
</template>

<style lang="scss" scoped>
.sft {
  width: 100%;
}

.sft__empty {
  padding: 10px 2px;
  font-size: 12px;
  color: var(--el-text-color-placeholder);
}

.sft__tree {
  padding: 2px 0;
  overflow: auto;

  /* 细滚动条贴右边缘：默认滚动条较宽，右侧内容看着离边很远 */
  &::-webkit-scrollbar {
    width: 6px;
  }
  &::-webkit-scrollbar-thumb {
    background: var(--el-border-color-darker);
    border-radius: 3px;
  }
  &::-webkit-scrollbar-track {
    background: transparent;
  }

  :deep(.el-tree) {
    background: transparent;
  }

  :deep(.el-tree-node__content) {
    height: 28px;
  }

  /*
   * el-tree 会给每个 .el-tree-node 写 draggable="false"（它自己的拖拽模型默认关闭），
   * 这会沿 DOM 传染、压掉行内元素的 draggable="true"，导致原生拖拽完全不触发。
   * 这里把它显式恢复成 auto，让行自己的 draggable 生效。
   */
  :deep(.el-tree-node) {
    -webkit-user-drag: element;
  }

  :deep(.el-tree-node[draggable='false']) {
    draggable: auto;
  }
}

/* 平铺模式（检查清单专用）：叶子无层级、去掉列表边框、隐藏展开箭头占位 */
.sft__tree--flat {
  border: 0;
  border-radius: 0;

  :deep(.el-tree-node__expand-icon) {
    display: none;
  }
}

.sft__tip {
  margin-top: 6px;
  font-size: 11px;
  color: var(--el-text-color-placeholder);
}

.trow {
  display: flex;
  flex: 1;
  align-items: center;
  gap: 5px;
  min-width: 0;
  padding-right: 6px;

  &.is-drop {
    background: var(--el-color-primary-light-9);
    box-shadow: inset 0 0 0 1px var(--el-color-primary-light-5);
  }

  &.is-locked .trow__nm {
    color: var(--el-color-info);
  }

  /* 勾选模式下未勾选的数据行整行淡出，直观表达「本行不入库」 */
  &.is-unchecked {
    opacity: 0.45;
  }
}

.trow__check {
  flex-shrink: 0;
  height: 18px;
  margin-right: 1px;
}

.trow__ic {
  flex-shrink: 0;
  font-size: 14px;
  color: var(--el-text-color-placeholder);

  .is-dir & {
    color: #e6a23c;
  }
}

.trow__nm {
  flex: 1;
  min-width: 0;
  max-width: 220px;
  overflow: hidden;
  font-size: 12px;
  color: var(--el-text-color-regular);
  text-overflow: ellipsis;
  white-space: nowrap;

  .is-dir & {
    font-weight: 600;
  }
}

.trow__tag {
  flex-shrink: 0;
  height: 18px;
  padding: 0 5px;
  font-size: 10px;
  line-height: 18px;
}

/* 来源徽标：比 metadata 更低调（effect=plain + 更浅的边框），避免与锁定标抢注意力 */
.trow__tag--src {
  max-width: 120px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.trow__cnt {
  flex-shrink: 0;
  font-size: 11px;
  color: var(--el-text-color-placeholder);
}

.trow__path {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 11px;
  color: var(--el-text-color-placeholder);
  text-align: right;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.trow__ops {
  display: flex;
  flex-shrink: 0;
  margin-left: auto;
  gap: 2px;
  opacity: 0;
  transition: opacity 0.15s;
}

.trow:hover .trow__ops,
.trow.is-drop .trow__ops {
  opacity: 1;
}
</style>
