import { reactive, ref } from 'vue';
import { listMetadataFileChecks } from '@/api/product-manage/platform/metadata-check';
import type { MetadataCheckTaskSummary } from '@/api/product-manage/platform/metadata-check';

export type { MetadataCheckTaskSummary } from '@/api/product-manage/platform/metadata-check';

/**
 * 列表是否被截断（仅筛选分支有意义：拉满上限做本地过滤前，后端还有更多）。
 *
 * WHY 不静默：截断而不提示，用户会以为「总共就这些」，排查时永远找不到那条记录。
 */
export const truncated = ref(false);

/**
 * 检查任务列表：直接持有后端返回项，页面按后端字段渲染。
 * 分页模式下只持有**当前页**；筛选模式下是拉满的过滤前全集。
 */
export const checkTasks = reactive<MetadataCheckTaskSummary[]>([]);

/** 默认页大小：一次请求 10 条（用户 2026-11-17 口径「接口一次请求10条」，与 Table 默认 size 一致） */
export const CHECK_PAGE_SIZE = 10;

/** 筛选分支的取数上限（后端列表接口不支持筛选参数，本地过滤只处理到这么多） */
const FILTER_FETCH_LIMIT = 200;

export interface CheckTaskPage {
  items: MetadataCheckTaskSummary[];
  total: number;
}

/**
 * 拉第 pageNum 页（每页 pageSize 条），单页一次请求。
 *
 * CONSTRAINT 2026-11-17 契约变更后接口是 page/pageSize 页码分页：cursor 已废弃，
 * 传 cursor 直接 400（实测）。此前「服务端单响应截断 → 游标链 + 补页 carry」机制整体作废，
 * 不要再往回加。现在先过滤再分页，除末页外单页条数恒等于 pageSize。
 * CONSTRAINT total 语义是「可见检查单数」：被入库/补录消费的单据默认隐藏（includeConsumed=false），
 * 比任务表总数小是契约口径而非数据丢失（实测任务表 23 条 → 列表 total=19）。
 */
export async function loadCheckTasksPage(pageNum = 1, pageSize = CHECK_PAGE_SIZE): Promise<CheckTaskPage> {
  const res = await listMetadataFileChecks({ page: pageNum, pageSize });
  const items = res?.data?.items ?? [];
  const total = res?.data?.total ?? 0;
  checkTasks.splice(0, checkTasks.length, ...items);
  truncated.value = false;
  return { items, total };
}

/**
 * 拉满（仅筛选条件生效时用）：列表接口不支持 keyword/state 参数，只能按页码把上限内
 * 数据拉回交给页面本地过滤。pageSize=200 是契约上限——一页 200 条，不再是旧截断时代
 * 的「每响应 5 条 ×N 连拉」，常规数据量一次请求即全集。
 */
export async function loadCheckTasks(limit = FILTER_FETCH_LIMIT) {
  const items: MetadataCheckTaskSummary[] = [];
  let page = 1;
  let hasMore = false;
  do {
    const res = await listMetadataFileChecks({ page, pageSize: Math.min(FILTER_FETCH_LIMIT, Math.max(CHECK_PAGE_SIZE, limit)) });
    const data = res?.data;
    const got = data?.items ?? [];
    items.push(...got);
    hasMore = !!data?.hasMore && got.length > 0;
    page++;
  } while (hasMore && items.length < limit);
  const kept = items.slice(0, limit);
  checkTasks.splice(0, checkTasks.length, ...kept);
  // 达到条数上限而后端还有更多 = 页面需给用户可见提示
  truncated.value = hasMore;
  return kept;
}

/** 兼容既有调用名；真实接口下进度来自后端，前端不再本地持久化 */
export function persistCheckTasks() {
  // no-op: 列表每次取数均从后端重取
}
