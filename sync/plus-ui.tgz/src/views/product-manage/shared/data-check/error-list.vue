<script setup lang="ts">
import { pt } from '@/lang/modules/pm-i18n';
import { ElMessage } from 'element-plus';
import { CopyDocument, CircleCheckFilled, WarningFilled } from '@element-plus/icons-vue';
import { messageSegments, errorToText, type IndexedError, type MessageSegment, type MessageTone } from './error-utils';

/**
 * 错误账本列表（错误报表 / 检查任务详情共用）。
 *
 * WHY 共用：同一个错误以前在两个弹窗里长得不一样——报表页把 PostgreSQL 多段报错换行了，
 * 详情页却是纯文本一坨；「已解决」一个用 el-tag、一个只靠透明度。抽成同一组件后，
 * 无论从哪个入口进来，序号、错误码、字段、状态、消息分段都完全一致。
 *
 * CONSTRAINT 消息只做结构化呈现，不改字：段标签取自原文已有的 `ERROR:` / `DETAIL:` 等前缀，
 * 复制出来仍是后端原始 message。
 */
defineOptions({ name: 'MetadataCheckErrorList' });

const props = withDefaults(
  defineProps<{
    /** 已编号的错误（indexErrors 的输出），筛选后仍显示原始序号 */
    items: IndexedError[];
    /** 列表最大高度，超出内部滚动；不传则由父容器控制 */
    maxHeight?: string;
    /** 紧凑模式：详情页嵌在长页面里，缩小间距与字号 */
    compact?: boolean;
    /** 无错误时的中性占位文案 */
    emptyText?: string;
  }>(),
  {
    maxHeight: undefined,
    compact: false,
    emptyText: pt('当前检查任务没有错误明细')
  }
);

/** 单条消息分段：有段前缀时按语义行渲染，无前缀时退化为普通正文行 */
function segments(raw?: string): MessageSegment[] {
  return messageSegments(raw);
}

/** 段标签的语义色 class */
function toneClass(tone: MessageTone): string {
  return 'tone--' + tone;
}

/** 复制单条：与「复制全部」保持同一份纯文本快照格式 */
async function copyOne(item: IndexedError) {
  try {
    await navigator.clipboard.writeText(errorToText(item.error, item.index));
    ElMessage.success('已复制第 ' + item.index + ' 条错误');
  } catch {
    ElMessage.warning(pt('复制失败，请手动选择文本'));
  }
}
</script>

<template>
  <div class="error-list" :class="{ 'error-list--compact': compact }" :style="maxHeight ? { maxHeight, overflowY: 'auto' } : undefined">
    <el-empty v-if="!items.length" :description="emptyText" :image-size="56" />
    <template v-else>
      <article
        v-for="item in items"
        :key="item.error.errorUid || item.index"
        class="error-card"
        :class="{ 'error-card--resolved': item.error.resolved }"
      >
        <!-- 左侧序号轨：编号在筛选后仍指向完整账本中的位置 -->
        <div class="card-rail">
          <span class="card-index">{{ String(item.index).padStart(2, '0') }}</span>
        </div>

        <div class="card-body">
          <header class="card-head">
            <span class="code-chip">{{ item.error.code || '未知' }}</span>
            <span v-if="item.error.fieldKey" class="field-chip" :title="'字段 ' + item.error.fieldKey">
              {{ item.error.fieldKey }}
            </span>
            <span class="status-chip" :class="item.error.resolved ? 'status-chip--resolved' : 'status-chip--open'">
              <el-icon class="status-icon">
                <CircleCheckFilled v-if="item.error.resolved" />
                <WarningFilled v-else />
              </el-icon>
              {{ item.error.resolved ? '已解决' : '未解决' }}
            </span>
            <el-button class="copy-btn" link size="small" :icon="CopyDocument" @click="copyOne(item)">{{ pt('复制') }}</el-button>
          </header>

          <!-- 消息正文：原文已有的 ERROR/DETAIL/HINT/CONTEXT 前缀显式化为语义段标签 -->
          <div class="message-block">
            <template v-for="(seg, si) in segments(item.error.message)" :key="si">
              <div v-if="seg.blank" class="msg-blank" />
              <div v-else class="msg-line" :class="toneClass(seg.tone)">
                <span v-if="seg.label" class="msg-label" :class="toneClass(seg.tone)">{{ seg.label }}</span>
                <span class="msg-text">{{ seg.text }}</span>
              </div>
            </template>
          </div>

          <footer v-if="item.error.itemUid" class="card-foot">
            <span v-if="item.error.itemUid" class="meta-token" :title="'数据项 ' + item.error.itemUid">
              <span class="meta-key">数据项</span>{{ item.error.itemUid }}
            </span>
          </footer>
        </div>
      </article>
    </template>
  </div>
</template>

<style scoped lang="scss">
.error-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
  padding-right: 2px;
}

.error-card {
  display: flex;
  gap: 12px;
  padding: 12px 14px 12px 0;
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 8px;
  background: var(--el-bg-color);
  transition:
    border-color 0.18s ease,
    box-shadow 0.18s ease;

  &:hover {
    border-color: var(--el-color-danger-light-5);
    box-shadow: 0 2px 10px rgb(0 0 0 / 4%);
  }
}

.error-card--resolved {
  background: var(--el-fill-color-blank);

  &:hover {
    border-color: var(--el-color-success-light-5);
  }

  .code-chip {
    color: var(--el-text-color-secondary);
    background: var(--el-fill-color);
  }
}

/* 左侧序号轨：用一条竖线把「账本」的连续感做出来 */
.card-rail {
  flex: 0 0 46px;
  align-self: stretch;
  display: flex;
  align-items: flex-start;
  justify-content: center;
  padding-top: 2px;
  border-right: 2px solid var(--el-color-danger-light-7);
}

.error-card--resolved .card-rail {
  border-right-color: var(--el-color-success-light-7);
}

.card-index {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 12px;
  font-weight: 700;
  font-variant-numeric: tabular-nums;
  color: var(--el-color-danger);
}

.error-card--resolved .card-index {
  color: var(--el-color-success);
}

.card-body {
  flex: 1;
  min-width: 0;
}

.card-head {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 10px;
}

.code-chip {
  padding: 2px 8px;
  border-radius: 4px;
  background: var(--el-color-danger-light-9);
  color: var(--el-color-danger);
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 12px;
  font-weight: 600;
  letter-spacing: 0.02em;
}

.field-chip {
  max-width: 220px;
  overflow: hidden;
  padding: 2px 8px;
  border-radius: 4px;
  background: var(--el-fill-color);
  color: var(--el-text-color-regular);
  font-size: 12px;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.status-chip {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 2px 8px;
  border-radius: 10px;
  font-size: 12px;
  line-height: 18px;
  white-space: nowrap;
}

.status-chip--open {
  background: var(--el-color-warning-light-9);
  color: var(--el-color-warning);
}

.status-chip--resolved {
  background: var(--el-color-success-light-9);
  color: var(--el-color-success);
}

.status-icon {
  font-size: 12px;
}

.copy-btn {
  margin-left: auto;
  font-size: 12px;
}

/* 消息正文：等宽 + 保留换行，段标签用左侧色条区分语义 */
.message-block {
  padding: 8px 10px;
  border-left: 2px solid var(--el-border-color);
  border-radius: 0 4px 4px 0;
  background: var(--el-fill-color-lighter);
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 12px;
  line-height: 1.65;
}

.msg-line {
  display: flex;
  gap: 8px;
  white-space: pre-wrap;
  word-break: break-word;
}

.msg-line.tone--error {
  border-left: 2px solid var(--el-color-danger);
  margin-left: -10px;
  padding-left: 8px;
  background: var(--el-color-danger-light-9);
}

.msg-label {
  flex: 0 0 auto;
  font-weight: 700;
  white-space: nowrap;
}

.msg-label.tone--error {
  color: var(--el-color-danger);
}
.msg-label.tone--detail {
  color: var(--el-color-primary);
}
.msg-label.tone--hint {
  color: var(--el-color-warning);
}
.msg-label.tone--context {
  color: var(--el-text-color-secondary);
}

.msg-text {
  min-width: 0;
  color: var(--el-text-color-primary);
}

.msg-blank {
  height: 6px;
}

.card-foot {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-top: 8px;
}

.meta-token {
  max-width: 100%;
  overflow: hidden;
  color: var(--el-text-color-secondary);
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 11.5px;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.meta-key {
  margin-right: 6px;
  padding: 1px 5px;
  border-radius: 3px;
  background: var(--el-fill-color);
  color: var(--el-text-color-secondary);
  font-family: var(--el-font-family);
  font-size: 11px;
}

/* 紧凑模式：详情页里错误列表只是其中一节，不抢视觉权重 */
.error-list--compact {
  gap: 8px;

  .error-card {
    padding-top: 10px;
    padding-bottom: 10px;
  }

  .card-rail {
    flex-basis: 38px;
  }

  .card-head {
    margin-bottom: 8px;
  }

  .message-block {
    font-size: 11.5px;
  }
}
</style>
