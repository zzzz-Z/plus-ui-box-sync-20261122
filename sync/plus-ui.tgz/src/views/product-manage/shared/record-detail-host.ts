import { getCurrentInstance, onActivated, onDeactivated, ref, type Ref } from 'vue';
import type { MetadataAttributeColumn, MetadataAttributeRecord } from '@/api/product-manage/platform/metadata-attributes';
import type { AttributeRowEnrich } from './attribute-row-dialog.vue';

/**
 * 右侧「记录详情」列的宿主契约（布局 ↔ 消费方）。
 *
 * WHY 模块级注册而不是 provide/inject + Teleport（r275 初版方案）：
 *  - 地图要素点击详情的入口 openFeatureDetail 是纯函数，没有 setup 上下文，inject 拿不到宿主，
 *    只能继续走旧悬浮抽屉 —— 而「点图层」与「点列表行」必须是同一份详情视图；
 *  - 两个消费方 Teleport 进同一宿主会叠加渲染，还得靠认领令牌裁决「这一列归谁」，复杂度白给。
 * 所以改成：布局注册宿主 → 消费方只写内容 → 布局集中渲染一份面板。
 *
 * 约定：
 *  - registerRecordDetailHost 在布局 setup 调用，onBeforeUnmount 时 unregister；
 *    KeepAlive 下多个布局并存时，只有「已激活且 DOM 可见」的布局才是当前宿主。
 *    切回缓存页不会重跑 setup，必须靠 onActivated 重新认领；showRecordDetail 也会
 *    再按可见性复核，避免详情写进隐藏页（表现就是点图层后右侧记录详情不出现）；
 *  - showRecordDetail 返回令牌表示「内容已由你打开」；返回 null 表示没有可见布局上下文
 *    （如 __debug 页单独挂 DataQuery / Map），调用方应回落为原来的非模态抽屉；
 *  - closeRecordDetail(token) 按令牌精确收起打开者 —— 属性表卸载清理时，
 *    不会误关别人（如地图）随后打开的详情；
 *  - 面板关闭按钮走宿主自带的 close()，无条件收起本布局自己的列；
 *  - 内容非空 ⇔ 该列显示。布局据此占位，把地图与列表挤向中心，而不是悬浮遮挡。
 */
export interface RecordDetailContent {
  /** 当前查看的一行记录（地图要素由调用方包装成同样形状） */
  row: MetadataAttributeRecord;
  /** 列清单（列名 + 中文标签） */
  columns: MetadataAttributeColumn[];
  /** 头部信息片：资源名 / 表名 / 几何类型等（地图通道传） */
  tags?: string[];
  /** 打开后再补一次权威数据：瓦片属性缺列中文名与部分字段（地图通道传） */
  enrich?: () => Promise<AttributeRowEnrich | null | undefined>;
}

/** 宿主注册后返回的接口，布局侧使用 */
export interface RecordDetailHostApi {
  /** 当前打开的详情内容；null 表示该列收起 */
  content: Ref<RecordDetailContent | null>;
  /** 面板关闭按钮：无条件收起本列 */
  close: () => void;
  /** 布局卸载：注销宿主并清空内容 */
  unregister: () => void;
}

interface HostState {
  content: Ref<RecordDetailContent | null>;
  token: symbol | null;
  /** 布局自身是否真正可见：KeepAlive 缓存页的 DOM 已移出 document，不能算当前宿主 */
  isVisible: () => boolean;
  /** 最近一次认领序号：多个布局同时可见时取最后激活的那个 */
  claimedAt: number;
  registered: boolean;
}

/** 所有已注册且未卸载的布局宿主 */
const hosts = new Set<HostState>();
/** 首选宿主；失效时由 currentHost() 重新挑一个可见宿主 */
let active: HostState | null = null;
let claimSeq = 0;

/** 认领当前宿主：setup 首次挂载、KeepAlive 切回缓存页都会走这里 */
function claim(host: HostState) {
  host.claimedAt = ++claimSeq;
  active = host;
}

/**
 * 取「当前真正可见」的宿主。
 *
 * WHY 不直接用 active：KeepAlive 切页不重跑 setup，active 可能仍指向上一页；
 * 缓存页的 DOM 被移进 storageContainer（isConnected=false / 无矩形），
 * 直接写它会让详情落在看不见的布局里 —— 产品数据浏览点图层就表现为右侧详情不出现。
 */
function currentHost(): HostState | null {
  if (active?.registered && active.isVisible()) return active;
  let best: HostState | null = null;
  for (const host of hosts) {
    if (!host.registered || !host.isVisible()) continue;
    if (!best || host.claimedAt > best.claimedAt) best = host;
  }
  active = best;
  return best;
}

/**
 * 布局侧注册宿主；返回的 unregister 必须在 onBeforeUnmount 里调用。
 * isVisible 由布局用自身容器判断（可选，缺省时按组件根元素判断）。
 */
export function registerRecordDetailHost(isVisible?: () => boolean): RecordDetailHostApi {
  const instance = getCurrentInstance();
  const host: HostState = {
    content: ref(null),
    token: null,
    isVisible: () => {
      if (isVisible) return isVisible();
      const el = (instance?.proxy?.$el ?? instance?.vnode?.el) as unknown as HTMLElement | null | undefined;
      return !!el?.isConnected && el.getClientRects().length > 0;
    },
    claimedAt: 0,
    registered: true
  };
  hosts.add(host);
  claim(host);

  // KeepAlive 切回缓存页不会重跑 setup：激活时重新认领，失活时让出首选位，
  // 下次 showRecordDetail 由 currentHost() 按可见性挑宿主。
  if (instance) {
    onActivated(() => claim(host));
    onDeactivated(() => {
      if (active === host) active = null;
    });
  }

  return {
    content: host.content,
    close() {
      // 关闭按钮属于本布局：无条件收起自己，不再受 active 指向谁影响
      host.content.value = null;
      host.token = null;
    },
    unregister() {
      host.registered = false;
      hosts.delete(host);
      host.content.value = null;
      host.token = null;
      // 自己正是首选时，回退到仍可见的宿主；没有就置空，让调用方回落抽屉
      if (active === host) active = currentHost();
    }
  };
}

/**
 * 打开（或原地切换）记录详情占位列。
 * 返回 null 表示没有可见布局宿主，调用方应回落为抽屉。
 */
export function showRecordDetail(content: RecordDetailContent): symbol | null {
  const host = currentHost();
  if (!host) return null;
  const token = Symbol('record-detail');
  host.content.value = content;
  host.token = token;
  return token;
}

/** 收起记录详情列；带 token 时只允许「当前内容的打开者」关闭 */
export function closeRecordDetail(token?: symbol | null): void {
  // showRecordDetail 返回 null 表示无布局宿主、调用方回落了抽屉，此时不要清别人的列
  if (token === null) return;
  const host = token != null ? [...hosts].find((item) => item.token === token) : currentHost();
  if (!host) return;
  host.content.value = null;
  host.token = null;
}
