<script setup lang="ts">
import { queryState, sampleQuery, toggleQuerySelection } from '@/views/product-manage/shared/map/query/state';
import { getProductCategoryTree } from '@/api/product-manage/platform/category';
import { collectLayerFeatures, listMetadataLayers } from '@/api/product-manage/platform/resources';
import { BEST_EFFORT_HEADER } from '@/utils/request';
import { hashId } from '@/views/product-manage/shared/resource-row';
import { useMap } from '@/views/product-manage/shared/map/use-map';
import { mountVectorTileLayer, unmountVectorTileLayer, restyleVectorTileLayer } from '@/views/product-manage/shared/map/vector-tile-layer';
import { toTileUrl } from '@/api/product-manage/platform/metadata-tiles';
import { openFeatureDetail } from '../map/feature-detail-dialog';
import { useProductPalette } from '../store';
import AttributeTable from '../data-browse/attribute-table.vue';

/**
 * 数据查询（元数据查询 tab）
 *
 * 交互口径（用户 2026-11-04 确认）：
 *   1. **不再有左侧类别树**：查询条件统一在地图上的「数据查询」面板里（默认展开）；
 *   2. 查询结果直接落到下方表格区，用「资源属性表」（AttributeTable）展示 ——
 *      与元数据浏览右侧那张属性表是同一个组件，列由后端元数据表决定；
 *   3. 地图查询面板的每次查询都会写 `queryState.selectedIds` / `queryState.hitFeatures`
 *      （条件查询写 selectedIds，空间查询写 hitFeatures），本组件只把这两处的
 *      resourceUid 归并成「命中资源集合」喂给属性表，不再自己拉 /platform/resources 列表。
 *
 * WHY 命中集合要同时读两处：
 *   条件查询（runSampleQuery）只拿到资源行（没有几何），空间查询（applySpatialQuery）
 *   只有要素级的 hitFeatures；两者互相清空对方，任一处有值就代表「本轮查询结果」。
 */

/**
 * mapVisible：布局下发的「地图是否显示」。
 * 该 prop 现在不参与渲染（表格恒随查询命中走），保留是为了调用方（shared/index.vue、
 * shared/metadata-manage/index.vue）继续按既有契约传参，避免无谓的调用点改动。
 */
defineProps<{ mapVisible?: boolean }>();

const map = useMap();
const { palette } = useProductPalette();

/**
 * 本组件实例：传给 openFeatureDetail 当 owner，让要素详情抽屉随本页面卸载一起销毁。
 * WHY 必须在 setup 顶层取：onFeatureClick 是地图回调，那时 getCurrentInstance() 为 null。
 */
const owner = getCurrentInstance();

/* --------------------------- 查询命中资源集合 --------------------------- */

/** 要素 → resourceUid（两套来源的字段位置不同，统一在此收敛） */
function uidOfHit(feature: any): string {
  return String(feature?.properties?.resourceUid ?? feature?.resourceUid ?? '') || '';
}

/**
 * 本轮查询命中的资源 uid（有序去重）。
 * WHY 保序：属性表的页签顺序 = 传入的 uid 顺序，保持与查询结果一致的阅读顺序。
 */
const hitResourceUids = computed<string[]>(() => {
  // WHY 用 recordUid：条件查询的 results 是 toQueryRow 产出的行对象，资源 uid 落在 recordUid 上
  // （resourceUid 只是接口原始字段名，映射后不再保留）。
  const fromRows = (sampleQuery.results ?? []).map((r: any) => String(r?.recordUid ?? r?.resourceUid ?? ''));
  const fromHits = (queryState.hitFeatures ?? []).map(uidOfHit);
  const seen = new Set<string>();
  const list: string[] = [];
  for (const uid of [...fromRows, ...fromHits]) {
    if (!uid || seen.has(uid)) continue;
    seen.add(uid);
    list.push(uid);
  }
  return list;
});

/** uid → 资源中文名：属性表在多资源时给页签加前缀，避免同名表分不清 */
const hitResourceNames = computed<Record<string, string>>(() => {
  const names: Record<string, string> = {};
  for (const r of sampleQuery.results ?? []) {
    const uid = String(r?.recordUid ?? r?.resourceUid ?? '');
    if (uid) names[uid] = String(r.name || r.resourceName || uid);
  }
  for (const f of queryState.hitFeatures ?? []) {
    const uid = uidOfHit(f);
    if (uid && !names[uid]) names[uid] = String(f?.properties?.name || uid);
  }
  return names;
});

/* --------------------------- 地图图层数据源 --------------------------- */

/**
 * 地图图层数据源：命中行的真实几何。
 *
 * WHY 不能直接把列表行丢给 renderLayers：/platform/resources 列表**不返回几何**，
 * toQueryRow 里的 bbox 只能是 [0, 0, 0, 0] 占位；正确来源是
 * /platform/resources/metadata-layers（geojson），与「数据浏览」同一套链路。
 */
const layerFeatures = ref<any[]>([]);
/** uid → 该资源的要素数组；再次命中同一资源不再重复请求 */
const featureCache = new Map<string, any[]>();

/** 单个资源加载：后端支持 resourceUid 精确过滤，多图层用 cursor 翻完；失败只影响该资源 */
async function fetchOneResource(uid: string) {
  const featureId = hashId(uid);
  // 资源名/类别优先取本轮查询结果里的行，取不到再用后端返回的 resourceName / categoryName
  const row = sampleQuery.results.find((r: any) => String(r?.recordUid ?? r?.resourceUid ?? '') === uid);
  const collected: any[] = [];
  try {
    let cursor: string | undefined;
    do {
      // 载荷拼装收敛在 listMetadataLayers → buildMetadataLayerQuery，页面不拼字段
      const res = await listMetadataLayers({ resourceUid: uid, limit: 50, cursor });
      for (const item of res?.data?.items ?? []) {
        if (!item?.resourceUid) continue;
        // 多表模型：item.geojson 只是首张表，collectLayerFeatures 会一并取出 metadataTables 的几何
        for (const f of collectLayerFeatures(item)) {
          collected.push({
            ...f,
            id: featureId,
            properties: {
              ...f.properties,
              resourceUid: item.resourceUid,
              name: item.resourceName || row?.name || f.properties?.product_name || item.resourceUid,
              // 类别统一用中文名：图例与 palette 的键都是类别名，用 uid 会全量失配
              category: item.categoryName || row?.category || '',
              createTime: f.properties?.update_time || f.properties?.created_at || row?.updatedAt || ''
            }
          });
        }
      }
      cursor = res?.data?.hasMore ? res?.data?.nextCursor : undefined;
    } while (cursor);
  } catch {
    // 该资源几何拉不到就跳过，不影响其它资源
  }
  featureCache.set(uid, collected);
}

/**
 * 并发拉取多个资源的几何。
 * WHY 限并发 5：查询可能一次命中几十条，串行会把上图拖到十几秒；不限并发又会打爆后端。
 */
const FETCH_CONCURRENCY = 5;
async function fetchLayerFeatures(uids: string[]) {
  const queue = [...uids];
  const worker = async () => {
    for (let uid = queue.shift(); uid; uid = queue.shift()) {
      await fetchOneResource(uid);
    }
  };
  await Promise.all(Array.from({ length: Math.min(FETCH_CONCURRENCY, uids.length) }, worker));
}

/**
 * 选中 id → resourceUid：条件查询命中行 → 空间查询命中要素。
 * WHY 要带上两处：id 来源分散（地图点选 / 条件查询 / 空间查询），只查一处会漏。
 */
function resolveUid(id: number): string | undefined {
  return (
    sampleQuery.results.find((r: any) => r.id === id)?.recordUid || uidOfHit((queryState.hitFeatures ?? []).find((f: any) => Number(f?.id) === id))
  );
}

/**
 * 选中集合 → 图层要素（唯一入口）。
 * 两类要素来源：① 空间查询已拿到的命中要素（queryState.hitFeatures）→ 直接复用；
 * ② 条件查询命中的资源行 → 异步拉 metadata-layers 几何。
 *
 * WHY 必须让 hitFeatures 优先：空间查询命中的 id 也能通过 properties.resourceUid 解析出 uid，
 * 之前的实现一律走 ②，而 metadata-layers 的 geojson.features 恒为空（几何只在 MVT 里），
 * 结果就是「提示命中 N 个图层要素、地图上什么也没有」。hitFeatures 是 extent2d 兜底出来的
 * 真实面，直接上图才与提示一致。
 */
async function syncLayersFromSelection(ids: number[]) {
  if (!ids.length) {
    layerFeatures.value = [];
    return;
  }
  const uids: string[] = [];
  const local: any[] = [];
  const hitById = new Map<string, any>((queryState.hitFeatures ?? []).map((f: any) => [String(f?.id), f]));
  const hitUids: string[] = [];
  for (const id of ids) {
    const hit = hitById.get(String(id));
    if (hit) {
      // ① 空间查询命中：几何已在手，直接上图；同时记下 uid 以便挂矢量瓦片图层
      local.push(hit);
      const uid = uidOfHit(hit);
      if (uid && !hitUids.includes(uid)) hitUids.push(uid);
      continue;
    }
    // ② 条件查询命中行：只有 uid，几何要现拉
    const uid = resolveUid(id);
    if (uid && !uids.includes(uid)) uids.push(uid);
  }
  const missing = uids.filter((uid) => !featureCache.has(uid));
  if (missing.length) await fetchLayerFeatures(missing);
  layerFeatures.value = [...uids.flatMap((uid) => featureCache.get(uid) ?? []), ...local];
  void syncVectorTileLayers([...uids, ...hitUids]);
}

/* ---------------------- 矢量瓦片图层（类别配色） ---------------------- */
/** 资源 → 元数据表清单缓存；重复查询同一资源不再请求 */
const tileTablesCache = new Map<string, any[]>();
/** 资源 → 类别中文名（从 metadata-layers 的 categoryName 兜底补齐，图例取色同口径） */
const tileCategoryOf = ref(new Map<string, string>());
/** 瓦片图层同步轮次：连续查询时只让最新一轮写图层 */
let tileSyncToken = 0;

/** 单个资源的元数据表清单：失败按「无表」缓存，避免反复重试打接口 */
async function fetchTileTables(uid: string): Promise<any[]> {
  const cached = tileTablesCache.get(uid);
  if (cached) return cached;
  const tables: any[] = [];
  try {
    const res: any = await listMetadataLayers({ resourceUid: uid, limit: 50 });
    for (const item of res?.data?.items ?? []) {
      if (item?.resourceUid !== uid) continue;
      if (item.categoryName) tileCategoryOf.value.set(uid, String(item.categoryName));
      for (const t of item.metadataTables ?? []) tables.push(t);
    }
  } catch {
    /* 该资源没有元数据表（40404）或拉取失败：缓存空数组 */
  }
  tileTablesCache.set(uid, tables);
  return tables;
}

/**
 * 命中资源 → 挂矢量瓦片图层，颜色取类别配色表（与图例 / 数据浏览同源）。
 *
 * WHY 与 renderLayers 并存：条件查询命中的资源没有几何（列表接口不返回 geojson），
 * renderLayers 画不出来；真正的几何在 metadata-tables 的 MVT 里，只能挂瓦片图层。
 */
async function syncVectorTileLayers(uids: string[]) {
  const m = map.mapInstance.value;
  if (!m) return;
  const token = ++tileSyncToken;
  const needFetch = uids.filter((uid) => !tileTablesCache.has(uid));
  await Promise.all(needFetch.map((uid) => fetchTileTables(uid)));
  // 本轮已被更新的选择取代：放弃挂载，交给最新一轮
  if (token !== tileSyncToken) return;
  const m2 = map.mapInstance.value;
  if (!m2) return;

  const wanted = new Set<string>();
  for (const uid of uids) {
    const category = uidToName.value.get(uid) || tileCategoryOf.value.get(uid) || '';
    const categoryColor = palette[category];
    const tables = tileTablesCache.get(uid) ?? [];
    tables.forEach((t: any, i: number) => {
      if (!t?.metadataTableKey) return;
      const key = `${uid}:${t.metadataTableKey}`;
      wanted.add(key);
      if (mountedTileKeys.value.includes(key)) return;
      mountVectorTileLayer(m2, {
        key,
        url: toTileUrl(uid, t.metadataTableKey, t.tileTemplate),
        label: t.displayName || t.layerName || t.metadataTableComment || t.metadataTableKey,
        color: categoryColor ?? TILE_COLORS[i % TILE_COLORS.length],
        maxzoom: TILE_MAX_ZOOM
      });
    });
  }
  // 卸掉不再需要的（选择变化后不在命中集里的资源）
  for (const key of [...mountedTileKeys.value]) {
    if (!wanted.has(key)) unmountVectorTileLayer(m2, key);
  }
  mountedTileKeys.value = [...wanted];
}

/* ---------------------- 地图瓦片图层配色 ---------------------- */
/** 已挂到地图上的瓦片图层 key（`${resourceUid}:${tableKey}`） */
const mountedTileKeys = ref<string[]>([]);
/** 实测服务端 z≥14 返回 404，声明 maxzoom 让 maplibre 停止取瓦片 */
const TILE_MAX_ZOOM = 13;
/** 类别配色表里没有该类别时的兜底色，多张表按序号区分 */
const TILE_COLORS = ['#2563a8', '#13a8a8', '#e6a23c', '#8b5cf6', '#2ba471', '#f56c6c'];

/** 类别 uid → 中文名：瓦片配色按类别中文名取 palette，映射缺失时退回 TILE_COLORS */
const uidToName = ref(new Map<string, string>());

/**
 * uid → 类别中文名映射。
 * WHY 用类别树接口（/platform/product-categories）而不是 getResourceTree：
 * 资源树节点字段是 uid / name，没有 categoryName，walkTree 一条也收不到（映射恒空）；
 * 类别树的 items 正好是 { categoryUid, categoryName }。
 */
async function loadTreeMaps() {
  const u2n = new Map<string, string>();
  try {
    // WHY 带 x-best-effort：这份映射只用于配色，失败降级即可，
    // 不应因为它弹「登录状态已过期」全屏遮罩把地图点击一起锁死。
    const res: any = await getProductCategoryTree({ headers: { [BEST_EFFORT_HEADER]: '1' } });
    for (const item of res?.data?.items ?? []) {
      if (item?.categoryUid && item?.categoryName) u2n.set(item.categoryUid, item.categoryName);
    }
  } catch {
    // 拉不到映射时瓦片层用兜底色
  }
  uidToName.value = u2n;
}

/**
 * 图例过滤：activeCategories 为 null = 未初始化（全选）→ 全部上图，不做任何裁剪。
 * WHY 不能写成「先算 all 再 resolveActiveCategories(all)」：all 是从要素自身类别派生的，
 * 一旦命中要素的类别为空（后端没给 categoryName），all 就是空集，集合恒空、要素被整体滤掉，
 * 表现为「查询明明命中了，地图上什么都没有」。类别为空的要素一律保留（未知类别不隐藏）。
 */
const mapFeatures = computed(() => {
  const active = queryState.activeCategories;
  if (active === null) return layerFeatures.value;
  const set = new Set(active);
  return layerFeatures.value.filter((f: any) => {
    const category = String(f?.properties?.category ?? '');
    return !category || set.has(category);
  });
});

/* ---------------------- 选择联动 ---------------------- */
/** 选中集合 → 拉几何并上图 */
watch(
  () => [...queryState.selectedIds],
  (ids) => {
    void syncLayersFromSelection(ids);
  },
  { immediate: true }
);

/**
 * 地图侧图层：渲染「本轮命中」的真实几何。
 * WHY 同时 watch mapInstance 与 mapFeatures：地图容器是兄弟组件可能晚于本组件挂载；
 * 几何是异步到达的，只在挂载时渲染一次会因为数据为空而画不出东西。
 */
watch(
  [map.mapInstance, mapFeatures],
  ([m, feats]) => {
    if (!m) return;
    if (!feats.length) {
      // 没有命中时清掉图层，否则旧要素会一直留在图上
      map.clearRenderLayers();
      return;
    }
    map.renderLayers(feats, {
      colorKey: 'category',
      // palette 是 reactive 对象：renderLayers 内部会包成 computed 并 watch，配色方案切换后自动重涂
      palette: { ...palette },
      cluster: true,
      labelKey: 'name',
      // 相机由下方自己 fitBounds：renderLayers 内部 fit 无 try/catch，退化几何会抛错
      fit: false,
      // WHY 显式提供 properties：renderLayers 的 toFeature 默认 { ...record }，
      // 对 GeoJSON Feature 而言会把业务字段埋进 properties.properties，
      // 结果就是分色取不到 category、label 取不到 name、悬停浮窗全空。
      properties: (r: any) => ({ ...(r?.properties ?? {}) }),
      hoverContent: (p: any) => {
        const title = p.sheetNo || p.name || '未命名';
        const nameLine = p.sheetNo && p.name ? `名称：${p.name}` : '';
        return (
          [
            title,
            nameLine,
            p.category ? `类别：${p.category}` : '',
            p.productType ? `类型：${p.productType}` : '',
            p.state ? `状态：${p.state}` : '',
            p.createdAt ? `创建时间：${p.createdAt}` : ''
          ]
            .filter(Boolean)
            .join(' · ') || null
        );
      },
      onFeatureClick: (feature: any, event: any) => {
        // 点击要素 = 勾选 + 弹详情：勾选保持空间查询的既有语义（Shift 多选），
        // 详情复用全项目统一的「要素详情」弹窗（见 map/feature-detail-dialog.tsx）。
        // WHY 在这里补而不是靠 map 的全局监听：这条是 geojson 通道，图层 id 由 genId() 随机生成，
        // 无法反查业务身份，只能由持有要素数据的一方（本组件）把 properties 交出去。
        // WHY Shift 不弹详情：与 use-feature-detail.ts 的公共监听同一口径 —— Shift 是加选，
        // 弹窗会打断连续多选。
        if (!event?.shiftKey) {
          const props = feature?.properties ?? {};
          openFeatureDetail({
            values: props,
            tags: ['查询结果'],
            resourceUid: props.resourceUid ? String(props.resourceUid) : undefined,
            geometryType: String(feature?.geometry?.type ?? ''),
            geometry: feature?.geometry,
            event,
            owner
          });
        }
        const id = Number(feature?.id);
        if (Number.isNaN(id)) return;
        toggleQuerySelection(id, event?.shiftKey ?? true);
      }
    });
    // 几何到达后把相机收到要素范围，保证「查了就看得见」
    try {
      map.getUtils()?.fitBounds({ type: 'FeatureCollection', features: feats } as any);
    } catch {
      // 退化包围盒跳过
    }
  },
  { immediate: true }
);

/**
 * 查询范围轮廓：把「本轮空间查询所用的范围」半透明高亮到地图（与命中要素叠加共存）。
 *
 * WHY 独立于 renderLayers：0 命中时上面的 render watch 会 clearRenderLayers()，
 * 若轮廓与命中要素共用 '__render__' 通道会被一起清掉 —— 那正是「查了海淀区却啥也看不见」的根因。
 * setQueryArea 走 useMap 单例里独立的 source / layer，clearRenderLayers 只清 '__render__'，两者互不干扰。
 *
 * WHY 只认 lastArea 一个数据源：条件查询 / clearQuerySelection 会把它置 null（下方 watch 自动清轮廓），
 * 每次空间查询写入新值（自动重画 + 换范围）；Esc 不清它 —— lastArea 同时是缓冲区查询的基准几何，
 * 顺带清掉会让「缓冲 N km」失去基准。轮廓代表「查的是哪块区域」，本就应在下一次查询前保留。
 *
 * 相机归属：有命中要素时交给上面的 render watch fit 到要素（视觉聚焦数据），这里不 fit，
 * 避免两次 fitBounds 动画打架；0 命中时才由轮廓自己 fit，保证查的区域始终看得见。
 * applySpatialQuery 是在同一同步块里依次写 lastArea / hitFeatures / selectedIds 的，
 * 因此本 watch 回调执行时 hitFeatures 已是本轮最终值，hasHits 判断准确。
 */
watch(
  () => queryState.lastArea,
  (area) => {
    const hasHits = (queryState.hitFeatures ?? []).length > 0;
    map.setQueryArea(area, { fit: !hasHits });
  },
  { immediate: true }
);

/**
 * 配色方案切换 → 已挂载瓦片层重涂。
 *
 * WHY 需要：瓦片颜色在 mount 时写死进 maplibre 的 paint 属性，而图例直接读响应式 palette
 * 实时变色；不重涂就会出现「图例已变色、地图还是旧色」的不一致。
 */
watch(palette, () => {
  const m = map.mapInstance.value;
  if (!m) return;
  for (const key of mountedTileKeys.value) {
    const uid = key.slice(0, key.lastIndexOf(':'));
    const color = palette[uidToName.value.get(uid) || tileCategoryOf.value.get(uid) || ''];
    if (color) restyleVectorTileLayer(m, key, color);
  }
});

/** 键盘：Esc 清除当前选择；输入态与绘制态下不抢键 */
function onSelectionKeydown(e: KeyboardEvent) {
  const t = e.target as HTMLElement | null;
  const tag = (t?.tagName || '').toLowerCase();
  if (tag === 'input' || tag === 'textarea' || tag === 'select' || (t as any)?.isContentEditable) return;
  if (e.key !== 'Escape') return;
  // WHY 绘制模式激活时 Esc 归 draw 引擎（取消绘制），此处不能同时清空选中
  if (sampleQuery.drawTool !== 'none') return;
  if (!queryState.selectedIds.length) return;
  e.preventDefault();
  queryState.selectedIds = [];
  queryState.hitFeatures = [];
}

onMounted(async () => {
  // 类别映射只用于瓦片配色（图例取色同源）；失败降级为兜底色，不阻塞查询
  await loadTreeMaps();
  window.addEventListener('keydown', onSelectionKeydown);
});
onUnmounted(() => {
  window.removeEventListener('keydown', onSelectionKeydown);
  // 瓦片图层挂在 map 单例上，组件卸载不会自动清理，必须显式卸掉
  const m = map.mapInstance.value;
  if (m) {
    for (const key of [...mountedTileKeys.value]) unmountVectorTileLayer(m, key);
  }
  mountedTileKeys.value = [];
  // 范围轮廓用固定 source / layer id，切到别的地图 tab 不会被覆盖，会变成「幽灵轮廓」。
  // 卸载即清；切回来时 watch(queryState.lastArea) 的 immediate 会按仍在的 lastArea 重画。
  map.clearQueryArea();
});
</script>

<template>
  <div class="data-query">
    <!-- 查询结果表格：与元数据浏览右侧的属性表是同一个组件（每资源每表一个页签）。
         默认 / 无命中时不渲染任何内容：布局层（shared/index.vue）据 hasQueryResult
         自动收起整块「详情列表」区让地图独占右列，命中后自动展开列表。
         0 命中的反馈由地图查询面板的 ElMessage 给出，本页不再摆空态占半屏。 -->
    <AttributeTable v-if="hitResourceUids.length" class="data-query__table" :resource-uids="hitResourceUids" :resource-names="hitResourceNames" />
  </div>
</template>

<style scoped lang="scss">
.data-query {
  height: 100%;
  min-height: 0;
  overflow: hidden;
}

.data-query__table {
  height: 100%;
}
</style>
