import { inject, type InjectionKey } from 'vue';

/**
 * 地图显隐控制（布局 → 业务面板 的注入契约）
 *
 * WHY 需要它：地图是否渲染由布局的 viewModes（含 '2'）与 v-if="showMap" 共同决定，
 * 真源在布局；业务面板（数据入库）在「点行 / 点定位按钮」时要保证地图已打开，
 * 但面板拿不到 viewModes，直接改 map store 的 mapInstance 也不会让 Map 组件挂载。
 * 由布局 provide 一个「确保地图可见」方法，面板 inject 后调用，不破坏 viewModes 单一真源。
 *
 * 未注入（独立挂载，如 __debug 页单独挂面板）时 useMapVisibility 返回 null，调用方静默跳过。
 */
export interface MapVisibility {
  /** 当前布局地图未打开则打开；已打开时什么都不做 */
  ensureMapVisible: () => void;
}

export const MAP_VISIBILITY_KEY: InjectionKey<MapVisibility> = Symbol('product-map-visibility');

/** 面板侧取地图显隐控制器；返回 null 表示没有布局上下文（独立挂载场景） */
export function useMapVisibility(): MapVisibility | null {
  return inject(MAP_VISIBILITY_KEY, null);
}
