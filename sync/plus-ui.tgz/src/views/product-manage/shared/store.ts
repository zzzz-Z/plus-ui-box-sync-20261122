import { recordsToFeatures } from '@/views/product-manage/shared/metadata-manage/record-map';
import { getAllMetadataRecords } from '@/api/product-manage/adapter/records';
import { buildSampleRecords } from '@/api/product-manage/mock/db';
import { listProductCategories } from '@/api/product-manage/platform/category';
import { BEST_EFFORT_HEADER } from '@/utils/request';
import { collectLeafNames } from '@/views/product-manage/shared/data-into-store/category-scope';
import {
  alignColors,
  cloneScheme,
  defaultBorderOf,
  fallbackColor,
  nextSchemeName,
  PALETTE_PRESETS,
  schemeFromColors
} from '@/api/product-manage/mock/palette';
import type { PaletteScheme } from '@/api/product-manage/mock/palette';
import type { MetadataRecord } from '@/api/product-manage/types';

const PALETTE_STORAGE_KEY = 'mdm.paletteState';

interface PersistedPalette {
  schemes: PaletteScheme[];
  activeId: string;
  colors: Record<string, string>;
  borderColors: Record<string, string>;
}

/** 直读本地配色状态；损坏或缺失时回退到内置标准方案 */
function readPersistedPalette(): PersistedPalette {
  const standard = PALETTE_PRESETS[0];
  // CONSTRAINT 首次加载不回退到内置 mock 配色：颜色以产品类型管理的后端 color 为唯一真源，
  // 本地只做缓存；后端返回前为空，展示层按「未设置」占位（不虚构颜色）。
  const fallback = (): PersistedPalette => ({
    schemes: PALETTE_PRESETS.map((scheme) => cloneScheme(scheme)),
    activeId: standard.id,
    colors: {},
    borderColors: {}
  });
  try {
    const raw = localStorage.getItem(PALETTE_STORAGE_KEY);
    return raw ? (JSON.parse(raw) as PersistedPalette) : fallback();
  } catch {
    return fallback();
  }
}

/**
 * 产品元数据记录共享状态（数据源由记录接口提供）
 *
 * 单次异步加载记录数据，供地图图层、数据浏览/查询、数据资产报告等
 * 记录类面板共用同一份数据源；features / sampleRecords 为派生视图，其 id 与
 * record 一致，保证地图要素与列表选择联动对齐。load 幂等，多处调用只拉取一次。
 */
export const useProductRecords = createSharedComposable(() => {
  const records = ref<MetadataRecord[]>([]);
  const loading = ref(false);
  let loaded = false;
  let pending: Promise<void> | null = null;

  /** 幂等加载：并发调用复用同一 Promise，加载完成后再次调用直接返回；force 为真时强制刷新 */
  function load(force = false): Promise<void> {
    if (loaded && !force) return Promise.resolve();
    if (pending) return pending;
    loading.value = true;
    pending = getAllMetadataRecords()
      .then((res) => {
        records.value = res?.data ?? [];
        loaded = true;
      })
      .finally(() => {
        loading.value = false;
        pending = null;
      });

    return pending;
  }

  /** 地图图层要素（record.bbox → GeoJSON Polygon） */
  const features = computed(() => recordsToFeatures(records.value));
  /** 数据查询样本（在记录上派生传感器/图号/分辨率等扩展字段） */
  const sampleRecords = computed(() => buildSampleRecords(records.value));

  return { records, features, sampleRecords, loading, load };
});

/**
 * 产品配色表共享状态（内置 + 自定义方案，统一驱动产品管理地图）
 *
 * - palette / borderPalette 为「当前生效」的类别→颜色映射，同步从 mock 初始化，
 *   首屏即有色（本地持久化）；产品地图（map/index.vue）、数据查询、元数据编辑等共用同一实例，
 *   在产品类型管理处切换 / 编辑配色后，各地图实时联动。
 * - schemes 为内置预设（标准/暖色/冷色/地质）+ 用户自定义方案；activeId 为当前生效方案。
 * - 类别集合来自产品类别接口：新增类别补齐兜底色、
 *   删除类别剔除配色、重命名保留原配色，由本模块统一写入，保证各地图/图例与配置对齐。
 * - 约定：UI 反馈（ElMessage / 确认框）由组件层负责，本模块只做数据与持久化。
 */
export const useProductPalette = createSharedComposable(() => {
  // 当前生效配色（同步初始化，地图与产品类型表共用）
  const initial = readPersistedPalette();
  const palette = reactive<Record<string, string>>({ ...initial.colors });
  const borderPalette = reactive<Record<string, string>>({ ...initial.borderColors });
  // 方案列表（内置 + 自定义）与当前生效方案 id
  const schemes = ref<PaletteScheme[]>(initial.schemes.map((scheme) => cloneScheme(scheme)));
  const activeId = ref<string>(initial.activeId);

  const activeScheme = computed(() => schemes.value.find((scheme) => scheme.id === activeId.value));

  /** 配色键基准：由类别接口异步填充，避免模块初始化时依赖后端可用性 */
  const categoryNames = ref<string[]>([]);
  const categories = () => categoryNames.value;

  /** 直接持久化到 localStorage（本模块是配色状态的唯一持有者） */
  function persist() {
    const state: PersistedPalette = {
      schemes: schemes.value.map((scheme) => cloneScheme(scheme)),
      activeId: activeId.value,
      colors: { ...palette },
      borderColors: { ...borderPalette }
    };
    localStorage.setItem(PALETTE_STORAGE_KEY, JSON.stringify(state));
  }

  function replaceAll(target: Record<string, string>, source: Record<string, string>) {
    Object.keys(target).forEach((key) => delete target[key]);
    Object.assign(target, source);
  }

  /**
   * 将配色键对齐到当前产品类型配置：补齐新增类别（内置配色 / 兜底色），剔除已删除类别。
   * 产品类型管理保存、删除后调用；初始化时也调用一次，纠正历史遗留的孤立配色键。
   */
  function syncCategories(names: string[] = categories()) {
    let changed = false;
    names.forEach((category, index) => {
      // 无后端 color 时的本地兜底：按索引等分色相生成，不使用 mock 内置色
      if (!palette[category]) {
        palette[category] = fallbackColor(index, names.length);
        changed = true;
      }
      if (!borderPalette[category]) {
        borderPalette[category] = defaultBorderOf(palette[category]);
        changed = true;
      }
    });
    Object.keys(palette).forEach((category) => {
      if (!names.includes(category)) {
        delete palette[category];
        delete borderPalette[category];
        changed = true;
      }
    });
    if (changed) persist();
  }

  /**
   * 按后端返回的类别对象同步配色：后端 color 为权威来源（非空时覆盖本地），
   * 空 color 保留本地值（不把用户已经调好的地图配色清掉）。
   */
  function syncCategoriesFromServer(items: Array<{ categoryName?: string; color?: string }> = []) {
    let changed = false;
    for (const item of items) {
      const name = item.categoryName;
      if (!name) continue;
      const color = item.color;
      if (color && palette[name] !== color) {
        palette[name] = color;
        if (!borderPalette[name]) borderPalette[name] = defaultBorderOf(color);
        changed = true;
      }
    }
    if (changed) persist();
  }

  /** 类别重命名：把原类别的填充色 / 边框色迁移到新名称 */
  function renameCategory(from: string, to: string) {
    if (!from || !to || from === to) return;
    if (palette[from]) {
      palette[to] = palette[from];
      delete palette[from];
    }
    if (borderPalette[from]) {
      borderPalette[to] = borderPalette[from];
      delete borderPalette[from];
    }
    persist();
  }

  /** 就地设置某类别填充色（产品类型表 / 地图图例直接编辑），边框色缺省自动派生 */
  function setColor(category: string, color?: string) {
    if (!category || !color) return;
    palette[category] = color;
    if (!borderPalette[category]) borderPalette[category] = defaultBorderOf(color);
    persist();
  }

  /** 就地设置某类别边框色 */
  function setBorderColor(category: string, color?: string) {
    if (!category || !color) return;
    borderPalette[category] = color;
    persist();
  }

  /** 套用某方案为当前生效配色（写入实时 palette，各地图联动） */
  function applyScheme(id: string) {
    const scheme = schemes.value.find((item) => item.id === id);
    if (!scheme) return;
    activeId.value = scheme.id;
    replaceAll(palette, alignColors(scheme.colors, categories()));
    replaceAll(borderPalette, alignColors(scheme.borderColors, categories()));
    persist();
  }

  /** 新建自定义方案（默认复制当前生效配色，或从 fromId 方案复制） */
  function createScheme(fromId?: string, name?: string) {
    const source = fromId ? schemes.value.find((item) => item.id === fromId) : undefined;
    const colors = source ? source.colors : { ...palette };
    const borderColors = source ? source.borderColors : { ...borderPalette };
    const scheme = schemeFromColors(
      `custom-${Date.now()}`,
      name || nextSchemeName(schemes.value.map((item) => item.name)),
      colors,
      borderColors,
      false,
      categories()
    );
    schemes.value.push(scheme);
    persist();
    return scheme;
  }

  /** 将当前生效配色保存进方案：传入自定义方案 id 则覆盖，否则新建自定义方案并设为当前 */
  function saveCurrentAsScheme(id?: string, name?: string) {
    const scheme = id ? schemes.value.find((item) => item.id === id) : undefined;
    if (scheme && !scheme.builtin) {
      scheme.colors = alignColors({ ...palette });
      scheme.borderColors = alignColors({ ...borderPalette });
      if (name) scheme.name = name;
      persist();
      return scheme;
    }
    const created = schemeFromColors(
      `custom-${Date.now()}`,
      name || nextSchemeName(schemes.value.map((item) => item.name)),
      { ...palette },
      { ...borderPalette },
      false,
      categories()
    );
    schemes.value.push(created);
    activeId.value = created.id;
    persist();
    return created;
  }

  /** 重命名自定义方案（内置方案不可重命名） */
  function renameScheme(id: string, name: string) {
    const scheme = schemes.value.find((item) => item.id === id);
    if (!scheme || scheme.builtin || !name.trim()) return;
    scheme.name = name.trim();
    persist();
  }

  /** 复制任意方案为新的自定义方案 */
  function copyScheme(id: string) {
    const source = schemes.value.find((item) => item.id === id);
    if (!source) return undefined;
    const scheme = cloneScheme(source, {
      id: `custom-${Date.now()}`,
      name: nextSchemeName(
        schemes.value.map((item) => item.name),
        `${source.name} 副本`
      ),
      builtin: false
    });
    schemes.value.push(scheme);
    persist();
    return scheme;
  }

  /** 删除自定义方案（内置不可删；删掉当前生效方案则回退到标准配色） */
  function deleteScheme(id: string) {
    const index = schemes.value.findIndex((item) => item.id === id);
    if (index < 0 || schemes.value[index].builtin) return;
    schemes.value.splice(index, 1);
    if (activeId.value === id) activeId.value = PALETTE_PRESETS[0].id;
    persist();
  }

  /** 保存配色板编辑器草稿到指定方案；若为当前生效方案则同步到实时 palette */
  function updateSchemeColors(id: string, colors: Record<string, string>, borderColors?: Record<string, string>) {
    const scheme = schemes.value.find((item) => item.id === id);
    if (!scheme) return;
    scheme.colors = alignColors(colors, categories());
    scheme.borderColors = alignColors(borderColors ?? scheme.borderColors, categories());
    if (id === activeId.value) {
      Object.assign(palette, scheme.colors);
      Object.assign(borderPalette, scheme.borderColors);
    }
    persist();
  }

  /** 恢复默认：清除自定义方案与本地覆盖，回到 4 套内置 + 标准生效 */
  function resetPalette() {
    schemes.value = PALETTE_PRESETS.map((scheme) => cloneScheme(scheme));
    applyScheme(PALETTE_PRESETS[0].id);
  }

  // 初始化：拉取真实类别后对齐配色（叶子类别补色、已删除类别清色）
  // 同时用后端返回的 color 覆盖本地 mock 兜底色 —— 图例/地图展示以真实配置为准
  // WHY 带 x-best-effort：本次拉取只影响配色对齐，失败已由下方 catch 降级为 syncCategories([])。
  // 若不标记，401 会被全局拦截器弹成「登录状态已过期」——那个框带全屏遮罩，
  // 会把地图上的点击/绘制全部吞掉（2026-10-24 实测复现），与这里的降级意图正相反。
  listProductCategories({ headers: { [BEST_EFFORT_HEADER]: '1' } })
    .then((res) => {
      const items = (res?.data?.items ?? []) as any[];
      categoryNames.value = [...collectLeafNames(items)];
      syncCategories(categoryNames.value);
      syncCategoriesFromServer(items);
    })
    .catch(() => syncCategories([]));

  return {
    palette,
    borderPalette,
    schemes,
    activeId,
    activeScheme,
    syncCategories,
    syncCategoriesFromServer,
    renameCategory,
    setColor,
    setBorderColor,
    applyScheme,
    createScheme,
    saveCurrentAsScheme,
    renameScheme,
    copyScheme,
    deleteScheme,
    updateSchemeColors,
    resetPalette,
    persist
  };
});
