/**
 * 资源行（/platform/resources → 前端行对象）的公共映射
 *
 * WHY 单独成文件：`map/query/state.ts`（查询面板）与 `data-query/index.vue`（列表页）
 * 都要用「资源 → 行」的映射和 id 生成规则；放在其中一边会造成循环依赖。
 *
 * 重要事实（踩过）：资源列表接口**不返回几何**（ResourceSummary 无 bbox / geometry），
 * 这里的 bbox 只能是 [0, 0, 0, 0] 占位。地图要画要素必须另取
 * GET /platform/resources/metadata-layers 的 geojson，不能拿这个 bbox 当真实范围。
 */
import type { SampleRecord } from '@/api/product-manage/types';

export type QueryRow = SampleRecord;

/** 稳定数字 id：把 resourceUid 哈希成 32 位整数（地图/选择集合用 number） */
export function hashId(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) {
    h = ((h << 5) - h + s.charCodeAt(i)) | 0;
  }
  return Math.abs(h);
}

/**
 * 真实资源 → QueryRow 映射（后端 /platform/resources）；真实缺失字段置空，列渲染兜底 '-'。
 *
 * category 用**类别中文名**（后端 categoryName）而不是 categoryUid：
 * 图例、palette 配色表、导出 CSV、逐列筛选全部按中文名对齐，
 * 早先填 uid 会让「地图分色为空 / 树筛选不命中」两处同时失效。
 * 原始 uid 另存 categoryUid，供类别树联动走后端过滤。
 */
export function toQueryRow(r: any, idx: number): QueryRow {
  const uid = r?.resourceUid || String(idx);
  const id = r?.resourceUid ? hashId(r.resourceUid) : idx;
  return {
    id,
    recordUid: uid,
    modelUid: '',
    tableUid: '',
    tableName: '',
    category: r?.categoryName || r?.categoryUid || '',
    categoryUid: r?.categoryUid || '',
    name: r?.name || r?.resourceName || '',
    version: r?.version != null ? String(r.version) : r?.versionCount != null ? String(r.versionCount) : '',
    dataLevel: '公开',
    region: '',
    bbox: [0, 0, 0, 0],
    description: r?.description || '',
    operator: '',
    createdAt: r?.createdAt || '',
    updatedAt: r?.updatedAt || '',
    sensor: '',
    sheetNo: '',
    resolution: '',
    featureCode: '',
    tileLevel: '',
    tileSpec: '',
    productType: r?.dataType || '',
    taskId: '',
    training: '',
    path: '',
    // 以下三项来自 /platform/resources：状态列与数据数/版本数列直接消费它们
    state: r?.state ?? '',
    dataCount: typeof r?.dataCount === 'number' ? r.dataCount : undefined,
    versionCount: typeof r?.versionCount === 'number' ? r.versionCount : undefined
  } as any;
}
