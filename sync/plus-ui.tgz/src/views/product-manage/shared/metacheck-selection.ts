/**
 * 检查 ↔ 入库的共享文件选择上下文。
 *
 * WHY 必须存在（业务硬约束，不是设计偏好）：需求文档 §1 明确
 * 「检查页面和入库页面必须共用同一份文件选择结果，**禁止在入库页重新拼一套文件清单**」。
 * 若两页各自拼，用户会在检查页看到 A 组文件、在入库页被服务端按 B 组复核，触发
 * `409 CHECK_BINDING_MISMATCH`；更糟的是两者都「看起来成功」，只有执行期才炸。
 *
 * WHY 用模块级 reactive 而非 Pinia store：
 * 这份上下文只在「检查页 → 切 tab → 入库页」这一段生命周期内有效，且必须在
 * `createDialog` 挂到 body 的弹窗里也能读到 —— 弹窗 vnode 无 parent，`inject` 链是断的
 * （本项目既有范式，见 data-check/edit.vue 对 categoryRoot 的同类处理），
 * 而 Pinia 需要 app 上下文注入。模块级单例两条都满足，且不会污染全局 store。
 *
 * CONSTRAINT 不持久化到 localStorage：文件选择与 checkUid 是「本次操作」的临时态，
 * 刷新后后端才是唯一真源（入库侧可用 row.checkUid 重新绑定）。持久化反而会让用户
 * 下次打开看到一个早已失效的 checkUid。
 */
import { computed, reactive, readonly } from 'vue';

/** 来源类型机器码，与检查/入库契约同值域 */
export type MetacheckSourceType = 'upload' | 'registered_share' | 'direct_shared_path';

/**
 * 共享选择上下文。
 *
 * 字段语义与提交载荷一一对应，页面不得在其中塞展示专用数据（展示名放 fileNames）。
 */
export interface MetacheckSelection {
  /** 检查单号：入库绑定的唯一依据；检查未受理成功时为空串 */
  checkUid: string;
  /** 该检查是否 `accepted=true`（能否入库）；未知时 false（fail-closed） */
  accepted: boolean;
  /** 已登记共享位置 uid；upload / direct 来源为空串 */
  locationUid: string;
  /** 来源数据根（= browse 返回的 data.dataRootPath），提交给 dataRootPath */
  dataRootPath: string;
  /** 选中文件相对路径（= entry.relativePath），提交给 files */
  files: string[];
  /** 选中文件显示名，仅 UI 用，不提交 */
  fileNames: string[];
  /** 来源类型机器码 */
  sourceType: MetacheckSourceType;
  /** 产品类别 uid */
  categoryUid: string;
  /** 元数据模型 uid */
  modelUid: string;
  /** 检查任务名称，用于入库页摘要展示 */
  taskName: string;
  /** 最近一次写入时间戳（毫秒）；用于排查「上下文何时被写入」 */
  updatedAt: number;
}

/** 空上下文（clearSelection 与首次读取共用，避免两处各写一份默认值） */
function emptySelection(): MetacheckSelection {
  return {
    checkUid: '',
    accepted: false,
    locationUid: '',
    dataRootPath: '',
    files: [],
    fileNames: [],
    sourceType: 'registered_share',
    categoryUid: '',
    modelUid: '',
    taskName: '',
    updatedAt: 0
  };
}

/**
 * 单例状态。
 *
 * CONSTRAINT 数组字段在 setSelection 里**拷贝**而非持有调用方引用：检查页的表单
 * `model.files` 在用户继续勾选时会被原地变更，若这里持有同一引用，
 * 「提交时的选择」会随表单后续编辑一起漂移 —— 那就等于没有快照。
 */
const state = reactive<MetacheckSelection>(emptySelection());

/** 是否有可用的选择结果：至少要有一个已受理的检查单或一组已选文件 */
export const hasSelection = computed(() => !!state.checkUid || state.files.length > 0);

/** 是否已绑定一个可入库的检查单（入库页据此默认进 require_passed 模式） */
export const hasAcceptedCheck = computed(() => !!state.checkUid && state.accepted);

/** 只读视图：页面读它做展示，写一律走 setSelection / clearSelection */
export const selection = readonly(state);

/**
 * 写入（或增量更新）上下文。
 *
 * WHY 用 patch 而非整体替换：检查页在「表单提交成功」和「行内去入库」两处写入，
 * 各自只掌握一部分字段（前者有 files/taskName，后者只有 checkUid + 列表行信息），
 * 整体替换会让后写者把前者的字段清空。
 */
export function setSelection(patch: Partial<MetacheckSelection>): void {
  if (patch.files) state.files = [...patch.files];
  if (patch.fileNames) state.fileNames = [...patch.fileNames];
  for (const key of ['checkUid', 'locationUid', 'dataRootPath', 'sourceType', 'categoryUid', 'modelUid', 'taskName'] as const) {
    if (patch[key] !== undefined) (state as Record<string, unknown>)[key] = patch[key];
  }
  if (patch.accepted !== undefined) state.accepted = patch.accepted;
  state.updatedAt = Date.now();
}

/** 清空（入库页「改为直接入库」/ 检查单失效时调用） */
export function clearSelection(): void {
  Object.assign(state, emptySelection());
}

/**
 * 检查记录变成不可入库时，就地撤销绑定。
 *
 * WHY 单独提供：入库页在 checkUid 已失效（被删 / 被重检覆盖 / accepted 变 false）时
 * 必须放弃绑定，否则用户会拿一个不可用的 checkUid 去提交并收到 409。
 * 返回是否发生了撤销，便于调用方决定要不要提示。
 */
export function revokeCheck(reason = ''): boolean {
  if (!state.checkUid) return false;
  state.checkUid = '';
  state.accepted = false;
  state.taskName = reason;
  state.updatedAt = Date.now();
  return true;
}
