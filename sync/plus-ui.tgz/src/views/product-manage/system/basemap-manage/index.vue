<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
import * as api from '@/api/product-manage/platform/basemap';
import { BASEMAP_TYPE_LABELS } from '@/api/product-manage/platform/basemap';
import type { BasemapListParams } from '@/api/product-manage/platform/basemap';
import { Delete, Edit, Plus } from '@element-plus/icons-vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import EditForm from './edit.vue';

const table = ref();
const queryParams = reactive({ keyword: '' });

const TYPE_LABELS = BASEMAP_TYPE_LABELS;

const columns: TableColumn[] = [
  { label: pt('图层名称'), prop: 'name', minWidth: 160 },
  {
    label: pt('类型'),
    width: 90,
    render: ({ row }) => <el-tag size="small">{TYPE_LABELS[row.type] ?? row.type}</el-tag>
  },
  { label: pt('服务地址'), prop: 'url', minWidth: 300, showOverflowTooltip: true },
  { label: pt('瓦片大小'), prop: 'tileSize', width: 90 },
  {
    /** 默认地图：全局最多一条，用标签直观标出，否则用户只能点进弹窗才知道哪张是默认 */
    label: pt('默认地图'),
    width: 100,
    align: 'center',
    render: ({ row }) =>
      row.isDefault ? (
        <el-tag type="success" size="small">
          默认
        </el-tag>
      ) : (
        <span class="text-gray-400">-</span>
      )
  },
  { label: pt('描述'), prop: 'description', minWidth: 160, showOverflowTooltip: true },
  {
    action: true,
    label: pt('操作'),
    render: ({ row }) => (
      <>
        <el-button type="primary" icon={Edit} link title="编辑" onClick={() => openEdit(row)} />
        <el-button type="danger" icon={Delete} link title="删除" onClick={() => deleteRow(row)} />
      </>
    )
  }
];

/** 配置变更后刷新列表 */
function refresh() {
  table.value?.getData();
}

async function deleteRow(row: any) {
  try {
    await ElMessageBox.confirm(`确认删除底图「${row.name}」？`, pt('提示'), {
      confirmButtonText: pt('确定'),
      cancelButtonText: pt('取消'),
      type: 'warning'
    });
  } catch {
    return;
  }
  // 真实接口的错误口径是 HTTP 4xx + body.code 同步（404 底图不存在 / 409 名称冲突），
  // 请求拦截器已把失败统一转成 reject，故这里只需成功分支；失败提示由拦截器弹 message。
  await api.deleteBasemap(row.uid);
  ElMessage.success(pt('删除成功'));
  refresh();
}

function openEdit(row?: any) {
  createDialog({
    title: row ? pt('编辑底图') : pt('新增底图'),
    width: '640px',
    afterSave: refresh,
    render: () => <EditForm row={row} />
  });
}

/**
 * Table 分页字段名覆盖。
 * CONSTRAINT Table 组件默认发 `page`（见 components/product-manage/table/index.vue 的
 * `_requestCfg` 默认 `page: 'page'`），而后端契约只认 `pageNum` —— 实测：
 * `?page=2` 返回第 1 页数据（参数被忽略），`?pageNum=2` 才真正翻页。
 * 不改这一项，分页器点了永远停在第 1 页（接口 200 但内容不变，极难发现）。
 */
const requestCfg = { page: 'pageNum' };

/**
 * Table 的 request 回调。
 * CONSTRAINT 必须显式挑白名单字段：Table 无条件注入分页参数，
 * 透传多余字段会被后端参数校验拒收（契约 additionalProperties 严格）。
 */
function getData(params: Params) {
  const query: BasemapListParams = {
    keyword: params.keyword || undefined,
    pageNum: params.pageNum,
    pageSize: params.pageSize
  };
  return api.listBasemaps(query);
}
</script>

<template>
  <div class="product-system-page">
    <Table ref="table" :columns="columns" :request="getData" :query-params="queryParams" :request-cfg="requestCfg" row-key="uid">
      <template #search>
        <el-input v-model="queryParams.keyword" :label="pt('图层名称')" />
      </template>

      <template #action>
        <el-button type="primary" :icon="Plus" @click="openEdit()"> 新增 </el-button>
      </template>
    </Table>
  </div>
</template>

<style lang="scss" scoped>
/* 撑满 AppMain 的路由视图容器（父级 .app-main__view 已限定高度） */
.product-system-page {
  height: 100%;
  min-height: 0;
  overflow: hidden;
}
</style>
