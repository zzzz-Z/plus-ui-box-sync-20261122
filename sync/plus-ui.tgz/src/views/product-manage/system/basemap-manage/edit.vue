<script setup lang="tsx">
import { pt } from '@/lang/modules/pm-i18n';
import { buildBasemapPayload, saveBasemap } from '@/api/product-manage/platform/basemap';
import { ElMessage } from 'element-plus';

/**
 * 表单模型字段与接口输入一一对应；实际提交前一律经 buildBasemapPayload 投影,
 * 页面只负责收集业务输入，不拼接口字段名（契约变更只改门面一处）。
 */
interface BasemapForm {
  uid?: string;
  name: string;
  type: 'xyz' | 'wms' | 'wmts' | 'offline';
  url: string;
  tileSize: number;
  wmsLayers?: string;
  wmsStyles?: string;
  wmsFormat?: string;
  wmsVersion?: string;
  wmsTransparent?: boolean;
  description?: string;
  isDefault?: boolean;
}

const props = defineProps<{ row?: Partial<BasemapForm> }>();
const emit = defineEmits<{ (e: 'saved'): void }>();
const form = ref();

const model = reactive<BasemapForm>({
  uid: props.row?.uid,
  name: props.row?.name ?? '',
  type: props.row?.type ?? 'xyz',
  url: props.row?.url ?? '',
  tileSize: props.row?.tileSize ?? 256,
  wmsLayers: props.row?.wmsLayers ?? '',
  wmsStyles: props.row?.wmsStyles ?? '',
  wmsFormat: props.row?.wmsFormat ?? 'image/png',
  wmsVersion: props.row?.wmsVersion ?? '1.1.1',
  wmsTransparent: props.row?.wmsTransparent ?? true,
  description: props.row?.description ?? '',
  // 编辑时回填真实值；新增时默认不勾选（契约缺省 false，且默认底图全局最多一条）
  isDefault: props.row?.isDefault ?? false
});

const typeOptions = [
  { label: pt('XYZ 图层'), value: 'xyz' },
  { label: pt('WMS 图层'), value: 'wms' },
  { label: pt('WMTS 图层'), value: 'wmts' }
];

const formatOptions = [
  { label: 'PNG', value: 'image/png' },
  { label: 'JPEG', value: 'image/jpeg' },
  { label: 'WebP', value: 'image/webp' }
];

const versionOptions = [
  { label: '1.1.1', value: '1.1.1' },
  { label: '1.3.0', value: '1.3.0' }
];

async function save() {
  // 校验与缺省值统一收敛到 buildBasemapPayload；此处只负责把异常转成 createDialog 认识的失败返回
  let payload;
  try {
    payload = buildBasemapPayload(model);
  } catch (error) {
    return { code: 1, message: (error as Error).message };
  }
  await saveBasemap(payload);
  ElMessage.success(pt('保存成功'));
  emit('saved');
  return { code: 0, message: pt('保存成功') };
}

defineExpose({ save, form });
</script>

<template>
  <Form ref="form" :model="model" :span="24">
    <el-input v-model="model.name" :label="pt('图层名称')" :placeholder="pt('如 XYZ 图层')" required />
    <el-select v-model="model.type" :label="pt('图层类型')" :options="typeOptions" required />
    <el-input
      v-model="model.url"
      :label="pt('服务地址')"
      :span="24"
      :placeholder="model.type === 'wms' ? 'https://example.com/geoserver/wms' : 'https://example.com/{z}/{x}/{y}.png'"
      required
    />
    <el-input-number v-model="model.tileSize" :label="pt('瓦片大小')" :min="64" :max="1024" :step="64" :span="12" />
    <!-- 默认地图：勾选后服务端会自动取消其它底图的默认标记（全局最多一条） -->
    <el-checkbox v-model="model.isDefault" :label="pt('设为默认地图')" />
    <template v-if="model.type === 'wms'">
      <el-input v-model="model.wmsLayers" :span="12" :label="pt('图层')" placeholder="workspace:layer" />
      <el-input v-model="model.wmsStyles" :span="12" :label="pt('样式')" :placeholder="pt('留空使用默认样式')" />
      <el-select v-model="model.wmsFormat" :span="12" :label="pt('格式')" :options="formatOptions" />
      <el-select v-model="model.wmsVersion" :span="12" :label="pt('WMS 版本')" :options="versionOptions" />
      <el-checkbox v-model="model.wmsTransparent" :label="pt('透明背景')" />
    </template>
    <el-input v-model="model.description" label="描述" placeholder="可选" />
  </Form>
</template>
