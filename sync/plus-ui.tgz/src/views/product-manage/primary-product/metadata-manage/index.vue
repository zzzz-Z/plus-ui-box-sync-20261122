<script setup lang="tsx">
import MetaDataManage from '../../shared/metadata-manage/index.vue';
provide('product-category-root', 'primary');
</script>
<template>
  <MetaDataManage />
</template>

<style lang="scss" scoped></style>
