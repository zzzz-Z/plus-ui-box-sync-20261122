<script setup lang="ts">
import Layout from '@/views/product-manage/shared/index.vue';
provide('product-category-root', 'land_sea_primary');
</script>

<template>
  <Layout context="primary" />
</template>
