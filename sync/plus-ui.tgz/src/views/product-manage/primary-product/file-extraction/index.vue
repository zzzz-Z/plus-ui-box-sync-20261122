<script setup lang="tsx">
import FileExtraction from '../../shared/data-extraction/index.vue';
provide('product-category-root', 'primary');
</script>
<template>
  <FileExtraction />
</template>

<style lang="scss" scoped></style>
