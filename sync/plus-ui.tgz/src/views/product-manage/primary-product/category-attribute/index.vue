<script setup lang="ts">
import Layout from '@/views/product-manage/shared/index.vue';
provide('product-category-root', 'attribute_primary');
</script>

<template>
  <Layout context="primary" />
</template>
