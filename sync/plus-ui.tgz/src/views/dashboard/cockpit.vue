<template>
  <div class="cockpit-page">
    <iframe class="cockpit-frame" :src="frameSrc" title="运行驾驶舱" frameborder="0"></iframe>
  </div>
</template>

<script setup lang="ts" name="Cockpit">
/**
 * 运行驾驶舱（第一版）
 *
 * 说明：
 * 1. 头部（Navbar）、标签栏（TagsView）、左侧菜单、面包屑全部由系统 layout 提供，
 *    本页只负责填充内容区，因此和全站视觉天然一致；
 * 2. 内容区以 iframe 加载静态原型 `public/cockpit/cockpit-embed.html`（布局 + 7 个面板 + 假数据），
 *    改动原型不需要动本项目代码，刷新即可看到效果；
 * 3. 后续接入真实数据时，按《驾驶舱-第一版设计-20261016.md》把 iframe 内的面板
 *    逐块替换为 Vue 组件（图表 echarts 6、地图复用 maplibre-gl 封装）。
 */
const frameSrc = `${import.meta.env.BASE_URL}cockpit/cockpit-embed.html`;
console.log('frameSrc', frameSrc);
</script>

<style scoped lang="scss">
.cockpit-page {
  width: 100%;
  height: 100%;
  background-color: #f5f7fb;
}

.cockpit-frame {
  display: block;
  width: 100%;
  height: 100%;
  border: 0;
}
</style>
