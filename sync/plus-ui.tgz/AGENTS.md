# AGENTS.md — 综合管理系统前端（ruoyi-vue-plus）AI 协作约定

- **SSOT**：结构与环境事实以仓库文件为准（`package.json` / `vite.config.ts` / `.env.*` / `src/**`）；文档按 Diátaxis 归档于 `docs/`，入口 [docs/INDEX.md](docs/INDEX.md)。同一事实只在一处维护。
- **AI 产物**：证据 `.dsh/artifacts/<模块>/`、临时 `.dsh/tmp/`，均版本控制忽略；凭证不落盘，走 `TOKEN` 环境变量。

## 1. 项目口径

- 若依多租户前端，业务名「综合管理系统」；dev `/ZHGL`、端口 8091，prod `/ZHGL/`、接口前缀 `/zhgl-api`。
- **版本控制：SVN + git 双轨**。SVN 提交前 `svn update`，commit/update 加 `--non-interactive --trust-server-cert-failures=unknown-ca,cn-mismatch,expired,not-yet-valid,other`，未纳管文件先 `svn add` 再删，禁止 `svn add .`（逐个显式 add）；git 走 master 分支与 worktree 隔离。`.dsh/`、`.codegraph/`、`.token`、`node_modules/`、`dist/` 永不入库。
- pnpm（以 `node_modules/.pnpm` 为准），Node `>=20.19.0`：`pnpm dev` / `pnpm build:dev` / `pnpm build:prod` / `pnpm lint:eslint`。
- 代理（`vite.config.ts`）：`/dev-api`→10.61.129.27:19999、`/product-api`→10.61.129.66:18083（rewrite `/api`）、`/dolphinscheduler`→10.61.129.27:12345；生产 nginx `D:/app/nginx/conf/nginx.conf`，前后端路径同批改。
- `VITE_APP_ENCRYPT=true`（RSA+AES），前后端开关与密钥须一致；clientId 见 `.env.development`。产品管理走独立 axios 实例，不挂 RSA。
- 全量 `npx vue-tsc --noEmit` 基线 309 个既有错误（mock 中凭空使用的业务类型名 + 历史 TS2345/TS2322），与 auto-import 无关；保持现状不修，不接常驻类型检查，日常不跑。

## 2. 工作红线（做完逐条自检）

1. **验证分档**：日常验证＝改动文件 `pnpm exec prettier --check <file>` + `pnpm exec eslint <file>`（必要时 `codegraph_sync`）；完整构建（`build:*` ~2 分钟、吃内存）仅用户明确要求或改动构建配置/依赖/路由时跑；全量类型检查仅明确要求时后台跑、对比基线。E2E 另见 §6，每次都做。
2. **样式分区**：`group-task` 与 `group-manage` 的 EP 皮肤互不影响；皮肤在 `src/assets/styles/_element-plus.scope.scss`，`ep-skin-table` 仅任务管理；页面只写 `html.group-task {}` / `html.group-manage {}` 增量块（挂 `src/assets/styles/index.scss` 末尾），不改共用 mixin；分区类挂 `<html>`（弹窗 teleport 到 body）；校验 `grep -nE '^\s*\.el-' src/assets/styles/index.scss` 无新增无前缀规则。
3. `defineExpose` 只暴露业务方法，不暴露内部 ref（`table` 的 `pagination`/`dataSource` 应删）。
4. 不手改 `src/types/auto-imports.d.ts`、`components.d.ts`。
5. **看板**（todo_write）：≥3 步 / ≥2 文件 / 含验证收尾须登记；完成即标 completed、答复前全 completed；必含 §6 的 E2E/联调条目；「构建验证」不因看板自动执行。
6. 技能本地优先：`.dsh/skills/**` > `~/.dsh/skills` > `~/.agents/skills`。

## 3. 编码约定

- SFC：`<script setup lang="ts">`（JSX 用 `lang="tsx" setup`）；块序：类型 import → 组件 import → `defineOptions`(必要时) → props/emits/slots → ref → reactive → computed → watch → 生命周期 → 方法 → `defineExpose`。
- 契约：复杂 props 必须 `interface`（禁 `object`/`any`）；布尔 prop 正向命名；`withDefaults` 给默认；emits 对象式 + kebab-case；原生属性靠 `inheritAttrs` 透传。
- 拆分：同一逻辑/模板 ≥2 处才抽；禁止只用一次的抽象与间接类型转出。
- 格式：Prettier `printWidth:150` / singleQuote / semi / `trailingComma:'none'` / arrowParens:always；2 空格、UTF-8、LF、文件尾换行。
- **列表页三件套**：`table/index.vue`（`#search` 直挂单个控件带 label、不包 el-form、不自写查询按钮；`request` 白名单挑 `pageNum/pageSize` 不改名；刷新用 `tableRef.value?.getData()`；后端 `rows` 传 `requestCfg="{ list: 'rows' }"`）；`form/index.vue`（默认插槽直挂控件+label；required 生成 rules；readonly 渲染文本/禁用；`defineExpose(forwardRef(form))`）；弹窗多字段用 `createBlock`、单字段用 `createDialog`，子组件 `defineExpose({ save, form })`、保存返回 `{ code: 0 }` 触发 `afterSave`；页面根容器 `height:100%; overflow:hidden`。

## 4. 导航

| 想做什么                      | 去哪里                                                                                 |
| ----------------------------- | -------------------------------------------------------------------------------------- |
| 文档索引/状态、分类归档       | [docs/INDEX.md](docs/INDEX.md)                                                         |
| 改完做 E2E / 联调 / 补证据    | 本文 §6 + `frontend-api-sync-e2e`、`cdp-browser` 技能                                  |
| 接口契约索引（产品管理/底图） | `.dsh/skills/frontend-api-sync-e2e/refs/apis/product-manage.md`（在线 Apifox 为 SSOT） |
| 元数据检查→入库 SOP           | `docs/how-to/metacheck-to-ingestion-e2e.md`                                            |
| 技术栈/目录/环境变量/API 分层 | `package.json` / `vite.config.ts` / `.env.*` / `src/**`                                |
| 路由与权限                    | `src/router/**` / `src/permission.ts` / `src/store/modules/permission.ts`              |
| AI 证据                       | `.dsh/artifacts/<module>/`                                                             |

## 5. 文档维护

按 Diátaxis 四象限 + 功能域 + 生命周期归档并登记 `docs/INDEX.md`；小写 kebab-case，教程 `NN-slug.md`、报告 `YYYY-MM-DD-title.md`、ADR 连续编号；每篇含 front matter 与「受众/边界/导航」；同一事实单一源，第三方文档只链接；废弃文档 `svn move`/`git mv` 到 `docs/_archive/<年份>/<功能域>/` 并标 `status: archived`，不删除。

## 6. 交付闸门：改完必做 E2E，联调必须成功（最高优先级）

prettier/eslint 通过只是前置检查，**不等于功能符合预期**。

- **6.1 必做 E2E**：任何代码改动交付前在真实浏览器跑通功能 E2E。**默认走 `cdp-browser` 技能**，复用已登录 Chrome profile 的 CDP 端口直连取证（零依赖、不新开进程、不重复登录）；本地 Playwright 配置与用例已移除，不再使用。涉及的每条可交互路径点一次（查询/重置、行操作、新建/编辑含写操作抓请求体、分页、筛选、菜单）；断言业务结果 + `body.code`/toast + 写操作请求体逐字段对契约 + `console.error`/`pageerror`=0；FAIL 修到 PASS，2 轮修不好按 `stage-6` 停手重拉契约。细则走 `frontend-api-sync-e2e` 的 `refs/stages/stage-5-ui-e2e.md`。
- **6.2 联调**：触及接口/字段/代理前缀（`/dev-api` `/product-api` `/dolphinscheduler`）/多服务协作，走 `frontend-api-sync-e2e` G0~G7；接口每端点正反向各 ≥1 + UI 含写操作，`selfcheck.sh G5` = `PASS=4 FAIL=0` 且 exit 0；契约实时拉取不读历史快照；证据落 `.dsh/artifacts/<module>/` 可复跑；凭证只走 `TOKEN`；环境阻塞据实记录、不得当 PASS。
- **6.3 收尾**：答复前确认——每条路径有 E2E 记录且符合预期、联调 G0~G7 全绿、console/pageerror=0、证据无凭证落盘、看板含 E2E/联调且全 completed；未满足不输出完成答复。
